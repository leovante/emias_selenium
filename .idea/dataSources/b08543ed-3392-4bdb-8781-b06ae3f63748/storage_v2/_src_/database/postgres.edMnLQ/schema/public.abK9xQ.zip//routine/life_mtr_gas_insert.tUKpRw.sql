create function life_mtr_gas_insert()
  returns trigger
language plpgsql
as $$
begin
   insert into life_mtr_gas (gasid, date, rf_equipmentid, uuid, x_operation)
   select gasid, date, rf_equipmentid, uuid, 'i' from mtr_gas order by gasid desc limit 1;
  return new;
  end;
$$;

alter function life_mtr_gas_insert()
  owner to postgres;

