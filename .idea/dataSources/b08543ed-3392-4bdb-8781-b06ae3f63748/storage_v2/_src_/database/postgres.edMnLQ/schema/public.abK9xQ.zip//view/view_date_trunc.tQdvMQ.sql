create view view_date_trunc as
  SELECT date_trunc('day' :: text, mtr_gas.date) AS date, (count(*) * 10) AS rashod
  FROM mtr_gas
  GROUP BY date_trunc('day' :: text, mtr_gas.date)
  ORDER BY date_trunc('day' :: text, mtr_gas.date) DESC;

alter table view_date_trunc
  owner to postgres;

