
CREATE view [V_ExpertPeriod6e4504b5-2293-4e8f-9756-5039e6470f90] as select * from [tmp_ExpertPeriod6e4504b5-2293-4e8f-9756-5039e6470f90]
go

