CREATE VIEW [V_oms_SMReestrLEK_PR_DATE_INJ] AS SELECT 
[hDED].[SMReestrLEK_PR_DATE_INJID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrLEK_PRID] as [rf_SMReestrLEK_PRID], 
[hDED].[DATE_INJ] as [DATE_INJ]
FROM [oms_SMReestrLEK_PR_DATE_INJ] as [hDED]
go

