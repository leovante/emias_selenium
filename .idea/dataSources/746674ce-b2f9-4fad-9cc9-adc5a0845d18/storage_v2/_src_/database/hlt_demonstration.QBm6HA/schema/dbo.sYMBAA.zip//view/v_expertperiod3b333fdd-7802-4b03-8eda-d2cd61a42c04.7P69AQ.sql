
CREATE view [V_ExpertPeriod3b333fdd-7802-4b03-8eda-d2cd61a42c04] as select * from [tmp_ExpertPeriod3b333fdd-7802-4b03-8eda-d2cd61a42c04]
go

