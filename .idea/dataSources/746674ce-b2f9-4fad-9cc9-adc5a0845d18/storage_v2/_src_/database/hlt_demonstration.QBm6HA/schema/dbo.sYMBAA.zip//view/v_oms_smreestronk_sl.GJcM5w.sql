CREATE VIEW [V_oms_SMReestrONK_SL] AS SELECT 
[hDED].[SMReestrONK_SLID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[rf_SMReestrZ_SLID] as [rf_SMReestrZ_SLID], 
[hDED].[DS1_T] as [DS1_T], 
[hDED].[STAD] as [STAD], 
[hDED].[ONK_T] as [ONK_T], 
[hDED].[ONK_N] as [ONK_N], 
[hDED].[ONK_M] as [ONK_M], 
[hDED].[MTSTZ] as [MTSTZ], 
[hDED].[SOD] as [SOD]
FROM [oms_SMReestrONK_SL] as [hDED]
go

