CREATE VIEW [V_oms_ds_PatDSFeature] AS SELECT 
[hDED].[ds_PatDSFeatureID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PatDSGUID] as [rf_PatDSGUID], 
[jT_oms_ds_PatDS].[rf_MKBID] as [SILENT_rf_PatDSGUID], 
[hDED].[rf_DSFeaturesGUID] as [rf_DSFeaturesGUID], 
[jT_oms_ds_DSFeatures].[Name] as [SILENT_rf_DSFeaturesGUID], 
[hDED].[rf_DSFeatureParamsGUID] as [rf_DSFeatureParamsGUID], 
[jT_oms_ds_DSFeatureParams].[Name] as [SILENT_rf_DSFeatureParamsGUID], 
[hDED].[rf_RecordID] as [rf_RecordID], 
[hDED].[Value] as [Value], 
[hDED].[Flags] as [Flags], 
[hDED].[PatDSFeatureGUID] as [PatDSFeatureGUID], 
[hDED].[Description] as [Description]
FROM [oms_ds_PatDSFeature] as [hDED]
INNER JOIN [oms_ds_PatDS] as [jT_oms_ds_PatDS] on [jT_oms_ds_PatDS].[PatDSGUID] = [hDED].[rf_PatDSGUID]
INNER JOIN [oms_ds_DSFeatures] as [jT_oms_ds_DSFeatures] on [jT_oms_ds_DSFeatures].[DSFeaturesGUID] = [hDED].[rf_DSFeaturesGUID]
INNER JOIN [oms_ds_DSFeatureParams] as [jT_oms_ds_DSFeatureParams] on [jT_oms_ds_DSFeatureParams].[DSFeatureParamsGUID] = [hDED].[rf_DSFeatureParamsGUID]
go

