
create PROCEDURE CheckLSUpd
	(
	  @table_oms nvarchar(50),--переменная содержит название таблицы OMS
      @table_dbf nvarchar(50),--переменная содержит название таблицы dbf
      @server_name nvarchar(30),--переменная содержит название подлинкованного сервера
	  @table_conn  nvarchar(30)--переменная содержит название таблицы отношений
	)
AS
	SET NOCOUNT ON
    --объявление локальных переменных
    declare @tab_oms nvarchar(50)
    declare @col_id nvarchar (50)
    declare @SQL nvarchar(1000)
    declare @tab_dbf nvarchar(50)
    declare @server_name_n nvarchar(250)
	declare @tab_oms1 nvarchar (50)
	declare @server_name_n1 nvarchar(250)
	declare @col_id1 nvarchar(250)

   -- таблица для хранения результатов
    create table #res (
          table_name varchar(50),
          status varchar(20),
          column_name varchar(50),
          id_value varchar(150),--bigint,
          count_times int
   )
    -- таблица для хранения информации о полях всех таблиц сервера @server_name
    create table #tmp (
		table_cat varchar(254),
		table_schem varchar(254),
		table_name varchar(254),
		column_name varchar(254),
		data_type smallint,
		type_name varchar(13),
		column_size int,
		buffer_length int,
		decimal_digits smallint,
		num_prec_radix smallint,
		nullable smallint,
		remarks varchar(254),
		column_def varchar(254),
		sql_data_type smallint,
		sql_datetime_sub smallint,
		char_octet_length int,
		ordinal_position int,
		is_nullable varchar(254),
		ss_data_type tinyint);
--Таблица, где хранятся значения таблицы отношений
Create table #tables (
  table_oms varchar(24),
  table_dbf varchar(24)
)
if not exists(select * from sysobjects where [name] = 'inf_tables') 
Begin
	CREATE TABLE inf_tables(
	table_n varchar(24),
	Status int,
	Rem varchar(200)
	)
end
	Set @SQL='INSERT INTO #tables Select * FROM '+@table_conn
	EXECUTE sp_executesql @SQL

	--Идет замена для корректного поиска
	Set @server_name_n=Replace(@server_name,'...','')
	INSERT INTO #tmp exec sp_columns_ex @server_name_n
    
    --таблица для хранения информации обо всех таблицах прилинкованного сервера @server_name
    create table #s_tables(
			table_cat varchar(254),
			table_schem varchar(254),
			table_name varchar(254),
			table_type varchar(32),
			remarks varchar(254)        
    )
    create table #t(
			a varchar(254)        
    )
    INSERT INTO #s_tables exec sp_tables_ex @server_name_n

    --поиск всех таблиц в Oms, на которые есть ссылки в @table_oms 
    DECLARE rf_tables CURSOR 
    FOR
    SELECT HeadTable FROM x_DocTypeDef
    WHERE DocTypeDefId IN (SELECT LinkedDocTypeDefId from x_DocElemDef e
                          INNER JOIN x_DocTypeDef t on t.DocTypeDefID=e.DocTypeDefID
                          WHERE HeadTable = @table_oms and e.name like 'rf_%')
    UNION SELECT @table_oms

    OPEN rf_tables
    FETCH rf_tables INTO @tab_oms

    WHILE (@@FETCH_STATUS>=0) BEGIN
        -- поиск в таблице в Oms поля с индексом 'IX%', которое будет ключевым для
        -- соответствующей таблицы в dbf
		SET @col_id=null;
		Set @server_name_n =null;--для использования в left outer join
        SELECT @col_id = ISNULL(@col_id,'')+ CASE WHEN @col_id IS NULL THEN '' ELSE ', ' END +c.name,
				@server_name_n=ISNULL(@server_name_n,'')+ CASE WHEN @server_name_n IS NULL THEN '' ELSE ', ' END +c.name+'/'+c.name 
				FROM sys.index_columns ic
           LEFT JOIN sys.indexes i ON ic.object_id=i.object_id
             LEFT JOIN sys.columns c ON ic.object_id=c.object_id
        WHERE ic.index_id=i.index_id and ic.column_id=c.column_id
            and i.name like 'IX%'and ic.object_id=object_id(@tab_oms)

        --если в базе вдруг не оказалось нужного индекса
        IF @col_id='' OR @col_id is NULL
		BEGIN
        PRINT 'Не найдено индекса для таблицы '+@tab_oms
		Insert into inf_tables values(@tab_oms,1,'')
		END
        --а если индекс найден, то надо выбрать из #tables 
        --соответствующую @tab_oms таблицу для dbf и проверить ее
        --на повторяющиеся записи, записи с пустым id и битые ссылки
        ELSE BEGIN
            SET @tab_dbf=''
            --ищем имя соответствующей таблицы в @table_conn
			SELECT @tab_dbf=table_dbf FROM #tables WHERE table_oms=@tab_oms
--------------------------------------------------------------------------------------------------------------------
-------------------Выполняется для таблиц OMS-----------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
			PRINT 'Проверяется таблица '+@tab_oms+' '+@col_id
			Insert into inf_tables values(@tab_oms,2,'')
			-- поиск записей, у которых пустой id или равный нулю
			SET @SQL = 'INSERT INTO #res  SELECT '''+@tab_oms+''', ''Пустой id'', '''+
			  @col_id+''', '+'cast( '+Replace(@col_id,', ',' as varchar)+'', ''+cast( ')+' as varchar), COUNT(*) FROM '+
			  @tab_oms+' WHERE ('+Replace(@col_id,', ','  IS NULL OR ')+' IS NULL OR '+Replace(@col_id,', ','=''0'' OR ')+'=''0'') AND '+Replace(@tab_oms,'oms_','')+'ID<>0'+
				' GROUP BY '+@col_id
			EXECUTE sp_executesql @SQL
			--поиск дублирующихся записей
			SET @SQL = 'INSERT INTO #res SELECT '''+@tab_oms+''', ''Дубли'', '''+@col_id+''', '+
              'cast( '+Replace(@col_id,', ',' as varchar)+'', ''+cast( ')+' as varchar), COUNT(*) FROM '+@tab_oms+
              ' GROUP BY '+@col_id+' HAVING COUNT(*)>1'
			EXECUTE sp_executesql @SQL
			--поиск ссылок на несуществующий id
			IF @tab_oms<>@table_oms
			BEGIN
				SET @SQL='INSERT INTO #res SELECT '''+@table_oms+''', ''Битая ссылка'', '''+'rf_'+
					Replace(@tab_oms,'oms_','')+'ID'',t1.'+'rf_'+Replace(@tab_oms,'oms_','')+'ID,COUNT(t1.rf_'+
					Replace(@tab_oms,'oms_','')+'ID) FROM '+@table_oms+' t1 LEFT JOIN '+@tab_oms+' t2 ON t1.rf_'+
					Replace(@tab_oms,'oms_','')+'ID=t2.'+Replace(@tab_oms,'oms_','')+'ID'+' WHERE t2.'+
					Replace(@tab_oms,'oms_','')+'ID'+' IS NULL GROUP BY t1.'+'rf_'+Replace(@tab_oms,'oms_','')+'ID'
 					EXECUTE sp_executesql @SQL
					Insert into inf_tables values(@tab_oms,3,@table_oms+' по полю '+'rf_'+Replace(@tab_oms,'oms_','')+'ID')
			END
-------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------				
		--если dbf не нашлось на подлинкованном сервере		 
		IF @tab_dbf=''
			BEGIN
                PRINT 'Не задано соответствие для таблицы '+@tab_oms
				Insert into inf_tables values(@tab_oms,4,'')
			END
        ELSE
		BEGIN
		--если в качестве индекса выступает ссылка, то заменяем на индекс таблицы, на которую ссылается эта ссылка
		IF charindex('rf_',@col_id)>0
		BEGIN
		--это необходимо, если индекс-ссылка составная, например rf_LPUID (MCOD+OGRN)
			Select @col_id1=isnull(@col_id1,'')+case when @col_id1 is null then '' else ', ' end+ c.name,
			@server_name_n1=isnull(@server_name_n1,'')+case when @server_name_n1 is null then '' else ', ' end+ c.name+'/'+c.name
			FROM sys.index_columns ic
			LEFT JOIN sys.indexes i ON ic.object_id=i.object_id
			LEFT JOIN sys.columns c ON ic.object_id=c.object_id
            WHERE ic.index_id=i.index_id and ic.column_id=c.column_id
			and i.name like 'IX%'and ic.object_id=object_id('oms_'+substring(@col_id,charindex('rf_',@col_id)+3,charindex('ID',@col_id)-charindex('rf_',@col_id)-3))		
			SELECT 
            @server_name_n=Replace(@server_name_n,substring(@server_name_n,charindex('rf_',@server_name_n),len(@server_name_n)),@server_name_n1),
			@col_id=Replace(@col_id,substring(@col_id,charindex('rf_',@col_id),charindex('ID',@col_id)+2-charindex('rf_',@col_id)),@col_id1)
		END
		--Проверка наличия ДБФ на сервере
                 IF NOT EXISTS(SELECT * FROM #s_tables WHERE table_name=@tab_dbf)
					BEGIN
				    PRINT 'На сервере '+@server_name+' нет таблицы с именем '+@tab_dbf
					Insert into inf_tables values(@tab_dbf,5,'')

					END
				 ELSE
					BEGIN
					/*Если мы проверяем аптеку, то ключевым считаем поле A_COD*/
					if @tab_oms='oms_APU' Set @col_id='A_COD'
					/*Если проверяются таблицы с ОКАТО, надо менять название поля*/
					if @table_oms in ('oms_APU','oms_LPU','oms_doctor','oms_OKATO')
					BEGIN
							Set @col_id=Replace(@col_id,'C_OKATO','TF_OKATO')
							Set @server_name_n=Replace(@server_name_n,'C_OKATO','TF_OKATO')
					END
					/*Если проверяются таблицы Tender,sp_rice, надо менять название поля*/
					if @tab_oms in ('oms_Tender','oms_CLS')
					BEGIN
							Set @col_id=Replace(@col_id,'Num','NUM_KON')
							Set @col_id=Replace(@col_id,'FO_OGRN','F_OGRN')
							Set @server_name_n=Replace(@server_name_n,'Num','NUM_KON')
							if @table_oms='oms_SFO' Set @server_name_n=Replace(@server_name_n,'FO_OGRN/','F_OGRN/')
							else Set @server_name_n=Replace(@server_name_n,'FO_OGRN','F_OGRN')
					END
					SET @SQL='INSERT INTO #t SELECT count(*) FROM #tmp WHERE table_name='''+@tab_dbf+''' and column_name in ('''+Replace(@col_id,', ',''', ''')+''')'
					EXECUTE sp_executesql @SQL
					SET @SQL='-1'
					Select @SQL=cast(a as varchar) from #t
					delete from #t
					--Проверка на наличие ВСЕХ ключевых полей с таким названием в таблице
                    IF @SQL<>isnull(cast((len(@col_id)-len(Replace(@col_id,', ','')))/2+1 as varchar),'0') 
					BEGIN
					PRINT 'В таблице '+@tab_dbf+' нет столбца с именем '+@col_id
					Insert into inf_tables values(@tab_dbf,6,@table_dbf+' по полю '+@col_id)
					END					   
					ELSE	
						BEGIN
					    if @tab_oms='oms_SFO' and @table_oms='oms_Tender' 
						SET @SQL='INSERT INTO #t SELECT count(*) FROM #tmp WHERE table_name='''+@table_dbf+''' and column_name in ('''+Replace(Replace(@col_id,', ',''', '''),'FO_OGRN','F_OGRN')+''')'
						else 
						SET @SQL='INSERT INTO #t SELECT count(*) FROM #tmp WHERE table_name='''+@table_dbf+''' and column_name in ('''+Replace(@col_id,', ',''', ''')+''')'
						EXECUTE sp_executesql @SQL
						SET @SQL='-1'
						Select @SQL=cast(a as varchar) from #t
						delete from #t
				    --Проверка на наличие ВСЕХ ключевых полей с таким названием в таблице
					IF @SQL<>isnull(cast((len(@col_id)-len(Replace(@col_id,', ','')))/2+1 as varchar),'0') 
					BEGIN
					PRINT 'В таблице '+@table_dbf+' нет столбца с именем '+@col_id
					Insert into inf_tables values(@table_dbf,6,@tab_dbf+' по полю '+@col_id)
					END	
                    ELSE
				    BEGIN 
------------------------------------------------------------------------------------------------------------------
--------------Выполняется для таблиц на подлинкованном сервере----------------------------------------------------
------------------------------------------------------------------------------------------------------------------
					PRINT 'Проверяется таблица '+@server_name+@table_dbf+' '+@tab_dbf+' '+@col_id
					Insert into inf_tables values(@tab_dbf,2,'')
						-- поиск записей, у которых пустой id или равный нулю
						SET @SQL = 'INSERT INTO #res  SELECT '''+@tab_dbf+''', ''Пустой id'', '''+
						  @col_id+''', '+'cast( cast(Replace('+Replace(@col_id,', ',','' '','''') as bigint) as varchar)+'', ''+cast( cast(Replace(')+','' '','''') as bigint) as varchar), COUNT(*) FROM '+
			  		      @server_name+@tab_dbf+' WHERE ('+Replace(@col_id,', ','  IS NULL OR ')+' IS NULL OR '+Replace(@col_id,', ','=''0'' OR ')+'=''0'') GROUP BY '+@col_id					
			
 EXECUTE sp_executesql @SQL
						--поиск дублирующихся записей
						SET @SQL = 'INSERT INTO #res SELECT '''+@tab_dbf+''', ''Дубли'', '''+@col_id+''', '+
                          'cast( cast(Replace('+Replace(@col_id,', ',','' '','''')  as bigint) as varchar)+'', ''+cast( cast(Replace(')+','' '','''')  as bigint) as varchar), COUNT(*) FROM '+@server_name+@tab_dbf+
                          ' GROUP BY '+@col_id+' HAVING COUNT(*)>1'	
						
EXECUTE sp_executesql @SQL
						--поиск ссылок на несуществующий id
						IF @tab_dbf<>@table_dbf
						BEGIN
					        if @tab_oms='oms_SFO' and @table_oms='oms_Tender' 
							BEGIN 
								Set @col_id=Replace(@col_id,'FO_OGRN','F_OGRN')
								Set @server_name_n=Replace(@server_name_n,'FO_OGRN/','F_OGRN/')
							SET @SQL ='INSERT INTO #res SELECT '''+@table_dbf+''', ''Битая ссылка'', '''+@col_id+''', '+
									'cast( cast(t1.'+Replace(@col_id,', ',' as bigint) as varchar)+'', ''+cast( cast(t1.')+' as bigint) as varchar), COUNT(*) FROM '+@server_name+@table_dbf+' t1 LEFT JOIN '+
	       							@server_name+@tab_dbf+' t2 ON t1.'+Replace(Replace(@server_name_n,'/','=t2.'),', ',' and t1.')+' WHERE t2.'+
									+Replace(Replace(@col_id,'F_OGRN','FO_OGRN'),', ','  IS NULL OR t2.')+' IS NULL GROUP BY t1.'+Replace(@col_id,', ',',t1.')							

							END
							else
							SET @SQL ='INSERT INTO #res SELECT '''+@table_dbf+''', ''Битая ссылка'', '''+@col_id+''', '+
									'cast( cast(t1.'+Replace(@col_id,', ',' as bigint) as varchar)+'', ''+cast( cast(t1.')+' as bigint) as varchar), COUNT(*) FROM '+@server_name+@table_dbf+' t1 LEFT JOIN '+
	       							@server_name+@tab_dbf+' t2 ON t1.'+Replace(Replace(@server_name_n,'/','=t2.'),', ',' and t1.')+' WHERE t2.'+
									+Replace(@col_id,', ','  IS NULL OR t2.')+' IS NULL GROUP BY t1.'+Replace(@col_id,', ',',t1.')							
						
EXECUTE sp_executesql @SQL
						Insert into inf_tables values(@tab_dbf,3,isnull(@table_dbf,'')+' по полю '+isnull(@col_id,''))
						END
--------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------
					END
				END
				END
             END
			END
        FETCH rf_tables INTO @tab_oms
    END

--Результат заносится во временную таблицу
if not exists(select * from sysobjects where [name] = 'tmp_LSresult') 
Begin
	CREATE TABLE [tmp_LSresult](
	[table_name] varchar(50),
	[status] varchar(20),
	[column_name] varchar(50),
	[id_value] varchar(150),
	[count_times] int
	)
end
--Вставка только тех значений, которых еще нет в таблице
    Insert into tmp_LSresult 
	Select #res.[table_name],#res.[status],#res.[column_name],#res.[id_value],#res.[count_times] from #res 
	left outer join tmp_LSresult on tmp_LSresult.[table_name]=#res.[table_name] and tmp_LSresult.[status]=#res.[status]
		and tmp_LSresult.[column_name]=#res.[column_name] and tmp_LSresult.[id_value]=#res.[id_value] and tmp_LSresult.[count_times]=#res.[count_times]
	where tmp_LSresult.[table_name] is NULL
	group by #res.[table_name],#res.[status],#res.[column_name],#res.[id_value],#res.[count_times]
	ORDER BY #res.table_name
--Удаление временных таблиц
    CLOSE rf_tables
    DEALLOCATE rf_tables
    drop table #res
    drop table #tmp
    drop table #s_tables
	drop table #tables
	drop table #t
RETURN(0)

go

