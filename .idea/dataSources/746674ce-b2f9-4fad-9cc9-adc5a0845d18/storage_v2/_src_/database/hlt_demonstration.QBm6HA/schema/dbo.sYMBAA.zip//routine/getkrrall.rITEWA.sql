
create FUNCTION [dbo].[GetKRRAll](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int
)
RETURNS @result TABLE (
vidID int,
info varchar(max),
[Value] [decimal](38, 3) NULL

)
AS
begin
INSERT INTO @result
select (select krrVidId from oms_krrvid where vidK_Code ='2'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='2' and @typeid=rf_kl_DepartmentTypeid union 
  select (select krrVidId from oms_krrvid where vidK_Code ='06'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='06' and @age<=3 and @age >=1 and @typeid=rf_kl_DepartmentTypeid union 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR1'),'', valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR1' and @age<1 and Replace(@usl1,'300DRG0117','')  not in ('105','106','107','108','109','110','111')  and @typeid=rf_kl_DepartmentTypeid union 
  select (select krrVidId from oms_krrvid where vidK_Code ='09'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='09' and @typeid=rf_kl_DepartmentTypeid and Replace(@usl1,'300DRG0116','')  not in ('002','003','004','005','011','012','016','083','084','097','140','148','149','153','154','155','179','200','252','281','295','299') and Replace(@usl1,'300DRG0117','')  not in ('002','003','004','005','011','012','016','084','300','097','146','154','155','159','160','161','185','206','258','287','302','306') and  @dlit<=3 and @usl2 like 'A16.%' union 
  select (select krrVidId from oms_krrvid where vidK_Code ='05'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='05' and @typeid=rf_kl_DepartmentTypeid and Replace(@usl1,'300DRG0116','')  not in ('002','003','004','005','011','012','016','083','084','097','140','148','149','153','154','155','179','200','252','281','295','299') and Replace(@usl1,'300DRG0117','')  not in ('002','003','004','005','011','012','016','084','300','097','146','154','155','159','160','161','185','206','258','287','302','306') and  @dlit<=3 and @usl2 not like 'A16.%' union 
  select (select krrVidId from oms_krrvid where vidK_Code ='3_01'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  inner join oms_lpu on lpuid =@LPUID where  V_oms_krr.rf_LPUID in( @LPUID, rf_mainLPUID) and  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='3_01' and Replace(@usl1,'300DRG0116','') not in ('001','002','003','004','005','006','007','008','009','010','011','012','013','014','105','106','107','108','109','110') and Replace(@usl1,'300DRG0117','') not in (      '002','003','004','005','006','007','008','009','010','011','012','013','014','105','106','107','108','109','110','111','017','029','084','095','159','195','197','199','200','204','230','243','253','259','271','272','273','274','275','300','302','306') and @typeid=rf_kl_DepartmentTypeid union 
  select (select krrVidId from oms_krrvid where vidK_Code ='08'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  inner join oms_lpu on lpuid =@LPUID where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='08' and rf_LPUID in (@lpuid, rf_MainLPUID)  and  V_ServiceMedicalCode1=@usl1 and @typeid=rf_kl_DepartmentTypeid union 
  select (select krrVidId from oms_krrvid where vidK_Code ='5_01'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId inner join oms_lpu on lpuid =@LPUID inner join oms_kl_DepartmentProfile on  kl_DepartmentProfileId= @profileId where V_oms_krr.rf_LPUID in ( @LPUID, rf_mainLPUID)  and  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='5_01' and @typeid=rf_kl_DepartmentTypeid and  (( Replace(@usl1,'300DRG0116','')  in ('001','002','003','004','005','006','007','008','009','010','011','012','013','014','105','106','107','108','109','110') ) or ( Replace(@usl1,'300DRG0117','')  in (      '002','003','004','005','006','007','008','009','010','011','012','013','014','105','106','107','108','109','110','111'))) union 
  select (select krrVidId from oms_krrvid where vidK_Code ='KDG08'),'',/*valueKRR*/ 0 from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KDG08' and @age>4 and @age<18 and @typeid=rf_kl_DepartmentTypeid union 
  select (select krrVidId from oms_krrvid where vidK_Code ='07'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  inner join oms_lpu on lpuid =@LPUID where  V_oms_krr.date_E>@date and V_oms_krr.date_B<@date and VidK_Code='07'  and rf_LPUID in (@lpuid, rf_MainLpuid) and @age<18 and @usl1 <>  '300DRG0116153' and V_ServiceMedicalCode1=@usl1 and V_ServiceMedicalCode2=@usl2 and @typeid=rf_kl_DepartmentTypeid union 
  select (select krrVidId from oms_krrvid where vidK_Code ='Кпс'),'',
 
case when @dlit > valueKrr or   @mkb in (select mkbid from oms_mkb 
 
where DS in (
 
'F10.0',
 
'F11.0',
 
'F12.0',
 
'F13.0',
 
'F14.0',
 
'F15.0',
 
'F16.0',
 
'F18.0',
 
'F19.0',
 
'F10.1',
 
'F11.1',
 
'F12.1',
 
'F13.1',
 
'F14.1',
 
'F15.1',
 
'F16.1',
 
'F18.1',
 
'F19.1',
 
'F10.3',
 
'F11.3',
 
'F12.3',
 
'F13.3',
 
'F14.3',
 
'F15.3',
 
'F16.3',
 
'F18.3',
 
'F19.3'))
 
then 1 else
 
round(@dlit/valuekrr,6)  end from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId   where   V_ServiceMedicalCode1=@usl1 and V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='Кпс' union 
  select (select krrVidId from oms_krrvid where vidK_Code ='KDG07'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KDG07' and @age>=75 and @usl1 <>  '300DRG0116153' and @typeid=rf_kl_DepartmentTypeid union 
  select (select krrVidId from oms_krrvid where vidK_Code ='08_1'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='08_1' and @typeid=rf_kl_DepartmentTypeid and (V_ServiceMedicalCode1=@usl1 or V_ServiceMedicalCode1='не определено') and (V_ServiceMedicalCode2=@usl2 or V_ServiceMedicalCode2='не определено') and (rf_MkbId=@mkb or rf_MKBID=0) union 
  select (select krrVidId from oms_krrvid where vidK_Code ='09_'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId inner join tmp_KRRFor70age  t on t.usl=@usl1 and @date between t.Date_B and t.date_E  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='09_' and @age>=70 and @usl1 = V_ServiceMedicalCode1  and @typeid=rf_kl_DepartmentTypeid 
 
 
 declare @info varchar(max)
 set @info=''
declare @vid06 decimal(18,6) set @vid06= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='06' and @age<=3 and @age >=1 and @typeid=rf_kl_DepartmentTypeid),0) 
 if (@vid06<=0) set @info= @info +' 06='+convert(varchar(30),@vid06)
  declare @vidKR1 decimal(18,6) set @vidKR1= isnull((select  valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR1' and @age<1 and Replace(@usl1,'300DRG0117','')  not in ('105','106','107','108','109','110','111')  and @typeid=rf_kl_DepartmentTypeid),0) 
 if (@vidKR1<=0) set @info= @info +' KR1='+convert(varchar(30),@vidKR1)
  declare @vid08 decimal(18,6) set @vid08= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  inner join oms_lpu on lpuid =@LPUID where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='08' and rf_LPUID in (@lpuid, rf_MainLPUID)  and  V_ServiceMedicalCode1=@usl1 and @typeid=rf_kl_DepartmentTypeid),0) 
 if (@vid08<=0) set @info= @info +' 08='+convert(varchar(30),@vid08)
  declare @vidKDG08 decimal(18,6) set @vidKDG08= isnull((select /*valueKRR*/ 0 from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KDG08' and @age>4 and @age<18 and @typeid=rf_kl_DepartmentTypeid),0) 
 if (@vidKDG08<=0) set @info= @info +' KDG08='+convert(varchar(30),@vidKDG08)
  declare @vid07 decimal(18,6) set @vid07= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  inner join oms_lpu on lpuid =@LPUID where  V_oms_krr.date_E>@date and V_oms_krr.date_B<@date and VidK_Code='07'  and rf_LPUID in (@lpuid, rf_MainLpuid) and @age<18 and @usl1 <>  '300DRG0116153' and V_ServiceMedicalCode1=@usl1 and V_ServiceMedicalCode2=@usl2 and @typeid=rf_kl_DepartmentTypeid),0) 
 if (@vid07<=0) set @info= @info +' 07='+convert(varchar(30),@vid07)
  declare @vidKDG07 decimal(18,6) set @vidKDG07= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KDG07' and @age>=75 and @usl1 <>  '300DRG0116153' and @typeid=rf_kl_DepartmentTypeid),0) 
 if (@vidKDG07<=0) set @info= @info +' KDG07='+convert(varchar(30),@vidKDG07)
  declare @vid08_1 decimal(18,6) set @vid08_1= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='08_1' and @typeid=rf_kl_DepartmentTypeid and (V_ServiceMedicalCode1=@usl1 or V_ServiceMedicalCode1='не определено') and (V_ServiceMedicalCode2=@usl2 or V_ServiceMedicalCode2='не определено') and (rf_MkbId=@mkb or rf_MKBID=0)),0) 
 if (@vid08_1<=0) set @info= @info +' 08_1='+convert(varchar(30),@vid08_1)
  declare @vid09_ decimal(18,6) set @vid09_= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId inner join tmp_KRRFor70age  t on t.usl=@usl1 and @date between t.Date_B and t.date_E  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='09_' and @age>=70 and @usl1 = V_ServiceMedicalCode1  and @typeid=rf_kl_DepartmentTypeid),0) 
 if (@vid09_<=0) set @info= @info +' 09_='+convert(varchar(30),@vid09_)
 
  INSERT INTO @result 
  select (select krrVidId from oms_krrvid where vidK_Code ='КСЛП_01'),@info,(select case when (select case when @vid09_>0 then @vid09_ else case when (@vid06>0 or @vidKR1>0 or @vid07>0 or @vidKDG07>0 or @vidKDG08>0) and  @vid08>=1 then @vid08-1 else @vid08 end +  case when @vid06>0 and @vid07>0 then @vid06 else case when @vidKDG08>0 and  @vid07>0 then @vidKDG08 else @vidKDG08+@vid07+@vid06+@vidKR1+@vid08_1 end end + @vidKDG07 end )>1.8 then 1.8 else case when @vid09_>0 then @vid09_  else case when (@vid06>0 or @vid07>0 or @vidKR1>0 or @vidKDG07>0 or @vidKDG08>0) and  @vid08>=1 then @vid08-1 else @vid08 end + case when @vid06>0 and @vid07>0 then @vid06 else case when @vidKDG08>0 and  @vid07>0 then @vidKDG08 else @vidKDG08+@vid07+@vid06+@vidKR1+@vid08_1 end end +@vidKDG07 end end) where (select case when (select case when @vid09_>0 then @vid09_ else case when (@vid06>0 or @vidKR1>0 or @vid07>0 or @vidKDG07>0 or @vidKDG08>0) and  @vid08>=1 then @vid08-1 else @vid08 end +  case when @vid06>0 and @vid07>0 then @vid06 else case when @vidKDG08>0 and  @vid07>0 then @vidKDG08 else @vidKDG08+@vid07+@vid06+@vidKR1+@vid08_1 end end + @vidKDG07 end )>1.8 then 1.8 else case when @vid09_>0 then @vid09_  else case when (@vid06>0 or @vid07>0 or @vidKR1>0 or @vidKDG07>0 or @vidKDG08>0) and  @vid08>=1 then @vid08-1 else @vid08 end + case when @vid06>0 and @vid07>0 then @vid06 else case when @vidKDG08>0 and  @vid07>0 then @vidKDG08 else @vidKDG08+@vid07+@vid06+@vidKR1+@vid08_1 end end +@vidKDG07 end end) >0 
  return end
go

