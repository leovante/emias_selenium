CREATE VIEW [V_dd_DDResearchAreaLevel] AS SELECT 
[hDED].[DDResearchAreaLevelID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDAreaLevelTypeGUID] as [rf_DDAreaLevelTypeGUID], 
[jT_dd_DDAreaLevelType].[Name] as [SILENT_rf_DDAreaLevelTypeGUID], 
[hDED].[rf_DDStateOfHealthAfterID] as [rf_DDStateOfHealthAfterID], 
[jT_dd_DDStateOfHealthAfter].[PreviouslyRegistered] as [SILENT_rf_DDStateOfHealthAfterID], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDResearchAreaLevel] as [hDED]
INNER JOIN [dd_DDAreaLevelType] as [jT_dd_DDAreaLevelType] on [jT_dd_DDAreaLevelType].[UGUID] = [hDED].[rf_DDAreaLevelTypeGUID]
INNER JOIN [dd_DDStateOfHealthAfter] as [jT_dd_DDStateOfHealthAfter] on [jT_dd_DDStateOfHealthAfter].[DDStateOfHealthAfterID] = [hDED].[rf_DDStateOfHealthAfterID]
go

