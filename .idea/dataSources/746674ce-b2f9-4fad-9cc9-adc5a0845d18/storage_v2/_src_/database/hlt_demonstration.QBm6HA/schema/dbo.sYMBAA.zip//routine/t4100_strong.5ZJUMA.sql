CREATE FUNCTION T4100_strong (@ds nvarchar(4000), @DateBegin datetime, @DateEnd datetime)
RETURNS TABLE
AS
RETURN 
(
SELECT 
count(TAP.TAPID) as appeal,
count(case when t_id is null then TAP.TAPID else null end) as povt
from oms_MKB MKB 
inner join selectByMKB(@ds) SBMKB on (MKB.MKBID=SBMKB.MKBID)
inner join hlt_TAP TAP WITH(NOLOCK) on (MKB.MKBID=TAP.rf_MKBID)
inner join oms_kl_VisitResult  on kl_VisitResultID=rf_kl_VisitResultID and kl_VisitResultID>0 and  
oms_kl_VisitResult.name <>'Лечение продолжено'
inner join oms_Department WITH(NOLOCK) on oms_Department.DepartmentID=TAP.rf_DepartmentID 
inner join oms_kl_DepartmentType td WITH(NOLOCK) on kl_DepartmentTypeID=oms_Department.rf_kl_DepartmentTypeID and td.Code='3'
inner join hlt_MKAB MKAB WITH(NOLOCK) on (MKAB.MKABID=TAP.rf_MKABID)
				left join (
				Select min(TAPID) as t_id from hlt_TAP t
				where t.DateTAP between @DateBegin and @DateEnd
				group by t.rf_MKABID,t.rf_MKBID
				)t_min on t_min.t_id=TAp.TAPID
    where (1=1 and convert(varchar(100),TAP.rf_DepartmentID)='2445' or 1=0) and 
	(1=1 and convert(varchar(100),TAP.rf_LPUDoctorID)='1928' or 1=0) and 
	(0=1 and convert(varchar(100),rf_CitizenID)='@hltCitizen.CitizenID' or 0=0) and 
	(1=1 and convert(varchar(100),oms_Department.rf_lpuid)='1788' or 1=0) and 
(TAP.DateTAP between @DateBegin and @DateEnd) and MKB.DS like 'Z%'
and ((MKAB.W = 0 and case when (case when DATEADD(YEAR, (DATEPART(YEAR, TAP.DateTAP) - DATEPART(YEAR, MKAB.Date_BD)) ,MKAB.Date_BD)>TAP.DateTAP then (DATEPART(YEAR, TAP.DateTAP) - DATEPART(YEAR, MKAB.Date_BD)) -1
      else (DATEPART(YEAR, TAP.DateTAP) - DATEPART(YEAR, MKAB.Date_BD))
       end ) <0 then 0
       else (case when DATEADD(YEAR, (DATEPART(YEAR, TAP.DateTAP) - DATEPART(YEAR, MKAB.Date_BD)) ,MKAB.Date_BD)>TAP.DateTAP then (DATEPART(YEAR, TAP.DateTAP) - DATEPART(YEAR, MKAB.Date_BD)) -1
      else (DATEPART(YEAR, TAP.DateTAP) - DATEPART(YEAR, MKAB.Date_BD))
       end ) end >54) OR
			(MKAB.W = 1 and case when (case when DATEADD(YEAR, (DATEPART(YEAR, TAP.DateTAP) - DATEPART(YEAR, MKAB.Date_BD)) ,MKAB.Date_BD)>TAP.DateTAP then (DATEPART(YEAR, TAP.DateTAP) - DATEPART(YEAR, MKAB.Date_BD)) -1
      else (DATEPART(YEAR, TAP.DateTAP) - DATEPART(YEAR, MKAB.Date_BD))
       end ) <0 then 0
       else (case when DATEADD(YEAR, (DATEPART(YEAR, TAP.DateTAP) - DATEPART(YEAR, MKAB.Date_BD)) ,MKAB.Date_BD)>TAP.DateTAP then (DATEPART(YEAR, TAP.DateTAP) - DATEPART(YEAR, MKAB.Date_BD)) -1
      else (DATEPART(YEAR, TAP.DateTAP) - DATEPART(YEAR, MKAB.Date_BD))
       end ) end >59))
)
go

