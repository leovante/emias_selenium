CREATE VIEW [V_oms_sr_MessType] AS SELECT 
[hDED].[sr_MessTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[version] as [version], 
[hDED].[XmsXSD] as [XmsXSD], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags], 
[hDED].[Post] as [Post]
FROM [oms_sr_MessType] as [hDED]
go

