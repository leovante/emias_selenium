CREATE VIEW [V_oms_StatusLPURecipe] AS SELECT 
[hDED].[StatusLPURecipeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Status_Name] as [Status_Name]
FROM [oms_StatusLPURecipe] as [hDED]
go

