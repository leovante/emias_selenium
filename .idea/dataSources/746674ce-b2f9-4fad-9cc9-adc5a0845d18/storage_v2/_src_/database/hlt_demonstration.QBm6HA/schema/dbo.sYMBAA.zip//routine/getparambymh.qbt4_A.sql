
Create FUNCTION [dbo].[GetParamByMH](@mhid int)

RETURNS varchar(max)

AS
begin

declare @SPCASE1 varchar(10) --1 - да, 0 - нет
declare @SPCASE256 varchar(10) --1 - да, 0 - нет
declare @SPCASE3 varchar(10) --1 - да, 0 - нет
declare @SPCASE4 varchar(10) --1 - да, 0 - нет
declare @SPCASE7 varchar(10) --1 - да, 0 - нет
declare @SPCASE varchar(max) --определяем, какое SPCASE заполнено

declare @VIDSF varchar(200)--ServiceMedicalCode, VID_SF
declare @VR varchar(10)--VisitResult

set @SPCASE = 0
set @SPCASE1 = 0
set @SPCASE256 = 0
set @SPCASE3 = 0
set @SPCASE4 = 0
set @SPCASE7 = 0

--SP_CASE 1 
set @SPCASE1=(select case isnull((select flag from stt_PatientAgent
	where rf_MedicalHistoryID=@mhid),'') when '' then 0 else (select flag&0x01 from stt_PatientAgent
	where rf_MedicalHistoryID=@mhid) end as isDiet)

--SP_CASE 2,5,6
set @SPCASE256=(select case  when VidK_Code='KSLP_SL7' then 'SPCASE="2"' 
						when VidK_Code='KSLP_SL11' and @SPCASE1=1 then 'SPCASE="6"' 
						when VidK_Code='KSLP_SL12' then 'SPCASE="5"' 
						else '' end 
 from oms_KRRValue
inner join stt_MedServicePatient on MedServicePatientID=rf_DocObjID and rf_MedicalHistoryID=@mhid
inner join oms_KrrVID on rf_KRRVidID=KRRVidID and VidK_Code in ('KSLP_SL7','KSLP_SL11','KSLP_SL12')
)
set @SPCASE256=(select case isnull(@SPCASE256,'') when '' then '' else @SPCASE256 end)

--SP_CASE 7
set @SPCASE7=(select case when count(mp.MigrationPatientID)>0 then 1 else 0 end  from stt_MigrationPatient mp
left join stt_MigrationProfile mpr on  mp.MigrationPatientID=mpr.rf_MigrationPatientID
left join stt_BedProfile bp on bp.BedProfileID=mpr.rf_BedProfileID
left join stt_StationarBranch sb on mp.rf_StationarBranchID=sb.StationarBranchID
left join oms_Department d on d.DepartmentID=sb.rf_DepartmentID
left join oms_kl_DepartmentProfile depProf on d.rf_kl_DepartmentProfileID=depProf.kl_DepartmentProfileID
left join oms_kl_DepartmentType dt on d.rf_kl_DepartmentTypeID=dt.kl_DepartmentTypeID
left join stt_BedProfile bpmp WITH(NOLOCK) on mp.rf_BedProfileID=bpmp.BedProfileID
inner join stt_MigrationPatient mp_next on mp.rf_MedicalHistoryID=mp_next.rf_MedicalHistoryID
		and mp_next.MigrationPatientID=dbo.stt_NextMigration(mp.rf_MedicalHistoryID,mp.MigrationPatientID)
left join stt_MigrationProfile mpr1 on  mp_next.MigrationPatientID=mpr1.rf_MigrationPatientID
left join stt_BedProfile bp1 on bp1.BedProfileID=mpr1.rf_BedProfileID
left join stt_StationarBranch sb1 on mp_next.rf_StationarBranchID=sb1.StationarBranchID
left join oms_Department d1 on d1.DepartmentID=sb1.rf_DepartmentID
left join oms_kl_DepartmentProfile depProf1 on d1.rf_kl_DepartmentProfileID=depProf1.kl_DepartmentProfileID
left join oms_kl_DepartmentType dt1 on d1.rf_kl_DepartmentTypeID=dt1.kl_DepartmentTypeID
left join stt_BedProfile bpmp1 WITH(NOLOCK) on mp_next.rf_BedProfileID=bpmp1.BedProfileID
where mp.rf_MedicalHistoryID=@mhid 
--and mp.migrationPatientID!=(select migrationPatientID from v_CurentMigrationPatient where rf_medicalHistoryID=mp.rf_MedicalHistoryID and rf_StationarBranchID=0) --исключаем последнее движение
and mp.migrationPatientID!=(select top 1 migrationPatientID from stt_migrationPatient where rf_medicalHistoryID=mp.rf_MedicalHistoryID order by DateIngoing) -- исключаем первое движение
and depProf.Name like '%%Акушерств%%' and depProf.Name like '%%гинеколог%%'
and dt.Code=2 and mp.BedDays<=5
and isnull(bp.Name,bpmp.Name) like '%%патологии беременности%%'
and dt1.Code=1
and mp_next.migrationPatientID!=case isnull((select migrationPatientID from v_CurentMigrationPatient where rf_medicalHistoryID=91600 and rf_StationarBranchID=0),'')
				when '' then 0 else (select migrationPatientID from v_CurentMigrationPatient where rf_medicalHistoryID=91600 and rf_StationarBranchID=0) end  --исключаем последнее движение
and mp_next.migrationPatientID!=(select top 1 migrationPatientID from stt_migrationPatient where rf_medicalHistoryID=mp.rf_MedicalHistoryID order by DateIngoing) -- исключаем первое движение
and isnull(bp1.Name,bpmp1.Name) like '%%рожениц%%')

--VID_SF ServiceMedicalCode1=VID_SF1;ServiceMedicalCode2=VID_SF2 // 1099511=09;300DRG0116198=09
set @VIDSF=isnull((select 
	(select '<b '+str from (select 'SMCODE="'+isnull(ServiceMedicalCode,'')+
		'" VIDSF="'+isnull(VID_SF,'')+'"></b>' as str from dbo.GetVIDSF(@mhid))t
FOR XML PATH(''))),'<b SMCode= "" VID_SF=""></b>')
set @VIDSF=(select REPLACE(REPLACE(@VIDSF,'&lt;','<'),'&gt;','>'))

--VisitResult
set @VR=(select isnull(vr.Code,0) from stt_MedicalHistory mh
inner join oms_kl_VisitResult vr on vr.kl_VisitResultID=mh.rf_kl_VisitResultID
where MedicalHistoryID=@mhid)

--определяем, какое SPCASE заполнено
set @SPCASE=(select case when @SPCASE256='' then 
				case when @SPCASE1=1 then 'SPCASE="1"' 
					 when @SPCASE7=1 then 'SPCASE="7"'
				else 'SPCASE="0"' end
			else @SPCASE256 end)




set @SPCASE = isnull((select '<a '+@SPCASE+' VR="'+@VR+'">'+@VIDSF+'</a>'),'<a SPCASE="0" VR="0"><b SMCode= "" VID_SF=""></b></a>')

return @SPCASE

 end
go

