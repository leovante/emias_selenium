CREATE VIEW [V_stt_Event] AS SELECT 
[hDED].[EventID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_stt_EventType].[Name] as [V_Name], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_CancelDoctorID] as [rf_CancelDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_CancelDocPRVDID] as [rf_CancelDocPRVDID], 
[jT_hlt_DocPRVD1].[Name] as [SILENT_rf_CancelDocPRVDID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_EventTypeID] as [rf_EventTypeID], 
[jT_stt_EventType].[Name] as [SILENT_rf_EventTypeID], 
[hDED].[rf_MedStageID] as [rf_MedStageID], 
[hDED].[Date] as [Date], 
[hDED].[UGUID] as [UGUID], 
[hDED].[CancelDate] as [CancelDate], 
[hDED].[Flags] as [Flags], 
[hDED].[rf_EventRecordID] as [rf_EventRecordID], 
[hDED].[Description] as [Description], 
[hDED].[Complete] as [Complete], 
[hDED].[CreateDate] as [CreateDate]
FROM [stt_Event] as [hDED]
INNER JOIN [stt_EventType] as [jT_stt_EventType] on [jT_stt_EventType].[EventTypeID] = [hDED].[rf_EventTypeID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD1] on [jT_hlt_DocPRVD1].[DocPRVDID] = [hDED].[rf_CancelDocPRVDID]
go

