CREATE VIEW [V_stt_Comunication] AS SELECT 
[hDED].[ComunicationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_AddressID] as [rf_AddressID], 
[jT_kla_Address].[CODE] as [SILENT_rf_AddressID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_PatientAgentID] as [rf_PatientAgentID], 
[jT_stt_PatientAgent].[Surname] as [SILENT_rf_PatientAgentID], 
[hDED].[rf_ComunicationTypeID] as [rf_ComunicationTypeID], 
[jT_stt_ComunicationType].[Name] as [SILENT_rf_ComunicationTypeID], 
[hDED].[ComInfo] as [ComInfo], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flags] as [flags], 
[hDED].[Mask] as [Mask]
FROM [stt_Comunication] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [kla_Address] as [jT_kla_Address] on [jT_kla_Address].[AddressID] = [hDED].[rf_AddressID]
INNER JOIN [stt_PatientAgent] as [jT_stt_PatientAgent] on [jT_stt_PatientAgent].[PatientAgentID] = [hDED].[rf_PatientAgentID]
INNER JOIN [stt_ComunicationType] as [jT_stt_ComunicationType] on [jT_stt_ComunicationType].[ComunicationTypeID] = [hDED].[rf_ComunicationTypeID]
go

