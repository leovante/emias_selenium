
-- =============================================
-- Author:		Shumer
-- Create date: 13.02.2013
-- Description:	Фильтрация услуг амбулатории
-- =============================================
CREATE FUNCTION [dbo].[hlt_smtap_getServiceFilter] 
(
	-- Add the parameters for the function here
	@P int,					-- Признаки фильтрации услуги
	@PT int,				-- Признаки фильтрации тарифа
	@date_p datetime,		-- Дата оказания услуги 
	@tapid int,				-- ТАП
	@mkbid int,				-- Диагноз
	@departmentid int,		-- Отделение
	@lpudoctorid int,		-- Врач
	@docprvdid int,			-- Должность врача
	@mkabid int,			-- МКАБ
	@userid int				-- user
)
RETURNS varchar(4000)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result varchar(4000)
	SET @Result = '(1=1)'
	
	DECLARE @P1 INT
	DECLARE @P2 INT
	DECLARE @P3 INT
	DECLARE @P4 INT
	DECLARE @P5 INT
	DECLARE @P6 INT
	DECLARE @P7 INT
	DECLARE @P8 INT
	DECLARE @P9 INT
	DECLARE @P10 INT
	DECLARE @P11 INT
	DECLARE @P12 INT
	DECLARE @P13 INT

	SET @P1  = 0x0001
	SET @P2  = 0x0002
	SET @P3  = 0x0004
	SET @P4  = 0x0008
	SET @P5  = 0x0010
	SET @P6  = 0x0020
	SET @P7  = 0x0040
	SET @P8  = 0x0080
	SET @P9  = 0x0100
	SET @P10 = 0x0200
	SET @P11 = 0x0400
	SET @P12 = 0x0800
	SET @P13 = 0x1000

/*

1 Базовый фильтр "Действует на дату оказания"

Дополнительные фильтры
I Фильтры по отделению
2 I.1. Тип отделения
Если Department != 0 и Department.rf_kl_DepartmentTypeID !=0 то фильтруем по этому полю

3 I.2. Профиль отделения
Если Department != 0 и Department.rf_kl_DepartmentProfileID !=0 то фильтруем по этому полю

4 I.3. Лицензируемые виды деятельности
Если Department != 0 то
Для всех действующих на дату оказания услуги лицензий отделения (LicenceReestrSMSet {rf_DepartmentID, V_DateB and V_DateE} выбрать профили 
отделения (rf_kl_DepartmentProfileID ) и фильтровать по этому полю

5 I.4. Включать услуги с незаполненным типом отделения (rf_kl_DepartmentTypeID) - (если используется фильтр I.1)
6 I.5. Включать услуги с незаполненным профилем отделения (rf_kl_DepartmentProfileID)- (если используется фильтр I.2 или I.3)


II Фильтры по врачу (в зависимости от того, передали ли LPUDoctor или DocPRVD - выдираются записи должности и специальности

7 II.1. Если врач != 0 и rf_PRVDID != 0 то фильтруем по этому полю
8 II.2. Если врач != 0 и rf_PRVSID != 0 то фильтруем по этому полю

9 II.3. Включать услуги с незаполненным полем должность (если используется фильтр II.1)

10 II.4. Включать услуги с незаполненным полем специальность (если используется фильтр II.2)

11 III Фильтры по тарифам    

12  Фильтр по Диагнозу     
*/
	

	-- 1 Базовый фильтр "Действует на дату оказания"
	IF @P & @P1 != 0
	BEGIN
		SET	@Result = @Result + ' AND (''' + convert(varchar,   @date_p, 126) + ''' between DATE_B and DATE_E)'
		-- select * from oms_servicemedical where    convert(varchar, getdate(), 126)  between DATE_B and DATE_E
	END

	IF @departmentid != 0 
	BEGIN
		--	2 I.1. Тип отделения
		IF @P & @P2 != 0
		BEGIN
			DECLARE @depType int
			SET @depType = isnull (
				(
					SELECT TOP 1 rf_kl_DepartmentTypeID
					FROM oms_Department 					
					WHERE DepartmentID = @departmentid 
				),0)


			--5 I.4. Включать услуги с незаполненным типом отделения (rf_kl_DepartmentTypeID) - (если используется фильтр I.1)
			IF @P & @P5 != 0
			BEGIN
				SET	@Result = @Result + ' AND ((rf_kl_DepartmentTypeID = ' + cast(@depType as varchar)  + ') OR (rf_kl_DepartmentTypeID = 0))'
				-- select * from oms_servicemedical where ((rf_kl_DepartmentTypeID = 0) OR (rf_kl_DepartmentTypeID = 0))
			END
			ELSE
			BEGIN
				SET	@Result = @Result + ' AND (rf_kl_DepartmentTypeID = ' + cast(@depType as varchar)  + ')'
				-- select * from oms_servicemedical where (rf_kl_DepartmentTypeID = 1)
			END
		END

		IF (@p & @P3 != 0) OR (@p & @P4 != 0)
		BEGIN
			DECLARE @res VARCHAR(2000) 
			SET @res = '-1'

			--6 I.5. Включать услуги с незаполненным профилем отделения (rf_kl_DepartmentProfileID)- (если используется фильтр I.2 или I.3)
			IF @P & @P6 != 0
			BEGIN
				SET	@res = '0'				
			END
					
			-- 3 I.2. Профиль отделения
			IF @P & @P3 != 0
			BEGIN
				DECLARE @depProfile int
				SET @depProfile = isnull (
					(
						SELECT TOP 1 rf_kl_DepartmentProfileID
						FROM oms_Department 					
						WHERE DepartmentID = @departmentid 
					),0)
				SET	@res = @res + ', ' + cast(@depProfile as varchar)
			END

			-- 4 I.3. Лицензируемые виды деятельности
			IF @P & @P4 != 0
			BEGIN
				SELECT @res =  isnull(@res + ', ', '') + cast(rf_kl_DepartmentProfileID as varchar)
				FROM oms_LicenceReestr l
					INNER JOIN oms_LicenceReestrSM lsm
						ON l.LicenceReestrID = lsm.rf_LicenceReestrID					
				WHERE rf_DepartmentID = @departmentid 
				AND @date_p BETWEEN l.DateB and l.DateE

			END

			SET	@Result = @Result + ' AND (rf_kl_DepartmentProfileID in (' + @res  + '))'
			-- select * from oms_servicemedical where (rf_kl_DepartmentProfileID in (-1,0))
		END
	END

	IF (@lpudoctorid != 0) OR (@docprvdid != 0)
	BEGIN
		DECLARE @prvd int
		DECLARE @prvs int

		IF @docprvdid	!= 0
		BEGIN
			SET @prvd = ISNULL((SELECT TOP 1 rf_PRVDID from hlt_DocPRVD where DocPRVDID = @docprvdid), 0)
			SET @prvs = ISNULL((SELECT TOP 1 rf_PRVSID from hlt_DocPRVD where DocPRVDID = @docprvdid), 0)
		END
		ELSE
			SET @prvd = ISNULL((SELECT TOP 1 rf_PRVDID from hlt_LPUDoctor where LPUDoctorID = @lpudoctorid), 0)
			SET @prvs = ISNULL((SELECT TOP 1 rf_PRVSID from hlt_LPUDoctor where LPUDoctorID = @lpudoctorid), 0)
		BEGIN

		--	7 II.1. Если врач != 0 и rf_PRVDID != 0 то фильтруем по этому полю
		IF (@P & @P7 != 0) AND (@prvd != 0)
		BEGIN
			--	9 II.3. Включать услуги с незаполненным полем должность (если используется фильтр II.1)
			IF @P & @P9 != 0
			BEGIN
				SET	@Result = @Result + ' AND ((rf_PRVDID = ' + cast(@prvd as varchar)  + ') OR (rf_PRVDID = 0))'
				-- select * from oms_servicemedical where ((rf_PRVDID = 0) OR (rf_PRVDID = 0))
			END
			ELSE
			BEGIN
				SET	@Result = @Result + ' AND (rf_PRVDID = ' + cast(@prvd as varchar)  + ')'
				-- select * from oms_servicemedical where (rf_PRVDID = 0)
			END
		END		


		--	8 II.2. Если врач != 0 и rf_PRVSID != 0 то фильтруем по этому полю
		IF (@P & @P8 != 0) AND (@prvs != 0)
		BEGIN
			--	10 II.4. Включать услуги с незаполненным полем специальность (если используется фильтр II.2)
			IF @P & @P10 != 0
			BEGIN
				SET	@Result = @Result + ' AND ((rf_PRVSID = ' + cast(@prvs as varchar)  + ') OR (rf_PRVSID = 0))'
				-- select * from oms_servicemedical where ((rf_PRVSID = 0) OR (rf_PRVSID = 0))
			END
			ELSE
			BEGIN
				SET	@Result = @Result + ' AND (rf_PRVSID = ' + cast(@prvs as varchar)  + ')'
				-- select * from oms_servicemedical where (rf_PRVSID = 0)
			END
		END	 

		END
	END

	-- 11 III Фильтры по тарифам 
	IF (@P & @P11 != 0)
	BEGIN
		SET	@Result = @Result + ' AND (serviceMedicalID in (select rf_serviceMedicalID from oms_Tariff where '
		DECLARE @tariffFilrer varchar(4000)
		SET @tariffFilrer = (SELECT [dbo].[hlt_smtap_getTariffFilter] (
			@PT,				-- Признаки фильтрации тарифа	
			@date_p,			-- Дата оказания услуги 
			0,					-- Услуга
			@tapid,				-- ТАП
			@mkbid,				-- Диагноз
			@departmentid,		-- Отделение
			@lpudoctorid,		-- Врач
			@docprvdid,			-- Должность врача
			@mkabid,			-- МКАБ
			@userid 
			))

		SET	@Result = @Result + @tariffFilrer + ' ))'		
	END 
	-- услуги по полу пациента (Диспансеризация)
    IF @P & @P13 != 0
	BEGIN
		SET @Result = @Result + ' AND (rf_kl_SexID in (0, (select kl_sexid from oms_kl_Sex where CODE = ''3''), (select kl_sexid from oms_kl_Sex where CODE =  (2 - isnull((select top 1 W from hlt_MKAB where MKABID = ' + cast(@mkabid as varchar(20)) + ' and MKABID != 0),0)))))' 
	END
		

	-- Return the result of the function
	RETURN @Result

END
go

