CREATE VIEW [V_oms_onco_N019] AS SELECT 
[hDED].[onco_N019ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ID_CONS] as [ID_CONS], 
[hDED].[Cons_Name] as [Cons_Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[GUIDN019] as [GUIDN019]
FROM [oms_onco_N019] as [hDED]
go

