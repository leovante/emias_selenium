CREATE VIEW [V_oms_DPCPharmacyRecipeReestr] AS SELECT 
[hDED].[DPCPharmacyRecipeReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Num] as [Num], 
[hDED].[Date_Create] as [Date_Create], 
[hDED].[OGRN] as [OGRN], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags]
FROM [oms_DPCPharmacyRecipeReestr] as [hDED]
go

