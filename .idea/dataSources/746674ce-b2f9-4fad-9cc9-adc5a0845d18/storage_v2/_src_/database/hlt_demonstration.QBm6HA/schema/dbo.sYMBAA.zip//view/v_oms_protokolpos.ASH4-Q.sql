CREATE VIEW [V_oms_ProtokolPos] AS SELECT 
[hDED].[ProtokolPosID], [hDED].[x_Edition], [hDED].[x_Status], 
( Cast ((hDED.Price*hDED.Count_All) as decimal(18,2))) as [V_Summa], 
[jT_oms_Protokol].[Num] as [V_Num], 
[jT_oms_LS].[NOMK_LS] as [V_NOMK_LS], 
[hDED].[rf_LSID] as [rf_LSID], 
[jT_oms_LS].[NAME_MED] as [SILENT_rf_LSID], 
[hDED].[rf_ProtokolID] as [rf_ProtokolID], 
[jT_oms_Protokol].[Num] as [SILENT_rf_ProtokolID], 
[hDED].[rf_ClassUnitID] as [rf_ClassUnitID], 
[jT_oms_ClassUnit].[Name] as [SILENT_rf_ClassUnitID], 
[hDED].[Price] as [Price], 
[hDED].[Count_All] as [Count_All], 
[hDED].[LotPositionGuid] as [LotPositionGuid], 
[hDED].[ProtokolPosGuid] as [ProtokolPosGuid], 
[hDED].[Rem] as [Rem], 
[hDED].[PriceAfter] as [PriceAfter], 
[hDED].[Count_EI] as [Count_EI], 
[hDED].[Price_EI] as [Price_EI], 
[hDED].[Koeff] as [Koeff]
FROM [oms_ProtokolPos] as [hDED]
INNER JOIN [oms_Protokol] as [jT_oms_Protokol] on [jT_oms_Protokol].[ProtokolID] = [hDED].[rf_ProtokolID]
INNER JOIN [oms_LS] as [jT_oms_LS] on [jT_oms_LS].[LSID] = [hDED].[rf_LSID]
INNER JOIN [oms_ClassUnit] as [jT_oms_ClassUnit] on [jT_oms_ClassUnit].[ClassUnitID] = [hDED].[rf_ClassUnitID]
go

