
create procedure [dbo].[createGetKRR] 
 AS
 Begin
   declare @sql nvarchar(max)
 set @sql='
 if exists (select * from sys.all_objects where name =''GetKRR'')
 drop function GetKRR
 '
 execute sp_executesql @sql
 set @sql='
create FUNCTION [dbo].[GetKRR](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int,
@prerv varchar(500)=''''
)
RETURNS @result TABLE (
vidID int,
info varchar(max),
[Value] [decimal](38, 6) NULL
)
AS
begin
declare @dKSLP decimal(38,6)
declare @d     decimal(38,6)
declare @nKSLP int
set @dKSLP=0
set @nKSLP=0
set @d=0
Declare @xml xml
set @xml = convert(xml,@prerv)
declare @SPCASE varchar(10)
declare @VR     varchar(10)
declare @SF varchar(20)
select  @SPCASE= SPCASE,@VR= VR, @SF=VIDSF
 from (
select 
   t.x.value(''@SPCASE[1]'', ''varchar(50)'') as SPCASE,
   t.x.value(''@VR[1]'',     ''varchar(50)'') as VR, 
  t2.x.value(''@SMCODE[1]'', ''varchar(50)'') as SMCODE,
  t2.x.value(''@SF[1]'',  ''varchar(50)'') as VIDSF
from @xml.nodes(''/a'') t(x) 
outer apply  x.nodes(''//b'') as t2 (x)
) t where Smcode in (@usl1, @usl2,'''') or Smcode is null
INSERT INTO @result
'

select @sql
 set  @sql=@sql+Replace(Replace(Replace(( select  'select krrvidId ,'''','+
 Replace([Source],'@vid', ''''+convert(varchar(10),vidK_Code)+'''') + 
 case when Row_Number() over (order by ExpertAlgorithmID desc)=1 then ' 
 '  else ' union 
 ' end as 'data()' from oms_krrvid
 inner join oms_ExpertAlgorithm on ExpertAlgorithmID= rf_ExpertAlgorithmID
 where ExpertAlgorithmID>0 and KSLP=0 and oms_krrvid.date_E>getdate() and oms_krrvid.date_B<=getdate()
 order by ExpertAlgorithmID 
 for xml  path('') ),'&gt;','>'),'&lt;','<'),'&#x0D;','
 ')

select @sql
select  @sql=@sql+'  set @d=  (select '+Replace([Source],'@vid', ''''+convert(varchar(10),vidK_Code)+'''') +') 
 '+case when KSLP<>2 then '
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   ' else ' set @dKSLP = @dKSlP+isnull(@d,0) ' end +'if (@d>0) INSERT INTO @result select '+convert(varchar(10),KrrvidID)+','''',@d
 '
 from oms_krrvid
 inner join oms_ExpertAlgorithm on ExpertAlgorithmID= rf_ExpertAlgorithmID
 where KSLP in (1,2) and oms_krrvid.date_E>getdate() and oms_krrvid.date_B<=getdate()
 order by KSLP
 print @sql

select  @sql= @sql+'  
 if  (@nKSLP>0)  INSERT INTO @result select '''+convert(varchar(10),KrrvidID)+''','''',@dKSLP-@nKSLP+1 
 '
 from oms_krrvid
 inner join oms_ExpertAlgorithm on ExpertAlgorithmID= rf_ExpertAlgorithmID
 where  KSLP =3 and oms_krrvid.date_E>getdate() and oms_krrvid.date_B<=getdate()
 order by KSLP
 select @sql=@sql+'
  if(select count(*) from @result
    inner join oms_KRRVid on KrrVidID= VidId
    where VidK_Code in (''KSLP_SL11'',''KSLP_SL1'',''KSLP_SL2''))>1 begin 

   update @result set Value = Value-(select top 1 Value from @result where VidId in  (select KrrvidId from oms_Krrvid where VidK_Code in (''KSLP_SL1'',''KSLP_SL2'')))+1
    where VidId in  (select KrrvidId from oms_Krrvid where VidK_Code in (''КСЛП_01''))
	
   delete from @result  where VidId in  (select KrrvidId from oms_Krrvid where VidK_Code in (''KSLP_SL1'',''KSLP_SL2''))
 end 
  return end
 '

 
select @sql
execute sp_executesql @sql



set @sql='
 if exists (select * from sys.all_objects where name =''GetKRRКпс'')
 drop function GetKRRКпс

 '
 select @sql
 execute sp_executesql @sql
 set @sql='
create FUNCTION [dbo].[GetKRRКпс](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int,
@prerv varchar(500)=''''
)
RETURNS @result TABLE (
vidID int,
info varchar(max),
[Value] [decimal](38, 6) NULL

)
AS
begin
Declare @xml xml
set @xml = convert(xml,@prerv)
declare @SPCASE varchar(10)
declare @VR     varchar(10)
declare @SF varchar(20)
select  @SPCASE= SPCASE,@VR= VR, @SF=VIDSF
 from (
select 
   t.x.value(''@SPCASE[1]'', ''varchar(50)'') as SPCASE,
   t.x.value(''@VR[1]'',     ''varchar(50)'') as VR, 
  t2.x.value(''@SMCODE[1]'', ''varchar(50)'') as SMCODE,
  t2.x.value(''@SF[1]'',  ''varchar(50)'') as VIDSF
from @xml.nodes(''/a'') t(x) 
outer apply  x.nodes(''//b'') as t2 (x)
) t where Smcode in (@usl1, @usl2,'''') or Smcode is null
INSERT INTO @result
'
select @sql
 set  @sql=@sql+Replace(Replace(Replace(( select  'select '''+convert(varchar(10),KRRVidId)+''','''','+
 Replace([Source],'@vid', ''''+convert(varchar(10),vidK_Code)+'''') + 
 case when Row_Number() over (order by ExpertAlgorithmID desc)=1 then ' 
 '  else ' union 
 ' end as 'data()' from oms_krrvid
 inner join oms_ExpertAlgorithm on ExpertAlgorithmID= rf_ExpertAlgorithmID
 where ExpertAlgorithmID>0 and AlgType=0 and oms_krrvid.date_E>=getdate() and oms_krrvid.date_B<getdate() and oms_krrvid.VidK_Code='KPS_1'
 order by ExpertAlgorithmID 
 for xml  path('') ),'&gt;','>'),'&lt;','<'),'&#x0D;','
 ')

    select @sql=@sql+'
	delete from @result where value=0
  return end'
  select @sql
   execute sp_executesql @sql
 END
go

