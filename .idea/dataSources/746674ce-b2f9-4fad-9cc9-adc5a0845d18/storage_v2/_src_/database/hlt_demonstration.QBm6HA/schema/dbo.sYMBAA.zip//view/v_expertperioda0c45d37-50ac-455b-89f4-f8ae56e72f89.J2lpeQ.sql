
CREATE view [V_ExpertPerioda0c45d37-50ac-455b-89f4-f8ae56e72f89] as select * from [tmp_ExpertPerioda0c45d37-50ac-455b-89f4-f8ae56e72f89]
go

