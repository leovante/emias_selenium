CREATE VIEW [V_hlt_MedHistoryUnloadJournal] AS SELECT 
[hDED].[MedHistoryUnloadJournalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[Count] as [Count], 
[hDED].[CountDel] as [CountDel], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[DateStart] as [DateStart], 
[hDED].[DocTypeDefGuid] as [DocTypeDefGuid], 
[hDED].[GUID] as [GUID], 
[hDED].[HasError] as [HasError], 
[hDED].[lastLifeObjId] as [lastLifeObjId], 
[hDED].[ms] as [ms]
FROM [hlt_MedHistoryUnloadJournal] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

