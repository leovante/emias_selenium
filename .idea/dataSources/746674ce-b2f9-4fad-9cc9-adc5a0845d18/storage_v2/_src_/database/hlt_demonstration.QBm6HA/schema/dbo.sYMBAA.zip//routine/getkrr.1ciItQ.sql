
create FUNCTION [dbo].[GetKRR](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int,
@prerv varchar(500)=''
)
RETURNS @result TABLE (
vidID int,
info varchar(max),
[Value] [decimal](38, 6) NULL
)
AS
begin
declare @dKSLP decimal(38,6)
declare @d     decimal(38,6)
declare @nKSLP int
set @dKSLP=0
set @nKSLP=0
set @d=0
Declare @xml xml
set @xml = convert(xml,@prerv)
declare @SPCASE varchar(10)
declare @VR     varchar(10)
declare @SF varchar(20)
select  @SPCASE= SPCASE,@VR= VR, @SF=VIDSF
 from (
select 
   t.x.value('@SPCASE[1]', 'varchar(50)') as SPCASE,
   t.x.value('@VR[1]',     'varchar(50)') as VR, 
  t2.x.value('@SMCODE[1]', 'varchar(50)') as SMCODE,
  t2.x.value('@SF[1]',  'varchar(50)') as VIDSF
from @xml.nodes('/a') t(x) 
outer apply  x.nodes('//b') as t2 (x)
) t where Smcode in (@usl1, @usl2,'') or Smcode is null
INSERT INTO @result
select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='2' and @typeid=rf_kl_DepartmentTypeid union 
  select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='06' and @age<=3 and @age >=1 and @typeid=rf_kl_DepartmentTypeid union 
  select krrvidId ,'', valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR1' and @age<1  and ( Replace(@usl1,'300DRG0117','')  not in ('105','106','107','108','109','110','111') and Replace(@usl1,'300DRG0118','')  not in ('107','108','109','110','111','112','113')  ) and @typeid=rf_kl_DepartmentTypeid union 
  select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KPS_3' and @typeid=rf_kl_DepartmentTypeid and Replace(@usl1,'300DRG0116','')  not in ('002','003','004','005','011','012','016','083','084','097','140','148','149','153','154','155','179','200','252','281','295','299') and Replace(@usl1,'300DRG0117','')  not in ('002','003','004','005','011','012','016','084','300','097','146','154','155','159','160','161','185','206','258','287','302','306') and  Replace(@usl1,'300DRG0118','')  not in ('002','003','004','005','011','012','016','086','314','146','147','148','149','150','151','152','153','154','155','159','099','157','167','168','172','173','174','198','219','271','301','316','320')  and @dlit<=3 and @usl2 like 'A16.%' union 
  select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='09' and @typeid=rf_kl_DepartmentTypeid and Replace(@usl1,'300DRG0116','')  not in ('002','003','004','005','011','012','016','083','084','097','140','148','149','153','154','155','179','200','252','281','295','299') and Replace(@usl1,'300DRG0117','')  not in ('002','003','004','005','011','012','016','084','300','097','146','154','155','159','160','161','185','206','258','287','302','306') and  Replace(@usl1,'300DRG0118','')  not in ('002','003','004','005','011','012','016','086','314','146','147','148','149','150','151','152','153','154','155','159','099','157','167','168','172','173','174','198','219','271','301','316','320')  and @dlit<=3 and @usl2 like 'A16.%' union 
  select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KPS_2' and @typeid=rf_kl_DepartmentTypeid and Replace(@usl1,'300DRG0116','')  not in ('002','003','004','005','011','012','016','083','084','097','140','148','149','153','154','155','179','200','252','281','295','299') and Replace(@usl1,'300DRG0117','')  not in ('002','003','004','005','011','012','016','084','300','097','146','154','155','159','160','161','185','206','258','287','302','306') and Replace(@usl1,'300DRG0118','')  not in ('002','003','004','005','011','012','016','086','314','146','147','148','149','150','151','152','153','154','155','159','099','157','167','168','172','173','174','198','219','271','301','316','320') and @dlit<=3 and @usl2 not like 'A16.%' union 
  select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='05' and @typeid=rf_kl_DepartmentTypeid and Replace(@usl1,'300DRG0116','')  not in ('002','003','004','005','011','012','016','083','084','097','140','148','149','153','154','155','179','200','252','281','295','299') and Replace(@usl1,'300DRG0117','')  not in ('002','003','004','005','011','012','016','084','300','097','146','154','155','159','160','161','185','206','258','287','302','306') and Replace(@usl1,'300DRG0118','')  not in ('002','003','004','005','011','012','016','086','314','146','147','148','149','150','151','152','153','154','155','159','099','157','167','168','172','173','174','198','219','271','301','316','320') and @dlit<=3 and @usl2 not like 'A16.%' union 
  select krrvidId ,'', valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  inner join oms_lpu on lpuid =@LPUID 
 where  V_oms_krr.rf_LPUID in( @LPUID, rf_mainLPUID) and  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='3_01'
 and Replace(@usl1,'300DRG0116','') not in ('001','002','003','004','005','006','007','008','009','010','011','012','013','014','105','106','107','108','109','110') 
 and Replace(@usl1,'300DRG0117','') not in (      '002','003','004','005','006','007','008','009','010','011','012','013','014','105','106','107','108','109','110','111','017','029','084','095','159','195','197','199','200','204','230','243','253','259','271','272','273','274','275','300','302','306') 
 and @typeid=rf_kl_DepartmentTypeid
and Replace(@usl1,'300DRG0118','') not in ('017','030','086','097','172','208','210','212','213','217','243','256','266','272','284','285','286','287','288','314','316','320')
and Replace(@usl1,'300DRG0118','') not in ('001','002','003','004','005','006','007','008','009','010','011','012','013','014')


 union 
  select krrvidId ,'',
valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId inner join oms_lpu on lpuid =@LPUID inner join oms_kl_DepartmentProfile on  kl_DepartmentProfileId= @profileId where V_oms_krr.rf_LPUID in ( @LPUID, rf_mainLPUID)  and  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='5_01' and @typeid=rf_kl_DepartmentTypeid and  (( Replace(@usl1,'300DRG0116','')  in ('001','002','003','004','005','006','007','008','009','010','011','012','013','014','105','106','107','108','109','110') ) 
or ( Replace(@usl1,'300DRG0117','')  in (      '002','003','004','005','006','007','008','009','010','011','012','013','014','105','106','107','108','109','110','111')) 
or Replace(@usl1,'300DRG0118','')  in ('001','002','003','004','005','006','007','008','009','010','011','012','013','014'))
 union 
  select krrvidId ,'',/*valueKRR*/ 0 from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KDG08' and @age>4 and @age<18 and @typeid=rf_kl_DepartmentTypeid union 
  select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>@date and V_oms_krr.date_B<@date and VidK_Code='07'  and @age<18 and @usl1 <>  '300DRG0116153' and V_ServiceMedicalCode1=@usl1 and (V_ServiceMedicalCode2=@usl2 or V_ServiceMedicalCode2=''  or V_ServiceMedicalCode2='не определено')and @typeid=rf_kl_DepartmentTypeid and (rf_MkbId=@mkb or rf_MKBID=0) union 
  select krrvidId ,'',
 
case when @dlit > valueKrr or   @mkb in (select mkbid from oms_mkb 
 
where DS in (
 
'F10.0',
 
'F11.0',
 
'F12.0',
 
'F13.0',
 
'F14.0',
 
'F15.0',
 
'F16.0',
 
'F18.0',
 
'F19.0',
 
'F10.1',
 
'F11.1',
 
'F12.1',
 
'F13.1',
 
'F14.1',
 
'F15.1',
 
'F16.1',
 
'F18.1',
 
'F19.1',
 
'F10.3',
 
'F11.3',
 
'F12.3',
 
'F13.3',
 
'F14.3',
 
'F15.3',
 
'F16.3',
 
'F18.3',
 
'F19.3'))
 
then 1 else
 
round(@dlit/valuekrr,6)  end from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId   where   V_ServiceMedicalCode1=@usl1 and V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='Кпс' union 
  select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KDG07' and @age>=75 and @usl1 <>  '300DRG0116153' and @typeid=rf_kl_DepartmentTypeid union 
  select krrvidId ,'',
 
valueKRR from V_oms_krr 
 
inner join oms_krrvid on krrvidId= rf_KrrvidId 
 
where V_oms_krr.date_E>=@date 
 
and V_oms_krr.date_B<@date 
 
and VidK_Code='08_1' 
 
and @typeid=rf_kl_DepartmentTypeid 
 
and (V_ServiceMedicalCode1=@usl1 and  V_ServiceMedicalCode1 in ('300DRG0118206','300DRG0118204','300DRG0118102') ) 
 
and (V_ServiceMedicalCode2=@usl2 ) 
 
and  @mkb= rf_MKBID   
 
and  @mkb  in (select mkbid from oms_mkb where DS  in ('I60', 'I61', 'I67.1', 'I67.8', 'I78.0','Q28.2', 'Q28.3', 'Q28.8') or Ds like 'I60.%' or DS like 'I61.%')  
 
and rf_MkbId=@mkb union 
  select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId inner join tmp_KRRFor70age  t on t.usl=@usl1 and @date between t.Date_B and t.date_E  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='09_' and @age>=70 and @usl1 = V_ServiceMedicalCode1  and @typeid=rf_kl_DepartmentTypeid union 
  select krrvidId ,'',
(select 1 where @usl1 in (
'300DRG0118148',
'300DRG0118157',
'300DRG0118149',
'300DRG0118146',
'300DRG0118012',
'300DRG0118271',	
'300DRG0118099',	
'300DRG0118016',		
'300DRG0118154',		
'300DRG0118155',		
'300DRG0118152',		
'300DRG0118005',		
'300DRG0118003',		
'300DRG0118002',		
'300DRG0118159',		
'300DRG0118004',		
'300DRG0118150',		
'300DRG0118011',		
'300DRG0118153',		
'300DRG0118147',		
'300DRG0118151',		
'300DRG0118301',		
'300DRG0118173',		
'300DSG0118061',		
'300DSG0118058',		
'300DSG0118056',		
'300DRG0118167',		
'300DRG0118168',		
'300DRG0118172',		
'300DRG0118316',		
'300DRG0118174',		
'300DRG0118314',		
'300DSG0118060',		
'300DSG0118054',		
'300DRG0118198',		
'300DRG0118086',		
'300DRG0118219',		
'300DRG0118320'		
) or 
@usl1 like '%300DSG0118055' or 
@usl1 like '%300DSG0118054' or		
@usl1 like '%300DSG0118059' or		
@usl1 like '%300DSG0118057' or	
@usl1 like '%300DSG0118061' or		
@usl1 like '%300DSG0118060' or		
@usl1 like '%300DSG01180055' or		
@usl1 like '%300DSG0118059'  or 		
@usl1 like '%300DSG01180055' or		
@usl1  like '%300DSG0118056' or		
@usl1  like '%300DSG0118055' or
@usl1  like '%300DSG0118058' or	
@usl1  like '%300DSG0118057')  from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where  VidK_Code='KPS_4' union 
  select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KPS_5' and @typeid=rf_kl_DepartmentTypeid and @SPCASE ='7' union 
  select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KPS_6' and @typeid=rf_kl_DepartmentTypeid and @SPCASE  in ('3','4') union 
  select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KPS_8' and @typeid=rf_kl_DepartmentTypeid  and @dlit>3 and @usl2  like 'A16.%' and @VR in ('06','27','28','80')  union 
  select krrvidId ,'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KPS_7' and @typeid=rf_kl_DepartmentTypeid  and @dlit>3 and @usl2 not like 'A16.%' and @VR in ('06','27','28','80')  union 
  select krrvidId ,'',
case when    @mkb in (select mkbid from oms_mkb where DS in (
'F10.0','F11.0','F12.0','F13.0','F14.0','F15.0','F16.0','F18.0','F19.0','F10.1','F11.1','F12.1','F13.1',
'F14.1','F15.1','F16.1','F18.1','F19.1','F10.3','F11.3','F12.3','F13.3','F14.3','F15.3','F16.3','F18.3','F19.3')
) and @SF in ('16','17')  then 1 else 
case when @dlit > valueKrr then
round(@dlit/valuekrr,6) else 0  end  end from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId   where   V_ServiceMedicalCode1=@usl1 and V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KPS_1' 
   set @d=  (select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>@date and V_oms_krr.date_B<@date and VidK_Code='KSLP_SL12'  and @age>=18 and @usl1 =  '300DRG0118172' and V_ServiceMedicalCode1=@usl1 and (V_ServiceMedicalCode2=@usl2 or  V_ServiceMedicalCode2='не определено'  or V_ServiceMedicalCode2='') and @typeid=rf_kl_DepartmentTypeid and (rf_MkbId=@mkb or rf_MKBID=0)) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 25,'',@d
   set @d=  (select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  
where  V_oms_krr.date_E>=@date 
and V_oms_krr.date_B<@date 
and VidK_Code='KSLP_SL15' 
and @usl1 like '%300DSG0118005[12345]'
and (V_ServiceMedicalCode1=@usl1 ) 

and @typeid=rf_kl_DepartmentTypeid) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 26,'',@d
   set @d=  (select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  
where  V_oms_krr.date_E>=@date 
and V_oms_krr.date_B<@date 
and VidK_Code='KSLP_SL14' 
and @usl1 like '%300DSG011802[36]'
and (V_ServiceMedicalCode1=@usl1 ) 

and @typeid=rf_kl_DepartmentTypeid) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 29,'',@d
   set @d=  (select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KSLP_SL3' and @age<4 and  @SPCase in ('1','4','6') and @typeid=rf_kl_DepartmentTypeid) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 31,'',@d
   set @d=  (select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  
where  V_oms_krr.date_E>=@date 
and V_oms_krr.date_B<@date 
and VidK_Code='KSLP_SL6' 
and @usl1= '300DRG0118233'  
and V_ServiceMedicalCode1=@usl1  

and @typeid=rf_kl_DepartmentTypeid) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 32,'',@d
   set @d=  (select valueKRR 
from V_oms_krr
 inner join oms_krrvid on krrvidId= rf_KrrvidId 
where  V_oms_krr.date_E>=@date 
and V_oms_krr.date_B<@date 
and VidK_Code='KSLP_SL7' 
and (V_ServiceMedicalCode1=@usl1 and  V_ServiceMedicalCode1='300DRG0118327') 
and (V_ServiceMedicalCode2=@usl2 or V_ServiceMedicalCode2='A19.23.002.017') 
and  @mkb in (select mkbid from oms_mkb where DS  in ('I69.3','I69.8','T90.5','T90.8','T91.3','T91.1','I69.0','I69.1')) 
and  @mkb= rf_MKBID   

and  @typeid=rf_kl_DepartmentTypeid
) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 33,'',@d
   set @d=  (select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KSLP_SL10' and @age>=4 and @age<18 and  @SPCase in ('1','4','6') and @typeid=rf_kl_DepartmentTypeid) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 34,'',@d
   set @d=  (select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId inner join tmp_KRRFor70age  t on t.usl=@usl1 and @date between t.Date_B and t.date_E  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KSLP_SL5' and @age>=70 and @usl1 = V_ServiceMedicalCode1  and @typeid=rf_kl_DepartmentTypeid) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 36,'',@d
   set @d=  (select 
valueKRR from V_oms_krr 
inner join oms_krrvid on krrvidId= rf_KrrvidId 
where V_oms_krr.date_E>=@date 
and V_oms_krr.date_B<@date 
and VidK_Code='KSLP_SL8' 
and @typeid=rf_kl_DepartmentTypeid 
and (V_ServiceMedicalCode1=@usl1 and  V_ServiceMedicalCode1 in ('300DRG0118206','300DRG0118204','300DRG0118102') ) 
and (V_ServiceMedicalCode2=@usl2 ) 
and  @mkb= rf_MKBID   
and  @mkb  in (select mkbid from oms_mkb where DS  in ('I60', 'I61', 'I67.1', 'I67.8', 'I78.0','Q28.2', 'Q28.3', 'Q28.8') or Ds like 'I60.%' or DS like 'I61.%')  
and rf_MkbId=@mkb) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 37,'',@d
   set @d=  (select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KSLP_SL2' and @age<=3 and @age >=1 and @typeid=rf_kl_DepartmentTypeid) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 39,'',@d
   set @d=  (select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KSLP_SL4' and @age>=75 and @usl1 <>  '300DRG0116153' and @typeid=rf_kl_DepartmentTypeid) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 41,'',@d
   set @d=  (select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>@date and V_oms_krr.date_B<@date and VidK_Code='KSLP_SL11'  and @age<18 and @usl1 <>  '300DRG0116153' and V_ServiceMedicalCode1=@usl1 and (V_ServiceMedicalCode2=@usl2 or V_ServiceMedicalCode2=''  or V_ServiceMedicalCode2='не определено')and @typeid=rf_kl_DepartmentTypeid and (rf_MkbId=@mkb or rf_MKBID=0)) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 42,'',@d
   set @d=  (select /*valueKRR*/ 0 from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KSLP_SL9' and @age>4 and @age<18 and @typeid=rf_kl_DepartmentTypeid) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 43,'',@d
   set @d=  (select  valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KSLP_SL1' and @age<1  and ( Replace(@usl1,'300DRG0117','')  not in ('105','106','107','108','109','110','111') and Replace(@usl1,'300DRG0118','')  not in ('107','108','109','110','111','112','113')  ) and @typeid=rf_kl_DepartmentTypeid) 
 
 if(@d>0 and @dKSlP+isnull(@d,0)-@nKSLP<1.8) begin set @dKSLP = @dKSlP+isnull(@d,0) 
 if (@d>0)  begin set @nKSLP = @nKSlP+1 end end else begin if(@d>0) begin set @dKSLP=1.8 set @nKSLP=1 end end   if (@d>0) INSERT INTO @result select 44,'',@d
   set @d=  (select case when (((@dlit-
case when Replace(@usl1,'300DRG0118','') in      ('045','046','108','109','161','162','233','279','280','298') and @dlit > 45 then 45
     when Replace(@usl1,'300DRG0118','') not in  ('045','046','108','109','161','162','233','279','280','298') and @dlit > 30 then 30
	 else @dlit end)/
	 case when Replace(@usl1,'300DRG0118','') in ('045','046','108','109','161','162','233','279','280','298') and @dlit > 45 then 45
     when Replace(@usl1,'300DRG0118','') not in  ('045','046','108','109','161','162','233','279','280','298') and @dlit > 30 then 30
	 else @dlit end)*
	 case when Replace(@usl1,'300DRG0118','') in ( '022','062','220','299','321','322','324','323') then 0.4
	 else 0.25
	 end)>0 then 1+(((@dlit-
case when Replace(@usl1,'300DRG0118','') in      ('045','046','108','109','161','162','233','279','280','298') and @dlit > 45 then 45
     when Replace(@usl1,'300DRG0118','') not in  ('045','046','108','109','161','162','233','279','280','298') and @dlit > 30 then 30
	 else @dlit end)/
	 case when Replace(@usl1,'300DRG0118','') in ('045','046','108','109','161','162','233','279','280','298') and @dlit > 45 then 45
     when Replace(@usl1,'300DRG0118','') not in  ('045','046','108','109','161','162','233','279','280','298') and @dlit > 30 then 30
	 else @dlit end)*
	 case when Replace(@usl1,'300DRG0118','') in ( '022','062','220','299','321','322','324','323') then 0.4
	 else 0.25
	 end) else 0 end
 from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId   where    V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KSLP_SL13' and V_oms_krr.rf_kl_DepartmentTypeId=@typeId) 
  set @dKSLP = @dKSlP+isnull(@d,0) if (@d>0) INSERT INTO @result select 21,'',@d
   
 if  (@nKSLP>0)  INSERT INTO @result select '14','',@dKSLP-@nKSLP+1 
 
  if(select count(*) from @result
    inner join oms_KRRVid on KrrVidID= VidId
    where VidK_Code in ('KSLP_SL11','KSLP_SL1','KSLP_SL2'))>1 begin 

   update @result set Value = Value-(select top 1 Value from @result where VidId in  (select KrrvidId from oms_Krrvid where VidK_Code in ('KSLP_SL1','KSLP_SL2')))+1
    where VidId in  (select KrrvidId from oms_Krrvid where VidK_Code in ('КСЛП_01'))
	
   delete from @result  where VidId in  (select KrrvidId from oms_Krrvid where VidK_Code in ('KSLP_SL1','KSLP_SL2'))
 end 
  return end

go

