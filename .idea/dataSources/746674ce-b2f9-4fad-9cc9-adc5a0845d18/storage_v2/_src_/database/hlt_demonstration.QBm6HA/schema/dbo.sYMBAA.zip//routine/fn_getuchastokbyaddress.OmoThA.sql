-- =============================================
	-- Author:		Shevchenko Nina
	-- Create date: 2018-01-25
	-- Description:	Get UchastokId by Address
	-- =============================================
	-- По УРЗ не проверяем, предполагается, что до этого вызывалась функция [dbo].[fn_GetAttachmentFlagsByMkab] и по флагу NOT_IN_URZ 
	-- обработка идет дальше только если пользователь действительно хочет прикрепить неприкрепленного по УРЗ
	CREATE FUNCTION [dbo].[fn_GetUchastokByAddress]
	(
		@mkabId int,
		-- используются если @mkabId=0, предполагается что МКАБ в процессе создания
		@dr date,
		@liveAdrId int,
		@regAdrId int,
		@uchastokId int,
		-- используется если @liveAdrId=0, @regAdrId=0, @uchastokId=0
		@area varchar(100),--Район, город
		@building varchar(10),--Номер здания
		@kladrCode varchar(20),--Код КЛАДР
		@fiasCode varchar(50),--Код ФИАС
		@locality varchar(100),--Населенный пункт, город
		@region varchar(100),--Регион
		@corps varchar(10),--Корпус
		@street varchar(100),--Улица
		@superTown varchar(100),--Город
		@type varchar(20),--Тип адреса
		@areaPrefix varchar(20),--Префикс района, город
		@regionPrefix varchar(100),--Префикс региона
		@superTownPrefix varchar(100),--Префикс города
		@streetPrefix varchar(100),--Префикс улицы
	
		@urbanDistrict varchar(100),--Микрорайон, населенный пункт
		@urbanDistrictPrefix varchar(100),--Префикс микрорайона
		@houseNumber varchar(10)--Номер дома
	)
	RETURNS 
	@resTable TABLE 
	(
		typeAddress varchar(30),
		rfUchastokId int
	)
	AS
	BEGIN
		if @mkabId>0 
		begin
			insert into @resTable
			select 'UCHASTOK_BY_LIVEADR',uchastokid
			from hlt_MKAB with(nolock)
			inner join kla_Address with(nolock) on AddressId =rf_AddressLiveId and AddressId>0
			inner join kla_house with(nolock) on kla_house.houseid=kla_Address.rf_houseid and kla_house.houseid>0
			inner join hlt_housetouchastok with(nolock) 
			on (kla_house.houseid=hlt_housetouchastok.rf_houseid 
			or (hlt_housetouchastok.rf_houseid=0 and kla_house.code 
			in(hlt_housetouchastok.kladrcode,(SUBSTRING(hlt_housetouchastok.kladrcode,1,11)+'00'),(SUBSTRING(hlt_housetouchastok.kladrcode,1,8)+'00000'))))
			and hlt_housetouchastok.rf_UchastokId>0
			inner join hlt_Uchastok with(nolock) on hlt_housetouchastok.rf_UchastokId=UchastokId
			inner join hlt_Uchastokmkab with(nolock) on hlt_Uchastokmkab.rf_Uchastokid=hlt_housetouchastok.rf_uchastokid and hlt_Uchastokmkab.rf_MKABID=MKABID
			inner join oms_kl_TypeU with(nolock) on kl_TypeUID=hlt_Uchastok.rf_kl_TypeUID
			where 
			MKABID=@mkabId
			and hlt_Uchastokmkab.isDetach=0
			and hlt_Uchastok.isClosed = 0
			and
			((oms_kl_TypeU.kl_typeuid in (7,9,11,12) and dateadd(year,18,date_bd)>getdate())
			or 
			(oms_kl_TypeU.kl_typeuid in (1,8,9,10,12,13) and dateadd(year,18,date_bd)<=getdate()))

			insert into @resTable
			select 'UCHASTOK_BY_REGADR', UchastokID
			from hlt_MKAB with(nolock)
			inner join kla_Address with(nolock) on AddressId =rf_AddressRegID and AddressId>0
			inner join kla_house with(nolock) on kla_house.houseid=kla_Address.rf_houseid and kla_house.houseid>0
			inner join hlt_housetouchastok with(nolock) 
			on (kla_house.houseid=hlt_housetouchastok.rf_houseid 
			or (hlt_housetouchastok.rf_houseid=0 and kla_house.code 
			in(hlt_housetouchastok.kladrcode,(SUBSTRING(hlt_housetouchastok.kladrcode,1,11)+'00'),(SUBSTRING(hlt_housetouchastok.kladrcode,1,8)+'00000'))))
			and hlt_housetouchastok.rf_UchastokId>0
			inner join hlt_Uchastok with(nolock) on hlt_housetouchastok.rf_UchastokId=UchastokId
			inner join hlt_Uchastokmkab with(nolock) on hlt_Uchastokmkab.rf_Uchastokid=hlt_housetouchastok.rf_uchastokid and hlt_Uchastokmkab.rf_MKABID=MKABID
			inner join oms_kl_TypeU with(nolock) on kl_TypeUID=hlt_Uchastok.rf_kl_TypeUID
			where 
			MKABID=@mkabId
			and hlt_Uchastokmkab.isDetach=0
			and hlt_Uchastok.isClosed = 0
			and
			((oms_kl_TypeU.kl_typeuid in (7,9,11,12) and dateadd(year,18,date_bd)>getdate())
			or 
			(oms_kl_TypeU.kl_typeuid in (1,8,9,10,12,13) and dateadd(year,18,date_bd)<=getdate()))
		end
		else
		begin
			if @liveAdrId>0 
			begin
				insert into @resTable
				select 'UCHASTOK_BY_LIVEADR', UchastokID
				from kla_Address with(nolock) 
				inner join kla_house with(nolock) on kla_house.houseid=kla_Address.rf_houseid and kla_house.houseid>0
				inner join hlt_housetouchastok with(nolock) 
				on (kla_house.houseid=hlt_housetouchastok.rf_houseid 
				or (hlt_housetouchastok.rf_houseid=0 and kla_house.code 
				in(hlt_housetouchastok.kladrcode,(SUBSTRING(hlt_housetouchastok.kladrcode,1,11)+'00'),(SUBSTRING(hlt_housetouchastok.kladrcode,1,8)+'00000'))))
				and hlt_housetouchastok.rf_UchastokId>0
				inner join hlt_Uchastok with(nolock) on hlt_housetouchastok.rf_UchastokId=UchastokId and hlt_Uchastok.UchastokID=@uchastokId
				inner join oms_kl_TypeU with(nolock) on kl_TypeUID=hlt_Uchastok.rf_kl_TypeUID
				where 
				AddressId =@liveAdrId and AddressId>0
				and hlt_Uchastok.isClosed = 0
				and
				((oms_kl_TypeU.kl_typeuid in (7,9,11,12) and dateadd(year,18,@dr)>getdate())
				or 
				(oms_kl_TypeU.kl_typeuid in (1,8,9,10,12,13) and dateadd(year,18,@dr)<=getdate()))
			end

			if @regAdrId>0 
			begin
				insert into @resTable
				select 'UCHASTOK_BY_REGADR', UchastokID
				from kla_Address with(nolock) 
				inner join kla_house with(nolock) on kla_house.houseid=kla_Address.rf_houseid and kla_house.houseid>0
				inner join hlt_housetouchastok with(nolock) 
				on (kla_house.houseid=hlt_housetouchastok.rf_houseid 
				or (hlt_housetouchastok.rf_houseid=0 and kla_house.code 
				in(hlt_housetouchastok.kladrcode,(SUBSTRING(hlt_housetouchastok.kladrcode,1,11)+'00'),(SUBSTRING(hlt_housetouchastok.kladrcode,1,8)+'00000'))))
				and hlt_housetouchastok.rf_UchastokId>0
				inner join hlt_Uchastok with(nolock) on hlt_housetouchastok.rf_UchastokId=UchastokId and hlt_Uchastok.UchastokID=@uchastokId
				inner join oms_kl_TypeU with(nolock) on kl_TypeUID=hlt_Uchastok.rf_kl_TypeUID
				where 
				AddressId =@regAdrId and AddressId>0
				and hlt_Uchastok.isClosed = 0
				and
				((oms_kl_TypeU.kl_typeuid in (7,9,11,12) and dateadd(year,18,@dr)>getdate())
				or 
				(oms_kl_TypeU.kl_typeuid in (1,8,9,10,12,13) and dateadd(year,18,@dr)<=getdate()))
			end

			if len(@kladrCode)>=13 and @houseNumber!=''
			begin
				insert into @resTable
				select @type, UchastokID
				from kla_house with(nolock)
				inner join hlt_housetouchastok with(nolock) 
				on (kla_house.houseid=hlt_housetouchastok.rf_houseid 
				or (hlt_housetouchastok.rf_houseid=0 and kla_house.code 
				in(hlt_housetouchastok.kladrcode,(SUBSTRING(hlt_housetouchastok.kladrcode,1,11)+'00'),(SUBSTRING(hlt_housetouchastok.kladrcode,1,8)+'00000'))))
				and hlt_housetouchastok.rf_UchastokId>0
				inner join hlt_Uchastok with(nolock) on hlt_housetouchastok.rf_UchastokId=UchastokId 
				inner join oms_kl_TypeU with(nolock) on kl_TypeUID=hlt_Uchastok.rf_kl_TypeUID
				where 
				HouseId>0 and kla_house.number=@houseNumber and kla_house.building=@building and kla_house.[Construction]=@corps and kla_House.CODE=@kladrCode
				and hlt_Uchastok.isClosed = 0
				and
				((oms_kl_TypeU.kl_typeuid in (7,9,11,12) and dateadd(year,18,@dr)>getdate())
				or 
				(oms_kl_TypeU.kl_typeuid in (1,8,9,10,12,13) and dateadd(year,18,@dr)<=getdate()))
			end

			if len(@kladrCode)<13 and @houseNumber!='' and @street!='' and @streetPrefix!=''
			begin
				insert into @resTable
				select @type, UchastokID
				from kla_street with(nolock)
				inner join kla_kladr with(nolock) on kla_street.rf_kladrid=kladrid
				inner join kla_house with(nolock) on kla_house.rf_StreetID=kla_street.StreetID
				inner join hlt_housetouchastok with(nolock) 
				on (kla_house.houseid=hlt_housetouchastok.rf_houseid 
				or (hlt_housetouchastok.rf_houseid=0 and kla_street.code 
				in(hlt_housetouchastok.kladrcode,(SUBSTRING(hlt_housetouchastok.kladrcode,1,11)+'00'),(SUBSTRING(hlt_housetouchastok.kladrcode,1,8)+'00000'))))
				and hlt_housetouchastok.rf_UchastokId>0
				inner join hlt_Uchastok with(nolock) on hlt_housetouchastok.rf_UchastokId=UchastokId 
				inner join oms_kl_TypeU with(nolock) on kl_TypeUID=hlt_Uchastok.rf_kl_TypeUID
				where 
				HouseId>0 and kla_house.number=@houseNumber and kla_house.building=@building and kla_house.[Construction]=@corps 
				and kla_street.name=@street and kla_street.code like'%00' and kla_street.socr=@streetPrefix
				and kla_kladr.name in(@urbanDistrict,@locality)
				and hlt_Uchastok.isClosed = 0
				and
				((oms_kl_TypeU.kl_typeuid in (7,9,11,12) and dateadd(year,18,@dr)>getdate())
				or 
				(oms_kl_TypeU.kl_typeuid in (1,8,9,10,12,13) and dateadd(year,18,@dr)<=getdate()))
			end

			if len(@kladrCode)<13 and @houseNumber!='' and @street='' and (@urbanDistrict!='' or @locality!='')
			begin
				insert into @resTable
				select @type, UchastokID
				from kla_house with(nolock)
				inner join kla_kladr with(nolock) on kla_kladr.code=kla_house.code
				inner join hlt_housetouchastok with(nolock) 
				on (kla_house.houseid=hlt_housetouchastok.rf_houseid 
				or (hlt_housetouchastok.rf_houseid=0 and kla_house.code 
				in(hlt_housetouchastok.kladrcode,(SUBSTRING(hlt_housetouchastok.kladrcode,1,11)+'00'),(SUBSTRING(hlt_housetouchastok.kladrcode,1,8)+'00000'))))
				and hlt_housetouchastok.rf_UchastokId>0
				inner join hlt_Uchastok with(nolock) on hlt_housetouchastok.rf_UchastokId=UchastokId 
				inner join oms_kl_TypeU with(nolock) on kl_TypeUID=hlt_Uchastok.rf_kl_TypeUID
				where 
				HouseId>0 and kla_house.number=@houseNumber and kla_house.building=@building and kla_house.[Construction]=@corps 
				and kla_kladr.name in (@urbanDistrict,@locality) and kla_kladr.code like'%00'
				and hlt_Uchastok.isClosed = 0 
				and
				((oms_kl_TypeU.kl_typeuid in (7,9,11,12) and dateadd(year,18,@dr)>getdate())
				or 
				(oms_kl_TypeU.kl_typeuid in (1,8,9,10,12,13) and dateadd(year,18,@dr)<=getdate()))
			end

			if len(@kladrCode)<13 and @houseNumber='' and @street!='' and @streetPrefix!=''
			begin
				insert into @resTable
				select @type, UchastokID
				from kla_street with(nolock)
				inner join kla_kladr with(nolock) on kla_street.rf_kladrid=kladrid
				inner join hlt_housetouchastok with(nolock) 
				on (hlt_housetouchastok.rf_houseid=0 and kla_street.code 
				in(hlt_housetouchastok.kladrcode,(SUBSTRING(hlt_housetouchastok.kladrcode,1,11)+'00'),(SUBSTRING(hlt_housetouchastok.kladrcode,1,8)+'00000')))
				and hlt_housetouchastok.rf_UchastokId>0
				inner join hlt_Uchastok with(nolock) on hlt_housetouchastok.rf_UchastokId=UchastokId 
				inner join oms_kl_TypeU with(nolock) on kl_TypeUID=hlt_Uchastok.rf_kl_TypeUID
				where 
				kla_street.name=@street and kla_street.code like'%00' and kla_street.socr=@streetPrefix
				and kla_kladr.name in(@urbanDistrict,@locality)
				and hlt_Uchastok.isClosed = 0
				and
				((oms_kl_TypeU.kl_typeuid in (7,9,11,12) and dateadd(year,18,@dr)>getdate())
				or 
				(oms_kl_TypeU.kl_typeuid in (1,8,9,10,12,13) and dateadd(year,18,@dr)<=getdate()))
			end

			if len(@kladrCode)<13 and @houseNumber='' and @street='' and (@urbanDistrict!='' or @locality!='')
			begin
				insert into @resTable
				select @type, UchastokID
				from kla_kladr with(nolock) 
				inner join hlt_housetouchastok with(nolock) 
				on (hlt_housetouchastok.rf_houseid=0 and kla_kladr.code 
				in(hlt_housetouchastok.kladrcode,(SUBSTRING(hlt_housetouchastok.kladrcode,1,11)+'00'),(SUBSTRING(hlt_housetouchastok.kladrcode,1,8)+'00000')))
				and hlt_housetouchastok.rf_UchastokId>0
				inner join hlt_Uchastok with(nolock) on hlt_housetouchastok.rf_UchastokId=UchastokId 
				inner join oms_kl_TypeU with(nolock) on kl_TypeUID=hlt_Uchastok.rf_kl_TypeUID
				where 
				kla_kladr.name in (@urbanDistrict,@locality) and kla_kladr.code like'%00'
				and hlt_Uchastok.isClosed = 0 
				and
				((oms_kl_TypeU.kl_typeuid in (7,9,11,12) and dateadd(year,18,@dr)>getdate())
				or 
				(oms_kl_TypeU.kl_typeuid in (1,8,9,10,12,13) and dateadd(year,18,@dr)<=getdate()))
			end
		end
		RETURN 
	END


go

