CREATE VIEW [V_hlt_CallPersonType] AS SELECT 
[hDED].[CallPersonTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Flags] as [Flags], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Guid] as [Guid]
FROM [hlt_CallPersonType] as [hDED]
go

