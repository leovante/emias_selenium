
-------------------
-------------------
-- =============================================
-- Author:		Ranzou
-- Create date: <Create Date,,>
-- Description:	Показывает ошибки в файлах с заданным приоритетом
-- =============================================
CREATE PROCEDURE [dbo].[LDBF_ShowErrors]
	@Priority int,
	@iReestr int	
AS
BEGIN

Declare @Result varchar(100),@SQL nvarchar(max);


DECLARE cur_Tab SCROLL CURSOR  FOR
Select Name_DBF,Key_DBF,Query_DBF,Code,Name_DBF
	from oms_LoadNSITable 
		inner join [tmp_LoadPrepare] on tablename=Table_Name and LoadNSITableID = tableID
	where LoadNSITableID>0 and oms_LoadNSITable.Priority=@Priority
group by Key_DBF,Name_DBF,Query_DBF,Code,oms_LoadNSITable.Priority
order by oms_LoadNSITable.Priority

OPEN cur_Tab
DECLARE @N_T varchar(100), @Key varchar(400),@QueryDBF varchar(8000), @Code int,@N_T_0 varchar(100)
	FETCH FIRST FROM cur_Tab
	INTO @N_T,@Key,@QueryDBF,@Code,@N_T_0
WHILE @@FETCH_STATUS = 0
BEGIN
begin try
	
	exec [dbo].[OMS_LoadError_upd] @Code,@iReestr,@Result
	print @Result

end try

begin CATCH 
	print 'Error '+@Result
end Catch

	FETCH NEXT FROM cur_Tab
	INTO @N_T,@Key,@QueryDBF,@Code,@N_T_0
END

DEALLOCATE cur_Tab;



END

go

