CREATE VIEW [V_oms_mn_Polis] AS SELECT 
[hDED].[mn_PolisID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_kl_TipOMSID] as [rf_kl_TipOMSID], 
[jT_oms_kl_TipOMS].[IDDOC] as [SILENT_rf_kl_TipOMSID], 
[hDED].[rf_mn_PersonID] as [rf_mn_PersonID], 
[jT_oms_mn_Person].[V_FIO] as [SILENT_rf_mn_PersonID], 
[hDED].[Series] as [Series], 
[hDED].[Number] as [Number], 
[hDED].[FlagDMS] as [FlagDMS], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[isActive] as [isActive], 
[hDED].[PolisGuid] as [PolisGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[SNPolis_Find] as [SNPolis_Find]
FROM [oms_mn_Polis] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_kl_TipOMS] as [jT_oms_kl_TipOMS] on [jT_oms_kl_TipOMS].[kl_TipOMSID] = [hDED].[rf_kl_TipOMSID]
INNER JOIN [V_oms_mn_Person] as [jT_oms_mn_Person] on [jT_oms_mn_Person].[mn_PersonID] = [hDED].[rf_mn_PersonID]
go

