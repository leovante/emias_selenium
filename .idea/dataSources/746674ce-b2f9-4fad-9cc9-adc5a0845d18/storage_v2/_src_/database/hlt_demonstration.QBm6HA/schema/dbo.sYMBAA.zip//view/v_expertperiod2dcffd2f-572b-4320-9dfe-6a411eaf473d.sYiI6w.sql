
CREATE view [V_ExpertPeriod2dcffd2f-572b-4320-9dfe-6a411eaf473d] as select * from [tmp_ExpertPeriod2dcffd2f-572b-4320-9dfe-6a411eaf473d]
go

