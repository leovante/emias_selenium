CREATE VIEW [V_hlt_MessageQueue] AS SELECT 
[hDED].[MessageQueueID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_MKAB].[V_FIO] as [V_FIO], 
[hDED].[rf_MkabGUID] as [rf_MkabGUID], 
[hDED].[Type] as [Type], 
[hDED].[Message] as [Message], 
[hDED].[Date] as [Date], 
[hDED].[DateSend] as [DateSend], 
[hDED].[GUID] as [GUID], 
[hDED].[MessageID] as [MessageID], 
[hDED].[MessageState] as [MessageState], 
[hDED].[CommandStatus] as [CommandStatus], 
[hDED].[Flags] as [Flags], 
[hDED].[Subject] as [Subject], 
[hDED].[Address] as [Address]
FROM [hlt_MessageQueue] as [hDED]
INNER JOIN [V_hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[UGUID] = [hDED].[rf_MkabGUID]
go

