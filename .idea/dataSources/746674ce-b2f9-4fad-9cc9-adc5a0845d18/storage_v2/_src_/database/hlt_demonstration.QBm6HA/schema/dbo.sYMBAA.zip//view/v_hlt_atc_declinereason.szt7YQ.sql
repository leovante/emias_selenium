CREATE VIEW [V_hlt_atc_DeclineReason] AS SELECT 
[hDED].[atc_DeclineReasonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_atc_ClaimKindID] as [rf_atc_ClaimKindID], 
[jT_hlt_atc_ClaimKind].[Name] as [SILENT_rf_atc_ClaimKindID], 
[hDED].[Code] as [Code], 
[hDED].[Reason] as [Reason], 
[hDED].[Reccom] as [Reccom], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_atc_DeclineReason] as [hDED]
INNER JOIN [hlt_atc_ClaimKind] as [jT_hlt_atc_ClaimKind] on [jT_hlt_atc_ClaimKind].[atc_ClaimKindID] = [hDED].[rf_atc_ClaimKindID]
go

