CREATE VIEW [V_oms_SMReestrCONS] AS SELECT 
[hDED].[SMReestrCONSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[PR_CONS] as [PR_CONS], 
[hDED].[DT_CONS] as [DT_CONS]
FROM [oms_SMReestrCONS] as [hDED]
go

