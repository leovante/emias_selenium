CREATE VIEW [V_oms_RecipeDefinition] AS SELECT 
[hDED].[RecipeDefinitionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[hDED].[DOCTOR_FAMILY] as [DOCTOR_FAMILY], 
[hDED].[DOCTOR_NAME] as [DOCTOR_NAME], 
[hDED].[DOCTOR_PATRONYMIC] as [DOCTOR_PATRONYMIC], 
[hDED].[PERSON_FAMILY] as [PERSON_FAMILY], 
[hDED].[PERSON_NAME] as [PERSON_NAME], 
[hDED].[PERSON_PATRONYMIC] as [PERSON_PATRONYMIC], 
[hDED].[SN_POL] as [SN_POL], 
[hDED].[DR] as [DR], 
[hDED].[DOC_REASON] as [DOC_REASON], 
[hDED].[ADRES] as [ADRES], 
[hDED].[SS_RD] as [SS_RD]
FROM [oms_RecipeDefinition] as [hDED]
go

