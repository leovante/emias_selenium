
CREATE view [VV_ExpertPeriod31e3a07b-1493-4ba5-a9ca-3e9e6b6de365] as 
select v.* from 
(
Select
isnull(FHReestrOccasionID,0) FHReestrOccasionID,
isnull(FHReestrPositionID,0) FHReestrPositionID,
isnull(ReestrOccasionID,0) SU,
isnull(ReestrMKSBID,0) ReestrMKSBID,
isnull(rf_MedServicePatientId,0) rf_MedServicePatientId,
isnull(tmp_UTable_Reestr.ReestrMHSMTAPId,0) ReestrMHSMTAPId,
isnull(ReestrTAPMHID,0) rf_ReestrTAPMHID,
isnull(rf_ReestrMHID,0) rf_ReestrMHID,
dep_name,
rf_SMOID,
rf_ReportPeriodID,lpuid,lpu_name,
mTAPID NHISTORY,
convert(varchar(10),U_Table.N_REC)+U_Table.MSK_OT as Usl_IDSERV,
U_Table.NHISTORY+U_Table.CODE_OTD as Sluch_SluchID,
convert(varchar(10),P_Table.N_REC)+P_Table.MSK_OT Patient_ID_PAC,
isnull(U_Table.SUM_RUB,0) as usl_sumV_Usl,
case when U_Table.USL_OK ='01' then 1
when U_Table.USL_OK ='03' then 3
when U_Table.USL_OK ='07' then 4
else 2 end Sluch_USL_OK,
isnull(rf_JournalCallID,0) rf_JournalCallID,
isnull(rf_MKABID,0) rf_MKABID,
isnull(rf_TAPID,0) rf_TAPID,
isnull(SK,0) SK,
isnull(rf_ServiceMedicalID,0) rf_ServiceMedicalID
,U_Table.N_REC as Usl_N_REC,
U_Table.OT_PER as Usl_OT_PER ,
U_Table.CODE_LPU as Usl_CODE_LPU ,
U_Table.MSK_OT as Usl_MSK_OT ,
U_Table.PERSCODE as Usl_PERSCODE ,
U_Table.VID_MP as Usl_VID_MP ,
U_Table.USL_OK as Usl_USL_OK ,
U_Table.NHISTORY as Usl_NHISTORY ,
U_Table.PROFIL as Usl_PROFIL ,
U_Table.MKB1 as Usl_MKB1 ,
U_Table.MKB2 as Usl_MKB2 
,U_Table.MKB3 as Usl_MKB3 ,
U_Table.CODE_USL as Usl_CODE_USL ,
U_Table.CODE_MD as Usl_CODE_MD,
U_Table.DATE_IN as Usl_DATE_IN ,
U_Table.DATE_OUT as Usl_DATE_OUT ,
U_Table.KOL_USL as Usl_KOL_USL ,
U_Table.KOL_FACT as Usl_KOL_FACT ,
U_Table.ISH_MOV as Usl_ISH_MOV ,
U_Table.RES_GOSP as Usl_RES_GOSP
,U_Table.VID_SF as Usl_VID_SF ,
U_Table.TARIF_B as Usl_TARIF_B ,
U_Table.TARIF_S as Usl_TARIF_S ,
U_Table.TARIF_D as Usl_TARIF_D ,
U_Table.SUM_RUB as Usl_SUM_RUB ,U_Table.VID_TR as Usl_VID_TR ,U_Table.TARIF_1K as Usl_TARIF_1K ,U_Table.EXTR as Usl_EXTR ,U_Table.CODE_OTD as Usl_CODE_OTD ,U_Table.SOUF as Usl_SOUF
,Z_Table.TEETH_CODE as Usl_TEETH_CODE,Z_Table.OCCLUSION as Usl_OCCLUSION,Z_Table.N_REC as Z_N_REC
,P_Table.N_Rec as Patient_N_Rec ,P_Table.OT_PER as Patient_OT_PER ,P_Table.CODE_LPU as Patient_CODE_LPU ,P_Table.MSK_OT as Patient_MSK_OT ,P_Table.PERSCODE as Patient_PERSCODE ,P_Table.ENP as Patient_ENP ,P_Table.DOMC_TYPE as Patient_DOMC_TYPE ,
P_Table.SERIES as Patient_SERIES ,P_Table.NUMBER as Patient_NUMBER ,P_Table.CODE_MSK as Patient_CODE_MSK ,P_Table.NAME_MSK as Patient_NAME_MSK ,P_Table.OKATO_INS as Patient_OKATO_INS ,P_Table.FAM as Patient_FAM ,P_Table.IM as Patient_IM ,
P_Table.OT as Patient_OT ,P_Table.BIRTHDAY as Patient_DR ,P_Table.SEX as Patient_SEX ,P_Table.OKATO_NAS as Patient_OKATO_NAS ,P_Table.COUNTRY as Patient_COUNTRY ,P_Table.PASP_SER as Patient_PASP_SER ,P_Table.PASP_NUM as Patient_PASP_NUM ,
P_Table.PASP_VID as Patient_PASP_VID ,P_Table.FAM1 as Patient_FAM1 ,P_Table.IM1 as Patient_IM1 ,P_Table.OT1 as Patient_OT1 ,P_Table.SEX_P as Patient_SEX_P ,P_Table.BIRTHDAY_P as Patient_BIRTHDAY_P ,P_Table.PASP_SER_P as Patient_PASP_SER_P ,
P_Table.PASP_NUM_P as Patient_PASP_NUM_P ,P_Table.PASP_VID_P as Patient_PASP_VID_P ,P_Table.MR as Patient_MR ,P_Table.NOVOR as Patient_NOVOR ,P_Table.OS_SLUCH as Patient_OS_SLUCH ,P_Table.SNILS as Patient_SNILS ,P_Table.VNOV as Patient_VNOV ,
P_Table.DOST_FIO as Patient_DOST_FIO ,P_Table.DOST_FIO_D as Patient_DOST_FIO_D ,P_Table.DOST_DR as Patient_DOST_DR ,P_Table.VNOV_M as Patient_VNOV_M ,P_Table.PR_LG as Patient_PR_LG
,D_table2.n_rec as D_n_rec,D_table2.OT_PER as D_OT_PER,D_table2.CODE_LPU as D_CODE_LPUc,D_table2.CODE_MD as D_CODE_MD,D_table2.FIO_MD as D_FIO_MD,D_table2.KATEG_MD as D_KATEG_MD,
D_table2.SPEC_MD as D_SPEC_MD,D_table2.POST_MD as D_POST_MD,D_table2.MD_SS as D_MD_SS
,M_table.N_REC as M_N_REC,M_table.OT_PER as M_OT_PER,M_table.CODE_LPU as M_CODE_LPU,M_table.MSK_OT as M_MSK_OT,M_table.PERSCODE as M_PERSCODE,M_table.NHISTORY as M_NHISTORY,
M_table.CODE_USL as M_CODE_USL,M_table.DATE_DVN as M_DATE_DVN,M_table.ISP_DVN as M_ISP_DVN,M_table.NEW_DVN as M_NEW_DVN
,G_table.N_Rec as G_N_Rec ,G_table.OT_PER as G_OT_PER ,G_table.CODE_LPU as G_CODE_LPU ,G_table.MSK_OT as G_MSK_OT ,G_table.PERSCODE as G_PERSCODE ,G_table.VID_SF as G_VID_SF ,G_table.VID_MP as G_VID_MP ,G_table.USL_OK as G_USL_OK ,G_table.NHISTORY as G_NHISTORY 
,G_table.PROFIL as G_PROFIL ,G_table.MKB1 as G_MKB1 ,G_table.MKB2 as G_MKB2 ,G_table.MKB3 as G_MKB3 ,G_table.CODE_USL as G_CODE_USL ,G_table.CODE_OTD as G_CODE_OTD ,G_table.CODE_MD as G_CODE_MD
,G_table.DATE_IN as G_DATE_IN ,G_table.DATE_OUT as G_DATE_OUT ,G_table.KOL_FACT as G_KOL_FACT ,G_table.ISH_MOV as G_ISH_MOV ,G_table.RES_GOSP as G_RES_GOSP ,G_table.SUM_RUB as G_SUM_RUB ,
G_table.CODE_NOM1 as G_CODE_NOM1 ,G_table.CODE_NOM2 as G_CODE_NOM2 ,G_table.CODE_NOM3 as G_CODE_NOM3 ,G_table.EXTR as G_EXTR ,G_table.VID_TR as G_VID_TR
,X_table.N_Rec as X_N_Rec ,X_table.OT_PER as X_OT_PER ,X_table.CODE_LPU as X_CODE_LPU ,X_table.MSK_OT as X_MSK_OT ,X_table.PERSCODE as X_PERSCODE ,X_table.NHISTORY as X_NHISTORY ,X_table.CODE_USL as X_CODE_USL
,X_table.DATE_IN as X_DATE_IN ,X_table.DATE_OUT as X_DATE_OUT ,X_table.TIME_FIX as X_TIME_FIX ,X_table.TIME_IN as X_TIME_IN ,X_table.TIME_OUT as X_TIME_OUT,X_table.DATE_FIX as X_DATE_FIX
,PrevUE1,PrevUE2,Prev
from [tmp_UTable_Reestr31e3a07b-1493-4ba5-a9ca-3e9e6b6de365] tmp_UTable_Reestr
left join [U_Table231e3a07b-1493-4ba5-a9ca-3e9e6b6de365] U_Table on mTAPID =NHISTORY and (U_Table.MedServicePatientID>0 and U_Table.MedServicePatientID=rf_MedServicePatientId OR 
U_Table.MedServicePatientID=0 and Code_USL=case when SMCode like '210[68]000%' then Code_USL else SMCode end and Date_P between U_Table.date_IN and U_Table.Date_OUT
and U_Table.TEETH_CODE=isnull(tmp_UTable_Reestr.TEETH_CODE,') and U_Table.OCCLUSION=isnull(tmp_UTable_Reestr.OCCLUSION,'))
left join [P_table31e3a07b-1493-4ba5-a9ca-3e9e6b6de365] P_table on isnull(U_Table.PersCODE,PersCODE_r)=P_Table.PersCODE  and isnull(U_Table.CODE_LPU,'777777')=P_table.CODE_LPU
--PersCODE_r=P_Table.PersCODE 
left join [D_table231e3a07b-1493-4ba5-a9ca-3e9e6b6de365] D_table2 on D_table2.CODE_MD=U_Table.CODE_MD and U_Table.CODE_LPU=D_table2.CODE_LPU
left join [M_table31e3a07b-1493-4ba5-a9ca-3e9e6b6de365] M_table on U_Table.NHISTORY=M_table.NHISTORY and SMCode=M_table.Code_USL
left join [G_table31e3a07b-1493-4ba5-a9ca-3e9e6b6de365] G_table on U_Table.NHISTORY=G_table.NHISTORY and (G_table.Code_USL=M_table.Code_USL or G_table.Code_USL=U_table.Code_USL) and U_Table.MedServicePatientID=G_table.MedServicePatientID
left join [X_table31e3a07b-1493-4ba5-a9ca-3e9e6b6de365] X_table on U_Table.NHISTORY=X_table.NHISTORY and X_table.Code_USL=M_table.Code_USL
left join [Z_Table31e3a07b-1493-4ba5-a9ca-3e9e6b6de365] Z_Table on Z_Table.ReestrMHSMTAPID=tmp_UTable_Reestr.ReestrMHSMTAPId
)v
go

