
create FUNCTION  [dbo].[GetKRRValueКпс](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int,
@prerv varchar(1000)=''
)
RETURNS  [decimal](38, 6) 
AS
begin
declare @k decimal(18,6)
set @k=1
select @k=@k*value
from [dbo].[GetKRRКпс](@date, @lpuid,@profileId,@typeid,@usl1 ,@usl2,@mkb ,@age,@dlit,@prerv)
return @k
end
go

