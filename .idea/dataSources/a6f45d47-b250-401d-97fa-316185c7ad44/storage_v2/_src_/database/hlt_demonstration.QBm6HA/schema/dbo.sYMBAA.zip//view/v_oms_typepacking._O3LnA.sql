CREATE VIEW [V_oms_TypePacking] AS SELECT 
[hDED].[TypePackingID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [oms_TypePacking] as [hDED]
go

