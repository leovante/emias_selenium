
CREATE view [V_ExpertPeriod15bfa575-7583-437e-8293-9b5ab527ea6b] as select * from [tmp_ExpertPeriod15bfa575-7583-437e-8293-9b5ab527ea6b]
go

