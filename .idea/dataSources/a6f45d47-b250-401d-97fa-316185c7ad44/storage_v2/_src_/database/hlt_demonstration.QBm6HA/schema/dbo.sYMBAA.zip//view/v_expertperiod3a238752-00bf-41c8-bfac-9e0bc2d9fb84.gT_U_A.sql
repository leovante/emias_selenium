
CREATE view [V_ExpertPeriod3a238752-00bf-41c8-bfac-9e0bc2d9fb84] as select * from [tmp_ExpertPeriod3a238752-00bf-41c8-bfac-9e0bc2d9fb84]
go

