CREATE VIEW [V_oms_Tariff] AS SELECT 
[hDED].[TariffID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [V_SMName], 
[jT_oms_kl_Category].[Name] as [V_CategoryNAME], 
[jT_oms_TariffTarget].[TariffTargetName] as [V_TariffTargetName], 
[hDED].[rf_DOGOVORID] as [rf_DOGOVORID], 
[jT_oms_DOGOVOR].[V_Info] as [SILENT_rf_DOGOVORID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_kl_AgeGroupID] as [rf_kl_AgeGroupID], 
[jT_oms_kl_AgeGroup].[Name] as [SILENT_rf_kl_AgeGroupID], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[hDED].[rf_kl_MedCareTypeID] as [rf_kl_MedCareTypeID], 
[jT_oms_kl_MedCareType].[Code] as [SILENT_rf_kl_MedCareTypeID], 
[hDED].[rf_kl_MedCareUnitID] as [rf_kl_MedCareUnitID], 
[jT_oms_kl_MedCareUnit].[Code] as [SILENT_rf_kl_MedCareUnitID], 
[hDED].[rf_kl_ReasonTypeID] as [rf_kl_ReasonTypeID], 
[jT_oms_kl_ReasonType].[Name] as [SILENT_rf_kl_ReasonTypeID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[rf_kl_TariffTypeID] as [rf_kl_TariffTypeID], 
[jT_oms_kl_TariffType].[Name] as [SILENT_rf_kl_TariffTypeID], 
[hDED].[rf_kl_VisitPlaceID] as [rf_kl_VisitPlaceID], 
[jT_oms_kl_VisitPlace].[Name] as [SILENT_rf_kl_VisitPlaceID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_kl_CategoryID] as [rf_kl_CategoryID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[rf_TariffTargetID] as [rf_TariffTargetID], 
[jT_oms_TariffTarget].[TariffTargetCode] as [SILENT_rf_TariffTargetID], 
[hDED].[rf_TariffNormID] as [rf_TariffNormID], 
[hDED].[rf_ServiceMedicalTreeID] as [rf_ServiceMedicalTreeID], 
[jT_oms_ServiceMedicalTree].[rf_ChildServiceMedicalID] as [SILENT_rf_ServiceMedicalTreeID], 
[hDED].[rf_NDSRateID] as [rf_NDSRateID], 
[jT_oms_NDSRate].[NDS_Name] as [SILENT_rf_NDSRateID], 
[hDED].[Value1] as [Value1], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Value2] as [Value2], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Flags] as [Flags], 
[hDED].[GUIDTariff] as [GUIDTariff], 
[hDED].[IncSalary] as [IncSalary], 
[hDED].[IncMedication] as [IncMedication], 
[hDED].[IncFood] as [IncFood], 
[hDED].[IncStock] as [IncStock], 
[hDED].[IncManage] as [IncManage], 
[hDED].[IncMisc] as [IncMisc], 
[hDED].[UET_MD] as [UET_MD], 
[hDED].[UET_MS] as [UET_MS], 
[hDED].[Doc] as [Doc], 
[hDED].[Value3] as [Value3], 
[hDED].[Value4] as [Value4], 
[hDED].[Rem] as [Rem], 
[hDED].[isOneAgreement] as [isOneAgreement]
FROM [oms_Tariff] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_kl_Category] as [jT_oms_kl_Category] on [jT_oms_kl_Category].[kl_CategoryID] = [hDED].[rf_kl_CategoryID]
INNER JOIN [oms_TariffTarget] as [jT_oms_TariffTarget] on [jT_oms_TariffTarget].[TariffTargetID] = [hDED].[rf_TariffTargetID]
INNER JOIN [V_oms_DOGOVOR] as [jT_oms_DOGOVOR] on [jT_oms_DOGOVOR].[DOGOVORID] = [hDED].[rf_DOGOVORID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_kl_AgeGroup] as [jT_oms_kl_AgeGroup] on [jT_oms_kl_AgeGroup].[kl_AgeGroupID] = [hDED].[rf_kl_AgeGroupID]
INNER JOIN [oms_kl_MedCareType] as [jT_oms_kl_MedCareType] on [jT_oms_kl_MedCareType].[kl_MedCareTypeID] = [hDED].[rf_kl_MedCareTypeID]
INNER JOIN [oms_kl_MedCareUnit] as [jT_oms_kl_MedCareUnit] on [jT_oms_kl_MedCareUnit].[kl_MedCareUnitID] = [hDED].[rf_kl_MedCareUnitID]
INNER JOIN [oms_kl_ReasonType] as [jT_oms_kl_ReasonType] on [jT_oms_kl_ReasonType].[kl_ReasonTypeID] = [hDED].[rf_kl_ReasonTypeID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [oms_kl_TariffType] as [jT_oms_kl_TariffType] on [jT_oms_kl_TariffType].[kl_TariffTypeID] = [hDED].[rf_kl_TariffTypeID]
INNER JOIN [oms_kl_VisitPlace] as [jT_oms_kl_VisitPlace] on [jT_oms_kl_VisitPlace].[kl_VisitPlaceID] = [hDED].[rf_kl_VisitPlaceID]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
INNER JOIN [oms_ServiceMedicalTree] as [jT_oms_ServiceMedicalTree] on [jT_oms_ServiceMedicalTree].[ServiceMedicalTreeID] = [hDED].[rf_ServiceMedicalTreeID]
INNER JOIN [oms_NDSRate] as [jT_oms_NDSRate] on [jT_oms_NDSRate].[NDSRateID] = [hDED].[rf_NDSRateID]
go

