CREATE VIEW [V_dd_DDNormCost] AS SELECT 
[hDED].[DDNormCostID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[jT_dd_DDType].[Name] as [SILENT_rf_DDTypeGUID], 
[hDED].[AgeMinBoundary] as [AgeMinBoundary], 
[hDED].[AgeMaxBoundary] as [AgeMaxBoundary], 
[hDED].[Summa] as [Summa], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDNormCost] as [hDED]
INNER JOIN [dd_DDType] as [jT_dd_DDType] on [jT_dd_DDType].[UGUID] = [hDED].[rf_DDTypeGUID]
go

