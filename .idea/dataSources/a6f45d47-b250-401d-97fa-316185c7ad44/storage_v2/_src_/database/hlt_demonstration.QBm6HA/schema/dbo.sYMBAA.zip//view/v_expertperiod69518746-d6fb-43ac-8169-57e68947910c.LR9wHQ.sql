
CREATE view [V_ExpertPeriod69518746-d6fb-43ac-8169-57e68947910c] as select * from [tmp_ExpertPeriod69518746-d6fb-43ac-8169-57e68947910c]
go

