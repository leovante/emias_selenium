CREATE VIEW [V_vcn_InoculationSteps] AS SELECT 
[hDED].[InoculationStepsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_InoculationID] as [rf_InoculationID], 
[hDED].[rf_VaccinationTypeID] as [rf_VaccinationTypeID], 
[hDED].[rf_VaccinationGroupID] as [rf_VaccinationGroupID], 
[hDED].[Flags] as [Flags], 
[hDED].[InoculationStepsGuid] as [InoculationStepsGuid]
FROM [vcn_InoculationSteps] as [hDED]
go

