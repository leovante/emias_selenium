
create FUNCTION [dbo].[GetKRRКпс](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int,
@prerv varchar(500)=''
)
RETURNS @result TABLE (
vidID int,
info varchar(max),
[Value] [decimal](38, 6) NULL

)
AS
begin
Declare @xml xml
set @xml = convert(xml,@prerv)
declare @SPCASE varchar(10)
declare @VR     varchar(10)
declare @SF varchar(20)
select  @SPCASE= SPCASE,@VR= VR, @SF=VIDSF
 from (
select 
   t.x.value('@SPCASE[1]', 'varchar(50)') as SPCASE,
   t.x.value('@VR[1]',     'varchar(50)') as VR, 
  t2.x.value('@SMCODE[1]', 'varchar(50)') as SMCODE,
  t2.x.value('@SF[1]',  'varchar(50)') as VIDSF
from @xml.nodes('/a') t(x) 
outer apply  x.nodes('//b') as t2 (x)
) t where Smcode in (@usl1, @usl2,'') or Smcode is null
INSERT INTO @result
select '38','',
case when    @mkb in (select mkbid from oms_mkb where DS in (
'F10.0','F11.0','F12.0','F13.0','F14.0','F15.0','F16.0','F18.0','F19.0','F10.1','F11.1','F12.1','F13.1',
'F14.1','F15.1','F16.1','F18.1','F19.1','F10.3','F11.3','F12.3','F13.3','F14.3','F15.3','F16.3','F18.3','F19.3')
) and @SF in ('16','17')  then 1 else 
case when @dlit > valueKrr then
round(@dlit/valuekrr,6) else 0  end  end from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId   where   V_ServiceMedicalCode1=@usl1 and V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KPS_1' 
 
	delete from @result where value=0
  return end
go

