CREATE VIEW [V_hlt_atc_ClaimPerson] AS SELECT 
[hDED].[atc_ClaimPersonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_TYPEDOCID] as [rf_TYPEDOCID], 
[jT_oms_TYPEDOC].[C_DOC] as [SILENT_rf_TYPEDOCID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_AddressRegID] as [rf_AddressRegID], 
[hDED].[rf_AddressliveID] as [rf_AddressliveID], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[rf_kl_TipOMSID] as [rf_kl_TipOMSID], 
[jT_oms_kl_TipOMS].[IDDOC] as [SILENT_rf_kl_TipOMSID], 
[hDED].[rf_NotWorkDocCareID] as [rf_NotWorkDocCareID], 
[jT_hlt_NotWorkDocCare].[NAME] as [SILENT_rf_NotWorkDocCareID], 
[hDED].[rf_OKSMID] as [rf_OKSMID], 
[jT_oms_OKSM].[NameSM] as [SILENT_rf_OKSMID], 
[hDED].[rf_atc_CategoryID] as [rf_atc_CategoryID], 
[jT_hlt_atc_Category].[Name] as [SILENT_rf_atc_CategoryID], 
[hDED].[rf_atc_LiveStatusID] as [rf_atc_LiveStatusID], 
[jT_hlt_atc_LiveStatus].[Name] as [SILENT_rf_atc_LiveStatusID], 
[hDED].[IdInSource] as [IdInSource], 
[hDED].[Family] as [Family], 
[hDED].[Name] as [Name], 
[hDED].[Ot] as [Ot], 
[hDED].[BD] as [BD], 
[hDED].[SS] as [SS], 
[hDED].[S_DOC] as [S_DOC], 
[hDED].[N_DOC] as [N_DOC], 
[hDED].[S_POL] as [S_POL], 
[hDED].[N_POL] as [N_POL], 
[hDED].[BirthPlace] as [BirthPlace], 
[hDED].[AddressReg] as [AddressReg], 
[hDED].[ContactMPhone] as [ContactMPhone], 
[hDED].[ContactEmail] as [ContactEmail], 
[hDED].[Comment] as [Comment], 
[hDED].[GUID] as [GUID], 
[hDED].[AddressLive] as [AddressLive], 
[hDED].[DateDoc] as [DateDoc], 
[hDED].[DocIssuedBy] as [DocIssuedBy], 
[hDED].[DatePolBegin] as [DatePolBegin], 
[hDED].[DatePolEnd] as [DatePolEnd], 
[hDED].[AgeChild] as [AgeChild], 
[hDED].[GestationalAge] as [GestationalAge], 
[hDED].[InsuranceChecked] as [InsuranceChecked]
FROM [hlt_atc_ClaimPerson] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_TYPEDOC] as [jT_oms_TYPEDOC] on [jT_oms_TYPEDOC].[TYPEDOCID] = [hDED].[rf_TYPEDOCID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
INNER JOIN [oms_kl_TipOMS] as [jT_oms_kl_TipOMS] on [jT_oms_kl_TipOMS].[kl_TipOMSID] = [hDED].[rf_kl_TipOMSID]
INNER JOIN [hlt_NotWorkDocCare] as [jT_hlt_NotWorkDocCare] on [jT_hlt_NotWorkDocCare].[NotWorkDocCareID] = [hDED].[rf_NotWorkDocCareID]
INNER JOIN [oms_OKSM] as [jT_oms_OKSM] on [jT_oms_OKSM].[OKSMID] = [hDED].[rf_OKSMID]
INNER JOIN [hlt_atc_Category] as [jT_hlt_atc_Category] on [jT_hlt_atc_Category].[atc_CategoryID] = [hDED].[rf_atc_CategoryID]
INNER JOIN [hlt_atc_LiveStatus] as [jT_hlt_atc_LiveStatus] on [jT_hlt_atc_LiveStatus].[atc_LiveStatusID] = [hDED].[rf_atc_LiveStatusID]
go

