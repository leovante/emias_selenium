CREATE VIEW [V_oms_ConsolidatedWPL] AS SELECT 
[hDED].[ConsolidatedWPLID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[GUIDMedicalHistory] as [GUIDMedicalHistory]
FROM [oms_ConsolidatedWPL] as [hDED]
go

