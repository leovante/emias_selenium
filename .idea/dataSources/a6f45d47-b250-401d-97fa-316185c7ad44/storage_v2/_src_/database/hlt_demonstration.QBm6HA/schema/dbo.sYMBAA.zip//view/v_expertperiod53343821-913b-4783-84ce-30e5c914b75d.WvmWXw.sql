
CREATE view [V_ExpertPeriod53343821-913b-4783-84ce-30e5c914b75d] as select * from [tmp_ExpertPeriod53343821-913b-4783-84ce-30e5c914b75d]
go

