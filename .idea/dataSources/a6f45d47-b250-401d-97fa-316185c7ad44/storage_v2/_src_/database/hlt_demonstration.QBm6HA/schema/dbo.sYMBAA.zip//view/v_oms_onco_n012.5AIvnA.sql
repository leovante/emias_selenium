CREATE VIEW [V_oms_onco_N012] AS SELECT 
[hDED].[onco_N012ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_onco_N010ID] as [rf_onco_N010ID], 
[jT_oms_onco_N010].[Igh_NAME] as [SILENT_rf_onco_N010ID], 
[hDED].[ID_I_D] as [ID_I_D], 
[hDED].[DS_Igh] as [DS_Igh], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN012] as [GUIDN012]
FROM [oms_onco_N012] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_onco_N010] as [jT_oms_onco_N010] on [jT_oms_onco_N010].[onco_N010ID] = [hDED].[rf_onco_N010ID]
go

