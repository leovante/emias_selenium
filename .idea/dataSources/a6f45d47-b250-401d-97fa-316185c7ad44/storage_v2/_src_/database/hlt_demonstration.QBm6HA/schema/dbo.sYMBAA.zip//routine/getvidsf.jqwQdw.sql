
CREATE FUNCTION [dbo].[GetVIDSF](@mhid int)

RETURNS @result TABLE (
ServiceMedicalCode varchar(20),
VID_SF varchar(2)
)
AS
begin
INSERT INTO @result
select ServiceMedicalCode,
	convert(varchar(2),case 
when ro.rf_SMOID=0 and ro.rf_OKATOID=0 then '15'--сводная справка к реестру счетов медицинской помощи, оказанной пациентам, не идентифицированным как застрахованные по ОМС лица
when ro.rf_SMOID=0 and depProf.Code in ('74','79','80','82','85') then '17'--Сводная справка к реестру счетов по сверхбазовой программе ОМС (МТР)
when ro.rf_SMOID=0 then '12'--Счет-фактура "Б"-2009, Сводная справка к Реестру счетов -"иногородние" с 05.2011 
when depProf.Code in ('74','79','80','82','85') then '16'--Сводная справка к реестру счетов по сверхбазовой программе ОМС
else '09'
end) as VID_SF
from stt_ReestrMKSB r
inner join stt_ReestrOccasion ro on r.rf_ReestrOccasionID=ro.ReestrOccasionID
inner join stt_MedServicePatient msp on msp.MedServicePatientID=r.rf_MedServicePatientID
inner join oms_ServiceMedical sm on sm.ServiceMedicalID=msp.rf_ServiceMedicalID
inner join oms_kl_MedCareUnit mcu on mcu.kl_MedCareUnitID=sm.rf_kl_MedCareUnitID
inner join stt_MigrationPatient mp on r.rf_MigrationPatientID=mp.MigrationPatientID
inner join stt_StationarBranch sb on mp.rf_StationarBranchID=sb.StationarBranchID
inner join oms_Department d on d.DepartmentID=sb.rf_DepartmentID
inner join oms_kl_DepartmentProfile depProf on d.rf_kl_DepartmentProfileID=depProf.kl_DepartmentProfileID
--inner join oms_SMO smo on ro.rf_SMOID=smo.SMOID
where r.rf_medicalHistoryID=@mhid
and mcu.Name not like '%хирург%опер%'--чтоб не выгрузить операцию
and r.rf_medicalHistoryID>0
and mp.migrationPatientID!=(select migrationPatientID from v_CurentMigrationPatient where rf_medicalHistoryID=r.rf_medicalHistoryID and rf_StationarBranchID=0) --исключаем последнее движение
and mp.migrationPatientID!=(select top 1 migrationPatientID from stt_migrationPatient where rf_medicalHistoryID=r.rf_medicalHistoryID order by DateIngoing) -- исключаем первое движение

 return end
go

