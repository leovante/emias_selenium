CREATE VIEW [dbo].[V_x_SqlModule] AS SELECT 
[hDED].[SqlModuleID], [hDED].[x_Edition], [hDED].[x_Status], 
((select  [type] from sys.sql_modules left join sys.objects on sys.objects.object_id = sys.sql_modules.object_id 
where name = [hDed].[Name] )) as [V_TypeCode], 
((IsNull(((select 

CASE type 
	WHEN 'V' THEN 'Представление' 
	WHEN 'TR' THEN 'Триггер' 
	WHEN 'P' THEN 'Процедура' 
	WHEN 'PC' THEN 'Процедура' 
	WHEN 'FN' THEN 'Функция' 
	WHEN 'FS' THEN 'Функция' 
	WHEN 'FT' THEN 'Функция' 
	WHEN 'TF' THEN 'Функция' 
	WHEN 'IF' THEN 'Функция' 
	ELSE 'неизвестный' 
end 

from sys.sql_modules
left join sys.objects on sys.objects.object_id = sys.sql_modules.object_id 
where name = [hDed].[Name]
)), 'не найдено'))) as [V_TypeName], 
[jT_x_Theme].[Name] as [V_ThemeName], 
[hDED].[Name] as [Name], 
[hDED].[rf_ThemeGUID] as [rf_ThemeGUID]
FROM [x_SqlModule] as [hDED]
INNER JOIN [x_Theme] as [jT_x_Theme] on [jT_x_Theme].[GUID] = [hDED].[rf_ThemeGUID]
go

