
CREATE PROCEDURE [dbo].[spGetPatientOrders_PLPU] 
	@MKABID int,
	@Date_A datetime,
	@Date_B datetime,
	@mcod varchar(20),
	@result xml output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from

	SET NOCOUNT ON;

	SET DATEFIRST 1

	DECLARE @DBTType INT = 8

declare @tmp_tab TABLE
(
	dttid int,
	dvtid int,
	uguid uniqueidentifier,
	DateTimeCreate datetime,
	StubNum  varchar(50),
	V_Family varchar(50),
	V_Name varchar (50), 
	V_Ot varchar (50),	
	RoomNum varchar (100),
	PRVSName varchar (255),	
	ShortDate varchar(10),
	Time_from varchar(10),
	FlagVisitMaker int,
	mcod varchar(20)
)

insert into @tmp_tab
select  hlt_DoctorTimeTable.DoctorTimeTableID as dttid,
		hlt_DoctorVisitTable.DoctorVisitTableID as dvtid,
		hlt_DoctorVisitTable.UGUID as uguid,
		hlt_DoctorVisitTable.DateTimeCreate,
		hlt_DoctorVisitTable.StubNum,
		Upper(substring(hlt_LPUDoctor.Fam_V, 1, 1)) +
		Lower(substring(hlt_LPUDoctor.Fam_V, 2, Len(hlt_LPUDoctor.Fam_V))) as [V_Family!3],
	    Upper(substring(hlt_LPUDoctor.IM_V, 1, 1)) +
		Lower(substring(hlt_LPUDoctor.IM_V, 2, Len(hlt_LPUDoctor.IM_V))) as V_Name,
	    Upper(substring(hlt_LPUDoctor.OT_V, 1, 1)) +
		Lower(substring(hlt_LPUDoctor.OT_V, 2, Len(hlt_LPUDoctor.OT_V))) as V_OT,
	    isnull(hlt_HealingRoom.Num, 'н/д') as RoomNum,
	    isnull(oms_PRVS.PRVS_NAME, 'н/д') as PRVSName,
	    convert(varchar, hlt_DoctorTimeTable.Date, 104) as Date,
		CASE 
			when DATEPART(hh, hlt_DoctorTimeTable.Begin_Time) <= 9 
			then '0' + Convert(varchar(1), DATEPART(hh, hlt_DoctorTimeTable.Begin_Time))
			else Convert(varchar(2), DATEPART(hh, hlt_DoctorTimeTable.Begin_Time))
		end 
		  + ':' +
		CASE 
			when DATEPART(mi, hlt_DoctorTimeTable.Begin_Time) <= 9 
			then '0' + Convert(varchar(1), DATEPART(mi, hlt_DoctorTimeTable.Begin_Time))
			else Convert(varchar(2), DATEPART(mi, hlt_DoctorTimeTable.Begin_Time))
		end 
		as Time_from,
		CASE 
				WHEN isnull(hlt_DoctorVisitTable.DoctorVisitTableID, 0) = 0 THEN  0
				ELSE hlt_DoctorVisitTable.fromReg * 1 + hlt_DoctorVisitTable.fromDoc * 2 + hlt_DoctorVisitTable.fromInfomat * 4 + hlt_DoctorVisitTable.fromInternet * 8 + hlt_DoctorVisitTable.fromTel * 16
			END as FlagVisitMaker,
		ltrim(rtrim(lpu.mcod)) as mcod

from hlt_DoctorVisitTable 
	inner join hlt_DoctorTimeTable 
		on hlt_DoctorTimeTable.DoctorTimeTableID = hlt_DoctorVisitTable.rf_DoctorTimeTableID
	inner join hlt_DocPrVd
		on hlt_DoctorTimeTable.rf_DocPrVdID = hlt_DocPrVd.DocPrVdID
	inner join oms_department dep 
		on dep.departmentid = hlt_DocPrVd.rf_Departmentid
	inner join oms_lpu lpu 
		on lpu.lpuid = dep.rf_LPUID
	inner join hlt_LPUDoctor
		on hlt_DocPrVd.rf_LPUDoctorID = hlt_LPUDoctor.LPUDoctorID
	left join oms_PRVS
		on hlt_DocPrVd.rf_PRVSID = oms_PRVS.PRVSID
	left join hlt_HealingRoom
		on hlt_DocPrVd.rf_HealingRoomID = hlt_HealingRoom.HealingRoomID
where rf_MKABID = @MkabID and
	DoctorVisitTableID > 0 and
	hlt_DoctorTimeTable.Date between CONVERT(date,@Date_A) and @Date_B and -- отбрасываем время 
	hlt_DoctorTimeTable.Begin_Time > @Date_A and -- добавлено чтобы не отдавать талоны время которых уже прошло
	hlt_DoctorTimeTable.rf_DocBusyType in (select  DocBusyTypeID from hlt_DocBusyType where (TypeBusy != 0) AND (TypeBusy != @DBTType))	
	and hlt_DoctorVisitTable.VisitStatus =  0
	and (@mcod='' or lpu.mcod = @mcod)
order by hlt_DoctorTimeTable.Date,
         hlt_DoctorTimeTable.Begin_Time,
		 oms_PRVS.PRVS_NAME,
		 hlt_LPUDoctor.FAM_V,
		 hlt_LPUDoctor.IM_V	

	set @result =
	(SELECT tt.* FROM 
(
select distinct
		1 as Tag,
		0 as Parent,
		null as [GetPatientOrdersResult!1],
		'true'   as [GetPatientOrdersResult!1!Result],
		0    as [GetPatientOrdersResult!1!Code],
		isnull((select top 1 1 from hlt_CallDoctor where isFinalize = 0 and rf_MKABID = @MkabID and CallDoctorID > 0), 0) as [GetPatientOrdersResult!1!ActiveCallDoc2Home],
		null as [Orders!2],
		0 as [Order!3!DTTID],		
		0 as [Order!3!DVTID],  
		cast(cast(0 as binary) as uniqueidentifier) as [Order!3!UGUID],
		null as [Order!3!V_Family!Element],
		null as [Order!3!V_Name!Element],
		null as [Order!3!V_Ot!Element],
		null as [Order!3!RoomNum!Element],
		null as [Order!3!PRVSName!Element],
		null as [Order!3!ShortDate!Element],
		null as [Order!3!Time_from!Element],	
		null as [Order!3!StubNum!Element],	
		null as [Order!3!FlagVisitMaker],	
		null as [Order!3!DateCreateVisit],	
		null as [Order!3!DateActiveReserv],	
		null as [Order!3!MCOD]
UNION ALL
	select distinct
		2 as Tag,
		1 as Parent,
		null as [GetPatientOrdersResult!1],
		null as [GetPatientOrdersResult!1!Result],
		null as [GetPatientOrdersResult!1!Code],
		null    as [GetPatientOrdersResult!1!ActiveCallDoc2Home],
		null as [Orders!2],
		0 as [Order!3!DTTID],
		0 as [Order!3!DVTID],
		cast(cast(0 as binary) as uniqueidentifier) as [Order!3!UGUID],
		null as [Order!3!V_Family!Element],
		null as [Order!3!V_Name!Element],
		null as [Order!3!V_Ot!Element],
		null as [Order!3!RoomNum!Element],
		null as [Order!3!PRVSName!Element],
		null as [Order!3!ShortDate!Element],
		null as [Order!3!Time_from!Element],	
		null as [Order!3!StubNum!Element],	
		null as [Order!3!FlagVisitMaker],	
		null as [Order!3!DateCreateVisit],
		null as [Order!3!DateActiveReserv],	
		null as [Order!3!MCOD]

	from @tmp_tab
UNION ALL
	select distinct
		3 as Tag,
		2 as Parent,
		null		as [GetPatientOrdersResult!1],
		null		as [GetPatientOrdersResult!1!Result],
		null		as [GetPatientOrdersResult!1!Code],
		null		as [GetPatientOrdersResult!1!ActiveCallDoc2Home],
		null		as [Orders!2],
		dttid		as [Order!3!DTTID],
		dvtid		as [Order!3!DVT],
		uguid		as [Order!3!UGUID],
		V_Family	as [Order!3!V_Family!Element],
		V_Name		as [Order!3!V_Name!Element],
		V_Ot		as [Order!3!V_Ot!Element],
		RoomNum		as [Order!3!RoomNum!Element],
		PRVSName	as [Order!3!PRVSName!Element],
		ShortDate	as [Order!3!ShortDate!Element],
		Time_from	as [Order!3!Time_from!Element],	
		StubNum		as [Order!3!StubNum!Element],	
		FlagVisitMaker as [Order!3!FlagVisitMaker],	
		--isnull((select top 1 convert(varchar(19), x_DateTime, 126) from life_hlt_doctorVisitTable where doctorVisitTableID = dvtid and x_Operation='i'), 'н/д') as [Order!3!DateCreateVisit],
		case when year(DateTimeCreate) != '1900' then DateTimeCreate else isnull((select top 1 convert(varchar(19), x_DateTime, 126) from life_hlt_doctorVisitTable where doctorVisitTableID = dvtid and x_Operation='i'), 'н/д') end  as [Order!3!DateCreateVisit],
		--isnull((select top 1 convert(varchar(19), [TicketLiveTime], 126) from hlt_WaitingList where rf_doctorVisitTableID = dvtid ), '') as [Order!3!DateActiveReserv],	
		'' as [Order!3!DateActiveReserv],	
		mcod as [Order!3!MCOD]
	from @tmp_tab
) tt
ORDER BY 
convert(datetime, isnull([Order!3!ShortDate!Element], '2222-01-01T00:00:00'), 104) desc,
isnull([Order!3!Time_from!Element], '2222-01-01T00:00:00') desc,
[Order!3!DTTID]
FOR XML EXPLICIT, TYPE
)

END
go

