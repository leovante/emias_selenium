CREATE VIEW [V_ehr_View] AS SELECT 
[hDED].[ViewID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TemplateID] as [rf_TemplateID], 
[hDED].[rf_ViewTypeID] as [rf_ViewTypeID], 
[hDED].[FormView] as [FormView]
FROM [ehr_View] as [hDED]
go

