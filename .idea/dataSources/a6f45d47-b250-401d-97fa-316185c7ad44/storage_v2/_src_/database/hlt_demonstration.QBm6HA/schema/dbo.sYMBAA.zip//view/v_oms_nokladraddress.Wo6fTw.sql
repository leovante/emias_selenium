CREATE VIEW [V_oms_NoKladrAddress] AS SELECT 
[hDED].[NoKladrAddressID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OKSMID] as [rf_OKSMID], 
[jT_oms_OKSM].[NameSM] as [SILENT_rf_OKSMID], 
[hDED].[Area] as [Area], 
[hDED].[Region] as [Region], 
[hDED].[City] as [City], 
[hDED].[Street] as [Street], 
[hDED].[House] as [House], 
[hDED].[Apartment] as [Apartment], 
[hDED].[AddressString] as [AddressString], 
[hDED].[Flags] as [Flags], 
[hDED].[NoKladrAddressGUID] as [NoKladrAddressGUID]
FROM [oms_NoKladrAddress] as [hDED]
INNER JOIN [oms_OKSM] as [jT_oms_OKSM] on [jT_oms_OKSM].[OKSMID] = [hDED].[rf_OKSMID]
go

