
CREATE view [V_ExpertPeriodb426678f-d9cd-401c-ba6a-5d831536570f] as select * from [tmp_ExpertPeriodb426678f-d9cd-401c-ba6a-5d831536570f]
go

