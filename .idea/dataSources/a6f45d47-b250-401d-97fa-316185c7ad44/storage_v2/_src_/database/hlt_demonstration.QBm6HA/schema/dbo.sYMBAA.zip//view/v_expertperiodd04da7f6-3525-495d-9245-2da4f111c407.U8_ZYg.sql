
CREATE view [V_ExpertPeriodd04da7f6-3525-495d-9245-2da4f111c407] as select * from [tmp_ExpertPeriodd04da7f6-3525-495d-9245-2da4f111c407]
go

