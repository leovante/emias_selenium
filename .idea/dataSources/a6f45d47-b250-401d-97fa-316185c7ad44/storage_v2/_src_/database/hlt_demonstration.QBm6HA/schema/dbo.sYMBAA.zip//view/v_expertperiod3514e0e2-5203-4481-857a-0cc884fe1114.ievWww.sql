
CREATE view [V_ExpertPeriod3514e0e2-5203-4481-857a-0cc884fe1114] as select * from [tmp_ExpertPeriod3514e0e2-5203-4481-857a-0cc884fe1114]
go

