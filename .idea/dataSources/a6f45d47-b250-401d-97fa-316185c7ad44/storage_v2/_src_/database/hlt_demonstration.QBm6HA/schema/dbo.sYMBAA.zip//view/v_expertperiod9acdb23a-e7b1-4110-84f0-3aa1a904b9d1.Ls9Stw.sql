
CREATE view [V_ExpertPeriod9acdb23a-e7b1-4110-84f0-3aa1a904b9d1] as select * from [tmp_ExpertPeriod9acdb23a-e7b1-4110-84f0-3aa1a904b9d1]
go

