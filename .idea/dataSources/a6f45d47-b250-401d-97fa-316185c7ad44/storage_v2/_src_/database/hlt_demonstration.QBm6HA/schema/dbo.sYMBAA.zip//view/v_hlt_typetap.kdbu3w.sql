CREATE VIEW [V_hlt_TypeTAP] AS SELECT 
[hDED].[TypeTAPID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [hlt_TypeTAP] as [hDED]
go

