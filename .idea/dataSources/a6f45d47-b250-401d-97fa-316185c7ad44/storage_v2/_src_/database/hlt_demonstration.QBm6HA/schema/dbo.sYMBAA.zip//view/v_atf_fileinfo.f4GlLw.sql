CREATE VIEW [V_atf_FileInfo] AS SELECT 
[hDED].[FileInfoID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FileTypeID] as [rf_FileTypeID], 
[jT_atf_FileType].[Name] as [SILENT_rf_FileTypeID], 
[hDED].[DateDoc] as [DateDoc], 
[hDED].[rf_DoctorTypeGuid] as [rf_DoctorTypeGuid], 
[hDED].[rf_DoctorGuid] as [rf_DoctorGuid], 
[hDED].[DoctorName] as [DoctorName], 
[hDED].[rf_LPUTypeGuid] as [rf_LPUTypeGuid], 
[hDED].[rf_LPUGuid] as [rf_LPUGuid], 
[hDED].[LPUName] as [LPUName], 
[hDED].[rf_DescTypeGuid] as [rf_DescTypeGuid], 
[hDED].[DescGuid] as [DescGuid], 
[hDED].[Description] as [Description], 
[hDED].[Guid] as [Guid], 
[hDED].[Flags] as [Flags]
FROM [atf_FileInfo] as [hDED]
INNER JOIN [atf_FileType] as [jT_atf_FileType] on [jT_atf_FileType].[FileTypeID] = [hDED].[rf_FileTypeID]
go

