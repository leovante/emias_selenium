CREATE VIEW [V_hlt_NotWorkDocAddReason] AS SELECT 
[hDED].[NotWorkDocAddReasonID], [hDED].[x_Edition], [hDED].[x_Status], 
(CODE + ' - ' + NAME) as [v_CN], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME]
FROM [hlt_NotWorkDocAddReason] as [hDED]
go

