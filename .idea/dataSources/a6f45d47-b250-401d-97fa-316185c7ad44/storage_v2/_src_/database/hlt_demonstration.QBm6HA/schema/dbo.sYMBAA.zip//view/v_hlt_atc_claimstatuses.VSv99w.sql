CREATE VIEW [V_hlt_atc_ClaimStatuses] AS SELECT 
[hDED].[atc_ClaimStatusesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_atc_StatusID] as [rf_atc_StatusID], 
[jT_hlt_atc_Status].[Name] as [SILENT_rf_atc_StatusID], 
[hDED].[rf_atc_ClaimID] as [rf_atc_ClaimID], 
[hDED].[DateStatus] as [DateStatus], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[UserName] as [UserName], 
[hDED].[Comment] as [Comment], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_atc_ClaimStatuses] as [hDED]
INNER JOIN [hlt_atc_Status] as [jT_hlt_atc_Status] on [jT_hlt_atc_Status].[atc_StatusID] = [hDED].[rf_atc_StatusID]
go

