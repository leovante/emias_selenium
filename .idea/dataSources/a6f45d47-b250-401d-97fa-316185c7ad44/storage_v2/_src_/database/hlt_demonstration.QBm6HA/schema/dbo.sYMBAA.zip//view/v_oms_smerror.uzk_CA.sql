CREATE VIEW [V_oms_SMError] AS SELECT 
[hDED].[SMErrorID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_SMExpert].[V_SMExpert] as [V_V_SMExpert], 
[hDED].[rf_SMReestrID] as [rf_SMReestrID], 
[jT_oms_SMReestr].[V_SMReestr] as [SILENT_rf_SMReestrID], 
[hDED].[rf_SMReestrPatientID] as [rf_SMReestrPatientID], 
[jT_oms_SMReestrPatient].[V_FIO] as [SILENT_rf_SMReestrPatientID], 
[hDED].[rf_SMExpertID] as [rf_SMExpertID], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[jT_oms_SMCriterion].[SMCriterionCaption] as [SILENT_rf_SMCriterionID], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[jT_oms_SMReestrSluch].[IDCase] as [SILENT_rf_SMReestrSluchID], 
[hDED].[rf_SMreestrUslID] as [rf_SMreestrUslID], 
[jT_oms_SMreestrUsl].[rf_SMReestrSluchID] as [SILENT_rf_SMreestrUslID], 
[hDED].[rf_SMExpertTypeID] as [rf_SMExpertTypeID], 
[jT_oms_SMExpertType].[Name] as [SILENT_rf_SMExpertTypeID], 
[hDED].[rf_SMFieldConditionID] as [rf_SMFieldConditionID], 
[hDED].[rf_MTReestrID] as [rf_MTReestrID], 
[hDED].[rf_SMReestrZ_SLID] as [rf_SMReestrZ_SLID], 
[hDED].[Rem] as [Rem], 
[hDED].[S_CODE] as [S_CODE], 
[hDED].[S_SUM] as [S_SUM], 
[hDED].[S_TIP] as [S_TIP], 
[hDED].[S_IST] as [S_IST], 
[hDED].[num_zap] as [num_zap], 
[hDED].[VIDEXP] as [VIDEXP], 
[hDED].[S_COM] as [S_COM], 
[hDED].[S_OSN] as [S_OSN], 
[hDED].[SankGuid] as [SankGuid]
FROM [oms_SMError] as [hDED]
INNER JOIN [V_oms_SMExpert] as [jT_oms_SMExpert] on [jT_oms_SMExpert].[SMExpertID] = [hDED].[rf_SMExpertID]
INNER JOIN [V_oms_SMReestr] as [jT_oms_SMReestr] on [jT_oms_SMReestr].[SMReestrID] = [hDED].[rf_SMReestrID]
INNER JOIN [V_oms_SMReestrPatient] as [jT_oms_SMReestrPatient] on [jT_oms_SMReestrPatient].[SMReestrPatientID] = [hDED].[rf_SMReestrPatientID]
INNER JOIN [oms_SMCriterion] as [jT_oms_SMCriterion] on [jT_oms_SMCriterion].[SMCriterionID] = [hDED].[rf_SMCriterionID]
INNER JOIN [oms_SMReestrSluch] as [jT_oms_SMReestrSluch] on [jT_oms_SMReestrSluch].[SMReestrSluchID] = [hDED].[rf_SMReestrSluchID]
INNER JOIN [oms_SMreestrUsl] as [jT_oms_SMreestrUsl] on [jT_oms_SMreestrUsl].[SMreestrUslID] = [hDED].[rf_SMreestrUslID]
INNER JOIN [oms_SMExpertType] as [jT_oms_SMExpertType] on [jT_oms_SMExpertType].[SMExpertTypeID] = [hDED].[rf_SMExpertTypeID]
go

