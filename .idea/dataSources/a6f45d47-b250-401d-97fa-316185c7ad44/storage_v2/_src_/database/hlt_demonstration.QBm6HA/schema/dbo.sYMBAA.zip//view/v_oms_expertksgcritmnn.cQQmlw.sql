CREATE VIEW [V_oms_ExpertKSGCritMNN] AS SELECT 
[hDED].[ExpertKSGCritMNNID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MNNameID] as [rf_MNNameID], 
[jT_oms_MNName].[NAME_MNN] as [SILENT_rf_MNNameID], 
[hDED].[rf_ExpertKSGCriterionID] as [rf_ExpertKSGCriterionID], 
[hDED].[Flags] as [Flags], 
[hDED].[ExpertKSGCritMNNGUID] as [ExpertKSGCritMNNGUID]
FROM [oms_ExpertKSGCritMNN] as [hDED]
INNER JOIN [oms_MNName] as [jT_oms_MNName] on [jT_oms_MNName].[MNNameID] = [hDED].[rf_MNNameID]
go

