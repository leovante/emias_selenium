CREATE VIEW [V_oms_SMNorm] AS SELECT 
[hDED].[SMNormID], [hDED].[x_Edition], [hDED].[x_Status], 
((select Name from oms_kl_MedCareUnit where kl_MedCareUnitId =jT_oms_ServiceMedical.rf_kl_MedCareUnitId  )) as [V_UnitName], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_kl_CategoryID] as [rf_kl_CategoryID], 
[jT_oms_kl_Category].[Code] as [SILENT_rf_kl_CategoryID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[flag] as [flag], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[NORM] as [NORM], 
[hDED].[Delta] as [Delta], 
[hDED].[SMNormGuid] as [SMNormGuid], 
[hDED].[Nmin] as [Nmin], 
[hDED].[Nmax] as [Nmax]
FROM [oms_SMNorm] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [oms_kl_Category] as [jT_oms_kl_Category] on [jT_oms_kl_Category].[kl_CategoryID] = [hDED].[rf_kl_CategoryID]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
go

