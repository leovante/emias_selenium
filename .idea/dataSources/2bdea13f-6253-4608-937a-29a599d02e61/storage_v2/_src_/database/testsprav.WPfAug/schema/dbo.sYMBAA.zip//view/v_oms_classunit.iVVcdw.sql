CREATE VIEW [V_oms_ClassUnit] AS SELECT 
[hDED].[ClassUnitID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClassUnitGroupID] as [rf_ClassUnitGroupID], 
[hDED].[rf_ClassUnitTypeID] as [rf_ClassUnitTypeID], 
[hDED].[Name] as [Name], 
[hDED].[number_code] as [number_code], 
[hDED].[eng_name1] as [eng_name1], 
[hDED].[eng_name2] as [eng_name2], 
[hDED].[rus_name1] as [rus_name1], 
[hDED].[rus_name2] as [rus_name2]
FROM [oms_ClassUnit] as [hDED]
go

