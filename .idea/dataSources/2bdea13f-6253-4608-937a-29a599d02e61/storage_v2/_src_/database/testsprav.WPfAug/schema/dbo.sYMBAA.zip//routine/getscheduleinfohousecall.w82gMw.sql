
CREATE FUNCTION [dbo].[GetScheduleInfoHousecall]
(	
	@Session_ID varchar(50), 
	@Resource_Id varchar(100),
	@StartDateRange varchar(50),
	@EndDateRange varchar(50)


)
RETURNS TABLE 
AS
RETURN 
(

select @Session_ID as Session_ID,DTT.DoctorTimeTableID as Slot_Id,DTT.Begin_Time as VisitTime, DATEDIFF(minute, DTT.Begin_Time, DTT.end_Time) as Duration, 0 as Error
from hlt_DoctorTimeTable DTT 
where rf_DocPRVDID=@Resource_Id
and (convert(date,DTT.[Date],105) between convert(date,cast(@StartDateRange as varchar(10)),105) and convert(date,cast(@EndDateRange as varchar(10)),105)
)
and DTT.Begin_Time>=getdate()
and (dtt.FlagAccess & 4) > 0
and dtt.DoctorTimeTableID not in (select rf_DoctorTimeTableID from hlt_DoctorVisitTable where rf_DoctorTimeTableID=DTT.DoctorTimeTableID)                      
and dtt.Begin_Time <> '1900-01-01T00:00:00'
and (dtt.rf_DocPRVDID <> 0)



)
go

