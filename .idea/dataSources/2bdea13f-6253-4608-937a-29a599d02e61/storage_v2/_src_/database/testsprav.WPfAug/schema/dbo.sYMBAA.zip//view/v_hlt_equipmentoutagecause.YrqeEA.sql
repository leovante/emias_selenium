CREATE VIEW [V_hlt_EquipmentOutageCause] AS SELECT 
[hDED].[EquipmentOutageCauseID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Description] as [Description], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_EquipmentOutageCause] as [hDED]
go

