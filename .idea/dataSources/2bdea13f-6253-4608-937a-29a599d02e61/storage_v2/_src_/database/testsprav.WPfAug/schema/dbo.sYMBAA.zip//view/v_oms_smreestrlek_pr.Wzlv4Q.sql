CREATE VIEW [V_oms_SMReestrLEK_PR] AS SELECT 
[hDED].[SMReestrLEK_PRID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[rf_SMReestrONK_SLID] as [rf_SMReestrONK_SLID], 
[hDED].[rf_SMReestrONK_USLID] as [rf_SMReestrONK_USLID], 
[hDED].[REGNUM] as [REGNUM]
FROM [oms_SMReestrLEK_PR] as [hDED]
go

