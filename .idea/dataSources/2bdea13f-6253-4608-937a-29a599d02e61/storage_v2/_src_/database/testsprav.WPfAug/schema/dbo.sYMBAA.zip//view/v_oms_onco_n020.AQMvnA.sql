CREATE VIEW [V_oms_onco_N020] AS SELECT 
[hDED].[onco_N020ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ID_LEKP] as [ID_LEKP], 
[hDED].[MNN] as [MNN], 
[hDED].[DateBeg] as [DateBeg], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[GuidN020] as [GuidN020]
FROM [oms_onco_N020] as [hDED]
go

