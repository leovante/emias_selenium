CREATE VIEW [V_oms_PR_LR] AS SELECT 
[hDED].[PR_LRID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[PR_LR_VALUE] as [PR_LR_VALUE], 
[hDED].[Rate] as [Rate]
FROM [oms_PR_LR] as [hDED]
go

