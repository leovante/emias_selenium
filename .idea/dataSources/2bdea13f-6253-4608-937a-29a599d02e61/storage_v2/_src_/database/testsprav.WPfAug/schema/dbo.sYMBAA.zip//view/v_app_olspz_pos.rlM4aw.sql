CREATE VIEW [V_App_OLSPZ_POS] AS SELECT 
[hDED].[OLSPZ_POSID], [hDED].[x_Edition], [hDED].[x_Status], 
ISNULL ((SELECT TOP (1) PR_REG FROM dbo.oms_CLS AS m WHERE (rf_LSID = hDED.rf_LSID) ORDER BY DATE_BP DESC), 0.0) as [V_Price], 
ISNULL ((SELECT TOP (1) PR_REG FROM dbo.oms_CLS AS m WHERE (rf_LSID = hDED.rf_LSID) ORDER BY DATE_BP DESC), 0.0) * hDED.OrdCnt as [V_Sum], 
isnull( (select top 1 ([Family] + ' ' + [Name] + ' '+  [Patronymic]) from oms_Person m where m.SS = hDED.SS) , '') as [V_PatFIO], 
[jT_oms_LS].[NAME_MED] as [NAME_MED], 
[jT_oms_LS].[NOMK_LS] as [NOMK_LS], 
[hDED].[rf_LSID] as [rf_LSID], 
[jT_oms_LS].[NAME_MED] as [SILENT_rf_LSID], 
[hDED].[rf_FINLID] as [rf_FINLID], 
[jT_oms_Finl].[NAME] as [SILENT_rf_FINLID], 
[hDED].[rf_OLSPZID] as [rf_OLSPZID], 
[hDED].[rf_CrusialPZID] as [rf_CrusialPZID], 
[jT_App_CrusialPZ].[LPUDoctorFIO] as [SILENT_rf_CrusialPZID], 
[hDED].[SS] as [SS], 
[hDED].[OrdCnt] as [OrdCnt], 
[hDED].[BK] as [BK], 
[hDED].[Flags] as [Flags], 
[hDED].[MaxCnt] as [MaxCnt]
FROM [App_OLSPZ_POS] as [hDED]
INNER JOIN [oms_LS] as [jT_oms_LS] on [jT_oms_LS].[LSID] = [hDED].[rf_LSID]
INNER JOIN [oms_Finl] as [jT_oms_Finl] on [jT_oms_Finl].[FinlID] = [hDED].[rf_FINLID]
INNER JOIN [App_CrusialPZ] as [jT_App_CrusialPZ] on [jT_App_CrusialPZ].[CrusialPZID] = [hDED].[rf_CrusialPZID]
go

