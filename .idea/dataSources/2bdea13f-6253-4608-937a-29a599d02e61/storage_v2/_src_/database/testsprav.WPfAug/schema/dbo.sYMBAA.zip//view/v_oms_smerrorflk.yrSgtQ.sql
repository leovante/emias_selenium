CREATE VIEW [V_oms_SMErrorFLK] AS SELECT 
[hDED].[SMErrorFLKID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrID] as [rf_SMReestrID], 
[jT_oms_SMReestr].[V_SMReestr] as [SILENT_rf_SMReestrID], 
[hDED].[rf_SMFieldConditionID] as [rf_SMFieldConditionID], 
[jT_oms_SMFieldCondition].[MainField] as [SILENT_rf_SMFieldConditionID], 
[hDED].[FNAME_I] as [FNAME_I], 
[hDED].[N_ZAP] as [N_ZAP], 
[hDED].[IDCASE] as [IDCASE], 
[hDED].[SL_ID] as [SL_ID], 
[hDED].[IDSERV] as [IDSERV], 
[hDED].[Rem] as [Rem]
FROM [oms_SMErrorFLK] as [hDED]
INNER JOIN [V_oms_SMReestr] as [jT_oms_SMReestr] on [jT_oms_SMReestr].[SMReestrID] = [hDED].[rf_SMReestrID]
INNER JOIN [oms_SMFieldCondition] as [jT_oms_SMFieldCondition] on [jT_oms_SMFieldCondition].[SMFieldConditionID] = [hDED].[rf_SMFieldConditionID]
go

