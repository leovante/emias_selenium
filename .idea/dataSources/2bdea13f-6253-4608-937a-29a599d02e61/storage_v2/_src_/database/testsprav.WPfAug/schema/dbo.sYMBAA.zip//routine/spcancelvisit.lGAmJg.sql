create PROCEDURE [dbo].[spCancelVisit]
	@dvtid int,
	@mkabid int,
	@result int output
AS
BEGIN
begin tran

-- Есть ли такая запись?
if not exists
(
	select * from hlt_DoctorVisitTable
	where DoctorVisitTableID = @dvtid
		and rf_MKABID = @mkabid
)
begin
	rollback tran
	set @result = -21	
	return
end

/* Удаляем запись */
delete from hlt_DoctorVisitTable where DoctorVisitTableID = @dvtid

commit tran
set @result = 0

END
go

