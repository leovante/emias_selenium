CREATE VIEW [V_oms_Egisz_TypeDoc] AS SELECT 
[hDED].[Egisz_TypeDocID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Uid] as [Uid], 
[hDED].[Name] as [Name]
FROM [oms_Egisz_TypeDoc] as [hDED]
go

