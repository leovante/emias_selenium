CREATE VIEW [V_stt_ActiveMS] AS SELECT 
[hDED].[ActiveMSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ServiceMedicalID] as [ServiceMedicalID]
FROM [stt_ActiveMS] as [hDED]
go

