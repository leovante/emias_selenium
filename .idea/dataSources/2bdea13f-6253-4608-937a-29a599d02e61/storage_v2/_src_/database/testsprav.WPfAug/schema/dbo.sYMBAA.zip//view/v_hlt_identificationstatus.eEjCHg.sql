CREATE VIEW [V_hlt_IdentificationStatus] AS SELECT 
[hDED].[IdentificationStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Description] as [Description], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Guid] as [Guid], 
[hDED].[Flags] as [Flags]
FROM [hlt_IdentificationStatus] as [hDED]
go

