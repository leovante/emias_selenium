CREATE VIEW [V_vcn_MkbToVaccinationGroup] AS SELECT 
[hDED].[MkbToVaccinationGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_VaccinationGroupID] as [rf_VaccinationGroupID], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [vcn_MkbToVaccinationGroup] as [hDED]
go

