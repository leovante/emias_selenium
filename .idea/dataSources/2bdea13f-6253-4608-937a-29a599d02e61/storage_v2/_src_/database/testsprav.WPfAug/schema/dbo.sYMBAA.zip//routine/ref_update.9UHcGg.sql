
-- =============================================
-- Author:		Игорь Сидоров, Татьяна Абаньшина
-- Create date: 22.05.2013
-- Description:	Заменяет ссылки с одного значения на другое по заданному имени поля и тематики
-- =============================================
create PROCEDURE [dbo].[Ref_update](@themeName varchar(100), @fieldLike varchar(100), @old int,@new int)
AS
BEGIN

DECLARE @SQL nvarchar(max)
declare _cursor cursor
	for 
			select 	' update '+d.HeadTable+ ' set ' +e.Name +'= ' +convert(varchar(10),@new) +' where '+e.Name+' = '+convert(varchar(10),@old)  from x_DocElemDef e
		
			inner join x_DocTypeDef d on d.DocTypeDefID = e.DocTypeDefID
			inner join x_theme on x_Theme.ThemeId= d.ThemeID 
			where e.Name  like @fieldLike and x_Theme.Name=@themeName
			
open _cursor
	fetch next from _cursor into @SQL
	while (@@fetch_status <> -1)
	begin				
		
	
		EXECUTE sp_executesql @SQL

		fetch next from _cursor into @SQL
	end
	close _cursor
		
	deallocate _cursor				
	
END
go

