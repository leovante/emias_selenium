CREATE VIEW [V_App_CrusialSZ] AS SELECT 
[hDED].[CrusialSZID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OLSSZID] as [rf_OLSSZID], 
[hDED].[_LPUDoctorID] as [_LPUDoctorID], 
[hDED].[_UchastokID] as [_UchastokID], 
[hDED].[FCompl] as [FCompl], 
[hDED].[LPUDoctorFIO] as [LPUDoctorFIO], 
[hDED].[Uchastok] as [Uchastok]
FROM [App_CrusialSZ] as [hDED]
go

