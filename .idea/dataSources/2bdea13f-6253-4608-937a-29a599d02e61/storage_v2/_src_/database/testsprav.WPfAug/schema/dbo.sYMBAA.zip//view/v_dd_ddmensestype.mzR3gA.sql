CREATE VIEW [V_dd_DDMensesType] AS SELECT 
[hDED].[DDMensesTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDMensesType] as [hDED]
go

