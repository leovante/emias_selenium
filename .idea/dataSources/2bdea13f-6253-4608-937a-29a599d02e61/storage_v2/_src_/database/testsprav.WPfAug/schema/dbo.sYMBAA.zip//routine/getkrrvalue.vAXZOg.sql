
CREATE FUNCTION [dbo].[GetKRRValue](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int,
@prerv varchar(max) 
)
RETURNS  [decimal](38, 6) 

AS

begin

declare @k decimal(18,6)
set @k=1


select @k=@k*round(value,5)
from [dbo].[GetKRR](@date, @lpuid,@profileId,@typeid,@usl1 ,@usl2,@mkb ,@age,@dlit, @prerv)
return round(@k,5)
end
go

