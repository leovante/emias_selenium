
CREATE FUNCTION [dbo].[GetKRRValueКпс](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int,
@prerv varchar(max) 
)
RETURNS  [decimal](38, 6) 

AS

begin


return 1
end
go

