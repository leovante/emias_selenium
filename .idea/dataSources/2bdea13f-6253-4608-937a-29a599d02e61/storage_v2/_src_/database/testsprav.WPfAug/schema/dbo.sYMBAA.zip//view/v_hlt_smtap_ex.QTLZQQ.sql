CREATE VIEW [V_hlt_SMTAP_Ex] AS SELECT 
[hDED].[SMTAP_ExID], [hDED].[x_Edition], [hDED].[x_Status], 
(((SELECT '[' + ltrim(rtrim(PCOD)) + '] '+ Upper(substring(ltrim(FAM_V), 1, 1))+ 
CASE WHEN LEN(FAM_V) > 0  THEN LOWER(SUBSTRING(LTRIM(RTRIM(FAM_V)), 2, LEN(LTRIM(RTRIM(FAM_V))) - 1))  
ELSE '' END + ' '  + Upper(substring(ltrim(IM_V), 1, 1)) + '. ' + Upper(substring(ltrim(OT_V), 1, 1)) + '.' FROM hlt_LPUDoctor where hlt_LPUDoctor.LPUDoctorID = [jT_hlt_DocPRVD].rf_LPUDoctorID))) as [V_DocInfo], 
[hDED].[rf_SMTAPID] as [rf_SMTAPID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[ParticipationRatio] as [ParticipationRatio]
FROM [hlt_SMTAP_Ex] as [hDED]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
go

