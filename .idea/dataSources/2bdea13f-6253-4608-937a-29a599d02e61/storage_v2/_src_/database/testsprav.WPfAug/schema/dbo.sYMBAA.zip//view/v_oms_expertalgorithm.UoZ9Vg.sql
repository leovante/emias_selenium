CREATE VIEW [V_oms_ExpertAlgorithm] AS SELECT 
[hDED].[ExpertAlgorithmID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Caption] as [Caption], 
[hDED].[Source] as [Source], 
[hDED].[AlgType] as [AlgType], 
[hDED].[Description] as [Description]
FROM [oms_ExpertAlgorithm] as [hDED]
go

