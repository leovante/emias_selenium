CREATE VIEW [V_hlt_EquipmentServiceContract] AS SELECT 
[hDED].[EquipmentServiceContractID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_EquipmentID] as [rf_EquipmentID], 
[jT_hlt_Equipment].[Name] as [SILENT_rf_EquipmentID], 
[hDED].[Date] as [Date], 
[hDED].[OrgName] as [OrgName], 
[hDED].[Guid] as [Guid], 
[hDED].[Number] as [Number], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[OrgInn] as [OrgInn], 
[hDED].[OrgOgrn] as [OrgOgrn], 
[hDED].[Fio] as [Fio], 
[hDED].[Phone] as [Phone], 
[hDED].[Flags] as [Flags], 
[hDED].[Rem] as [Rem]
FROM [hlt_EquipmentServiceContract] as [hDED]
INNER JOIN [hlt_Equipment] as [jT_hlt_Equipment] on [jT_hlt_Equipment].[EquipmentID] = [hDED].[rf_EquipmentID]
go

