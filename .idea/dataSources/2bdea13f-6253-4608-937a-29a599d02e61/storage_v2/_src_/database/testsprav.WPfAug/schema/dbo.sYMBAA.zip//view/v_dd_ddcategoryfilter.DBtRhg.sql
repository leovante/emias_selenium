CREATE VIEW [V_dd_DDCategoryFilter] AS SELECT 
[hDED].[DDCategoryFilterID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CategoryCode] as [CategoryCode], 
[hDED].[CategoryFilter] as [CategoryFilter], 
[hDED].[CategoryName] as [CategoryName], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDCategoryFilter] as [hDED]
go

