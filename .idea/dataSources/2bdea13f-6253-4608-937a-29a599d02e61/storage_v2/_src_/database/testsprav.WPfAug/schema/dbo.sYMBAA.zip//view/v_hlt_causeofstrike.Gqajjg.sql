CREATE VIEW [V_hlt_CauseOfStrike] AS SELECT 
[hDED].[CauseOfStrikeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [hlt_CauseOfStrike] as [hDED]
go

