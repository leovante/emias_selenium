CREATE VIEW [V_hlt_ReasonCloseMKAB] AS SELECT 
[hDED].[ReasonCloseMKABID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Reason] as [Reason], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [hlt_ReasonCloseMKAB] as [hDED]
go

