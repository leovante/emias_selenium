
CREATE PROCEDURE [dbo].[DeleteDataSets]
@ItemID [uniqueidentifier]
AS
DELETE
FROM [DataSets]
WHERE [ItemID] = @ItemID
DELETE
FROM [ReportServer$SQLEXPRESS2008TempDB].dbo.TempDataSets
WHERE [ItemID] = @ItemID
go

