
CREATE PROCEDURE [dbo].[ReadLockSnapshot]
@SnapshotDataID as uniqueidentifier
AS
SELECT SnapshotDataID
FROM
   SnapshotData WITH (REPEATABLEREAD, ROWLOCK)
WHERE
   SnapshotDataID = @SnapshotDataID
go

