
CREATE PROCEDURE [dbo].[DeletePersistedStreams]
@SessionID varchar(32)
AS
SET NOCOUNT OFF
delete 
    [ReportServer$SQLEXPRESS2008TempDB].dbo.PersistedStream
from 
    (select top 1 * from [ReportServer$SQLEXPRESS2008TempDB].dbo.PersistedStream PS2 where PS2.SessionID = @SessionID) as e1
where 
    e1.SessionID = [ReportServer$SQLEXPRESS2008TempDB].dbo.PersistedStream.[SessionID] and
    e1.[Index] = [ReportServer$SQLEXPRESS2008TempDB].dbo.PersistedStream.[Index]
go

