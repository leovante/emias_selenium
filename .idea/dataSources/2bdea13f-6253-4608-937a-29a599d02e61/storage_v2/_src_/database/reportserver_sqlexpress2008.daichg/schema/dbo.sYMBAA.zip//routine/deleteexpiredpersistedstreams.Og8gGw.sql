
CREATE PROCEDURE [dbo].[DeleteExpiredPersistedStreams]
AS
SET NOCOUNT OFF
SET DEADLOCK_PRIORITY LOW
DELETE
    [ReportServer$SQLEXPRESS2008TempDB].dbo.PersistedStream
FROM 
    (SELECT TOP 1 * FROM [ReportServer$SQLEXPRESS2008TempDB].dbo.PersistedStream PS2 WHERE PS2.RefCount = 0 AND GETDATE() > PS2.ExpirationDate) AS e1
WHERE 
    e1.SessionID = [ReportServer$SQLEXPRESS2008TempDB].dbo.PersistedStream.[SessionID] AND
    e1.[Index] = [ReportServer$SQLEXPRESS2008TempDB].dbo.PersistedStream.[Index]
go

