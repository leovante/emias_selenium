CREATE view [V_x_DocTypeDef] as select [DocTypeDefID], [x_DocTypeDef].[x_Edition], [x_DocTypeDef].[x_Status], [x_Theme].[Name] as [ThemeNameVSV],
[x_DocTypeDef].[Name],[MnemCode],[Caption],[Description],[HeadTable],[PK_Name],[TagName],[ToString],[x_DocTypeDef].[ThemeID],[x_DocTypeDef].[GUID],[Type],[Flags] 
from [x_DocTypeDef] inner join [x_Theme] on [x_DocTypeDef].[ThemeID] = [x_Theme].[ThemeID]
go

