CREATE VIEW [V_hlt_atc_ClaimKind] AS SELECT 
[hDED].[atc_ClaimKindID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[SourceClaim] as [SourceClaim]
FROM [hlt_atc_ClaimKind] as [hDED]
go

