CREATE VIEW [V_ehr_Template] AS SELECT 
[hDED].[TemplateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TemplateID] as [rf_TemplateID], 
[hDED].[Guid] as [Guid], 
[hDED].[Name] as [Name], 
[hDED].[Number] as [Number], 
[hDED].[IsVisible] as [IsVisible], 
[hDED].[IsGroup] as [IsGroup], 
[hDED].[IsComplex] as [IsComplex], 
[hDED].[rf_RecordTypeGuid] as [rf_RecordTypeGuid], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[UpdateDate] as [UpdateDate], 
[hDED].[Author] as [Author], 
[hDED].[InputData] as [InputData]
FROM [ehr_Template] as [hDED]
go

