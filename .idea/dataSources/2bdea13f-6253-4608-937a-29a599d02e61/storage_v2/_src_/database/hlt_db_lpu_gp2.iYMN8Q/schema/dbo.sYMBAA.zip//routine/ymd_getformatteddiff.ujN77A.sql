
CREATE FUNCTION [dbo].[ymd_GetFormattedDiff](@BIRTH_DATE datetime,@DATE datetime)
RETURNS varchar(15)
WITH EXECUTE AS CALLER
AS
BEGIN
	DECLARE @years int
	DECLARE @month int 
	DECLARE @days int
	DECLARE @res varchar(15)

	SET @years = dbo.FullYearAge(@BIRTH_DATE, @DATE)
	SET @DATE = DATEADD(yy, @years*(-1), @DATE)
	SET @month = DATEDIFF(month, @BIRTH_DATE, @DATE)
	IF (DATEPART(dd, @DATE) < DATEPART(dd, @BIRTH_DATE)) SET @month = @month - 1
	SET @DATE = DATEADD(mm, @month*(-1), @DATE)
	SET @days = DATEDIFF(day, @BIRTH_DATE, @DATE)
	--IF (@days > 29) SET @days = 29 
	RETURN cast(@years as varchar) + 'г. ' + cast(@month as varchar) + 'м. ' + cast(@days as varchar) + 'д.'
END;
go

