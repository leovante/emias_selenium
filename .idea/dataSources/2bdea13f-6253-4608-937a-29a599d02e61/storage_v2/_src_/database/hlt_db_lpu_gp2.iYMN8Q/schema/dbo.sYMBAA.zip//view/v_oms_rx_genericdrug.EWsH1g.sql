CREATE VIEW [V_oms_rx_GenericDrug] AS SELECT 
[hDED].[rx_GenericDrugID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MNNameID] as [rf_MNNameID], 
[jT_oms_MNName].[NAME_MNN] as [SILENT_rf_MNNameID], 
[hDED].[rf_LFID] as [rf_LFID], 
[jT_oms_LF].[C_LF] as [SILENT_rf_LFID], 
[hDED].[rf_DLSID] as [rf_DLSID], 
[jT_oms_DLS].[C_DLS] as [SILENT_rf_DLSID], 
[hDED].[rf_VLFID] as [rf_VLFID], 
[jT_oms_VLF].[C_VLF] as [SILENT_rf_VLFID], 
[hDED].[rf_MLFID] as [rf_MLFID], 
[jT_oms_MLF].[C_MLF] as [SILENT_rf_MLFID], 
[hDED].[rf_kl_ATHID] as [rf_kl_ATHID], 
[jT_oms_kl_ATH].[C_ATH] as [SILENT_rf_kl_ATHID], 
[hDED].[Name_GD] as [Name_GD], 
[hDED].[Dosage] as [Dosage], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID_GD] as [GUID_GD], 
[hDED].[D_LS] as [D_LS], 
[hDED].[V_LF] as [V_LF], 
[hDED].[M_LF] as [M_LF], 
[hDED].[N_DOZA] as [N_DOZA]
FROM [oms_rx_GenericDrug] as [hDED]
INNER JOIN [oms_MNName] as [jT_oms_MNName] on [jT_oms_MNName].[MNNameID] = [hDED].[rf_MNNameID]
INNER JOIN [oms_LF] as [jT_oms_LF] on [jT_oms_LF].[LFID] = [hDED].[rf_LFID]
INNER JOIN [oms_DLS] as [jT_oms_DLS] on [jT_oms_DLS].[DLSID] = [hDED].[rf_DLSID]
INNER JOIN [oms_VLF] as [jT_oms_VLF] on [jT_oms_VLF].[VLFID] = [hDED].[rf_VLFID]
INNER JOIN [oms_MLF] as [jT_oms_MLF] on [jT_oms_MLF].[MLFID] = [hDED].[rf_MLFID]
INNER JOIN [oms_kl_ATH] as [jT_oms_kl_ATH] on [jT_oms_kl_ATH].[kl_ATHID] = [hDED].[rf_kl_ATHID]
go

