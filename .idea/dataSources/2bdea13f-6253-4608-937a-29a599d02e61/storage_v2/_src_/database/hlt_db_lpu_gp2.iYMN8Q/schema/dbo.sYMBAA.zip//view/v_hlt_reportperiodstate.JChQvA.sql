CREATE VIEW [V_hlt_ReportPeriodState] AS SELECT 
[hDED].[ReportPeriodStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [hlt_ReportPeriodState] as [hDED]
go

