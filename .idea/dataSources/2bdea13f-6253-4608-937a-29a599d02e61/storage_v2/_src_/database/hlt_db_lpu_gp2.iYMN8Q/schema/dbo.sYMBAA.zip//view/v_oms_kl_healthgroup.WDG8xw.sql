CREATE VIEW [V_oms_kl_HealthGroup] AS SELECT 
[hDED].[kl_HealthGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_HealthGroupCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_HealthGroup] as [hDED]
go

