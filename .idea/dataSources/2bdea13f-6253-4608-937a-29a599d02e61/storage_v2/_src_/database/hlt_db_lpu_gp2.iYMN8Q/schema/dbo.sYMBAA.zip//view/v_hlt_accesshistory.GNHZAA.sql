CREATE VIEW [V_hlt_AccessHistory] AS SELECT 
[hDED].[AccessHistoryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_VisitHistoryID] as [rf_VisitHistoryID], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[UserFIO] as [UserFIO], 
[hDED].[Date] as [Date], 
[hDED].[Comment] as [Comment], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID], 
[hDED].[Operation] as [Operation]
FROM [hlt_AccessHistory] as [hDED]
go

