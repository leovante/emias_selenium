CREATE VIEW [V_hlt_atc_DocumentType] AS SELECT 
[hDED].[atc_DocumentTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_atc_DocumentType] as [hDED]
go

