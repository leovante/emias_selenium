CREATE VIEW [V_hlt_BlankTemplate] AS SELECT 
[hDED].[BlankTemplateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_BlankTemplateID] as [rf_BlankTemplateID], 
[jT_hlt_BlankTemplate].[Caption] as [SILENT_rf_BlankTemplateID], 
[hDED].[rf_ContextID] as [rf_ContextID], 
[jT_hlt_Context].[Name] as [SILENT_rf_ContextID], 
[hDED].[rf_BlankTemplateTypeID] as [rf_BlankTemplateTypeID], 
[jT_hlt_BlankTemplateType].[Name] as [SILENT_rf_BlankTemplateTypeID], 
[hDED].[Caption] as [Caption], 
[hDED].[TemplatePrint] as [TemplatePrint], 
[hDED].[Code] as [Code], 
[hDED].[TemplateEdit] as [TemplateEdit], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID], 
[hDED].[Value] as [Value], 
[hDED].[Validations] as [Validations], 
[hDED].[Source] as [Source], 
[hDED].[Comment] as [Comment], 
[hDED].[Actual] as [Actual], 
[hDED].[Author] as [Author], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[Version] as [Version], 
[hDED].[XmlData] as [XmlData], 
[hDED].[rf_MedRecordTypeGuid] as [rf_MedRecordTypeGuid]
FROM [hlt_BlankTemplate] as [hDED]
INNER JOIN [hlt_BlankTemplate] as [jT_hlt_BlankTemplate] on [jT_hlt_BlankTemplate].[BlankTemplateID] = [hDED].[rf_BlankTemplateID]
INNER JOIN [hlt_Context] as [jT_hlt_Context] on [jT_hlt_Context].[ContextID] = [hDED].[rf_ContextID]
INNER JOIN [hlt_BlankTemplateType] as [jT_hlt_BlankTemplateType] on [jT_hlt_BlankTemplateType].[BlankTemplateTypeID] = [hDED].[rf_BlankTemplateTypeID]
go

