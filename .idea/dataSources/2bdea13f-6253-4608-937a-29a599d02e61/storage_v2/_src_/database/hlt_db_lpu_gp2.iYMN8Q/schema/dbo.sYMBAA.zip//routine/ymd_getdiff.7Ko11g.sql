
CREATE FUNCTION [dbo].[ymd_GetDiff](@BIRTH_DATE datetime,@DATE datetime)
RETURNS varchar(10)
WITH EXECUTE AS CALLER
AS
BEGIN
	DECLARE @years int
	DECLARE @month int 
	DECLARE @days int

	SET @years = dbo.FullYearAge(@BIRTH_DATE, @DATE)
	SET @DATE = DATEADD(yy, @years*(-1), @DATE)
	SET @month = DATEDIFF(month, @BIRTH_DATE, @DATE)
	IF (DATEPART(dd, @DATE) < DATEPART(dd, @BIRTH_DATE)) SET @month = @month - 1
	SET @DATE = DATEADD(mm, @month*(-1), @DATE)
	SET @days = DATEDIFF(day, @BIRTH_DATE, @DATE)
	IF (@days > 29) SET @days = 29 
	RETURN RIGHT('000' + cast(@years as varchar), 3) + '.' + RIGHT('00' + cast(@month as varchar), 2) + '.' + RIGHT('00' + cast(@days as varchar), 2)
END;
go

