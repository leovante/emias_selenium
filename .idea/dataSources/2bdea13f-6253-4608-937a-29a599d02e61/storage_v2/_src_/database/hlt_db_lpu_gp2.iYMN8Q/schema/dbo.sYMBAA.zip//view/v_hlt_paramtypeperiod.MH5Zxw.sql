CREATE VIEW [V_hlt_ParamTypePeriod] AS SELECT 
[hDED].[ParamTypePeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_ParamTypePeriod] as [hDED]
go

