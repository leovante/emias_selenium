CREATE VIEW [V_oms_SMReestrSL_KOEF] AS SELECT 
[hDED].[SMReestrSL_KOEFID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrKSGID] as [rf_SMReestrKSGID], 
[hDED].[IDSL] as [IDSL], 
[hDED].[Z_SL] as [Z_SL]
FROM [oms_SMReestrSL_KOEF] as [hDED]
go

