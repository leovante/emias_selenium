CREATE VIEW [V_stt_TemplateValue] AS SELECT 
[hDED].[TemplateValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TemplateDefaultID] as [rf_TemplateDefaultID], 
[hDED].[Value] as [Value]
FROM [stt_TemplateValue] as [hDED]
go

