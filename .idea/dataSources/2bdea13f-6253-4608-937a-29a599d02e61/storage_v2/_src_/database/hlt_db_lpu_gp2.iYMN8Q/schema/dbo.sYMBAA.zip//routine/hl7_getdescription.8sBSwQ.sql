





CREATE FUNCTION [dbo].[hl7_GetDescription] 
(
	@DocumentGuid VARCHAR(100),
	@TemplateCode VARCHAR(50),
	@ID VARCHAR(100)
 )
RETURNS VARCHAR(MAX)
AS
BEGIN


	DECLARE     @result  VARCHAR(max)
	DECLARE		@XmlData xml	
	SET @result = '' 
	
	SET @XmlData = 	
		(select TOP(1) CONVERT(XML,mr.Data) from hlt_MedRecord mr 
			join hlt_BlankTemplate bt on mr.rf_BlankTemplateID = bt.BlankTemplateID
		where bt.Code = @TemplateCode AND mr.DescGuid = @DocumentGuid )


	DECLARE @text VARCHAR(max)
	SET @text = dbo.GetValueFromXMl(@XmlData,@ID)
	IF (ISNULL(@text,'') != '')	
		SET @result = @result + @text 

	IF (ISNULL(@result,'') = '')
		RETURN NULL

	RETURN @result       
END

go

