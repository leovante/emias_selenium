
CREATE FUNCTION [dbo].[ymd_AddToDate](@DATE datetime, @yy int, @mm int, @dd int)
RETURNS datetime
WITH EXECUTE AS CALLER
AS
BEGIN
	SET @DATE = DATEADD(dd, @dd, @DATE)
	SET @DATE = DATEADD(mm, @mm, @DATE)
	SET @DATE = DATEADD(yy, @yy, @DATE)
	RETURN @DATE
END;
go

