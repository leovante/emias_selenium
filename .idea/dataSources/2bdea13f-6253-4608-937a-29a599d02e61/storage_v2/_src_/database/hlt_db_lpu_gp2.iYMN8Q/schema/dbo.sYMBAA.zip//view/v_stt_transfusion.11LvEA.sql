CREATE VIEW [V_stt_Transfusion] AS SELECT 
[hDED].[TransfusionID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_stt_MedicalHistory].[FAMILY] as [V_Family], 
[jT_stt_MedicalHistory].[MedCardNum] as [V_MedCardNum], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[jT_stt_StationarBranch].[V_BranchInfo] as [SILENT_rf_StationarBranchID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_TransfusionTypeID] as [rf_TransfusionTypeID], 
[jT_stt_TransfusionType].[Name] as [SILENT_rf_TransfusionTypeID], 
[hDED].[rf_TrMethodID] as [rf_TrMethodID], 
[jT_stt_TrMethod].[Name] as [SILENT_rf_TrMethodID], 
[hDED].[BeginDateTime] as [BeginDateTime], 
[hDED].[EndDateTime] as [EndDateTime], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flags] as [flags]
FROM [stt_Transfusion] as [hDED]
INNER JOIN [stt_MedicalHistory] as [jT_stt_MedicalHistory] on [jT_stt_MedicalHistory].[MedicalHistoryID] = [hDED].[rf_MedicalHistoryID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [V_stt_StationarBranch] as [jT_stt_StationarBranch] on [jT_stt_StationarBranch].[StationarBranchID] = [hDED].[rf_StationarBranchID]
INNER JOIN [stt_TransfusionType] as [jT_stt_TransfusionType] on [jT_stt_TransfusionType].[TransfusionTypeID] = [hDED].[rf_TransfusionTypeID]
INNER JOIN [stt_TrMethod] as [jT_stt_TrMethod] on [jT_stt_TrMethod].[TrMethodID] = [hDED].[rf_TrMethodID]
go

