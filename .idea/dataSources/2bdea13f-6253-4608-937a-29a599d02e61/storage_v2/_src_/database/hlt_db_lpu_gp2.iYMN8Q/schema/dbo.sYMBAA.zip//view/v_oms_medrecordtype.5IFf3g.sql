CREATE VIEW [V_oms_MedRecordType] AS SELECT 
[hDED].[MedRecordTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ParentMedRecordTypeID] as [rf_ParentMedRecordTypeID], 
[hDED].[rf_EmdTypeID] as [rf_EmdTypeID], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[GUID] as [GUID], 
[hDED].[IsCategoryType] as [IsCategoryType]
FROM [oms_MedRecordType] as [hDED]
go

