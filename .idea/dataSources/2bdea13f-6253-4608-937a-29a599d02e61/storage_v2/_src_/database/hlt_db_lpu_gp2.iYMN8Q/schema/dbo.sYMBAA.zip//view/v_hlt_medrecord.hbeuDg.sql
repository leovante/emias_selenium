CREATE VIEW [V_hlt_MedRecord] AS SELECT 
[hDED].[MedRecordID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_DocInfo], 
[hDED].[rf_MKABGuid] as [rf_MKABGuid], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABGuid], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPrvdGuid] as [rf_DocPrvdGuid], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPrvdGuid], 
[hDED].[rf_BlankTemplateID] as [rf_BlankTemplateID], 
[jT_hlt_BlankTemplate].[Caption] as [SILENT_rf_BlankTemplateID], 
[hDED].[rf_VisitHistoryID] as [rf_VisitHistoryID], 
[hDED].[Data] as [Data], 
[hDED].[CRC] as [CRC], 
[hDED].[Sign] as [Sign], 
[hDED].[ConfidentialityCode] as [ConfidentialityCode], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[PersonGUID] as [PersonGUID], 
[hDED].[Date] as [Date], 
[hDED].[rf_DocTypeDefGUID] as [rf_DocTypeDefGUID], 
[hDED].[rf_DOCGUID] as [rf_DOCGUID], 
[hDED].[EventDataTime] as [EventDataTime], 
[hDED].[ViewData] as [ViewData], 
[hDED].[rf_CreateUserID] as [rf_CreateUserID], 
[hDED].[CreateUserName] as [CreateUserName], 
[hDED].[rf_EditUserID] as [rf_EditUserID], 
[hDED].[EditUserName] as [EditUserName], 
[hDED].[DescGuid] as [DescGuid], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[Description] as [Description], 
[hDED].[isUpload] as [isUpload], 
[hDED].[IsDel] as [IsDel]
FROM [hlt_MedRecord] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[UGUID] = [hDED].[rf_MKABGuid]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[GUID] = [hDED].[rf_DocPrvdGuid]
INNER JOIN [hlt_BlankTemplate] as [jT_hlt_BlankTemplate] on [jT_hlt_BlankTemplate].[BlankTemplateID] = [hDED].[rf_BlankTemplateID]
go

