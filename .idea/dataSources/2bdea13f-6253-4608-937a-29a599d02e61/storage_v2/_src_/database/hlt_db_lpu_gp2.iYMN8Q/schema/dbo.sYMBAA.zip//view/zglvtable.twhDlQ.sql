CREATE view [ZGLVTable] as select
'1.0' AS [VERSION],
 convert(varchar(15),Substring(Convert(varchar,GetDate(),121),1,10)) as [DATA],
'HM554002T31_17021' AS [FILENAME]
go

