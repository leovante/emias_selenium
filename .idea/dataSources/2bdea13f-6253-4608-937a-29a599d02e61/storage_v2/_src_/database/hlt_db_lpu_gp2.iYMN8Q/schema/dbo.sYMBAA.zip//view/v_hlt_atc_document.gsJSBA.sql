CREATE VIEW [V_hlt_atc_Document] AS SELECT 
[hDED].[atc_DocumentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_atc_ClaimID] as [rf_atc_ClaimID], 
[jT_hlt_atc_Claim].[Num] as [SILENT_rf_atc_ClaimID], 
[hDED].[rf_atc_DocumentTypeID] as [rf_atc_DocumentTypeID], 
[jT_hlt_atc_DocumentType].[Name] as [SILENT_rf_atc_DocumentTypeID], 
[hDED].[IdInSource] as [IdInSource], 
[hDED].[Description] as [Description], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Family] as [Family], 
[hDED].[Name] as [Name], 
[hDED].[Ot] as [Ot], 
[hDED].[BD] as [BD], 
[hDED].[DocSer] as [DocSer], 
[hDED].[DocNum] as [DocNum], 
[hDED].[DateDoc] as [DateDoc], 
[hDED].[DocIssuedBy] as [DocIssuedBy]
FROM [hlt_atc_Document] as [hDED]
INNER JOIN [hlt_atc_Claim] as [jT_hlt_atc_Claim] on [jT_hlt_atc_Claim].[atc_ClaimID] = [hDED].[rf_atc_ClaimID]
INNER JOIN [hlt_atc_DocumentType] as [jT_hlt_atc_DocumentType] on [jT_hlt_atc_DocumentType].[atc_DocumentTypeID] = [hDED].[rf_atc_DocumentTypeID]
go

