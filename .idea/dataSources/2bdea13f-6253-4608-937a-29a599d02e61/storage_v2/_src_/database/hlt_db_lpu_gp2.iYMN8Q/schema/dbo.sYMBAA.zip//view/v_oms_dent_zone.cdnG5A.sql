CREATE VIEW [V_oms_dent_Zone] AS SELECT 
[hDED].[dent_ZoneID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidZone], 
[hDED].[rf_dent_ConditionGroupID] as [rf_dent_ConditionGroupID], 
[jT_oms_dent_ConditionGroup].[Name] as [SILENT_rf_dent_ConditionGroupID], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Number] as [Number]
FROM [oms_dent_Zone] as [hDED]
INNER JOIN [oms_dent_ConditionGroup] as [jT_oms_dent_ConditionGroup] on [jT_oms_dent_ConditionGroup].[dent_ConditionGroupID] = [hDED].[rf_dent_ConditionGroupID]
go

