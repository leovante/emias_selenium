CREATE FUNCTION TempTable20171(@PCOD int)
RETURNS TABLE
AS
RETURN 
(
select
     hlt_TAP.DateTap as DateSMTAP,
     hlt_Citizen.COD as Cit_COD,
     hlt_MKAB.DATE_BD as BD,
     case oms_kl_VisitPlace.kl_VisitPlaceID when 0 then '0' else oms_kl_VisitPlace.Code end as TypeV_COD,  
     --hlt_TypeVisit.COD as TypeV_COD,
     case oms_kl_ReasonType.kl_ReasonTypeID when 0 then '0' else oms_kl_ReasonType.Code end as Goal_COD, 
     --hlt_GoalVisit.COD as Goal_COD,
     '0' as Ser_COD,--case oms_ServiceMedical.ServiceMedicalID when 0 then '0' else oms_ServiceMedical.ServiceMedicalCode end as Ser_COD,
     --hlt_ServiceMedical.CODE as Ser_COD,
     case oms_kl_ProfitType.kl_ProfitTypeID when 0 then '0' else oms_kl_ProfitType.Code end as TS_COD,
     --hlt_TypeSell.COD as TS_COD,
     hlt_Tap.DateTap as DT,
		 1 as cnt,
     isNULL(SMTAP.Count,0) as cnt_uet,
     hlt_LPUDoctor.LPUDoctorID as DoctorID,
		 (case when hlt_LPUDoctor.rf_PRVSID in (select PRVS.PRVSID from oms_PRVS PRVS where PRVS.C_PRVS IN ('3','171','174','176','175','177','208','209','233')) then 1 else 0 end) as Stom,
     hlt_LPUDoctor.FAM_V+' '+left([PCOD],10) as Fam,
		 hlt_TAP.TAPID as tapid,
		 (select count(*) from hlt_SMTAP where rf_tapid = hlt_TAP.TAPID) KolSMTAP
from
     hlt_TAP
		 left  join hlt_SMTAP SMTAP on SMTAP.rf_TAPID=hlt_TAP.TAPID and SMTAP.FlagBill=1 and SMTAP.rf_omsServiceMedicalID not in (select SM.ServiceMedicalID from oms_ServiceMedical SM where SM.ServiceMedicalCode='5500000000200071' or SM.ServiceMedicalCode='5500000000200072')
     inner join hlt_MKAB on hlt_MKAB.MKABID = hlt_TAP.rf_MKABID
     inner join hlt_Citizen on hlt_Citizen.CitizenID = hlt_MKAB.rf_CitizenID
     --inner join hlt_SMTAP on hlt_SMTAP.rf_TAPID = hlt_TAP.TAPID
     --inner join oms_ServiceMedical on oms_ServiceMedical.ServiceMedicalID = hlt_SMTAP.rf_omsServiceMedicalID
     --inner join hlt_ServiceMedical on hlt_ServiceMedical.ServiceMedicalID = hlt_SMTAP.rf_ServiceMedicalID
     inner join hlt_LPUDoctor on hlt_LPUDoctor.LPUDoctorID = hlt_TAP.rf_LPUDoctorID
     inner join oms_PRVS on oms_PRVS.PRVSID = hlt_LPUDoctor.rf_PRVSID
     inner join oms_kl_VisitPlace on oms_kl_VisitPlace.kl_VisitPlaceID = hlt_TAP.rf_kl_VisitPlaceID 
     --inner join hlt_TypeVisit on hlt_TypeVisit.TypeVisitID = hlt_TAP.rf_TypeVisitID
     inner join oms_kl_ReasonType on oms_kl_ReasonType.kl_ReasonTypeID = hlt_TAP.rf_kl_ReasonTypeID
     --inner join hlt_GoalVisit on hlt_GoalVisit.GoalVisitID = hlt_TAP.rf_GoalVisitID
     inner join oms_kl_ProfitType on oms_kl_ProfitType.kl_ProfitTypeID = hlt_TAP.rf_kl_ProfitTypeID
     --inner join hlt_TypeSell on hlt_TypeSell.TypeSellID = hlt_TAP.rf_TypeSellID
     --join oms_kl_MedCareUnit mcu on oms_ServiceMedical.rf_kl_MedCareUnitID = mcu.kl_MedCareUnitID
     --join hlt_UnitMedHelp umh on hlt_ServiceMedical.rf_UnitMedHelpID = umh.UnitMedHelpID
where
     hlt_TAP.DateTap > convert(datetime,'01-01-2017')
     --and mcu.Code = '1'	 
     --and umh.code = '1'
     --and oms_kl_ProfitType.kl_ProfitTypeID = @opl.kl_ProfitTypeID
		 and hlt_tap.IsClosed = '1'
     --and hlt_TypeSell.TypeSellID = @opl.TypeSellID
     and hlt_LPUDoctor.PCOD = @PCOD
)
go

