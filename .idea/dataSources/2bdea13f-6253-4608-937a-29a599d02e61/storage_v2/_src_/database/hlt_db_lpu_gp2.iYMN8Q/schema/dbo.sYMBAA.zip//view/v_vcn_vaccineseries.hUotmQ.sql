CREATE VIEW [V_vcn_VaccineSeries] AS SELECT 
[hDED].[VaccineSeriesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_VaccineID] as [rf_VaccineID], 
[jT_vcn_Vaccine].[Name] as [SILENT_rf_VaccineID], 
[hDED].[VaccineSeriesGuid] as [VaccineSeriesGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[Series] as [Series], 
[hDED].[DateRelease] as [DateRelease], 
[hDED].[DateExpiration] as [DateExpiration]
FROM [vcn_VaccineSeries] as [hDED]
INNER JOIN [vcn_Vaccine] as [jT_vcn_Vaccine] on [jT_vcn_Vaccine].[VaccineID] = [hDED].[rf_VaccineID]
go

