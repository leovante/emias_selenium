CREATE FUNCTION [dbo].[GetExpert](@id int)
RETURNS @expert TABLE (
	[Код] [varchar](10),
	[Замечание] [varchar](100),
	[Амбулатория пациенты] [int] NULL,
    [Амбулатория услуги] [int] NULL,
	[Амбулатория Сумма] [decimal](38, 2) NULL,
    [IDD] [int]
)
AS
begin
INSERT INTO @expert
select 
       SMCriterionCode as [Код],
	   SMCriterionCaption as [Замечание],
	   count(distinct [Амбулатория пациенты]) as [Амбулатория пациенты],
       count(distinct [Амбулатория услуги]) as   [Амбулатория услуги],   
	  Sum([Амбулатория Сумма])	 as   [Амбулатория Сумма],
      SMCriterionID as [ID]
from (
select rf_SMCriterionID as ID,
  r.rf_MKABID  as [Амбулатория пациенты],
  r.rf_ReestrMHSMTAPId as[Амбулатория услуги],
  S_ALL as [Амбулатория Сумма]    
  from [hlt_ReestrTAPMHReturns] R    
  inner join tmp_ExpertReestr v  on   v.rf_ReestrMHSMTAPId= r.rf_ReestrMHSMTAPId and v.rf_MKABId = r.rf_MKABId    
  where rf_reestrMHID =@id and v.rf_MKABId>0
) a 
inner join oms_SMCriterion on a.ID = SMCriterionID    
group by SMCriterionID,SMCriterionCode,SMCriterionCaption


union
select '  ','Всего по счету ',
	   [Амбулатория пациенты],
       [Амбулатория услуги],
       [Амбулатория Сумма],
	   '-3'
from (
 select count(distinct r.rf_MKABID)         as [Амбулатория пациенты], 
         count(distinct rf_ReestrMHSMTAPId) as [Амбулатория услуги],   
         Sum(round(S_ALL,2))                as [Амбулатория сумма]   
  from tmp_ExpertReestr r  
  where rf_MKABID>0 
) a
union
select '  ','Всего ошибок ',
	   [Амбулатория пациенты],
       [Амбулатория услуги],
       [Амбулатория Сумма],
       '-1'
from (
  select count(*) as [Амбулатория услуги] ,count(distinct r.rf_MKABID) as [Амбулатория пациенты], Sum(round(S_ALL,2)) as [Амбулатория Сумма]   
  from [hlt_ReestrTAPMHReturns] R    
  inner join  tmp_ExpertReestr v on  v.rf_ReestrMHSMTAPId= r.rf_ReestrMHSMTAPId and v.rf_MKABId = r.rf_MKABId    
  where  rf_reestrMHID =@id
) a
 
RETURN 
END
go

