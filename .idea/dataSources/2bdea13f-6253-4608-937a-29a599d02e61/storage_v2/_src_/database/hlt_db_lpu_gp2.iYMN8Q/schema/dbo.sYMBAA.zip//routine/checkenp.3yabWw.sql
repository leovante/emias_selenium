
CREATE function [dbo].[CheckENP] (@ENP nvarchar(17))
	 returns int 
AS
BEGIN

   if (LEN(@ENP) = 0) or (patindex('%[^0-9]%', @ENP) <> 0)
		return 0
		 
	--declare @enp2 varchar(17)
	--set @enp2 = dbo.IsDigits1( @enp )
	if (LEN(@ENP)=16) --and (@enp2 = @enp)
	begin
		set @ENP = '0'+@ENP
		
		declare @sum int
		set @sum=0
		declare @nchetsum int
		set @nchetsum=0
		declare @nch int
		declare @i int 
		set @i= 16	
		while(@i>0)
		begin
			set @sum = @sum+SUBSTRING(@ENP,@i-1,1)
			set @nch = SUBSTRING(@ENP,@i,1)*2
			set @nchetsum =  @nchetsum + (@nch % 10 + @nch / 10)
			set @i=@i-2
		end
		set @sum = @sum+ @nchetsum
        set @sum = (10 - @sum % 10) % 10
        if (@sum<>SUBSTRING(@ENP,17,1))
			return 0		
		else return 1		
    end
    
    return 0
END
go

