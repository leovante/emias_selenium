CREATE VIEW [V_hlt_HouseToUchastok] AS SELECT 
[hDED].[HouseToUchastokID], [hDED].[x_Edition], [hDED].[x_Status], 
(([jT_kla_House].[SILENT_rf_StreetID])) as [V_StreetName], 
[hDED].[rf_UchastokID] as [rf_UchastokID], 
[jT_hlt_Uchastok].[CODE] as [SILENT_rf_UchastokID], 
[hDED].[rf_HouseID] as [rf_HouseID], 
[jT_kla_House].[V_FullNumber] as [SILENT_rf_HouseID], 
[hDED].[KladrCode] as [KladrCode]
FROM [hlt_HouseToUchastok] as [hDED]
INNER JOIN [hlt_Uchastok] as [jT_hlt_Uchastok] on [jT_hlt_Uchastok].[UchastokID] = [hDED].[rf_UchastokID]
INNER JOIN [V_kla_House] as [jT_kla_House] on [jT_kla_House].[HouseID] = [hDED].[rf_HouseID]
go

