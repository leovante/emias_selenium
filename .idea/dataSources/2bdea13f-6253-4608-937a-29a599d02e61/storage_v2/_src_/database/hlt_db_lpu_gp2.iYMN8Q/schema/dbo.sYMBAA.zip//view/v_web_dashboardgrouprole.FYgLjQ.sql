CREATE VIEW [V_web_DashboardGroupRole] AS SELECT 
[hDED].[DashboardGroupRoleID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DashboardGroupGuid] as [rf_DashboardGroupGuid], 
[hDED].[rf_RoleGuid] as [rf_RoleGuid], 
[hDED].[Guid] as [Guid]
FROM [web_DashboardGroupRole] as [hDED]
go

