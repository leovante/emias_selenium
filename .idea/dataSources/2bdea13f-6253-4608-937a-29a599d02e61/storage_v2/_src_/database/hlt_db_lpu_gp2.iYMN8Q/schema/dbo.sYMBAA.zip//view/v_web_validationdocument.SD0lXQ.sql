CREATE VIEW [V_web_ValidationDocument] AS SELECT 
[hDED].[ValidationDocumentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Guid] as [Guid]
FROM [web_ValidationDocument] as [hDED]
go

