CREATE VIEW [V_oms_pr_Reestr] AS SELECT 
[hDED].[pr_ReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_SMO].[Q_NAME] as [V_Q_NAME], 
[jT_oms_LPU].[M_NAMES] as [V_M_NAMES], 
[jT_oms_pr_ReestrType].[Name] as [V_NameType], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_pr_ReestrTypeID] as [rf_pr_ReestrTypeID], 
[hDED].[Version] as [Version], 
[hDED].[Date_Out] as [Date_Out], 
[hDED].[Date_IN] as [Date_IN], 
[hDED].[FileName] as [FileName], 
[hDED].[Code_MO] as [Code_MO], 
[hDED].[Code_SMO] as [Code_SMO], 
[hDED].[ZAP] as [ZAP], 
[hDED].[ZAP_FLK] as [ZAP_FLK], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [oms_pr_Reestr] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_pr_ReestrType] as [jT_oms_pr_ReestrType] on [jT_oms_pr_ReestrType].[pr_ReestrTypeID] = [hDED].[rf_pr_ReestrTypeID]
go

