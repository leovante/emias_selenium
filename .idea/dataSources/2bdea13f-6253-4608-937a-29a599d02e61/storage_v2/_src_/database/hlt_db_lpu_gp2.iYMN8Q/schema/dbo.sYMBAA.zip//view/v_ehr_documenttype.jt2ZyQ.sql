CREATE VIEW [V_ehr_DocumentType] AS SELECT 
[hDED].[DocumentTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Description] as [Description]
FROM [ehr_DocumentType] as [hDED]
go

