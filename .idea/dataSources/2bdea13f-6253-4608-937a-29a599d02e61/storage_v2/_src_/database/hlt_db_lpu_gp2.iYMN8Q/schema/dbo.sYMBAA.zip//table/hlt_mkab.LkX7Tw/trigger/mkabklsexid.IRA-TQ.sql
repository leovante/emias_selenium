CREATE TRIGGER [dbo].[MKABklsexId] 
   ON [dbo].[hlt_MKAB]
   AFTER INSERT, UPDATE
AS 
BEGIN
    SET NOCOUNT ON;
     
    update hlt_mkab
    set rf_kl_SexId = isnull((select kl_sexId from oms_kl_sex where code=(case when hlt_mkab.w=0 then '2' when hlt_mkab.w=1 then '1' else '0' end )),0)
    from hlt_mkab 
    join inserted i on i.mkabID = hlt_mkab.mkabID
END
go

