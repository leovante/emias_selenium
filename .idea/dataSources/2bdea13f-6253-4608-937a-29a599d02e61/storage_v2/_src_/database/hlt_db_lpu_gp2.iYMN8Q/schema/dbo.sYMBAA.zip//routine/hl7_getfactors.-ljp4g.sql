





create function [dbo].[hl7_GetFactors]
(
	@DocumentGuid VARCHAR(100),
	@TemplateCode VARCHAR(50)
 )
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE     @result  VARCHAR(max)
	DECLARE		@XmlData xml	
	SET @result = '' 
	
	SET @XmlData = 
		(select TOP(1) CONVERT(XML,mr.Data) from hlt_MedRecord mr 
			join hlt_BlankTemplate bt on mr.rf_BlankTemplateID = bt.BlankTemplateID
		where bt.Code = @TemplateCode AND mr.DescGuid = @DocumentGuid )
	
	DECLARE @text VARCHAR(MAX)
	SET @text = 
'                                    <text>
                                        <table border="1">
                                            <thead>
                                                <tr>
                                                    <th>Фактор риска</th>
                                                    <th>Дата начала фактора риска</th>
                                                    <th>Дата окончания фактора риска</th>
                                                </tr>
                                            </thead>
                                            <tbody>'
	
			
	DECLARE @I INT
	SET @I = 1
		WHILE (@I <= 3)
			BEGIN
				IF NOT((dbo.GetValueFromXMl(@XmlData,'refFR'+CONVERT(VARCHAR,@I)) = '' OR dbo.GetValueFromXMl(@XmlData,'refFR'+CONVERT(VARCHAR,@I)) = '0' OR dbo.GetValueFromXMl(@XmlData,'DateFactorBegin'+CONVERT(VARCHAR,@I)) = '' ))
				BEGIN

				SET @text = @text + '
                                                <tr>
                                                    <td align="center">' 
													+ (SELECT cv.NameNSI
														FROM hl7_catalogValue cv
														WHERE cv.catalogValueID = dbo.GetInstanseId(@XmlData,'refFR'+CONVERT(VARCHAR,@I))) +'</td>
                                                    <td align="center">'+convert(varchar,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateFactorBegin'+CONVERT(VARCHAR,@I)),104),105)+'</td>
                                                    <td align="center">'+convert(varchar,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateFactorEnd'+CONVERT(VARCHAR,@I)),104),105) + '</td>
                                                </tr>'

				SET @result = @result +
'                                            
                                            <component typeCode="COMP">
                                                <observation classCode="OBS" moodCode="EVN">
                                                    <code code="' + (SELECT cv.CodeNSI
					FROM hl7_catalogValue cv
				WHERE cv.catalogValueID = dbo.GetInstanseId(@XmlData,'refFR'+CONVERT(VARCHAR,@I))) + 
						'" codeSystem="1.2.643.5.1.13.2.1.1.325" codeSystemName="Классификатор факторов риска и медицинского анамнеза больного с острым нарушением мозгового кровообращения" displayName="'
						+ (SELECT cv.NameNSI
							FROM hl7_catalogValue cv
						WHERE cv.catalogValueID = dbo.GetInstanseId(@XmlData,'refFR'+CONVERT(VARCHAR,@I))) + '"/>
                                                    <effectiveTime>
                                                        <low value="' +replace(replace(replace(convert(varchar,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateFactorBegin'+CONVERT(VARCHAR,@I)),104),120),'-',''),':',''),' ','')+ '"/>
                                                        <high value="' +replace(replace(replace(convert(varchar,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateFactorEnd'+CONVERT(VARCHAR,@I)),104),120),'-',''),':',''),' ','')+ '"/>
                                                    </effectiveTime>
                                                </observation>
                                            </component>'	
				END
			SET @I = @I + 1
			END

	IF (ISNULL(@result,'') = '')
		RETURN NULL

	SET @text = @text  +
'
                                            </tbody>
                                        </table>
                                    </text>'
	RETURN @text + 
'
                                    <entry>
                                        <templateId root="1.2.643.5.1.13.2.7.5.4.7"/>
                                        <organizer classCode="CLUSTER" moodCode="EVN">
                                            <templateId root="1.2.643.5.1.13.2.7.5.3.14"/>
                                            <code code="RISKFACTOR" codeSystem="1.2.643.5.1.13.2.7.1.12" codeSystemName="Система кодирования событий" displayName="Факторы риска"/>
                                            <statusCode code="completed"/>'	
		  +@result + '
                                        </organizer>
                                    </entry>'
          
END

go

