CREATE VIEW [V_oms_pr_LPUResource] AS SELECT 
[hDED].[pr_LPUResourceID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_pr_LPU].[V_M_NAMES] as [V_V_M_NAMES], 
[jT_oms_pr_ResourceType].[Name] as [V_NameRes], 
[hDED].[rf_pr_ResourceTypeID] as [rf_pr_ResourceTypeID], 
[hDED].[rf_pr_LPUID] as [rf_pr_LPUID], 
[hDED].[Date_IN] as [Date_IN], 
[hDED].[Resource] as [Resource], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [oms_pr_LPUResource] as [hDED]
INNER JOIN [V_oms_pr_LPU] as [jT_oms_pr_LPU] on [jT_oms_pr_LPU].[pr_LPUID] = [hDED].[rf_pr_LPUID]
INNER JOIN [oms_pr_ResourceType] as [jT_oms_pr_ResourceType] on [jT_oms_pr_ResourceType].[pr_ResourceTypeID] = [hDED].[rf_pr_ResourceTypeID]
go

