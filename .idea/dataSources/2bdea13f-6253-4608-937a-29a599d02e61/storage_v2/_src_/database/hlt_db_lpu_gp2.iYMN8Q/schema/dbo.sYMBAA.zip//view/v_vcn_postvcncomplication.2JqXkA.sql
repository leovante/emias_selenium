CREATE VIEW [V_vcn_PostVcnComplication] AS SELECT 
[hDED].[PostVcnComplicationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_HospMkbID] as [rf_HospMkbID], 
[jT_oms_MKB1].[DS] as [SILENT_rf_HospMkbID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_InoculationID] as [rf_InoculationID], 
[hDED].[pvcGuid] as [pvcGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[BasicSymptoms] as [BasicSymptoms], 
[hDED].[Num] as [Num], 
[hDED].[DateMkb] as [DateMkb], 
[hDED].[DateHosp] as [DateHosp], 
[hDED].[DateDoc] as [DateDoc], 
[hDED].[DateObr] as [DateObr], 
[hDED].[AdditionalInfo] as [AdditionalInfo]
FROM [vcn_PostVcnComplication] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_MKB] as [jT_oms_MKB1] on [jT_oms_MKB1].[MKBID] = [hDED].[rf_HospMkbID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
go

