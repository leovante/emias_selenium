CREATE VIEW [V_vcn_PlannedInoculation] AS SELECT 
[hDED].[PlannedInoculationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_InoculationCardID] as [rf_InoculationCardID], 
[jT_vcn_InoculationCard].[V_FIO] as [SILENT_rf_InoculationCardID], 
[hDED].[rf_VaccinationTypeID] as [rf_VaccinationTypeID], 
[jT_vcn_VaccinationType].[ShortName] as [SILENT_rf_VaccinationTypeID], 
[hDED].[rf_ReasonID] as [rf_ReasonID], 
[jT_vcn_Reason].[Name] as [SILENT_rf_ReasonID], 
[hDED].[rf_VaccinationGroupID] as [rf_VaccinationGroupID], 
[jT_vcn_VaccinationGroup].[Name] as [SILENT_rf_VaccinationGroupID], 
[hDED].[rf_VaccineTypeID] as [rf_VaccineTypeID], 
[jT_vcn_VaccineType].[Name] as [SILENT_rf_VaccineTypeID], 
[hDED].[rf_SchemaID] as [rf_SchemaID], 
[jT_vcn_Schema].[Name] as [SILENT_rf_SchemaID], 
[hDED].[rf_PlanID] as [rf_PlanID], 
[jT_vcn_Plan].[Author] as [SILENT_rf_PlanID], 
[hDED].[Date] as [Date], 
[hDED].[Details] as [Details]
FROM [vcn_PlannedInoculation] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [V_vcn_InoculationCard] as [jT_vcn_InoculationCard] on [jT_vcn_InoculationCard].[InoculationCardID] = [hDED].[rf_InoculationCardID]
INNER JOIN [vcn_VaccinationType] as [jT_vcn_VaccinationType] on [jT_vcn_VaccinationType].[VaccinationTypeID] = [hDED].[rf_VaccinationTypeID]
INNER JOIN [vcn_Reason] as [jT_vcn_Reason] on [jT_vcn_Reason].[ReasonID] = [hDED].[rf_ReasonID]
INNER JOIN [vcn_VaccinationGroup] as [jT_vcn_VaccinationGroup] on [jT_vcn_VaccinationGroup].[VaccinationGroupID] = [hDED].[rf_VaccinationGroupID]
INNER JOIN [vcn_VaccineType] as [jT_vcn_VaccineType] on [jT_vcn_VaccineType].[VaccineTypeID] = [hDED].[rf_VaccineTypeID]
INNER JOIN [vcn_Schema] as [jT_vcn_Schema] on [jT_vcn_Schema].[SchemaID] = [hDED].[rf_SchemaID]
INNER JOIN [vcn_Plan] as [jT_vcn_Plan] on [jT_vcn_Plan].[PlanID] = [hDED].[rf_PlanID]
go

