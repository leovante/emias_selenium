CREATE VIEW [V_oms_dent_ToolbarType] AS SELECT 
[hDED].[dent_ToolbarTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidToolbarType], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [oms_dent_ToolbarType] as [hDED]
go

