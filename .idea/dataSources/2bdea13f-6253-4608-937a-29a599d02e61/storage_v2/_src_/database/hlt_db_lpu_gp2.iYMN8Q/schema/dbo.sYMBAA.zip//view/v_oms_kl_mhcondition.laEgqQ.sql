CREATE VIEW [V_oms_kl_MHCondition] AS SELECT 
[hDED].[kl_MHConditionID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_MHConditionCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_MHCondition] as [hDED]
go

