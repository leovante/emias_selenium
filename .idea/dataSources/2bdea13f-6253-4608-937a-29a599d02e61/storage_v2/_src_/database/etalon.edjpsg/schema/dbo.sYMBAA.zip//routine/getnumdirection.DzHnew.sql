
CREATE PROC [dbo].[GetNumDirection] 
	@Number varchar(20) output, 
	@Date datetime 
as 

	set transaction isolation level SERIALIZABLE 
	begin tran tranz1 

	declare @VI bigint 
	declare @MCOD varchar(10)

	SET @Number=-1 
	SET @VI = isnull((select top 1 ValueInt from x_UserSettings WHERE x_UserSettings.Property like 'Текущий номер направления в другое ЛПУ'), 0)
	if (@VI = 0)
	BEGIN
	 INSERT INTO [dbo].[x_UserSettings]
			   ([rf_UserID]
			   ,[OwnerGUID]
			   ,[DocTypeDefGUID]
			   ,[rf_SettingTypeID]
			   ,[Property]
			   ,[ValueInt]
			   ,[x_Edition]
			   ,[x_Status])
		 VALUES
			   (1
			   ,'00000000-0000-0000-0000-000000000000'
			   ,'00000000-0000-0000-0000-000000000000'
			   ,8 -- целое число
			   ,'Текущий номер направления в другое ЛПУ'
			   ,1
			   ,1
			   ,1)
		SET @VI  = 1
	END

	SET @MCOD = isnull((select top 1 ValueStr from x_usersettings where property = 'Код поликлиники' and rf_UserID = 1), '0000000')


	UPDATE x_UserSettings 
	SET ValueInt = @VI + 1 
	FROM x_UserSettings (rowlock) 
	WHERE x_UserSettings.Property like 'Текущий номер направления в другое ЛПУ' 

	SET @Number = @MCOD + cast(@VI as varchar)

	declare @len int, @i int, @k int, @r int
	set @len = len(@Number)
	set @i = 1;
	set @k = 0;
	set @r = 0;

	while @i <= @len 
	BEGIN
		set @r = (@r + ASCII(substring(@Number, @i, 1)) * (@k % 9 + 1)) % 10
		set @i = @i + 1
		set @k = @k + 1
	END

	SET @Number = @Number + cast(@r as varchar(1))

	commit tran tranz1 
	set transaction isolation level READ COMMITTED  
	RETURN
go

