
CREATE VIEW [V_x_UserGroup] AS SELECT 
[hDED].[UserGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[GUID] as [GUID], 
[hDED].[WinSid] as [WinSid], 
[hDED].[Description] as [Description]
FROM [x_UserGroup] as [hDED]
go

