
CREATE PROCEDURE [dbo].[spCreateVisitWOExpert]
	@dttid int,
	@mkabid int,
	@result int output
AS
BEGIN

	/* Есть ли такая временная запись? */
	IF NOT EXISTS
	(
		SELECT * FROM hlt_DoctorTimeTable WHERE DoctorTimeTableID = @dttid
	)
	BEGIN
		SET @result = -8	
		RETURN
	END

		

BEGIN TRAN

declare @dvtID int
declare @TAPID int

/* Создаем записи в hlt_DoctorVisitTable */
INSERT INTO hlt_DoctorVisitTable 
(
	rf_DoctorTimeTableID, 
	rf_MKABID, 
	Comment,
	Flags,
	fromInternet,
	UGUID,
	NormaUE)
SELECT 
	@dttid, 
	@mkabid, 
	hlt_MKAB.FAMILY + ' ' + hlt_MKAB.NAME + ' ' + hlt_MKAB.OT + ', ' + cast (datepart(yy, hlt_MKAB.DATE_BD) as varchar(4)) + ' г.р.',
	4,
	1,
	newid(),
	1
FROM hlt_MKAB WHERE MKABID = @mkabid

COMMIT TRAN
SET @result = 0

END

go

