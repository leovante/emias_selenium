CREATE PROCEDURE [dbo].[AddDefaultService] 
 @dateA datetime, 
 @dateB datetime
AS
BEGIN
 SET NOCOUNT ON;
 
 /*Дополнительные услуги*/
 declare @DOPUSL_POLYCLINICA int
 declare @DOPUSL_STOMATOLOGIA int
 
 SET @DOPUSL_POLYCLINICA = isnull((select top 1 servicemedicalid from oms_servicemedical where servicemedicalcode = '5500000000200071'),0)
 SET @DOPUSL_STOMATOLOGIA = isnull((select top 1 servicemedicalid from oms_servicemedical where servicemedicalcode = '5500000000200072'),0)

 /*Талоны для обновления услуг*/
 declare @@TapTable table (tapid int, mainservice int, dopservice int)

 INSERT INTO @@TapTable (tapid, mainservice, dopservice)
 SELECT tapid ,0 ,0
 FROM hlt_tap i
 WHERE i.DateTap between @dateA and @dateB
 and i.isClosed = 1
 and i.rf_LPUDoctorID > 0
 
 /*Основная услуга*/
 update @@TapTable
 set mainservice = 1
 from @@TapTable TapTable 
  inner join hlt_smtap on rf_tapid = TapTable.tapid
 where hlt_smtap.isFake=0
 
 /*Дополнительная услуга*/
 update @@TapTable
 set dopservice = 1
 from @@TapTable TapTable 
  inner join hlt_smtap on rf_tapid = TapTable.tapid
 where hlt_smtap.isFake=1
  
 /*Добавляем основную услугу для всех закрытых ТАПов отчетного периуда*/
 INSERT INTO [dbo].[hlt_SMTAP]
           ([x_Edition]
           ,[x_Status]
           ,[rf_TAPID]
           ,[REG_S]
           ,[SMTAPGuid]
           ,[IsFake]
           ,[rf_LPUDoctorID]
           ,[Count]
           ,[DATE_P]
           ,[rf_DoctorVisitTableID]
           ,[FLAGS]
           ,[rf_LPUID]
           ,[rf_MKBID]
           ,[Description]
           ,[rf_omsServiceMedicalID]
           ,[rf_TariffID]
           ,[rf_DepartmentID]
           ,[FlagPay]
           ,[FlagComplete]
           ,[FlagStatist]
           ,[FlagBill]
           ,[rf_CreateUserID]
           ,[rf_EditUserID]
           ,[CreateUserName]
           ,[EditUserName]
           ,[rf_InvoiceID])
     SELECT 
            1 as [x_Edition]
           ,1 as [x_Status]
           ,i.[TAPID] as [rf_TAPID]
           ,0 as [REG_S]
           ,newid() as [SMTAPGuid]
           ,0 as [IsFake]
           ,i.[rf_LPUDoctorID] as [rf_LPUDoctorID]
           ,1 as [Count]
           ,i.DateTap as [DATE_P]
           ,0 as [rf_DoctorVisitTableID]
           ,0 as [FLAGS] 
           ,0 as [rf_LPUID]
           ,i.[rf_MKBID] as [rf_MKBID]
           ,'' as [Description]   
     ,0 as [rf_omsServiceMedicalID]
           ,0 as [rf_TariffID]
           ,i.rf_DepartmentID as [rf_DepartmentID] 
           ,0 as [FlagPay]
           ,1 as [FlagComplete]
           ,1 as [FlagStatist]
           ,1 as [FlagBill]
           ,i.[rf_CreateUserID] as [rf_CreateUserID]
           ,i.[rf_EditUserID] as [rf_EditUserID]
           ,i.[CreateUserName] as [CreateUserName]
           ,i.[EditUserName] as [EditUserName]
           ,0 as [rf_InvoiceID]
 FROM hlt_tap i
  INNER JOIN @@TapTable TapTable on i.tapid=TapTable.tapid
 WHERE TapTable.mainservice=0

 
 /*Добавляем дополнительную услугу для всех закрытых ТАПов отчетного периуда*/
 INSERT INTO [dbo].[hlt_SMTAP]
           ([x_Edition]
           ,[x_Status]
           ,[rf_TAPID]
           ,[REG_S]
           ,[SMTAPGuid]
           ,[IsFake]
           ,[rf_LPUDoctorID]
           ,[Count]
           ,[DATE_P]
           ,[rf_DoctorVisitTableID]
           ,[FLAGS]
           ,[rf_LPUID]
           ,[rf_MKBID]
           ,[Description]
           ,[rf_omsServiceMedicalID]
           ,[rf_TariffID]
           ,[rf_DepartmentID]
           ,[FlagPay]
           ,[FlagComplete]
           ,[FlagStatist]
           ,[FlagBill]
           ,[rf_CreateUserID]
           ,[rf_EditUserID]
           ,[CreateUserName]
           ,[EditUserName]
           ,[rf_InvoiceID])
     SELECT 
            1 as [x_Edition]
           ,1 as [x_Status]
           ,i.[TAPID] as [rf_TAPID]
           ,0 as [REG_S]
           ,newid() as [SMTAPGuid]
           ,1 as [IsFake] /*Дополнительные услуги помечаем признаком фиктивной записи*/
           ,i.[rf_LPUDoctorID] as [rf_LPUDoctorID]
           ,1 as [Count]
           ,i.DateTap as [DATE_P]
           ,0 as [rf_DoctorVisitTableID]
           ,0 as [FLAGS] 
           ,0 as [rf_LPUID]
           ,i.[rf_MKBID] as [rf_MKBID]
           ,'Дополнительная услуга' as [Description] 
           /*TODO: УЧЕСТЬ СТОМАТОЛОГОВ*/   
     , case when oms_prvs.C_PRVS in (
'14',     -- Стоматология
'1401',   -- Стоматология общей практики
'140101', -- Ортодонтия
'140102', -- Стоматология детская
'140103', -- Стоматология терапевтическая
'140104', -- Стоматология ортопедическая
'140105', -- Стоматология хирургическая
'140106', -- Челюстно-лицевая хирургия
'2004',   -- Стоматология
'2005',   -- Стоматология ортопедическая
'2027'    -- Стоматология профилактическая
) 
    then @DOPUSL_STOMATOLOGIA
    else @DOPUSL_POLYCLINICA end as [rf_omsServiceMedicalID]
           ,0 as [rf_TariffID]
           ,i.rf_DepartmentID as [rf_DepartmentID] 
           ,0 as [FlagPay]
           ,1 as [FlagComplete]
           ,1 as [FlagStatist]
           ,1 as [FlagBill]
           ,i.[rf_CreateUserID] as [rf_CreateUserID]
           ,i.[rf_EditUserID] as [rf_EditUserID]
           ,i.[CreateUserName] as [CreateUserName]
           ,i.[EditUserName] as [EditUserName]
           ,0 as [rf_InvoiceID]
 FROM hlt_tap i
  INNER JOIN @@TapTable TapTable on i.tapid=TapTable.tapid
  inner join hlt_lpudoctor doc on i.rf_lpudoctorid = doc.lpudoctorid 
  inner join oms_prvs on doc.rf_prvsid = oms_prvs.prvsid 
 WHERE TapTable.dopservice=0
  
 /*Где можем - проставляем услуги*/
 UPDATE [hlt_SMTAP]
 SET [rf_omsServiceMedicalID] =
 ISNULL((
    select top 1 ServiceMedicalID 
    from oms_ServiceMedical sm
    where sm.rf_PRVSID = doc.rf_PRVSID
    and exists 
    (
     select 1 from oms_Tariff t where t.rf_ServiceMedicalID = sm.ServiceMedicalID
     and i.[DATE_P] between t.date_B and t.date_E
    ) 
 ), 0), 
 rf_LPUID = doc.rf_LPUID
 FROM [hlt_SMTAP] i
  INNER JOIN @@TapTable TapTable on i.rf_tapid=TapTable.tapid
  inner join hlt_LPUDoctor doc on i.rf_LPUDoctorID = doc.LPUDoctorID
 where  [rf_omsServiceMedicalID]=0 /*Дополнительные услуги уже проставлены*/
 
 /*Добавляем тарифы*/
 UPDATE [hlt_SMTAP]
 SET [rf_TariffID] =isnull(
 (
    select top 1 TariffID 
    from oms_Tariff t
    where t.rf_ServiceMedicalID = i.[rf_omsServiceMedicalID]
     and i.[DATE_P] between t.date_B and t.date_E
 ),0)
 FROM [hlt_SMTAP] i
  INNER JOIN @@TapTable TapTable on i.rf_tapid=TapTable.tapid
  inner join hlt_LPUDoctor doc on i.rf_LPUDoctorID = doc.LPUDoctorID
 where [rf_TariffID] = 0
END
go

