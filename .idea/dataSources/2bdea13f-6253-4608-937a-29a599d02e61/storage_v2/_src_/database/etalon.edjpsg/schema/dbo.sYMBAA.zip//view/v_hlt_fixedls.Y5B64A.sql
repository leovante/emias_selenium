CREATE VIEW [V_hlt_FixedLS] AS SELECT 
[hDED].[FixedLSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LSID] as [rf_LSID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[Count] as [Count], 
[hDED].[DateB] as [DateB], 
[hDED].[DateE] as [DateE], 
[hDED].[LSName] as [LSName], 
[hDED].[Signa] as [Signa], 
[hDED].[Note] as [Note]
FROM [hlt_FixedLS] as [hDED]
go

