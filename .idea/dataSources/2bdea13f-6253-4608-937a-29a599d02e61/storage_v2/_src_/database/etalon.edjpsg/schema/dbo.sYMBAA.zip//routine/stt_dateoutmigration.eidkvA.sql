/*Дату выбытия для движения */ create function [dbo].[stt_dateOutMigration](@MedicalHistoryID int,@MigrationPatientID int) returns datetime begin  declare @DateOut datetime  select top 1 @DateOut= DateIngoing from stt_MigrationPatient where MigrationPatientID = (SELECT [dbo].[stt_NextMigration] (@MedicalHistoryID,@MigrationPatientID))   return @DateOut end
go

