/*тригггер на удаление тяжелых полей, [Data], [ViewData]*/
Create TRIGGER [dbo].[Trigger_life_hlt_MedRecord_DelXml] ON [dbo].[life_hlt_MedRecord] After INSERT
AS 

SET NOCOUNT ON;


BEGIN
	update life_hlt_MedRecord set [Data]='',[ViewData]=''
	from life_hlt_MedRecord m
	inner join inserted i on m.MedRecordLifeID = i.MedRecordLifeID
END; 

SET NOCOUNT OFF;
go

