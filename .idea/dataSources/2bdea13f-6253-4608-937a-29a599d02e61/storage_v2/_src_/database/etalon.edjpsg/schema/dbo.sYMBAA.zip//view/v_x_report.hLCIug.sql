
CREATE view [dbo].[V_x_Report] as select [ReportID], [x_Edition], [x_Status], 
[ReportGUID],[Caption],[Description],[rf_DocTypeDefID],[ReportDesc],[ReportTemplate],[OwnerType],[Format],[flags],
(CASE [OwnerType] WHEN 2 THEN '<нет>' ELSE 
(CASE [rf_DocTypeDefID] WHEN -1 THEN '<нет>' ELSE 
(select top 1 [x_Theme].[Name] + '.' + [x_DocTypeDef].[Name] 
from [x_DocTypeDef] inner join [x_Theme] on [x_DocTypeDef].[ThemeID] = [x_Theme].[ThemeID]
where DocTypeDefID=[rf_DocTypeDefID]) END) END)
as [DocTypeNameVSV] from [x_Report]
go

