
CREATE view [VV_ExpertPeriod00000000-0000-0000-0000-000000000000] as 
select v.* 
from 
(
select
isnull(DepartmentID,0) DepartmentID, isnull(Lpu_Info,'МО с таким кодом нет') +' || '+isnull(departmentCode,'XX')+' '+  isnull(dep_name,'Код отделения не найден') as dep_name,
Sluch_SUMV as S_all,
        sluch.*, 
		zsluch.*,
		ksg.*,
		naz.*,
		ds2.*,
		Usl.*, 
		patient.*,
		zap.*,
		SCHET.*,
        onk.*,
        uslonk.*,
B_DIAG,B_PROt, NAPR,

isnull(usl_ReestrMKSBID,0) as ReestrMKSBID,
0 as MedserviceID,
0 as FHReestrPositionId,
0 as rf_JournalCallID,
0 as FHReestrOccasionID,
--isnull(usl_MedserviceID,0) as MedserviceID,
--isnull (FHReestrPositionId,0) as FHReestrPositionId,
--isnull(JournalCallID,0) as rf_JournalCallID,
--isnull(FHReestrOccasionID,0) as FHReestrOccasionID,
isnull(usl_MKABID,0) as rf_MKABID,
isnull(usl_TAPID,0) as rf_TAPID,
124 as rf_ReportPeriodID,
isnull(dep.lpuid,0) as lpuid ,
isnull(Lpu_Info,'МО с таким кодом нет') as lpu_name,
isnull(usl_ReestrMHSMTAPId,0) as  ReestrMHSMTAPId,
isnull(usl_ReestrTAPMHId,0) rf_ReestrTAPMHID,
isnull(usl_MedServicePatientId,0) as rf_MedServicePatientId,

isnull(usl_ServiceMedicalId,0) rf_ServiceMedicalID,
isnull(usl_ReestrOccasionID,0) as SU,

isnull(usl_MedicalHistoryId,0) as  SK,
isnull(usl_SMOID,0)  rf_SMOID,

0 rf_ReestrMHID

 from      [tmp_Usl00000000-0000-0000-0000-000000000000]           usl  WITH(NOLOCK) 
inner join [tmp_schet00000000-0000-0000-0000-000000000000]         schet  WITH(NOLOCK)  on 1=1
left join  [tmp_Sluch00000000-0000-0000-0000-000000000000]         sluch   WITH(NOLOCK)  on sluch.[Sluch_SluchID] =usl.[Usl_rf_SluchID] and sluch.sluch_Disp=usl.usl_Disp
left join  [tmp_zap00000000-0000-0000-0000-000000000000]           zap     WITH(NOLOCK)  on sluch.SLUCH_rf_ZapId = zap.ZapID 
left join  [tmp_patient00000000-0000-0000-0000-000000000000]       patient WITH(NOLOCK)  on patient.rf_ZapId= zap.ZapID
left join  [tmp_KSG00000000-0000-0000-0000-000000000000]           ksg     WITH(NOLOCK)   on ksg.ksg_rf_SLuchID= sluch.Sluch_SluchID and ksg.ksg_rf_ZSLuchID =sluch.sluch_rf_zsluchId
left  join [tmp_naz00000000-0000-0000-0000-000000000000]           naz     WITH(NOLOCK)  on sluch.SLUCH_SluchId = naz.NAZ_rf_SluchID  
left  join [tmp_ds200000000-0000-0000-0000-000000000000]           ds2     WITH(NOLOCK)  on sluch.SLUCH_SluchId = ds2.DS2_rf_SluchID  
left join  [tmp_dep00000000-0000-0000-0000-000000000000]           dep     WITH(NOLOCK)  on (sluch.Sluch_LPU_1 = dep.Code_Lpu  and   convert(varchar(10),sluch.Sluch_Podr)=dep.DepartmentCode )
left join  [tmp_Zsluch00000000-0000-0000-0000-000000000000]        zsluch  WITH(NOLOCK)  on sluch_tapID= zsluch_tapid and sluch_ReestrOccasionID=zsluch_ReestrOccasionID and sluch_Disp=zsluch_Disp  and zsluch_METOD_HMP=Sluch_METOD_HMP and ZSluch_VID_HMP=Sluch_VID_HMP
left join  [tmp_ONK00000000-0000-0000-0000-000000000000]          onk     WITH(NOLOCK)  on sluch.SLUCH_SluchId = onk.ONK_rf_SluchID 
left join  [tmp_ONK_USL00000000-0000-0000-0000-000000000000]     uslonk    WITH(NOLOCK)  on sluch.SLUCH_SluchId = uslonk.ONK_USL_rf_SluchID  and usl.usl_ID_USL =  uslonk.ONK_USL_ID_USL
left join  [tmp_B_DIAG00000000-0000-0000-0000-000000000000]      b_diagn   WITH(NOLOCK)  on sluch.SLUCH_SluchId = b_diagn.rf_SluchID 
left join  [tmp_B_PROT00000000-0000-0000-0000-000000000000]      prot      WITH(NOLOCK)  on sluch.SLUCH_SluchId = prot.rf_SluchID 
left join  [tmp_NAPR00000000-0000-0000-0000-000000000000]        nap       WITH(NOLOCK)  on sluch.SLUCH_SluchId = nap.rf_SluchID 
) v

go

