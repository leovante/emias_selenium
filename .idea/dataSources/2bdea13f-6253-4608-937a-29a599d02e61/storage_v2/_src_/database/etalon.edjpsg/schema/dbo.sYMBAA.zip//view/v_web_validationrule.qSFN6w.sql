CREATE VIEW [V_web_ValidationRule] AS SELECT 
[hDED].[ValidationRuleID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ValidationQueryGuid] as [rf_ValidationQueryGuid], 
[hDED].[rf_ValidationDocumentGuid] as [rf_ValidationDocumentGuid], 
[hDED].[Name] as [Name], 
[hDED].[Message] as [Message], 
[hDED].[IsError] as [IsError], 
[hDED].[IsDisabled] as [IsDisabled], 
[hDED].[FieldList] as [FieldList], 
[hDED].[Guid] as [Guid], 
[hDED].[IsMaster] as [IsMaster]
FROM [web_ValidationRule] as [hDED]
go

