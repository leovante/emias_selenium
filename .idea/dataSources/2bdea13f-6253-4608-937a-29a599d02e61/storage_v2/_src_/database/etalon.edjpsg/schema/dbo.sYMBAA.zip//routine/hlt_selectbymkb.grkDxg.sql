CREATE FUNCTION [dbo].[hlt_selectByMKB](@MKB_CODES VARCHAR(255)) 
RETURNS @rTable TABLE 
     ( 
     FullCode NVARCHAR(255) NOT NULL, 
     CodeMKB NVARCHAR(255) NOT NULL, 
     MKBID INT 
     ) 
AS 
BEGIN 
DECLARE @MKB VARCHAR(255),@MKB_DS VARCHAR(255),@MKB_ID INT,@MKB_NAME VARCHAR(255) 
SET @MKB=@MKB_CODES 
SET @MKB_CODES=LEFT(@MKB_CODES,LEN(@MKB_CODES)-1) 
---Операции выделения кодов мкб
     WHILE LEN(@MKB)>0 
                BEGIN 
                        IF ((CHARINDEX('-',@MKB COLLATE Cyrillic_General_CI_AS,1)>0) AND 
                                (CHARINDEX('-',@MKB COLLATE Cyrillic_General_CI_AS,1)<CHARINDEX(',',@MKB COLLATE Cyrillic_General_CI_AS,1))) 
                        BEGIN 
                                SET @MKB_DS=LEFT(@MKB,CHARINDEX('-',@MKB COLLATE Cyrillic_General_CI_AS)-1) 
                                DECLARE @betA VARCHAR(10),@betB VARCHAR(10); 
                                SET @betA=LEFT(@MKB,CHARINDEX('-',@MKB COLLATE Cyrillic_General_CI_AS)-1); 
                                SET @betB=SUBSTRING(@MKB,CHARINDEX('-',@MKB COLLATE Cyrillic_General_CI_AS)+1,CHARINDEX(',',@MKB COLLATE Cyrillic_General_CI_AS)-(CHARINDEX('-',@MKB COLLATE Cyrillic_General_CI_AS)+1)); 
                                INSERT INTO @rTable(FullCode,CodeMKB,MKBID) 
                                SELECT @MKB_CODES,OMS_MKB.DS,OMS_MKB.MKBID 
                                FROM OMS_MKB 
                                WHERE DS BETWEEN @betA and (@betB+'.99') 
                        END 
                        ELSE 
                        BEGIN 
                                SET @MKB_DS=LEFT(@MKB,CHARINDEX(',',@MKB COLLATE Cyrillic_General_CI_AS)-1); 
                                IF LEN(@MKB_DS)=0 BEGIN SET @MKB_DS=@MKB END; 
                                --SET @MKB_ID=(SELECT TOP 1 MKBID FROM dbo.oms_MKB WHERE oms_mkb.DS=@MKB_DS); 
                                --INSERT INTO @rTable VALUES(@MKB_CODES,@MKB_DS,@MKB_ID) 

                                INSERT INTO @rTable(FullCode,CodeMKB,MKBID) 
                                SELECT @MKB_CODES,OMS_MKB.DS,OMS_MKB.MKBID 
                                FROM OMS_MKB 
                                WHERE DS BETWEEN @MKB_DS and (@MKB_DS+'.99') 
                        END 
                            SET @MKB=REPLACE(@MKB,LEFT(@MKB,CHARINDEX(',',@MKB COLLATE Cyrillic_General_CI_AS)),'') 
          END 
RETURN 
END
go

