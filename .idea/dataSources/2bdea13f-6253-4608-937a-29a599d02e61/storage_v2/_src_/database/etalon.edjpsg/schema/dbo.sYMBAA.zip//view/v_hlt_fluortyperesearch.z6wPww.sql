CREATE VIEW [V_hlt_FluorTypeResearch] AS SELECT 
[hDED].[FluorTypeResearchID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Dose] as [Dose], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_FluorTypeResearch] as [hDED]
go

