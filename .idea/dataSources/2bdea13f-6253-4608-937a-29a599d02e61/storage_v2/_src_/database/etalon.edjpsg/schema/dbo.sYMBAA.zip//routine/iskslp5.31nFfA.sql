
CREATE FUNCTION [dbo].[IsKSLP5](@ListOper varchar(max), @ListSh varchar(max))

RETURNS  [integer]
AS
begin
declare @var1 int
declare @var2 int
declare @var3 int
declare @var4 int
select @var1 =count(distinct Op), @var2=max(tp), @var3=count(distinct tp)  from 
(select t.Item Op from dbo.TableFromString(@ListOper,',') t
 ) z  inner join 
 (
 select rf_OperationServiceMedicalID opid, tp from (
 --вся ID лучевая терапия
(
select distinct  rf_OperationServiceMedicalID, '1' as tp from oms_ExpertKSG
inner join oms_ServiceMedical ksg on ksg.ServiceMedicalID = rf_KSGServiceMedicalID
where oms_ExpertKSG.date_E>getdate() and  ksg.ServiceMedicalCode like 'S18116[012]' 
union
--вся id хирургическ. вмешательства
select distinct rf_OperationServiceMedicalID, '0' as tp from oms_ExpertKSG
inner join oms_ServiceMedical ksg on ksg.ServiceMedicalID = rf_KSGServiceMedicalID
where oms_ExpertKSG.date_E>getdate() and  (ksg.ServiceMedicalCode like 'S18111[789]'  or ksg.ServiceMedicalCode like 'S1811[23][0123456789]' or ksg.ServiceMedicalCode like 'S18114[0123]' ) and  ksg.ServiceMedicalCode not in ('S181138')
)


)  all_op 
) all_op on Op=OpId

if(@var3>1) return 1
if(@var1>1 and @var2>0) return 1


select @var4 =count(distinct Sh)  from 
(select t.Item Sh from dbo.TableFromString(@ListSh,',') t
 ) z  inner join 

( select distinct  rf_ExpertKSGCriterionId from oms_ExpertKSG
inner join oms_ServiceMedical ksg on ksg.ServiceMedicalID = rf_KSGServiceMedicalID
where oms_ExpertKSG.date_E>getdate() and ( ksg.ServiceMedicalCode like 'S18114[6789]' or ksg.ServiceMedicalCode like 'S18115[012345]')
) t on rf_ExpertKSGCriterionId=Sh
if(@var4>1 or (@var1>0 and @var4>0)) return 1 


return 0

end
go

