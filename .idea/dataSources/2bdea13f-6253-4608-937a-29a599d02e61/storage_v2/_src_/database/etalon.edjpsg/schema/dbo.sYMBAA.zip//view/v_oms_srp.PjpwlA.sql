CREATE VIEW [V_oms_SRP] AS SELECT 
[hDED].[SRPID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_RLP] as [C_RLP], 
[hDED].[N_RAZD] as [N_RAZD], 
[hDED].[NAME_RAZD] as [NAME_RAZD], 
[hDED].[N_PRAZD] as [N_PRAZD], 
[hDED].[NAME_PRAZD] as [NAME_PRAZD], 
[hDED].[MSG_TEXT] as [MSG_TEXT]
FROM [oms_SRP] as [hDED]
go

