
CREATE FUNCTION dbo.hl7_GetPastMedical
(
	@DocumentGuid VARCHAR(100),
	@TemplateCode VARCHAR(50)
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE     @result  VARCHAR(max)
	DECLARE		@XmlData xml	
	SET @result = '' 
	
	SET @XmlData = 
		(select TOP(1) CONVERT(XML,mr.Data) from hlt_MedRecord mr 
			join hlt_BlankTemplate bt on mr.rf_BlankTemplateID = bt.BlankTemplateID
		where bt.Code = @TemplateCode AND mr.DescGuid = @DocumentGuid )

	DECLARE @text VARCHAR(MAX)
	SET @text = 
'                                    <text>
                                        <table border="1">
                                            <thead>
                                                <tr>
                                                    <th>Дата</th>
                                                    <th>Обстоятельства перенесенного заболевания</th>
                                                    <th>Диагноз</th>
                                                </tr>
                                            </thead>
                                            <tbody>'

	DECLARE @I INT
	SET @I = 1


		WHILE (@I <= 3)
			BEGIN
				DECLARE @MKBID VARCHAR(100)
				SET @MKBID = dbo.GetInstanseId(@XmlData,'rcDisease'+CONVERT(VARCHAR,@I))
							
				IF NOT(@MKBID = '' OR  @MKBID = '0' OR dbo.GetValueFromXMl(@XmlData,'DateStartDisease'+CONVERT(VARCHAR,@I)) = '')
				BEGIN

				SET @text = @text + '
                                                <tr>
                                                    <td align="center">'+CONVERT(VARCHAR,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateStartDisease'+CONVERT(VARCHAR,@I)),104),105)+
				 CASE WHEN (dbo.GetValueFromXMl(@XmlData,'DateEndDisease'+CONVERT(VARCHAR,@I)) != '') THEN ' - ' + CONVERT(VARCHAR,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateEndDisease'+CONVERT(VARCHAR,@I)),104),105) ELSE '' END +'</td>
                                                    <td align="center">'+dbo.GetValueFromXMl(@XmlData,'TextCircumstancesDisease'+CONVERT(VARCHAR,@I))+'</td>
                                                    <td align="center">'+dbo.GetValueFromXMl(@XmlData,'rcDisease'+CONVERT(VARCHAR,@I))+'</td>
                                                </tr>'


				DECLARE @CODE_MKB VARCHAR(50)
				SET @CODE_MKB = (SELECT DS FROM oms_MKB WHERE MKBID = @MKBID)
				
				DECLARE @DATE_END VARCHAR(50)
				SET @DATE_END = dbo.GetValueFromXMl(@XmlData,'DateEndDisease'+CONVERT(VARCHAR,@I))

				IF (@DATE_END != '' )												
					SET @DATE_END = 'value="'+replace(replace(replace(convert(varchar,CONVERT(DATETIME,@DATE_END,104),120),'-',''),':',''),' ','') +'"'
				ELSE SET @DATE_END = 'nullFlavor="NA"'

				DECLARE @CODE VARCHAR(10)
				SET @CODE = dbo.GetValueFromXMl(@XmlData,'CodeCircumstancesDisease'+CONVERT(VARCHAR,@I))

				SET @result = @result + '
                                    <entry>
                                        <templateId root="1.2.643.5.1.13.2.7.5.4.7"/>
                                        <organizer classCode="BATTERY" moodCode="EVN">
                                            <templateId root="1.2.643.5.1.13.2.7.5.3.12"/>
                                            <code code="PRVDS" codeSystem="1.2.643.5.1.13.2.7.1.12" codeSystemName="Система кодирования событий" displayName="Перенесенное заболевание"/>
                                            <statusCode code="completed"/>
                                            <effectiveTime>
                                                <low value="'+replace(replace(replace(convert(varchar,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateStartDisease'+CONVERT(VARCHAR,@I)),104),120),'-',''),':',''),' ','')+'"/>
                                                <high '+ @DATE_END +'/>
                                            </effectiveTime>'
										IF @CODE != '0' AND @CODE != ''
											SET @result = @result + 
'
                                            <subject>
                                                <relatedSubject classCode="PRS">
                                                    <code code="'+@CODE+'" codeSystem="1.2.643.5.1.13.2.7.1.58" codeSystemName="Обстоятельства перенесенного заболевания" displayName="'+dbo.GetValueFromXMl(@XmlData,'TextCircumstancesDisease'+CONVERT(VARCHAR,@I))+'"/>
                                                </relatedSubject>
                                            </subject>'
										SET @result = @result +'
                                            <component typeCode="COMP">
                                                <observation classCode="OBS" moodCode="EVN">
                                                    <code code="'+(SELECT dbo.GetCatalogCode('1.2.643.5.1.13.2.1.1.641',@CODE_MKB,@CODE_MKB))+'" codeSystem="1.2.643.5.1.13.2.1.1.641" codeSystemName="Международная классификация болезней и состояний, связанных со здоровьем, Десятого пересмотра. Версия 2" displayName="'+(SELECT dbo.GetCatalogValue('1.2.643.5.1.13.2.1.1.641',@CODE_MKB,(SELECT replace(NAME,'"','&quot;') FROM oms_MKB WHERE MKBID = @MKBID)))+'"/>
                                                </observation>
                                            </component>
                                        </organizer>
                                    </entry>'
					END
			 SET @I = @I + 1
			END
	
	IF (ISNULL(@result,'') = '')
		RETURN NULL

	SET @text = @text  +
'
                                            </tbody>
                                        </table>
                                    </text>'
	RETURN @text + @result
END
go

