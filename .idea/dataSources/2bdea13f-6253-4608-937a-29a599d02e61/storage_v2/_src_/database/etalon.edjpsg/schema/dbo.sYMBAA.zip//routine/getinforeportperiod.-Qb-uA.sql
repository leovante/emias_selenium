

CREATE FUNCTION [dbo].[GetInfoReportPeriod](@id int)
RETURNS @InfoReportPeriod TABLE (
	[Наименование] [varchar](255),
	
	[Амбулатория пациенты] [int] NULL,
 --   [Амбулатория услуги]   [int] NULL,
    [Амбулатория случаев]  [int] NULL,
    [Амбулатория Сумма]    varchar(30),
    
	[Стационар пациенты] [int] NULL,
--	[Стационар услуги]   [int] NULL,
	[Стационар случаи]   [int] NULL,
	[Стационар сумма]   varchar(30),  
	
	[Дневной стационар пациенты] [int] NULL,
	--[Дневной стационар услуги]   [int] NULL,
	[Дневной стационар случаи]   [int] NULL,
	[Дневной стационар сумма]   varchar(30),  
	
    [Скорая помощь пациенты] [int] NULL,
	--[Скорая помощь услуги]   [int] NULL,
	[Скорая помощь случаи]   [int] NULL,
	[Скорая помощь сумма]   varchar(30)
    
    
    
)
AS
begin
INSERT INTO @InfoReportPeriod




select SMO, Amb_P, Amb_S, replace(replace(convert(varchar(30), cast( replace([Amb_Sum] , ',', '.') as money), 1),  ',', ' '), '.', ',') as Amb_Sum , 
St_P, St_S,      replace(replace(convert(varchar(30), cast( replace([ST_Sum] , ',', '.') as money), 1),  ',', ' '), '.', ',') as  St_Sum, 
DS_P,  DS_S,  replace(replace(convert(varchar(30), cast( replace([DS_Sum] , ',', '.') as money), 1),  ',', ' '), '.', ',') as DS_Sum,	 
SP_P,  SP_S,  replace(replace(convert(varchar(30), cast( replace([SP_Sum] , ',', '.') as money), 1),  ',', ' '), '.', ',') as SP_Sum
from (
select 1 as tp,Num, Smo, Rem_,  Sum(Amb_P) Amb_P,   Sum(Amb_S) Amb_S,      Sum(Amb_Sum) Amb_Sum, 
								Sum(St_P) as St_P,  Sum(St_S) as St_S,     Sum(St_Sum) as St_Sum,
								Sum(Ds_P) as DS_P,  Sum(DS_S) as DS_S,     Sum(DS_Sum) as DS_Sum,
								Sum(SP_P) as SP_P,  Sum(SP_S) as SP_S,     Sum(SP_Sum) as SP_Sum
from (
select 
case when v_cod=-1 then 10000 
     when OtherTerFlag=1 then -2
     when rf_SMOID =0    then -1
else rf_SMOID end as Num, 
case when v_cod=-1 then 'ИТОГО' 
     when OtherTerFlag=1 then 'Иногородние'
     when rf_SMOID =0    then 'Не идентифицированные'
else SILENT_rf_SMOID end as SMO, 
case when v_cod=-1 then 'Итого ' 
     when OtherTerFlag=1 then 'Иногородние'
     when rf_SMOID =0    then 'Итого по не идентифицированным'
else Rem end as Rem_,V_hlt_ViewExpert.*

 from V_hlt_ViewExpert
inner join oms_SMO on SMOid = rf_SMOID
where V_hlt_ViewExpert.flags=-3 and dep_name ='' and rf_ReportPeriodId =@id
) AllPeriod 
group by Rem_, Num, Smo
union all
select 2 as tp,Num, Smo, Rem_, Sum(Amb_P) Amb_P,   Sum(Amb_S) Amb_S,      Sum(Amb_Sum) Amb_Sum, 
								Sum(St_P) as St_P,  Sum(St_S) as St_S,     Sum(St_Sum) as St_Sum,
								Sum(Ds_P) as DS_P,  Sum(DS_S) as DS_S,     Sum(DS_Sum) as DS_Sum,
								Sum(SP_P) as SP_P,  Sum(SP_S) as SP_S,     Sum(SP_Sum) as SP_Sum
from (
select 
case when v_cod=-1 then 10000 
     when OtherTerFlag=1 then -2
     when rf_SMOID =0    then -1
else rf_SMOID end as Num, 
case when v_cod=-1 then '  в том числе Итого ошибок' 
     when OtherTerFlag=1 then '  в том числе ошибок по Иногородним'
     when rf_SMOID =0    then '  в том числе ошибок по Не идентифицированным'
else '  в том числе ошибок по ' +SILENT_rf_SMOID end as SMO, 
case when v_cod=-1 then '  в том числе Итого ошибок по ' 
     when OtherTerFlag=1 then '  в том числе ошибок по Иногородним'
     when rf_SMOID =0    then '  в том числе ошибок по Не идентифицированным'
else Rem end as Rem_,V_hlt_ViewExpert.*

 from V_hlt_ViewExpert
inner join oms_SMO on SMOid = rf_SMOID
where V_hlt_ViewExpert.flags=-1 and dep_name ='' and rf_ReportPeriodId =@id
) AllPeriod 
group by Rem_, Num, Smo
) k
order by Num, tp
return
end

go

