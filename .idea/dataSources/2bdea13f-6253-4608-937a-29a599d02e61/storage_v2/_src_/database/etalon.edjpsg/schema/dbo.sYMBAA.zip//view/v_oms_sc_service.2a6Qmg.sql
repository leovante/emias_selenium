CREATE VIEW [V_oms_sc_Service] AS SELECT 
[hDED].[sc_ServiceID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_kl_NomService].[Name] as [V_Name], 
[hDED].[rf_kl_NomServiceID] as [rf_kl_NomServiceID], 
[jT_oms_kl_NomService].[Code] as [SILENT_rf_kl_NomServiceID], 
[hDED].[rf_sc_StandartCureID] as [rf_sc_StandartCureID], 
[jT_oms_sc_StandartCure].[StandartName] as [SILENT_rf_sc_StandartCureID], 
[hDED].[rf_sc_ServiceTypeID] as [rf_sc_ServiceTypeID], 
[jT_oms_sc_ServiceType].[Name] as [SILENT_rf_sc_ServiceTypeID], 
[hDED].[Frequency] as [Frequency], 
[hDED].[AverageCount] as [AverageCount], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_sc_Service] as [hDED]
INNER JOIN [oms_kl_NomService] as [jT_oms_kl_NomService] on [jT_oms_kl_NomService].[kl_NomServiceID] = [hDED].[rf_kl_NomServiceID]
INNER JOIN [oms_sc_StandartCure] as [jT_oms_sc_StandartCure] on [jT_oms_sc_StandartCure].[sc_StandartCureID] = [hDED].[rf_sc_StandartCureID]
INNER JOIN [oms_sc_ServiceType] as [jT_oms_sc_ServiceType] on [jT_oms_sc_ServiceType].[sc_ServiceTypeID] = [hDED].[rf_sc_ServiceTypeID]
go

