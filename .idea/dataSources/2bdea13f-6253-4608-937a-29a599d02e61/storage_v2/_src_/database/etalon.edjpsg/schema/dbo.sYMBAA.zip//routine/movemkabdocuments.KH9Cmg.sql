
CREATE PROCEDURE [dbo].[MoveMkabDocuments] 
	-- Add the parameters for the stored procedure here
	@mkabFrom int = 0, 
	@mkabTo int = 0
AS
BEGIN
	-- =============================================
	-- Author: Пищулин Игорь
	-- Editor: Крысов Алексей	
	-- =============================================
	
	--получаем гуиды мкабов
	declare @mkabguidfrom uniqueidentifier
	declare @mkabguidto uniqueidentifier
	select @mkabguidfrom = case mkabid when @mkabFrom then uguid else @mkabguidfrom end,@mkabguidto = case mkabid when @mkabTo then uguid else @mkabguidto end from hlt_MKAB where mkabid in(@mkabFrom,@mkabTo)
	-- в переменных теперь гуиды

	--получаем идентификатор документа МКАБ
	declare @mkabdtid int
	select @mkabdtid = DocTypeDefID from x_DocTypeDef where HeadTable = 'hlt_mkab'
	--

	--строим запросы по ссылающимся полям
	declare @sql varchar(max)
	select @sql = STUFF(
                        (select 'update ' + dt.HeadTable +' set '+ de.FieldName + '=' + 
	 case when de.SqlDataType = 'uniqueidentifier' then ''''+convert(varchar(40), @mkabguidto)+'''' else convert(varchar(15), @mkabTo) end +
	' where ' + de.FieldName + '=' + 
	 case when de.SqlDataType = 'uniqueidentifier' then ''''+convert(varchar(40), @mkabguidfrom)+'''' else convert(varchar(15), @mkabfrom) end + ';' from x_DocElemDef de
	join x_DocElemDef linkde on de.LinkedDocElemDefID = linkde.DocElemDefID
	join x_DocTypeDef dt on de.DocTypeDefID = dt.DocTypeDefID
	where de.LinkedDocTypeDefID = @mkabdtid and de.ElemType = 2 --srv
	for xml path(''))
                        , 1
                        , 0
                        , '')

	exec(@sql)
	--

	/* корректируем hlt_PolisMKAB, проставляем ссылки из ТАП на один PolisMKAB */

		declare @tmpPolises table([count] int, spol varchar(100), npol varchar(100), mkabid int)
		insert into @tmpPolises ([count], spol, npol, mkabid)
			select COUNT(1) as [count], p.S_POL as spol, p.N_POL as npol, p.rf_MKABID as mkabid from hlt_PolisMKAB p
		where p.PolisMKABID > 0 and p.rf_MKABID = @mkabTo
		group by p.S_POL, p.N_POL, p.rf_MKABID having COUNT(1) > 1
		--select * from @tmpPolises

		declare @tmpPolisesDouble table(id int)
		declare @firstPolisMkabId int

		declare @rank int,
			@spol varchar(100), @npol varchar(100), @mkabid int
		declare rank_cursor cursor
		for select spol, npol, mkabid
			from @tmpPolises
		open rank_cursor
			fetch next from rank_cursor into @spol, @npol, @mkabid
			set @rank = 1
			while (@@fetch_status <> -1)
			begin
				--select @rank, @spol, @npol, @mkabid
				set @rank = @rank + 1

					delete from @tmpPolisesDouble
					insert into @tmpPolisesDouble(id)
						select PolisMKABID from hlt_PolisMKAB where PolisMKABID > 0 and rf_MKABID = @mkabid and S_POL = @spol and N_POL = @npol
									--select * from @tmpPolisesDouble
					set @firstPolisMkabId = (select top 1 id from @tmpPolisesDouble)
									--select @firstPolisMkabId

					update hlt_TAP
					set rf_PolisMKABID = @firstPolisMkabId
					where TAPID > 0 and rf_PolisMKABID in (select id from @tmpPolisesDouble)

					delete from hlt_PolisMKAB
					where PolisMKABID > 0
					and PolisMKABID in (select id from @tmpPolisesDouble)
					and PolisMKABID != @firstPolisMkabId
					and rf_MKABID = @mkabid and S_POL = @spol and N_POL = @npol	
			
					delete from @tmpPolisesDouble
				fetch next from rank_cursor into @spol, @npol, @mkabid
			end
		close rank_cursor
		deallocate rank_cursor

	/* end of: корректируем hlt_PolisMKAB, проставляем ссылки из ТАП на один PolisMKAB */
END
go

