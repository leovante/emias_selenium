CREATE VIEW [V_stt_Ambulance] AS SELECT 
[hDED].[AmbulanceID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Flag] as [Flag], 
[hDED].[COD] as [COD], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_Ambulance] as [hDED]
go

