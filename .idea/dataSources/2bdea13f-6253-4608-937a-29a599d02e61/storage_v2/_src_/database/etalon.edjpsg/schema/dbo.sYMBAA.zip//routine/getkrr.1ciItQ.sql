
create FUNCTION [dbo].[GetKRR](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int,
@prervxml varchar(max)
)
RETURNS @result TABLE (
vidID int,
info varchar(max),
[Value] [decimal](38, 6) NULL

)
AS
begin
Declare @xml xml
declare @Sh varchar(max)
declare @Op varchar(max)
declare @DopDS varchar(max)
declare @prerv varchar(10)
set @xml =convert(xml,@prervxml)

set @Sh=''
set @Op=''
set @DopDs=''
set @prerv=''

select  @Sh= t.x.value('@Sh[1]',  'varchar(max)'),
@Op=t.x.value('@Op[1]',  'varchar(max)')
from @xml.nodes('/a') t(x) 

select  @DopDs=t.x.value('@DopDS[1]',  'varchar(max)')
from @xml.nodes('/b') t(x) 

/*select  top 1 @prerv=Code
 from (
select t.x.value('@dateOut[1]',  'datetime') as Dt, 
  t.x.value('@rf_kl_DepartmentTypeId[1]', 'int') as DepartementTypeID,
  t.x.value('@rf_lpuid[1]', 'int') as lpuid,
  t.x.value('@rf_kl_DepartmentProfileID[1]','int') as DepartementProfileID,
  t.x.value('@Code[1]','varchar') as Code
from   @xml.nodes('/Prerv ') as t(x)
  )t 
where lpuid=@lpuid and @profileId =DepartementProfileID and DepartementTypeID=@typeid
*/

INSERT INTO @result
select (select krrVidId from oms_krrvid where vidK_Code ='KR1'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR1' and @age<1  and  @usl1  not in ('S181107','S181108','S181109','S181110','S181111','S181112','S181113')
     and @usl1  not like '%[-]%' union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR2'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR2' and @age<=3 and @age >=1 and @typeid=rf_kl_DepartmentTypeid 
     and @usl1  not like '%[-]%'
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='КороткОп'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='КороткОп' and @typeid=rf_kl_DepartmentTypeid and @usl1 not in (
'S181002','S181003','S181004','S181005','S181011','S181012','S181016','S181086','S181314','S181146','S181147','S181148','S181149','S181150','S181151','S181152','S181153',
'S181154','S181155','S181159','S181099','S181157','S181167','S181168','S181172','S181173','S181174','S181198','S181219','S181271','S181301','S181316','S181320',
'S182001','S182003','S182004','S182038','S182118','S182054','S182055','S182056','S182057','S182058','S182059','S182060','S182061','S182039','S182063','S182065','S182066',
'S182069','S182071','S182072','S182084','S182112','S182121'
)  and  @dlit<=3 and @usl2 like 'A16.%'
     and @usl1  not like '%[-]%'
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='Коротк'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='Коротк' and @typeid=rf_kl_DepartmentTypeid and @usl1 not in (
'S181002','S181003','S181004','S181005','S181011','S181012','S181016','S181086','S181314','S181146','S181147','S181148','S181149','S181150','S181151','S181152','S181153',
'S181154','S181155','S181159','S181099','S181157','S181167','S181168','S181172','S181173','S181174','S181198','S181219','S181271','S181301','S181316','S181320',
'S182001','S182003','S182004','S182038','S182118','S182054','S182055','S182056','S182057','S182058','S182059','S182060','S182061','S182039','S182063','S182065','S182066',
'S182069','S182071','S182072','S182084','S182112','S182121'
)  and  @dlit<=3 and @usl2 not like 'A%'

     and @usl1  not like '%[-]%'
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='Длин'),'',0.75+ 0.25*@dlit/ 
case when @usl1 in      ('S181045','S181046','S181108','S181109','S181161','S181162','S181233','S181279','S181280','S181298') and @dlit > 45 then 45
     when @usl1 not in  ('S181045','S181046','S181108','S181109','S181161','S181162','S181233','S181279','S181280','S181298') and @dlit > 30 then 30
	 else @dlit end
	 from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId   where    V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='Длин' and

( 
( @usl1 in      ('S181045','S181046','S181108','S181109','S181161','S181162','S181233','S181279','S181280','S181298') and @dlit > 45) or
( @usl1 not in  ('S181045','S181046','S181108','S181109','S181161','S181162','S181233','S181279','S181280','S181298') and @dlit > 30) 
)

 and V_oms_krr.rf_kl_DepartmentTypeId=@typeId
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='2'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  inner join oms_lpu on lpuid =@LPUID 
	 where  V_oms_krr.rf_LPUID in( @LPUID, rf_mainLPUID) and  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='2' 
	 and @usl1  not in  ('S181017','S181030','S181086','S181097','S181172','S181208','S181210',
     'S181212','S181213','S181217','S181243','S181256','S181266','S181272',
     'S181284','S181285','S181286','S181287','S181288','S181314','S181316','S181320' ) 
     and @usl1  not like '%[-]%'
     and @typeid=rf_kl_DepartmentTypeid
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='1'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='1' and @typeid=rf_kl_DepartmentTypeid and @usl1  not like '%[-]%'
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR3'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR3' and @age>=75 and @usl1 <>  'S181339' and @typeid=rf_kl_DepartmentTypeid union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR4'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR4' and @typeid=rf_kl_DepartmentTypeid and dbo.IsPathology(@DopDS)>0  union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR5'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR5' and @typeid=rf_kl_DepartmentTypeid and dbo.IsKSLP5(@Op,@Sh )>0  
 
 
 
 declare @info varchar(max)
 set @info=''
declare @vidKR1 decimal(18,6) set @vidKR1= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR1' and @age<1  and  @usl1  not in ('S181107','S181108','S181109','S181110','S181111','S181112','S181113')
     and @usl1  not like '%[-]%'),0) 
 
 if (@vidKR1>0) set @info= @info +' KR1='+convert(varchar(30),@vidKR1)
 
  declare @vidKR2 decimal(18,6) set @vidKR2= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR2' and @age<=3 and @age >=1 and @typeid=rf_kl_DepartmentTypeid 
     and @usl1  not like '%[-]%'
),0) 
 
 if (@vidKR2>0) set @info= @info +' KR2='+convert(varchar(30),@vidKR2)
 
  declare @vidКороткОп decimal(18,6) set @vidКороткОп= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='КороткОп' and @typeid=rf_kl_DepartmentTypeid and @usl1 not in (
'S181002','S181003','S181004','S181005','S181011','S181012','S181016','S181086','S181314','S181146','S181147','S181148','S181149','S181150','S181151','S181152','S181153',
'S181154','S181155','S181159','S181099','S181157','S181167','S181168','S181172','S181173','S181174','S181198','S181219','S181271','S181301','S181316','S181320',
'S182001','S182003','S182004','S182038','S182118','S182054','S182055','S182056','S182057','S182058','S182059','S182060','S182061','S182039','S182063','S182065','S182066',
'S182069','S182071','S182072','S182084','S182112','S182121'
)  and  @dlit<=3 and @usl2 like 'A16.%'
     and @usl1  not like '%[-]%'
),0) 
 
 if (@vidКороткОп>0) set @info= @info +' КороткОп='+convert(varchar(30),@vidКороткОп)
 
  declare @vidКоротк decimal(18,6) set @vidКоротк= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='Коротк' and @typeid=rf_kl_DepartmentTypeid and @usl1 not in (
'S181002','S181003','S181004','S181005','S181011','S181012','S181016','S181086','S181314','S181146','S181147','S181148','S181149','S181150','S181151','S181152','S181153',
'S181154','S181155','S181159','S181099','S181157','S181167','S181168','S181172','S181173','S181174','S181198','S181219','S181271','S181301','S181316','S181320',
'S182001','S182003','S182004','S182038','S182118','S182054','S182055','S182056','S182057','S182058','S182059','S182060','S182061','S182039','S182063','S182065','S182066',
'S182069','S182071','S182072','S182084','S182112','S182121'
)  and  @dlit<=3 and @usl2 not like 'A%'

     and @usl1  not like '%[-]%'
),0) 
 
 if (@vidКоротк>0) set @info= @info +' Коротк='+convert(varchar(30),@vidКоротк)
 
  declare @vidДлин decimal(18,6) set @vidДлин= isnull((select 0.75+ 0.25*@dlit/ 
case when @usl1 in      ('S181045','S181046','S181108','S181109','S181161','S181162','S181233','S181279','S181280','S181298') and @dlit > 45 then 45
     when @usl1 not in  ('S181045','S181046','S181108','S181109','S181161','S181162','S181233','S181279','S181280','S181298') and @dlit > 30 then 30
	 else @dlit end
	 from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId   where    V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='Длин' and

( 
( @usl1 in      ('S181045','S181046','S181108','S181109','S181161','S181162','S181233','S181279','S181280','S181298') and @dlit > 45) or
( @usl1 not in  ('S181045','S181046','S181108','S181109','S181161','S181162','S181233','S181279','S181280','S181298') and @dlit > 30) 
)

 and V_oms_krr.rf_kl_DepartmentTypeId=@typeId
),0) 
 
 if (@vidДлин>0) set @info= @info +' Длин='+convert(varchar(30),@vidДлин)
 
  declare @vid2 decimal(18,6) set @vid2= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  inner join oms_lpu on lpuid =@LPUID 
	 where  V_oms_krr.rf_LPUID in( @LPUID, rf_mainLPUID) and  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='2' 
	 and @usl1  not in  ('S181017','S181030','S181086','S181097','S181172','S181208','S181210',
     'S181212','S181213','S181217','S181243','S181256','S181266','S181272',
     'S181284','S181285','S181286','S181287','S181288','S181314','S181316','S181320' ) 
     and @usl1  not like '%[-]%'
     and @typeid=rf_kl_DepartmentTypeid
),0) 
 
 if (@vid2>0) set @info= @info +' 2='+convert(varchar(30),@vid2)
 
  declare @vid1 decimal(18,6) set @vid1= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='1' and @typeid=rf_kl_DepartmentTypeid and @usl1  not like '%[-]%'
),0) 
 
 if (@vid1>0) set @info= @info +' 1='+convert(varchar(30),@vid1)
 
  declare @vidKR3 decimal(18,6) set @vidKR3= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR3' and @age>=75 and @usl1 <>  'S181339' and @typeid=rf_kl_DepartmentTypeid),0) 
 
 if (@vidKR3>0) set @info= @info +' KR3='+convert(varchar(30),@vidKR3)
 
  declare @vidKR4 decimal(18,6) set @vidKR4= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR4' and @typeid=rf_kl_DepartmentTypeid and dbo.IsPathology(@DopDS)>0 ),0) 
 
 if (@vidKR4>0) set @info= @info +' KR4='+convert(varchar(30),@vidKR4)
 
  declare @vidKR5 decimal(18,6) set @vidKR5= isnull((select valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR5' and @typeid=rf_kl_DepartmentTypeid and dbo.IsKSLP5(@Op,@Sh )>0 ),0) 
 
 if (@vidKR5>0) set @info= @info +' KR5='+convert(varchar(30),@vidKR5)
 
 
  return end
go

