CREATE VIEW [V_oms_sc_Phase] AS SELECT 
[hDED].[sc_PhaseID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_kl_Phase].[Name] as [V_Name], 
[hDED].[rf_sc_StandartCureID] as [rf_sc_StandartCureID], 
[hDED].[rf_kl_PhaseID] as [rf_kl_PhaseID], 
[jT_oms_kl_Phase].[Name] as [SILENT_rf_kl_PhaseID], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_sc_Phase] as [hDED]
INNER JOIN [oms_kl_Phase] as [jT_oms_kl_Phase] on [jT_oms_kl_Phase].[kl_PhaseID] = [hDED].[rf_kl_PhaseID]
go

