
Create FUNCTION [dbo].[GetParamByMH](@mhid int)
RETURNS varchar(max)
AS
begin
return  Replace(

'<a Sh ="'+
isnull(
(select distinct  convert(varchar(100),rf_ExpertKSGCriterionID)+',' as 'data()' from stt_MigrationPatient Sh
where rf_ExpertKSGCriterionID>0 and rf_MedicalHistoryId=@mhid
for xml path('')) ,'')+'" Op="' +
isnull((select distinct convert(varchar(100),rf_ServiceMedicalID)+',' as 'data()' from stt_MedServicePatient Operation
where rf_ServiceMedicalID>0 and rf_MedicalHistoryId=@mhid
for xml path('') ),'')+'"/>',',"','"')

 end
go

