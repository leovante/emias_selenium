CREATE VIEW [V_oms_sr_MessRecord] AS SELECT 
[hDED].[sr_MessRecordID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_sr_Message].[V_Rem] as [V_V_Rem], 
[jT_oms_sr_Message].[MessageInfo] as [V_MessageInfo], 
[jT_oms_sr_Message].[Rem] as [V_Rem], 
[jT_oms_sr_Message].[DateMess] as [V_DateMess], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[jT_oms_Tender].[Num] as [SILENT_rf_TenderID], 
[hDED].[rf_ProtokolID] as [rf_ProtokolID], 
[jT_oms_Protokol].[Num] as [SILENT_rf_ProtokolID], 
[hDED].[rf_sr_MessageID] as [rf_sr_MessageID], 
[jT_oms_sr_Message].[MessageInfo] as [SILENT_rf_sr_MessageID], 
[hDED].[rf_PurchaseRequisitionID] as [rf_PurchaseRequisitionID], 
[jT_oms_PurchaseRequisition].[rf_ProtokolID] as [SILENT_rf_PurchaseRequisitionID], 
[hDED].[Code] as [Code], 
[hDED].[Num] as [Num], 
[hDED].[NameVar] as [NameVar], 
[hDED].[Value] as [Value], 
[hDED].[LotGuid] as [LotGuid], 
[hDED].[XmlRec] as [XmlRec], 
[hDED].[Flags] as [Flags]
FROM [oms_sr_MessRecord] as [hDED]
INNER JOIN [V_oms_sr_Message] as [jT_oms_sr_Message] on [jT_oms_sr_Message].[sr_MessageID] = [hDED].[rf_sr_MessageID]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
INNER JOIN [oms_Tender] as [jT_oms_Tender] on [jT_oms_Tender].[TenderID] = [hDED].[rf_TenderID]
INNER JOIN [oms_Protokol] as [jT_oms_Protokol] on [jT_oms_Protokol].[ProtokolID] = [hDED].[rf_ProtokolID]
INNER JOIN [oms_PurchaseRequisition] as [jT_oms_PurchaseRequisition] on [jT_oms_PurchaseRequisition].[PurchaseRequisitionID] = [hDED].[rf_PurchaseRequisitionID]
go

