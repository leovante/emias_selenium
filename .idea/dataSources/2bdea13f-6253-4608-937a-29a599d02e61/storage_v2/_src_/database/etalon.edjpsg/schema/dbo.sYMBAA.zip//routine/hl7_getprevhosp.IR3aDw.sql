
CREATE FUNCTION dbo.hl7_GetPrevHosp
(
	@DocumentGuid VARCHAR(100),
	@TemplateCode VARCHAR(50)
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE     @result  VARCHAR(max)
	DECLARE		@XmlData xml	
	SET @result = '' 
	
	SET @XmlData = 
		(select TOP(1) CONVERT(XML,mr.Data) from hlt_MedRecord mr 
			join hlt_BlankTemplate bt on mr.rf_BlankTemplateID = bt.BlankTemplateID
		where bt.Code = @TemplateCode AND mr.DescGuid = @DocumentGuid )

	DECLARE @text VARCHAR(MAX)
	SET @text = 
'                                    <text>
                                        <table border="1">
                                            <thead>
                                                <tr>
                                                    <th>Дата госпитализации</th>
                                                    <th>Дата Выписки</th>
                                                    <th>Учреждение</th>
                                                    <th>Cведения о предыдущей госпитализации</th>
                                                </tr>
                                            </thead>
                                            <tbody>'


	DECLARE @I INT
	SET @I = 1
		WHILE (@I <= 3)
			BEGIN


				DECLARE @LPUID VARCHAR(100)
				SET @LPUID = dbo.GetInstanseId(@XmlData,'rcHosp'+CONVERT(VARCHAR,@I))	
							
				IF NOT((@LPUID = '' OR @LPUID = '0' OR  dbo.GetValueFromXMl(@XmlData,'DateStartHosp'+CONVERT(VARCHAR,@I)) = ''))
				BEGIN
				DECLARE @CODE_LPU VARCHAR(50)
				SET @CODE_LPU = (SELECT MCOD FROM oms_LPU WHERE LPUID = @LPUID)

				SET @text = @text + '
                                                <tr>
                                                    <td align="center">'+CONVERT(VARCHAR,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateStartHosp'+CONVERT(VARCHAR,@I)),104),105)+'</td>
                                                    <td align="center">'+CONVERT(VARCHAR,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateEndHosp'+CONVERT(VARCHAR,@I)),104),105) + '</td>
                                                    <td align="center">'+(SELECT dbo.GetCatalogValue('1.2.643.5.1.13.2.1.1.178',@CODE_LPU,(SELECT replace(M_NAMES,'"','&quot;') FROM oms_LPU WHERE LPUID = @LPUID)))+'</td>
                                                    <td align="center">'+dbo.GetValueFromXMl(@XmlData,'DescHosp'+CONVERT(VARCHAR,@I))+'</td>
                                                </tr>'

				SET @result = @result +
				'
                                    <entry typeCode="COMP">
                                        <templateId root="1.2.643.5.1.13.2.7.5.4.3"/>
                                        <encounter classCode="ENC" moodCode="EVN">
                                            <templateId root="1.2.643.5.1.13.2.7.5.3.17" />
                                            <code code="PRVHOSP" codeSystem="1.2.643.5.1.13.2.7.1.12" codeSystemName="Система кодирования событий" displayName="Предыдущая госпитализация">
                                                <originalText>'+dbo.GetValueFromXMl(@XmlData,'DescHosp'+CONVERT(VARCHAR,@I))+'</originalText>
                                            </code>
                                            <statusCode code="completed"/>
                                            <effectiveTime>
                                                <low value="'+ replace(replace(replace(convert(varchar,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateStartHosp'+CONVERT(VARCHAR,@I)),104),120),'-',''),':',''),' ','') +'"/>
                                                <high value="'+ replace(replace(replace(convert(varchar,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateEndHosp'+CONVERT(VARCHAR,@I)),104),120),'-',''),':',''),' ','') +'"/>
                                            </effectiveTime>
                                            <performer typeCode="PRF">
                                                <assignedEntity>
                                                    <id root="1.2.643.5.1.13.3.25.34.98"/>
                                                        <representedOrganization classCode="ORG" determinerCode="INSTANCE">
                                                            <id root="'+(SELECT dbo.GetCatalogOID('1.2.643.5.1.13.2.1.1.178',@CODE_LPU,@CODE_LPU))+'"/>
                                                            <name>'+(SELECT dbo.GetCatalogValue('1.2.643.5.1.13.2.1.1.178',@CODE_LPU,(SELECT replace(M_NAMES,'"','&quot;') FROM oms_LPU WHERE LPUID = @LPUID)))+'</name>
                                                        </representedOrganization>
                                                </assignedEntity>
                                            </performer>
                                        </encounter>
                                    </entry>'
				END
				SET @I = @I + 1
			END

	IF (ISNULL(@result,'') = '')
		RETURN NULL

	SET @text = @text  +
'
                                            </tbody>
                                        </table>
                                    </text>'
	RETURN @text + @result
END
go

