CREATE function [dbo].[GetSmTalonLSFiltr]()
returns nvarchar(max)
as 
begin
return (select '[rf_FARGID] in (select [FARGID] from [V_oms_FARG] where [V_oms_FARG].[FNAME_FRG] like ''%противоопух%'' or [V_oms_FARG].[FNAME_FRG] like ''%Алкилир%'') or  rf_mnnameid in (select mnnameid from oms_mnname where c_mnn in(''2071'',''3392''))');
end;
go

