CREATE VIEW [V_web_RoleRoute] AS SELECT 
[hDED].[RoleRouteID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RouteGuid] as [rf_RouteGuid], 
[hDED].[rf_RoleGuid] as [rf_RoleGuid], 
[hDED].[Allow] as [Allow], 
[hDED].[Enabled] as [Enabled], 
[hDED].[Comment] as [Comment], 
[hDED].[Guid] as [Guid]
FROM [web_RoleRoute] as [hDED]
go

