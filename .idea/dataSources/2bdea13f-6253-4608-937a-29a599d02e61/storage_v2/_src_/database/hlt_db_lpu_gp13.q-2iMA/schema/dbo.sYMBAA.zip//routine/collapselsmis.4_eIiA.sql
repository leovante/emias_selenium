
CREATE PROCEDURE [dbo].[CollapseLsMis](@plusCode bigint, @minusCode bigint)
AS
BEGIN
	;
	DISABLE TRIGGER insert_LS_Finl ON oms_LS;
	DISABLE TRIGGER [LifeTrigger_stt_PurposeLS] on [stt_PurposeLS];
	DISABLE TRIGGER [LifeTrigger_stt_LSOutlay] on [stt_LSOutlay];
	DISABLE TRIGGER [LifeTrigger_hlt_FixedLS] on [hlt_FixedLS];
	DISABLE TRIGGER [LifeTrigger_hlt_LSPurpose] on [hlt_LSPurpose];
	if (select COUNT(1) from sys.triggers where name like '%insert_Nameless_LS%') = 1
		DISABLE TRIGGER insert_Nameless_LS ON oms_LS;	

	BEGIN TRY 
		declare @plusID int; --ID ЛС с положительным кодом
		select @plusID = LSID from oms_LS where NOMK_LS = @plusCode;
		declare @minusID int; --ID ЛС с отрицательным кодом
		select @minusID = LSID from oms_LS where NOMK_LS = @minusCode;

		declare @plusChar varchar(max)
		select @plusChar = CONVERT(varchar(max), @plusCode)
		
		declare @minusChar varchar(max)
		select @minusChar = CONVERT(varchar(max), @minusCode)
		
		--обрабатываем тематику STT
		update [stt_PurposeLS]
		set CodeRAS = @plusChar
		where PurposeLSID > 0 and [stt_PurposeLS].CodeRAS = @minusChar

		update [stt_LSOutlay]
		set CodeRAS = @plusChar
		where LSOutlayID > 0 and  [stt_LSOutlay].CodeRAS = @minusChar
	
		if (@plusID is not null and @minusID is not null)
		begin
			--обрабатываем тематику HLT
			update hlt_PolyclinicRecipeRegionLG
			set NOMK_LS = @plusCode
			where PolyclinicRecipeRegionLGID > 0 and NOMK_LS = @minusCode

			update hlt_PolyclinicRecipeFederalLG
			set NOMK_LS = @plusCode
			where PolyclinicRecipeFederalLGID > 0 and NOMK_LS = @minusCode
						
			exec  Ref_update 'OMS', 'rf_LSID%', @minusID, @plusID
			exec  Ref_update 'HEALTH', 'rf_LSID%', @minusID, @plusID
			exec  Ref_update 'STT', 'rf_LSID%', @minusID, @plusID
		end

		update oms_CollapseHistory 
			set 
				CollapseDate = GETDATE(),
				IsSuccessAu = 1
			where OldCode = @minusCode and NewCode = @plusCode
	END TRY
	BEGIN CATCH
		SELECT 
			ERROR_NUMBER() AS ErrorNumber,
			ERROR_MESSAGE() AS ErrorMessage;
	END CATCH

	;
	ENABLE TRIGGER insert_LS_Finl ON oms_LS;
	ENABLE TRIGGER [LifeTrigger_stt_PurposeLS] on [stt_PurposeLS];
	ENABLE TRIGGER [LifeTrigger_stt_LSOutlay] on [stt_LSOutlay];
	ENABLE TRIGGER [LifeTrigger_hlt_FixedLS] on [hlt_FixedLS];
	ENABLE TRIGGER [LifeTrigger_hlt_LSPurpose] on [hlt_LSPurpose];
	if (select COUNT(1) from sys.triggers where name like '%insert_Nameless_LS%') = 1
		ENABLE TRIGGER insert_Nameless_LS ON oms_LS;	
END
go

