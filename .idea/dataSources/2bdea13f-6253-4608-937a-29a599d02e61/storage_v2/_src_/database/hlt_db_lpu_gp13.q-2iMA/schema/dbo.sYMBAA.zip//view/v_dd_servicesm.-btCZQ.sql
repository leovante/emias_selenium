CREATE VIEW [V_dd_ServiceSM] AS SELECT 
[hDED].[ServiceSMID], [hDED].[x_Edition], [hDED].[x_Status], 
((SELECT CASE IsMain 
WHEN 1 THEN 'Да' 
ELSE 'Нет' END)) as [V_IsMain], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [V_ServiceMedicalName], 
[jT_dd_DDService].[DDServiceName] as [V_DDServiceName], 
[hDED].[rf_ServiceMedicalGUIDSM] as [rf_ServiceMedicalGUIDSM], 
[hDED].[rf_DDServiceUGUID] as [rf_DDServiceUGUID], 
[hDED].[rf_CategoryServiceUGUID] as [rf_CategoryServiceUGUID], 
[hDED].[Uguid] as [Uguid], 
[hDED].[Flags] as [Flags], 
[hDED].[IsMain] as [IsMain]
FROM [dd_ServiceSM] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[GUIDSM] = [hDED].[rf_ServiceMedicalGUIDSM]
INNER JOIN [dd_DDService] as [jT_dd_DDService] on [jT_dd_DDService].[UGUID] = [hDED].[rf_DDServiceUGUID]
go

