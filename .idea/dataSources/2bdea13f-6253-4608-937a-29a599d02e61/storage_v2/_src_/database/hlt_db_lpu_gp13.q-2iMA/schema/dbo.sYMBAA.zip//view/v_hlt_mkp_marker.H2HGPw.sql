CREATE VIEW [V_hlt_mkp_Marker] AS SELECT 
[hDED].[mkp_MarkerID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorGUID] as [rf_LPUDoctorGUID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorGUID], 
[hDED].[rf_mkp_CardGUID] as [rf_mkp_CardGUID], 
[hDED].[rf_mkp_TypeMarkerGUID] as [rf_mkp_TypeMarkerGUID], 
[jT_hlt_mkp_TypeMarker].[Name] as [SILENT_rf_mkp_TypeMarkerGUID], 
[hDED].[Date] as [Date], 
[hDED].[NoteText] as [NoteText], 
[hDED].[rf_ResearchResultGUID] as [rf_ResearchResultGUID], 
[hDED].[Flags] as [Flags], 
[hDED].[Result] as [Result], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_mkp_Marker] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[UGUID] = [hDED].[rf_LPUDoctorGUID]
INNER JOIN [hlt_mkp_TypeMarker] as [jT_hlt_mkp_TypeMarker] on [jT_hlt_mkp_TypeMarker].[UGUID] = [hDED].[rf_mkp_TypeMarkerGUID]
go

