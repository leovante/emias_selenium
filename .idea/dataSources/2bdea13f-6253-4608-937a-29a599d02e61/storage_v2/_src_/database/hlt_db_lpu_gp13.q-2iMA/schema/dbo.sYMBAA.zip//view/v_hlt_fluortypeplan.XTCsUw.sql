CREATE VIEW [V_hlt_FluorTypePlan] AS SELECT 
[hDED].[FluorTypePlanID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_FluorTypePlan] as [hDED]
go

