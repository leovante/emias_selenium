CREATE VIEW [V_vcn_Reason] AS SELECT 
[hDED].[ReasonID], [hDED].[x_Edition], [hDED].[x_Status], 
(GUID) as [V_ReasonGUID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[ShortName] as [ShortName], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[PlanFlag] as [PlanFlag], 
[hDED].[GUID] as [GUID]
FROM [vcn_Reason] as [hDED]
go

