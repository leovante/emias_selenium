CREATE VIEW [V_oms_TehAtrDataType] AS SELECT 
[hDED].[TehAtrDataTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [oms_TehAtrDataType] as [hDED]
go

