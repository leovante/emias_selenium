CREATE VIEW [V_App_RPXZ] AS SELECT 
[hDED].[RPXZID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[SS] as [SS], 
[hDED].[OKATO] as [OKATO], 
[hDED].[S_POL] as [S_POL], 
[hDED].[N_POL] as [N_POL], 
[hDED].[Family] as [Family], 
[hDED].[Name] as [Name], 
[hDED].[Patronymic] as [Patronymic], 
[hDED].[W] as [W], 
[hDED].[DR] as [DR], 
[hDED].[DS] as [DS], 
[hDED].[NOMK_LS] as [NOMK_LS], 
[hDED].[Count] as [Count], 
[hDED].[NOZ_Group] as [NOZ_Group], 
[hDED].[MCOD] as [MCOD], 
[hDED].[DATE_IN] as [DATE_IN], 
[hDED].[DATE_OUT] as [DATE_OUT], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E], 
[hDED].[C_FINL] as [C_FINL], 
[hDED].[BK] as [BK], 
[hDED].[COMMENTS] as [COMMENTS]
FROM [App_RPXZ] as [hDED]
go

