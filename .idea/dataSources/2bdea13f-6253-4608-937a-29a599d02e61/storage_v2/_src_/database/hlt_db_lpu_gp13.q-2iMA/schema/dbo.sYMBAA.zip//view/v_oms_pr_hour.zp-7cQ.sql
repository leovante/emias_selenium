CREATE VIEW [V_oms_pr_Hour] AS SELECT 
[hDED].[pr_HourID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [oms_pr_Hour] as [hDED]
go

