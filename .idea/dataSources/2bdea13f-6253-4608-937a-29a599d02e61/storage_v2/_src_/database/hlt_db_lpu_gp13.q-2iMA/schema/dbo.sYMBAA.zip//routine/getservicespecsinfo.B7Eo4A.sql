CREATE FUNCTION [dbo].[GetServiceSpecsInfo]
(	
	@Session_ID varchar(50), 
	@MO_Id varchar(100)
)
RETURNS TABLE 
AS
RETURN 
(

select @Session_ID as Session_ID,PRVS.C_PRVS as ServiceSpec_Id,PRVS.PRVS_NAME as ServiceSpec_Name,0 as Error
from hlt_DocPRVD DPRVD
Inner Join oms_PRVS PRVS on PRVS.PRVSID=DPRVD.rf_PRVSID
Inner Join hlt_DoctorTimeTable DTT on DTT.rf_DocPRVDID=DPRVD.DocPRVDID and (DTT.FlagAccess&4)>0
where DTT.[Date] between GETDATE() and GETDATE()+14
group by PRVS.C_PRVS,PRVS.PRVS_NAME 

)


go

