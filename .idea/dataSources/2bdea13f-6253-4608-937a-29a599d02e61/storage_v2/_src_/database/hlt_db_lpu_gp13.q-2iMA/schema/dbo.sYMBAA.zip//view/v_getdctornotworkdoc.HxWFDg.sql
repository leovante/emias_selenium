CREATE VIEW [dbo].[V_GetDctorNotWorkDoc]
AS
SELECT     dbo.oms_OKATO.O_NAME AS 'Наименование субъекта', dbo.oms_LPU.M_NAMES AS 'Наименование ЛПУ', 
                      UPPER(ISNULL(dbo.hlt_LPUDoctor.FAM_V + ' ' + dbo.hlt_LPUDoctor.IM_V + ' ' + dbo.hlt_LPUDoctor.OT_V, dbo.hlt_NotWorkDoc.DocCloseNWDS_FIO)) AS Doctor, 
                      COUNT(1) AS Count, dbo.hlt_NotWorkDoc.DateOpen
FROM         dbo.oms_LPU INNER JOIN
                      dbo.oms_OKATO ON dbo.oms_OKATO.OKATOID = dbo.oms_LPU.rf_OKATOID INNER JOIN
                      dbo.hlt_NotWorkDocReestr ON dbo.hlt_NotWorkDocReestr.rf_LPUID = dbo.oms_LPU.LPUID INNER JOIN
                      dbo.hlt_NotWorkDoc ON dbo.hlt_NotWorkDocReestr.NotWorkDocReestrID = dbo.hlt_NotWorkDoc.rf_NotWorkDocReestrID LEFT OUTER JOIN
                      dbo.hlt_LPUDoctor ON dbo.hlt_LPUDoctor.LPUDoctorID = dbo.hlt_NotWorkDoc.rf_DocCloseNWDSID
WHERE     (dbo.oms_LPU.LPUID <> 0) AND (dbo.oms_LPU.rf_OKATOID > 0) AND (dbo.hlt_NotWorkDoc.IsMainPE = 1)
GROUP BY dbo.oms_OKATO.O_NAME, dbo.oms_LPU.C_OGRN, dbo.oms_LPU.M_NAMES, dbo.hlt_NotWorkDoc.DateOpen, 
                      UPPER(ISNULL(dbo.hlt_LPUDoctor.FAM_V + ' ' + dbo.hlt_LPUDoctor.IM_V + ' ' + dbo.hlt_LPUDoctor.OT_V, dbo.hlt_NotWorkDoc.DocCloseNWDS_FIO))
go

