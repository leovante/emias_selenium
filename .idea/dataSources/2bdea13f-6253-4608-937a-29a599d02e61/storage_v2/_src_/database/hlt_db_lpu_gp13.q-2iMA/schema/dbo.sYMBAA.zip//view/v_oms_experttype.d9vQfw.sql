CREATE VIEW [V_oms_ExpertType] AS SELECT 
[hDED].[ExpertTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[OrderExp] as [OrderExp], 
[hDED].[IsHand] as [IsHand]
FROM [oms_ExpertType] as [hDED]
go

