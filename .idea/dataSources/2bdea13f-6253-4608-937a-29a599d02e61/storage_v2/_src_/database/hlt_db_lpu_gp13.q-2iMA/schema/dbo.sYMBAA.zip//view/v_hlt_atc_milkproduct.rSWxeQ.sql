CREATE VIEW [V_hlt_atc_MilkProduct] AS SELECT 
[hDED].[atc_MilkProductID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_atc_MilkSetID] as [rf_atc_MilkSetID], 
[jT_hlt_atc_MilkSet].[Num] as [SILENT_rf_atc_MilkSetID], 
[hDED].[Name] as [Name], 
[hDED].[Value] as [Value], 
[hDED].[Cost] as [Cost], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_atc_MilkProduct] as [hDED]
INNER JOIN [hlt_atc_MilkSet] as [jT_hlt_atc_MilkSet] on [jT_hlt_atc_MilkSet].[atc_MilkSetID] = [hDED].[rf_atc_MilkSetID]
go

