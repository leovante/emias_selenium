CREATE VIEW [V_web_Script] AS SELECT 
[hDED].[ScriptID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Guid] as [Guid], 
[hDED].[TaskNumber] as [TaskNumber], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[RunCount] as [RunCount], 
[hDED].[Success] as [Success]
FROM [web_Script] as [hDED]
go

