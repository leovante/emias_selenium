


CREATE FUNCTION [dbo].[GetScheduleInfoHouseCall]
(	
	@Session_ID varchar(50), 
	@Resource_Id varchar(100),
	@StartDateRange varchar(50),
	@EndDateRange varchar(50)
	

)
RETURNS TABLE 
AS
RETURN 
(
--declare @Session_ID varchar(50);
--SET @Session_ID='2017-asdasdasdasd';
--declare @StartDateRange varchar(50);
--SET @StartDateRange='2017-09-06';
--declare @EndDateRange varchar(50);
--SET @EndDateRange='2017-09-30';
--declare @Resource_Id varchar(100);
--SET @Resource_Id='06294640778.5500000001075240';
SELECT @Session_ID as Session_ID,DTT.UGUID as Slot_Id,DTT.Begin_Time as VisitTime,Datediff(n,DTT.Begin_Time,DTT.End_Time) as Duration
--, Datepart(n,(DTT.End_Time -DTT.Begin_Time)) --Datepart(minute,(DTT.End_Time -DTT.Begin_Time))  --*--DTT.DoctorTimeTableID, DTT.Begin_Time, RIGHT(@Resource_Id, len(@Resource_Id) - CHARINDEX('.', @Resource_Id)) --PCOD
from hlt_LPUDoctor LPUD
inner Join hlt_DoctorTimeTable DTT on DTT.rf_LPUDoctorID = LPUD.LPUDoctorID 
where LPUD.PCOD = RIGHT(@Resource_Id, len(@Resource_Id) - CHARINDEX('.', @Resource_Id)) and 
 DTT.UGUID is not null and (convert(date,DTT.Date,102) between convert(date,@StartDateRange,105) and convert(date,@EndDateRange,105))and
 Datediff(n,DTT.Begin_Time,DTT.End_Time)>0 and
 (dtt.FlagAccess /*& 4*/) > 0
and dtt.DoctorTimeTableID not in (select rf_DoctorTimeTableID from hlt_DoctorVisitTable where rf_DoctorTimeTableID=DTT.DoctorTimeTableID) 
and (dtt.rf_DocPRVDID <> 0) 
and dtt.Begin_Time <> '1900-01-01T00:00:00')
go

