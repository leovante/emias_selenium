CREATE PROCEDURE [dbo].[CancelAppointment]
	@Book_Id_Mis int,
	@Book_Id_Mis_2 int output,
	@Status_Code int output,
	@Comment varchar(200) output
AS
BEGIN
begin tran

-- Есть ли такая запись?
if not exists
(
	select * from hlt_DoctorVisitTable
	where DoctorVisitTableID = @Book_Id_Mis
)
begin
	rollback tran
	set @Status_Code = -21	
	return
end

/* Удаляем запись */
delete from hlt_DoctorVisitTable where DoctorVisitTableID = @Book_Id_Mis

commit tran
SET @Book_Id_Mis_2=@Book_Id_Mis
SET @Status_Code = 0
SET @Comment=''

END

go

