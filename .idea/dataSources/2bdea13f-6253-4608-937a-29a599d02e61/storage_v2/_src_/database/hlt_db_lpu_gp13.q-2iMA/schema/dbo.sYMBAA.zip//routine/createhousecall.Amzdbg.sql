

CREATE PROCEDURE [dbo].[CreateHouseCall]
    @Session_ID varchar(100),
	@Slot_Id varchar(100),
	@mkabid int,
	@Session_ID_2 varchar(100) output,
	@Book_Id_Mis int output, 
	@Status_Code int output,
	@Comment varchar(200) output,
	@Slot_Id_2 varchar(100) output,
	@VisitTime varchar(20) output, 
	@Duration int output 
AS
BEGIN
begin tran
	
declare @dvtID int
declare @TAPID int

-- Есть ли такая временная запись?
if not exists
(
	select * from hlt_DoctorTimeTable
	where UGUID = @Slot_Id
)
begin
	rollback tran
	set @Status_Code = 1	
	set @Comment = 'Внутренняя ошибка системы'
	
	SET @Session_ID_2 = @Session_ID
SET	@Book_Id_Mis = ''
SET	@Slot_Id_2 = @Slot_Id
SET	@VisitTime = (select Begin_Time from hlt_DoctorTimeTable where UGUID=@Slot_Id)
SET @Duration = (select Datediff(n,Begin_Time,End_Time) from hlt_DoctorTimeTable where UGUID=@Slot_Id )


	return
end

-- А может уже кого-то записали?
if exists
(
	select * from hlt_DoctorVisitTable dvt 
	inner join hlt_DoctorTimeTable dtt 
		on dvt.rf_DoctorTimeTableID = dtt.DoctorTimeTableID
	where dtt.UGUID = @Slot_Id
)
begin	
	rollback tran
	set @Status_Code = 2
	set @Comment = 'Отказ. Время занято'
	
	SET @Session_ID_2 = @Session_ID
SET	@Book_Id_Mis = ''
SET	@Slot_Id_2 = @Slot_Id
SET	@VisitTime = (select Begin_Time from hlt_DoctorTimeTable where UGUID=@Slot_Id)
SET @Duration = (select Datediff(n,Begin_Time,End_Time) from hlt_DoctorTimeTable where UGUID=@Slot_Id )


	return
end

---- Уже записаны на этот день к этому врачу
if exists
(
	select * 
	from hlt_DoctorVisitTable
	where DoctorVisitTableID in
	( 
		select dvt.DoctorVisitTableID
		from hlt_DoctorTimeTable dtt
		inner join hlt_DoctorVisitTable dvt
			on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID
			and dvt.rf_MkabID = @mkabid
		inner join hlt_DoctorTimeTable dtt2
			on dtt.Date = dtt2.Date
			and dtt.rf_LPUDoctorID = dtt2.rf_LPUDoctorID
			and dtt2.UGUID = @Slot_Id
			--and dtt2.DoctorTimeTableID = @Slot_Id    		
	)
)
begin
	rollback tran
	set @Status_Code = 3
	set @Comment = 'Пациент уже записан к данному специалисту на указанную услугу в этот день'
	
	SET @Session_ID_2 = @Session_ID
SET	@Book_Id_Mis = ''
SET	@Slot_Id_2 = @Slot_Id
SET	@VisitTime = (select Begin_Time from hlt_DoctorTimeTable where UGUID=@Slot_Id)
SET @Duration = (select Datediff(n,Begin_Time,End_Time) from hlt_DoctorTimeTable where UGUID=@Slot_Id )

	return
end
--------------------------------------------------------
---- Уже записаны на этот день к врачу данной специальности
--if exists
--(
--	select * 
--	from hlt_DoctorVisitTable
--	where DoctorVisitTableID in
--	( 
--		select dvt.DoctorVisitTableID
--		from hlt_DoctorTimeTable dtt
--		inner join hlt_DoctorVisitTable dvt
--		on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID and dvt.rf_MkabID = @mkabid
--		inner join hlt_LPUDoctor LPD on LPD.LPUDoctorID=dtt.rf_LPUDoctorID 	
--		where convert(date,dtt.[date])=convert(date,(select [date] from hlt_DoctorTimeTable where DoctorTimeTableID=@Slot_Id))
--			  and LPD.rf_PRVSID=(select LPD.rf_PRVSID from hlt_DoctorTimeTable inner join hlt_LPUDoctor LPD on LPD.LPUDoctorID=rf_LPUDoctorID where DoctorTimeTableID=@Slot_Id)
	
--	)
--)
--begin
--	rollback tran
--	set @Status_Code = -101
--	return
--end
--------------------------------------------------------
--------------------------------------------------------
---- Проверка пересечения времени
if exists
(
	select * 
	from hlt_DoctorVisitTable
	where DoctorVisitTableID in
	( 
		select dvt.DoctorVisitTableID
		from hlt_DoctorTimeTable dtt
		inner join hlt_DoctorVisitTable dvt
		on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID and dvt.rf_MkabID =@mkabid
		inner join hlt_LPUDoctor LPD on LPD.LPUDoctorID=dtt.rf_LPUDoctorID 	
		where DTT.[Date]=(select [DATE] from hlt_DoctorTimeTable where UGUID=@Slot_Id)
              and DTT.Begin_Time between (select Begin_Time from hlt_DoctorTimeTable where UGUID=@Slot_Id)
                                     and (select End_Time from hlt_DoctorTimeTable where UGUID=@Slot_Id)     
              or DTT.END_Time between (select Begin_Time from hlt_DoctorTimeTable where UGUID=@Slot_Id)
                                  and (select End_Time from hlt_DoctorTimeTable where UGUID=@Slot_Id)  
              and DTT.Begin_Time!='1900-01-01 00:00:00.000' 
			  
	
	)
)
begin
	rollback tran
	set @Status_Code = 5
	set @Comment = 'Пациент уже записан на это время к другому специалисту '
	
	SET @Session_ID_2 = @Session_ID
SET	@Book_Id_Mis = ''
SET	@Slot_Id_2 = @Slot_Id
SET	@VisitTime = (select Begin_Time from hlt_DoctorTimeTable where UGUID=@Slot_Id)
SET @Duration = (select Datediff(n,Begin_Time,End_Time) from hlt_DoctorTimeTable where UGUID=@Slot_Id )
	
	return
end
--------------------------------------------------------
-- Создаем записи в hlt_DoctorVisitTable
insert into hlt_DoctorVisitTable 
(
rf_DoctorTimeTableID, 
rf_MKABID, 
Comment,
Flags,
fromInternet)
select (select DoctorTimeTableID from hlt_DoctorTimeTable where UGUID=@Slot_Id), @mkabid, hlt_MKAB.FAMILY + ' ' + hlt_MKAB.NAME + ' ' + hlt_MKAB.OT + ', ' + 
cast (datepart(yy, hlt_MKAB.DATE_BD) as varchar(4)) + ' г.р.', 4,1
from hlt_MKAB where MKABID = @mkabid

-- Создаем ТАПы
if (0 = 1)
begin
	-- сохраняем ID записи
	set @dvtid = (SELECT IDENT_CURRENT('hlt_DoctorVisitTable'))

	insert into hlt_TAP
	 (
		 rf_MKABID,
		 rf_INVID,
		 rf_OtherSMOID,
		 rf_SMOID,
		 rf_SpecEventCertID,
		 isWorker,
		 S_POL,
		 N_POL,
		 FAMILY,
		 DateTAP,
	 rf_LPUDoctorID
	)
	select  
	 @mkabId,
	 rf_INVID,
	 rf_OtherSMOID,
	 rf_SMOID,
	 rf_SpecEventCertID,
	 isWorker,
	 S_POL,
	 N_POL,
	 FAMILY,
	 isnull ((select top 1 Date from hlt_DoctorTimeTable where UGUID = @Slot_Id), GetDate()),
	 isnull ((select top 1 rf_LPUDoctorID from hlt_DoctorTimeTable where UGUID = @Slot_Id), 0)
	from hlt_MKAB 
	where MKABID = @mkabID

	set @tapid = (SELECT IDENT_CURRENT('hlt_TAP'))

	update hlt_DoctorVisitTable set rf_TAPID = @tapID where DoctorVisitTableID = @dvtID
end

commit tran
set @Status_Code = 0
SET @Session_ID_2 = @Session_ID
SET	@Book_Id_Mis = (SELECT IDENT_CURRENT('hlt_DoctorVisitTable'))
SET	@Comment = ''
SET	@Slot_Id_2 = @Slot_Id
SET	@VisitTime = (select Begin_Time from hlt_DoctorTimeTable where UGUID=@Slot_Id)
SET @Duration = (select Datediff(n,Begin_Time,End_Time) from hlt_DoctorTimeTable where UGUID=@Slot_Id )
END


go

