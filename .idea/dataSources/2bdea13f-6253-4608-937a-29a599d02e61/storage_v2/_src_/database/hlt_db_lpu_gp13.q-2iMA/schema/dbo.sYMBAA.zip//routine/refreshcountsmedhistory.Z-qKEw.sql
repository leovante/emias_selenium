-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[RefreshCountsMedHistory]

AS
BEGIN	
	declare @TAPCount int -- число тапов
	declare @SttMedHistoryCount int
	declare @AnamnezCount int
	declare @LSPurposeCount int
	declare @ResearchCount int
	declare @VisitHistoryCount int
	declare @MedRecordCount int
	declare @DirectionCount int
	declare @FluorCardCount int
	declare @NotWorkCount int
	declare @DirectionManipulationCount int
	declare @MInfo xml                       
		declare @currMKAB int 
		DECLARE @CURSOR CURSOR
		SET @CURSOR  = CURSOR  LOCAL
		FOR select MKABID from hlt_MKAB
		OPEN @CURSOR				
		FETCH NEXT FROM @CURSOR INTO @currMKAB
		WHILE @@FETCH_STATUS = 0
		BEGIN								
					
					select @TAPCount = COUNT(1) from hlt_TAP where hlt_TAP.rf_MKABID = @currMKAB
	
					select @SttMedHistoryCount = COUNT(distinct CASE WHEN stt_DiagnosType.Code ='03' and stt_MigrationPatient.rf_StationarBranchID != 0 THEN stt_Diagnos.rf_MedicalHistoryID ELSE null END) 
					from stt_MedicalHistory 
					left join stt_Diagnos on stt_Diagnos.rf_MedicalHistoryID = stt_MedicalHistory.MedicalHistoryID
					left join stt_DiagnosType on stt_DiagnosType.DiagnosTypeID = stt_Diagnos.rf_DiagnosTypeID
					left join stt_MigrationPatient on stt_MedicalHistory.MedicalHistoryID = stt_MigrationPatient.rf_MedicalHistoryID
					where stt_MedicalHistory.rf_MKABID = @currMKAB
				    
					select @AnamnezCount = count(distinct CASE WHEN stt_Anamnez.isSigned='true' and stt_DiagnosType.Code ='03' THEN stt_Anamnez.AnamnezID  ELSE null END)
					from stt_MedicalHistory 
					left join stt_Diagnos on stt_Diagnos.rf_MedicalHistoryID = stt_MedicalHistory.MedicalHistoryID
					left join stt_DiagnosType on stt_DiagnosType.DiagnosTypeID = stt_Diagnos.rf_DiagnosTypeID    
					left join stt_Anamnez on stt_Anamnez.rf_MedicalHistoryID = stt_MedicalHistory.MedicalHistoryID
					where stt_MedicalHistory.rf_MKABID = @currMKAB
				    
					select @LSPurposeCount = COUNT(1) from hlt_LSPurpose
					where hlt_LSPurpose.rf_MKABID = @currMKAB
				    
					select @ResearchCount = COUNT(1) from lbr_LaboratoryResearch
					left join lbr_Research on lbr_Research.rf_LaboratoryResearchGUID = lbr_LaboratoryResearch.GUID
					where lbr_LaboratoryResearch.rf_MKABID = @currMKAB
					
					select @VisitHistoryCount = COUNT(1) from hlt_VisitHistory where hlt_VisitHistory.rf_MKABID = @currMKAB
					
					select @MedRecordCount = COUNT(distinct CASE WHEN LEN(hlt_MedRecord.Sign)>0 THEN hlt_MedRecord.MedRecordID ELSE null END ) from hlt_VisitHistory
					left join hlt_MedRecord on hlt_VisitHistory.VisitHistoryID = hlt_MedRecord.rf_VisitHistoryID
					where hlt_VisitHistory.rf_MKABID = @currMKAB
					
					select @DirectionCount = COUNT(1) from hlt_Direction where hlt_Direction.rf_MKABID = @currMKAB
					
					select @FluorCardCount = COUNT(1) from hlt_FluorCard where hlt_FluorCard.rf_MKABID = @currMKAB
					
					select @NotWorkCount = COUNT(1) from hlt_NotWorkDoc where hlt_NotWorkDoc.rf_MKABID = @currMKAB
					
					select @DirectionManipulationCount = COUNT(1) from hlt_DirectionManipulation where hlt_DirectionManipulation.rf_MKABID = @currMKAB
					
					declare @currXML xml
					set @currXML = (select @TAPCount as 'TAPCount', @SttMedHistoryCount as 'SttMedHistoryCount', @AnamnezCount as 'AnamnezCount',
					@LSPurposeCount as 'LSPurposeCount', @ResearchCount as 'ResearchCount', @VisitHistoryCount as 'VisitHistoryCount',
					@MedRecordCount as 'MedRecordCount', @DirectionCount as 'DirectionCount', @FluorCardCount as 'FluorCardCount',
					@NotWorkCount as 'NotWorkCount', @DirectionManipulationCount as 'DirectionManipulationCount'
					for xml raw)					
					UPDATE hlt_MKAB
					SET MKABInfo = @currXML		
					WHERE CURRENT OF @CURSOR					
					FETCH NEXT FROM @CURSOR INTO @currMKAB
		END
		CLOSE @CURSOR
		deallocate @CURSOR
END
go

