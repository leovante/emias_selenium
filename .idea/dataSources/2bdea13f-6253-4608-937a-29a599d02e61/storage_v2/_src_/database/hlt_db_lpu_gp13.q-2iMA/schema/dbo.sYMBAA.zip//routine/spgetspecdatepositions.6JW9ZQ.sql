

-- =============================================
-- Author:		Шумаков Сергей
-- Create date: 26.05.2010
-- Description:	Процедура возвращает дни приема заданной специальности за указанный период
-- в формате xml
-- =============================================
CREATE PROCEDURE [dbo].[spGetSpecDatePositions] 
	@PRVS_NAME varchar(100),
	@Date_A datetime,
	@Date_B datetime,
	@result xml output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SET DATEFIRST 1
	
	set @result = 

	(
	select tt.* from
	(
	select distinct
		1 as Tag,
		null as Parent,
		null as [GetDoctorDatePositionsResult!1],
		'true' as [GetDoctorDatePositionsResult!1!Result],
		0 as [GetDoctorDatePositionsResult!1!Code],
		null as [Date!2],
		null as [Date!2!DayOfWeek]
	UNION SELECT DISTINCT
		2 as Tag,
		1 as Parent,
		null as [GetDoctorDatePositionsResult!1],
		null as [GetDoctorDatePositionsResult!1!Result],
		null as [GetDoctorDatePositionsResult!1!Code],		
		dtt.date as [Date!2],
		datepart(dw, dtt.date) as [Date!2!DayOfWeek]
    from hlt_DoctorTimeTable dtt	
		inner join hlt_LPUDoctor doc
			on dtt.rf_LPUDoctorID = doc.LPUDoctorID --and doc.PCOD = @pcod
		inner join oms_prvs prvs on doc.rf_prvsid = prvs.PRVSID
			and prvs.PRVS_NAME = @PRVS_NAME
		inner join hlt_DocBusyType dbt
			on dtt.rf_DocBusyType = dbt.DocBusyTypeID
/*
2010-05-03 Изменил условие для записи на осмотры в 4 детской поликлиники
*/
			--and dbt.CODE = 4
			and dbt.TypeBusy = 1


        left join hlt_DoctorVisitTable dvt
		
        on   dvt.rf_DoctorTimeTableID = dtt.DoctorTimeTableID
    where       dtt.date between @Date_A and @Date_B		                    
            and Begin_Time <> '1900-01-01T00:00:00' -- отсекаем записи вне очереди
            and dvt.DoctorVisitTableID is null -- отсекаем занятые дни
            -- Еще фильтр по правам доступа	
            -- and (FlagAccess & 4) > 0	
            
    
	) tt
	order by [Date!2] asc
	FOR XML EXPLICIT, TYPE
	)
	

END




/****** Object:  StoredProcedure [dbo].[spGetDoctorTimePositions]    Script Date: 12/05/2012 12:44:40 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[spGetDoctorTimePositions]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[spGetDoctorTimePositions]
go

