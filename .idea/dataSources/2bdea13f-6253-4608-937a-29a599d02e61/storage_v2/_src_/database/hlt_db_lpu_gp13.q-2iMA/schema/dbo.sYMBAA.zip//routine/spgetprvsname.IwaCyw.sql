
-- =============================================
-- Author:		Сергей Шумаков
-- Create date: 26.05.2010
-- Description:	Получаем набор врачей заданной специальности, принимающей в заданное время
-- =============================================
CREATE PROCEDURE [dbo].[spGetPRVSName] 
	@result xml output
AS
BEGIN	
	SET NOCOUNT ON;

    set @result = 

	(
	select tt.* from
	(
	select distinct
		1 as Tag,
		null as Parent,
		null as [GetPRVSName!1],
		'true' as [GetPRVSName!1!Result],
		0 as [GetPRVSName!1!Code],
		null as [PRVSName!2]		
	UNION SELECT DISTINCT
	    2 as Tag,
		1 as Parent,
		null as [GetPRVSName!1],
		'true' as [GetPRVSName!1!Result],
		null as [GetPRVSName!1!Code],
		prvs_name as [PRVSName!2]		
	from hlt_lpudoctor doc
	inner join oms_prvs prvs
	on doc.rf_PRVSID = prvs.PRVSID
	where doc.InTime = 1
	and doc.IsDoctor = 1
	and doc.LPUDoctorID > 0
	and prvs.PRVSID > 0
) tt
	order by [PRVSName!2] asc
	FOR XML EXPLICIT, TYPE
	)
END

go

