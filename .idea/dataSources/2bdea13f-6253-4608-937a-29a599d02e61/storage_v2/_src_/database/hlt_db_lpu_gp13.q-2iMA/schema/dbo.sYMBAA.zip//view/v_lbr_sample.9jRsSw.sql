CREATE VIEW [V_lbr_Sample] AS SELECT 
[hDED].[SampleID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResearchID] as [rf_ResearchID], 
[hDED].[rf_BioMID] as [rf_BioMID], 
[hDED].[SampleDate] as [SampleDate], 
[hDED].[IsFailed] as [IsFailed], 
[hDED].[Number] as [Number]
FROM [lbr_Sample] as [hDED]
go

