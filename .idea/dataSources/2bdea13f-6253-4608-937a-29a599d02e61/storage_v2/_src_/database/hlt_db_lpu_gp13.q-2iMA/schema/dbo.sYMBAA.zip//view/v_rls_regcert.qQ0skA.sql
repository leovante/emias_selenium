CREATE VIEW [V_rls_RegCert] AS SELECT 
[hDED].[RegCertID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LatinNamesUID] as [rf_LatinNamesUID], 
[hDED].[rf_TradeNamesUID] as [rf_TradeNamesUID], 
[hDED].[rf_RegCert_StatusUID] as [rf_RegCert_StatusUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[RegNum] as [RegNum], 
[hDED].[RegDate] as [RegDate], 
[hDED].[EndDate] as [EndDate], 
[hDED].[Composition] as [Composition], 
[hDED].[PharmaActions] as [PharmaActions], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_RegCert] as [hDED]
go

