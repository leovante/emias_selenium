CREATE VIEW [V_stt_ProcedureList] AS SELECT 
[hDED].[ProcedureListID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_CancelDoctorID] as [rf_CancelDoctorID], 
[jT_hlt_LPUDoctor1].[V_DocInfo] as [SILENT_rf_CancelDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_CancelDocPRVDID] as [rf_CancelDocPRVDID], 
[jT_hlt_DocPRVD1].[Name] as [SILENT_rf_CancelDocPRVDID], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_TariffID] as [rf_TariffID], 
[jT_oms_Tariff].[Value1] as [SILENT_rf_TariffID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_ProcedureID] as [rf_ProcedureID], 
[jT_stt_Procedure].[Name] as [SILENT_rf_ProcedureID], 
[hDED].[rf_MedStageID] as [rf_MedStageID], 
[hDED].[Signature] as [Signature], 
[hDED].[flag] as [flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[CancelDate] as [CancelDate], 
[hDED].[CreateDate] as [CreateDate]
FROM [stt_ProcedureList] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor1] on [jT_hlt_LPUDoctor1].[LPUDoctorID] = [hDED].[rf_CancelDoctorID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD1] on [jT_hlt_DocPRVD1].[DocPRVDID] = [hDED].[rf_CancelDocPRVDID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_Tariff] as [jT_oms_Tariff] on [jT_oms_Tariff].[TariffID] = [hDED].[rf_TariffID]
INNER JOIN [stt_Procedure] as [jT_stt_Procedure] on [jT_stt_Procedure].[ProcedureID] = [hDED].[rf_ProcedureID]
go

