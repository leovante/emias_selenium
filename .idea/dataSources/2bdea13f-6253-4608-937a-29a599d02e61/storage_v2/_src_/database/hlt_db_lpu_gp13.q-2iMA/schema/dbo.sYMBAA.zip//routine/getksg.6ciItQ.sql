
--Возвращает список КСГ для набора данных
CREATE FUNCTION [dbo].[GetKSG](
@List_OperDS nvarchar(4000), 
-- Список пар из операций и диагнозов вида разделенных ;Пример :(A16.24.006.001,T95);(A16.24.006.001,T91);(A16.08.029.004,)
---И операция и диагноз не обязательны, но запятая обязательно
@List_DS nvarchar(4000), 
-- список диагнозов разделенных запятыми Пример 'T95,T91,A00,'
@Sex varchar(1),
--Код пола
-- 2 Женский
-- 1 Мужской
@Age int, 
--Возраст
@IsAgeDay bit=0, 
-- 1 в случае если возраст в днях
-- 0 возраст в годах
@departmentId int=0,
--ID отделения
@date datetime, 
-- дата окончания лечения
@dlit int=1
--Длительность лечения
)
RETURNS @result TABLE (
ServicemedicalID int,
[КСГ] [varchar](50),
[Наименование КСГ] [varchar](300),
[Тип] [varchar](100),
[TariffId] [int] NULL, 
[KSGValue] [decimal](38, 5) NULL, 
[KRRValue] [decimal](38, 5) NULL,
[Value] [decimal](38, 2) NULL,
[rf_MKBId] [int] NULL, 
[Диагноз] [varchar](255)
)
AS
begin
declare @krr decimal(20,5)
set @krr = isnull(dbo.getDepartmentKRR(@departmentId, @date),1)
declare @depType int
select @depType = rf_kl_DepartmentTypeID from oms_Department
where DepartmentID =@departmentId

INSERT INTO @result
select distinct rf_ServicemedicalID,replace(ServicemedicalCode,'ксг',''), Servicemedicalname,Info, tariffID, isnull(value1,1),@krr ,
case when (--Info like 'Тер.%' OR ksg.Flags<>1
@List_OperDS not like '%(A%' and ksg.ServicemedicalCode not in --Flags<>1--однозначное деление на 2, нет операций и не сверхкороткое пребывание
('4','5','8','9','11','13','14','20','134','135','138','159','177','226','245')
) and @dlit<=3 then round(isnull(value1,1)*@krr*0.5,2)
else round(isnull(value1,1)*@krr,2) end,
rf_MKBID,[Диагноз]
from (
select isnull(ksg.ServicemedicalCode, Qw1.ServicemedicalCode)ServicemedicalCode, 
isnull(ksg.Servicemedicalname,Qw1.Servicemedicalname) Servicemedicalname, 
isnull(( ksg.Info+'('+
case when Qw.Oper is not null and qw.Oper<>'' then 'операция: '+Qw.Oper
else '' end+ case when Qw.DSQ is not null then ' диагноз: '+Qw.DSQ
else '' end+ ')'), Qw1.Info) as Info, isnull( ksg.ServiceMedicalId,Qw1.ServiceMedicalId) as ServiceMedicalId, 
MKBID rf_MKBID,
oms_mkb.name [Диагноз], oms_ExpertKSG.Flags
from oms_ExpertKSG
inner join oms_ServiceMedical on oms_ServiceMedical.ServiceMedicalId = rf_OperationServiceMedicalID
inner join oms_ServiceMedical ksg on ksg.ServiceMedicalId = rf_KSGServiceMedicalID
inner join oms_MKB on MKBID = rf_MKBID
inner join oms_kl_SEX on kl_SExID = oms_ExpertKSG.rf_kl_SEXID
right join (
select Substring (Item,charIndex('(',Item)+1, charIndex(',',Item)-charIndex('(',Item)-1) as Oper,
Substring (Item,charIndex(',',Item)+1,charIndex(')',Item)-charIndex(',',Item)-1 ) as DsQ
from dbo.TableFromString(@List_OperDS,';')
union 
select '' ,Item from dbo.TableFromString(@List_DS,',') 
) Qw on ltrim(rtrim(qw.Oper)) =ltrim(rtrim(oms_ServiceMedical.ServiceMedicalCode)) and ( ltrim(rtrim(DS))= ltrim(rtrim(DSQ)) ) 
and (Code=@Sex or kl_SEXID=0) 
and (Year2=0 or (@Age>=Year1 and @Age<Year2 and IsAgeDay=@IsAgeDay)
or (@IsAgeDay=1 and Year1=0 and IsAgeDay=0 )
or (@IsAgeDay=1 and IsAgeDay=1 and @Age>=255 and Year1=28)
or( @IsAgeDay=0 and IsAgeDay=1 and @Age>1 and Year1=29)
)
left join ( 
select oper.ServicemedicalCode as Oper, ksg.ServicemedicalCode,ksg.Servicemedicalname, ksg.Info+'(операция: '+oper.ServicemedicalCode +')' as Info,ksg.ServicemedicalId, rf_MKBID, oms_MKB.Name as [Диагноз] from oms_ExpertKSG
inner join oms_ServiceMedical oper on oper.ServiceMedicalId = rf_OperationServiceMedicalID
inner join oms_ServiceMedical ksg on ksg.ServiceMedicalId = rf_KSGServiceMedicalID
inner join oms_kl_SEX on kl_SExID = oms_ExpertKSG.rf_kl_SEXID
inner join oms_MKB on MKBID = rf_MKBID
where rf_MKBID=0 and rf_OperationServiceMedicalID>0 and ExpertKSGId>0 
/**тут почему-то не проверялась дата закрытия КСГ**/
and oms_ExpertKSG.Date_E>@date  
/**************************************************/
and (Code=@Sex or kl_SEXID=0) 
and (Year2=0 or (@Age>=Year1 and @Age<Year2 and IsAgeDay=@IsAgeDay)
or (@IsAgeDay=1 and Year1=0 and IsAgeDay=0 )
or (@IsAgeDay=1 and IsAgeDay=1 and @Age>=255 and Year1=28)
or( @IsAgeDay=0 and IsAgeDay=1 and @Age>1 and Year1=29)
)
) Qw1 on ExpertKSGID is null and Qw1.Oper = qw.Oper and Qw.Oper<>'' 
) ksg 
inner join oms_Tariff on ksg.ServicemedicalID=oms_Tariff.rf_ServicemedicalID and oms_Tariff.date_b<=@date and oms_Tariff.date_e>@date
inner join oms_TariffTarget on rf_TariffTargetID = TariffTargetID and (oms_TariffTarget.rf_kl_DepartmentTypeID=@depType or oms_TariffTarget.rf_kl_DepartmentTypeID=0)
where ServicemedicalId>0
 
declare @num int 
set @num=0
select @num=Num from  @result
inner join 
(
select '7' usl1 , '13' Usl2, '1' Num union
select '7', '14', '2' Union 
select '8', '13', '3' Union
select '22','64', '4' Union
select '81','193','5' Union
select '81','196','6' Union
select '143','138','7' Union
select '166','245','8' Union
select '244','245','9' Union
select '200','37','10' Union
select '226','211','11') t on [КСГ] = usl1 or [КСГ] =Usl2
group by Num
having count(*)>1
if(@num>0)
 
declare @notUsl integer
set @notUsl =0
select @notUsl=usl1 from (
select '7' usl1 , '13' Usl2, '1' Num union
select '7', '14', '2' Union 
select '8', '13', '3' Union
select '22','64', '4' Union
select '81','193','5' Union
select '81','196','6' Union
select '143','138','7' Union
select '166','245','8' Union
select '244','245','9' Union
select '200','37','10' Union
select '226','211','11') t where Num =@num
 
delete from @result where [КСГ]=@notUsl
 
 
 
RETURN 
END
go

