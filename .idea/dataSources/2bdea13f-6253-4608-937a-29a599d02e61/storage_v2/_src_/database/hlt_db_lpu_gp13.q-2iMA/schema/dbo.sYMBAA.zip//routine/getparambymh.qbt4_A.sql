create FUNCTION [dbo].[GetParamByMH](@mhid int)
RETURNS varchar(20)
AS
begin
declare @m varchar(20)
set @m=''
return @m
end
go

