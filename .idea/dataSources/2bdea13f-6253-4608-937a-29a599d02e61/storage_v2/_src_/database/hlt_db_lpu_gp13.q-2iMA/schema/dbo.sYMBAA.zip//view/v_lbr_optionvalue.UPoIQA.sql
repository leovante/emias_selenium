CREATE VIEW [V_lbr_OptionValue] AS SELECT 
[hDED].[OptionValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SampleID] as [rf_SampleID], 
[hDED].[rf_OptionID] as [rf_OptionID], 
[hDED].[Value] as [Value]
FROM [lbr_OptionValue] as [hDED]
go

