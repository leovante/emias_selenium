CREATE VIEW [V_rls_Synon_Iic] AS SELECT 
[hDED].[Synon_IicID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsIicUID] as [rf_ClsIicUID], 
[hDED].[rf_IicSynonymsUID] as [rf_IicSynonymsUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Synon_Iic] as [hDED]
go

