CREATE FUNCTION [dbo].[GetResourceInfo]
(	
	@Session_ID varchar(50), 
	@ServiceSpec_id varchar(100)
)
RETURNS TABLE 
AS
RETURN 
(

select @Session_ID as Session_ID,DPRVD.DocPRVDID as Resource_Id,LPD.V_DocInfo+
' ('+(select M_NAMES from oms_LPU where LPUID = (select rf_LPUID from oms_Department where DepartmentID = DPRVD.rf_DepartmentID))+')' as Resource_Name,0 as Error
from hlt_DocPRVD DPRVD
Inner Join V_hlt_LPUDoctor LPD on LPD.LPUDoctorID=DPRVD.rf_LPUDoctorID
Inner Join oms_PRVS PRVS on PRVS.PRVSID=DPRVD.rf_PRVSID
Inner Join hlt_DoctorTimeTable DTT on DTT.rf_DocPRVDID=DPRVD.DocPRVDID and (DTT.FlagAccess&4)>0
where DTT.[Date] between GETDATE() and GETDATE()+14
and PRVS.C_PRVS=@ServiceSpec_id
group by DPRVD.DocPRVDID,LPD.V_DocInfo,DPRVD.rf_DepartmentID

)
go

