CREATE VIEW [V_App_OLSSZ] AS SELECT 
[hDED].[OLSSZID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrderLSID] as [rf_OrderLSID], 
[jT_App_OrderLS].[Description] as [SILENT_rf_OrderLSID], 
[hDED].[rf_OLSSZStateID] as [rf_OLSSZStateID], 
[jT_App_OLSSZState].[State] as [SILENT_rf_OLSSZStateID], 
[hDED].[rf_Time_SSZID] as [rf_Time_SSZID], 
[jT_App_Time_SSZ].[Description] as [SILENT_rf_Time_SSZID], 
[hDED].[Flags] as [Flags]
FROM [App_OLSSZ] as [hDED]
INNER JOIN [App_OrderLS] as [jT_App_OrderLS] on [jT_App_OrderLS].[OrderLSID] = [hDED].[rf_OrderLSID]
INNER JOIN [App_OLSSZState] as [jT_App_OLSSZState] on [jT_App_OLSSZState].[OLSSZStateID] = [hDED].[rf_OLSSZStateID]
INNER JOIN [App_Time_SSZ] as [jT_App_Time_SSZ] on [jT_App_Time_SSZ].[Time_SSZID] = [hDED].[rf_Time_SSZID]
go

