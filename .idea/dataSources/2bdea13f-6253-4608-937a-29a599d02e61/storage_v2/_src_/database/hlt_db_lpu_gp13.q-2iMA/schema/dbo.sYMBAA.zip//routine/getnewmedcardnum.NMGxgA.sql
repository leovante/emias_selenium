
-- =============================================
-- Author:		  Kulbabov Vasiliy
-- Redactor:      Zinkova Marina
-- Create date:   25.01.2016
-- Revision date: 21.02.2018
-- Description:	  Генерирует номер мед карты.
-- =============================================

CREATE PROCEDURE [dbo].[GetNewMedCardNum] 
	-- Add the parameters for the stored procedure here
	@num varchar(100) output, 
	@userID int,
	@StationarBranchID int,
	@date datetime	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	-- SET NOCOUNT ON;
set transaction isolation level SERIALIZABLE 
begin transaction  GetMedCardNum

declare @MedCardTemplate varchar(100), @NumMode int, @BranchNumMode int

-- 0 - не обнулять номера
-- 1 - обнулить номера
if((select top 1 case when ValueStr='' then 0  
		else 
			case when CAST(ValueStr as int) < YEAR(GETDATE()) then 1  
			else 0	end
		end
	from x_UserSettings 
	where Property='CurrentYear'
	and OwnerGUID ='4DF516BE-7A1D-416C-BD93-1CBB2159B26D'
	and rf_UserID=1) = 1)
	begin
		UPDATE [dbo].[x_UserSettings] 
		set [ValueInt]= 0
		where Property ='LastMedcardNum'
		and OwnerGUID ='4DF516BE-7A1D-416c-BD93-1CBB2159B26D'
		and rf_UserID = 1

		update stt_StationarBranch 
		set LastMedCardNum = 0
		where StationarBranchID>0

		UPDATE [dbo].[x_UserSettings] 
		set ValueStr = YEAR(GETDATE())
		where Property='CurrentYear'
		and OwnerGUID ='4DF516BE-7A1D-416C-BD93-1CBB2159B26D'
		and rf_UserID=1
	end

	 --Режим работы автоматической нумерации мед. карт 
	 --0 - не установлен,
	 --1 - сквозной в рамках отделения, 
	 --2 - ручной в рамках отделения
set @BranchNumMode = (select BranchNumMode from stt_StationarBranch where StationarBranchID=@StationarBranchID)

if(@BranchNumMode = 0)--номерация по всем отделениям
	begin
		--Настройка NumMode. 
		--Если  0-сквозная номерация по всем отделениям, 
		--1- ручная номерация по всем отделениям.
		select top 1 @NumMode=ValueInt 
		from x_UserSettings 
		where Property='NumMode'
			and OwnerGUID ='4DF516BE-7A1D-416c-BD93-1CBB2159B26D'
			and rf_UserID=1 

		select @NumMode = ISNULL(@NumMode, 0) 
		if(@NumMode = 0) --сквозная номерация по всем отделениям
			begin

				-- номер
				UPDATE [dbo].[x_UserSettings] 
				set [ValueInt]= [ValueInt]+1
				where Property ='LastMedcardNum'
				and OwnerGUID ='4DF516BE-7A1D-416c-BD93-1CBB2159B26D'
				and rf_UserID = 1

				if(@@rowcount=0)
				begin
					INSERT INTO [dbo].[x_UserSettings]
							([rf_UserID]
							,[OwnerGUID]
							,[DocTypeDefGUID]
							,[rf_SettingTypeID]
							,[Property]
							,[ValueInt]
							)
						VALUES
							(1
							,'4DF516BE-7A1D-416c-BD93-1CBB2159B26D'           
							,'00000000-0000-0000-0000-000000000000'           
							,(select SettingTypeID from x_SettingType where MnemCode='Целая настройка')
							,'LastMedcardNum'
							,1)
				end

				select @num= cast([ValueInt] as varchar) from x_userSettings  
				where Property ='LastMedcardNum'
				and OwnerGUID ='4DF516BE-7A1D-416c-BD93-1CBB2159B26D'
				and rf_UserID = 1

				--шаблон
				select top 1 @MedCardTemplate =ValueStr from x_UserSettings   
				where Property ='MedCardNumTemplate'
				and OwnerGUID ='4DF516BE-7A1D-416c-BD93-1CBB2159B26D'
				and rf_UserID = @userID

				if(@@rowcount=0 or @MedCardTemplate='')
				begin 
	
					select top 1 @MedCardTemplate =ValueStr from x_UserSettings   
					where Property ='MedCardNumTemplate'
					and OwnerGUID ='4DF516BE-7A1D-416c-BD93-1CBB2159B26D'
					and rf_UserID = 1

					if(@@rowcount=0)
					begin
							INSERT INTO [dbo].[x_UserSettings]
									([rf_UserID]
									,[OwnerGUID]
									,[DocTypeDefGUID]
									,[rf_SettingTypeID]
									,[Property]
									,[ValueStr]
									)
								VALUES
									(1
									,'4DF516BE-7A1D-416c-BD93-1CBB2159B26D'           
									,'00000000-0000-0000-0000-000000000000'           
									,(select SettingTypeID from x_SettingType where MnemCode='Строковая')
									,'MedCardNumTemplate'
									,'%NUM%')

							set @MedCardTemplate ='%NUM%'
					end
				end
			end
		else
			begin 
				SET @num='' --ручная номерация по всем отделениям				
			end 
	end
else 
	if(@BranchNumMode = 1)
		begin --сквозная номерация по приемным отделениям 
			--читаем шаблон номера
			select @MedCardTemplate = MedCardNumTemplate from stt_StationarBranch where StationarBranchID=@StationarBranchID
			if(@MedCardTemplate='') --если пустой задаем стандартный
			begin
				update stt_StationarBranch set MedCardNumTemplate='%NUM%' where StationarBranchID=@StationarBranchID
				set @MedCardTemplate='%NUM%'
			end
			--увелечение номера на 1
			update stt_StationarBranch 
			set LastMedCardNum = LastMedCardNum + 1 
			where StationarBranchID=@StationarBranchID
			--читаем номер карты
			select @num = cast(LastMedCardNum as varchar) from stt_StationarBranch where StationarBranchID=@StationarBranchID
		end
	else 
		begin 
			SET @num='' --ручная номерация по всем отделениям			
	   end 

if(@num<>'')--создание номера из шаблона
	begin
		--убираем лишние пробелы, перевод в верхний регистр
		set @MedCardTemplate = upper(ltrim(rtrim(@MedCardTemplate)))
		--если шаблон без определения начального количество символов номера
		if(CHARINDEX('%NUM%', @MedCardTemplate)>0)
			set @num = replace(@MedCardTemplate,'%NUM%', @num) --заменяем в шаблоне номер
		else
			begin
				declare @kol int, @index1 int, @index2 int
				select @index1 = CHARINDEX('%NUM:', @MedCardTemplate)--поиск первого индекса
				select @index2 = CHARINDEX('%', @MedCardTemplate, @index1+5)--поиск последнего индекса
				set @kol = cast(SUBSTRING(@MedCardTemplate, @index1+5, @index2-(@index1+5))as int)--читаем значение количества символов
				set @num = ISNULL(REPLICATE('0',@kol-len(@num))+@num, @num)--добавляем перед номером нужное количество символов

				set @num = replace(@MedCardTemplate, SUBSTRING(@MedCardTemplate, @index1, @index2-@index1+1), @num)
			end

		set @num = replace(@num,'%YYYY%',DATEPART(year,@date))--заменяем в шаблоне год полный
		set @num = replace(@num,'%YY%',SUBSTRING(cast(DATEPART(year,@date) as varchar(4)),3,2))--заменяем в шаблоне год частичный
		set @num = replace(@num,'%MM%', substring(Convert(varchar,@date,101),1,2))--заменяем в шаблоне месяц
		if(CHARINDEX('%BRANCHCODE%',@num)>0) --заменяем в шаблоне отделение
		begin
			set @num = replace(@num,'%BRANCHCODE%',
				isNull((select V_Code from v_stt_stationarBranch where StationarBranchID = @StationarBranchID),''))
		end
	end

commit transaction  GetMedCardNum

set transaction isolation level READ COMMITTED  

Return
END
go

