CREATE VIEW [V_App_OLSPZ] AS SELECT 
[hDED].[OLSPZID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrderLSID] as [rf_OrderLSID], 
[jT_App_OrderLS].[Description] as [SILENT_rf_OrderLSID], 
[hDED].[rf_OLSPZStateID] as [rf_OLSPZStateID], 
[jT_App_OLSPZState].[State] as [SILENT_rf_OLSPZStateID]
FROM [App_OLSPZ] as [hDED]
INNER JOIN [App_OrderLS] as [jT_App_OrderLS] on [jT_App_OrderLS].[OrderLSID] = [hDED].[rf_OrderLSID]
INNER JOIN [App_OLSPZState] as [jT_App_OLSPZState] on [jT_App_OLSPZState].[OLSPZStateID] = [hDED].[rf_OLSPZStateID]
go

