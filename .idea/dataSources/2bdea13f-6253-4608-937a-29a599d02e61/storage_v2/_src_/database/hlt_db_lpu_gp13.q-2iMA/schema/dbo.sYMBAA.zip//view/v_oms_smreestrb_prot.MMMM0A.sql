CREATE VIEW [V_oms_SMReestrB_PROT] AS SELECT 
[hDED].[SMReestrB_PROTID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[rf_SMReestrONK_SLID] as [rf_SMReestrONK_SLID], 
[hDED].[PROT] as [PROT], 
[hDED].[D_PROT] as [D_PROT]
FROM [oms_SMReestrB_PROT] as [hDED]
go

