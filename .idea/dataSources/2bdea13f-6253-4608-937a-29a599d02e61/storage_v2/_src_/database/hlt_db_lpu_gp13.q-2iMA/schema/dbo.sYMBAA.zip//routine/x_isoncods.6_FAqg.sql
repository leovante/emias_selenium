
CREATE FUNCTION [dbo].[x_IsOncoDS]
( @MKBID int = 0, @isMain int = 1)
RETURNS int
AS
BEGIN
	DECLARE @ret int
	if (@isMain = 1)
	set @ret = (select top 1 count(*) from oms_MKB where 
	MKBID = @MKBID and (MKBID in (select MKBID from hlt_selectByMKB('C00-C99.9,')) 
    or MKBID in (select MKBID from hlt_selectByMKB('D70-D70.9,'))));
	else 
	set @ret = (select top 1 count(*) from oms_MKB where 
	MKBID = @MKBID and (MKBID in (select MKBID from hlt_selectByMKB('C00-C80.9,')) 
	or MKBID in (select MKBID from hlt_selectByMKB('C97-C97.9,'))));
	RETURN @ret
END
go

