CREATE VIEW [V_oms_Unit] AS SELECT 
[hDED].[UnitID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_AmountID] as [rf_AmountID], 
[jT_oms_Amount].[Name] as [SILENT_rf_AmountID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Koef] as [Koef], 
[hDED].[DescRu] as [DescRu], 
[hDED].[DescInter] as [DescInter], 
[hDED].[Flags] as [Flags], 
[hDED].[Rate] as [Rate], 
[hDED].[DiffKoef] as [DiffKoef], 
[hDED].[IsBase] as [IsBase], 
[hDED].[GUIDUnit] as [GUIDUnit]
FROM [oms_Unit] as [hDED]
INNER JOIN [oms_Amount] as [jT_oms_Amount] on [jT_oms_Amount].[AmountID] = [hDED].[rf_AmountID]
go

