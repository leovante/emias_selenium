CREATE VIEW [V_oms_hs_HospitalisationRequest] AS SELECT 
[hDED].[hs_HospitalisationRequestID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_hs_DirectionID] as [rf_hs_DirectionID], 
[jT_oms_hs_Direction].[DirNumber] as [SILENT_rf_hs_DirectionID], 
[hDED].[rf_hs_StateHospitalisationRequestID] as [rf_hs_StateHospitalisationRequestID], 
[jT_oms_hs_StateHospitalisationRequest].[Name] as [SILENT_rf_hs_StateHospitalisationRequestID], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[UserSuppID] as [UserSuppID], 
[hDED].[Email] as [Email], 
[hDED].[Phone] as [Phone], 
[hDED].[Comment] as [Comment], 
[hDED].[DateVisit] as [DateVisit], 
[hDED].[Guid] as [Guid]
FROM [oms_hs_HospitalisationRequest] as [hDED]
INNER JOIN [oms_hs_Direction] as [jT_oms_hs_Direction] on [jT_oms_hs_Direction].[hs_DirectionID] = [hDED].[rf_hs_DirectionID]
INNER JOIN [oms_hs_StateHospitalisationRequest] as [jT_oms_hs_StateHospitalisationRequest] on [jT_oms_hs_StateHospitalisationRequest].[hs_StateHospitalisationRequestID] = [hDED].[rf_hs_StateHospitalisationRequestID]
go

