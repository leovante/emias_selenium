CREATE VIEW [V_dd_DDPhisicalDeviationType] AS SELECT 
[hDED].[DDPhisicalDeviationTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDPhisicalDeviationType] as [hDED]
go

