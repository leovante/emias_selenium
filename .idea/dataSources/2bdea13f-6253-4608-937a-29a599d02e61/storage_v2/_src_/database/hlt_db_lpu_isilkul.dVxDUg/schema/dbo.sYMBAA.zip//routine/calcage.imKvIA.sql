
CREATE function [dbo].[CalcAge](
@Birthday datetime, -- дата рождения
@CalcForDate datetime -- дата на которую надо вычислить возраст
)
returns @t table(
yeas int --полных лет
, months int -- полных месяцев
, days int -- полных дней
)
as
begin
  declare @y int, @m int, @d int

  set @y=DATEDIFF(year, @Birthday, @CalcForDate)

  set @Birthday=DATEADD(year, @y, @Birthday)
  if @Birthday>@CalcForDate begin
    SET @y=@y-1
    set @Birthday=DATEADD(year, -1, @Birthday)
  end

  set @m=DATEDIFF(month, @Birthday, @CalcForDate)

  set @Birthday=DATEADD(month, @m, @Birthday)
  if @Birthday>@CalcForDate begin
    SET @m=@m-1
    set @Birthday=DATEADD(month, -1, @Birthday)
  end

  set @d=DATEDIFF(day, @Birthday, @CalcForDate)

  insert @t
  VALUES(@y, @m, @d)
  return
end

go

