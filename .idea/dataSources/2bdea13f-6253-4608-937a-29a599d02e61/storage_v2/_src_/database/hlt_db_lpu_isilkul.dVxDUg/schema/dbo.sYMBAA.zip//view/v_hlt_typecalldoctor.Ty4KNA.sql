CREATE VIEW [V_hlt_TypeCallDoctor] AS SELECT 
[hDED].[TypeCallDoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME], 
[hDED].[EnumName] as [EnumName], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_TypeCallDoctor] as [hDED]
go

