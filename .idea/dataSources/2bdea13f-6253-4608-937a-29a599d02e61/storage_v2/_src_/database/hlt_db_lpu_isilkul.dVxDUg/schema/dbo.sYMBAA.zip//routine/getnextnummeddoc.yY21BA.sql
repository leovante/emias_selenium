



CREATE FUNCTION [dbo].[GetNextNumMedDoc] 
(
)
RETURNS int
AS
BEGIN
	DECLARE @res int
	select @res =  max(MedRecordID) 
 from life_hlt_MedRecord where
  rf_BlankTemplateID=(select BlankTemplateID from hlt_BlankTemplate where Caption='Заявление о прикреплении к МО')
	RETURN @res
END


go

