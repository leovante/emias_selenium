CREATE VIEW [V_oms_regs_Tabs] AS SELECT 
[hDED].[regs_TabsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[GUID] as [GUID]
FROM [oms_regs_Tabs] as [hDED]
go

