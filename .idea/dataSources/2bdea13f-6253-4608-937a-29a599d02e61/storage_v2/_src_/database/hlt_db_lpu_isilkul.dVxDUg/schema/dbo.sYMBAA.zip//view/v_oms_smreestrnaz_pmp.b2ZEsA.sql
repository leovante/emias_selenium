CREATE VIEW [V_oms_SMReestrNAZ_PMP] AS SELECT 
[hDED].[SMReestrNAZ_PMPID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[NAZ_PMP] as [NAZ_PMP]
FROM [oms_SMReestrNAZ_PMP] as [hDED]
go

