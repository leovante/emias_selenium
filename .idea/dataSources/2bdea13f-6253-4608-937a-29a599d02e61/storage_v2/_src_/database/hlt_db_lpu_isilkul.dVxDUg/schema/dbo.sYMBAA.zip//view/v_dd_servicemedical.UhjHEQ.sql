CREATE VIEW [V_dd_ServiceMedical] AS SELECT 
[hDED].[ServiceMedicalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Q_MU] as [Q_MU], 
[hDED].[NMU] as [NMU], 
[hDED].[SMU] as [SMU], 
[hDED].[MSG_TEXT] as [MSG_TEXT]
FROM [dd_ServiceMedical] as [hDED]
go

