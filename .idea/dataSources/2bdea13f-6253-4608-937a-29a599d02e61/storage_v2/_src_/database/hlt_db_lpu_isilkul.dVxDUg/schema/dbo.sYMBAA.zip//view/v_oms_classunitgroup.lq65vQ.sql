CREATE VIEW [V_oms_ClassUnitGroup] AS SELECT 
[hDED].[ClassUnitGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [oms_ClassUnitGroup] as [hDED]
go

