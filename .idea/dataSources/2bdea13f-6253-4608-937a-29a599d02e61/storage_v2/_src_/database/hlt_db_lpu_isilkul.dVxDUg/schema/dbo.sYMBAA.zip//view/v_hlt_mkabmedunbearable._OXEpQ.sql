CREATE VIEW [V_hlt_MKABMedUnbearable] AS SELECT 
[hDED].[MKABMedUnbearableID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[MedUnbearable] as [MedUnbearable]
FROM [hlt_MKABMedUnbearable] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
go

