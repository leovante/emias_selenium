CREATE VIEW [V_oms_UnitAgeRange] AS SELECT 
[hDED].[UnitAgeRangeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_sc_AgeRangeID] as [rf_sc_AgeRangeID], 
[jT_oms_sc_AgeRange].[V_Range] as [SILENT_rf_sc_AgeRangeID], 
[hDED].[rf_UnitID] as [rf_UnitID], 
[jT_oms_Unit].[Name] as [SILENT_rf_UnitID], 
[hDED].[Description] as [Description], 
[hDED].[GUIDUnitAgeGroup] as [GUIDUnitAgeGroup]
FROM [oms_UnitAgeRange] as [hDED]
INNER JOIN [V_oms_sc_AgeRange] as [jT_oms_sc_AgeRange] on [jT_oms_sc_AgeRange].[sc_AgeRangeID] = [hDED].[rf_sc_AgeRangeID]
INNER JOIN [oms_Unit] as [jT_oms_Unit] on [jT_oms_Unit].[UnitID] = [hDED].[rf_UnitID]
go

