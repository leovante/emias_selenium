-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spwlProcessRecord] 
	@wlid int
AS
BEGIN

DECLARE @WaitingListID int
DECLARE @mkabID int
DECLARE @rf_DocPRVDID int
DECLARE @rf_PRVSID int 
DECLARE @DateFrom datetime
DECLARE @DateTo datetime
DECLARE @HourFrom int
DECLARE @HourTo int

DECLARE @FromReg    int
DECLARE @FromInet   int
DECLARE @FromDoc    int
DECLARE @FromInfomat int


SELECT @WaitingListID = WaitingListID
	,@mkabID = rf_mkabID
	,@rf_DocPRVDID = rf_DocPRVDID
	,@rf_PRVSID = rf_PRVSID
	,@DateFrom = DateFrom
	,@DateTo = DateTo
	,@HourFrom = HourFrom
	,@HourTo = HourTo
	,@FromReg = FromReg  
	,@FromInet =  FromInternet
	,@FromDoc =  FromDoc 
	,@FromInfomat = FromInfomat
	
FROM dbo.hlt_WaitingList
WHERE WaitingListID = @wlid


DECLARE @dttid int
	/*Ищем свободное время*/
	IF @rf_DocPRVDID > 0 
	BEGIN
		SET @dttid = isnull((
	    SELECT top 1 DoctorTimeTableID FROM IV_Schedul 
		WHERE DTT_DATE between @DateFrom and @DateTo
			and dtt_DocPRVDID = @rf_DocPRVDID
			and DoctorVisitTableID is null
			and datepart(hh, DTT_BEGIN_TIME) between @HourFrom and @HourTo
			and (DTT_FlagAccess & 4) != 0
		ORDER BY DTT_DATE, DTT_Begin_Time
		), 0)
	END
	ELSE
	BEGIN
		SET @dttid = isnull((
	    SELECT top 1 DoctorTimeTableID FROM IV_Schedul 
		WHERE DTT_DATE between @DateFrom and @DateTo
			and DPRVD_PRVSID = @rf_PRVSID
			and DoctorVisitTableID is null
			and datepart(hh, DTT_BEGIN_TIME) between @HourFrom and @HourTo
			and (DTT_FlagAccess & 4) != 0
		ORDER BY DTT_DATE, DTT_Begin_Time
		), 0)
	END

	IF @dttid = 0 RETURN

	BEGIN TRAN
		DECLARE	@subresult int

		EXEC	 [dbo].[spCreateVisitWOExpert]
						@dttid = @dttid,
						@mkabid = @mkabID,
						@result = @subresult OUTPUT
		print @subresult

		IF @subresult = 0
		BEGIN
			DECLARE @dvtid int
			set @dvtid = isnull((select top 1 DoctorVisitTableID FROM hlt_DoctorVisitTable where rf_MKABID = @mkabid and rf_DoctorTimeTableID = @dttid),0)

			IF @dvtid > 0
			BEGIN
				UPDATE hlt_WaitingList
				SET rf_DoctorVisitTableID = @dvtid,
					TicketCount = TicketCount + 1,
					TicketCreateTime = getdate(),
					TicketLiveTime = DateAdd(hour, 2, getdate())
				WHERE WaitingListID = @WaitingListID

				UPDATE hlt_DoctorVisitTable
				SET Flags = 16
				,fromReg = @FromReg
				,fromDoc = @FromDoc
				,fromInfomat = @FromInfomat
				,fromInternet = @FromInet
				WHERE DoctorVisitTableID = @dvtid

			END
		END

	COMMIT TRAN
END
go

