CREATE VIEW [V_die_Mkb] AS SELECT 
[hDED].[MkbID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_DieDiagnosTypeGuid] as [rf_DieDiagnosTypeGuid], 
[hDED].[rf_CertificateGuid] as [rf_CertificateGuid], 
[hDED].[rf_MkbVaismanID] as [rf_MkbVaismanID], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Comment] as [Comment], 
[hDED].[Period] as [Period]
FROM [die_Mkb] as [hDED]
go

