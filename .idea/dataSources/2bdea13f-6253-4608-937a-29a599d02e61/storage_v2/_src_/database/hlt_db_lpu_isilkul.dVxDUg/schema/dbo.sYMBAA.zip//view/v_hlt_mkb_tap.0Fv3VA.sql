CREATE VIEW [V_hlt_MKB_TAP] AS SELECT 
[hDED].[MKB_TAPID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_MKBExternalID] as [rf_MKBExternalID], 
[jT_oms_MKB1].[DS] as [SILENT_rf_MKBExternalID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[jT_hlt_TAP].[v_TAP] as [SILENT_rf_TAPID], 
[hDED].[rf_kl_DiseaseTypeID] as [rf_kl_DiseaseTypeID], 
[hDED].[rf_kl_TraumaTypeID] as [rf_kl_TraumaTypeID], 
[hDED].[rf_kl_DispRegStateID] as [rf_kl_DispRegStateID], 
[hDED].[rf_kl_RegistrationEndReasonID] as [rf_kl_RegistrationEndReasonID], 
[jT_oms_kl_RegistrationEndReason].[Name] as [SILENT_rf_kl_RegistrationEndReasonID], 
[hDED].[rf_kl_DiagnosTypeID] as [rf_kl_DiagnosTypeID], 
[jT_oms_kl_DiagnosType].[Code] as [SILENT_rf_kl_DiagnosTypeID], 
[hDED].[isMain] as [isMain], 
[hDED].[Comments] as [Comments], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[rf_DocTypeDefGUID] as [rf_DocTypeDefGUID], 
[hDED].[rf_DocGUID] as [rf_DocGUID], 
[hDED].[GUID] as [GUID]
FROM [hlt_MKB_TAP] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_MKB] as [jT_oms_MKB1] on [jT_oms_MKB1].[MKBID] = [hDED].[rf_MKBExternalID]
INNER JOIN [V_hlt_TAP] as [jT_hlt_TAP] on [jT_hlt_TAP].[TAPID] = [hDED].[rf_TAPID]
INNER JOIN [oms_kl_RegistrationEndReason] as [jT_oms_kl_RegistrationEndReason] on [jT_oms_kl_RegistrationEndReason].[kl_RegistrationEndReasonID] = [hDED].[rf_kl_RegistrationEndReasonID]
INNER JOIN [oms_kl_DiagnosType] as [jT_oms_kl_DiagnosType] on [jT_oms_kl_DiagnosType].[kl_DiagnosTypeID] = [hDED].[rf_kl_DiagnosTypeID]
go

