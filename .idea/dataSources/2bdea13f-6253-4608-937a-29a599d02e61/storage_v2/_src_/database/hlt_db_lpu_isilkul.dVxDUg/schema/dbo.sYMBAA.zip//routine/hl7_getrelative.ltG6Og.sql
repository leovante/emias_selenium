
create function hl7_GetRelative
(
	@DocumentGuid VARCHAR(100),
	@TemplateCode VARCHAR(50)
 )
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE     @result  VARCHAR(max)
	DECLARE		@XmlData xml	
	SET @result = '' 
	
	SET @XmlData = 
		(select TOP(1) CONVERT(XML,mr.Data) from hlt_MedRecord mr 
			join hlt_BlankTemplate bt on mr.rf_BlankTemplateID = bt.BlankTemplateID
		where bt.Code = @TemplateCode AND mr.DescGuid = @DocumentGuid )
	
	DECLARE @text VARCHAR(MAX)
	SET @text = 
'                                    <text>
                                        <table border="1">
                                            <thead>
                                                <tr>
                                                    <th>Отношение к пациенту</th>
                                                    <th>Заболевание</th>
                                                    <th>Дата смерти</th>
                                                    <th>Причина смерти</th>
                                                </tr>
                                            </thead>
                                            <tbody>'
	
			
	DECLARE @I INT
	SET @I = 1
		WHILE (@I <= 3)
			BEGIN
			IF NOT((dbo.GetInstanseId(@XmlData,'refMKB'+CONVERT(VARCHAR,@I)) = '' or dbo.GetInstanseId(@XmlData,'refMKB'+CONVERT(VARCHAR,@I)) = '0' ))
			BEGIN
				DECLARE @MKB_CODE VARCHAR(10) 
				SET @MKB_CODE = (SELECT DS FROM oms_MKB WHERE MKBID = dbo.GetInstanseId(@XmlData,'refMKB'+CONVERT(VARCHAR,@I)))
				DECLARE @DeathMKB_CODE VARCHAR(10) 
				SET @DeathMKB_CODE = (SELECT DS FROM oms_MKB WHERE MKBID = dbo.GetInstanseId(@XmlData,'refMKBDeath'+CONVERT(VARCHAR,@I)))


				SET @text = @text + '
                                                <tr>
                                                    <td align="center">' + (SELECT NameNSI FROM hl7_CatalogValue WHERE CatalogValueID = dbo.GetInstanseId(@XmlData,'refFamily'+CONVERT(VARCHAR,@I))) +'</td>
                                                    <td align="center">'+ dbo.GetCatalogValue('1.2.643.5.1.13.2.1.1.641',@MKB_CODE,(SELECT NAME FROM oms_mkb WHERE ds = @MKB_CODE)) +'</td>
                                                    <td align="center">'+case when ( dbo.GetInstanseId(@XmlData,'refMKBDeath'+CONVERT(VARCHAR,@I)) != '' AND dbo.GetInstanseId(@XmlData,'refMKBDeath'+CONVERT(VARCHAR,@I)) != '0' )
						      then + dbo.GetValueFromXMl(@XmlData,'DateDeath'+CONVERT(VARCHAR,@I)) else '' end + '</td>
                                                    <td align="center">'+case when ( dbo.GetInstanseId(@XmlData,'refMKBDeath'+CONVERT(VARCHAR,@I)) != '' AND dbo.GetInstanseId(@XmlData,'refMKBDeath'+CONVERT(VARCHAR,@I)) != '0' )
						      then + dbo.GetCatalogValue('1.2.643.5.1.13.2.1.1.641',@DeathMKB_CODE,dbo.GetValueFromXMl(@XmlData,'refMKBDeath'+CONVERT(VARCHAR,@I)))   else '' end + '</td>
                                                </tr>'
					 
				select @result = @result +
'
                                    <entry>
                                        <templateId root="1.2.643.5.1.13.2.7.5.4.4"/>          
                                        <observation classCode="OBS" moodCode="EVN">
                                            <templateId root="1.2.643.5.1.13.2.7.5.3.13"/>
                                            <code code="FAMILY" codeSystem="1.2.643.5.1.13.2.7.1.12" codeSystemName="Система кодирования событий" displayName="Семейный (наследственный) анамнез"/>
                                            <value code="' + dbo.GetCatalogCode('1.2.643.5.1.13.2.1.1.641',@MKB_CODE,@MKB_CODE)+ '" codeSystem="1.2.643.5.1.13.2.1.1.641" codeSystemName="Международная классификация болезней и состояний, связанных со здоровьем, Десятого пересмотра. Версия 2" displayName="' + dbo.GetCatalogValue('1.2.643.5.1.13.2.1.1.641',@MKB_CODE,(SELECT NAME FROM oms_mkb WHERE ds = @MKB_CODE)) + '" xsi:type="CD"/>
                                            <subject>
                                                <relatedSubject classCode="PRS">
                                                <code code="' + (SELECT CodeNSI FROM hl7_CatalogValue WHERE CatalogValueID = dbo.GetInstanseId(@XmlData,'refFamily'+CONVERT(VARCHAR,@I))) + '" codeSystem="1.2.643.5.1.13.2.7.1.15" codeSystemName="Отношение к пациенту" displayName="' + (SELECT NameNSI FROM hl7_CatalogValue WHERE CatalogValueID = dbo.GetInstanseId(@XmlData,'refFamily'+CONVERT(VARCHAR,@I))) + '">
                                                    <originalText>' + dbo.GetValueFromXMl(@XmlData,'FamilyDescr'+CONVERT(VARCHAR,@I)) + '</originalText>
                                                </code>
                                                </relatedSubject>
                                            </subject> '
					+
					case when ( dbo.GetInstanseId(@XmlData,'refMKBDeath'+CONVERT(VARCHAR,@I)) != '' AND dbo.GetInstanseId(@XmlData,'refMKBDeath'+CONVERT(VARCHAR,@I)) != '0' )
					then                  
'                                            <entryRelationship typeCode="CAUS">
                                                <observation classCode="OBS" moodCode="EVN">
                                                    <code code="FAMDEATH" codeSystem="1.2.643.5.1.13.2.7.1.12" codeSystemName="Система кодирования событий" displayName="Сбор семейного анамнеза"/>
                                                    <value xsi:type="CD" code="' + dbo.GetCatalogCode('1.2.643.5.1.13.2.1.1.641',@DeathMKB_CODE,@DeathMKB_CODE) + '" codeSystem="1.2.643.5.1.13.2.1.1.641" codeSystemName="Международная классификация болезней и состояний, связанных со здоровьем, Десятого пересмотра. Версия 2" displayName="' +  dbo.GetCatalogValue('1.2.643.5.1.13.2.1.1.641',@DeathMKB_CODE,(SELECT TOP(1) mkb.NAME FROM oms_MKB mkb WHERE mkb.mkbid = dbo.GetInstanseId(@XmlData,'refMKBDeath'+CONVERT(VARCHAR,@I))  )) +'/>"
                                                    <interpretationCode code="' + (SELECT TOP(1) cv.CodeNSI FROM hl7_CatalogValue cv WHERE cv.CatalogValueID =  dbo.GetInstanseId(@XmlData,'refDeathMkbType'+CONVERT(VARCHAR,@I))) + '" codeSystem="1.2.643.5.1.13.2.7.1.13" codeSystemName="Тип диагноза" displayName="' + (SELECT TOP(1) cv.NameNSI FROM hl7_CatalogValue cv WHERE cv.CatalogValueID =  dbo.GetInstanseId(@XmlData,'refDeathMkbType'+CONVERT(VARCHAR,@I))) + '"/>
                                                </observation>
                                            </entryRelationship>'
					else ''
					end +
					'
                                        </observation>
                                    </entry>'
			END
			SET @I = @I + 1
			END

	IF (ISNULL(@result,'') = '')
		RETURN NULL

	SET @text = @text  +
'
                                            </tbody>
                                        </table>
                                    </text>'
	RETURN @text + @result
          
END
go

