CREATE VIEW [V_hlt_FluorPlan] AS SELECT 
[hDED].[FluorPlanID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_UchastokID] as [rf_UchastokID], 
[hDED].[rf_EnterpriseID] as [rf_EnterpriseID], 
[jT_hlt_Enterprise].[NumEnt] as [SILENT_rf_EnterpriseID], 
[hDED].[rf_FluorContingentID] as [rf_FluorContingentID], 
[jT_hlt_FluorContingent].[Code] as [SILENT_rf_FluorContingentID], 
[hDED].[rf_FluorGroupRiskID] as [rf_FluorGroupRiskID], 
[jT_hlt_FluorGroupRisk].[Code] as [SILENT_rf_FluorGroupRiskID], 
[hDED].[rf_FluorTypePlanID] as [rf_FluorTypePlanID], 
[jT_hlt_FluorTypePlan].[Code] as [SILENT_rf_FluorTypePlanID], 
[hDED].[MonthPlan] as [MonthPlan], 
[hDED].[YearPlan] as [YearPlan], 
[hDED].[Amount] as [Amount]
FROM [hlt_FluorPlan] as [hDED]
INNER JOIN [hlt_Enterprise] as [jT_hlt_Enterprise] on [jT_hlt_Enterprise].[EnterpriseID] = [hDED].[rf_EnterpriseID]
INNER JOIN [hlt_FluorContingent] as [jT_hlt_FluorContingent] on [jT_hlt_FluorContingent].[FluorContingentID] = [hDED].[rf_FluorContingentID]
INNER JOIN [hlt_FluorGroupRisk] as [jT_hlt_FluorGroupRisk] on [jT_hlt_FluorGroupRisk].[FluorGroupRiskID] = [hDED].[rf_FluorGroupRiskID]
INNER JOIN [hlt_FluorTypePlan] as [jT_hlt_FluorTypePlan] on [jT_hlt_FluorTypePlan].[FluorTypePlanID] = [hDED].[rf_FluorTypePlanID]
go

