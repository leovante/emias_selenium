CREATE VIEW [V_dd_DDRstNSI] AS SELECT 
[hDED].[DDRstNSIID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[NRst] as [NRst], 
[hDED].[DateRstBeg] as [DateRstBeg], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[GuidRst] as [GuidRst], 
[hDED].[FLAG] as [FLAG]
FROM [dd_DDRstNSI] as [hDED]
go

