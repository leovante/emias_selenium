CREATE VIEW [V_oms_regs_RegisterColumn] AS SELECT 
[hDED].[regs_RegisterColumnID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_regs_RegisterID] as [rf_regs_RegisterID], 
[jT_oms_regs_Register].[TypeName] as [SILENT_rf_regs_RegisterID], 
[hDED].[rf_DocElemDef] as [rf_DocElemDef], 
[hDED].[rf_UserGuid] as [rf_UserGuid]
FROM [oms_regs_RegisterColumn] as [hDED]
INNER JOIN [oms_regs_Register] as [jT_oms_regs_Register] on [jT_oms_regs_Register].[regs_RegisterID] = [hDED].[rf_regs_RegisterID]
go

