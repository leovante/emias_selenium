CREATE function [dbo].[HttpGetMethod]
(
@url varchar(8000)
)
returns varchar(8000)as
BEGIN
	DECLARE @win int
	DECLARE @HttpWinRequest  int
	DECLARE @ResultText varchar(8000)

	EXEC @HttpWinRequest=sp_OACreate 'WinHttp.WinHttpRequest.5.1',@win OUT

	IF @HttpWinRequest <> 0 EXEC sp_OAGetErrorInfo @win
	
	EXEC @HttpWinRequest=sp_OAMethod @win, 'Open',NULL,'GET',@url,'false'

	IF @HttpWinRequest <> 0 EXEC sp_OAGetErrorInfo @win
		
	EXEC @HttpWinRequest=sp_OAMethod @win,'Send'

	IF @HttpWinRequest <> 0 EXEC sp_OAGetErrorInfo @win

	EXEC @HttpWinRequest=sp_OAGetProperty @win,'ResponseText',@ResultText OUTPUT

	IF @HttpWinRequest <> 0 EXEC sp_OAGetErrorInfo @win

	EXEC @HttpWinRequest=sp_OADestroy @win

	IF @HttpWinRequest <> 0 EXEC sp_OAGetErrorInfo @win
	RETURN @ResultText
END
go

