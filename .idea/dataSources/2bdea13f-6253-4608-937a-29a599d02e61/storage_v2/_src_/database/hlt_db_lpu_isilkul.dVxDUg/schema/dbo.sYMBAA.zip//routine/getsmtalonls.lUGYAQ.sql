
CREATE FUNCTION [dbo].[GetSmTalonLS] (@MigrationPatientID int)
RETURNS TABLE
AS
RETURN
(
select v_oms_ls.LSID, convert(date,plp.date) Date_B, V_NAME_MNN
from stt_plposition plp
inner join stt_purposeLS pls on plp.rf_PurposeLSID = pls.PurposeLSID 
inner join v_oms_ls on convert(varchar (20),NOMK_LS) =convert(varchar (20), CodeRAS )
inner join oms_MNName on rf_MNNameID=MNNameID
inner join stt_listofpurpose lop on plp.rf_listofpurposeid=listofpurposeid
inner join stt_MigrationPatient mp on mp.rf_MedicalHistoryID=lop.rf_MedicalHistoryID and mp.rf_StationarBranchID =lop.rf_StationarBranchID 
left join onco_Talon OT on OT.rf_MigrationPatientID=MigrationPatientID
left  join onco_SmTalon OST on ost.rf_TalonID =TalonID 
left join oms_onco_N013 on OST.rf_onco_N013ID=onco_N013ID
left  join onco_smTalonLS on rf_SmTalonid =SmTalonid and convert(date,plp.date)=convert(date,onco_smTalonLS.date_b) and onco_smTalonLS.rf_LSID=v_oms_ls.LSID
where
 ( [rf_FARGID] in (select [FARGID] from [V_oms_FARG] where [V_oms_FARG].[FNAME_FRG] like '%противоопух%' or [V_oms_FARG].[FNAME_FRG] like '%Алкилир%') or  rf_mnnameid in (select mnnameid from oms_mnname where c_mnn in('2071','3392')))
and
 rf_CancelDoctorID=0 --and ID_TLech in (2,4)
and onco_smTalonLS.smTalonLSID is null
and MigrationPatientID =@MigrationPatientID
 group by   convert(date,plp.date),v_oms_ls.LSID,V_NAME_MNN
);
go

