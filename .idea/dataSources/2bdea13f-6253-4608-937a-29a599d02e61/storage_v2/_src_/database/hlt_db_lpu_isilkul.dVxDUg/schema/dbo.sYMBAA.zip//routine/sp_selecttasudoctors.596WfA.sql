
CREATE procedure [dbo].[sp_selectTasuDoctors]
	@fam varchar(100), 
	@im varchar(100),
	@ot varchar(100),
	@pcod varchar(10),
	@result varchar(254) output
as
begin
	set @result = ''

	if not exists(select 1 from sys.tables where name = 'tmp_cl5000' and [type] = 'U')
		set @result = 'CL5000.dbf, '

	if not exists(select 1 from sys.tables where name = 'tmp_cl5100' and [type] = 'U')
		set @result = @result + 'CL5100.dbf, '
	
	if not exists(select 1 from sys.tables where name = 'tmp_cl5200' and [type] = 'U')
		set @result = @result + 'CL5200.dbf, '

	if (@result = '')
	begin
		select top 100
			cast(ROW_NUMBER() OVER(ORDER BY c1.rpname DESC) as int) AS Id, --идентификатор записи для отображения,
			convert(varchar(20), c1.pcod) as PCod, -- код врача в ТАСУ (аналог hlt_LPUDoctor.PCOD)
			convert(varchar(15), c1.scode) as SCode, -- код специалиста в ТАСУ (аналог hlt_DocPRVD.PCOD) 
			convert(varchar(254), c1.rpname) as RPName, -- наименование специалиста в ТАСУ (фио + отеделение)
			convert(varchar(4), isnull(c1.prvd, '')) as PrvdCode, -- код должности по справочнику oms_PRVD
			convert(varchar(100), isnull(p.NAME, '')) as PrvdName,  -- наименование должности по справочнику oms_PRVD
			convert(varchar(15), isnull(c2.spcode, '')) as Spcode, -- код отделения в ТАСУ
			convert(varchar(254), isnull(c2.spname, '')) as Spname,  -- наименование отделения в ТАСУ
			convert(varchar(10), isnull(rtrim(lpu.mcod), '')) as MCOD, --МКОД ЛПУ
			convert(varchar(254), isnull(lpu.M_NAMES, '')) as M_NAMES, --Наименование ЛПУ (Короткое)
			convert(varchar(36), c1.cod_U) as GuidTasuDoctor, -- уникальный идентификатор (ГУИД) специалиста в ТАСУ
			convert(varchar(30), rtrim(ltrim(c3.fam))) as Family, --Фамилия
			convert(varchar(25), rtrim(ltrim(c3.im))) as Name, --Имя
			convert(varchar(25), rtrim(ltrim(c3.ot))) as OT  --Отчество
		from tmp_cl5100 c1
		left join tmp_cl5000 c2 on c1.spcode = c2.spcode and c1.mcod = c2.mcod
		join tmp_cl5200 c3 on c1.pcod = c3.pcod and c1.mcod = c3.mcod
		left join oms_PRVD p on c1.prvd = p.C_PRVD
		left join oms_LPU lpu on lpu.mcod = c1.mcod
		where c3.fam like @fam + '%' and c3.im like @im + '%' and c3.ot like @ot + '%' and c3.pcod like '%' + @pcod + '%'
	end
	else
		set @result = 'Отсутствуют следующие таблицы: ' + SUBSTRING(@result, 1, LEN(@result) - 1)		
end
go

