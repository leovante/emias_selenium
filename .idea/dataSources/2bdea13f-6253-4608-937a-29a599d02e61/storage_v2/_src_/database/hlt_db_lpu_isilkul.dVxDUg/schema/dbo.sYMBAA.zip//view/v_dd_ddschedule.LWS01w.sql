CREATE VIEW [V_dd_DDSchedule] AS SELECT 
[hDED].[DDScheduleID], [hDED].[x_Edition], [hDED].[x_Status], 
case DATEPART(year,DateBeginPeriod) when 1900 then 'Не установлен' else 'c ' + Convert(varchar,DateBeginPeriod,104) + ' г.  по ' + Convert(varchar,DateEndPeriod,104) + ' г.' end as [Caption], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[jT_dd_DDType].[Name] as [SILENT_rf_DDTypeGUID], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateBeginPeriod] as [DateBeginPeriod], 
[hDED].[DateEndPeriod] as [DateEndPeriod], 
[hDED].[Flag] as [Flag]
FROM [dd_DDSchedule] as [hDED]
INNER JOIN [dd_DDType] as [jT_dd_DDType] on [jT_dd_DDType].[UGUID] = [hDED].[rf_DDTypeGUID]
go

