CREATE VIEW [V_die_MaritalStatus] AS SELECT 
[hDED].[MaritalStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [die_MaritalStatus] as [hDED]
go

