CREATE VIEW [V_oms_ARecipe_Reestr] AS SELECT 
[hDED].[ARecipe_ReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Recipe_Reestr_Num] as [Recipe_Reestr_Num], 
[hDED].[Recipe_Reestr_Begin_Date] as [Recipe_Reestr_Begin_Date], 
[hDED].[Recipe_Reestr_End_Date] as [Recipe_Reestr_End_Date], 
[hDED].[Recipe_Count] as [Recipe_Count], 
[hDED].[Recipe_Sum] as [Recipe_Sum], 
[hDED].[upload_date] as [upload_date], 
[hDED].[Guid] as [Guid]
FROM [oms_ARecipe_Reestr] as [hDED]
go

