CREATE VIEW [V_hlt_FluorResearchResult] AS SELECT 
[hDED].[FluorResearchResultID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_FluorResearchResult] as [hDED]
go

