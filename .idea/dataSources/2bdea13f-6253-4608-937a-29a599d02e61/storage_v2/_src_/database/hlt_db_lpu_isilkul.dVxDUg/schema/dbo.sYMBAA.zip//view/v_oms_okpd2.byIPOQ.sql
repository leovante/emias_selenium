CREATE VIEW [V_oms_OKPD2] AS SELECT 
[hDED].[OKPD2ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[NAME] as [NAME], 
[hDED].[CODE] as [CODE], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Rem] as [Rem]
FROM [oms_OKPD2] as [hDED]
go

