CREATE VIEW dbo.sysutility_ucp_deployed_dacs
AS
SELECT
   dac_id,    -- todo (VSTS #345036): This column will be removed
   dac_name,
   dac_deploy_date AS dac_deployed_date,
   dac_description AS dac_description,
   dac_percent_total_cpu_utilization AS dac_percent_total_cpu_utilization,
   server_instance_name AS dac_server_instance_name,
   physical_server_name AS dac_physical_server_name,
   batch_time AS dac_collection_time,
   processing_time AS dac_processing_time,
   urn,
   powershell_path
FROM dbo.syn_sysutility_ucp_dacs;
go

