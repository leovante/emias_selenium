CREATE PROCEDURE sp_dts_secure
	@flag	INT
AS
	SET NOCOUNT ON

	--// sysadmin only.
	IF (ISNULL(IS_SRVROLEMEMBER(N'sysadmin'), 0) <> 1)
	BEGIN
		RAISERROR(15003, 16, 1, N'sysadmin')
		RETURN(1) -- Failure
	END
	
	IF(@flag <> 0)
	BEGIN
		REVOKE EXECUTE ON sp_get_dtsversion				FROM PUBLIC
		REVOKE EXECUTE ON sp_make_dtspackagename		FROM PUBLIC
		REVOKE EXECUTE ON sp_add_dtspackage				FROM PUBLIC
		REVOKE EXECUTE ON sp_drop_dtspackage			FROM PUBLIC
		REVOKE EXECUTE ON sp_reassign_dtspackageowner	FROM PUBLIC
		REVOKE EXECUTE ON sp_get_dtspackage				FROM PUBLIC
		REVOKE EXECUTE ON sp_enum_dtspackages			FROM PUBLIC
		REVOKE EXECUTE ON sp_log_dtspackage_begin		FROM PUBLIC
		REVOKE EXECUTE ON sp_log_dtspackage_end			FROM PUBLIC
		REVOKE EXECUTE ON sp_log_dtsstep_begin			FROM PUBLIC
		REVOKE EXECUTE ON sp_log_dtsstep_end			FROM PUBLIC
		REVOKE EXECUTE ON sp_log_dtstask				FROM PUBLIC
		REVOKE EXECUTE ON sp_enum_dtspackagelog			FROM PUBLIC
		REVOKE EXECUTE ON sp_enum_dtssteplog			FROM PUBLIC
		REVOKE EXECUTE ON sp_enum_dtstasklog			FROM PUBLIC
		REVOKE EXECUTE ON sp_dump_dtslog_all			FROM PUBLIC
		REVOKE EXECUTE ON sp_dump_dtspackagelog			FROM PUBLIC
		REVOKE EXECUTE ON sp_dump_dtssteplog			FROM PUBLIC
		REVOKE EXECUTE ON sp_dump_dtstasklog			FROM PUBLIC
	END
	ELSE
	BEGIN
		GRANT EXECUTE ON sp_get_dtsversion				TO PUBLIC
		GRANT EXECUTE ON sp_make_dtspackagename			TO PUBLIC
		GRANT EXECUTE ON sp_add_dtspackage				TO PUBLIC
		GRANT EXECUTE ON sp_drop_dtspackage				TO PUBLIC
		GRANT EXECUTE ON sp_reassign_dtspackageowner	TO PUBLIC
		GRANT EXECUTE ON sp_get_dtspackage				TO PUBLIC
		GRANT EXECUTE ON sp_enum_dtspackages			TO PUBLIC
		GRANT EXECUTE ON sp_log_dtspackage_begin		TO PUBLIC
		GRANT EXECUTE ON sp_log_dtspackage_end			TO PUBLIC
		GRANT EXECUTE ON sp_log_dtsstep_begin			TO PUBLIC
		GRANT EXECUTE ON sp_log_dtsstep_end				TO PUBLIC
		GRANT EXECUTE ON sp_log_dtstask					TO PUBLIC
		GRANT EXECUTE ON sp_enum_dtspackagelog			TO PUBLIC
		GRANT EXECUTE ON sp_enum_dtssteplog				TO PUBLIC
		GRANT EXECUTE ON sp_enum_dtstasklog				TO PUBLIC
		GRANT EXECUTE ON sp_dump_dtslog_all				TO PUBLIC
		GRANT EXECUTE ON sp_dump_dtspackagelog			TO PUBLIC
		GRANT EXECUTE ON sp_dump_dtssteplog				TO PUBLIC
		GRANT EXECUTE ON sp_dump_dtstasklog				TO PUBLIC
	END
	
	RETURN 0
go

