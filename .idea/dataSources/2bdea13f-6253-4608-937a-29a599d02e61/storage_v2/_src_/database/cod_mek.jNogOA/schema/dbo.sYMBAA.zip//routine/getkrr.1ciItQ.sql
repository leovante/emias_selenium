
create FUNCTION [dbo].[GetKRR](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int,
@prervxml varchar(max)
)
RETURNS @result TABLE (
vidID int,
info varchar(max),
[Value] [decimal](38, 6) NULL

)
AS
begin
Declare @xml xml
declare @Sh varchar(max)
declare @Op varchar(max)
declare @DopDS varchar(max)
declare @prerv varchar(10)
set @xml =convert(xml,@prervxml)

set @Sh=''
set @Op=''
set @DopDs=''
set @prerv=''

select  @Sh= t.x.value('@Sh[1]',  'varchar(max)'),
@Op=t.x.value('@Op[1]',  'varchar(max)')
from @xml.nodes('/a') t(x) 

select  @DopDs=t.x.value('@DopDS[1]',  'varchar(max)')
from @xml.nodes('/b') t(x) 

select  top 1 @prerv=Code
 from (
select t.x.value('@dateOut[1]',  'datetime') as Dt, 
  t.x.value('@rf_kl_DepartmentTypeId[1]', 'int') as DepartementTypeID,
  t.x.value('@rf_lpuid[1]', 'int') as lpuid,
  t.x.value('@rf_kl_DepartmentProfileID[1]','int') as DepartementProfileID,
  t.x.value('@Code[1]','varchar') as Code
from   @xml.nodes('/Prerv ') as t(x)
  )t 
where lpuid=@lpuid and @profileId =DepartementProfileID and DepartementTypeID=@typeid


INSERT INTO @result
select (select krrVidId from oms_krrvid where vidK_Code ='KR1'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR1' and @age<1  and  @usl1  not in ('181107','181108','181109','181110','181111','181112','181113')
     and @usl1  not like '%[-]%' union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR2'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR2' and @age<=3 and @age >=1 and @typeid=rf_kl_DepartmentTypeid 
     and @usl1  not like '%[-]%'
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='КороткОп'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='КороткОп' and @typeid=rf_kl_DepartmentTypeid and @usl1 not in (
'181002','181003','181004','181005','181011','181012','181016','181086','181314','181146','181147','181148','181149','181150','181151','181152','181153',
'181154','181155','181159','181099','181157','181167','181168','181172','181173','181174','181198','181219','181271','181301','181316','181320',
'182001','182003','182004','182038','182118','182054','182055','182056','182057','182058','182059','182060','182061','182039','182063','182065','182066',
'182069','182071','182072','182084','182112','182121'
)  and  @dlit<=3 and @usl2 like 'A16.%'
     and @usl1  not like '%[-]%'
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='Коротк'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='Коротк' and @typeid=rf_kl_DepartmentTypeid and @usl1 not in (
'181002','181003','181004','181005','181011','181012','181016','181086','181314','181146','181147','181148','181149','181150','181151','181152','181153',
'181154','181155','181159','181099','181157','181167','181168','181172','181173','181174','181198','181219','181271','181301','181316','181320',
'182001','182003','182004','182038','182118','182054','182055','182056','182057','182058','182059','182060','182061','182039','182063','182065','182066',
'182069','182071','182072','182084','182112','182121'
)  and  @dlit<=3 and @usl2 not like 'A%'

     and @usl1  not like '%[-]%'
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='Длин'),'',0.75+ 0.25*@dlit/ 
case when @usl1 in      ('181045','181046','181108','181109','181161','181162','181233','181279','181280','181298') and @dlit > 45 then 45
     when @usl1 not in  ('181045','181046','181108','181109','181161','181162','181233','181279','181280','181298') and @dlit > 30 then 30
	 else @dlit end
	 from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId   where    V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='Длин' and

( 
( @usl1 in      ('181045','181046','181108','181109','181161','181162','181233','181279','181280','181298') and @dlit > 45) or
( @usl1 not in  ('181045','181046','181108','181109','181161','181162','181233','181279','181280','181298') and @dlit > 30) 
)

 and V_oms_krr.rf_kl_DepartmentTypeId=@typeId
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='1'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='1' and @typeid=rf_kl_DepartmentTypeid and @usl1  not like '%[-]%'
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR3'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR3' and @age>=75 and @usl1 <>  '181339' and @typeid=rf_kl_DepartmentTypeid union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR4'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR4' and @typeid=rf_kl_DepartmentTypeid and dbo.IsPathology(@DopDS)>0  union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR5'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR5' and @typeid=rf_kl_DepartmentTypeid and dbo.IsKSLP5(@Op,@Sh )>0  
 
 
 
 declare @info varchar(max)
 set @info=''

  return end
go

