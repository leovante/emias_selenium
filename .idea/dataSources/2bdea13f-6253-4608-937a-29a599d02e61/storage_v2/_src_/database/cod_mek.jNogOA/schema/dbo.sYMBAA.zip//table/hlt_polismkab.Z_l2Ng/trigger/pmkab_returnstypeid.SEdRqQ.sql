
CREATE TRIGGER [dbo].[pmkab_ReturnsTypeID] 
   ON [dbo].[hlt_PolisMKAB]
   AFTER INSERT, UPDATE
AS 
BEGIN
    SET NOCOUNT ON;

    update hlt_ReestrTAPMH
    set rf_ReestrMHReturnsTypeID = 0
    from hlt_ReestrTAPMH 
 join hlt_TAP on TAPID=rf_TAPID
    join inserted i on i.PolisMKABID = hlt_TAP.rf_PolisMKABID
END
go

