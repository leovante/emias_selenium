CREATE VIEW [V_hlt_SpecEventCert] AS SELECT 
[hDED].[SpecEventCertID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CODE] as [CODE], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_SpecEventCert] as [hDED]
go

