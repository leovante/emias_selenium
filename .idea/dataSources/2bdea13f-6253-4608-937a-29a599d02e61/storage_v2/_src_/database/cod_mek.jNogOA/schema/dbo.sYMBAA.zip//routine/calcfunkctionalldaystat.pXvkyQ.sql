

---- ================================================
---- Template generated from Template Explorer using:
---- Create Scalar Function (New Menu).SQL
----
---- Use the Specify Values for Template Parameters 
---- command (Ctrl-Shift-M) to fill in the parameter 
---- values below.
----
---- This block of comments will not be included in
---- the definition of the function.
---- ================================================
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
---- =============================================
---- Author:		<Author,,Name>
---- Create date: <Create Date, ,>
---- Description:	<Description, ,>
---- =============================================
CREATE FUNCTION [dbo].[CalcFunkctionAllDayStat]
(
	@beginHosp datetime, @endHosp datetime, @StartHospitalTime datetime
)
RETURNS int 
AS
BEGIN

	declare @t datetime,  @d datetime
	declare @dt int , @ts int
	set @t= @endHosp

	if (CONVERT(datetime,@endHosp,121)='1900-01-01 00:00:00') return 0
	if(@t<@beginHosp)
	begin
		set @endHosp = @beginHosp
        set @beginHosp = @t
	end

	if(CONVERT(VARCHAR(8),@beginHosp,108)>CONVERT(VARCHAR(8),@StartHospitalTime,108))
		set @beginHosp =  DateAdd(Day,1,@beginHosp)
	
	set @d=convert(datetime,replace(convert(varchar(19),@beginHosp,121),CONVERT(VARCHAR(8),@beginHosp,108),CONVERT(VARCHAR(8),@StartHospitalTime,108)),121)

	set @dt=DATEDIFF(dd,@d,@endHosp)
	set @ts=DATEDIFF(ss,@d,@endHosp)
	
	if((@ts-@dt*(24*60*60))>0) set @dt=@dt+1
	if (@dt=0) set @dt=1

	RETURN @dt

END


go

