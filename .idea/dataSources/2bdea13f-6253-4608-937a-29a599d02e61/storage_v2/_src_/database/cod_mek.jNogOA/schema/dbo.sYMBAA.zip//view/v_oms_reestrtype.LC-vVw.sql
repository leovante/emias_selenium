CREATE VIEW [V_oms_ReestrType] AS SELECT 
[hDED].[ReestrTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name]
FROM [oms_ReestrType] as [hDED]
go

