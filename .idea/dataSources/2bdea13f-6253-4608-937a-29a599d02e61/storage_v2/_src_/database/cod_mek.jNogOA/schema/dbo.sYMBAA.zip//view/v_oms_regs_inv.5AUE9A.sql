CREATE VIEW [V_oms_regs_Inv] AS SELECT 
[hDED].[regs_InvID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[COD] as [COD], 
[hDED].[Name] as [Name]
FROM [oms_regs_Inv] as [hDED]
go

