CREATE VIEW [V_hlt_FluorCard] AS SELECT 
[hDED].[FluorCardID], [hDED].[x_Edition], [hDED].[x_Status], 
(select convert(DateTime, '1900-01-01')) as [v_DateFluorResearch], 
(select hDED.Family+ ' '+ hDED.Name+' '+ hDED.OT) as [V_FIO], 
(select '') as [v_ResultFluorResearch], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[Rf_EnterpriseID] as [Rf_EnterpriseID], 
[jT_hlt_Enterprise].[NumEnt] as [SILENT_Rf_EnterpriseID], 
[hDED].[Rf_FluorContingentID] as [Rf_FluorContingentID], 
[hDED].[rf_FluorGroupRiskID] as [rf_FluorGroupRiskID], 
[jT_hlt_FluorGroupRisk].[Code] as [SILENT_rf_FluorGroupRiskID], 
[hDED].[DateFluorCard] as [DateFluorCard], 
[hDED].[NFluorCard] as [NFluorCard], 
[hDED].[ResearchYearsAgo] as [ResearchYearsAgo], 
[hDED].[FAMILY] as [FAMILY], 
[hDED].[NAME] as [NAME], 
[hDED].[OT] as [OT], 
[hDED].[Sex] as [Sex], 
[hDED].[BurdenIll] as [BurdenIll], 
[hDED].[Prof] as [Prof], 
[hDED].[Address] as [Address], 
[hDED].[BD] as [BD], 
[hDED].[DescriptionCard] as [DescriptionCard], 
[hDED].[S_POL] as [S_POL], 
[hDED].[N_POL] as [N_POL], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_FluorCard] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_Enterprise] as [jT_hlt_Enterprise] on [jT_hlt_Enterprise].[EnterpriseID] = [hDED].[Rf_EnterpriseID]
INNER JOIN [hlt_FluorGroupRisk] as [jT_hlt_FluorGroupRisk] on [jT_hlt_FluorGroupRisk].[FluorGroupRiskID] = [hDED].[rf_FluorGroupRiskID]
go

