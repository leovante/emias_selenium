
CREATE FUNCTION [dbo].[GetSignalInfo] (@mkabid int)
RETURNS varchar(max)
AS
BEGIN
	DECLARE @result varchar(max) = ''
	
	-- Флюороосмотр.
	set @result = 'Дата последней ФЛГ: ' + 
	              isnull((select convert(varchar(10), max(fr.DateFluorResearch), 104)
	                      from hlt_FluorCard fc WITH (NOLOCK)
	                      join hlt_FluorResearch fr WITH (NOLOCK) on fr.rf_FluorCardID = fc.FluorCardID
                          where fc.rf_MKABID = @mkabid), '')
	
	-- Диспансерный учет.
	if exists
	(
	  select *
	  from hlt_RegMedicalCheck WITH (NOLOCK)
	  where (rf_MKABID = @mkabid)
	    and (isClosed = 0)
	)
	begin
	  set @result += '\nДиспансерный учет: состоит'
	  
	  set @result += '\nДата последнего посещения ДУ: ' + 
	                 isnull((select convert(varchar(10), max(ItWasDate), 104)
	                         from hlt_RegMedicalCheck rmc WITH (NOLOCK)
	                         join hlt_DUVisit duv WITH (NOLOCK) on rmc.RegMedicalCheckID = duv.rf_ReqMedicalCheckID
	                         where (rmc.rf_MKABID = @mkabid)
	                           and (duv.isAppearance = 1)), '')
	end
	else
	begin
	  set @result += '\nДиспансерный учет: не состоит'
	end
	
	-- Диспансеризация и профилактический осмотр для прикрепленных к терапевтическому участку (код типа участка 1).
	select @result += '\nДиспансеризация в ' + cast(year(getdate()) as varchar) + ' году: ' + 
	                  case when (year(mkab.DATE_BD) <= year(getdate()) - 21) and ((year(getdate()) - year(mkab.DATE_BD)) % 3 = 0)
	                       then
	                       (
	                         select case when count(*) > 0 then 'пройдена' else 'не пройдена' end
	                         from hlt_TAP tap WITH (NOLOCK)
	                         join oms_kl_VisitResult vr WITH (NOLOCK) on vr.kl_VisitResultID = tap.rf_kl_VisitResultID
	                         where (tap.rf_MKABID = @mkabid)
	                           and (year(tap.DateTAP) = year(getdate()))
	                           and (tap.IsClosed = 1)
	                           and (vr.CODE in ('316', '317', '318', '319', '352', '353', '355', '356', '357', '358'))
	                       )
	                       else 'не подлежит' +
	                       (
	                         select case when count(*) > 0 then '\nПроф.осмотр: пройден' else '\nПроф.осмотр: не пройден' end
	                         from hlt_TAP tap WITH (NOLOCK)
	                         join oms_kl_VisitResult vr WITH (NOLOCK) on vr.kl_VisitResultID = tap.rf_kl_VisitResultID
	                         where (tap.rf_MKABID = @mkabid)
	                           and (year(tap.DateTAP) between (year(mkab.DATE_BD) + (year(getdate()) - year(mkab.DATE_BD)) / 3 * 3 + 1) 
	                                                      and (year(mkab.DATE_BD) + (year(getdate()) - year(mkab.DATE_BD)) / 3 * 3 + 2)
	                               )
	                           and (tap.IsClosed = 1)
	                           and (vr.CODE in ('343', '344', '345'))
	                       )
	                       end
	from hlt_MKAB mkab WITH (NOLOCK)
	join hlt_Uchastok u WITH (NOLOCK) on u.UchastokID = mkab.rf_UchastokID
	join oms_kl_TypeU tu WITH (NOLOCK) on tu.kl_TypeUID = u.rf_kl_TypeUID
	where (mkab.MKABID = @mkabid)
	  and (tu.Type_U = '1')

	RETURN @result
END
go

