
CREATE FUNCTION [dbo].[GetValueFromXml] 
(
	@Date XML,
	@ID VARCHAR(100)
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	RETURN ISNULL((select t.n.value('@value', 'nvarchar(max)') as [value]
												from 
												(SELECT @Date as [data])ttt cross apply ttt.data.nodes('*:root/*:element') t(n)
												where t.n.value('@id', 'nvarchar(max)') in (@ID)),'')
END
go

