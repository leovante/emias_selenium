CREATE VIEW [V_hlt_ReportPeriod] AS SELECT 
[hDED].[ReportPeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
(case month_ot
when 1 then 'Январь'
when 2 then 'Февраль'
when 3 then 'Март'
when 4 then 'Апрель'
when 5 then 'Май'
when 6 then 'Июнь'
when 7 then 'Июль'
when 8 then 'Август'
when 9 then 'Сентябрь'
when 10 then 'Октябрь'
when 11 then 'Ноябрь'
when 12 then 'Декабрь'
else 'не определено'
end + ' ' + cast(year_ot as varchar) + ' г.') as [Year_Month], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[rf_ReportPeriodStateID] as [rf_ReportPeriodStateID], 
[jT_hlt_ReportPeriodState].[Name] as [SILENT_rf_ReportPeriodStateID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Year_Ot] as [Year_Ot], 
[hDED].[Month_Ot] as [Month_Ot], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Description] as [Description]
FROM [hlt_ReportPeriod] as [hDED]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
INNER JOIN [hlt_ReportPeriodState] as [jT_hlt_ReportPeriodState] on [jT_hlt_ReportPeriodState].[ReportPeriodStateID] = [hDED].[rf_ReportPeriodStateID]
go

