CREATE VIEW [V_dd_DDAnamnesticData] AS SELECT 
[hDED].[DDAnamnesticDataID], [hDED].[x_Edition], [hDED].[x_Status], 
((Select HealthIndexName from dd_HealthIndex where dd_HealthIndex.UGUID=rf_DDHealthIndexGUID)) as [V_HealthIndex], 
(case when (Select dd_HealthIndex.UGUID from dd_HealthIndex 
where dd_HealthIndex.UGUID=rf_DDHealthIndexGUID
and rf_DDHealthIndexDataTypeGUID='DF461BBD-6C07-4887-B580-3EB50B7541A1'
) is NULL then Value else
case when Value=0 then 'Нет'
when Value=1 then 'Да'
else 'Не известно' end end) as [V_State], 
[hDED].[rf_DDStateOfHealthIndexGUID] as [rf_DDStateOfHealthIndexGUID], 
[hDED].[rf_DDHealthIndexGUID] as [rf_DDHealthIndexGUID], 
[hDED].[Value] as [Value], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDAnamnesticData] as [hDED]
go

