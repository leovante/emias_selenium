CREATE VIEW [V_oms_ipra_IPRA] AS SELECT 
[hDED].[ipra_IPRAID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_regs_RegisterMemberID] as [rf_regs_RegisterMemberID], 
[jT_oms_regs_RegisterMember].[rf_LPUID] as [SILENT_rf_regs_RegisterMemberID], 
[hDED].[ProtocolNum] as [ProtocolNum], 
[hDED].[ProtocolDate] as [ProtocolDate], 
[hDED].[IpraNum] as [IpraNum], 
[hDED].[PRG] as [PRG], 
[hDED].[DevelopDate] as [DevelopDate], 
[hDED].[IdInBuro] as [IdInBuro], 
[hDED].[LoadDate] as [LoadDate], 
[hDED].[ExportDate] as [ExportDate], 
[hDED].[IsExport] as [IsExport], 
[hDED].[IssueDate] as [IssueDate], 
[hDED].[IsForChild] as [IsForChild], 
[hDED].[IsFirst] as [IsFirst], 
[hDED].[IsUntil18] as [IsUntil18], 
[hDED].[IsIndefiniteEndDate] as [IsIndefiniteEndDate], 
[hDED].[IsAgree] as [IsAgree], 
[hDED].[XmlIPRA] as [XmlIPRA], 
[hDED].[GUID] as [GUID], 
[hDED].[EndDate] as [EndDate], 
[hDED].[IsClosed] as [IsClosed], 
[hDED].[ClosedDate] as [ClosedDate], 
[hDED].[IsActive] as [IsActive], 
[hDED].[LpuSenderName] as [LpuSenderName]
FROM [oms_ipra_IPRA] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_regs_RegisterMember] as [jT_oms_regs_RegisterMember] on [jT_oms_regs_RegisterMember].[regs_RegisterMemberID] = [hDED].[rf_regs_RegisterMemberID]
go

