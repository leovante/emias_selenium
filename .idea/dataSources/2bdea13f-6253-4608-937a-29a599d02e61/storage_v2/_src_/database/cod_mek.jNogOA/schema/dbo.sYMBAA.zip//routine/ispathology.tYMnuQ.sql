

create FUNCTION [dbo].[IsPathology](@ListDSDop varchar(max))

RETURNS  [integer]

AS

begin

return isnull ((select count(*) from 
(select t.Item DS from dbo.TableFromString(@ListDSDop,',') t
 ) z  where 
DS like 'E10%' or 
DS like 'E11%' or 
DS like 'E84%' or 
DS like 'G80%' or
DS like 'B2[01234]' or
ds like 'C85%' or
ds like 'C82%' or
DS in (
'C92.1','C88.0','C90.0', 'C83.0','C83.1','C83.3','C83.4','C83.8','C83.9','C84.5',
'C91.1','Z94.0','Z94.1','Z94.4', 'Z94.8','D59.3','D59.5','D61.9','D68.2','D69.3',
'D84.1','E22.8','E70.0', 'E70.1','E70.2','E71.0','E71.1','E71.3','E72.1','E72.3',
'E74.2','E75.2','E76.0', 'E76.1','E76.2','E80.2','E83.0','Q78.0','I27.0','M08.2',
'Z20.6','D66', 'D67','D68.0','E84','G35','E23.0','E75.5')),0) 

end


go

