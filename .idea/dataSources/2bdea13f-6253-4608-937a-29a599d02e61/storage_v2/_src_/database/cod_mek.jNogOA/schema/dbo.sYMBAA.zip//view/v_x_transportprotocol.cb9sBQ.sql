
/* поправить вьюхи */

CREATE VIEW [V_x_TransportProtocol] as select TransportProtocolID, x_Edition, x_Status, 
[TP_GUID],[TP_Name],[TP_DATA],[LinkedTableName], [LinkedTableName] as 
[LinkedTableNameVSV],[ProtocolType],[Title] from [x_TransportProtocol]
go

