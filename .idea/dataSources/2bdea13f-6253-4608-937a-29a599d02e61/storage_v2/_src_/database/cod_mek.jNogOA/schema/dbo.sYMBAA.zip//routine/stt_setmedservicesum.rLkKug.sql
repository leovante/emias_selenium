
create procedure [dbo].[stt_SetMedServiceSum](@MedServID int)
as
begin
  declare @per decimal(38,8),@smID int, @rows int;  
  Set @per=1.00000
  set @rows = 0
  Select @per=@per*Value,@rows = @rows+1 from oms_krrvalue
  where rf_DocObjID=@MedServID
  
 
  update stt_MedServicePatient
  set Sum_Usl = (
    Select case when @rows>0 then value1 else @per end as summa from stt_MedServicePatient        
        inner join oms_Tariff on TariffID=rf_TariffID
    where MedServicePatientID=@MedServID) * [Count]
  where MedServicePatientID=@MedServID
end
go

