CREATE VIEW [V_oms_mn_UrzPeriod] AS SELECT 
[hDED].[mn_UrzPeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[PeriodStartDate] as [PeriodStartDate], 
[hDED].[PeriodEndDate] as [PeriodEndDate], 
[hDED].[PeriodLoadDate] as [PeriodLoadDate]
FROM [oms_mn_UrzPeriod] as [hDED]
go

