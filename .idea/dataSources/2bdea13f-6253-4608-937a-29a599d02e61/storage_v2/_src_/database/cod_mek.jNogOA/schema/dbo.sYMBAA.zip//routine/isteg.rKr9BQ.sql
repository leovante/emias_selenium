-- =============================================
create FUNCTION [dbo].[isTeg]
(
	@str varchar(max),
	@teg_begin varchar(50),
	@teg_end varchar(50),
	@teg  varchar(50)
)
RETURNS int
AS
BEGIN
	declare @i int 
declare  @i1 int
declare @i2 int
declare @i3 int
declare @i4 int
set @i=1
while (1=1) 
begin 
select @i1=CHARINDEX(@teg_begin,@str,@i) , @i2=CHARINDEX(@teg_end,@str,@i+1)  
if(@i2=0 and @teg_end='<USL>') 

set @i2=CHARINDEX('</SLUCH>',@str,@i+1)  
if(@i1>@i2) 
begin 
set @i3=@i1
set @i1=@i2
set @i2=@i3
end

if @i1>0 and @i<len(@str)   begin
if (substring (@str, @i1, @i2-@i1) not like @teg)

return 1
end 
else return 0
set @i=@i2
end 

return 0

END


go

