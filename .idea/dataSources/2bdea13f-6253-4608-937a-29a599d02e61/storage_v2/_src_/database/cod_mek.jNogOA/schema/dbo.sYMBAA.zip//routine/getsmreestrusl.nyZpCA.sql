



CREATE FUNCTION [dbo].[GetSMReestrUsl](@id int)  RETURNS @fld TABLE (   [Номер] int ,  [Группа] varchar(250) ,      [Параметр] varchar(50) ,   [Значение] varchar(250),      [Значение из справочника] varchar(500),      [Заголовок] varchar(50) ,   [Описание] varchar(500) ,      [Справочник]       varchar(50),      [Поле справочника] varchar(50) , [Множественное значение] varchar(50)  )  AS  
 begin  INSERT INTO @fld 
 select 0 , '''','Пациент' as nm,convert(varchar(50),[rf_SMReestrSluchID]), isnull((select top 1 convert(varchar(150),[V_V_FIO]) from [V_oms_SMReestrSluch] where [SMReestrSluchID]=s.[rf_SMReestrSluchID]),'! Нет в справочнике') as Ref ,'ФИО Пациента','ФИО Пациента' as Dn ,'[oms_SMReestrSluch]','[SMReestrSluchID]',''  from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  1, '''','IDServ' as nm,[IDServ] ,'' as Ref ,'Номер записи в реестре услуг','Номер записи в реестре услуг' as Dn ,'' as Tab,'' as Field,''    from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  2,'''','LPU' as nm,[LPU] , isnull((select top 1 convert(varchar(150),[M_names]) from [V_oms_LPU] where mcod=s.[LPU]),'! Нет в справочнике') as Ref ,'МО','МО лечения' as Dn ,'[oms_LPU]','[Mcod]',''  from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  3, '''','LPU_1' as nm,[LPU_1] , isnull((select top 1 convert(varchar(150),[M_names]) from [V_oms_LPU] where mcod=s.[LPU_1]),'! Нет в справочнике') as Ref ,'Подразделение МО','Подразделение МО лечения из регионального справочника' as Dn ,'[oms_LPU]','[Mcod]',''  from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  4,'Мед.помощь','Podr' as nm,convert(varchar(50),[Podr]), isnull((select top 1 convert(varchar(150),[DepartmentName]) from [V_oms_Department] where convert(varchar(50),[DepartmentCODE])=convert(varchar(50),s.[PODR])),'! Нет в справочнике') as Ref ,'Отделение МО','Отделение МО лечения из регионального справочника' as Dn ,'[oms_Department]','[DepartmentCODE]',''  from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  5,'Мед.помощь','Profil' as nm,convert(varchar(50),[Profil]), isnull((select top 1 convert(varchar(150),[Name]) from [V_oms_kl_DepartmentProfile] where convert(varchar(50),[Code])=convert(varchar(50),s.[PROFIL])),'! Нет в справочнике') as Ref ,'Профиль','Профиль. Классификатор V003' as Dn ,'[oms_kl_DepartmentProfile]','[Code]',''  from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  6,'Мед.помощь','VID_VME' as nm,[VID_VME] , isnull((select top 1 convert(varchar(150),[ServiceMedicalName]) from [V_oms_ServiceMedical] where convert(varchar(50),[ServiceMedicalCode])=convert(varchar(50),s.[VID_VME])),'! Нет в справочнике') as Ref ,'Вид медицинского вмешательства','Указывается в соответствии с номенклатурой медицинских услуг (V001)' as Dn ,'[oms_ServiceMedical]','[ServiceMedicalCode]',''  from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union
select   7,'Мед.помощь','Det' as nm,convert(varchar(50),[Det]),case when Det='1' then 'Да' else 'Нет' end  as Ref ,'Детский профиль','Детский профиль; 0-нет, 1-да' as Dn ,'' as Tab,'' as Field,''    from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  8,'''','Date_IN' as nm,Replace(convert(varchar(50),[Date_IN],121),' 00:00:00.000',''),'' as Ref ,'Дата начала оказания услуги','Дата начала оказания услуги' as Dn ,'' as Tab,'' as Field,''    from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  9,'''','Date_OUT' as nm,Replace(convert(varchar(50),[Date_OUT],121),' 00:00:00.000',''),'' as Ref ,'Дата окончания оказания услуги','Дата окончания оказания услуги' as Dn ,'' as Tab,'' as Field,''    from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  10,'Стандарт','DS' as nm,[DS] , isnull((select top 1 convert(varchar(150),[Name]) from [V_oms_MKB] where convert(varchar(50),[DS])=convert(varchar(50),s.[DS])),'! Нет в справочнике') as Ref ,'Диагноз','Диагноз' as Dn ,'[oms_MKB]','[DS]' ,''  from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  11,'Мед.помощь','Code_USL' as nm,[Code_USL] , isnull((select top 1 convert(varchar(150),[ServiceMedicalName]) from [V_oms_ServiceMedical] where convert(varchar(50),[ServiceMedicalCode])=convert(varchar(50),s.[CODE_USL])),'! Нет в справочнике') as Ref ,'Услуга','Территориальный классификатор услуг' as Dn ,'[oms_ServiceMedical]','[ServiceMedicalCode]',''  from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  12,'Стоимость','Kol_USL' as nm,convert(varchar(50),[Kol_USL]),'' as Ref ,'Количество услуг','Количество услуг (кратнось услуги)' as Dn ,'' as Tab,'' as Field,''    from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  13,'Стоимость','Tarif' as nm,convert(varchar(50),[Tarif_Usl]),'' as Ref ,'Тариф','Тариф' as Dn ,'' as Tab,'' as Field,''    from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  14,'Стоимость','SUMV_USL' as nm,convert(varchar(50),[SUMV_USL]),'' as Ref ,'Стоимость','Стоимость медицинской услуги, принятая к оплате (руб.)' as Dn ,'' as Tab,'' as Field ,''   from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  15, '''','PRVS' as nm,convert(varchar(50),[PRVS]), isnull((select top 1 convert(varchar(150),[PRVS_NAME]) from [V_oms_PRVS] where convert(varchar(50),[C_PRVS])=convert(varchar(50),s.[PRVS])),'! Нет в справочнике') as Ref ,'Специальность медработника, выполнившего услугу','Специальность медработника, выполнившего услугу' as Dn ,'[oms_PRVS]','[C_PRVS]',''  from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  16,'Мед.помощь','Code_MD' as nm,[CODE_MD] , isnull((select top 1 convert(varchar(150),[V_DocInfo]) from V_hlt_LPUDoctor inner join oms_LPU on rf_LPUID=LPUID where convert(varchar(50),ltrim(Rtrim(C_OGRN))+' '+ltrim(Rtrim(PCOD)))=convert(varchar(50),s.[CODE_MD])),'! Нет в справочнике') as Ref ,'Медицинский работник','Медицинский работник, оказавшего медицинскую услугу' as Dn ,'[hlt_LPUDoctor]','[V_PCOD]',''  from oms_SMReestrusl s where SMReestruslID = convert(varchar(10),@id)

union  
select  17,'''','NPL' as nm,convert(varchar(5),Npl),
case when NPL=0 then ''
 when NPL=1 then 'Документированный отказ больного'
 when NPL=2 then 'Медицинские противопоказания'
 when NPL=3 then 'Прочие причины (умер, переведён в другое отделение и пр.)'
 when NPL=4 then 'Ранее проведённые услуги в пределах установленных сроков'
else 'неправильное значение' end  as Ref ,'Неполный объём','Указывается причина, по которой услуга не оказана или оказана не в полном объёме.' as Dn ,'' as Tab,'' as Field ,''   from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
union  
select  18,'''','ComentU' as nm,substring([ComentU],1,50),'' as Ref ,'Примечание.','Примечание. Служебное поле' as Dn ,'' as Tab,'' as Field,''    from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)

--union  select  '''','SumV_Usl' as nm,convert(varchar(50),[SumV_Usl]),'' as Ref ,'Стоимость услуги','Стоимость услуги' as Dn ,'' as Tab,'' as Field    from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)
--union  select  '''','Usl' as nm,substring([Usl],1,50),'' as Ref ,'Наименование услуги','Наименование услуги' as Dn ,'' as Tab,'' as Field    from oms_SMReestrUsl s where SMReestrUslID = convert(varchar(10),@id)

 RETURN  end

go

