CREATE VIEW [V_oms_mn_DocLPU] AS SELECT 
[hDED].[mn_DocLPUID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Rem] as [Rem], 
[hDED].[DocTypeDefGUID] as [DocTypeDefGUID]
FROM [oms_mn_DocLPU] as [hDED]
go

