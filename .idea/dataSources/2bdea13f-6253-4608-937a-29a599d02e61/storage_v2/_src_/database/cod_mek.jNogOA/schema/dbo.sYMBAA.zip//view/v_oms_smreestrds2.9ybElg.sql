CREATE VIEW [V_oms_SMReestrDS2] AS SELECT 
[hDED].[SMReestrDS2ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[jT_oms_SMReestrSluch].[IDCase] as [SILENT_rf_SMReestrSluchID], 
[hDED].[DS2] as [DS2], 
[hDED].[DS2_PR] as [DS2_PR], 
[hDED].[PR_DS2_N] as [PR_DS2_N]
FROM [oms_SMReestrDS2] as [hDED]
INNER JOIN [oms_SMReestrSluch] as [jT_oms_SMReestrSluch] on [jT_oms_SMReestrSluch].[SMReestrSluchID] = [hDED].[rf_SMReestrSluchID]
go

