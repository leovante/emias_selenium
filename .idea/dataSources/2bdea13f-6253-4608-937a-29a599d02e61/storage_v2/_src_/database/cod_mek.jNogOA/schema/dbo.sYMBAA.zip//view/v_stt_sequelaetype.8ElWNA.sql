CREATE VIEW [V_stt_SequelaeType] AS SELECT 
[hDED].[SequelaeTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_SequelaeType] as [hDED]
go

