
-- Процедура проверяет 'загруженнный' dbf - файл на следующие ошибки
-- Не проставлены ключевые поля , Дубли , Не поднятые ссылки
-- в результате работы будет создан файл rd_[Код загружаемой таблицы]
-- а в случае ошибок еще и err_[Код загружаемой таблицы]
CREATE PROCEDURE [dbo].[OMS_LoadError]
@Code_T int,    /*Код таблицы с данными для загрузки НСИ*/
@Result varchar(100)='' OUTPUT

AS

BEGIN TRY 
/*Переменные для функции*/
	Declare @tab_oms varchar(100), 
			@tab_dbf varchar(100),
			@key_dbf varchar(400),
			@key_oms varchar(400),
			@desc_table varchar(50),
			@desc_key varchar(500),
			@QueryDBF nvarchar(max),
			@SQL nvarchar(max),
			@SQL1 nvarchar(max),
			@id   int,
			@name_dbf varchar(100);

/*Инициализация переменных*/
	Select	@id        = LoadNSITableID,
		    @tab_oms   = headtable,
			@desc_table= caption,
	        @name_dbf  = Name_DBF,
		
/*Описание ключей*/
			@key_dbf   = Key_dbf,
			@key_oms   = key_oms,
/*Запроc*/ 
			@QueryDBF  = Query_DBF
	from oms_LoadNSITable 
		inner join x_DocTypeDef on headtable=Table_Name
	where Code=@Code_T


	if exists(select * from sysobjects where [name] = 'tt_oms_key') drop table tt_oms_key

--Получить ключи для таблицы OMS в промежуточную таблицу tt_oms_key
	Set @SQL='Select x_DocElemDef.Caption,x_DocElemDef.[Name],case when LinkedDocTypeDefId>0 then ''1'' else ''0'' end as IsRef, '+
		' case when x_DocElemDef.Name in ('''+Replace(@key_oms,',',''',''')+ ''') then ''1'' else ''0'' end IsKey '+
		' into tt_oms_key from x_DocElemDef
				inner join x_DocTypeDef on x_DocElemDef.DocTypeDefID=x_DocTypeDef.DocTypeDefID
				where ( x_DocElemDef.Name in ('''+Replace(@key_oms,',',''',''')+''') or LinkedDocTypeDefId>0) and headtable='''+@tab_oms+ ''' and ElemType<''3'''

	EXECUTE sp_executesql @SQL

END TRY 
BEGIN CATCH 
	Set @Result='Не прошла инициализация параметров для таблицы - '+@tab_oms;
END CATCH;

BEGIN TRY

/*Поиск записей, у  которых дубли по ключу в таблице DBF*/
SET @SQL = 'Insert into oms_LoadNSIResult Select 1,1,'+cast(@id as varchar)+' as rf_LoadNSITable,''Дубли'' as ErrorName,'''+@name_dbf+''' as Name_LT,
'''+@desc_table+''' as Desc_LT, 
 '''+@key_dbf+''' as Name_Field,'''+@desc_key+''' as Desc_Field,'+'isnull(cast('+Replace(@key_dbf,',',' as varchar(255)),'''')+'', ''+isnull(cast( ')
+' as varchar(255)),'''')  as ValueField,count(*) as Kol,'''' as Rem,(Select max(LoadNSIReestrID) from oms_LoadNSIReestr) as rf_LoadNSIReestrID from ['+@tab_dbf+'] GROUP BY '+'isnull(cast('+Replace(@key_dbf,',',' as varchar(255)),'''')+'', ''+isnull(cast( ')
+' as varchar(255)),'''')  HAVING COUNT(*)>1'
print @SQL
EXECUTE sp_executesql @SQL
Set @Result='Проверка завершена успешно для таблицы - '+@tab_oms;
END TRY 
BEGIN CATCH 
Set @Result='Не была проверена таблица DBF - '+@tab_dbf;
END CATCH

BEGIN TRY
	set @SQL = 'if exists(select * from sysobjects where [name] = ''rd_'+ convert(varchar(10), @Code_T)+''') drop table rd_'+convert(varchar(10), @Code_T)
	EXECUTE sp_executesql @SQL


	declare @dbf_col     nvarchar(max)
    declare @dbf_col_Rev     nvarchar(max)
	declare @dbf_col_key nvarchar(max)

	set @dbf_col=''
	set @dbf_col_Rev=''
	set @dbf_col_key=''


--Получим набор всех полей из DBF 
	select @dbf_col = @dbf_col+ 't.['+[name]+'] as [dbf_'+[name]+']',
		   @dbf_col_Rev = @dbf_col_Rev+ 't.[dbf_'+[name]+'] as ['+[name]+']' from sys.columns
	where object_id  = object_id(@Name_DBF)
	set @dbf_col = Replace (@dbf_col,']t','],t')
    set @dbf_col_Rev = Replace (@dbf_col_Rev,']t','],t')

--Получим набор полей для ключей в DBF
	select @dbf_col_key = @dbf_col_key+'t.[dbf_'+[name]+'] = d.[dbf_'+[name]+']' from sys.columns
	where object_id  = object_id(@Name_DBF) and Replace(@key_dbf,[name],'')<>@key_dbf
	set @dbf_col_key = Replace (@dbf_col_key,']t','],t')

--Получим таблицу 
	Select @SQL=replace(@QueryDBF,'"','''')+','+@dbf_col+', cast('''' as nvarchar(max)) as ERR  into rd_'+convert(varchar(10), @Code_T)+' from ['+@name_dbf+'] t'
	EXECUTE sp_executesql @SQL
	DECLARE @name varchar(50);
	declare @caption varchar(500);
	declare @IsRef varchar(1);
    declare @IsKey varchar(1);
    Declare cursor_ cursor SCROLL Local Read_ONLY FOR
		select [Caption],[Name], IsRef,IsKey from tt_oms_key where IsREf='1' or IsKey='1'
	OPEN cursor_
	FETCH First FROM cursor_  INTO  @caption,@name,@IsRef,@IsKey 
    WHILE @@FETCH_STATUS = 0
	Begin
--проставим ошибки по незаполненному ключевым или ссылочным полям ОМС
print @Name
		if(@IsKey='1')
				set @SQL = ' update rd_'+convert(varchar(10), @Code_T)+' set Err = '' ! Не заполнен ключ_['+@name+']-'+@caption+'; ''+Err where ['+@name+'] is null or ['+@name+']=''0'' or Convert(varchar(50),['+@name+'])='''''
				else 
                 set @SQL = ' update rd_'+convert(varchar(10), @Code_T)+' set Err = Err+'' Нет ссылки_['+@name+']-'+@caption+';'' where ['+@name+']=''0'''

			EXECUTE sp_executesql @SQL
        
		FETCH NEXT FROM cursor_
		INTO @caption,@name,@IsRef,@IsKey 
	END
	Close cursor_;
	DEALLOCATE cursor_;

--проставим ошибки по дублям в ключевом поле ДБФ
	set @SQL = 'update rd_'+convert(varchar(10), @Code_T)+' set Err='' ! Дубли['+@key_dbf +'];''+Err from rd_'+convert(varchar(10), @Code_T)+' t, (select dbf_'+(replace(@key_dbf,',',',dbf_'))+' from rd_'++convert(varchar(10), @Code_T)++
						' group by dbf_'+(replace(@key_dbf,',',',dbf_'))+' having count(*)>1) d where '+Replace(@dbf_col_key,',',' and ')
print @SQL
	EXECUTE sp_executesql @SQL
--проставим ошибки по дублям в ключевом поле ОМС

	declare @key_oms_kol nvarchar(max)
	set @key_oms_kol=''
	select @key_oms_kol = @key_oms_kol+'t.['+[Name]+']=d.['+[Name]+']' from tt_oms_key where IsKey='1'
	set @key_oms_kol = Replace (@key_oms_kol,']t','],t')
--проставим ошибки по дублям в ключевом поле ДБФ

	set @SQL = 'update rd_'+convert(varchar(10), @Code_T)+' set Err='' ! Дубли['+@key_oms +'];''+Err from rd_'+convert(varchar(10), @Code_T)+' t, (select '+@key_oms+' from rd_'+convert(varchar(10), @Code_T)+
				' group by '+@key_oms+' having count(*)>1) d where '+Replace(@key_oms_kol,',',' and ')
print @SQL
	EXECUTE sp_executesql @SQL
	
	set @SQL = 'if exists(select * from sysobjects where [name] = ''err_'+ convert(varchar(10), @Code_T)+''') drop table err_'+convert(varchar(10), @Code_T)
print @SQL
	EXECUTE sp_executesql @SQL
print @SQL
	set @SQL = ' if exists (select * from rd_'+convert(varchar(10), @Code_T) +' where Len(Err)>0) 	select '+@dbf_col_rev+', convert (varchar(255),Err) as ERR into Err_'+convert(varchar(10), @Code_T)+' from RD_'+convert(varchar(10), @Code_T)+' t where Len(Err)>0 '
	EXECUTE sp_executesql @SQL


	set @SQL = 'INSERT INTO [oms_LoadNSIResult]([rf_LoadNSITableID],[ErrorName],[Name_LT],[Desc_LT],[Kol],[rf_LoadNSIReestrID]) '+
			'select '''+convert(varchar,@id)+''' ,  substring(Err,1,100) , '''+ @name_dbf+''','''+ @desc_table+''', count(*),(Select max(LoadNSIReestrID) from oms_LoadNSIReestr) from rd_'+convert(varchar(10), @Code_T)+' where ERR <>'''' group by substring(ERR,1,100)'
	print @SQL
	EXECUTE sp_executesql @SQL
	

END TRY
BEGIN CATCH 
Set @Result='  '+@tab_dbf;
END CATCH;


go

