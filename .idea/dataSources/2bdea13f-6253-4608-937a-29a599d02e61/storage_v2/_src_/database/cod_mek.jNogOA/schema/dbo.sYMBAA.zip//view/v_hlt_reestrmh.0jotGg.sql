CREATE VIEW [V_hlt_ReestrMH] AS SELECT 
[hDED].[ReestrMHID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[jT_oms_OKATO].[C_OKATO] as [SILENT_rf_OKATOID], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_STFID] as [rf_STFID], 
[jT_oms_STF].[TF_NAME] as [SILENT_rf_STFID], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[jT_oms_Organisation].[ShortName] as [SILENT_rf_OrganisationID], 
[hDED].[rf_ReestrMHTypeID] as [rf_ReestrMHTypeID], 
[jT_hlt_ReestrMHType].[Code] as [SILENT_rf_ReestrMHTypeID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[jT_hlt_ReportPeriod].[Year_Month] as [SILENT_rf_ReportPeriodID], 
[hDED].[rf_ReportPeriodStateID] as [rf_ReportPeriodStateID], 
[jT_hlt_ReportPeriodState].[Name] as [SILENT_rf_ReportPeriodStateID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[BillNum] as [BillNum], 
[hDED].[BillDate] as [BillDate], 
[hDED].[Flag] as [Flag], 
[hDED].[Description] as [Description], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Sum_V] as [Sum_V], 
[hDED].[Kol_V] as [Kol_V], 
[hDED].[Sum_Norm] as [Sum_Norm], 
[hDED].[Count_Norm] as [Count_Norm], 
[hDED].[Discount] as [Discount], 
[hDED].[DiscountSumm] as [DiscountSumm]
FROM [hlt_ReestrMH] as [hDED]
INNER JOIN [oms_OKATO] as [jT_oms_OKATO] on [jT_oms_OKATO].[OKATOID] = [hDED].[rf_OKATOID]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_STF] as [jT_oms_STF] on [jT_oms_STF].[STFID] = [hDED].[rf_STFID]
INNER JOIN [oms_Organisation] as [jT_oms_Organisation] on [jT_oms_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID]
INNER JOIN [hlt_ReestrMHType] as [jT_hlt_ReestrMHType] on [jT_hlt_ReestrMHType].[ReestrMHTypeID] = [hDED].[rf_ReestrMHTypeID]
INNER JOIN [V_hlt_ReportPeriod] as [jT_hlt_ReportPeriod] on [jT_hlt_ReportPeriod].[ReportPeriodID] = [hDED].[rf_ReportPeriodID]
INNER JOIN [hlt_ReportPeriodState] as [jT_hlt_ReportPeriodState] on [jT_hlt_ReportPeriodState].[ReportPeriodStateID] = [hDED].[rf_ReportPeriodStateID]
go

