CREATE VIEW [V_oms_RegistrationCertificate] AS SELECT 
[hDED].[RegistrationCertificateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Number] as [Number]
FROM [oms_RegistrationCertificate] as [hDED]
go

