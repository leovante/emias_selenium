CREATE VIEW [V_oms_SMReestrNAZ_SP] AS SELECT 
[hDED].[SMReestrNAZ_SPID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[NAZ_SP] as [NAZ_SP]
FROM [oms_SMReestrNAZ_SP] as [hDED]
go

