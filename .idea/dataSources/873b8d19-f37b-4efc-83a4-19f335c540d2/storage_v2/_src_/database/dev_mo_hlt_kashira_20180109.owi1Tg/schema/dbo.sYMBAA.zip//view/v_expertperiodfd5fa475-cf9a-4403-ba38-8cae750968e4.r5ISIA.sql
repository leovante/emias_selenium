
CREATE view [V_ExpertPeriodfd5fa475-cf9a-4403-ba38-8cae750968e4] as select * from [tmp_ExpertPeriodfd5fa475-cf9a-4403-ba38-8cae750968e4]
go

