CREATE view [V_ExpertPeriodee952e57-026b-4fd4-9e71-0b2a246f78f2] as select * from [tmp_ExpertPeriodee952e57-026b-4fd4-9e71-0b2a246f78f2]
go

