CREATE view [V_ExpertPeriod99253715-81e6-4a5d-8e93-46500dfb09a1] as select * from [tmp_ExpertPeriod99253715-81e6-4a5d-8e93-46500dfb09a1]
go

