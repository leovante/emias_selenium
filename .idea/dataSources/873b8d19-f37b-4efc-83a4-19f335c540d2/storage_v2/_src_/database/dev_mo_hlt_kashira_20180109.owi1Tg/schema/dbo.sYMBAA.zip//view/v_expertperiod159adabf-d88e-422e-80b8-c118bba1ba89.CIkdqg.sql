
CREATE view [V_ExpertPeriod159adabf-d88e-422e-80b8-c118bba1ba89] as select * from [tmp_ExpertPeriod159adabf-d88e-422e-80b8-c118bba1ba89]
go

