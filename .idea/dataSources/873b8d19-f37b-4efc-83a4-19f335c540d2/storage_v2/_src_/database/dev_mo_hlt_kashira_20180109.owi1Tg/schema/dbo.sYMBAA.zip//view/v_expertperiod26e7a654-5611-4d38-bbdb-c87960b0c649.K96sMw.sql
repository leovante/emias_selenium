CREATE view [V_ExpertPeriod26e7a654-5611-4d38-bbdb-c87960b0c649] as select * from [tmp_ExpertPeriod26e7a654-5611-4d38-bbdb-c87960b0c649]
go

