CREATE view [V_ExpertPeriod81637088-1e70-4bb8-a59d-9cc649f0af82] as select * from [tmp_ExpertPeriod81637088-1e70-4bb8-a59d-9cc649f0af82]
go

