CREATE VIEW [V_dd_CategoryService] AS SELECT 
[hDED].[CategoryServiceID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_dd_DDService].[DDServiceName] as [V_DDServiceName], 
[hDED].[rf_HealingRoomID] as [rf_HealingRoomID], 
[jT_hlt_HealingRoom].[Num] as [SILENT_rf_HealingRoomID], 
[hDED].[rf_DDServiceID] as [rf_DDServiceID], 
[jT_dd_DDService].[DDServiceName] as [SILENT_rf_DDServiceID], 
[hDED].[rf_DDServiceUGUID] as [rf_DDServiceUGUID], 
[hDED].[rf_PatientCategoryID] as [rf_PatientCategoryID], 
[jT_dd_PatientCategory].[CategoryName] as [SILENT_rf_PatientCategoryID], 
[hDED].[rf_PatientCategoryUGUID] as [rf_PatientCategoryUGUID], 
[hDED].[RoomNum] as [RoomNum], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [dd_CategoryService] as [hDED]
INNER JOIN [dd_DDService] as [jT_dd_DDService] on [jT_dd_DDService].[DDServiceID] = [hDED].[rf_DDServiceID]
INNER JOIN [hlt_HealingRoom] as [jT_hlt_HealingRoom] on [jT_hlt_HealingRoom].[HealingRoomID] = [hDED].[rf_HealingRoomID]
INNER JOIN [dd_PatientCategory] as [jT_dd_PatientCategory] on [jT_dd_PatientCategory].[PatientCategoryID] = [hDED].[rf_PatientCategoryID]
go

