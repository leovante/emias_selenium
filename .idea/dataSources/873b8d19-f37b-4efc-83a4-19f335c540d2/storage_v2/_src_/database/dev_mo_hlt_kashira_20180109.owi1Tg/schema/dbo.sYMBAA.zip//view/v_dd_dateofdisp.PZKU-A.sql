CREATE VIEW [V_dd_DateOfDisp] AS SELECT 
[hDED].[DateOfDispID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDFormGUID] as [rf_DDFormGUID], 
[hDED].[rf_PersonOrgUGUID] as [rf_PersonOrgUGUID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Type] as [Type], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[DateEditAnketa] as [DateEditAnketa]
FROM [dd_DateOfDisp] as [hDED]
go

