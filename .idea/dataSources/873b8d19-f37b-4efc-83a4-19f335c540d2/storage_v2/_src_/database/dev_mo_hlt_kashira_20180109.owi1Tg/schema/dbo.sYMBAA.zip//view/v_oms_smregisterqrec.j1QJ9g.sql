CREATE VIEW [V_oms_SMRegisterQRec] AS SELECT 
[hDED].[SMRegisterQRecID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[rf_SMReestrSluchViewID] as [rf_SMReestrSluchViewID], 
[jT_oms_SMReestrSluchView].[inf_Family] as [SILENT_rf_SMReestrSluchViewID], 
[hDED].[rf_SMRegisterQueryID] as [rf_SMRegisterQueryID], 
[jT_oms_SMRegisterQuery].[Num] as [SILENT_rf_SMRegisterQueryID], 
[hDED].[Flags] as [Flags]
FROM [oms_SMRegisterQRec] as [hDED]
INNER JOIN [oms_SMReestrSluchView] as [jT_oms_SMReestrSluchView] on [jT_oms_SMReestrSluchView].[SMReestrSluchViewID] = [hDED].[rf_SMReestrSluchViewID]
INNER JOIN [oms_SMRegisterQuery] as [jT_oms_SMRegisterQuery] on [jT_oms_SMRegisterQuery].[SMRegisterQueryID] = [hDED].[rf_SMRegisterQueryID]
go

