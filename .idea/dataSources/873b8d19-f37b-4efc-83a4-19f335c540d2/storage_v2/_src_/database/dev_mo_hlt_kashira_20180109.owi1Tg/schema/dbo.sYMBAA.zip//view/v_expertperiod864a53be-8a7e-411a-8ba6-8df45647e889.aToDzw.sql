CREATE view [V_ExpertPeriod864a53be-8a7e-411a-8ba6-8df45647e889] as select * from [tmp_ExpertPeriod864a53be-8a7e-411a-8ba6-8df45647e889]
go

