CREATE view [V_ExpertPerioddb42b101-6e20-436b-b87e-6ed5c72db942] as select * from [tmp_ExpertPerioddb42b101-6e20-436b-b87e-6ed5c72db942]
go

