CREATE view [V_ExpertPeriodca2e14aa-d9be-4bed-b7a0-cd4b56e028f8] as select * from [tmp_ExpertPeriodca2e14aa-d9be-4bed-b7a0-cd4b56e028f8]
go

