CREATE view [V_ExpertPeriode66d9d4d-b13c-43c5-8563-9b824e670b62] as select * from [tmp_ExpertPeriode66d9d4d-b13c-43c5-8563-9b824e670b62]
go

