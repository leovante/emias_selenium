CREATE view [V_ExpertPeriod5fa4446d-af7d-4c1b-b8e7-3523c2d68c45] as select * from [tmp_ExpertPeriod5fa4446d-af7d-4c1b-b8e7-3523c2d68c45]
go

