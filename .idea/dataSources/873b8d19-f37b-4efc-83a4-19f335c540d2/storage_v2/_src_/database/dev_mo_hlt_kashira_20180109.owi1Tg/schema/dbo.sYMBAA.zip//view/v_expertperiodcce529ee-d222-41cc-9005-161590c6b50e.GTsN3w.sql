CREATE view [V_ExpertPeriodcce529ee-d222-41cc-9005-161590c6b50e] as select * from [tmp_ExpertPeriodcce529ee-d222-41cc-9005-161590c6b50e]
go

