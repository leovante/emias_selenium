CREATE view [V_ExpertPeriod824502c1-df68-4479-8f82-caaaa06156f5] as select * from [tmp_ExpertPeriod824502c1-df68-4479-8f82-caaaa06156f5]
go

