CREATE view [V_ExpertPeriodf5a017d5-7285-4fba-af45-a8686fb68431] as select * from [tmp_ExpertPeriodf5a017d5-7285-4fba-af45-a8686fb68431]
go

