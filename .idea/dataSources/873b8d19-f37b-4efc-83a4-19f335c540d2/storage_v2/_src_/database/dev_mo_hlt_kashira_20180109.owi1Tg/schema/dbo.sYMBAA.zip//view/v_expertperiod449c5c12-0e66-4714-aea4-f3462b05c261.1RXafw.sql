CREATE view [V_ExpertPeriod449c5c12-0e66-4714-aea4-f3462b05c261] as select * from [tmp_ExpertPeriod449c5c12-0e66-4714-aea4-f3462b05c261]
go

