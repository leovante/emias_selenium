CREATE view [V_ExpertPeriod21884284-2f47-4b76-8530-19eb51d2774a] as select * from [tmp_ExpertPeriod21884284-2f47-4b76-8530-19eb51d2774a]
go

