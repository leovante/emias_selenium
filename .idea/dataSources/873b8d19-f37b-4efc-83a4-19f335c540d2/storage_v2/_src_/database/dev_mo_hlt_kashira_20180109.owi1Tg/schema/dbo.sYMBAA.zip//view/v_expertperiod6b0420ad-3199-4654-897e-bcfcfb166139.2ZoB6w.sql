CREATE view [V_ExpertPeriod6b0420ad-3199-4654-897e-bcfcfb166139] as select * from [tmp_ExpertPeriod6b0420ad-3199-4654-897e-bcfcfb166139]
go

