CREATE VIEW [V_dd_DDExamMKB] AS SELECT 
[hDED].[DDExamMKBID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_DDExamID] as [rf_DDExamID], 
[jT_dd_DDExam].[DateExam] as [SILENT_rf_DDExamID], 
[hDED].[rf_DDExamGUID] as [rf_DDExamGUID], 
[hDED].[rf_DDTypeDiseaseGUID] as [rf_DDTypeDiseaseGUID], 
[hDED].[rf_DDDiscoveryDiseaseGUID] as [rf_DDDiscoveryDiseaseGUID], 
[hDED].[rf_DDStageDiseaseGUID] as [rf_DDStageDiseaseGUID], 
[hDED].[rf_DetectionMkbUGUID] as [rf_DetectionMkbUGUID], 
[hDED].[IsMainDS] as [IsMainDS], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDExamMKB] as [hDED]
INNER JOIN [dd_DDExam] as [jT_dd_DDExam] on [jT_dd_DDExam].[DDExamID] = [hDED].[rf_DDExamID]
go

