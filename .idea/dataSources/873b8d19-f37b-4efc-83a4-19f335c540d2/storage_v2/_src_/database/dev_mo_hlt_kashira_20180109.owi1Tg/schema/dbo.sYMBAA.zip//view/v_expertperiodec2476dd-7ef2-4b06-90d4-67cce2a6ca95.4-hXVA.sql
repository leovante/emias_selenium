CREATE view [V_ExpertPeriodec2476dd-7ef2-4b06-90d4-67cce2a6ca95] as select * from [tmp_ExpertPeriodec2476dd-7ef2-4b06-90d4-67cce2a6ca95]
go

