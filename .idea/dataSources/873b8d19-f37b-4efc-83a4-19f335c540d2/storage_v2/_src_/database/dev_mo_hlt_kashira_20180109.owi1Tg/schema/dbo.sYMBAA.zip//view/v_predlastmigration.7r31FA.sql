
/****** Object:  View [dbo].[v_PredLastMigration]    Script Date: 12/10/2013 18:49:04 ******/
--Кульбабов Василий Леонидович
--Вьюха движения в/из последнего отделения.
--Интересно использовать для получения информации по последнему движению, когда пациент выписан

create view [dbo].[v_PredLastMigration] as
select t.DateRealOutgoing, mp.* from stt_MigrationPatient mp join
(
	SELECT MAX(plmp.DateIngoing) DateIngoing,MAX(cmp.dateIngoing) DateRealOutgoing,plmp.rf_MedicalHistoryID FROM stt_MigrationPatient plmp
		join v_CurentMigrationPatient cmp on cmp.rf_MedicalHistoryID = plmp.rf_MedicalHistoryID 
	where plmp.rf_StationarBranchID>0 and plmp.DateIngoing<cmp.DateIngoing
	group by plmp.rf_MedicalHistoryID
) t on mp.rf_MedicalHistoryID=t.rf_MedicalHistoryID and t.DateIngoing = mp.DateIngoing
go

