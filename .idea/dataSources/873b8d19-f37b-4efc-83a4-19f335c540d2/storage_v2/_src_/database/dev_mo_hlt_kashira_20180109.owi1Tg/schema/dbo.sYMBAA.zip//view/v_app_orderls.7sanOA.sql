CREATE VIEW [V_App_OrderLS] AS SELECT 
[hDED].[OrderLSID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_App_OLSState].[Cod] as [CodeState], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_LimitsID] as [rf_LimitsID], 
[hDED].[rf_OLSStateID] as [rf_OLSStateID], 
[jT_App_OLSState].[State] as [SILENT_rf_OLSStateID], 
[hDED].[Num_Kvartal] as [Num_Kvartal], 
[hDED].[Year] as [Year], 
[hDED].[Description] as [Description], 
[hDED].[Date_Create] as [Date_Create], 
[hDED].[Date_Begin] as [Date_Begin], 
[hDED].[Date_End] as [Date_End], 
[hDED].[MaxCost] as [MaxCost], 
[hDED].[UGUID] as [UGUID]
FROM [App_OrderLS] as [hDED]
INNER JOIN [App_OLSState] as [jT_App_OLSState] on [jT_App_OLSState].[OLSStateID] = [hDED].[rf_OLSStateID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

