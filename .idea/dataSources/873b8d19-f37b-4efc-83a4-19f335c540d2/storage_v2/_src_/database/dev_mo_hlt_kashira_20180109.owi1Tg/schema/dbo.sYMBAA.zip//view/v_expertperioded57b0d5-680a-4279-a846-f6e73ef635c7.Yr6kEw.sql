CREATE view [V_ExpertPerioded57b0d5-680a-4279-a846-f6e73ef635c7] as select * from [tmp_ExpertPerioded57b0d5-680a-4279-a846-f6e73ef635c7]
go

