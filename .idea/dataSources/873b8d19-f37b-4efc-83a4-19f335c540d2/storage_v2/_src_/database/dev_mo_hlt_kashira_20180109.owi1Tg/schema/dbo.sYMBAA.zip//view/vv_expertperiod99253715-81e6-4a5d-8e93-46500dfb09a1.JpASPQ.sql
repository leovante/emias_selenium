
CREATE view [VV_ExpertPeriod99253715-81e6-4a5d-8e93-46500dfb09a1] as 
select v.* from 
(

select  isnull(Lpu_Info,'МО с таким кодом нет') +' || '+isnull(departmentCode,'XX')+' '+  isnull(dep_name,'Код отделения не найден') as dep_name,
Sluch_SUMV as S_all,
        sluch.*, 
		Usl.*, 
		patient.*,
		tmp_zap.*,
		SCHET.*,
		isnull(ReestrMKSBID,0) as ReestrMKSBID,
isnull(TAP.rf_MKABID,0) as rf_MKABID,
isnull(TAP.TAPID,0) as rf_TAPID,
isnull(ReestrMHSMTAPId,0) as  ReestrMHSMTAPId,
isnull(msp.rf_ServiceMedicalID,hlt_SMTAP.rf_omsServiceMedicalID) as rf_ServiceMedicalId, 
isnull(ReestrOccasionID,0) as SU,
isnull(MedicalHistoryId,isnull(msp.rf_MedicalHistoryId,0)) as  SK,
isnull(roc.rf_SMOID,hlt_ReestrMHSMTAP.rf_SMOID) as rf_SMOID,
 
isnull(rf_MedServicePatientId,0) as rf_MedServicePatientId,
isnull(ReestrTAPMHId, 0) as rf_ReestrTAPMHID,
26 as rf_ReportPeriodID,isnull(dep.lpuid,0) as lpuid ,isnull(Lpu_Info,'МО с таким кодом нет') as lpu_name
,isnull(roc.rf_ReestrMHID, hlt_ReestrMHSMTAP.rf_ReestrMHID) as rf_ReestrMHID
from [tmp_Usl99253715-81e6-4a5d-8e93-46500dfb09a1]   usl   

inner join [tmp_schet99253715-81e6-4a5d-8e93-46500dfb09a1]  schet   WITH(NOLOCK)   on 1=1

full join [tmp_Sluch99253715-81e6-4a5d-8e93-46500dfb09a1] sluch   WITH(NOLOCK)    on Sluch_SluchID =USL_rf_SluchId

 

left join hlt_ReestrTAPMH hlt WITH(NOLOCK)  on hlt.Num = Sluch_IDCase and hlt.rf_ReportPeriodID=26 

left join hlt_ReestrMHSMTAP WITH(NOLOCK)  on hlt_ReestrMHSMTAP.rf_ReestrTAPMHID = ReestrTAPMHID and USL_IDServ =hlt_ReestrMHSMTAP.Num and hlt_ReestrMHSMTAP.rf_ReportPeriodID=26

left join hlt_SMTAP WITH(NOLOCK)  on hlt_ReestrMHSMTAP.rF_SMTAPID = hlt_SMTAP.SMTAPID

left  join hlt_TAP tap WITH(NOLOCK)  on tap.TAPID = hlt_SMTAP.rf_TAPID

left join hlt_MKAB WITH(NOLOCK)  on tap.rf_MKABID =MKABID  

left join hlt_PolisMKAB WITH(NOLOCK)  on rf_PolisMKABID= PolisMKABID

left join Oms_TypeDoc hlt_doc       WITH(NOLOCK)  on hlt_MKAB.rf_TYPEDOCID =hlt_doc.TYPEDOCID

left join stt_MedicalHistory mh     WITH(NOLOCK) on  mh.MedicalHistoryID=substring(SLUCH_rf_ZAPID,len(SLUCH_rf_ZAPID)-CHARINDEX ('_',reverse(SLUCH_rf_ZAPID),1)+2,CHARINDEX ('_',reverse(SLUCH_rf_ZAPID),1)-1)
left join stt_ReestrOccasion roc    WITH(NOLOCK) on  roc.rf_MedicalHistoryID = mh.MedicalHistoryID and roc.rf_ReportPeriodID=26

left join stt_MedServicePatient msp   WITH(NOLOCK) on msp.MedServicePatientID   = (USL_IDSERV-16726)

left join stt_ReestrMKSB r            WITH(NOLOCK) on  roc.ReestrOccasionID     = r.rf_ReestrOccasionID and msp.MedServicePatientID=r.rf_MedServicePatientID 


left join Oms_TypeDoc stt_doc         WITH(NOLOCK)  on mh.rf_TYPEDOCID =stt_doc.TYPEDOCID
left join oms_kl_TipOMS sTipOMS       WITH(NOLOCK)  on sTipOMS.kl_TipOMSID=mh.rf_kl_TipOMSID

left join oms_kl_TipOMS aTipOMS       WITH(NOLOCK)  on aTipOMS.kl_TipOMSID=hlt_PolisMKAB.rf_kl_TipOMSID

full join [tmp_zap99253715-81e6-4a5d-8e93-46500dfb09a1]      tmp_zap              WITH(NOLOCK)   on SLUCH_rf_ZapId = ZapID   


full join [tmp_patient99253715-81e6-4a5d-8e93-46500dfb09a1] patient WITH(NOLOCK)   on  rf_ZapID=SLUCH_rf_ZAPID --and patient.Patient_Vpolis=(isnull(aTipOMS.IDDOC,sTipOMS.IDDOC)) 

and isnull(patient.Patient_DOCTYPE,'')=(isnull(hlt_doc.C_DOC,stt_doc.C_DOC))

and isnull(patient.Patient_DOCNUM,'')=(isnull(hlt_MKAB.N_DOC,mh.N_DOC))

and isnull(convert(varchar(50),patient.Patient_DOCser),'')=(isnull(convert(varchar(50),hlt_MKAB.s_DOC), convert(varchar(50),mh.s_DOC)))




left join 
(select lpuid, Replace(m_names,'''','') as m_names,mcod as Code_LPU, convert(varchar(10),Code_department) as departmentCode,  Replace(DepartmentName ,'''','')   as Dep_name from oms_department
inner join oms_lpu on lpuid=rf_lpuid
where departmentId>0
and oms_LPU.C_OGRN='1025002510664'
) dep on (Sluch_LPU_1 = Code_Lpu and  Sluch_Podr = DepartmentCode) 

left join (select Replace(m_names,'''','')  as Lpu_Info, mcod from oms_LPU where lpuid>0
and oms_LPU.C_OGRN ='1025002510664'

) lpu on mcod = Sluch_LPU_1 
)v
go

