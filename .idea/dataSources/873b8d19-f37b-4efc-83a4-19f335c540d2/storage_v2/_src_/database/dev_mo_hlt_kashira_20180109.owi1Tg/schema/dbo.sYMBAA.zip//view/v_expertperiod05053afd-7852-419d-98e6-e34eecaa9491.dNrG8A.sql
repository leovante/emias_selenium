CREATE view [V_ExpertPeriod05053afd-7852-419d-98e6-e34eecaa9491] as select * from [tmp_ExpertPeriod05053afd-7852-419d-98e6-e34eecaa9491]
go

