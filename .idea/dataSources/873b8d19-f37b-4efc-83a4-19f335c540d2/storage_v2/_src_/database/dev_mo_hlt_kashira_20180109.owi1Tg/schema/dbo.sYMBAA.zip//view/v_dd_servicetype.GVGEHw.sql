CREATE VIEW [V_dd_ServiceType] AS SELECT 
[hDED].[ServiceTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ServiceTypeName] as [ServiceTypeName], 
[hDED].[ServiceTypeCode] as [ServiceTypeCode], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [dd_ServiceType] as [hDED]
go

