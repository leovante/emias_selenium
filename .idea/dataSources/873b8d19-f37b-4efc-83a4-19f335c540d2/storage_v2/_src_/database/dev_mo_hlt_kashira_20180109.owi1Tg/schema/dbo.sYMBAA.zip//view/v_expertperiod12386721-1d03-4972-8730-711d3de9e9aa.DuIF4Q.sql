CREATE view [V_ExpertPeriod12386721-1d03-4972-8730-711d3de9e9aa] as select * from [tmp_ExpertPeriod12386721-1d03-4972-8730-711d3de9e9aa]
go

