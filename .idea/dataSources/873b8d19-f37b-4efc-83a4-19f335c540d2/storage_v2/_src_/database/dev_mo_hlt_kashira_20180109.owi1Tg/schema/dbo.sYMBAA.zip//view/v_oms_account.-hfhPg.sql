CREATE VIEW [V_oms_Account] AS SELECT 
[hDED].[AccountID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Date] as [Date], 
[hDED].[Sum] as [Sum], 
[hDED].[Count] as [Count], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[Rem] as [Rem], 
[hDED].[PAID] as [PAID], 
[hDED].[DATE_PAID] as [DATE_PAID]
FROM [oms_Account] as [hDED]
go

