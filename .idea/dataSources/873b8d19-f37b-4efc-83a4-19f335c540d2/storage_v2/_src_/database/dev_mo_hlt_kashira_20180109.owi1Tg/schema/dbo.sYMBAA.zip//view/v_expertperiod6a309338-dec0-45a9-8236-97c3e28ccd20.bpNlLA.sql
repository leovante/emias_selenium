CREATE view [V_ExpertPeriod6a309338-dec0-45a9-8236-97c3e28ccd20] as select * from [tmp_ExpertPeriod6a309338-dec0-45a9-8236-97c3e28ccd20]
go

