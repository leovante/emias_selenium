CREATE VIEW [V_App_Limits] AS SELECT 
[hDED].[LimitsID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_App_LimitsState].[Cod] as [CodeState], 
[hDED].[rf_LimitsStateID] as [rf_LimitsStateID], 
[jT_App_LimitsState].[State] as [SILENT_rf_LimitsStateID], 
[hDED].[Date_Begin] as [Date_Begin], 
[hDED].[Date_End] as [Date_End], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags], 
[hDED].[Num_Kvartal] as [Num_Kvartal], 
[hDED].[Year] as [Year]
FROM [App_Limits] as [hDED]
INNER JOIN [App_LimitsState] as [jT_App_LimitsState] on [jT_App_LimitsState].[LimitsStateID] = [hDED].[rf_LimitsStateID]
go

