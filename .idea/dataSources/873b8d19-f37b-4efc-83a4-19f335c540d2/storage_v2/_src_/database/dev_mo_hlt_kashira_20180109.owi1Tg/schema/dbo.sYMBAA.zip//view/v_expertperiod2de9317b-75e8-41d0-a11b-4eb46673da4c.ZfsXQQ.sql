CREATE view [V_ExpertPeriod2de9317b-75e8-41d0-a11b-4eb46673da4c] as select * from [tmp_ExpertPeriod2de9317b-75e8-41d0-a11b-4eb46673da4c]
go

