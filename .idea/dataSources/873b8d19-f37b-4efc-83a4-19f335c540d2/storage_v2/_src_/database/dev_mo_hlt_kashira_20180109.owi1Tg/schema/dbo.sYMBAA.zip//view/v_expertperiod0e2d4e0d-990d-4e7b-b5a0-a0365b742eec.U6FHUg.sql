CREATE view [V_ExpertPeriod0e2d4e0d-990d-4e7b-b5a0-a0365b742eec] as select * from [tmp_ExpertPeriod0e2d4e0d-990d-4e7b-b5a0-a0365b742eec]
go

