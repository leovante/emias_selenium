CREATE view [V_ExpertPeriodf5d62954-1e8a-48c6-819a-be0e40fd1c36] as select * from [tmp_ExpertPeriodf5d62954-1e8a-48c6-819a-be0e40fd1c36]
go

