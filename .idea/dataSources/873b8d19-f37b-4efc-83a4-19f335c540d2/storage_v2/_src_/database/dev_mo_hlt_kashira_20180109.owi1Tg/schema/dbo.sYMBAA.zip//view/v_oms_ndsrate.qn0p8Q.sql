CREATE VIEW [V_oms_NDSRate] AS SELECT 
[hDED].[NDSRateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[NDS_Code] as [NDS_Code], 
[hDED].[NDS_Name] as [NDS_Name], 
[hDED].[Rate_Num] as [Rate_Num], 
[hDED].[Rate_Denom] as [Rate_Denom], 
[hDED].[Rate] as [Rate], 
[hDED].[NDS_Report] as [NDS_Report], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_NDSRate] as [hDED]
go

