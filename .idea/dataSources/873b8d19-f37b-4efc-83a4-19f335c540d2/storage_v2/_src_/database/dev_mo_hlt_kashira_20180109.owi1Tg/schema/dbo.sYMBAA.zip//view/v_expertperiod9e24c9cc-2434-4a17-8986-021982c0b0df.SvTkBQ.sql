CREATE view [V_ExpertPeriod9e24c9cc-2434-4a17-8986-021982c0b0df] as select * from [tmp_ExpertPeriod9e24c9cc-2434-4a17-8986-021982c0b0df]
go

