CREATE VIEW [V_hlt_atc_MsCategory] AS SELECT 
[hDED].[atc_MsCategoryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_atc_CategoryID] as [rf_atc_CategoryID], 
[jT_hlt_atc_Category].[Name] as [SILENT_rf_atc_CategoryID], 
[hDED].[Name] as [Name], 
[hDED].[TuCode] as [TuCode], 
[hDED].[AgeFrom] as [AgeFrom], 
[hDED].[AgeTo] as [AgeTo], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [hlt_atc_MsCategory] as [hDED]
INNER JOIN [hlt_atc_Category] as [jT_hlt_atc_Category] on [jT_hlt_atc_Category].[atc_CategoryID] = [hDED].[rf_atc_CategoryID]
go

