CREATE view [V_ExpertPeriodf510d2ff-55b0-4943-a27d-8dec8944bbbf] as select * from [tmp_ExpertPeriodf510d2ff-55b0-4943-a27d-8dec8944bbbf]
go

