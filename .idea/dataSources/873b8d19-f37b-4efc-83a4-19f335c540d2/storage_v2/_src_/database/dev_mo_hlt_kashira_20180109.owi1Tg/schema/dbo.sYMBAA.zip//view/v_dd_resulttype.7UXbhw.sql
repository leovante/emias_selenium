CREATE VIEW [V_dd_ResultType] AS SELECT 
[hDED].[ResultTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_dd_DDType].[Name] as [V_Name], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID]
FROM [dd_ResultType] as [hDED]
INNER JOIN [dd_DDType] as [jT_dd_DDType] on [jT_dd_DDType].[UGUID] = [hDED].[rf_DDTypeGUID]
go

