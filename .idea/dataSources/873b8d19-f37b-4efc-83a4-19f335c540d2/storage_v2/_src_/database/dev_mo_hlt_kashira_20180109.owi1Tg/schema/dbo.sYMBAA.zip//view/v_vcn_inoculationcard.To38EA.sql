CREATE VIEW [V_vcn_InoculationCard] AS SELECT 
[hDED].[InoculationCardID], [hDED].[x_Edition], [hDED].[x_Status], 
((select [hded].Fam+ ' '+ [hded].IM+' '+[hded].Ot)) as [V_FIO], 
((select case when [hDED].rf_UchastokID > 0 then '[' + rtrim(ltrim([jT_hlt_Uchastok].CODE)) + '] ' + rtrim(ltrim([jT_hlt_Uchastok].UchastoCaption)) else '' end)) as [V_Uchastok], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_UchastokID] as [rf_UchastokID], 
[jT_hlt_Uchastok].[CODE] as [SILENT_rf_UchastokID], 
[hDED].[rf_AddressID] as [rf_AddressID], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[rf_ContingentID] as [rf_ContingentID], 
[hDED].[Fam] as [Fam], 
[hDED].[Im] as [Im], 
[hDED].[Ot] as [Ot], 
[hDED].[BD] as [BD], 
[hDED].[num] as [num], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[DateClose] as [DateClose], 
[hDED].[GUID] as [GUID]
FROM [vcn_InoculationCard] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [hlt_Uchastok] as [jT_hlt_Uchastok] on [jT_hlt_Uchastok].[UchastokID] = [hDED].[rf_UchastokID]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
go

