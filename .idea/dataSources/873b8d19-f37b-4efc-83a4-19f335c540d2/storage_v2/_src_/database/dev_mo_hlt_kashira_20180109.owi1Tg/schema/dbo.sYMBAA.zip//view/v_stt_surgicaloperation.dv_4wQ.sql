CREATE VIEW [V_stt_SurgicalOperation] AS SELECT 
[hDED].[SurgicalOperationID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_stt_MedicalHistory].[MedCardNum] as [V_MedCardNum], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode], 
[jT_stt_MedicalHistory].[FAMILY] as [V_Family], 
[hDED].[rf_DiagnosAfterID] as [rf_DiagnosAfterID], 
[jT_oms_MKB].[DS] as [SILENT_rf_DiagnosAfterID], 
[hDED].[rf_DoctorID] as [rf_DoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_DoctorID], 
[hDED].[rf_kl_ServiceMedicalID] as [rf_kl_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_kl_ServiceMedicalID], 
[hDED].[rf_TariffID] as [rf_TariffID], 
[jT_oms_Tariff].[Value1] as [SILENT_rf_TariffID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[jT_stt_StationarBranch].[V_BranchInfo] as [SILENT_rf_StationarBranchID], 
[hDED].[rf_ComplicationID] as [rf_ComplicationID], 
[jT_stt_Complication].[Code] as [SILENT_rf_ComplicationID], 
[hDED].[rf_OperationID] as [rf_OperationID], 
[jT_stt_Operation].[Description] as [SILENT_rf_OperationID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_AnesthesiaID] as [rf_AnesthesiaID], 
[jT_stt_Anesthesia].[Name] as [SILENT_rf_AnesthesiaID], 
[hDED].[rf_TypeAnesthesiaID] as [rf_TypeAnesthesiaID], 
[jT_stt_TypeAnesthesia].[Name] as [SILENT_rf_TypeAnesthesiaID], 
[hDED].[rf_SurgOperationResultID] as [rf_SurgOperationResultID], 
[jT_stt_SurgOperationResult].[Name] as [SILENT_rf_SurgOperationResultID], 
[hDED].[rf_TypeSurgOperationInTimeID] as [rf_TypeSurgOperationInTimeID], 
[jT_stt_TypeSurgOperationInTime].[Name] as [SILENT_rf_TypeSurgOperationInTimeID], 
[hDED].[rf_TypeComplicationID] as [rf_TypeComplicationID], 
[jT_stt_TypeComplication].[Name] as [SILENT_rf_TypeComplicationID], 
[hDED].[Date] as [Date], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Annotation] as [Annotation], 
[hDED].[isVMT] as [isVMT], 
[hDED].[CountMorph] as [CountMorph], 
[hDED].[Flag] as [Flag], 
[hDED].[Num] as [Num], 
[hDED].[DataEnd] as [DataEnd]
FROM [stt_SurgicalOperation] as [hDED]
INNER JOIN [stt_MedicalHistory] as [jT_stt_MedicalHistory] on [jT_stt_MedicalHistory].[MedicalHistoryID] = [hDED].[rf_MedicalHistoryID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_kl_ServiceMedicalID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_DiagnosAfterID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_DoctorID]
INNER JOIN [oms_Tariff] as [jT_oms_Tariff] on [jT_oms_Tariff].[TariffID] = [hDED].[rf_TariffID]
INNER JOIN [V_stt_StationarBranch] as [jT_stt_StationarBranch] on [jT_stt_StationarBranch].[StationarBranchID] = [hDED].[rf_StationarBranchID]
INNER JOIN [stt_Complication] as [jT_stt_Complication] on [jT_stt_Complication].[ComplicationID] = [hDED].[rf_ComplicationID]
INNER JOIN [stt_Operation] as [jT_stt_Operation] on [jT_stt_Operation].[OperationID] = [hDED].[rf_OperationID]
INNER JOIN [stt_Anesthesia] as [jT_stt_Anesthesia] on [jT_stt_Anesthesia].[AnesthesiaID] = [hDED].[rf_AnesthesiaID]
INNER JOIN [stt_TypeAnesthesia] as [jT_stt_TypeAnesthesia] on [jT_stt_TypeAnesthesia].[TypeAnesthesiaID] = [hDED].[rf_TypeAnesthesiaID]
INNER JOIN [stt_SurgOperationResult] as [jT_stt_SurgOperationResult] on [jT_stt_SurgOperationResult].[SurgOperationResultID] = [hDED].[rf_SurgOperationResultID]
INNER JOIN [stt_TypeSurgOperationInTime] as [jT_stt_TypeSurgOperationInTime] on [jT_stt_TypeSurgOperationInTime].[TypeSurgOperationInTimeID] = [hDED].[rf_TypeSurgOperationInTimeID]
INNER JOIN [stt_TypeComplication] as [jT_stt_TypeComplication] on [jT_stt_TypeComplication].[TypeComplicationID] = [hDED].[rf_TypeComplicationID]
go

