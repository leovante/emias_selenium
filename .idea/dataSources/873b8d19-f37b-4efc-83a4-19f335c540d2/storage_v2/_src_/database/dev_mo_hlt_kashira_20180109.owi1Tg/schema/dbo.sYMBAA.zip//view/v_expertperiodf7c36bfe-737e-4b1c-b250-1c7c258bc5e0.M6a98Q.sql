CREATE view [V_ExpertPeriodf7c36bfe-737e-4b1c-b250-1c7c258bc5e0] as select * from [tmp_ExpertPeriodf7c36bfe-737e-4b1c-b250-1c7c258bc5e0]
go

