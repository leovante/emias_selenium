
CREATE view [V_ExpertPeriod341fd172-0c4c-4af4-bbbb-d51d8a6397bb] as select * from [tmp_ExpertPeriod341fd172-0c4c-4af4-bbbb-d51d8a6397bb]
go

