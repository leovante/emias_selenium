
CREATE procedure [dbo].[sp_VaccinationPlan]
	@DateBegin datetime, 
	@DateEnd datetime,
	@mkabId int,
	@vg int,
	@reasonId int,
	@result varchar(254) output
AS
BEGIN
	set @result = ''

	declare @dateBd datetime = (select Date_BD from hlt_MKAB where MKABID = @mkabId)
	declare @ic int = (select top 1 InoculationCardID from vcn_InoculationCard where rf_MKABID = @mkabId)

	-- Определение предыдущего шага

	declare @PrevVaccinationType int = 0 
	declare @PrevInoculationDate datetime = @dateBd

	select 
		@PrevVaccinationType = isnull(inoc.rf_VaccinationTypeID, 0), 
		@PrevInoculationDate = isnull(inoc.[DateExecute], @dateBd) 
	from vcn_Inoculation inoc
	join vcn_InoculationCard ic on inoc.rf_InoculationCardID = ic.InoculationCardID
	join vcn_Vaccine vac on inoc.rf_ExecuteVaccineID = vac.VaccineID
	join vcn_VaccineType vt on vac.rf_VaccineTypeID = vt.VaccineTypeID
	join vcn_VaccineToVaccinationGroup v2vg on v2vg.rf_VaccineTypeID = vt.VaccineTypeID
	join vcn_VaccinationGroup vg on v2vg.rf_VaccinationGroupID = vg.VaccinationGroupID
	join vcn_Status st on inoc.rf_StatusID = st.StatusID
	where 
	ic.rf_MKABID = @mkabId -- заданный пациент
	and vg.VaccinationGroupID = @vg -- заданная болезнь
	and st.Code = '2' -- выполненные прививки
	order by inoc.DateExecute desc

	--print @PrevVaccinationType
	--print @PrevInoculationDate

	-- Определение схемы
	declare @contingent int = 0
	declare @w int = (select rf_kl_SexID from hlt_MKAB where MKABID = @mkabId)

	declare @dateNext datetime
	declare @schema int
	declare @schemaStage int

	set @contingent = isnull((select top 1 c2c.rf_ContingentID from vcn_InoculationCard ic
	join vcn_ContingentToCard c2c on c2c.rf_InoculationCardID = ic.InoculationCardID
	where ic.rf_MKABID = @mkabId and c2c.rf_VaccinationGroupID = @vg), 0)



	--print @contingent
	--print @w

	select top 1 
		@schemaStage = ss.SchemaStageID,
		@schema = ss.rf_SchemaID,
		@dateNext = dbo.ymd_AddToDate(@PrevInoculationDate, ss.intervalMinY, ss.intervalMinM, ss.intervalMinD)
	from vcn_SchemaStage ss
	where ss.rf_SchemaID in (
		-- Определение подходящих схем в первом приближении
		select SchemaID 
		from vcn_Schema sch
		where sch.rf_VaccinationGroupID = @vg -- заданная болезнь
		and sch.rf_ReasonID = @reasonId -- заданный календарь
		and isActive = 1 -- активные схемы
		and dbo.ymd_GetDiff(@dateBd, @dateBegin) < RIGHT('000' + cast(sch.ageMaxY as varchar), 3) + RIGHT('00' + cast(sch.ageMaxM as varchar), 2) + RIGHT('00' + cast(sch.ageMaxD as varchar), 2) -- учёт максимального возраста
		and sch.rf_ContingentID = @contingent -- учёт группы риска
		and (sch.rf_kl_SexID = 0 or sch.rf_kl_SexID = @w) -- учёт пола
		)
	and ss.rf_PrevVaccinationTypeID = @PrevVaccinationType -- учёт предыдущего шага
	and RIGHT('000' + cast(ss.ageMinY as varchar), 3) + RIGHT('00' + cast(ss.ageMinM as varchar), 2) + RIGHT('00' + cast(ss.ageMinD as varchar), 2) <= dbo.ymd_GetDiff(@dateBd, @dateEnd) -- учёт минимального возраста
	and dbo.ymd_AddToDate(@PrevInoculationDate, ss.intervalMinY, ss.intervalMinM, ss.intervalMinD) <= @DateEnd -- учёт минимального интервала между шагами
	order by dbo.ymd_AddToDate(@PrevInoculationDate, ss.intervalMinY, ss.intervalMinM, ss.intervalMinD) asc -- поиск шага с минимальной плановой датой следующего шага

	--print @schema
	--print @dateNext
	--print @schemaStage

	-- определение параметров плановой прививки
	if (@DateBegin > @dateNext) SET @dateNext = @DateBegin

	if (select rf_SeasonID from vcn_Schema where SchemaID = @schema) > 0 -- учёт сезона
	begin
		if @dateNext < (select s.DateBegin from vcn_Schema sch join vcn_Season s on sch.rf_SeasonID = s.SeasonID where sch.SchemaID = @schema)
			Set @dateNext = (select s.DateBegin from vcn_Schema sch join vcn_Season s on sch.rf_SeasonID = s.SeasonID where sch.SchemaID = @schema)
	end

	if (@dateNext > @DateEnd) 
		set @result = 'Дата планируемой прививки выходит за пределы периода'
	

	if (@result = '')
	begin
		select 
			@ic,
			@vg,
			ss.rf_NextVaccinationTypeID,
			@dateNext,
			vt.VaccineTypeID,
			ss.rf_SchemaID,
			0,
			0,
			@reasonId
		from vcn_SchemaStage ss
		join vcn_VaccinationType vnt on ss.rf_NextVaccinationTypeID = vnt.VaccinationTypeID
		join vcn_VaccineType vt on ss.rf_VaccineTypeID = vt.VaccineTypeID
		where ss.SchemaStageID = @schemaStage
	end

END
go

