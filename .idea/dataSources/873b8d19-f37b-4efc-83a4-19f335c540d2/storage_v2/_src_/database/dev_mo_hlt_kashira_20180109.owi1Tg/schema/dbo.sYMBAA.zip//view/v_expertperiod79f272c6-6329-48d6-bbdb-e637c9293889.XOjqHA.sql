CREATE view [V_ExpertPeriod79f272c6-6329-48d6-bbdb-e637c9293889] as select * from [tmp_ExpertPeriod79f272c6-6329-48d6-bbdb-e637c9293889]
go

