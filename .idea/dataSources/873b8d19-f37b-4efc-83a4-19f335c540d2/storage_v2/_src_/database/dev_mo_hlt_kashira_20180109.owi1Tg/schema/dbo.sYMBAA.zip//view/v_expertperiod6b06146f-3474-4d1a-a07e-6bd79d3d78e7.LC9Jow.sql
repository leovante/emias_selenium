
CREATE view [V_ExpertPeriod6b06146f-3474-4d1a-a07e-6bd79d3d78e7] as select * from [tmp_ExpertPeriod6b06146f-3474-4d1a-a07e-6bd79d3d78e7]
go

