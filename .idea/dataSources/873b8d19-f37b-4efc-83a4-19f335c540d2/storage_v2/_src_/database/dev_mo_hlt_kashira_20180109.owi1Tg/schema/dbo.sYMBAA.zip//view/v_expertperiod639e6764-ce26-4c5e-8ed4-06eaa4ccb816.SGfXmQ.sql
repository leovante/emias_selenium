CREATE view [V_ExpertPeriod639e6764-ce26-4c5e-8ed4-06eaa4ccb816] as select * from [tmp_ExpertPeriod639e6764-ce26-4c5e-8ed4-06eaa4ccb816]
go

