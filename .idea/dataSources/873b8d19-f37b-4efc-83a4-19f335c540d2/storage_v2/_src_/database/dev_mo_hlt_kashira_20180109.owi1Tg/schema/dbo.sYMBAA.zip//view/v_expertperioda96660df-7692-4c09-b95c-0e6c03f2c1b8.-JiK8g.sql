CREATE view [V_ExpertPerioda96660df-7692-4c09-b95c-0e6c03f2c1b8] as select * from [tmp_ExpertPerioda96660df-7692-4c09-b95c-0e6c03f2c1b8]
go

