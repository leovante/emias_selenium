/*
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dd_spDeleteForm]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[dd_spDeleteForm]
GO
*/
CREATE PROCEDURE [dbo].[dd_spDeleteForm]
   @ddformguid uniqueidentifier,
   @result INT OUT	-- 1-6 - �� ���������, 0 - ���������
AS
BEGIN
--declare @result int;
--declare @ddformguid uniqueidentifier;
--set @ddformguid = '004AE2E8-3E8E-46F1-9444-B8678F7D8010';
DECLARE @tmp_v XML;
-- DDFormID
declare @ddformid int = (select top 1 DDFormID  from dd_DDForm where DDFormGUID = @ddformguid);
-- TAPGuid
declare @ddtapguid uniqueidentifier = (select top 1 TAPGuid  from dd_DDForm where DDFormID = @ddformid);
-- MKABGuid
declare @ddmkabguid uniqueidentifier = (select top 1 MKABGuid  from dd_DDForm where DDFormID = @ddformid);
-- ���
declare @tap int = (select top 1 TAPID from hlt_TAP where UGUID = @ddtapguid);	
-- ����	
declare @mkab int = (select top 1 MKABID from hlt_MKAB where UGUID = @ddmkabguid);

-- ���� ��� ������, �� �������� �� ����������
if exists(select * from hlt_TAP where IsClosed = 1
	AND TAPID = @tap)
begin
	set @result = 1;
	return @result;
end;
-- �������� ��������� ������ ��� ��������
-- dd_DDExam
declare @ddexam table (DDExamID int, DDExamGuid uniqueidentifier);	
insert into @ddexam
	(DDExamID, DDExamGuid)
	select DDExamID, DDExamGuid
	from dd_DDExam
	where rf_DDFormID = @ddformid;
set @tmp_v = (SELECT * FROM @ddexam FOR XML AUTO)
-- dd_DDResearchLF
declare @ddresearch table (DDResearchLFID int);	
insert into @ddresearch
	(DDResearchLFID)
	select DDResearchLFID 
	from dd_DDResearchLF 
	where rf_DDFormID = @ddformid;
set @tmp_v = (SELECT * FROM @ddresearch FOR XML AUTO)
-- lbr_Research
declare @lbrresearch table (ResearchID int, GUID uniqueidentifier, IsComplete bit);	
insert into @lbrresearch
	(ResearchID, IsComplete, GUID)
	select ResearchID, IsComplete, GUID
	from lbr_Research
	where rf_TAPID = @tap;
set @tmp_v = (SELECT * FROM @lbrresearch FOR XML AUTO)
-- ���� ���� ����������� ������������, �� �������� �� ����������
if exists(select IsComplete from @lbrresearch where IsComplete = 1)
begin
	set @result = 2;
	return @result;
end;
-- hlt_ActionSchedule
declare @actionschedule table (ActionScheduleID int, rf_DoctorVisitTableID int);	
insert into @actionschedule
	(ActionScheduleID, rf_DoctorVisitTableID)
	select ActionScheduleID, rf_DoctorVisitTableID
	from hlt_ActionSchedule
	where	(DocTypeDefID =  isnull((select top 1 DocTypeDefID from x_DocTypeDef where HeadTable = 'dd_DDExam'), 0)
			AND rf_DocTypeID in (select DDExamID from @ddexam))
			OR (DocTypeDefID = isnull((select top 1 DocTypeDefID from x_DocTypeDef where HeadTable = 'dd_DDResearchLF'), 0)
			AND rf_DocTypeID in (select DDResearchLFID from @ddresearch));
set @tmp_v = (SELECT * FROM @actionschedule FOR XML AUTO)
if exists(select * from @actionschedule)
begin
	-- hlt_DoctorVisitTable
	declare @doctorvisittable table (DoctorVisitTableID int);	
	insert into @doctorvisittable
		(DoctorVisitTableID)
		select DoctorVisitTableID
		from hlt_DoctorVisitTable
		where	DoctorVisitTableID in (select rf_DoctorVisitTableID from @actionschedule) 
				AND rf_MKABID = @mkab;
	set @tmp_v = (SELECT * FROM @doctorvisittable FOR XML AUTO)
	if exists(select * from @doctorvisittable)
	begin
		-- hlt_VisitHistory
		declare @visithistory table (VisitHistoryID int);	
		insert into @visithistory
			(VisitHistoryID)
			select VisitHistoryID
			from hlt_VisitHistory
			where	rf_DoctorVisitTableID in (select DoctorVisitTableID from @doctorvisittable) 
					AND rf_TAPID = @tap
					OR GUID in (select DDExamGuid from @ddexam );
		set @tmp_v = (SELECT * FROM @visithistory FOR XML AUTO)
		if exists(select * from @visithistory)
		begin
			-- ���� ���� ������ hlt_VisitHistory � hlt_MedRecord, �� �������� �� ����������
			if exists(select MedRecordID
				from hlt_MedRecord
				where	rf_VisitHistoryID in (select VisitHistoryID from @visithistory))
			begin
				--select N'������ � hlt_MedRecord ����������'
				set @result = 3;
				return @result;
			end;
		end;
	end;
end;
-- hlt_SMTAP
declare @smtap table (SMTAPID int);	
insert into @smtap
	(SMTAPID)
	select SMTAPID
	from hlt_SMTAP
	where	rf_TAPID = @tap;
set @tmp_v = (SELECT * FROM @smtap FOR XML AUTO)
if exists(select * from @smtap)
begin
	-- ���� ���� ������ hlt_SMTAP � hlt_ReestrMHSMTAP, �� �������� �� ����������
	if exists(select ReestrMHSMTAPID
		from hlt_ReestrMHSMTAP
		where	rf_SMTAPID in (select SMTAPID from @smtap))
	begin
		--select N'������ hlt_SMTAP ���������� � hlt_ReestrMHSMTAP'
		set @result = 4;
		return @result;
	end;
end;

-- ���� ���� ������ hlt_TAP � hlt_ReestrTAPMH, �� �������� �� ����������
if exists(select ReestrTAPMHID
	from hlt_ReestrTAPMH
	where	rf_TAPID = @tap)
begin
	--select N'��� ���� � hlt_ReestrTAPMH'
	set @result = 5;
	return @result;
end;
-- ���������� ��������� ������ �� ��������
-- lbr_LaboratoryResearch
declare @lbrLabResearch table (LaboratoryResearchID int);	
insert into @lbrLabResearch
	(LaboratoryResearchID)
	select LaboratoryResearchID
	from lbr_LaboratoryResearch
	where	rf_TAPID = @tap
			AND rf_MKABID = @mkab;
set @tmp_v = (SELECT * FROM @lbrLabResearch FOR XML AUTO)
-- dd_DDReestrErrors
declare @r_err table (DDReestrErrorsID int);	
insert into @r_err
	(DDReestrErrorsID)
	select DDReestrErrorsID 
	from dd_DDReestrErrors 
	where rf_DDFormID = @ddformid;
set @tmp_v = (SELECT * FROM @r_err FOR XML AUTO)
-- dd_DDErrors
declare @err table (DDErrorsID int);	
insert into @err
	(DDErrorsID)
	select DDErrorsID 
	from dd_DDErrors 
	where rf_DDFormID = @ddformid;
set @tmp_v = (SELECT * FROM @err FOR XML AUTO)
-- dd_DDFormMKB
declare @formmkb table (DDFormMKBID int);	
insert into @formmkb
	(DDFormMKBID)
	select DDFormMKBID 
	from dd_DDFormMKB 
	where rf_DDFormID = @ddformid;
set @tmp_v = (SELECT * FROM @formmkb FOR XML AUTO)
-- dd_DDStateOfHealthIndex
declare @sohi table (DDStateOfHealthIndexID int, UGUID uniqueidentifier);	
insert into @sohi
	(DDStateOfHealthIndexID, UGUID)
	select DDStateOfHealthIndexID, UGUID
	from dd_DDStateOfHealthIndex 
	where rf_DDFormID = @ddformid;
set @tmp_v = (SELECT * FROM @sohi FOR XML AUTO)
-- dd_ResultValue
declare @res table (ResultValueID int);	
insert into @res
	(ResultValueID)
	select ResultValueID
	from dd_ResultValue 
	where rf_DDFormGUID = @ddformguid;
set @tmp_v = (SELECT * FROM @res FOR XML AUTO)
-- dd_HealthIndicators
declare @indicators table (HealthIndicatorsID int);	
insert into @indicators
	(HealthIndicatorsID)
	select HealthIndicatorsID 
	from dd_HealthIndicators 
	where rf_DDFormGUID = @ddformguid;
set @tmp_v = (SELECT * FROM @indicators FOR XML AUTO)
-- dd_RiskFactors
declare @risk table (RiskFactorsID int);	
insert into @risk
	(RiskFactorsID)
	select RiskFactorsID 
	from dd_RiskFactors 
	where rf_DDFormGUID = @ddformguid;
set @tmp_v = (SELECT * FROM @risk FOR XML AUTO)
-- dd_PersonOrg
declare @personorg table (PersonOrgID int);	
insert into @personorg
	(PersonOrgID)
	select PersonOrgID 
	from dd_PersonOrg 
	where rf_DDFormGUID = @ddformguid;
set @tmp_v = (SELECT * FROM @personorg FOR XML AUTO)
-- dd_DateOfDisp
declare @datedisp table (DateOfDispID int);	
insert into @datedisp
	(DateOfDispID)
	select DateOfDispID 
	from dd_DateOfDisp 
	where rf_DDFormGUID = @ddformguid;
set @tmp_v = (SELECT * FROM @datedisp FOR XML AUTO)
-- ������ �������
-- dd_DDExamMKB
declare @exammkb table (DDExamMKBID int);	
insert into @exammkb
	(DDExamMKBID)
	select DDExamMKBID
	from dd_DDExamMKB 
	where rf_DDExamID in (select DDExamID from @ddexam);
set @tmp_v = (SELECT * FROM @exammkb FOR XML AUTO)
-- dd_DDExamService
declare @service table (DDExamServiceID int);	
insert into @service
	(DDExamServiceID)
	select DDExamServiceID
	from dd_DDExamService 
	where rf_DDExamID in (select DDExamID from @ddexam);
set @tmp_v = (SELECT * FROM @service FOR XML AUTO)
-- dd_DDResearchLFService
declare @serviceresch table (DDResearchLFServiceID int);	
insert into @serviceresch
	(DDResearchLFServiceID)
	select DDResearchLFServiceID
	from dd_DDResearchLFService 
	where rf_DDResearchLFID in (select DDResearchLFID from @ddresearch);
set @tmp_v = (SELECT * FROM @serviceresch FOR XML AUTO)
-- dd_DDAnamnesticData
declare @anamnes table (DDAnamnesticDataID int);	
insert into @anamnes
	(DDAnamnesticDataID)
	select DDAnamnesticDataID
	from dd_DDAnamnesticData 
	where rf_DDStateOfHealthIndexGUID in (select UGUID from @sohi);
set @tmp_v = (SELECT * FROM @anamnes FOR XML AUTO)
-- lbr_ResearchResult
declare @researchresult table (ResearchResultID int);	
insert into @researchresult
	(ResearchResultID)
	select ResearchResultID
	from lbr_ResearchResult
	where rf_ResearchGUID in (select GUID from @lbrresearch);
set @tmp_v = (SELECT * FROM @researchresult FOR XML AUTO)
-- ��������� ������
declare @rows table (HeadTable varchar(max), ID int);
insert into @rows (HeadTable, ID)
	select 'hlt_VisitHistory', VisitHistoryID
	from @visithistory
insert into @rows (HeadTable, ID)
	select 'hlt_ActionSchedule', ActionScheduleID
	from @actionschedule
insert into @rows (HeadTable, ID)
	select 'hlt_SMTAP', SMTAPID
	from @smtap
insert into @rows (HeadTable, ID)
	select 'hlt_DoctorVisitTable', DoctorVisitTableID
	from @doctorvisittable
insert into @rows (HeadTable, ID)
	select 'lbr_Research', ResearchID
	from @lbrresearch
insert into @rows (HeadTable, ID)
	select 'lbr_LaboratoryResearch', LaboratoryResearchID
	from @lbrLabResearch
insert into @rows (HeadTable, ID)
	select 'hlt_TAP', @tap
insert into @rows (HeadTable, ID)
	select 'dd_DDReestrErrors', DDReestrErrorsID
	from @r_err
insert into @rows (HeadTable, ID)
	select 'dd_DDExamMKB', DDExamMKBID 
	from @exammkb
insert into @rows (HeadTable, ID)
	select 'dd_DDExamService', DDExamServiceID 
	from @service
insert into @rows (HeadTable, ID)
	select 'dd_ResultValue', ResultValueID 
	from @res
insert into @rows (HeadTable, ID)
	select 'dd_DDExam', DDExamID 
	from @ddexam
insert into @rows (HeadTable, ID)
	select 'dd_DDResearchLFService', DDResearchLFServiceID 
	from @serviceresch
insert into @rows (HeadTable, ID)
	select 'dd_DDResearchLF', DDResearchLFID 
	from @ddresearch
insert into @rows (HeadTable, ID)
	select 'dd_DDErrors', DDErrorsID 
	from @err
insert into @rows (HeadTable, ID)
	select 'dd_DDFormMKB', DDFormMKBID 
	from @formmkb
insert into @rows (HeadTable, ID)
	select 'dd_DDAnamnesticData', DDAnamnesticDataID 
	from @anamnes
insert into @rows (HeadTable, ID)
	select 'dd_DDStateOfHealthIndex', DDStateOfHealthIndexID 
	from @sohi
insert into @rows (HeadTable, ID)
	select 'dd_HealthIndicators', HealthIndicatorsID 
	from @indicators
insert into @rows (HeadTable, ID)
	select 'dd_RiskFactors', RiskFactorsID 
	from @risk
insert into @rows (HeadTable, ID)
	select 'dd_DateOfDisp', DateOfDispID 
	from @datedisp
insert into @rows (HeadTable, ID)
	select 'dd_PersonOrg', PersonOrgID 
	from @personorg
insert into @rows (HeadTable, ID)
	select 'dd_DDForm', @ddformid
insert into @rows (HeadTable, ID)
	select 'lbr_ResearchResult', ResearchResultID
	from @researchresult
set @tmp_v = (SELECT * FROM @rows FOR XML AUTO)
Declare @sql nvarchar(max)
Declare @queryTable table (Query varchar(max));		
-- ������ �� ��������� ������, ��������� �������
insert into @queryTable
	(Query)
	select distinct 
		'update t1 set ' + ded.Name + ' = (select top 1 ' + ded.Name + 
		' from ' + dtd.HeadTable + ' where '  + dtd.PK_Name + ' = 0)' +
		' from ' + dtd.HeadTable + ' t1'+
		' join ' + dtd2.HeadTable + ' t2 on t1.' + ded.Name + ' = t2.' + case ded2.DocElemDefID when 0 then dtd2.PK_Name else ded2.Name end +
		' where t2.' + dtd2.PK_Name + ' = ' + convert(varchar, r.ID)
	from x_DocTypeDef dtd
	join x_DocElemDef ded on ded.DocTypeDefID = dtd.DocTypeDefID
	join x_DocTypeDef dtd2 on dtd2.DocTypeDefID = ded.LinkedDocTypeDefID
	join x_DocElemDef ded2 on ded2.DocElemDefID = ded.LinkedDocElemDefID
	join @rows r on r.HeadTable = dtd2.HeadTable
	where ded.ElemType = 2 AND r.ID <> 0
set @tmp_v = (SELECT * FROM @queryTable FOR XML AUTO)
-- ������ �� ��������
insert into @queryTable
	(Query)
	select distinct 
		'delete from ' + r.HeadTable +
		' where ' + dtd.PK_Name + ' = ' + convert(varchar, r.ID)
	from x_DocTypeDef dtd
	join @rows r on r.HeadTable = dtd.HeadTable
	where r.ID <> 0
set @tmp_v = (SELECT * FROM @queryTable FOR XML AUTO)
DECLARE
	cur CURSOR for (select Query from @queryTable)
	OPEN cur;
	FETCH NEXT FROM cur into @sql;
	while @@FETCH_STATUS = 0
	begin
		EXEC sp_executesql @sql;
		FETCH NEXT FROM cur into @sql;
	end
CLOSE cur;
DEALLOCATE cur;
set @result = 0;
return @result;
END
go

