CREATE VIEW [V_hlt_FluorResearch] AS SELECT 
[hDED].[FluorResearchID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_LPU].[M_NAMES] as [V_LPUName], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_LPUDoctor2ID] as [rf_LPUDoctor2ID], 
[hDED].[rf_FluorCardID] as [rf_FluorCardID], 
[jT_hlt_FluorCard].[NFluorCard] as [SILENT_rf_FluorCardID], 
[hDED].[rf_FluorTypePathologyID] as [rf_FluorTypePathologyID], 
[jT_hlt_FluorTypePathology].[Code] as [SILENT_rf_FluorTypePathologyID], 
[hDED].[rf_FluorTypePathology2ID] as [rf_FluorTypePathology2ID], 
[jT_hlt_FluorTypePathology1].[Code] as [SILENT_rf_FluorTypePathology2ID], 
[hDED].[Rf_FluorControlResearchID] as [Rf_FluorControlResearchID], 
[hDED].[Rf_FluorControlResearch2ID] as [Rf_FluorControlResearch2ID], 
[hDED].[rf_FluorLocalizationID] as [rf_FluorLocalizationID], 
[hDED].[rf_FluorLocalization2ID] as [rf_FluorLocalization2ID], 
[hDED].[rf_FluorTypeResearchID] as [rf_FluorTypeResearchID], 
[jT_hlt_FluorTypeResearch].[Code] as [SILENT_rf_FluorTypeResearchID], 
[hDED].[rf_FluorResearchResultID] as [rf_FluorResearchResultID], 
[jT_hlt_FluorResearchResult].[NAME] as [SILENT_rf_FluorResearchResultID], 
[hDED].[rf_FluorResearchReestrID] as [rf_FluorResearchReestrID], 
[jT_hlt_FluorResearchReestr].[Num] as [SILENT_rf_FluorResearchReestrID], 
[hDED].[rf_FluorResearchReestr2ID] as [rf_FluorResearchReestr2ID], 
[jT_hlt_FluorResearchReestr1].[Num] as [SILENT_rf_FluorResearchReestr2ID], 
[hDED].[DateFluorResearch] as [DateFluorResearch], 
[hDED].[NFluorResearch] as [NFluorResearch], 
[hDED].[Dose] as [Dose], 
[hDED].[DescriptionResearch] as [DescriptionResearch], 
[hDED].[DirectionNum] as [DirectionNum], 
[hDED].[ExternalResearch] as [ExternalResearch], 
[hDED].[LPUDoctor] as [LPUDoctor], 
[hDED].[LPUDoctor2] as [LPUDoctor2], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_FluorResearch] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [hlt_FluorCard] as [jT_hlt_FluorCard] on [jT_hlt_FluorCard].[FluorCardID] = [hDED].[rf_FluorCardID]
INNER JOIN [hlt_FluorTypePathology] as [jT_hlt_FluorTypePathology] on [jT_hlt_FluorTypePathology].[FluorTypePathologyID] = [hDED].[rf_FluorTypePathologyID]
INNER JOIN [hlt_FluorTypePathology] as [jT_hlt_FluorTypePathology1] on [jT_hlt_FluorTypePathology1].[FluorTypePathologyID] = [hDED].[rf_FluorTypePathology2ID]
INNER JOIN [hlt_FluorTypeResearch] as [jT_hlt_FluorTypeResearch] on [jT_hlt_FluorTypeResearch].[FluorTypeResearchID] = [hDED].[rf_FluorTypeResearchID]
INNER JOIN [hlt_FluorResearchResult] as [jT_hlt_FluorResearchResult] on [jT_hlt_FluorResearchResult].[FluorResearchResultID] = [hDED].[rf_FluorResearchResultID]
INNER JOIN [hlt_FluorResearchReestr] as [jT_hlt_FluorResearchReestr] on [jT_hlt_FluorResearchReestr].[FluorResearchReestrID] = [hDED].[rf_FluorResearchReestrID]
INNER JOIN [hlt_FluorResearchReestr] as [jT_hlt_FluorResearchReestr1] on [jT_hlt_FluorResearchReestr1].[FluorResearchReestrID] = [hDED].[rf_FluorResearchReestr2ID]
go

