CREATE view [V_ExpertPeriod6376c0e2-67b5-479f-bfda-669017376d9a] as select * from [tmp_ExpertPeriod6376c0e2-67b5-479f-bfda-669017376d9a]
go

