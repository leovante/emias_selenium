CREATE view [V_ExpertPeriod29690a94-a765-49c8-96e8-9dec26d4ddd9] as select * from [tmp_ExpertPeriod29690a94-a765-49c8-96e8-9dec26d4ddd9]
go

