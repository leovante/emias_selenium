CREATE view [V_ExpertPeriode8c8133f-1c26-4ace-bd57-e22d29d0566a] as select * from [tmp_ExpertPeriode8c8133f-1c26-4ace-bd57-e22d29d0566a]
go

