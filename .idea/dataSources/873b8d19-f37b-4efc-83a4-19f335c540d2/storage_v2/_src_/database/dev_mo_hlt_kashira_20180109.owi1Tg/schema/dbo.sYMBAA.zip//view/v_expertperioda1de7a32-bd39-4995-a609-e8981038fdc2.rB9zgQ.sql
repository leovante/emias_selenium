
CREATE view [V_ExpertPerioda1de7a32-bd39-4995-a609-e8981038fdc2] as select * from [tmp_ExpertPerioda1de7a32-bd39-4995-a609-e8981038fdc2]
go

