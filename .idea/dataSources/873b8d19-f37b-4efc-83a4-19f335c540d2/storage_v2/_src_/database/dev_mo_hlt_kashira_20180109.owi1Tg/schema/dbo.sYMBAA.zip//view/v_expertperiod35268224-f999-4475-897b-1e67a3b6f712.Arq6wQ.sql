CREATE view [V_ExpertPeriod35268224-f999-4475-897b-1e67a3b6f712] as select * from [tmp_ExpertPeriod35268224-f999-4475-897b-1e67a3b6f712]
go

