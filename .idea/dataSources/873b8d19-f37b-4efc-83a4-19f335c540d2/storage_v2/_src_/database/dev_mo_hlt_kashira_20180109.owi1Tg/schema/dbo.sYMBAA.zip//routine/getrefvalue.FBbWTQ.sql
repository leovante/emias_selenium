
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
create PROCEDURE [dbo].[GetRefValue]
	@txt varchar(250),
	@dtdid int,
	@id	varchar(50),
	@Result varchar(max) output	
	,@linkedDEDID int = 0
AS
BEGIN
	
	IF (Left(@txt, 1) != '#' or Right(@txt, 1) != '#' or len(@txt) <= 2) RETURN ''
	/* Результат */
	DECLARE @ResultVar varchar(max)
	
	/* Имя таблицы, ПК */
	DECLARE @tbName varchar(50), @fldName varchar(50)	
	SELECT @tbName  = [headTable], @fldName=PK_Name from x_docTypeDef where docTypeDefID = @dtdid
	if @linkedDEDID > 0 
	BEGIN
		SET @fldName = isnull(( SELECT name from x_docElemDef where docElemDefID = @linkedDEDID), '')
	END

	/* Позиция разделителя */
	DECLARE  @divInd int 
	SET @divInd = charindex('.', @txt)
	
	/* Выбираемый элемент */
	DECLARE @selElem varchar(250)
	DECLARE @dtFormat varchar(10)
	SET @dtFormat = ''

	IF (@divInd != 0) 
		BEGIN
			/* Просто поле */		
			SET @selElem = substring(@txt, 2, @divInd - 2)		
		END
	ELSE
		BEGIN		
			/* Ссылочное поле */
			SET @selElem =  replace(@txt, '#', '')
		END	
	
	
	/*Используем формат даты*/
	if (isnull((select top 1 ValueType from x_docElemDef WHERE DocTypeDefID = @dtdid AND FieldName = @selElem), 0) = 5)
		SET @dtFormat = ', 104'

	/* Команда выбора данных */
	DECLARE @cmd nvarchar(4000)	
	/*SET @cmd = 'select @res1=convert(varchar(max), ' + @selElem + @dtFormat + ')  from ' + @tbName + 
			   ' where cast(' +  @fldName + ' as varchar(10))  = ''' + @id + ''''*/

	SET @cmd = 'select @res1=convert(varchar(max), ' + @selElem + @dtFormat + ')  from ' + @tbName 
	IF (@tbName = 'hlt_TAP' and @fldName = 'TAPID')
	BEGIN
		SET @cmd =  @cmd + ' where ' +  @fldName + '  = ' + @id 
	END
	ELSE IF (@tbName = 'hlt_MKAB' and @fldName = 'MKABID')
	BEGIN
		SET @cmd =  @cmd + ' where ' +  @fldName + '  = ' + @id 
	END 
	ELSE
	BEGIN
		SET @cmd =  @cmd + ' where cast(' +  @fldName + ' as varchar(50))  = ''' + @id + ''''
		
	END
--print @cmd

	EXEC sp_executesql @cmd, N'@res1 varchar(255) out', @res1 = @ResultVar out 	
	--print @cmd
	/*Выбирали конечный элемент - выходим */
	IF (@divInd = 0) 
	BEGIN
		SET @Result = @ResultVar
		RETURN 0
	END

	/* Выбирали ссылочный документ. Определяем новый доктип */
	DECLARE @newDTDID int, @newDEDID int
	SELECT @newDTDID = linkedDocTypeDefID, @newDEDID = LinkedDocElemDefID FROM x_docElemDef 
		WHERE DocTypeDefID = @dtdid AND FieldName = @selElem

	/* Новый запрос */
	SET @selElem = '#' +  right(@txt, len(@txt) - @divInd )	

	DECLARE	@return_value int
	DECLARE	@refResult varchar(max)

	EXEC	@return_value = [dbo].[GetRefValue]
			@txt = @selElem,
			@dtdid = @newDTDID,
			@id = @ResultVar,
			@Result = @refResult OUTPUT
			,@linkedDEDID = @newDEDID
	
	SET @Result = @refResult
	RETURN @return_value
END


go

