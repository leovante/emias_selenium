CREATE view [V_ExpertPeriod457e1bef-ea7d-41c3-9556-76b0ad411440] as select * from [tmp_ExpertPeriod457e1bef-ea7d-41c3-9556-76b0ad411440]
go

