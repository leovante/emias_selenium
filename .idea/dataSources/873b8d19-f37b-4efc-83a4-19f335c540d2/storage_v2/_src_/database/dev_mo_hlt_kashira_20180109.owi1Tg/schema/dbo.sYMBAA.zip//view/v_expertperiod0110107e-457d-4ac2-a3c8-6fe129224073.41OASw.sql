CREATE view [V_ExpertPeriod0110107e-457d-4ac2-a3c8-6fe129224073] as select * from [tmp_ExpertPeriod0110107e-457d-4ac2-a3c8-6fe129224073]
go

