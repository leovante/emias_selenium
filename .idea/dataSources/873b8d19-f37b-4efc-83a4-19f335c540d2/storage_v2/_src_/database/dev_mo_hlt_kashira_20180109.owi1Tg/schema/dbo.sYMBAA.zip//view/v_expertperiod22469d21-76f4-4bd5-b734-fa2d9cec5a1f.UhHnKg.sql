CREATE view [V_ExpertPeriod22469d21-76f4-4bd5-b734-fa2d9cec5a1f] as select * from [tmp_ExpertPeriod22469d21-76f4-4bd5-b734-fa2d9cec5a1f]
go

