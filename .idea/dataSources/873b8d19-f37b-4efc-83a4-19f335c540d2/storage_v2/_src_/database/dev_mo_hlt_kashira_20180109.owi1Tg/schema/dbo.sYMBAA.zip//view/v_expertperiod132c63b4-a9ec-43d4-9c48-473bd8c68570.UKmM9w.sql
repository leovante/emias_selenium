CREATE view [V_ExpertPeriod132c63b4-a9ec-43d4-9c48-473bd8c68570] as select * from [tmp_ExpertPeriod132c63b4-a9ec-43d4-9c48-473bd8c68570]
go

