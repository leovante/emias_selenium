CREATE VIEW [V_dd_PatientCategory] AS SELECT 
[hDED].[PatientCategoryID], [hDED].[x_Edition], [hDED].[x_Status], 
(SELECT CASE Sex 
WHEN 0 THEN 'Женский'
WHEN 1 THEN 'Мужской'
WHEN 2 THEN 'Для обоих полов' END) as [V_Sex], 
[jT_dd_DDType].[Name] as [V_DDTypeName], 
[hDED].[rf_kl_SocStatusID] as [rf_kl_SocStatusID], 
[hDED].[rf_DDTypeUGUID] as [rf_DDTypeUGUID], 
[hDED].[AgeMinBoundary] as [AgeMinBoundary], 
[hDED].[AgeMaxBoundary] as [AgeMaxBoundary], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[CategoryName] as [CategoryName], 
[hDED].[Sex] as [Sex], 
[hDED].[SQLCase] as [SQLCase]
FROM [dd_PatientCategory] as [hDED]
INNER JOIN [dd_DDType] as [jT_dd_DDType] on [jT_dd_DDType].[UGUID] = [hDED].[rf_DDTypeUGUID]
go

