CREATE view [V_ExpertPeriod110a1cc3-5428-4714-a032-e57cc9c49f7b] as select * from [tmp_ExpertPeriod110a1cc3-5428-4714-a032-e57cc9c49f7b]
go

