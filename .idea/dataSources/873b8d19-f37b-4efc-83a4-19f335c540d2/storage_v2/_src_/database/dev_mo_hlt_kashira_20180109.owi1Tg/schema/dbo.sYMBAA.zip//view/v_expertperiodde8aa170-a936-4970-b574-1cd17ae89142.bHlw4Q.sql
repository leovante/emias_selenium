CREATE view [V_ExpertPeriodde8aa170-a936-4970-b574-1cd17ae89142] as select * from [tmp_ExpertPeriodde8aa170-a936-4970-b574-1cd17ae89142]
go

