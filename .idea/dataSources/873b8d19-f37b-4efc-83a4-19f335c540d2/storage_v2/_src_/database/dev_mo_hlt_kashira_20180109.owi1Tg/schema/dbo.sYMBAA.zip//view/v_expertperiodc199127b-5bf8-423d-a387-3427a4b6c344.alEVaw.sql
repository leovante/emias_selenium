CREATE view [V_ExpertPeriodc199127b-5bf8-423d-a387-3427a4b6c344] as select * from [tmp_ExpertPeriodc199127b-5bf8-423d-a387-3427a4b6c344]
go

