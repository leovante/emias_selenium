CREATE view [V_ExpertPerioda3434575-cc94-4c2e-a7cb-d1fba87961be] as select * from [tmp_ExpertPerioda3434575-cc94-4c2e-a7cb-d1fba87961be]
go

