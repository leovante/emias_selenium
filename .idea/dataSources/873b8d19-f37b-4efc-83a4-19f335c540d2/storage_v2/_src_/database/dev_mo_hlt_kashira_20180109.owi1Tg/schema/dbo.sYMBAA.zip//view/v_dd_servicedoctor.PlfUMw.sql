CREATE VIEW [V_dd_ServiceDoctor] AS SELECT 
[hDED].[ServiceDoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_V_DocInfo], 
[jT_hlt_DocPRVD].[Name] as [V_DocPrvdName], 
[jT_dd_DDService].[DDServiceName] as [V_DDServiceName], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPrvdGUID] as [rf_DocPrvdGUID], 
[hDED].[rf_DDServiceID] as [rf_DDServiceID], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [dd_ServiceDoctor] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[GUID] = [hDED].[rf_DocPrvdGUID]
INNER JOIN [dd_DDService] as [jT_dd_DDService] on [jT_dd_DDService].[DDServiceID] = [hDED].[rf_DDServiceID]
go

