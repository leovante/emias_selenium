
CREATE PROCEDURE [SQLStress].[SP] 
@Client nvarchar(64),	-- Client Nodename
@Server nvarchar(64),	-- Server Nodename
@User int,				-- Usernumber
@Data int,				-- Random Usernumber
@Id uniqueidentifier	-- Id
AS
BEGIN
    INSERT
    INTO SQLStress.Data( Client, Server, UserThread, Data, Id )
    VALUES( @Client, @Server, @User, @Data, @Id )
END
go

