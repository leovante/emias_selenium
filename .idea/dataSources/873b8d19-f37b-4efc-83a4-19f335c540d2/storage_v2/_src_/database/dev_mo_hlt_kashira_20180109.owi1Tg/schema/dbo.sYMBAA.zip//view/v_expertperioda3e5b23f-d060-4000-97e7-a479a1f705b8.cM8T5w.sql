CREATE view [V_ExpertPerioda3e5b23f-d060-4000-97e7-a479a1f705b8] as select * from [tmp_ExpertPerioda3e5b23f-d060-4000-97e7-a479a1f705b8]
go

