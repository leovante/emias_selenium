CREATE view [V_ExpertPeriodbfe62d9b-99a5-4213-b983-dd8ce9d31148] as select * from [tmp_ExpertPeriodbfe62d9b-99a5-4213-b983-dd8ce9d31148]
go

