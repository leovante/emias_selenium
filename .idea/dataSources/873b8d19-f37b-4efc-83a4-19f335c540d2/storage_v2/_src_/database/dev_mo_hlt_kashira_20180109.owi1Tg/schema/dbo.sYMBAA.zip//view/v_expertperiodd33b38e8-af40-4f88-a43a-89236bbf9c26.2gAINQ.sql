CREATE view [V_ExpertPeriodd33b38e8-af40-4f88-a43a-89236bbf9c26] as select * from [tmp_ExpertPeriodd33b38e8-af40-4f88-a43a-89236bbf9c26]
go

