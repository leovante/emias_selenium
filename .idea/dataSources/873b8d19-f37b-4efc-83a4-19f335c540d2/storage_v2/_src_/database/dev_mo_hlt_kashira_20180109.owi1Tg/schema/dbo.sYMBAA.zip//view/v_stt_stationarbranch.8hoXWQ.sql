CREATE VIEW [V_stt_StationarBranch] AS SELECT 
[hDED].[StationarBranchID], [hDED].[x_Edition], [hDED].[x_Status], 
(isnull(
(select count(1) from stt_Ward w 
	join stt_Bed b on b.rf_WardID = w.WardID
	join stt_BedAction ba on ba.rf_BedID =b.BedID
	join 
		(
			select rf_BedID, max(date) date from stt_BedAction
			group by rf_BedID
		) lba on lba.rf_BedID =ba.rf_bedID and lba.Date = ba.date
	join stt_ActionType at on at.ActionTypeID = ba.rf_ActionTypeId
	where at.Code in(2,5,7) and rf_StationarBranchID = hDED.StationarBranchID
) ,0)) as [V_FreeBedCount], 
(isnull(
(select count(1) from stt_Ward w 
	join stt_Bed b on b.rf_WardID = w.WardID
	join stt_BedAction ba on ba.rf_BedID =b.BedID
	join 
		(
			select rf_BedID, max(date) date from stt_BedAction
			group by rf_BedID
		) lba on lba.rf_BedID =ba.rf_bedID and lba.Date = ba.date
	join stt_ActionType at on at.ActionTypeID = ba.rf_ActionTypeId
	where at.Code in(1,2,5,7) and rf_StationarBranchID = hDED.StationarBranchID
) ,0)) as [V_CurrentBedCount], 
('['+[jT_oms_Department].[DepartmentCODE]+'] ' +[jT_oms_Department].[DepartmentNAME]) as [V_BranchInfo], 
((isnull((select sum(BedCount) from stt_Ward where rf_StationarBranchID = hDED.StationarBranchID),0) )) as [V_PlannedBedCount], 
[jT_oms_Department].[DepartmentNAME] as [V_Name], 
[jT_oms_Department].[DepartmentCODE] as [V_Code], 
[jT_stt_StationarType].[Name] as [NameStationarType], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[hDED].[rf_StationarTypeID] as [rf_StationarTypeID], 
[jT_stt_StationarType].[Name] as [SILENT_rf_StationarTypeID], 
[hDED].[rf_TransportHostID] as [rf_TransportHostID], 
[hDED].[rf_BedProfileID] as [rf_BedProfileID], 
[hDED].[Flag] as [Flag], 
[hDED].[ConnectionString] as [ConnectionString], 
[hDED].[Password] as [Password], 
[hDED].[Login] as [Login]
FROM [stt_StationarBranch] as [hDED]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [stt_StationarType] as [jT_stt_StationarType] on [jT_stt_StationarType].[StationarTypeID] = [hDED].[rf_StationarTypeID]
go

