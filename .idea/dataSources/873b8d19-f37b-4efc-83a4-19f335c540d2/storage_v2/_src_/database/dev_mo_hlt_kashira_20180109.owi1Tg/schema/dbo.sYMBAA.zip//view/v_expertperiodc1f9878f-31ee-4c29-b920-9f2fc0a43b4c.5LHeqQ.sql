CREATE view [V_ExpertPeriodc1f9878f-31ee-4c29-b920-9f2fc0a43b4c] as select * from [tmp_ExpertPeriodc1f9878f-31ee-4c29-b920-9f2fc0a43b4c]
go

