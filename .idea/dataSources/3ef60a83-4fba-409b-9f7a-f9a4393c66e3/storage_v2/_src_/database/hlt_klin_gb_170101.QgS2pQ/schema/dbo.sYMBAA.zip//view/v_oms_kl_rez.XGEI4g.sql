CREATE VIEW [V_oms_kl_REZ] AS SELECT 
[hDED].[kl_REZID], [hDED].[x_Edition], [hDED].[x_Status], 
(((Code))) as [V_kl_REZ], 
[hDED].[Kod] as [Kod], 
[hDED].[Opis] as [Opis], 
[hDED].[Code] as [Code], 
[hDED].[date_b] as [date_b], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_REZ] as [hDED]
go

