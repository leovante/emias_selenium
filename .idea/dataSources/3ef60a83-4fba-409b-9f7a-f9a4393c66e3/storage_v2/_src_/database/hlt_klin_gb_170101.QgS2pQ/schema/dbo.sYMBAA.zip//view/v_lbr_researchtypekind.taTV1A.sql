CREATE VIEW [V_lbr_ResearchTypeKind] AS SELECT 
[hDED].[ResearchTypeKindID], [hDED].[x_Edition], [hDED].[x_Status], 
(UGUID) as [V_ResearchTypeKindGUID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Description] as [Description], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [lbr_ResearchTypeKind] as [hDED]
go

