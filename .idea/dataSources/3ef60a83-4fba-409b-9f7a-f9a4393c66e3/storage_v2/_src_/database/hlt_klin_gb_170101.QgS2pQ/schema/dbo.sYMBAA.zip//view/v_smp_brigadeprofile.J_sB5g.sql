CREATE VIEW [V_smp_BrigadeProfile] AS SELECT 
[hDED].[BrigadeProfileID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID]
FROM [smp_BrigadeProfile] as [hDED]
go

