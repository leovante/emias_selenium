CREATE FUNCTION [dbo].[RPGU2_DoctorList]()
RETURNS TABLE 
AS
RETURN 
(
	select 
		docprvd.docprvdid ID,
		case when doc.SS = '000-000-000 00' then '' else doc.SS end as SS,
		doc.Fam_V,
		doc.Im_V,
		doc.Ot_V,
		doc.PCOD,
		prvs.PRVSID,
		prvs.C_PRVS,
		prvs.PRVS_NAME,
		prvd.C_PRVD,
		prvd.NAME as PRVD_NAME,
		dep.DepartmentNAME,
		lpu.mcod
	from hlt_docprvd docprvd WITH (NOLOCK) 
		inner join hlt_lpudoctor doc  WITH (NOLOCK) on doc.lpudoctorid = docprvd.rf_lpudoctorid
		inner join oms_department dep  WITH (NOLOCK) on dep.departmentid = docprvd.rf_Departmentid
		inner join oms_lpu lpu  WITH (NOLOCK) on lpu.lpuid = dep.rf_LPUID
		inner join oms_prvs prvs  WITH (NOLOCK) on prvs.prvsid = docprvd.rf_prvsid
		inner join oms_prvd prvd  WITH (NOLOCK) on prvd.prvdid = docprvd.rf_prvdid
	where rf_ResourceTypeID = isnull((select ResourceTypeID from hlt_ResourceType  WITH (NOLOCK) where CODE = '1'), '1')
		and docprvdid in 
		(
			select distinct rf_docprvdid
			from hlt_doctortimetable WITH (NOLOCK) 
			where date >= getdate()
			and rf_docprvdid > 0
		)
		and prvs.PRVSID > 0
)
go

