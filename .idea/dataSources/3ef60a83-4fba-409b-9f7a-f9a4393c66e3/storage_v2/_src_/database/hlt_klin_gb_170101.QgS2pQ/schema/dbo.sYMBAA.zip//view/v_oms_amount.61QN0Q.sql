CREATE VIEW [V_oms_Amount] AS SELECT 
[hDED].[AmountID], [hDED].[x_Edition], [hDED].[x_Status], 
((Code)) as [V_AmountCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Desc] as [Desc]
FROM [oms_Amount] as [hDED]
go

