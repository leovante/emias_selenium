
/****** Object:  UserDefinedFunction [dbo].[stt_CalcHospLen]    Script Date: 02/18/2014 17:09:16 ******/
-- =============================================
-- Author:              Кульбабов Валилий Леонидович
-- Create date: 10.12.2013
-- Description: Функция производи подсчет количества дней пребывания в зависимости от типа отделния(реагирует на тип отделения)
-- =============================================
CREATE FUNCTION [dbo].[stt_CalcHospLen]
(
        @beginHosp datetime, @endHosp datetime, @StationarBranchId int
)
RETURNS int
AS
BEGIN   
        declare @HospLen int,@funkLenName varchar(100)  
        declare @StartHospitalTime datetime
        select top 1 @StartHospitalTime = CONVERT(time,valueStr)  from x_UserSettings where Property = 'StartHospitalDay' and OwnerGUID = '4DF516BE-7A1D-416C-BD93-1CBB2159B26D'
        
        select @funkLenName=cm.[Function] from stt_StationarBranch sb 
        join stt_StationarType st on sb.rf_StationarTypeID = st.StationarTypeID
        join stt_CalculateMethod cm on st.rf_CalculateMethodID = cm.CalculateMethodID
        where sb.StationarBranchID = @StationarBranchId

        exec @HospLen= @funkLenName @beginHosp, @endHosp, @StartHospitalTime
        RETURN @HospLen
END
go

