CREATE VIEW [V_dd_DDReestrErrors] AS SELECT 
[hDED].[DDReestrErrorsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDFormID] as [rf_DDFormID], 
[hDED].[rf_DDErrorCodeGUID] as [rf_DDErrorCodeGUID], 
[hDED].[rf_DDReestrID] as [rf_DDReestrID], 
[hDED].[rf_DDChildFormID] as [rf_DDChildFormID], 
[jT_dd_DDChildForm].[v_FIO] as [SILENT_rf_DDChildFormID], 
[hDED].[Comment] as [Comment], 
[hDED].[isOper] as [isOper], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDReestrErrors] as [hDED]
INNER JOIN [V_dd_DDChildForm] as [jT_dd_DDChildForm] on [jT_dd_DDChildForm].[DDChildFormID] = [hDED].[rf_DDChildFormID]
go

