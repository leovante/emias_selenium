CREATE VIEW [V_oms_kl_Complication] AS SELECT 
[hDED].[kl_ComplicationID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_ComplicationCode], 
[hDED].[rf_kl_ComplicationTreeID] as [rf_kl_ComplicationTreeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_Complication] as [hDED]
go

