CREATE VIEW [V_stt_QuotaType] AS SELECT 
[hDED].[QuotaTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description]
FROM [stt_QuotaType] as [hDED]
go

