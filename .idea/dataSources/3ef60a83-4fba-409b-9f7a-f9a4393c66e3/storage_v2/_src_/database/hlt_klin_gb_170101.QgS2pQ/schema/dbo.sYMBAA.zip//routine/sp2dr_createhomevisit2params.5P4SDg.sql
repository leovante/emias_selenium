CREATE PROCEDURE [dbo].[sp2dr_CreateHomeVisit2Params] (
	 @mkabid INT
	,@mcod VARCHAR(20)
	,@date DATETIME
	,@address VARCHAR(200)
	,@complaint VARCHAR(100)
	,@phone VARCHAR(25)
	,@porch INT
	,@floor INT
	,@intercome VARCHAR(20)
	,@source int
	,@result INT OUTPUT
	)
AS
BEGIN
	SET NOCOUNT ON;

	-- Игнорируем переданную дату!
	SET @date = CAST(GETDATE() AS DATE)

	-- Признак типа расписания для вызова врача на дом
	DECLARE @DBTType INT = 8
	DECLARE @DVT_CallHomeFlag INT = 0x0080
	DECLARE @CallDocDTDID INT = isnull((
				SELECT DocTypeDefID
				FROM x_DocTypeDef
				WHERE GUID = '743F4CC3-29A1-4F24-882B-33CC9D0ED8FE'
				), 0)
	-- Коды ошибок
	-- Перечень проверок:
	-- Нет ИЭМК								= -3
	-- В ЭМК не указан участок				= -201
	-- На участке нет врача					= -202
	-- Нет расписания у участкового врача	= -203
	-- Расписание участкового врача занято	= -204
	-- Уже есть офрмленный вызов			= -7

	DECLARE @EOK INT = 0
	DECLARE @EMKABNotFound INT = - 3
	DECLARE @EUnknownError INT = - 11
	DECLARE @EMkabWithoutUchastok INT = - 201
	DECLARE @EUchastokWithoutDoctor INT = - 202
	DECLARE @ESchedulNotExists INT = - 203
	DECLARE @ESchedulBusy INT = - 204
	DECLARE @EExistsVisitDayDoc INT = - 7



	declare @CallDocGuid uniqueidentifier
	set @CallDocGuid = newid()

	SET @result = @EUnknownError

	SET @phone = replace(replace(replace(replace(@phone, ' ', ''), '-', ''), '(', ''), ')', '')

	-- Нет ИЭМК								= -3
	IF NOT EXISTS (
			SELECT 1
			FROM hlt_mkab WITH (NOLOCK)
			WHERE mkabid = @mkabid
				AND isclosed = 0
			)
	BEGIN
		SET @result = @EMKABNotFound

		RETURN
	END

	-- В ЭМК не указан участок				= -201
	DECLARE @uchastokid INT = 0

	SET @uchastokid = (
			SELECT isnull((
						SELECT TOP 1 rf_uchastokid
						FROM hlt_mkab WITH (NOLOCK)
						WHERE mkabid = @mkabid
						), 0)
			)

	IF @uchastokid <= 0
	BEGIN
		SET @result = @EMkabWithoutUchastok

		--RETURN
	END


	-- На участке нет врача					= -202
	DECLARE @docid INT = 0

	SET @docid = (
			SELECT TOP 1 rf_DocPRVDID
			FROM hlt_Uchastok WITH (NOLOCK)
			WHERE hlt_Uchastok.Uchastokid = @uchastokid
			)

	IF @docid <= 0 and @uchastokid>0
	BEGIN
		SET @result = @EUchastokWithoutDoctor

		--RETURN
	END

	-- Если врач относится к другому ЛПУ - таких не считаем
	IF NOT EXISTS (
			SELECT 1
			FROM oms_lpu lpu WITH (NOLOCK)
			INNER JOIN oms_department department WITH (NOLOCK) ON lpu.lpuid = department.rf_LPUID
			INNER JOIN hlt_Docprvd prvd WITH (NOLOCK) ON prvd.rf_DepartmentID = department.DepartmentID
			WHERE prvd.DocPRVDID = @docid
				AND lpu.mcod = @mcod
			) and @docid>0
	BEGIN
		SET @result = @EUchastokWithoutDoctor

		--RETURN
	END

	-- Уже есть офрмленный вызов			= -7
	IF EXISTS (
			SELECT 1
			FROM [hlt_CallDoctor] cd WITH (NOLOCK)
			INNER JOIN hlt_CallDoctorStatus cds WITH (NOLOCK) ON cd.rf_CallDoctorStatusID = cds.CallDoctorStatusID
			WHERE rf_mkabid = @MKABID
				AND ( cds.Code = '1' or cds.Code = '0')
				AND CAST(cd.DateCall  AS DATE) >= CAST(GETDATE() AS DATE)
			)
	BEGIN
		SET @result = @EExistsVisitDayDoc

		RETURN
	END

	DECLARE @dttid INT = 0

	SET @dttid = isnull((
				SELECT TOP 1 DoctorTimeTableID
				FROM hlt_DoctorTimeTable dtt WITH (NOLOCK)
				WHERE rf_DocPRVDID = @docid
					AND DATE = @date
					AND ((@date > getdate()) OR (dtt.Begin_Time > getdate()))		-- -- вернул Begin_Time Коржов С.А. 17-10-2017
					AND rf_DocBusyType IN (
						SELECT DocBusyTypeID
						FROM hlt_DocBusyType WITH (NOLOCK)
						WHERE TypeBusy & @DBTType != 0
						)
					AND PlanUE > UsedUE
					AND dtt.Begin_Time <> '1900-01-01T00:00:00' AND datepart(hour, dtt.Begin_Time) > 0
					-- Отсекаем по провам доступа
					AND dtt.FlagAccess & 4 > 0
				ORDER BY dtt.Begin_Time
				), 0)

	DECLARE @BegTime DATETIME = ISNULL((SELECT TOP 1 Begin_Time FROM hlt_DoctorTimeTable WHERE DoctorTimeTableID = @dttid), '1900-01-01T00:00:00')
	if @BegTime < getdate()
	BEGIN
		SET @BegTime = getdate()
	END
	-- Расписание участкового врача занято	= -204
	IF @dttid > 0
			BEGIN
				--SET @result = @ESchedulBusy

				--RETURN
			--END*/

			BEGIN TRAN

			-- Создаем ЗНП
			/*INSERT INTO hlt_DoctorVisitTable (
				x_edition
				,x_status
				,rf_DoctorTimeTableID
				,rf_MKABID
				,Comment
				,Flags
				,fromTEL
				,fromInternet
				,UGUID
				,NormaUE
				)
			SELECT 1
				,1
				,@dttid
				,@mkabid
				,hlt_MKAB.FAMILY + ' ' + hlt_MKAB.NAME + ' ' + hlt_MKAB.OT + ', ' + cast(datepart(yy, hlt_MKAB.DATE_BD) AS VARCHAR(4)) + ' г.р.'
				,@DVT_CallHomeFlag
				,case when @source = 3 then 1 else 0 end as fromTel-- КЦ
				,case when @source = 1 then 1 else 0 end as fromInternet -- РПГУ
				,newid()
				,1
			FROM hlt_MKAB
			WHERE MKABID = @mkabid
				AND (
					SELECT PlanUE - UsedUE
					FROM hlt_DoctorTimeTable
					WHERE DoctorTimeTableID = @dttid
					) > 0

			DECLARE @dvtid INT = SCOPE_IDENTITY()
*/
			-- Создаем ВВНД
			INSERT INTO [dbo].[hlt_CallDoctor] (
				[x_Edition]
				,[x_Status]
				,[GUID]
				,[rf_LPUDoctorID]
				,[rf_MKABID]
				,[Family]
				,[Name]
				,[Ot]
				,[SeriesPol]
				,[NumberPol]
				,[BirthDate]
				,[isChild]
				,[rf_CallPersonTypeID]
				,[Address]
				,[Complaint]
				,[DateCall]
				,[DateVisit]
				,[rf_CallDoctorStatusID]
				,[isFinalize]
				,[DateFinalize]
				,[rf_TAPID]
				,[CodeDomophon]
				,[Phone]
				,[Rf_FinalizeLPUDoctorID]
				,[Description]
				,[rf_TypeCallDoctorID]
				,[Entrance]
				,[Floor]
				,[rf_AddressID]
				,[rf_DocPRVDID]
				,[rf_FinalizeDocPRVDID]
				,[rf_LPUID]
				,[SourceDvt]
				,[DateStatus]
				,[Age]
				,AgeTitle
				)
			SELECT 1 [x_Edition]
				,1 [x_Status]
				, @CallDocGuid
				,isnull((
						SELECT TOP 1 rf_LPUDoctorID
						FROM hlt_DocPRVD WITH (NOLOCK)
						WHERE DocPRVDID = @docid
						), 0) [rf_LPUDoctorID]
				,@mkabid [rf_MKABID],
				Family [Family]	,
				Name [Name]	,
				Ot [Ot],
				isnull((select top 1 S_POL from hlt_PolisMKAB where rf_MKABID = MKABID and isActive = 1), '') [SeriesPol],
				isnull((select top 1 S_POL from hlt_PolisMKAB where rf_MKABID = MKABID and isActive = 1), '')  [NumberPol],
				date_BD [BirthDate],
				IIF ( DATEDIFF(year, date_BD, getdate()) >= 18 , 0, 1 ) as [isChild],
				isnull((select top 1 CallPersonTypeID
						from [hlt_CallPersonType] where
						guid = 'E010B8A6-F629-4040-95E3-B4DB7B162B48'), 0) [rf_CallPersonTypeID]
				,cast(@ADDRESS as varchar(200)) [Address]
				,cast(case @source
						when 3 then '[КЦ] ' -- КЦ
						when 1 then '[ИНТЕРНЕТ] ' --
						else ''
					  end + @Complaint as varchar(100))[Complaint]
				,getdate() [DateCall]
				,@BegTime [DateVisit]
				,(
					SELECT isnull((
								SELECT TOP 1 CallDoctorStatusID
								FROM hlt_CallDoctorStatus WITH (NOLOCK)
								WHERE CODE = '1'
								), 0)
					) [rf_CallDoctorStatusID]
				,0 [isFinalize]
				,'2222-01-01T00:00:00' [DateFinalize]
				,0 [rf_TAPID]
				,cast(@intercome as varchar(20)) [CodeDomophon]
				,cast(@Phone as varchar(25)) [Phone]
				,0 [Rf_FinalizeLPUDoctorID]
				,'' [Description]
				,(
					SELECT isnull((
								SELECT TOP 1 TypeCallDoctorID
								FROM hlt_TypeCallDoctor WITH (NOLOCK)
								WHERE CODE = '1'
								), 0)
					) [rf_TypeCallDoctorID]
				,@porch [Entrance]
				,@floor [Floor]
				,0 [rf_AddressID]
				,@docid [rf_DocPRVDID]
				,0 [rf_FinalizeDocPRVDID]
				,(select top 1 LPUID from oms_LPU where MCOD = @mcod) [rf_LPUID]
				,@source [SourceDvt] -- 3 КЦ
				,getdate() [DateStatus] -- дата/время установки статуса
								-- возраст
				,IIF(date_BD > CONVERT(datetime, '1900/01/01 00:00:00.000', 120),
  			  IIF(DATEDIFF(YEAR, date_BD, getdate()) > 0
  			      ,DATEDIFF(YEAR, date_BD, getdate())
  			      ,IIF(DATEDIFF(MONTH, date_BD, getdate()) > 0
  			        ,DATEDIFF(MONTH, date_BD, getdate())
  			        ,IIF(DATEDIFF(DAY, date_BD, getdate()) >= 0
  			          ,DATEDIFF(DAY, date_BD, getdate())
  			          ,0
  			          )
  			      )
  			  ),
  			0) AS [Age]
				-- тип возраста (лет/мес./д.)
				,IIF(date_BD > CONVERT(datetime, '1900/01/01 00:00:00.000', 120),
  				IIF(DATEDIFF(YEAR, date_BD, getdate()) > 0
  				    ,3
  				    , IIF(DATEDIFF(MONTH, date_BD, getdate()) > 0
  				      ,2
  				      ,IIF(DATEDIFF(DAY, date_BD, getdate()) >= 0
  				        ,1
  				        , 0
  				        )
  				    )
  				)
  			,0) as [AgeTitle]
				from hlt_MKAB where MKABID = @mkabid

			DECLARE @callid INT = SCOPE_IDENTITY()

			-- В каком то случае вставка на проходила. Скорее всего, была проблема во входных данных.
			-- В этом случае SCOPE_IDENTITY возвращал идентификатор равный @dvtid
			-- На всякий случай проверим, добавлена ли запись. Если нет - сообщим об ошибке!
			IF ISNULL((SELECT TOP 1 rf_mkabid FROM [hlt_CallDoctor] WHERE CallDoctorID = @callid and [DateVisit] = @BegTime), 0) != @mkabid
			BEGIN
			   ROLLBACK TRAN
			   RETURN
			END

			--Связываем их
			/*INSERT INTO [dbo].[hlt_ActionSchedule] (
				[DocTypeDefID]
				,[Flags]
				,[GUID]
				,[rf_DoctorVisitTableID]
				,[rf_DocTypeID]
				,[x_Edition]
				,[x_Status]
				)
			VALUES (
				@CallDocDTDID
				,0
				,newid()
				,@dvtid
				,@callid
				,1
				,1
				)*/

			UPDATE hlt_mkab
			SET contactmphone = @phone
			WHERE mkabid = @mkabid and contactmphone != @phone


			-- запись в историю
				INSERT INTO [dbo].[oms_DocumentHistory]
						   (
							[Editor]
						   ,[NewValue]
						   ,[OldValue]
						   ,[rf_ClientApplicationGuid]
						   ,[rf_DocElemDefGuid]
						   ,[rf_DocTypeDefGuid]
						   ,[rf_DocumentGuid]
						   ,[x_Edition]
						   ,[x_Status])
					 VALUES
						   (''
						   ,''
						   ,''
						   ,
							case @source
								when 3 then 'CB174067-702F-42D0-B0EB-1D84A514515D' -- КЦ
								when 1 then '9C9902BD-AB4C-469C-AB8F-84E41925F95A' --
								else '00000000-0000-0000-0000-000000000000'
							end --[rf_ClientApplicationGuid]
						   ,'00000000-0000-0000-0000-000000000000'
						   ,'743F4CC3-29A1-4F24-882B-33CC9D0ED8FE'
						   , @CallDocGuid
						   ,1
						   ,1)


			COMMIT TRAN

			SET @result = @EOK
			END
	ELSE
			BEGIN

			-- Создаем ВВНД
			INSERT INTO [dbo].[hlt_CallDoctor] (
				[x_Edition]
				,[x_Status]
				,[GUID]
				,[rf_LPUDoctorID]
				,[rf_MKABID]
				,[Family]
				,[Name]
				,[Ot]
				,[SeriesPol]
				,[NumberPol]
				,[BirthDate]
				,[isChild]
				,[rf_CallPersonTypeID]
				,[Address]
				,[Complaint]
				,[DateCall]
				,[DateVisit]
				,[rf_CallDoctorStatusID]
				,[isFinalize]
				,[DateFinalize]
				,[rf_TAPID]
				,[CodeDomophon]
				,[Phone]
				,[Rf_FinalizeLPUDoctorID]
				,[Description]
				,[rf_TypeCallDoctorID]
				,[Entrance]
				,[Floor]
				,[rf_AddressID]
				,[rf_DocPRVDID]
				,[rf_FinalizeDocPRVDID]
				,[rf_LPUID]
				,[SourceDvt]
				,[DateStatus]
				,[Age]
				,[AgeTitle]
				)
			SELECT 1 [x_Edition]
				,1 [x_Status]
				, @CallDocGuid
				,CASE WHEN @dttid <= 0 THEN 0
				ELSE
				isnull((
						SELECT TOP 1 rf_LPUDoctorID
						FROM hlt_DocPRVD WITH (NOLOCK)
						WHERE DocPRVDID = @docid
						), 0)
				END	as [rf_LPUDoctorID]  -- привязка к врачу только если расписание кончилось.
				, @mkabid [rf_MKABID]
				, Family [Family]
				, Name [Name]
				, Ot [Ot]
				, isnull((select top 1 S_POL from hlt_PolisMKAB where rf_MKABID = MKABID and isActive = 1), '') [SeriesPol]
				, isnull((select top 1 S_POL from hlt_PolisMKAB where rf_MKABID = MKABID and isActive = 1), '')  [NumberPol]
				, date_BD [BirthDate]
				, IIF ( DATEDIFF(year, date_BD, getdate()) >= 18 , 0, 1 ) as [isChild]
				, isnull((select top 1 CallPersonTypeID
						from [hlt_CallPersonType] where
						guid = 'E010B8A6-F629-4040-95E3-B4DB7B162B48'), 0) [rf_CallPersonTypeID]
				,cast(@ADDRESS as varchar(200)) [Address]
				,cast(case @source
						when 3 then '[КЦ] ' -- КЦ
						when 1 then '[ИНТЕРНЕТ] ' --
						else ''
					  end + @Complaint as varchar(100))[Complaint]
				,getdate() [DateCall]
				,@BegTime [DateVisit]
				,(
					SELECT isnull((
								SELECT TOP 1 CallDoctorStatusID
								FROM hlt_CallDoctorStatus WITH (NOLOCK)
								WHERE CODE = '0' -- если не пишем в расписание то вызов врача /предварительный/
								), 0)
					) [rf_CallDoctorStatusID]
				,0 [isFinalize]
				,'2222-01-01T00:00:00' [DateFinalize]
				,0 [rf_TAPID]
				,cast(@intercome as varchar(20)) [CodeDomophon]
				,cast(@Phone as varchar(25)) [Phone]
				,0 [Rf_FinalizeLPUDoctorID]
				,'' [Description]
				,(
					SELECT isnull((
								SELECT TOP 1 TypeCallDoctorID
								FROM hlt_TypeCallDoctor WITH (NOLOCK)
								WHERE CODE = '1'
								), 0)
					) [rf_TypeCallDoctorID]
				,@porch [Entrance]
				,@floor [Floor]
				,0 [rf_AddressID]
				,CASE WHEN @dttid <= 0 THEN 0
				ELSE
				@docid
				END as [rf_DocPRVDID]
				,0 [rf_FinalizeDocPRVDID]
				,(select top 1 LPUID from oms_LPU where MCOD = @mcod) [rf_LPUID]
				,@source [SourceDvt] --
				,getdate() [DateStatus] -- дата/время установки статуса
				-- возраст
				,IIF(date_BD > CONVERT(datetime, '1900/01/01 00:00:00.000', 120),
  			  IIF(DATEDIFF(YEAR, date_BD, getdate()) > 0
  			      ,DATEDIFF(YEAR, date_BD, getdate())
  			      ,IIF(DATEDIFF(MONTH, date_BD, getdate()) > 0
  			        ,DATEDIFF(MONTH, date_BD, getdate())
  			        ,IIF(DATEDIFF(DAY, date_BD, getdate()) >= 0
  			          ,DATEDIFF(DAY, date_BD, getdate())
  			          ,0
  			          )
  			      )
  			  ),
  			0) AS [Age]
				-- тип возраста (лет/мес./д.)
				,IIF(date_BD > CONVERT(datetime, '1900/01/01 00:00:00.000', 120),
  				IIF(DATEDIFF(YEAR, date_BD, getdate()) > 0
  				    ,3
  				    , IIF(DATEDIFF(MONTH, date_BD, getdate()) > 0
  				      ,2
  				      ,IIF(DATEDIFF(DAY, date_BD, getdate()) >= 0
  				        ,1
  				        , 0
  				        )
  				    )
  				)
  			,0) as [AgeTitle]
				from hlt_MKAB where MKABID = @mkabid

				-- запись в историю
				INSERT INTO [dbo].[oms_DocumentHistory]
						   (
							[Editor]
						   ,[NewValue]
						   ,[OldValue]
						   ,[rf_ClientApplicationGuid]
						   ,[rf_DocElemDefGuid]
						   ,[rf_DocTypeDefGuid]
						   ,[rf_DocumentGuid]
						   ,[x_Edition]
						   ,[x_Status])
					 VALUES
						   (''
						   ,''
						   ,''
						   ,
							case @source
								when 3 then 'CB174067-702F-42D0-B0EB-1D84A514515D' -- КЦ
								when 1 then '9C9902BD-AB4C-469C-AB8F-84E41925F95A' --
								else '00000000-0000-0000-0000-000000000000'
							end --[rf_ClientApplicationGuid]
						   ,'00000000-0000-0000-0000-000000000000'
						   ,'743F4CC3-29A1-4F24-882B-33CC9D0ED8FE'
						   , @CallDocGuid
						   ,1
						   ,1)

				SET @result = @EOK
			END

	RETURN
END
go

