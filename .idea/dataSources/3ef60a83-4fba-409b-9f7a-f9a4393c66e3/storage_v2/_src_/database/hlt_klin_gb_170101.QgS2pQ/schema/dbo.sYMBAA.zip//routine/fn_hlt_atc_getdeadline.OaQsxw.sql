
	CREATE FUNCTION [dbo].[fn_hlt_atc_GetDeadLine]
		(@dateReg datetime)
	RETURNS datetime
	AS
	BEGIN
		declare @res datetime
		set @res = case when [dbo].is_day_budni(@dateReg)=1  then
			  case when   datepart(hour,@dateReg) between 9 and 15 or datepart(hour,@dateReg)=16 and datepart(minute,@dateReg)<30 then dateadd(minute,90,@dateReg)
							when datepart(hour,@dateReg) <9 then dateadd(minute,60*9+90, cast(cast(@dateReg as date) as datetime))
							when datepart(hour,@dateReg)=16 and datepart(minute,@dateReg)>=30 or datepart(hour,@dateReg) >16 then dateadd(minute,60*9+90,[dbo].next_day_budni(@dateReg))
						else dateadd(minute,90,@dateReg) end
			  else dateadd(minute,60*9+90, dbo.[next_day_Budni](@dateReg)) end
		return @res
	END
  go

