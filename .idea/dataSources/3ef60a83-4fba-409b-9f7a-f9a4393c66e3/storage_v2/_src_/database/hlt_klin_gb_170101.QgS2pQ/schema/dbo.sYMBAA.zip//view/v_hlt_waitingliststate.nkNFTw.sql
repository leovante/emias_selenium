CREATE VIEW [V_hlt_WaitingListState] AS SELECT 
[hDED].[WaitingListStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateB] as [DateB], 
[hDED].[DateE] as [DateE], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_WaitingListState] as [hDED]
go

