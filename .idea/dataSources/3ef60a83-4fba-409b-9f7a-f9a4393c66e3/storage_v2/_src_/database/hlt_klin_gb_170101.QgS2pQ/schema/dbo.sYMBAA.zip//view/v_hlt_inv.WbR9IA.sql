CREATE VIEW [V_hlt_INV] AS SELECT 
[hDED].[INVID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[COD] as [COD], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[NAME] as [NAME], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_INV] as [hDED]
go

