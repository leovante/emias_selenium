CREATE VIEW [V_oms_SMReestrLoadStatus] AS SELECT 
[hDED].[SMReestrLoadStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME]
FROM [oms_SMReestrLoadStatus] as [hDED]
go

