CREATE VIEW [V_stt_PreHospDeffect] AS SELECT 
[hDED].[PreHospDeffectID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag], 
[hDED].[Code] as [Code], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_PreHospDeffect] as [hDED]
go

