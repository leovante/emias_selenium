CREATE VIEW [V_lbr_LaboratoryKind] AS SELECT 
[hDED].[LaboratoryKindID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flags] as [Flags], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [lbr_LaboratoryKind] as [hDED]
go

