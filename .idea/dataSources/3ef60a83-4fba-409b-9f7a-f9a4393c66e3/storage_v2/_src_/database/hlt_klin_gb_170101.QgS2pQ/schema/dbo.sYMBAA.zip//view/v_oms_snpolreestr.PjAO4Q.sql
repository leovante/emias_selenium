CREATE VIEW [V_oms_SNPOLReestr] AS SELECT 
[hDED].[SNPOLReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_PersonID] as [rf_PersonID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[hDED].[rf_kl_TipOMSID] as [rf_kl_TipOMSID], 
[hDED].[rf_kl_FORMID] as [rf_kl_FORMID], 
[hDED].[N_POL] as [N_POL], 
[hDED].[S_POL] as [S_POL], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E], 
[hDED].[GUID] as [GUID], 
[hDED].[LoadDate] as [LoadDate]
FROM [oms_SNPOLReestr] as [hDED]
go

