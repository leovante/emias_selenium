CREATE VIEW [V_lbr_ResearchService] AS SELECT 
[hDED].[ResearchServiceID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [V_ServiceMedicalName], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[hDED].[rf_ResearchGUID] as [rf_ResearchGUID], 
[hDED].[GUID] as [GUID], 
[hDED].[Flag] as [Flag]
FROM [lbr_ResearchService] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
go

