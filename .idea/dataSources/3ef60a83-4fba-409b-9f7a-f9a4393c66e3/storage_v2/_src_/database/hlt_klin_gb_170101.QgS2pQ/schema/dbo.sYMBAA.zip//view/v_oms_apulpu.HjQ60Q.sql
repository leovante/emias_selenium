CREATE VIEW [V_oms_ApuLpu] AS SELECT 
[hDED].[ApuLpuID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_APU].[NP_NAME] as [V_NP_NAME], 
[jT_oms_APU].[R_NAME] as [V_R_NAME], 
[jT_oms_APU].[UL_NAME] as [V_UL_NAME], 
[jT_oms_APU].[DOM] as [V_DOM], 
[jT_oms_LPU].[ADRES] as [V_ADRES], 
[jT_oms_APU].[ADRES] as [V_ADRES_AU], 
[jT_oms_APU].[G_NAME] as [V_G_NAME], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_LPUClientID] as [rf_LPUClientID], 
[jT_oms_LPU1].[M_NAMES] as [SILENT_rf_LPUClientID], 
[hDED].[rf_APUID] as [rf_APUID], 
[jT_oms_APU].[P_NAMES] as [SILENT_rf_APUID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID], 
[hDED].[rf_ApuTypeID] as [rf_ApuTypeID], 
[jT_oms_ApuType].[ApuTypeName] as [SILENT_rf_ApuTypeID], 
[hDED].[Note] as [Note], 
[hDED].[Flags] as [Flags], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_ApuLpu] as [hDED]
INNER JOIN [oms_APU] as [jT_oms_APU] on [jT_oms_APU].[APUID] = [hDED].[rf_APUID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_LPU] as [jT_oms_LPU1] on [jT_oms_LPU1].[LPUID] = [hDED].[rf_LPUClientID]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
INNER JOIN [oms_ApuType] as [jT_oms_ApuType] on [jT_oms_ApuType].[ApuTypeID] = [hDED].[rf_ApuTypeID]
go

