
CREATE FUNCTION [dbo].[f2dr_CheckHomeVisit2] (
	@mkabid INT
	,@mcod VARCHAR(20)
	)
RETURNS @T TABLE (
	Id INT
	,ErrorCode INT
	,UchastokId INT
	,UchastokCode VARCHAR(50)
	,UchastokName VARCHAR(250)
	,DocprvdId INT
	,DoctorName VARCHAR(250)
	,DocPrvdName varchar(100)
	,AddressFact VARCHAR(500)
	,Phone VARCHAR(50)
	,DATE DATETIME
	,TimeFrom DATETIME
	,TimeTo DATETIME
	,FreeCount INT
	)
AS
BEGIN
	-- Перечень проверок:
	-- Нет ИЭМК								= -3
	-- В ЭМК не указан участок				= -201
	-- На участке нет врача					= -202
	-- Нет расписания у участкового врача	= -203
	-- Расписание участкового врача занято	= -204
	-- Уже есть офрмленный вызов			= -7
	--
	--
	-- Даты, на которые будет проверяться расписание врача
	-- Берем сегодня и завтра
	DECLARE @dateA DATETIME = CAST(GETDATE() AS DATE)
	DECLARE @dateB DATETIME = dateadd(day, 1, @dateA)
	-- Признак типа расписания для вызова врача на дом
	DECLARE @DBTType INT = 8
	-- Коды ошибок
	DECLARE @EOK INT = 0
	DECLARE @EMKABNotFound INT = - 3
	DECLARE @EUnknownError INT = - 11
	DECLARE @EMkabWithoutUchastok INT = - 201
	DECLARE @EUchastokWithoutDoctor INT = - 202
	DECLARE @ESchedulNotExists INT = - 203
	DECLARE @ESchedulBusy INT = - 204
	DECLARE @EExistsVisitDayDoc INT = - 7

	INSERT INTO @T (
		Id
		,ErrorCode
		,UchastokId
		,UchastokCode
		,UchastokName
		,DocprvdId
		,DoctorName
		,DocPRVDName
		,AddressFact
		,Phone
		,DATE
		,TimeFrom
		,TimeTo
		,FreeCount
		)
	VALUES (
		1
		,@EUnknownError
		,- 1
		,''
		,''
		,- 1
		,''
		,''
		,''
		,''
		,'1900-01-01'
		,'1900-01-01'
		,'1900-01-01'
		,- 1
		)

	-- Нет ИЭМК								= -3
	IF NOT EXISTS (
			SELECT 1
			FROM hlt_mkab WITH (NOLOCK)
			WHERE mkabid = @mkabid
				AND isclosed = 0
			)
	BEGIN
		UPDATE @T
		SET ErrorCode = @EMKABNotFound

		RETURN
	END

	-- В ЭМК не указан участок				= -201
	DECLARE @uchastokid INT = 0
	DECLARE @AddressFact VARCHAR(500)
	DECLARE @Phone VARCHAR(50)

	SELECT TOP 1 @uchastokid = rf_uchastokid
		,@AddressFact = AdresFact
		,@Phone = contactMPhone
	FROM hlt_mkab WITH (NOLOCK)
	WHERE mkabid = @mkabid

	IF @uchastokid <= 0
	BEGIN
		UPDATE @T
		SET ErrorCode = @EMkabWithoutUchastok

		RETURN
	END

	UPDATE @T
	SET UchastokId = @uchastokid
		,UchastokCode = hlt_Uchastok.CODE
		,UchastokName = hlt_Uchastok.UchastoCaption
		,DocprvdId = hlt_Uchastok.rf_DocPRVDID
	FROM @T
	INNER JOIN hlt_Uchastok WITH (NOLOCK) ON (1 = 1)
	WHERE hlt_Uchastok.Uchastokid = @uchastokid

	-- На участке нет врача					= -202
	DECLARE @docid INT = 0

	SET @docid = (
			SELECT TOP 1 DocprvdId
			FROM @T
			)

	IF @docid <= 0
	BEGIN
		UPDATE @T
		SET ErrorCode = @EUchastokWithoutDoctor

		RETURN
	END

	UPDATE @T
	SET DoctorName = V_FIO
		,DocPRVDName = v_hlt_DocPRVD.V_PRVDName
		,AddressFact = @AddressFact
		,Phone = @Phone
	FROM @T
	INNER JOIN v_hlt_DocPRVD WITH (NOLOCK) ON (1 = 1)
	WHERE v_hlt_DocPRVD.DocPRVDID = @docid

	-- Если врач относится к другому ЛПУ - таких не считаем
	IF NOT EXISTS (
			SELECT 1
			FROM oms_lpu lpu WITH (NOLOCK)
			INNER JOIN oms_department department WITH (NOLOCK) ON lpu.lpuid = department.rf_LPUID
			INNER JOIN hlt_Docprvd prvd WITH (NOLOCK) ON prvd.rf_DepartmentID = department.DepartmentID
			WHERE prvd.DocPRVDID = @docid
				AND lpu.mcod = @mcod
			)
	BEGIN
		UPDATE @T
		SET ErrorCode = @EUchastokWithoutDoctor

		RETURN
	END

	

	--Добав
	UPDATE @T
	SET ErrorCode = @EOK
	WHERE Id = 1

	--Сегодня
	DECLARE @FreeCnt1 int = 0
	DECLARE @FreeCnt2 int = 0

	SET @FreeCnt1 = isnull(
	(
		SELECT sum(PlanUE - UsedUE)
		FROM hlt_DoctorTimeTable dtt WITH (NOLOCK)
		WHERE dtt.rf_DocPRVDID = @docid
			AND dtt.DATE= @dateA			
			AND dtt.rf_DocBusyType IN (
				SELECT DocBusyTypeID
				FROM hlt_DocBusyType WITH (NOLOCK)
				WHERE TypeBusy & @DBTType != 0
				)
			AND dtt.Begin_Time <> '1900-01-01T00:00:00' AND datepart(hour, dtt.Begin_Time) > 0  
			-- Отсекаем по провам доступа и по времени начала вызова
			AND dtt.FlagAccess & 4 > 0 
			AND dtt.End_Time > getdate()	--Begin_Time
	), 0)

	INSERT INTO @T (
		Id
		,DATE
		,TimeFrom
		,TimeTo
		,FreeCount
		)
	SELECT 2
		,dtt.DATE
		,min(dtt.Begin_Time)
		,max(dtt.End_Time)
		,@FreeCnt1
	FROM hlt_DoctorTimeTable dtt WITH (NOLOCK)
	WHERE dtt.rf_DocPRVDID = @docid
		AND dtt.DATE= @dateA	
		AND dtt.rf_DocBusyType IN (
			SELECT DocBusyTypeID
			FROM hlt_DocBusyType WITH (NOLOCK)
			WHERE TypeBusy & @DBTType != 0
			)
		AND dtt.Begin_Time <> '1900-01-01T00:00:00' AND datepart(hour, dtt.Begin_Time) > 0 
		--AND dtt.Begin_Time > getdate()	
	GROUP BY dtt.DATE

	/*
	--Завтра
	
	SET @FreeCnt2 = isnull(
	(
		SELECT sum(PlanUE - UsedUE)
		FROM hlt_DoctorTimeTable dtt WITH (NOLOCK)
		WHERE dtt.rf_DocPRVDID = @docid
			AND dtt.DATE= @dateB
			AND dtt.rf_DocBusyType IN (
				SELECT DocBusyTypeID
				FROM hlt_DocBusyType WITH (NOLOCK)
				WHERE TypeBusy & @DBTType != 0
				)
			AND dtt.Begin_Time <> '1900-01-01T00:00:00' AND datepart(hour, dtt.Begin_Time) > 0  
			-- Отсекаем по провам доступа
			AND dtt.FlagAccess & 4 > 0 		
	), 0)

	INSERT INTO @T (
		Id
		,DATE
		,TimeFrom
		,TimeTo
		,FreeCount
		)
	SELECT 2
		,dtt.DATE
		,min(dtt.Begin_Time)
		,max(dtt.End_Time)
		,@FreeCnt2
	FROM hlt_DoctorTimeTable dtt WITH (NOLOCK)
	WHERE dtt.rf_DocPRVDID = @docid
		AND dtt.DATE= @dateB	
		AND dtt.rf_DocBusyType IN (
			SELECT DocBusyTypeID
			FROM hlt_DocBusyType WITH (NOLOCK)
			WHERE TypeBusy & @DBTType != 0
			)
		AND dtt.Begin_Time <> '1900-01-01T00:00:00' AND datepart(hour, dtt.Begin_Time) > 0 
	GROUP BY dtt.DATE

	*/
	-- Уже есть офрмленный вызов			= -7
	IF EXISTS (
			SELECT 1
			FROM [hlt_CallDoctor] cd WITH (NOLOCK)
			INNER JOIN hlt_CallDoctorStatus cds WITH (NOLOCK) ON cd.rf_CallDoctorStatusID = cds.CallDoctorStatusID
			WHERE rf_mkabid = @MKABID
				AND (cds.Code = '1' or cds.Code = '0')
				AND CAST(cd.DateCall AS DATE) >= CAST(@dateA AS DATE)
			)
	BEGIN
		UPDATE @T
		SET ErrorCode = @EExistsVisitDayDoc

		RETURN
	END	

	-- Нет расписания у участкового врача	= -203
	IF NOT EXISTS (
			SELECT 1
			FROM hlt_DoctorTimeTable WITH (NOLOCK)
			WHERE rf_DocPRVDID = @docid
				AND DATE BETWEEN @dateA
					AND @dateB
				AND rf_DocBusyType IN (
					SELECT DocBusyTypeID
					FROM hlt_DocBusyType WITH (NOLOCK)
					WHERE TypeBusy & @DBTType != 0
					)
			)
	BEGIN
		UPDATE @T
		SET ErrorCode = @ESchedulNotExists

		RETURN
	END

	-- Расписание участкового врача занято	= -204	
	IF @FreeCnt1 + @FreeCnt2 <= 0
	BEGIN
		UPDATE @T
		SET ErrorCode = @ESchedulBusy

		RETURN
	END

	RETURN
END
go

