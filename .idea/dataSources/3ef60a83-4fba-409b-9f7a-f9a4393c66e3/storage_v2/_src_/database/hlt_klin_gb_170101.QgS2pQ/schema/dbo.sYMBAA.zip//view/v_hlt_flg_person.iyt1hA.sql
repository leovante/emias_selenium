CREATE VIEW [V_hlt_FLG_Person] AS SELECT 
[hDED].[FLG_PersonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[hDED].[NAME_DL] as [NAME_DL], 
[hDED].[SN_DL] as [SN_DL], 
[hDED].[DATE_BL] as [DATE_BL], 
[hDED].[DATE_EL] as [DATE_EL], 
[hDED].[S_DL] as [S_DL], 
[hDED].[N_DL] as [N_DL], 
[hDED].[Name] as [Name], 
[hDED].[PersonGUID] as [PersonGUID], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_FLG_Person] as [hDED]
go

