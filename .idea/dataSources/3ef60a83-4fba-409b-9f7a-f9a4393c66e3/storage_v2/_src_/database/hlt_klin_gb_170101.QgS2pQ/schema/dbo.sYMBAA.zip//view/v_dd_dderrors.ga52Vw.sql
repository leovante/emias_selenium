CREATE VIEW [V_dd_DDErrors] AS SELECT 
[hDED].[DDErrorsID], [hDED].[x_Edition], [hDED].[x_Status], 
((Select Error_Comment from dd_DDErrorCode
where UGUID=rf_DDErrorCodeGUID)) as [V_DDErrorCode], 
[hDED].[rf_DDFormID] as [rf_DDFormID], 
[hDED].[rf_DDErrorCodeGUID] as [rf_DDErrorCodeGUID], 
[hDED].[rf_DDChildFormID] as [rf_DDChildFormID], 
[jT_dd_DDChildForm].[v_FIO] as [SILENT_rf_DDChildFormID], 
[hDED].[COMMENT] as [COMMENT]
FROM [dd_DDErrors] as [hDED]
INNER JOIN [V_dd_DDChildForm] as [jT_dd_DDChildForm] on [jT_dd_DDChildForm].[DDChildFormID] = [hDED].[rf_DDChildFormID]
go

