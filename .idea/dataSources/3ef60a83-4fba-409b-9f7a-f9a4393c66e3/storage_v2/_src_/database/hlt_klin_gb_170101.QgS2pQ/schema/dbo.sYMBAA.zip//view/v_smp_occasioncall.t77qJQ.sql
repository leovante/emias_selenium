CREATE VIEW [V_smp_OccasionCall] AS SELECT 
[hDED].[OccasionCallID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID]
FROM [smp_OccasionCall] as [hDED]
go

