-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spGetRepotrData]
	-- Add the parameters for the stored procedure here
	@dateA datetime,
	@dateB datetime,
	@type int,
	@param varchar(1000),
	@result varchar(max) output

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


declare @trpt_lpulist table 
(
		dbname varchar(250)
		,lpuid int
		,c_ogrn varchar(50)
		,mcod varchar(20)
		,m_names varchar(500)
		,tel varchar(500)
		,adres varchar(500)
		,MainLPU int
)

declare @trpt_usage1 table
(
		  DBName varchar(250)
		, LPUID int
		, [year] int
		, [month] int 
		, TapCnt int 
		, TapCloseCnt int 
		, DoctorCount int
		, TicketCount int
		, RecordCount int
		, MCOD varchar(20)
)

insert into @trpt_lpulist
select 
	 db_name() as DBName,
	 l2.LPUID,
	 l2.C_OGRN,
	 l2.MCOD,
	 l2.m_names,
	 l2.tel,
	 l2.adres,
	 case when l1.LPUID = l2.LPUID then 1 else 0 end as MainLPU 
from oms_lpu l1, oms_lpu l2
where l1.c_ogrn = (select top 1 valuestr from x_usersettings where property = 'ОГРН поликлиники' and rf_userid = 1)
and l1.mcod = (select top 1 valuestr from x_usersettings where property = 'Код поликлиники' and rf_userid = 1)
and (l1.LPUID = l2.rf_MainLPUID OR l1.LPUID = l2.LPUID)

insert into @trpt_usage1
SELECT 
		DBName
		, LPUID
		, [year]
		, [month]
		, 0 as TapCnt
		, 0 as TapCloseCnt
		, sum(DoctorCount) as DoctorCount
		, sum(TicketCount) as TicketCount
		, sum(RecordCount) as RecordCount	
		, '          ' as MCOD		
	FROM (
	select db_name() as DBName,
	case when dept.rf_LPUID is null then (select lpuid from @trpt_lpulist where MainLPU = 1) else dept.rf_LPUID end as LPUID,
	datepart(year, date) as [year],
	datepart(month, date) as [month],
	0 as TapCnt,
	count(distinct dprvd.DocPRVDID) as DoctorCount,
	count(dtt.DoctorTimeTableID) as TicketCount,
	count(dvt.DoctorVisitTableID) as RecordCount
	from hlt_DoctorTimeTable dtt
	left join hlt_DoctorVisitTable dvt on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID
	inner join hlt_DocPRVD dprvd on dtt.rf_DocPRVDID = dprvd.DocPRVDID
	left join oms_Department dept on dept.DepartmentID = dprvd.rf_DepartmentID and dept.DepartmentID != 0 and dept.DepartmentID != (select lpuid from @trpt_lpulist where MainLPU = 1)
	where DoctorTimeTableID > 0
	and (dvt.DoctorVisitTableID is null or dvt.Flags != 8)
	and dprvd.DocPRVDID != 0

	and date between @dateA and @dateB
	
	group by dept.rf_LPUID, datepart(year, date), datepart(month, date)
	)t
	group by DBName, LPUID, [year], [month]




		update @trpt_usage1
		set tapcnt = tt.tapcnt
		from @trpt_usage1 rpt
		inner join 
		(
			select LPUID, [year], [month], sum (tapcnt) tapcnt from (
			select 
				case when dept.rf_LPUID is null then (select lpuid from @trpt_lpulist where MainLPU = 1) else dept.rf_LPUID end as LPUID, 
				datepart(year, DateTAP) as [year],
				datepart(month, DateTAP)  as [month],
				count(tapid) as tapcnt
			from hlt_tap
			left join oms_Department dept on dept.DepartmentID = hlt_tap.rf_DepartmentID and dept.DepartmentID != 0 and dept.DepartmentID != (select lpuid from @trpt_lpulist where MainLPU = 1)
			group by  dept.rf_LPUID, datepart(year, DateTAP), datepart(month, DateTAP)) t0
			group by LPUID, [year], [month]
		) tt
		on tt.[year] = rpt.[year] and tt.[month] = rpt.[month] and tt.LPUID = rpt.LPUID


		update @trpt_usage1
		set TapCloseCnt = tt.tapcnt		
		from @trpt_usage1 rep
		inner join 
		(
			select LPUID, [year], [month], sum (tapcnt) tapcnt from (
			select 
				case when dept.rf_LPUID is null then (select lpuid from @trpt_lpulist where MainLPU = 1) else dept.rf_LPUID end as LPUID, 
				datepart(year, DateTAP) as [year],
				datepart(month, DateTAP)  as [month],
				count(tapid) as tapcnt
			from hlt_tap
			left join oms_Department dept on dept.DepartmentID = hlt_tap.rf_DepartmentID and dept.DepartmentID != 0 and dept.DepartmentID != (select lpuid from @trpt_lpulist where MainLPU = 1)
			where hlt_tap.isClosed = 1
			group by  dept.rf_LPUID, datepart(year, DateTAP), datepart(month, DateTAP)) t0
			group by LPUID, [year], [month]
		) tt
		on tt.[year] = rep.[year] and tt.[month] = rep.[month] and tt.LPUID = rep.LPUID

		

		update @trpt_usage1
		set MCOD = (select top 1 MCOD from oms_LPU lpu where lpu.LPUID = rpt.LPUID)
		from @trpt_usage1	 rpt


set @result = (select 
	 l1.DBName
	,l1.LPUID	
	,l1.C_OGRN
	,ltrim(rtrim(l1.MCOD)) as MCOD
	,l1.M_Names
	--,l1.tel
	--,l1.adres
	,l1.MainLPU
	,r1.[year]
	,r1.[month]
	,r1.TapCnt
	,r1.TapCloseCnt
	,r1.DoctorCount
	,r1.TicketCount
	,r1.RecordCount
from @trpt_usage1 r1 inner join @trpt_lpulist l1 on r1.LPUID = l1.LPUID
for xml raw ('raw'), root ('report'))

END
go

