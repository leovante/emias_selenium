CREATE VIEW [V_oms_Licenses] AS SELECT 
[hDED].[LicensesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[NumLicense] as [NumLicense], 
[hDED].[Serial] as [Serial], 
[hDED].[MinNumber] as [MinNumber], 
[hDED].[Number] as [Number], 
[hDED].[MaxNumber] as [MaxNumber], 
[hDED].[Other] as [Other], 
[hDED].[Data] as [Data], 
[hDED].[HOST_GUID] as [HOST_GUID], 
[hDED].[OGRN_LPU] as [OGRN_LPU], 
[hDED].[mCod] as [mCod], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_Licenses] as [hDED]
go

