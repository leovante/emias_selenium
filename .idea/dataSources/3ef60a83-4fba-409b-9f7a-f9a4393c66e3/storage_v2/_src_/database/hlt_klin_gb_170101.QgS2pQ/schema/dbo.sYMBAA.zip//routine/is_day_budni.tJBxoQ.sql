
	Create FUNCTION [dbo].[is_day_Budni]( @d datetime)
	RETURNS int
	AS
	BEGIN
	declare @res int;

	SET @res =  (CASE 
	 when left(convert(varchar,@d,104),5) in ('01.01','02.01','03.01','04.01','05.01',
	  '06.01','07.01','23.02','08.03','01.05','09.05','12.06','04.11') then 0 
	 when convert(varchar,@d,104) in ('08.01.2017','06.11.2017','24.02.2017','08.05.2017')then 0 
	 when convert(varchar,@d,104) in ('08.01.2018','05.11.2018','09.03.2018','02.05.2018','30.04.2018','11.06.2018','31.12.2018')then 0 
	 when convert(varchar,@d,104) in ('28.04.2018','09.06.2018','29.12.2018')then 1
	 WHEN DATENAME(dw, @d) IN ('Saturday','Sunday') THEN 0 
	  ELSE 1 END) 
	RETURN @res
	END
  go

