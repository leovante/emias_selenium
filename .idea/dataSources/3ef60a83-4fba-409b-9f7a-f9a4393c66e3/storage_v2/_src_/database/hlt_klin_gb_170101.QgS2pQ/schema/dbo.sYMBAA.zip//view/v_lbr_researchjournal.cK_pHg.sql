CREATE VIEW [V_lbr_ResearchJournal] AS SELECT 
[hDED].[ResearchJournalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResearchGUID] as [rf_ResearchGUID], 
[hDED].[rf_LaboratoryResearchID] as [rf_LaboratoryResearchID], 
[jT_lbr_LaboratoryResearch].[Number] as [SILENT_rf_LaboratoryResearchID], 
[hDED].[rf_ResearchStateID] as [rf_ResearchStateID], 
[hDED].[HL7Message] as [HL7Message], 
[hDED].[Comment] as [Comment], 
[hDED].[ActionDate] as [ActionDate]
FROM [lbr_ResearchJournal] as [hDED]
INNER JOIN [lbr_LaboratoryResearch] as [jT_lbr_LaboratoryResearch] on [jT_lbr_LaboratoryResearch].[LaboratoryResearchID] = [hDED].[rf_LaboratoryResearchID]
go

