CREATE VIEW [V_rls_PhAct_Desc] AS SELECT 
[hDED].[PhAct_DescID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PharmaActionsUID] as [rf_PharmaActionsUID], 
[hDED].[rf_DescriptionsUID] as [rf_DescriptionsUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[Number] as [Number], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_PhAct_Desc] as [hDED]
go

