CREATE VIEW [V_rls_ActMat_PhGr] AS SELECT 
[hDED].[ActMat_PhGrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsPharmaGroupUID] as [rf_ClsPharmaGroupUID], 
[hDED].[rf_ActMattersUID] as [rf_ActMattersUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_ActMat_PhGr] as [hDED]
go

