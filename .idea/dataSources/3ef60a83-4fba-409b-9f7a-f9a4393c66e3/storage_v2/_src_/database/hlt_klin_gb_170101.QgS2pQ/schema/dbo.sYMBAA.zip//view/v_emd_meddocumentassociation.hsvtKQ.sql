CREATE VIEW [V_emd_MedDocumentAssociation] AS SELECT 
[hDED].[MedDocumentAssociationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FirstMedDocumentID] as [rf_FirstMedDocumentID], 
[jT_emd_MedDocument].[RegNum] as [SILENT_rf_FirstMedDocumentID], 
[hDED].[rf_SecondMedDocumentID] as [rf_SecondMedDocumentID], 
[jT_emd_MedDocument1].[RegNum] as [SILENT_rf_SecondMedDocumentID], 
[hDED].[rf_AssociationTypeID] as [rf_AssociationTypeID], 
[jT_emd_AssociationType].[Name] as [SILENT_rf_AssociationTypeID], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [emd_MedDocumentAssociation] as [hDED]
INNER JOIN [emd_MedDocument] as [jT_emd_MedDocument] on [jT_emd_MedDocument].[MedDocumentID] = [hDED].[rf_FirstMedDocumentID]
INNER JOIN [emd_MedDocument] as [jT_emd_MedDocument1] on [jT_emd_MedDocument1].[MedDocumentID] = [hDED].[rf_SecondMedDocumentID]
INNER JOIN [emd_AssociationType] as [jT_emd_AssociationType] on [jT_emd_AssociationType].[AssociationTypeID] = [hDED].[rf_AssociationTypeID]
go

