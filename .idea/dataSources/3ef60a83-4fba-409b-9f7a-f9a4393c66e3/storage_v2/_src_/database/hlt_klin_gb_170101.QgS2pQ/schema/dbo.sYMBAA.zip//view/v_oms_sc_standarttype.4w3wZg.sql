CREATE VIEW [V_oms_sc_StandartType] AS SELECT 
[hDED].[sc_StandartTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[TypeSt_Code] as [TypeSt_Code], 
[hDED].[TypeSt] as [TypeSt]
FROM [oms_sc_StandartType] as [hDED]
go

