CREATE VIEW [V_oms_Tokens] AS SELECT 
[hDED].[TokensID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[DO] as [DO], 
[hDED].[SER_REC] as [SER_REC], 
[hDED].[MIN_NUM] as [MIN_NUM], 
[hDED].[MAX_NUM] as [MAX_NUM], 
[hDED].[KEY_STATE1] as [KEY_STATE1], 
[hDED].[KEY_STATE2] as [KEY_STATE2], 
[hDED].[KEY_STATE3] as [KEY_STATE3], 
[hDED].[KEY_STATE4] as [KEY_STATE4], 
[hDED].[KEY_ATTRIB1] as [KEY_ATTRIB1], 
[hDED].[KEY_ATTRIB2] as [KEY_ATTRIB2], 
[hDED].[KEY_ATTRIB3] as [KEY_ATTRIB3], 
[hDED].[KEY_ATTRIB4] as [KEY_ATTRIB4], 
[hDED].[CONTROL] as [CONTROL]
FROM [oms_Tokens] as [hDED]
go

