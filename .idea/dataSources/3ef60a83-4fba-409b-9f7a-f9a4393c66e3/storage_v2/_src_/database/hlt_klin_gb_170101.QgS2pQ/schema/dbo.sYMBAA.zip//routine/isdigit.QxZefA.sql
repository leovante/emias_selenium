CREATE PROCEDURE [dbo].[IsDigit]  @Field varchar(30) AS 

declare @Like varchar(30)
declare @ii int;

set @Like ='';
set @ii  = 0


while @ii< len(@Field)
begin
	set @Like =@Like + '[0-9]';
	set @ii=@ii+1;
end
select 
case 
when PATINDEX ( '%'+@Like+'%' ,@Field) >0 then @Field
else '0' end
go

