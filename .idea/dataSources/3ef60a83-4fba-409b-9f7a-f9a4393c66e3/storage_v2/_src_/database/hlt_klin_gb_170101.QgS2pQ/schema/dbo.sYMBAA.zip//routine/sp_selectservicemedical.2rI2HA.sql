
CREATE procedure [dbo].[sp_selectServiceMedical]
		@str varchar(100),
		@dateSm datetime,
		@docPrvdId int, /* значение Id из hlt_DocPrvd */
		@doctorId int, /* значение Id из hlt_LpuDoctor */
		@departmentId int, 	
		@reasonTypeId int, /* цель посещения (Заболевание,Профосмотр,Патронаж,Другое), таблица oms_kl_ReasonType */	
		@mkabId int,
		@medicalHistoryId int,
		@favorite bit,
		@result varchar(254) output--выходной параметр в случае ошибки или доп.инфо
as
begin
	set @result = ''--информационное сообщение, в случае ошибки или доп.инфо.
	set @str = '%' + ltrim(rtrim(@str)) + '%';

	if (@favorite = 1) 
	begin
		
		SELECT top 100
			sm.[ServiceMedicalID] AS Id,
			sm.[ServiceMedicalCode]+case when len(@str)>3 and len(FCode_Usl)>2 and sm.FCode_Usl LIKE @str ESCAPE '~' 
						and (sm.FCode_Usl != sm.[ServiceMedicalCode]) then ' ('+sm.FCode_Usl+')' else '' end  AS Code,
			sm.[ServiceMedicalName] AS Name, 
			sm.[GUIDSM] AS UGuid, 
			sm.[Date_B] AS [Begin], 
			sm.[Date_E] AS [End], 
			smDepType.[kl_DepartmentTypeID] AS [DepTypeId], 
			smDepType.[Name] AS [DepTypeName], 
			smDepProfile.[kl_DepartmentProfileID] AS [DepProfileId], 
			smDepProfile.[Name] AS [DepProfileName],
			prvd.[PRVDID] AS [PrvdId], 
			prvd.[NAME] AS [PrvdName], 
			prvs.[PRVSID] AS [PrvsId], 
			prvs.[PRVS_NAME] AS [PrvsName],
			actionteeth.[kl_ActionTeethID] as ActionTeethId,
			actionteeth.[Name] as ActionTeethName,
			fr.FavoriteRecordsID AS [Favorite],						
			unit.kl_MedCareUnitID as UnitId,
			unit.CODE as UnitCode,
			unit.NAME as UnitName,
			sm.Info as Info,
			sm.IDServ as IdService--Номер записи в реестре услуг
		FROM [dbo].[oms_ServiceMedical] AS sm
				INNER JOIN [dbo].[oms_kl_MedCareUnit] as unit ON sm.rf_kl_MedCareUnitID = unit.kl_MedCareUnitID
				INNER JOIN [dbo].[oms_kl_DepartmentType] AS smDepType ON sm.[rf_kl_DepartmentTypeID] = smDepType.[kl_DepartmentTypeID]
				INNER JOIN [dbo].[oms_kl_DepartmentProfile] AS smDepProfile ON sm.[rf_kl_DepartmentProfileID] = smDepProfile.[kl_DepartmentProfileID]
				INNER JOIN [dbo].[oms_PRVD] AS prvd ON sm.[rf_PRVDID] = prvd.[PRVDID]
				INNER JOIN [dbo].[oms_PRVS] AS prvs ON sm.[rf_PRVSID] = prvs.[PRVSID]
				INNER JOIN [dbo].[oms_kl_ActionTeeth] AS actionteeth ON sm.rf_kl_ActionTeethID = actionteeth.kl_ActionTeethID
				INNER JOIN [dbo].[hlt_FavoriteRecords] AS fr on sm.[ServiceMedicalID] = fr.[rf_DocID] and fr.[rf_DocTypeDefGUID] = '3426C6B4-49EB-41CA-A240-D27D4FC727BB' and fr.[rf_DocPRVDID] = @docPrvdId
		where sm.ServiceMedicalID > 0 AND ((sm.[ServiceMedicalName] LIKE @str ESCAPE '~') OR (sm.[ServiceMedicalCode] LIKE @str ESCAPE '~')
		OR (len(@str)>3 and len(FCode_Usl)>2 and sm.FCode_Usl LIKE @str ESCAPE '~'))
		ORDER BY sm.[ServiceMedicalID] ASC

	end 
	else
	begin
		/* ищем услуги без признака избранные */

		--дополнительные параметры, получаем из входных
		declare @depProfileId int,
				@depTypeId int,
				@lpuId int;
		declare @prvdId int,
				@prvsId int;
		select @depTypeId = ISNULL(rf_kl_DepartmentTypeID, 0),
		 @depProfileId = ISNULL(rf_kl_DepartmentProfileID, 0), 
		 @lpuId = ISNULL(rf_LPUID, 0) from oms_Department where DepartmentID = @departmentId;

		/* получаем значения ИД должности и специлальности из занимаемой должности врача (hlt_DocPrvd) */
		select @prvdId = ISNULL(rf_PRVDID, 0), @prvsId = ISNULL(rf_PRVSID, 0) from hlt_DocPRVD where DocPRVDID = @docPrvdId;
		--на будущее: если будет задействован @doctorId(hlt_LpuDoctor), то из hlt_LpuDoctor взять @prvdId и @prvsId
		
		/* доп параметры из мкаба , пока не используется */
		--select isnull(1, 0) from hlt_MKAB where MKABID = @mkabId;

		/* получить массив ИД профилей для дальнейшего поиска */
		/* массив всех профилей ИД: профили по отделению (из лицензии) + профиль самого отделения*/
		DECLARE @tProfiles TABLE (id int, name varchar(500))
		INSERT INTO @tProfiles(id, name)
			select distinct ttt.id, ttt.name from 
			(
				select lic.rf_kl_DepartmentProfileID as id, dp.Name as name from oms_LicenceReestrSM lic
					join oms_kl_DepartmentProfile dp on lic.rf_kl_DepartmentProfileID = dp.kl_DepartmentProfileID
					where lic.rf_DepartmentID = @departmentId and (dp.[Date_E] >= @dateSm) AND (dp.[Date_B] <= @dateSm)
				union all
				select top 1 d.[rf_kl_DepartmentProfileID] as id, dp1.Name as name from oms_Department d
					join oms_kl_DepartmentProfile dp1 on d.rf_kl_DepartmentProfileID = dp1.kl_DepartmentProfileID
					where d.DepartmentID = @departmentId and (dp1.[Date_E] >= @dateSm) AND (dp1.[Date_B] <= @dateSm)
			)ttt

		/* признак - это стоматологический профиль или нет: для дальнейшей развилки в основной выборке данных */
		declare @IsStomatProfile bit
		set @IsStomatProfile = 0;
		set @IsStomatProfile = (Select case when COUNT(1) > 0 then 1 else 0 end from @tProfiles t where t.name like '%стомат%' or t.name like '%ортодонтия%')

		/* массив Id-идентификаторов записей стоматологических профилей по условию отбора: 1) по наименованию и 2) дат действия записей */
		DECLARE @tProfilesStomat TABLE (id int)
		INSERT INTO @tProfilesStomat(id)	
			select distinct ttt.id from 
			(
				select distinct kl_DepartmentProfileID as id from oms_kl_DepartmentProfile d 
					where (d.name like '%стомат%' or d.name like '%ортодонтия%') 
						  and (d.[Date_E] >= @dateSm AND d.[Date_B] <= @dateSm)
			)ttt
		
		/* основная выборка данных */
		SELECT top 100
			sm.[ServiceMedicalID] AS Id,
			sm.[ServiceMedicalCode]+case when len(@str)>3 and len(FCode_Usl)>2 and sm.FCode_Usl LIKE @str ESCAPE '~' and (sm.FCode_Usl != sm.[ServiceMedicalCode]) then ' ('+sm.FCode_Usl+')' else '' end  AS Code,
			sm.[ServiceMedicalName] AS Name, 
			sm.[GUIDSM] AS UGuid, 
			sm.[Date_B] AS [Begin], 
			sm.[Date_E] AS [End], 
			smDepType.[kl_DepartmentTypeID] AS [DepTypeId], 
			smDepType.[Name] AS [DepTypeName], 
			smDepProfile.[kl_DepartmentProfileID] AS [DepProfileId], 
			smDepProfile.[Name] AS [DepProfileName],
			prvd.[PRVDID] AS [PrvdId], 
			prvd.[NAME] AS [PrvdName], 
			prvs.[PRVSID] AS [PrvsId], 
			prvs.[PRVS_NAME] AS [PrvsName],
			actionteeth.[kl_ActionTeethID] as ActionTeethId,
			actionteeth.[Name] as ActionTeethName,			
			CASE WHEN (fr.FavoriteRecordsID IS NULL) THEN 0 ELSE fr.FavoriteRecordsID END AS [Favorite],
			unit.kl_MedCareUnitID as UnitId,
			unit.CODE as UnitCode,
			unit.NAME as UnitName,
			sm.Info as Info,
			sm.IDServ as IdService--Номер записи в реестре услуг
  		    FROM [dbo].[oms_ServiceMedical] AS sm   
			  INNER JOIN [dbo].[oms_kl_MedCareUnit] as unit ON sm.rf_kl_MedCareUnitID = unit.kl_MedCareUnitID       
			  INNER JOIN [dbo].[oms_kl_DepartmentType] AS smDepType ON sm.[rf_kl_DepartmentTypeID] = smDepType.[kl_DepartmentTypeID]
			  INNER JOIN [dbo].[oms_kl_DepartmentProfile] AS smDepProfile ON sm.[rf_kl_DepartmentProfileID] = smDepProfile.[kl_DepartmentProfileID]
			  INNER JOIN [dbo].[oms_PRVD] AS prvd ON sm.[rf_PRVDID] = prvd.[PRVDID]
			  INNER JOIN [dbo].[oms_PRVS] AS prvs ON sm.[rf_PRVSID] = prvs.[PRVSID]
			  INNER JOIN [dbo].[oms_kl_ActionTeeth] AS actionteeth ON sm.rf_kl_ActionTeethID = actionteeth.kl_ActionTeethID
			  INNER JOIN [dbo].oms_kl_AgeGroup AS AgeGroup ON sm.rf_kl_AgeGroupID = AgeGroup.kl_AgeGroupID
			  LEFT JOIN [dbo].[hlt_FavoriteRecords] AS fr on sm.[ServiceMedicalID] = fr.[rf_DocID] and fr.[rf_DocTypeDefGUID] = '3426C6B4-49EB-41CA-A240-D27D4FC727BB' and fr.[rf_DocPRVDID] = @docPrvdId
			WHERE (AgeGroup.kl_AgeGroupID = 0 OR AgeGroup.CODE = '3' OR AgeGroup.CODE = case when (select dbo.FullYearAge(hltMKAB.DATE_BD, @dateSm) from hlt_MKAB hltMKAB where hltMKAB.MKABID = @mkabId) >= 18 then '1' else '2' end) and
			( 
				EXISTS (SELECT 
				1 AS [C1]
				FROM [dbo].[oms_Tariff] AS tariff
				WHERE (tariff.[rf_ServiceMedicalID] = sm.[ServiceMedicalID]) 
				AND (tariff.[rf_kl_ReasonTypeID] IN (0,@reasonTypeId)) 
				AND (tariff.[rf_LPUID] IN (0,@lpuId)) 
				AND (tariff.[Date_B] <= @dateSm) AND (@dateSm <= tariff.[Date_E]))
			)
			AND (sm.[ServiceMedicalID] > 0) 
			AND (sm.[Date_E] >= @dateSm) 
			AND (sm.[Date_B] <= @dateSm) 
			AND 
			(
				(
					(
						(smDepProfile.[kl_DepartmentProfileID] IN (select id from @tProfiles )) --(0,0)
						OR
						((select count(1) from @tProfiles where id = 0) > 0)
					)
					AND (smDepType.[kl_DepartmentTypeID] IN (0,@depTypeId))	--тип отделения: поликлиника/стационар, тип берем из отделения, которое приходит извне в хранимку (поле отделения в форме оказанной услуги).
					AND (prvs.[PRVSID] IN (0,@prvsId)) 
					AND (prvd.[PRVDID] IN (0,@prvdId))
				)
				OR
				(
						--развилка для стоматологии
					(	--если ИД профиля входит в список профилей "стомат", то берем все стомат-профили						
						@IsStomatProfile = 1						
						AND sm.[rf_kl_DepartmentProfileID] in (select id from @tProfilesStomat)
					)			
					AND (smDepType.[kl_DepartmentTypeID] IN (0,@depTypeId))	
					AND (prvs.[PRVSID] IN (0,@prvsId)) 
					AND (prvd.[PRVDID] IN (0,@prvdId))
				)				
			)
			AND ((sm.[ServiceMedicalName] LIKE @str ESCAPE '~')	OR (sm.[ServiceMedicalCode] LIKE @str ESCAPE '~')
			OR (len(@str)>3 and len(FCode_Usl)>2 and sm.FCode_Usl LIKE @str ESCAPE '~'))
			ORDER BY sm.[ServiceMedicalID] ASC 	
	end	
end

go

