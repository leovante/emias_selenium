CREATE VIEW [V_lbr_AntiFag] AS SELECT 
[hDED].[AntiFagID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[CodeLis] as [CodeLis], 
[hDED].[Name] as [Name], 
[hDED].[Type] as [Type], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [lbr_AntiFag] as [hDED]
go

