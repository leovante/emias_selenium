CREATE FUNCTION [dbo].[GetCurrentUserID]()
RETURNS int
AS
BEGIN
	/* проверяем appName из конфига */
	
	DECLARE @app nvarchar(128)
	SET @app = APP_NAME()
	
	DECLARE @index1 int
	SET @index1 = charindex('-', @app) + 1;
	
	DECLARE @index2 int
	SET @index2 = charindex('-', @app, @index1) + 1;

	/* если есть appName берем его */
	if (@index1 > 1) AND (@index2 > @index1)
	begin
		RETURN CAST(SUBSTRING(@app, @index2, LEN(@app)) as int);

	end 
    
    DECLARE @context binary(16)
    SET @context = (select CONTEXT_INFO());    
   
	/* не нашлось контекста - выходим.*/
    if(@context is NULL OR @context = 0x0)
		RETURN 0;
    
    /* юзер занимает последний 4 байта, поэтому его тупо к инту */ 
   return convert(int, @context);
END
go

