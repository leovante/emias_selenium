CREATE VIEW [V_stt_FHDoctor] AS SELECT 
[hDED].[FHDoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_stt_FHRoleDoctor].[Name] as [V_RoleName], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_FHRoleDoctorID] as [rf_FHRoleDoctorID], 
[hDED].[rf_FHBrigadeID] as [rf_FHBrigadeID], 
[hDED].[Surname] as [Surname], 
[hDED].[Name] as [Name], 
[hDED].[Patronymic] as [Patronymic], 
[hDED].[Flag] as [Flag]
FROM [stt_FHDoctor] as [hDED]
INNER JOIN [stt_FHRoleDoctor] as [jT_stt_FHRoleDoctor] on [jT_stt_FHRoleDoctor].[FHRoleDoctorID] = [hDED].[rf_FHRoleDoctorID]
go

