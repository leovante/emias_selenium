CREATE VIEW [V_lbr_ResearchParamValueType] AS SELECT 
[hDED].[ResearchParamValueTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [lbr_ResearchParamValueType] as [hDED]
go

