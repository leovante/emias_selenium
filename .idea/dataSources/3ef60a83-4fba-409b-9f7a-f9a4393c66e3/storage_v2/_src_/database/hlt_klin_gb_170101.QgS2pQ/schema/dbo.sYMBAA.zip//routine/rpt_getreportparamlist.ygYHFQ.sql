CREATE FUNCTION [dbo].[rpt_GetReportParamList]

(

      -- Add the parameters for the function here

      @mcod varchar(20),

      @year int,

      @month int

)

RETURNS

@Res TABLE

(     

      ParamId int,

      ParamName varchar(50),

      ParamIntValue int

)

AS

BEGIN

      -- Fill the table variable with the rows for your result set

     

      -- 1. Количество ТАП

      insert into @Res (ParamId, ParamName, ParamIntValue)

      select 1,'TapCount',isnull(count(1), 0)

      from hlt_tap tap

      inner join oms_Department Department on tap.rf_DepartmentID = Department.DepartmentID

      inner join oms_LPU lpu on Department.rf_LPUID = lpu.LPUID

      where  lpu.mcod = @mcod

            and datepart(year, tap.datetap)  = @year

            and datepart(month, tap.datetap) = @month

 

      -- 2. Количество закрытых ТАП

      insert into @Res (ParamId, ParamName, ParamIntValue)

      select 2,'CloseTapCount',isnull(count(1), 0)

      from hlt_tap tap

      inner join oms_Department Department on tap.rf_DepartmentID = Department.DepartmentID

      inner join oms_LPU lpu on Department.rf_LPUID = lpu.LPUID

      where  lpu.mcod = @mcod

            and datepart(year, tap.datetap)  = @year

            and datepart(month, tap.datetap) = @month

            and tap.isClosed = 1

 

 

      -- 3. Количество врачей с расписанием

      insert into @Res (ParamId, ParamName, ParamIntValue)

      select 3,'SchedulDocCount',isnull(count(distinct rf_DocPRVDID), 0)

      from hlt_doctortimetable dtt

      inner join hlt_DocPRVD dprvd on dtt.rf_DocPRVDID = dprvd.DocPRVDID

      inner join oms_Department Department on dprvd.rf_DepartmentID = Department.DepartmentID

      inner join oms_LPU lpu on Department.rf_LPUID = lpu.LPUID

      where  lpu.mcod = @mcod

            and datepart(year, dtt.date)  = @year

            and datepart(month, dtt.date) = @month

 

 

      -- 4. Количество ячеек расписания

      insert into @Res (ParamId, ParamName, ParamIntValue)

      select 4,'SchedulTicketCount',isnull(sum(PlanUE), 0)

      from hlt_doctortimetable dtt

      inner join hlt_DocBusyType DocBusyType on dtt.rf_DocBusyType = DocBusyType.DocBusyTypeID

      inner join hlt_DocPRVD dprvd on dtt.rf_DocPRVDID = dprvd.DocPRVDID

      inner join oms_Department Department on dprvd.rf_DepartmentID = Department.DepartmentID

      inner join oms_LPU lpu on Department.rf_LPUID = lpu.LPUID

      where  lpu.mcod = @mcod

            and datepart(year, dtt.date)  = @year

            and datepart(month, dtt.date) = @month

            and datepart(hour, Begin_Time) != 0

            and DocBusyType.TypeBusy > 0

 

      -- 5. Количество записей на прием. Всего

      insert into @Res (ParamId, ParamName, ParamIntValue)

      select 5,'RecordCount',isnull(count(dvt.DoctorVisitTableID), 0)

      from hlt_doctortimetable dtt    

      inner join hlt_DocBusyType DocBusyType on dtt.rf_DocBusyType = DocBusyType.DocBusyTypeID

      inner join hlt_DocPRVD dprvd on dtt.rf_DocPRVDID = dprvd.DocPRVDID

      inner join oms_Department Department on dprvd.rf_DepartmentID = Department.DepartmentID

      inner join oms_LPU lpu on Department.rf_LPUID = lpu.LPUID

      inner join hlt_DoctorVisitTable dvt on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID

      where  lpu.mcod = @mcod and dvt.Flags<>8

            and datepart(year, dtt.date)  = @year

            and datepart(month, dtt.date) = @month

            and DocBusyType.TypeBusy > 0

 

      -- 6. Количество записей на прием. Через регистратуру

      insert into @Res (ParamId, ParamName, ParamIntValue)

      select 6,'RecordCountReg',isnull(count(dvt.DoctorVisitTableID), 0)

      from hlt_doctortimetable dtt    

      inner join hlt_DocBusyType DocBusyType on dtt.rf_DocBusyType = DocBusyType.DocBusyTypeID

      inner join hlt_DocPRVD dprvd on dtt.rf_DocPRVDID = dprvd.DocPRVDID

      inner join oms_Department Department on dprvd.rf_DepartmentID = Department.DepartmentID

      inner join oms_LPU lpu on Department.rf_LPUID = lpu.LPUID

      inner join hlt_DoctorVisitTable dvt on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID

      where  lpu.mcod = @mcod and dvt.Flags<>8

            and datepart(year, dtt.date)  = @year

            and datepart(month, dtt.date) = @month

            and DocBusyType.TypeBusy > 0

            and dvt.FromReg = 1

 

      -- 7. Количество записей на прием. Через doc

      insert into @Res (ParamId, ParamName, ParamIntValue)

      select 7,'RecordCountDoc',isnull(count(dvt.DoctorVisitTableID), 0)

      from hlt_doctortimetable dtt    

      inner join hlt_DocBusyType DocBusyType on dtt.rf_DocBusyType = DocBusyType.DocBusyTypeID

      inner join hlt_DocPRVD dprvd on dtt.rf_DocPRVDID = dprvd.DocPRVDID

      inner join oms_Department Department on dprvd.rf_DepartmentID = Department.DepartmentID

      inner join oms_LPU lpu on Department.rf_LPUID = lpu.LPUID

      inner join hlt_DoctorVisitTable dvt on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID

      where  lpu.mcod = @mcod and dvt.Flags<>8

            and datepart(year, dtt.date)  = @year

            and datepart(month, dtt.date) = @month

            and DocBusyType.TypeBusy > 0

            and dvt.FromDoc = 1

 

 

            -- 8. Количество записей на прием. Через doc

      insert into @Res (ParamId, ParamName, ParamIntValue)

      select 8,'RecordCountInfomat',isnull(count(dvt.DoctorVisitTableID), 0)

      from hlt_doctortimetable dtt    

      inner join hlt_DocBusyType DocBusyType on dtt.rf_DocBusyType = DocBusyType.DocBusyTypeID

      inner join hlt_DocPRVD dprvd on dtt.rf_DocPRVDID = dprvd.DocPRVDID

      inner join oms_Department Department on dprvd.rf_DepartmentID = Department.DepartmentID

      inner join oms_LPU lpu on Department.rf_LPUID = lpu.LPUID

      inner join hlt_DoctorVisitTable dvt on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID

      where  lpu.mcod = @mcod and dvt.Flags<>8

            and datepart(year, dtt.date)  = @year

            and datepart(month, dtt.date) = @month

            and DocBusyType.TypeBusy > 0

            and dvt.fromInfomat = 1

 

 

            -- 9. Количество записей на прием. Через doc

      insert into @Res (ParamId, ParamName, ParamIntValue)

      select 9,'RecordCountInternet',isnull(count(dvt.DoctorVisitTableID), 0)

      from hlt_doctortimetable dtt    

      inner join hlt_DocBusyType DocBusyType on dtt.rf_DocBusyType = DocBusyType.DocBusyTypeID

      inner join hlt_DocPRVD dprvd on dtt.rf_DocPRVDID = dprvd.DocPRVDID

      inner join oms_Department Department on dprvd.rf_DepartmentID = Department.DepartmentID

      inner join oms_LPU lpu on Department.rf_LPUID = lpu.LPUID

      inner join hlt_DoctorVisitTable dvt on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID

      where  lpu.mcod = @mcod and dvt.Flags<>8

            and datepart(year, dtt.date)  = @year

            and datepart(month, dtt.date) = @month

            and DocBusyType.TypeBusy > 0

            and dvt.fromInternet = 1

 

 

 

            -- 10. Количество записей на прием. Через doc

      insert into @Res (ParamId, ParamName, ParamIntValue)

      select 10,'RecordCountOtherLPU',isnull(count(dvt.DoctorVisitTableID), 0)

      from hlt_doctortimetable dtt    

      inner join hlt_DocBusyType DocBusyType on dtt.rf_DocBusyType = DocBusyType.DocBusyTypeID

      inner join hlt_DocPRVD dprvd on dtt.rf_DocPRVDID = dprvd.DocPRVDID

      inner join oms_Department Department on dprvd.rf_DepartmentID = Department.DepartmentID

      inner join oms_LPU lpu on Department.rf_LPUID = lpu.LPUID

      inner join hlt_DoctorVisitTable dvt on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID

      where  lpu.mcod = @mcod and dvt.Flags<>8

            and datepart(year, dtt.date)  = @year

            and datepart(month, dtt.date) = @month

            and DocBusyType.TypeBusy > 0

            and dvt.fromOtherLPU = 1

 

 

      -- 11. Количество записей на прием. Вне расписания

      insert into @Res (ParamId, ParamName, ParamIntValue)

      select 11,'RecordCountOutSchedul',isnull(count(dvt.DoctorVisitTableID), 0)

      from hlt_doctortimetable dtt    

      inner join hlt_DocBusyType DocBusyType on dtt.rf_DocBusyType = DocBusyType.DocBusyTypeID

      inner join hlt_DocPRVD dprvd on dtt.rf_DocPRVDID = dprvd.DocPRVDID

      inner join oms_Department Department on dprvd.rf_DepartmentID = Department.DepartmentID

      inner join oms_LPU lpu on Department.rf_LPUID = lpu.LPUID

      inner join hlt_DoctorVisitTable dvt on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID

      where  lpu.mcod = @mcod and dvt.Flags<>8

            and datepart(year, dtt.date)  = @year

            and datepart(month, dtt.date) = @month

            and datepart(hour, Begin_Time) = 0

            and DocBusyType.TypeBusy > 0

 

      RETURN

END
go

