CREATE VIEW [V_oms_ParamNorm] AS SELECT 
[hDED].[ParamNormID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[rf_sc_AgeRangeID] as [rf_sc_AgeRangeID], 
[jT_oms_sc_AgeRange].[V_Range] as [SILENT_rf_sc_AgeRangeID], 
[hDED].[rf_UnitID] as [rf_UnitID], 
[jT_oms_Unit].[Name] as [SILENT_rf_UnitID], 
[hDED].[rf_ParamID] as [rf_ParamID], 
[jT_oms_Param].[Name] as [SILENT_rf_ParamID], 
[hDED].[NormMin] as [NormMin], 
[hDED].[NormMax] as [NormMax], 
[hDED].[Norm] as [Norm], 
[hDED].[Flags] as [Flags], 
[hDED].[GuidParamNorm] as [GuidParamNorm]
FROM [oms_ParamNorm] as [hDED]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
INNER JOIN [V_oms_sc_AgeRange] as [jT_oms_sc_AgeRange] on [jT_oms_sc_AgeRange].[sc_AgeRangeID] = [hDED].[rf_sc_AgeRangeID]
INNER JOIN [oms_Unit] as [jT_oms_Unit] on [jT_oms_Unit].[UnitID] = [hDED].[rf_UnitID]
INNER JOIN [oms_Param] as [jT_oms_Param] on [jT_oms_Param].[ParamID] = [hDED].[rf_ParamID]
go

