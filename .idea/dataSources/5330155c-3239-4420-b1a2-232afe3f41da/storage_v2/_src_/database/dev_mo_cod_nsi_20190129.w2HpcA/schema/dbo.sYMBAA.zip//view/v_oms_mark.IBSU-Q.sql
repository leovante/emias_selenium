CREATE VIEW [V_oms_Mark] AS SELECT 
[hDED].[MarkID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ProjectID] as [rf_ProjectID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Flag] as [Flag], 
[hDED].[Date_E] as [Date_E]
FROM [oms_Mark] as [hDED]
go

