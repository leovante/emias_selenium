CREATE VIEW [V_dd_DDFinancialReport] AS SELECT 
[hDED].[DDFinancialReportID], [hDED].[x_Edition], [hDED].[x_Status], 
(jT_dd_DDNormCost.Summa * NumberByPlan) as [V_SummByPlan], 
(jT_dd_DDNormCost.Summa*NumberInReestrs) as [V_LPUPayment], 
[jT_dd_DDNormCost].[Summa] as [V_Summa], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[hDED].[rf_DDNormCostID] as [rf_DDNormCostID], 
[jT_dd_DDNormCost].[Summa] as [SILENT_rf_DDNormCostID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[NumberByPlan] as [NumberByPlan], 
[hDED].[Balance] as [Balance], 
[hDED].[SubsidyFromFOMS] as [SubsidyFromFOMS], 
[hDED].[SubsidyOther] as [SubsidyOther], 
[hDED].[NoPurposeFromLPU] as [NoPurposeFromLPU], 
[hDED].[NumberInReestrs] as [NumberInReestrs]
FROM [dd_DDFinancialReport] as [hDED]
INNER JOIN [dd_DDNormCost] as [jT_dd_DDNormCost] on [jT_dd_DDNormCost].[DDNormCostID] = [hDED].[rf_DDNormCostID]
go

