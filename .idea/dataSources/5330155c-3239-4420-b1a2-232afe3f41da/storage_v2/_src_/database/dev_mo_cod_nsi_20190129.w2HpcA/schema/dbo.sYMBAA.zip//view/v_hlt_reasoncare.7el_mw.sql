CREATE VIEW [V_hlt_ReasonCare] AS SELECT 
[hDED].[ReasonCareID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[COD] as [COD], 
[hDED].[NAME] as [NAME], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_ReasonCare] as [hDED]
go

