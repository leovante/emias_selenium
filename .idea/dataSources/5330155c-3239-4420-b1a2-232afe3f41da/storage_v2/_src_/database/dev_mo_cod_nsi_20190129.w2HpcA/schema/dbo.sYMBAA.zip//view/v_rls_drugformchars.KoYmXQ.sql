CREATE VIEW [V_rls_DrugFormChars] AS SELECT 
[hDED].[DrugFormCharsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[FullName] as [FullName], 
[hDED].[UID] as [UID], 
[hDED].[ShortName] as [ShortName], 
[hDED].[Code] as [Code]
FROM [rls_DrugFormChars] as [hDED]
go

