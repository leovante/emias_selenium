CREATE VIEW [V_rls_Okpd_v1] AS SELECT 
[hDED].[Okpd_v1ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[CodeRls] as [CodeRls]
FROM [rls_Okpd_v1] as [hDED]
go

