CREATE VIEW [V_oms_ParamValue] AS SELECT 
[hDED].[ParamValueID], [hDED].[x_Edition], [hDED].[x_Status], 
(((select FIO from x_User where UserId = MedUserID))) as [V_UserFIO], 
[jT_oms_ParamVar].[rf_ParamID] as [V_rf_ParamID], 
[hDED].[rf_ParamVarID] as [rf_ParamVarID], 
[jT_oms_ParamVar].[Code] as [SILENT_rf_ParamVarID], 
[hDED].[rf_ParamID] as [rf_ParamID], 
[jT_oms_Param].[Name] as [SILENT_rf_ParamID], 
[hDED].[rf_mn_PersonID] as [rf_mn_PersonID], 
[jT_oms_mn_Person].[V_FIO] as [SILENT_rf_mn_PersonID], 
[hDED].[rf_mn_DocLPUID] as [rf_mn_DocLPUID], 
[jT_oms_mn_DocLPU].[Name] as [SILENT_rf_mn_DocLPUID], 
[hDED].[Value] as [Value], 
[hDED].[Date] as [Date], 
[hDED].[GUIDParamValue] as [GUIDParamValue], 
[hDED].[MedUserID] as [MedUserID], 
[hDED].[DocGUID] as [DocGUID], 
[hDED].[PatientGUID] as [PatientGUID], 
[hDED].[Flags] as [Flags], 
[hDED].[DocumentGUID] as [DocumentGUID], 
[hDED].[DocumentMetaDataGuid] as [DocumentMetaDataGuid]
FROM [oms_ParamValue] as [hDED]
INNER JOIN [oms_ParamVar] as [jT_oms_ParamVar] on [jT_oms_ParamVar].[ParamVarID] = [hDED].[rf_ParamVarID]
INNER JOIN [oms_Param] as [jT_oms_Param] on [jT_oms_Param].[ParamID] = [hDED].[rf_ParamID]
INNER JOIN [V_oms_mn_Person] as [jT_oms_mn_Person] on [jT_oms_mn_Person].[mn_PersonID] = [hDED].[rf_mn_PersonID]
INNER JOIN [oms_mn_DocLPU] as [jT_oms_mn_DocLPU] on [jT_oms_mn_DocLPU].[mn_DocLPUID] = [hDED].[rf_mn_DocLPUID]
go

