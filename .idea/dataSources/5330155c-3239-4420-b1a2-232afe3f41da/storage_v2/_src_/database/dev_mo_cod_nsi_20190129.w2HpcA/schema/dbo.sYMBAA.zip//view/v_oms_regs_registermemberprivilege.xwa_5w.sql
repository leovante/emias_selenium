CREATE VIEW [V_oms_regs_RegisterMemberPrivilege] AS SELECT 
[hDED].[regs_RegisterMemberPrivilegeID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_KATL].[C_KATL] as [V_C_KATL], 
[jT_oms_MKB].[DS] as [V_DS], 
[jT_oms_MKB].[NAME] as [V_NAME], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_regs_RegisterMemberID] as [rf_regs_RegisterMemberID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[DateCreated] as [DateCreated], 
[hDED].[DateEdit] as [DateEdit], 
[hDED].[DateDelete] as [DateDelete], 
[hDED].[Actual] as [Actual], 
[hDED].[Approved] as [Approved]
FROM [oms_regs_RegisterMemberPrivilege] as [hDED]
INNER JOIN [oms_KATL] as [jT_oms_KATL] on [jT_oms_KATL].[KATLID] = [hDED].[rf_KATLID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
go

