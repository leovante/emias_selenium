CREATE VIEW [V_hlt_INV] AS SELECT 
[hDED].[INVID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[COD] as [COD], 
[hDED].[NAME] as [NAME], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_INV] as [hDED]
go

