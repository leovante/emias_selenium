CREATE VIEW [V_stt_ReactionType] AS SELECT 
[hDED].[ReactionTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_ReactionType] as [hDED]
go

