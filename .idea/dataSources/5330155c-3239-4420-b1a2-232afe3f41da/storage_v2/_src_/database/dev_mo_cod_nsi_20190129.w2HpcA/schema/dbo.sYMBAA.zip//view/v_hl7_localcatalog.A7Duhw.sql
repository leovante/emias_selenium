CREATE VIEW [V_hl7_LocalCatalog] AS SELECT 
[hDED].[LocalCatalogID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_CatalogUGUID] as [rf_CatalogUGUID], 
[hDED].[DtdName] as [DtdName], 
[hDED].[DTDGuid] as [DTDGuid]
FROM [hl7_LocalCatalog] as [hDED]
go

