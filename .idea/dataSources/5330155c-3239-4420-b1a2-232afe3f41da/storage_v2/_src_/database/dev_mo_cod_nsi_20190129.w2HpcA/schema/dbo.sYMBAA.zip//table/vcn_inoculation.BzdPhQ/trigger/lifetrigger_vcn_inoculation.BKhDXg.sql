CREATE TRIGGER [LifeTrigger_vcn_Inoculation] ON [vcn_Inoculation] FOR DELETE,INSERT,UPDATE
AS 

SET NOCOUNT ON;

DECLARE @userId INT
DECLARE @seanceId INT 

DECLARE @docTypeId INT 
DECLARE @CURDATE DATETIME


declare @app varchar(50)
declare @index1 int
declare @index2 int


/* @userId, @seanceId */

SET @userId = 0
SET @seanceId = 0

EXEC [GetMalibuContext] @seanceId = @seanceId OUTPUT, @userId = @userId OUTPUT

/* @docTypeId */

SET @CURDATE = getdate()

SET @docTypeId = 0

SELECT TOP 1 @docTypeId = [DocTypeDefID], @seanceId=case WHEN [x_STDO].[HostID] IS NULL THEN @seanceId ELSE 0 END
FROM [x_DocTypeDef] left join [x_STDO] on [x_DocTypeDef].[GUID] = [x_STDO].[DocTypeDef] 
WHERE [HeadTable] = 'vcn_Inoculation'

/* action type */

DECLARE @DEL BIT
DECLARE @INS BIT 

DECLARE @action CHAR(1)


SET @DEL = 0
SET @INS = 0


IF EXISTS (SELECT TOP 1 1 FROM DELETED) SET @DEL=1
IF EXISTS (SELECT TOP 1 1 FROM INSERTED) SET @INS = 1 

IF @INS = 1 AND @DEL = 1 SET @ACTION = 'u'
IF @INS = 1 AND @DEL = 0 SET @ACTION = 'i'
IF @INS = 0 AND @DEL = 1 SET @ACTION = 'd'


IF @ACTION = 'd'
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [InoculationID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM deleted;

	INSERT INTO Life_vcn_Inoculation([InoculationID],[AgeSelector],[CancelDate],[CancelUserName],[ControlNumber],[DateExecute],[DateExecuteSign],[DateME],[DatePurpose],[DateResult],[DateResultSign],[ExecuteDose],[GlobalReaction],[Hyperaemia],[Info],[InoculationGuid],[Age],[InoculationResult],[isExecuted],[isExecuteSigned],[isPurposed],[isPurposeSigned],[isResult],[isResultSigned],[LocalReaction],[LPUExecute],[LPUPurpose],[LPUResult],[PapSize],[PurposeDose],[Result],[ResultInfo],[rf_CancelUserID],[rf_ExecuteDLSID],[rf_ExecuteDocPRVDID],[rf_ExecuteInjectionTypeID],[rf_ExecuteLPUID],[rf_ExecuteVaccineID],[rf_GlobalReactionID],[rf_InoculationCardID],[rf_LocalReactionID],[rf_LPUDoctorID],[rf_MedicalExemptionID],[rf_MEReasonID],[rf_PurposeDLSID],[rf_PurposeDocPRVDID],[rf_PurposeInjectionTypeID],[rf_PurposeLPUID],[rf_PurposeVaccineID],[rf_ReasonID],[rf_ResultDocPRVDID],[rf_ResultID],[rf_ResultLPUID],[rf_StatusID],[rf_TAPID],[rf_VaccinationGroupID],[rf_VaccinationTypeID],[rf_VaccineSeriesID],[Scar],[Series],[VaccinationNumber],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [InoculationID],[AgeSelector],[CancelDate],[CancelUserName],[ControlNumber],[DateExecute],[DateExecuteSign],[DateME],[DatePurpose],[DateResult],[DateResultSign],[ExecuteDose],[GlobalReaction],[Hyperaemia],[Info],[InoculationGuid],[Age],[InoculationResult],[isExecuted],[isExecuteSigned],[isPurposed],[isPurposeSigned],[isResult],[isResultSigned],[LocalReaction],[LPUExecute],[LPUPurpose],[LPUResult],[PapSize],[PurposeDose],[Result],[ResultInfo],[rf_CancelUserID],[rf_ExecuteDLSID],[rf_ExecuteDocPRVDID],[rf_ExecuteInjectionTypeID],[rf_ExecuteLPUID],[rf_ExecuteVaccineID],[rf_GlobalReactionID],[rf_InoculationCardID],[rf_LocalReactionID],[rf_LPUDoctorID],[rf_MedicalExemptionID],[rf_MEReasonID],[rf_PurposeDLSID],[rf_PurposeDocPRVDID],[rf_PurposeInjectionTypeID],[rf_PurposeLPUID],[rf_PurposeVaccineID],[rf_ReasonID],[rf_ResultDocPRVDID],[rf_ResultID],[rf_ResultLPUID],[rf_StatusID],[rf_TAPID],[rf_VaccinationGroupID],[rf_VaccinationTypeID],[rf_VaccineSeriesID],[Scar],[Series],[VaccinationNumber],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM deleted;
END;
ELSE
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [InoculationID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM inserted;

	INSERT INTO Life_vcn_Inoculation([InoculationID],[AgeSelector],[CancelDate],[CancelUserName],[ControlNumber],[DateExecute],[DateExecuteSign],[DateME],[DatePurpose],[DateResult],[DateResultSign],[ExecuteDose],[GlobalReaction],[Hyperaemia],[Info],[InoculationGuid],[Age],[InoculationResult],[isExecuted],[isExecuteSigned],[isPurposed],[isPurposeSigned],[isResult],[isResultSigned],[LocalReaction],[LPUExecute],[LPUPurpose],[LPUResult],[PapSize],[PurposeDose],[Result],[ResultInfo],[rf_CancelUserID],[rf_ExecuteDLSID],[rf_ExecuteDocPRVDID],[rf_ExecuteInjectionTypeID],[rf_ExecuteLPUID],[rf_ExecuteVaccineID],[rf_GlobalReactionID],[rf_InoculationCardID],[rf_LocalReactionID],[rf_LPUDoctorID],[rf_MedicalExemptionID],[rf_MEReasonID],[rf_PurposeDLSID],[rf_PurposeDocPRVDID],[rf_PurposeInjectionTypeID],[rf_PurposeLPUID],[rf_PurposeVaccineID],[rf_ReasonID],[rf_ResultDocPRVDID],[rf_ResultID],[rf_ResultLPUID],[rf_StatusID],[rf_TAPID],[rf_VaccinationGroupID],[rf_VaccinationTypeID],[rf_VaccineSeriesID],[Scar],[Series],[VaccinationNumber],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [InoculationID],[AgeSelector],[CancelDate],[CancelUserName],[ControlNumber],[DateExecute],[DateExecuteSign],[DateME],[DatePurpose],[DateResult],[DateResultSign],[ExecuteDose],[GlobalReaction],[Hyperaemia],[Info],[InoculationGuid],[Age],[InoculationResult],[isExecuted],[isExecuteSigned],[isPurposed],[isPurposeSigned],[isResult],[isResultSigned],[LocalReaction],[LPUExecute],[LPUPurpose],[LPUResult],[PapSize],[PurposeDose],[Result],[ResultInfo],[rf_CancelUserID],[rf_ExecuteDLSID],[rf_ExecuteDocPRVDID],[rf_ExecuteInjectionTypeID],[rf_ExecuteLPUID],[rf_ExecuteVaccineID],[rf_GlobalReactionID],[rf_InoculationCardID],[rf_LocalReactionID],[rf_LPUDoctorID],[rf_MedicalExemptionID],[rf_MEReasonID],[rf_PurposeDLSID],[rf_PurposeDocPRVDID],[rf_PurposeInjectionTypeID],[rf_PurposeLPUID],[rf_PurposeVaccineID],[rf_ReasonID],[rf_ResultDocPRVDID],[rf_ResultID],[rf_ResultLPUID],[rf_StatusID],[rf_TAPID],[rf_VaccinationGroupID],[rf_VaccinationTypeID],[rf_VaccineSeriesID],[Scar],[Series],[VaccinationNumber],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM inserted;
END; 

SET NOCOUNT OFF;


go

