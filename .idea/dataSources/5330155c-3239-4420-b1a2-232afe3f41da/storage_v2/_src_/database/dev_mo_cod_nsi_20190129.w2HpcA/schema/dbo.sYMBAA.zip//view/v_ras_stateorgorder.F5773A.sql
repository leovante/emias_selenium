CREATE VIEW [V_ras_StateOrgOrder] AS SELECT 
[hDED].[StateOrgOrderID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note]
FROM [ras_StateOrgOrder] as [hDED]
go

