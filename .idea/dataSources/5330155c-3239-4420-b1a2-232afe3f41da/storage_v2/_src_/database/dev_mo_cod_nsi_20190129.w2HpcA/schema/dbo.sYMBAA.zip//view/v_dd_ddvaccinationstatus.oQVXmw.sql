CREATE VIEW [V_dd_DDVaccinationStatus] AS SELECT 
[hDED].[DDVaccinationStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDVaccinationStatus] as [hDED]
go

