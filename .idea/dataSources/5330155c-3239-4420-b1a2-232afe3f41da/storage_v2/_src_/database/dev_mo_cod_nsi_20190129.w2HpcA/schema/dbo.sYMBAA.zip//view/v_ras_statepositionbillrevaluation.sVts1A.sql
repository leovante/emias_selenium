CREATE VIEW [V_ras_StatePositionBillRevaluation] AS SELECT 
[hDED].[StatePositionBillRevaluationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Cod] as [Cod], 
[hDED].[Name] as [Name]
FROM [ras_StatePositionBillRevaluation] as [hDED]
go

