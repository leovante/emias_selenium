CREATE VIEW [V_oms_SMFieldCondition] AS SELECT 
[hDED].[SMFieldConditionID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_SMCriterion].[V_IDVID] as [V_V_IDVID], 
[jT_oms_SMCriterion].[SMCriterionCode] as [V_SMCriterionCode], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[jT_oms_SMCriterion].[SMCriterionCaption] as [SILENT_rf_SMCriterionID], 
[hDED].[MainTable] as [MainTable], 
[hDED].[MainField] as [MainField], 
[hDED].[RefTable] as [RefTable], 
[hDED].[RefField] as [RefField], 
[hDED].[Query] as [Query], 
[hDED].[Mask] as [Mask], 
[hDED].[IsExist] as [IsExist], 
[hDED].[IsActual] as [IsActual], 
[hDED].[FieldActual] as [FieldActual], 
[hDED].[Rem] as [Rem], 
[hDED].[Code] as [Code], 
[hDED].[GuidSMFieldCondition] as [GuidSMFieldCondition], 
[hDED].[IM_POL] as [IM_POL], 
[hDED].[BAS_EL] as [BAS_EL]
FROM [oms_SMFieldCondition] as [hDED]
INNER JOIN [V_oms_SMCriterion] as [jT_oms_SMCriterion] on [jT_oms_SMCriterion].[SMCriterionID] = [hDED].[rf_SMCriterionID]
go

