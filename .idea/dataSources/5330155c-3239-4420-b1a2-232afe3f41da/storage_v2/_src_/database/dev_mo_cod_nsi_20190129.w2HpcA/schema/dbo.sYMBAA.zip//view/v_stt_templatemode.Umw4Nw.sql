CREATE VIEW [V_stt_TemplateMode] AS SELECT 
[hDED].[TemplateModeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[ModeName] as [ModeName]
FROM [stt_TemplateMode] as [hDED]
go

