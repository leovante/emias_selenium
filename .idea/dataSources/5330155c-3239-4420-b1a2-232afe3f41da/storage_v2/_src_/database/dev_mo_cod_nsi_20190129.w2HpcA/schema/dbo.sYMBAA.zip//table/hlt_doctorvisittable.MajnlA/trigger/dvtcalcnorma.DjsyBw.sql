CREATE TRIGGER [dbo].[dvtCalcNorma] 
   ON  [dbo].[hlt_DoctorVisitTable]
   AFTER INSERT, DELETE, UPDATE
AS 
BEGIN
 -- SET NOCOUNT ON added to prevent extra result sets from
 -- interfering with SELECT statements.
 SET NOCOUNT ON;

    -- Insert statements for trigger here

 UPDATE hlt_DoctorTimeTable 
  SET UsedUE = dtt.UsedUE + i.NormaUE
 FROM hlt_DoctorTimeTable dtt
  INNER JOIN inserted i
 ON i.rf_DoctorTimeTableID = dtt.DoctorTimeTableID

 UPDATE hlt_DoctorTimeTable
  SET UsedUE = dtt.UsedUE - d.NormaUE
 FROM hlt_DoctorTimeTable dtt
  INNER JOIN deleted d
 ON d.rf_DoctorTimeTableID = dtt.DoctorTimeTableID
END
go

