CREATE VIEW [V_ras_StatePositionPosting] AS SELECT 
[hDED].[StatePositionPostingID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [ras_StatePositionPosting] as [hDED]
go

