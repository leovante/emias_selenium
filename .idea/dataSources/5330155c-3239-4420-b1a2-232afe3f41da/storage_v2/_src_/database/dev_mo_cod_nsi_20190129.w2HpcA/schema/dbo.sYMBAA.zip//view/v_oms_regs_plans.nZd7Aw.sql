CREATE VIEW [V_oms_regs_Plans] AS SELECT 
[hDED].[regs_PlansID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_RegisterID] as [rf_RegisterID], 
[hDED].[Targets] as [Targets]
FROM [oms_regs_Plans] as [hDED]
go

