CREATE VIEW [V_rls_DrugPack] AS SELECT 
[hDED].[DrugPackID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[Name] as [Name], 
[hDED].[UID] as [UID], 
[hDED].[FullName] as [FullName], 
[hDED].[Code] as [Code]
FROM [rls_DrugPack] as [hDED]
go

