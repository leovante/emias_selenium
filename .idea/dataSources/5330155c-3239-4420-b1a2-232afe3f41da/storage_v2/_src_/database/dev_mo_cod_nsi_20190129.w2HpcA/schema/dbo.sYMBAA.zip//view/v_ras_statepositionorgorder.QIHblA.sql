CREATE VIEW [V_ras_StatePositionOrgOrder] AS SELECT 
[hDED].[StatePositionOrgOrderID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note]
FROM [ras_StatePositionOrgOrder] as [hDED]
go

