CREATE VIEW [V_dd_ResultTypeValue] AS SELECT 
[hDED].[ResultTypeValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_dd_ResultType].[V_Name] as [V_V_Name], 
[jT_dd_ResultType].[Name] as [V_Name], 
[hDED].[rf_HeathGroupUGUID] as [rf_HeathGroupUGUID], 
[hDED].[rf_SportGroupGUID] as [rf_SportGroupGUID], 
[hDED].[rf_ResultTypeGUID] as [rf_ResultTypeGUID], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID]
FROM [dd_ResultTypeValue] as [hDED]
INNER JOIN [V_dd_ResultType] as [jT_dd_ResultType] on [jT_dd_ResultType].[UGUID] = [hDED].[rf_ResultTypeGUID]
go

