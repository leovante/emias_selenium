CREATE VIEW [V_stt_PurposeLS] AS SELECT 
[hDED].[PurposeLSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TypePackingID] as [rf_TypePackingID], 
[jT_stt_TypePacking].[Name] as [SILENT_rf_TypePackingID], 
[hDED].[Name] as [Name], 
[hDED].[CodeRAS] as [CodeRAS], 
[hDED].[flags] as [flags], 
[hDED].[UGUID] as [UGUID]
FROM [stt_PurposeLS] as [hDED]
INNER JOIN [stt_TypePacking] as [jT_stt_TypePacking] on [jT_stt_TypePacking].[TypePackingID] = [hDED].[rf_TypePackingID]
go

