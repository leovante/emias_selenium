CREATE VIEW [V_ras_StateDemand] AS SELECT 
[hDED].[StateDemandID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note]
FROM [ras_StateDemand] as [hDED]
go

