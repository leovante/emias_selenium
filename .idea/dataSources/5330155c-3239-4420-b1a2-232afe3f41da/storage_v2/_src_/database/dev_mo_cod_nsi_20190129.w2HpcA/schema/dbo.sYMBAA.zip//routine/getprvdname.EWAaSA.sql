
create FUNCTION [dbo].[GetPRVDName] (@Field varchar(50))  
RETURNS varchar(150)   AS  
BEGIN 
return (select top 1 NAME from  oms_PRVD where C_PRVD=@Field and date_E>getdate())
END
go

