CREATE VIEW [V_oms_DemandForTender] AS SELECT 
[hDED].[DemandForTenderID], [hDED].[x_Edition], [hDED].[x_Status], 
(((convert(decimal(18,3),case when convert(decimal(18,3), jT_oms_CLS.Koeff)>0 then DemandCount/convert(decimal(18,3), jT_oms_CLS.Koeff) else 0 end) ))) as [V_CountUp], 
[jT_oms_CLS].[Koeff] as [V_Koeff], 
[hDED].[rf_LSID] as [rf_LSID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_APUID] as [rf_APUID], 
[hDED].[rf_CLSID] as [rf_CLSID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[hDED].[rf_ProtokolID] as [rf_ProtokolID], 
[jT_oms_Protokol].[Num] as [SILENT_rf_ProtokolID], 
[hDED].[rf_ProtokolPosID] as [rf_ProtokolPosID], 
[jT_oms_ProtokolPos].[rf_LSID] as [SILENT_rf_ProtokolPosID], 
[hDED].[LotGuid] as [LotGuid], 
[hDED].[DemandCount] as [DemandCount], 
[hDED].[Name1] as [Name1], 
[hDED].[Name2] as [Name2], 
[hDED].[DemandCountS] as [DemandCountS]
FROM [oms_DemandForTender] as [hDED]
INNER JOIN [oms_CLS] as [jT_oms_CLS] on [jT_oms_CLS].[CLSID] = [hDED].[rf_CLSID]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
INNER JOIN [oms_Protokol] as [jT_oms_Protokol] on [jT_oms_Protokol].[ProtokolID] = [hDED].[rf_ProtokolID]
INNER JOIN [oms_ProtokolPos] as [jT_oms_ProtokolPos] on [jT_oms_ProtokolPos].[ProtokolPosID] = [hDED].[rf_ProtokolPosID]
go

