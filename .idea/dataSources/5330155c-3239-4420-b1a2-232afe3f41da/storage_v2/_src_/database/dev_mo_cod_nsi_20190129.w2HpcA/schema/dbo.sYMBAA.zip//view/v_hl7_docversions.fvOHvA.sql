CREATE VIEW [V_hl7_DocVersions] AS SELECT 
[hDED].[DocVersionsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[UGUID] as [UGUID], 
[hDED].[OID] as [OID], 
[hDED].[DateLastChange] as [DateLastChange], 
[hDED].[Version] as [Version]
FROM [hl7_DocVersions] as [hDED]
go

