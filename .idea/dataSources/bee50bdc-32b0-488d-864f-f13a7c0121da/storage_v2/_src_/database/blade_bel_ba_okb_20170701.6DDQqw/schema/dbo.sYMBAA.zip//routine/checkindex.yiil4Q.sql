-- ================================================
-- Процедура создает индексы
-- ================================================
-- =============================================
-- Author:		Татьяна Абаньшина
-- Create date: 26.05/2008
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[CheckIndex] 
(
	@index     nvarchar(50), -- индекс
	@tab       nvarchar(50), -- имя таблицы
	@column    nvarchar(50) -- имя колонки
 )
AS
BEGIN
IF EXISTS (select * from       sys.index_columns k 
inner join sys.indexes       i  on i.object_ID  = k.object_ID  and i.index_id = k.index_id
inner join sys.all_objects   o  on k.object_ID  = o.object_ID 
inner join sys.columns       kl on kl.object_ID = o.object_ID  and kl.column_id = k.column_id
where o.Name =@tab and i.Name = @index and kl.name = @column) return

IF EXISTS (select * from       sys.index_columns k 
inner join sys.indexes       i  on i.object_ID  = k.object_ID  and i.index_id = k.index_id
inner join sys.all_objects   o  on k.object_ID  = o.object_ID 
inner join sys.columns       kl on kl.object_ID = o.object_ID  and kl.column_id = k.column_id
where o.Name =@tab and i.Name = @index ) begin
declare @drIndex nvarchar(max) 
set @drIndex = 'drop index '+@tab+'.'+@index;
exec sp_executesql @drIndex;
end

declare @sql nvarchar(max)
set @sql = 'CREATE NONCLUSTERED INDEX ['+@index;
set @sql=  @sql+'] ON [dbo].['+@tab;
set @sql = @sql+'](	['+@column;
set @sql = @sql+'] ASC )WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY] ';
exec sp_executesql @sql;
END


go

