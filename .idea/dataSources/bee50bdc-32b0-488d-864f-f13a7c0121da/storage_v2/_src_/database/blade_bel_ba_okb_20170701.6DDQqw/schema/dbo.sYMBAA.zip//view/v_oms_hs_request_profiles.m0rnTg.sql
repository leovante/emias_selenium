CREATE VIEW [V_oms_hs_request_profiles] AS SELECT 
[hDED].[hs_request_profilesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_hs_request_bfID] as [rf_hs_request_bfID], 
[jT_oms_hs_request_bf].[request_bf_ext_id] as [SILENT_rf_hs_request_bfID], 
[hDED].[rf_BedProfileID] as [rf_BedProfileID], 
[hDED].[old_value] as [old_value], 
[hDED].[new_value] as [new_value]
FROM [oms_hs_request_profiles] as [hDED]
INNER JOIN [oms_hs_request_bf] as [jT_oms_hs_request_bf] on [jT_oms_hs_request_bf].[hs_request_bfID] = [hDED].[rf_hs_request_bfID]
go

