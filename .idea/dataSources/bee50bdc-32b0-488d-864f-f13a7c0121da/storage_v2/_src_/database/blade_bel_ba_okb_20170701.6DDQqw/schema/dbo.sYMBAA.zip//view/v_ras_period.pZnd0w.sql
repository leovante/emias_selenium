CREATE VIEW [V_ras_Period] AS SELECT 
[hDED].[PeriodID], [hDED].[HostPeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_StatePeriodID] as [rf_StatePeriodID], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [ras_Period] as [hDED]
go

