create view v_ras_StoredLsGroup as  select  sum(storedls.AllCount) AllCount ,sum(storedls.CurrentCount) CurrentCount,sum(storedls.Sum) Sum,sum(Reserve) Reserve,NomenclatureId,storedls.StoredId
from (
select
stls.rf_NomenclatureID NomenclatureId,
stls.rf_StoredId StoredId,
Count CurrentCount,
stls.CountAll AllCount,
isnull((Select sum(ras_Reserve.Count) col  from ras_reserve where rf_StateReserveID = 1  and count!=0  and rf_StoredLSID = stls.StoredLSID), 0)  Reserve,
stls.Price * stls.Count Sum
 from ras_Storedls stls
where stls.StoredLSID>0
 ) storedls
 group by storedls.NomenclatureId,storedls.StoredId
go

