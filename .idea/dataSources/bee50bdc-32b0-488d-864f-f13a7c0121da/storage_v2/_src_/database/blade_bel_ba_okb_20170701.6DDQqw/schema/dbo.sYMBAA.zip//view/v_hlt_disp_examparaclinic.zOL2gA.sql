CREATE VIEW [V_hlt_disp_ExamParaclinic] AS SELECT 
[hDED].[disp_ExamParaclinicID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ExamGuid] as [rf_ExamGuid], 
[jT_hlt_disp_Exam].[rf_ServiceGuid] as [SILENT_rf_ExamGuid], 
[hDED].[rf_LbrResearchGuid] as [rf_LbrResearchGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_ExamParaclinic] as [hDED]
INNER JOIN [hlt_disp_Exam] as [jT_hlt_disp_Exam] on [jT_hlt_disp_Exam].[Guid] = [hDED].[rf_ExamGuid]
go

