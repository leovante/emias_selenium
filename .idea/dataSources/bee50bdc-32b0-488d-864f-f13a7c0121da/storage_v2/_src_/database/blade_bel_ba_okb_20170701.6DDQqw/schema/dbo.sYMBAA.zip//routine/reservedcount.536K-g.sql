create function ReservedCount
(
	@StoredLSID int,
	@HostStoredLSID int
)
returns decimal(15,3)
as
begin
	declare @count decimal(15,3)
	set @count = isnull(
		(select sum([Count]) from ras_Reserve r 
		where (r.rf_StoredLSID = @StoredLSID and r.rf_StoredLSIDHost = @HostStoredLSID and 
			   rf_StateReserveID = 1)), 0)
	return @count
end
go

