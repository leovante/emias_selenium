CREATE VIEW [V_ras_Currency] AS SELECT 
[hDED].[CurrencyID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_Name] as [C_Name], 
[hDED].[Code] as [Code]
FROM [ras_Currency] as [hDED]
go

