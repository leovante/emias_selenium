
CREATE FUNCTION [dbo].[GetDateLastInv] (@Store int)
RETURNS datetime 
AS
BEGIN
	declare @USet int

	select @USet=isnull(
		(select isnull(ValueStr,1)from x_UserSettings u
			where u.Property='EnableGetLastInv'and u.OwnerGUID='00000000-0000-0000-0000-000000000000'),1)
	declare @dt datetime
	if @USet=1

	begin

		select @dt=max(date_B)
		from ras_Inventarisation inv
		INNER JOIN ras_Organisation as opr on 
			inv.rf_OrganisationID=opr.OrganisationID
		where 
			inv.InventarisationID>0 and
			inv.rf_StoreID=@Store 
			and rf_StateInvID = 20
	end
	else
	begin
		set @dt='1900-01-01'
	end

	RETURN @dt

END
go

