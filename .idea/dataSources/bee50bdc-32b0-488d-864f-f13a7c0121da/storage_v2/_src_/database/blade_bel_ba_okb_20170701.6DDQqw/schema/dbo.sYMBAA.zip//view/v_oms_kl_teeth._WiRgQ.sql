CREATE VIEW [V_oms_kl_Teeth] AS SELECT 
[hDED].[kl_TeethID], [hDED].[x_Edition], [hDED].[x_Status], 
((convert(varchar(2),Tooth))) as [V_Name], 
[hDED].[Tooth] as [Tooth], 
[hDED].[Occlusion] as [Occlusion], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Flags] as [Flags], 
[hDED].[GuidTeeth] as [GuidTeeth]
FROM [oms_kl_Teeth] as [hDED]
go

