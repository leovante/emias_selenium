CREATE VIEW [V_hlt_EquipmentOutage] AS SELECT 
[hDED].[EquipmentOutageID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_EquipmentID] as [rf_EquipmentID], 
[jT_hlt_Equipment].[Name] as [SILENT_rf_EquipmentID], 
[hDED].[rf_EquipmentOutageCauseID] as [rf_EquipmentOutageCauseID], 
[jT_hlt_EquipmentOutageCause].[Name] as [SILENT_rf_EquipmentOutageCauseID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Comment] as [Comment], 
[hDED].[Guid] as [Guid], 
[hDED].[Flags] as [Flags], 
[hDED].[DocumentUrl] as [DocumentUrl]
FROM [hlt_EquipmentOutage] as [hDED]
INNER JOIN [hlt_Equipment] as [jT_hlt_Equipment] on [jT_hlt_Equipment].[EquipmentID] = [hDED].[rf_EquipmentID]
INNER JOIN [hlt_EquipmentOutageCause] as [jT_hlt_EquipmentOutageCause] on [jT_hlt_EquipmentOutageCause].[EquipmentOutageCauseID] = [hDED].[rf_EquipmentOutageCauseID]
go

