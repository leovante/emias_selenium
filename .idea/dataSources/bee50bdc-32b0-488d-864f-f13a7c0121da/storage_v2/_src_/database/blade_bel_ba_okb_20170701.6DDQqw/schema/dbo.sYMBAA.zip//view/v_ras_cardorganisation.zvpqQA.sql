CREATE VIEW [V_ras_CardOrganisation] AS SELECT 
[hDED].[CardOrganisationID], [hDED].[HostCardOrganisationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_OrganisationIDHost] as [rf_OrganisationIDHost], 
[jT_ras_Organisation].[Name] as [SILENT_rf_OrganisationID], 
[hDED].[rf_StateCardOrganisationID] as [rf_StateCardOrganisationID], 
[jT_ras_StateCardOrganisation].[Name] as [SILENT_rf_StateCardOrganisationID], 
[hDED].[PostPeriod] as [PostPeriod], 
[hDED].[LastDeliveryDate] as [LastDeliveryDate], 
[hDED].[isActive] as [isActive], 
[hDED].[Organisation] as [Organisation], 
[hDED].[Priority] as [Priority], 
[hDED].[PrNZ] as [PrNZ]
FROM [ras_CardOrganisation] as [hDED]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationIDHost]
INNER JOIN [ras_StateCardOrganisation] as [jT_ras_StateCardOrganisation] on [jT_ras_StateCardOrganisation].[StateCardOrganisationID] = [hDED].[rf_StateCardOrganisationID]
go

