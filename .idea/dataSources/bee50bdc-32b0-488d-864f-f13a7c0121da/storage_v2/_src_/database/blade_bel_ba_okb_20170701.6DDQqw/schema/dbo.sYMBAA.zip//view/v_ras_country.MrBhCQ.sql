CREATE VIEW [V_ras_Country] AS SELECT 
[hDED].[CountryID], [hDED].[HostCountryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[SmallName] as [SmallName], 
[hDED].[BigName] as [BigName]
FROM [ras_Country] as [hDED]
go

