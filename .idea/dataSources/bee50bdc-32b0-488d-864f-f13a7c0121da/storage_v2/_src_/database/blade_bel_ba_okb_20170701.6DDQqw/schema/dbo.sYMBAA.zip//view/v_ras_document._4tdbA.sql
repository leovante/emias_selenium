

CREATE View [dbo].[V_ras_Document] As

Select  
  BillDocumentId as [Id],
  Date_fact as [Date],
  NUM as [Num],
  Sum as [Sum],
  Null as [StoreSourceId],
  rf_StoreID as [StoreDestinationId],
  rf_DocDescriptionID as [DocDescriptionId],
  ras_State.StateID as [StateDocumentId],
  ras_State.Name as [StateDocumentName]
From ras_BillDocument 
Inner Join ras_State On ras_BillDocument.rf_StateId = ras_State.StateId
Where BillDocumentID != 0

Union

Select
  PostingId as [Id],
  Date_fact as [Date],
  NUM as [Num],
  Sum as [Sum],
  Null as [StoreSourceId],
  rf_StoreID as [StoreDestinationId],
  rf_DocDescriptionID as [DocDescriptionId],
  ras_StatePosting.StatePostingID as [StateDocumentId],
  ras_StatePosting.Name as [StateDocumentName]
From ras_Posting
Inner Join ras_StatePosting On ras_Posting.rf_StatePostingId = ras_StatePosting.StatePostingId
Where PostingID != 0

Union

Select
  BillReturnProviderId as [Id],
  Date as [Date],
  NUM as [Num],
  Summa as [Sum],
  rf_StoreID as [StoreSourceId],
  Null as [StoreDestinationId],
  rf_DocDescriptionID as [DocDescriptionId],
  ras_StateBillRetProv.StateBillRetProvID as [StateDocumentId],
  ras_StateBillRetProv.Name as [StateDocumentName]
From ras_BillReturnProvider
Inner Join ras_StateBillRetProv On ras_BillReturnProvider.rf_StateBillRetProvID = ras_StateBillRetProv.StateBillRetProvId
Where BillReturnProviderID != 0

Union

Select
  BillShiftId as [Id],
  Date as [Date],
  NUM as [Num],
  Summa as [Sum],
  rf_StoreSourseID as [StoreSourceId],
  rf_StoreDestinationID as [StoreDestinationId],
  rf_DocDescriptionID as [DocDescriptionId],
  ras_StateBillShift.StateBillShiftID as [StateDocumentId],
  ras_StateBillShift.Name as [StateDocumentName]
From ras_BillShift
Inner Join ras_StateBillShift On ras_BillShift.rf_StateBillShiftID = ras_StateBillShift.StateBillShiftID
Where BillShiftID != 0

Union

Select
  WriteOffArticleId as [Id],
  Date as [Date],
  NUM as [Num],
  Summa as [Sum],
  rf_StoreID as [StoreSourceId],
  Null as [StoreDestinationId],
  rf_DocDescriptionID as [DocDescriptionId],
  ras_StateWriteOffArticle.StateWriteOffArticleID as [StateDocumentId],
  ras_StateWriteOffArticle.Name as [StateDocumentName]
From ras_WriteOffArticle
Inner Join ras_StateWriteOffArticle On ras_WriteOffArticle.rf_StateWriteOffArticleID = ras_StateWriteOffArticle.StateWriteOffArticleID
Where WriteOffArticleID != 0

Union

Select
  WriteOffPurposeListId as [Id],
  Date as [Date],
  NUM as [Num],
  Summa as [Sum],
  rf_StoreID as [StoreSourceId],
  Null as [StoreDestinationId],
  rf_DocDescriptionID as [DocDescriptionId],
  ras_StatePurposeList.StatePurposeListID as [StateDocumentId],
  ras_StatePurposeList.Name as [StateDocumentName]
From ras_WriteOffPurposeList
Inner Join ras_StatePurposeList On ras_WriteOffPurposeList.rf_StatePurposeListId = ras_StatePurposeList.StatePurposeListID
Where WriteOffPurposeListID != 0

Union
Select
  BillRequestId as [Id],
  DateCreate as [Date],
  Cast(Num as varchar) as [Num],
  Summa as [Sum],
  rf_StoreSourceID as [StoreSourceId],
  rf_StoreID as [StoreDestinationId],
  rf_DocDescriptionID as [DocDescriptionId],
  ras_StateRequest.StateRequestID as [StateDocumentId],
  ras_StateRequest.Name as [StateDocumentName]
From ras_BillRequest
Inner Join ras_StateRequest On ras_BillRequest.rf_StateRequestID = ras_StateRequest.StateRequestID
Where BillRequestID != 0

go

