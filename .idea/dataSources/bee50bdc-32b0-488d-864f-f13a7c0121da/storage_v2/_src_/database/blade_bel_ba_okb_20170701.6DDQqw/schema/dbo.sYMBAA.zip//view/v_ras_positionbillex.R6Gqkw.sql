CREATE VIEW [V_ras_PositionBillEx] AS SELECT 
[hDED].[PositionBillExID], [hDED].[HostPositionBillExID], [hDED].[x_Edition], [hDED].[x_Status], 
(ISNULL((SELECT top 1  TenderType_Name 
FROM oms_TenderType 
join ras_StoredLS on rf_TenderTypeID = TenderTypeID and hDed.rf_StoredLSID = ras_StoredLS.StoredLSID 
			  and hDed.rf_StoredLSIDHost = ras_StoredLS.HostStoredLSID),'')) as [V_TenderTypeName], 
((isnull((Select top 1 NUM from oms_tender where tenderID = [jT_ras_StoredLS].rf_tenderID ), '') )) as [V_TenderNum], 
(((isnull((Select top 1 name from ras_organisation where OrganisationID = [jT_ras_StoredLS].rf_organisationOwnerID), '') ))) as [V_Owner], 
(((isnull((Select top 1 Date_E from ras_Series where SeriesID = [jT_ras_StoredLS].rf_SeriesID), '1900-01-01') ))) as [V_ExpDate], 
((isnull((Select top 1 name from ras_subStore where SubstoreID = [jT_ras_StoredLS].rf_SubStoreID), '') )) as [V_SubStorePos], 
((isnull((Select top 1 cod_ras from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId ), '') )) as [V_COD_RAS], 
((isnull((Select top 1 name from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId), '') )) as [V_Nomenclature], 
(((isnull((Select top 1 NUM from ras_Series where SeriesID = [jT_ras_StoredLS].rf_SeriesID), '') ))) as [V_Series], 
((Select top 1 Name from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId)) as [V_StoredLS], 
((isnull((Select top 1 cod_ras from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId ), '') )) as [V_Cod_Nom], 
(ISNULL((select top 1 NAME_MNN from oms_MNName mnn 
join oms_LS ls on ls.rf_MNNameID=mnn.MNNameID 
join ras_Nomenclature nomenc on nomenc.rf_LSID=ls.LSID 
join ras_StoredLS sls on sls.rf_NomenclatureID = nomenc.NomenclatureID and hDed.rf_StoredLSID = sls.StoredLSID and hDed.rf_StoredLSIDHost = sls.HostStoredLSID),'')) as [V_MNName], 
[jT_ras_StoredLS].[Consigment] as [V_Consigment], 
[hDED].[rf_OrganisationByDemandID] as [rf_OrganisationByDemandID], 
[hDED].[rf_OrganisationByDemandIDHost] as [rf_OrganisationByDemandIDHost], 
[jT_ras_Organisation].[Name] as [SILENT_rf_OrganisationByDemandID], 
[hDED].[rf_NDSID] as [rf_NDSID], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_BillExtractedID] as [rf_BillExtractedID], 
[hDED].[rf_BillExtractedIDHost] as [rf_BillExtractedIDHost], 
[hDED].[rf_StateExPosBillID] as [rf_StateExPosBillID], 
[hDED].[rf_PositionStatusID] as [rf_PositionStatusID], 
[hDED].[rf_DeliveryCLSDateID] as [rf_DeliveryCLSDateID], 
[hDED].[rf_PositionOrderID] as [rf_PositionOrderID], 
[jT_ras_PositionOrder].[rf_NomenclatureID] as [SILENT_rf_PositionOrderID], 
[hDED].[NameLS] as [NameLS], 
[hDED].[Price] as [Price], 
[hDED].[Count] as [Count], 
[hDED].[Summa] as [Summa], 
[hDED].[SumNDS] as [SumNDS], 
[hDED].[PriceBase] as [PriceBase], 
[hDED].[PriceOPT] as [PriceOPT], 
[hDED].[Note] as [Note], 
[hDED].[Measure] as [Measure], 
[hDED].[MeasureCount] as [MeasureCount], 
[hDED].[FractionCount] as [FractionCount], 
[hDED].[DateOUT] as [DateOUT], 
[hDED].[Pr_Nadb] as [Pr_Nadb]
FROM [ras_PositionBillEx] as [hDED]
INNER JOIN [ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationByDemandID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationByDemandIDHost]
INNER JOIN [ras_PositionOrder] as [jT_ras_PositionOrder] on [jT_ras_PositionOrder].[PositionOrderID] = [hDED].[rf_PositionOrderID]
go

