CREATE VIEW [V_oms_onco_N002] AS SELECT 
[hDED].[onco_N002ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[ID_St] as [ID_St], 
[hDED].[DS_St] as [DS_St], 
[hDED].[KOD_St] as [KOD_St], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN002] as [GUIDN002]
FROM [oms_onco_N002] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
go

