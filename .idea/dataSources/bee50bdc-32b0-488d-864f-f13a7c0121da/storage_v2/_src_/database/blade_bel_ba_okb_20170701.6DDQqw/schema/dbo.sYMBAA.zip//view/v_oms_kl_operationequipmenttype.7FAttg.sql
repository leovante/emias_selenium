CREATE VIEW [V_oms_kl_OperationEquipmentType] AS SELECT 
[hDED].[kl_OperationEquipmentTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[GUIDOperationEType] as [GUIDOperationEType]
FROM [oms_kl_OperationEquipmentType] as [hDED]
go

