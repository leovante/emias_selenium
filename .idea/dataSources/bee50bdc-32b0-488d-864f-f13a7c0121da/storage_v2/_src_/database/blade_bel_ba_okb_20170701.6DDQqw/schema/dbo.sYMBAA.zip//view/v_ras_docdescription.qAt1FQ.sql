CREATE VIEW [V_ras_DocDescription] AS SELECT 
[hDED].[DocDescriptionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[NameTable] as [NameTable], 
[hDED].[NameType] as [NameType], 
[hDED].[MethodChange] as [MethodChange], 
[hDED].[NameFieldDate] as [NameFieldDate], 
[hDED].[NamePosition] as [NamePosition], 
[hDED].[NameFileldCount] as [NameFileldCount], 
[hDED].[isVerified] as [isVerified], 
[hDED].[StateDeleteDoc] as [StateDeleteDoc], 
[hDED].[StateDeletePos] as [StateDeletePos], 
[hDED].[Flag_use_storedLS] as [Flag_use_storedLS], 
[hDED].[Name_rf_State_Doc] as [Name_rf_State_Doc], 
[hDED].[Name_rf_State_Pos] as [Name_rf_State_Pos], 
[hDED].[PositionSumColumn] as [PositionSumColumn], 
[hDED].[Guid] as [Guid]
FROM [ras_DocDescription] as [hDED]
go

