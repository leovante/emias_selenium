CREATE VIEW [V_hlt_ReestrMHResult] AS SELECT 
[hDED].[ReestrMHResultID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrTAPMHID] as [rf_ReestrTAPMHID], 
[jT_hlt_ReestrTAPMH].[rf_TAPID] as [SILENT_rf_ReestrTAPMHID], 
[hDED].[rf_ReestrMHSMTAPID] as [rf_ReestrMHSMTAPID], 
[jT_hlt_ReestrMHSMTAP].[V_MedHelpDate] as [SILENT_rf_ReestrMHSMTAPID], 
[hDED].[Res_Name] as [Res_Name], 
[hDED].[ID_Rec] as [ID_Rec], 
[hDED].[N_Rec] as [N_Rec]
FROM [hlt_ReestrMHResult] as [hDED]
INNER JOIN [hlt_ReestrTAPMH] as [jT_hlt_ReestrTAPMH] on [jT_hlt_ReestrTAPMH].[ReestrTAPMHID] = [hDED].[rf_ReestrTAPMHID]
INNER JOIN [V_hlt_ReestrMHSMTAP] as [jT_hlt_ReestrMHSMTAP] on [jT_hlt_ReestrMHSMTAP].[ReestrMHSMTAPID] = [hDED].[rf_ReestrMHSMTAPID]
go

