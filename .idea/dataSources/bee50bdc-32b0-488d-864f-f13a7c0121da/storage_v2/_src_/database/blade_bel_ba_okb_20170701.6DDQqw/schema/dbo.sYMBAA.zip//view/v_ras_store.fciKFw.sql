CREATE VIEW [V_ras_Store] AS SELECT 
[hDED].[StoreID], [hDED].[HostStoreID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TypeDeliveryID] as [rf_TypeDeliveryID], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_OrganisationIDHost] as [rf_OrganisationIDHost], 
[hDED].[rf_ResponsibleID] as [rf_ResponsibleID], 
[hDED].[rf_ResponsibleIDHost] as [rf_ResponsibleIDHost], 
[jT_ras_Responsible].[V_FIO] as [SILENT_rf_ResponsibleID], 
[hDED].[rf_ParentStoreID] as [rf_ParentStoreID], 
[hDED].[rf_ParentStoreIDHost] as [rf_ParentStoreIDHost], 
[hDED].[StoreName] as [StoreName], 
[hDED].[Address] as [Address], 
[hDED].[Code] as [Code], 
[hDED].[isMain] as [isMain], 
[hDED].[PkuInvLastDate] as [PkuInvLastDate], 
[hDED].[GUID] as [GUID], 
[hDED].[isVirtual] as [isVirtual], 
[hDED].[CODE_OLD] as [CODE_OLD]
FROM [ras_Store] as [hDED]
INNER JOIN [V_ras_Responsible] as [jT_ras_Responsible] on [jT_ras_Responsible].[ResponsibleID] = [hDED].[rf_ResponsibleID] AND  [jT_ras_Responsible].[HostResponsibleID] = [hDED].[rf_ResponsibleIDHost]
go

