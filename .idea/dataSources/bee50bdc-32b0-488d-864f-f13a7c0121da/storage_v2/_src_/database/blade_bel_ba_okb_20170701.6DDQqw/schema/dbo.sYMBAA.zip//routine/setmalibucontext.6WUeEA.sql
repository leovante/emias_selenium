
-- =============================================
-- Author:		Semenyakin Dmitry
-- Create date: 05.03.2012
-- Description:	The function sets context_info for malibu triggers use
-- =============================================
CREATE PROCEDURE [dbo].[SetMalibuContext]
(	
	@seanceId int,
	@userId int	
)
AS
BEGIN

	DECLARE @temp bigint
	
	/* резервируем 32 бита так как пока используем System.Int32(int) */ 
	
	SET @temp = convert(bigint, @seanceId);
	
	/* сдвинули влево на 32 бита */ 	
	SET @temp = @temp * convert(bigint,Power(2, 30)) * 2 * 2; 
	
	/* в младшие 32 бита записали юзера*/
	SET @temp = @temp + @userId;
	
	/* именно столько говорится в документации по context_info() */
	DECLARE @res binary(16)
	
	SET @res = convert(binary(16), @temp)
	
	SET CONTEXT_INFO @res

END
go

