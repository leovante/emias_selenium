CREATE VIEW [V_hlt_atc_DeliveryPoint] AS SELECT 
[hDED].[atc_DeliveryPointID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Address] as [Address], 
[hDED].[WorkTime] as [WorkTime], 
[hDED].[DeliveryTime] as [DeliveryTime], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_atc_DeliveryPoint] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

