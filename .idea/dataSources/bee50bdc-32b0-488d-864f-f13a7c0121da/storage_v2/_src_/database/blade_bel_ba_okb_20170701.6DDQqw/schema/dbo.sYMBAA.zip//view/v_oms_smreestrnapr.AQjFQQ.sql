CREATE VIEW [V_oms_SMReestrNAPR] AS SELECT 
[hDED].[SMReestrNAPRID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[rf_SMreestrUslID] as [rf_SMreestrUslID], 
[hDED].[NAPR_DATE] as [NAPR_DATE], 
[hDED].[MET_ISSL] as [MET_ISSL], 
[hDED].[NAPR_V] as [NAPR_V], 
[hDED].[NAPR_USL] as [NAPR_USL]
FROM [oms_SMReestrNAPR] as [hDED]
go

