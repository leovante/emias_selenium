-- =============================================
-- Author:		<Абаньшина Татьяна>
-- Create date: <2010-02-02>
-- Description:	<Вставляет записи в таблицу oms_LS_FINL по вставленным ЛС, и вносит информацию в историю по oms_LS_Finl>								
-- =============================================
CREATE TRIGGER [dbo].[insert_LS_Finl]
   ON  [dbo].[oms_LS] 
   AFTER INSERT, UPDATE
AS 
BEGIN
	
	INSERT INTO [oms_LS_Finl]([rf_LSID],[rf_FinlID])
		select LSID,1 from inserted
        where LSID not in (select rf_LSID from oms_LS_Finl)


    INSERT INTO [x_ObjLife]([DocTypeDefID],[ObjID],[x_Edition],[EditionDt],[x_Status],[LastOperation],[UserID])
		select 177, Ls_FINLID,'1',getdate(),1,'i',1
		from oms_LS_Finl 
		inner join inserted t on rf_LSID = t.LSID
		where LS_FInlID<>0 and rf_FINLID ='1'
	--SET NOCOUNT ON;  
END

go

