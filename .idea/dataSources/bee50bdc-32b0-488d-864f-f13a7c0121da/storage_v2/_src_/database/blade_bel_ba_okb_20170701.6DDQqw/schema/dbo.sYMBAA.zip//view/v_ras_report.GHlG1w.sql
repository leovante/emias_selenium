CREATE VIEW [V_ras_Report] AS SELECT 
[hDED].[ReportID], [hDED].[HostReportID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_ras_Dogovor].[Date] as [V_DogovorDate], 
[jT_ras_Dogovor].[D_Name] as [V_DogovorName], 
[jT_ras_Store].[StoreName] as [V_Store], 
[hDED].[rf_OrganisationProviderID] as [rf_OrganisationProviderID], 
[hDED].[rf_OrganisationProviderIDHost] as [rf_OrganisationProviderIDHost], 
[hDED].[rf_OrganisationClientID] as [rf_OrganisationClientID], 
[hDED].[rf_OrganisationClientIDHost] as [rf_OrganisationClientIDHost], 
[hDED].[rf_DogovorID] as [rf_DogovorID], 
[hDED].[rf_DogovorIDHost] as [rf_DogovorIDHost], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[hDED].[rf_PeriodID] as [rf_PeriodID], 
[hDED].[rf_PeriodIDHost] as [rf_PeriodIDHost], 
[hDED].[rf_TypeReportID] as [rf_TypeReportID], 
[hDED].[rf_DocDescriptionID] as [rf_DocDescriptionID], 
[hDED].[rf_StateReportID] as [rf_StateReportID], 
[hDED].[Date] as [Date], 
[hDED].[PR_Reward] as [PR_Reward], 
[hDED].[Num] as [Num], 
[hDED].[V_TypeReport] as [V_TypeReport], 
[hDED].[Load_Send] as [Load_Send], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[DocGUID] as [DocGUID], 
[hDED].[isStorned] as [isStorned], 
[hDED].[TypePost] as [TypePost], 
[hDED].[Note] as [Note], 
[hDED].[Summa] as [Summa], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[FLAGS] as [FLAGS]
FROM [ras_Report] as [hDED]
INNER JOIN [ras_Dogovor] as [jT_ras_Dogovor] on [jT_ras_Dogovor].[DogovorID] = [hDED].[rf_DogovorID] AND  [jT_ras_Dogovor].[HostDogovorID] = [hDED].[rf_DogovorIDHost]
INNER JOIN [ras_Store] as [jT_ras_Store] on [jT_ras_Store].[StoreID] = [hDED].[rf_StoreID] AND  [jT_ras_Store].[HostStoreID] = [hDED].[rf_StoreIDHost]
go

