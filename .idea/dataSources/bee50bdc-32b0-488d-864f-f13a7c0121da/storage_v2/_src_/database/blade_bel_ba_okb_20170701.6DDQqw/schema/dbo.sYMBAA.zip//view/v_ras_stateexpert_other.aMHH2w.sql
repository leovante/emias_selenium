CREATE VIEW [V_ras_StateExpert_Other] AS SELECT 
[hDED].[StateExpert_OtherID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Action] as [Action]
FROM [ras_StateExpert_Other] as [hDED]
go

