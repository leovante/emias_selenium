




CREATE View [dbo].[V_ras_PositionDocument] As

Select  
  BillDocumentId as [DocumentId],
  Date_fact as [Date],
  NUM as [Num],
  Sum as [Sum],
  Null as [StoreSourceId],
  rf_StoreID as [StoreDestinationId],
  ras_BillDocument.rf_DocDescriptionID as [DocDescriptionId],
  ras_State.StateID as [StateDocumentId],
  ras_State.Name as [StateDocumentName],
  ----
  position.Count,
  position.rf_StateID as [StatePositionId],
  statePos.Name as [StatePositionName],
  position.PositionBillID as [Id],
  transactJoural.rf_StoredLSID as [StoredLsId]
From ras_BillDocument 
Inner Join ras_State On ras_BillDocument.rf_StateId = ras_State.StateId
inner join ras_PositionBill position on position.rf_BillDocumentID  = BillDocumentID
inner Join ras_State statePos On position.rf_StateId = statePos.StateId
inner join ras_TransactJournal transactJoural on transactJoural.PositionID = position.PositionBillID
Where BillDocumentID != 0 and transactJoural.rf_DocDescriptionID = 2

Union

Select
  PostingId as [DocumentId],
  Date_fact as [Date],
  NUM as [Num],
  Sum as [Sum],
  Null as [StoreSourceId],
  rf_StoreID as [StoreDestinationId],
  ras_Posting.rf_DocDescriptionID as [DocDescriptionId],
  ras_StatePosting.StatePostingID as [StateDocumentId],
  ras_StatePosting.Name as [StateDocumentName],
  ---
  position.Count,
  position.rf_StatePositionPostingID as [StatePositionId],
  statePos.Name as [StatePositionName],
  position.PositionPostingID as [Id],
  transactJoural.rf_StoredLSID as [StoredLsId]
From ras_Posting
Inner Join ras_StatePosting On ras_Posting.rf_StatePostingId = ras_StatePosting.StatePostingId
inner join ras_PositionPosting position on position.rf_PostingID = ras_Posting.PostingID
inner join ras_StatePositionPosting statePos on statePos.StatePositionPostingID = position.rf_StatePositionPostingID
inner join ras_TransactJournal transactJoural on transactJoural.PositionID = position.PositionPostingID
Where PostingID != 0 and transactJoural.rf_DocDescriptionID = 7

Union

Select
  BillReturnProviderId as [DocumentId],
  Date as [Date],
  NUM as [Num],
  ras_BillReturnProvider.Summa as [Sum],
  rf_StoreID as [StoreSourceId],
  Null as [StoreDestinationId],
  ras_BillReturnProvider.rf_DocDescriptionID as [DocDescriptionId],
  ras_StateBillRetProv.StateBillRetProvID as [StateDocumentId],
  ras_StateBillRetProv.Name as [StateDocumentName],
  ---
  position.Count,
  position.rf_StatePosBillReturnPrID as [StatePositionId],
  statePos.Name as [StatePositionName],
  position.PositionBillReturnPrID as [Id],
  transactJoural.rf_StoredLSID as [StoredLsId]
From ras_BillReturnProvider
Inner Join ras_StateBillRetProv On ras_BillReturnProvider.rf_StateBillRetProvID = ras_StateBillRetProv.StateBillRetProvId
inner join ras_PositionBillReturnPr position on position.rf_BillReturnProviderID = ras_BillReturnProvider.BillReturnProviderID
inner join ras_StatePosBillReturnPr statePos on statePos.StatePosBillReturnPrID = position.rf_StatePosBillReturnPrID
inner join ras_TransactJournal transactJoural on transactJoural.PositionID = position.PositionBillReturnPrID
Where BillReturnProviderID != 0 and transactJoural.rf_DocDescriptionID = 10

Union

Select
  BillShiftId as [DocumentId],
  Date as [Date],
  NUM as [Num],
  ras_BillShift.Summa as [Sum],
  rf_StoreSourseID as [StoreSourceId],
  rf_StoreDestinationID as [StoreDestinationId],
  ras_BillShift.rf_DocDescriptionID as [DocDescriptionId],
  ras_StateBillShift.StateBillShiftID as [StateDocumentId],
  ras_StateBillShift.Name as [StateDocumentName],
  ---
  position.Count,
  position.rf_StatePosBillIShiftID as [StatePositionId],
  statePos.Name as [StatePositionName],
  position.PositionBillShiftID as [Id],
  transactJoural.rf_StoredLSID as [StoredLsId]
From ras_BillShift
Inner Join ras_StateBillShift On ras_BillShift.rf_StateBillShiftID = ras_StateBillShift.StateBillShiftID
inner join ras_PositionBillShift position on position.PositionBillShiftID = ras_BillShift.BillShiftID
inner join ras_StatePosBillIShift statePos on statePos.StatePosBillIShiftID = position.rf_StatePosBillIShiftID
inner join ras_TransactJournal transactJoural on transactJoural.PositionID = position.PositionBillShiftID
Where BillShiftID != 0 and transactJoural.rf_DocDescriptionID = 5 

Union

Select
  WriteOffArticleId as [DocumentId],
  Date as [Date],
  NUM as [Num],
  ras_WriteOffArticle.Summa as [Sum],
  rf_StoreID as [StoreSourceId],
  Null as [StoreDestinationId],
  ras_WriteOffArticle.rf_DocDescriptionID as [DocDescriptionId],
  ras_StateWriteOffArticle.StateWriteOffArticleID as [StateDocumentId],
  ras_StateWriteOffArticle.Name as [StateDocumentName],
  ---
  position.Count,
  position.rf_StatePositionWriteOffArcticleID as [StatePositionId],
  statePos.Name as [StatePositionName],
  position.PositionWriteOffArticleID as [Id],
  transactJoural.rf_StoredLSID as [StoredLsId]
From ras_WriteOffArticle
Inner Join ras_StateWriteOffArticle On ras_WriteOffArticle.rf_StateWriteOffArticleID = ras_StateWriteOffArticle.StateWriteOffArticleID
inner join ras_PositionWriteOffArticle position on position.rf_WriteOffArticleID = ras_WriteOffArticle.WriteOffArticleID
inner join ras_StatePositionWriteOffArticle statePos on statePos.StatePositionWriteOffArticleID = position.rf_StatePositionWriteOffArcticleID
inner join ras_TransactJournal transactJoural on transactJoural.PositionID = position.PositionWriteOffArticleID
Where WriteOffArticleID != 0 and transactJoural.rf_DocDescriptionID = 6
Union

Select
  WriteOffPurposeListId as [DocumentId],
  ras_WriteOffPurposeList.Date as [Date],
  NUM as [Num],
  ras_WriteOffPurposeList.Summa as [Sum],
  rf_StoreID as [StoreSourceId],
  Null as [StoreDestinationId],
  ras_WriteOffPurposeList.rf_DocDescriptionID as [DocDescriptionId],
  ras_StatePurposeList.StatePurposeListID as [StateDocumentId],
  ras_StatePurposeList.Name as [StateDocumentName],
  ---
  position.Count,
  position.rf_StatePositionWPLID as [StatePositionId],
  statePos.Name as [StatePositionName],
  position.PositionWPLID as [Id],
  transactJoural.rf_StoredLSID as [StoredLsId]
From ras_WriteOffPurposeList
Inner Join ras_StatePurposeList On ras_WriteOffPurposeList.rf_StatePurposeListId = ras_StatePurposeList.StatePurposeListID
inner join ras_PositionWPL position on position.rf_WriteOffPurposeListID =  ras_WriteOffPurposeList.WriteOffPurposeListID
inner join ras_StatePositionWPL statePos on statePos.StatePositionWPLID = position.rf_StatePositionWPLID
inner join ras_TransactJournal transactJoural on transactJoural.PositionID = position.PositionWPLID
Where WriteOffPurposeListID != 0 and transactJoural.rf_DocDescriptionID = 17

go

