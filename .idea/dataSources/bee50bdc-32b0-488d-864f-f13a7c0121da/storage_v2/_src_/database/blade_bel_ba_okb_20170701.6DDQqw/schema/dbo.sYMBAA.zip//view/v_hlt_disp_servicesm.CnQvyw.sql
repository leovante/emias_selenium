CREATE VIEW [V_hlt_disp_ServiceSM] AS SELECT 
[hDED].[disp_ServiceSMID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OmsServiceMedicalGuid] as [rf_OmsServiceMedicalGuid], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_OmsServiceMedicalGuid], 
[hDED].[rf_PatientModelGuid] as [rf_PatientModelGuid], 
[jT_hlt_disp_PatientModel].[Code] as [SILENT_rf_PatientModelGuid], 
[hDED].[rf_ServiceGuid] as [rf_ServiceGuid], 
[jT_hlt_disp_Service].[Name] as [SILENT_rf_ServiceGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[RatioTariff] as [RatioTariff], 
[hDED].[DopPriznak] as [DopPriznak], 
[hDED].[Rem] as [Rem]
FROM [hlt_disp_ServiceSM] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[GUIDSM] = [hDED].[rf_OmsServiceMedicalGuid]
INNER JOIN [hlt_disp_PatientModel] as [jT_hlt_disp_PatientModel] on [jT_hlt_disp_PatientModel].[Guid] = [hDED].[rf_PatientModelGuid]
INNER JOIN [hlt_disp_Service] as [jT_hlt_disp_Service] on [jT_hlt_disp_Service].[Guid] = [hDED].[rf_ServiceGuid]
go

