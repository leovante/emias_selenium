CREATE VIEW [V_trs_Domain] AS SELECT 
[hDED].[DomainID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[DomainName] as [DomainName]
FROM [trs_Domain] as [hDED]
go

