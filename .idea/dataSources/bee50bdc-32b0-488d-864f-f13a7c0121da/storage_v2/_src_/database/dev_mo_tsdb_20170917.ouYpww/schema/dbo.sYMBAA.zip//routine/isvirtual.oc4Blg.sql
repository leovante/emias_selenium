
				create function [dbo].[IsVirtual] (@dd uniqueidentifier)
returns int as
begin
	declare @t int
	declare @dtFlags int
	set @dtFlags = (select top 1 FLAGS from x_STDO where @dd = DocTypeDef and HostID = 0)
	declare @canS bit
	declare @canI bit
	declare @canU bit
	declare @canD bit
    set @canI = @dtFlags & 0x04
    set @canU = @dtFlags & 0x08
    set @canD = @dtFlags & 0x10
    set @canS = @dtFlags & 0x20
    if (@canS = 1 and @canI = 0 and @canU = 0 and @canD = 0)
		set @t = 1
	else
		set @t = 0
	return @t
end
        go

