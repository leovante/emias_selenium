CREATE VIEW [V_trs_Host_Group] AS SELECT 
[hDED].[Host_GroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_HostID] as [rf_HostID], 
[jT_trs_Host].[HostName] as [SILENT_rf_HostID], 
[hDED].[rf_GroupID] as [rf_GroupID], 
[jT_trs_Group].[GroupName] as [SILENT_rf_GroupID]
FROM [trs_Host_Group] as [hDED]
INNER JOIN [trs_Host] as [jT_trs_Host] on [jT_trs_Host].[HostID] = [hDED].[rf_HostID]
INNER JOIN [trs_Group] as [jT_trs_Group] on [jT_trs_Group].[GroupID] = [hDED].[rf_GroupID]
go

