
CREATE FUNCTION [dbo].[x_GetElementTypeName] 
(@elemGUID uniqueidentifier)
RETURNS varchar(50)
AS
BEGIN
	DECLARE 
		@typeID int,
		@typeSize int,
		@typeScale int,
		@typeName varchar(50),
		@strSize varchar(10)

	select top 1 @typeID = ValueType, @typeSize = ValueSize, @typeScale = ValueScale 
	from [x_DocElemDef] Where [GUID] = @elemGUID;

	select @typeName = lower([Name]) from [x_ValueType] where ValueTypeID = @typeID;

	if (@typeName = 'decimal')
		RETURN @typeName + '(' + cast(@typeSize as varchar(10)) + ',' + cast(@typeScale as varchar(10)) + ')';	

	set @strSize = '(max)'

	if (@typeSize > 0)
		set @strSize = '(' + cast(@typeSize as varchar(10)) + ')'

	select @typeName = @typeName + @strSize
	where (@typeName in ('varbinary', 'varchar', 'nvarchar', 'nchar', 'binary', 'char'))

	RETURN @typeName;
END
go

