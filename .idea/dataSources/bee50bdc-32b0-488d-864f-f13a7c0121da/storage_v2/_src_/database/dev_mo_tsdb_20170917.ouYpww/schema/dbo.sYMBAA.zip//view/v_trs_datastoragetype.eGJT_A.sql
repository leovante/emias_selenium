CREATE VIEW [V_trs_DataStorageType] AS SELECT 
[hDED].[DataStorageTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[DataStorageTypeName] as [DataStorageTypeName]
FROM [trs_DataStorageType] as [hDED]
go

