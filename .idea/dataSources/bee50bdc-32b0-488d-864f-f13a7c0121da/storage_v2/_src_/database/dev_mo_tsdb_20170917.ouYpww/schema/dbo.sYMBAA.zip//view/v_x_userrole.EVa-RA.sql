
CREATE VIEW [dbo].[V_x_UserRole] as 
select UserRoleID, [x_UserRole].[x_Edition], [x_UserRole].[x_Status], x_Role.RoleID, x_UserRole.UserID, x_Role.Type, x_Role.Name as RoleNameVSV,
(CASE [Type] WHEN 1 THEN 'Администраторская' ELSE 'Пользовательская' END) as RoleTypeVSV
from x_UserRole
inner join x_Role on x_Role.RoleID = x_UserRole.RoleID
go

