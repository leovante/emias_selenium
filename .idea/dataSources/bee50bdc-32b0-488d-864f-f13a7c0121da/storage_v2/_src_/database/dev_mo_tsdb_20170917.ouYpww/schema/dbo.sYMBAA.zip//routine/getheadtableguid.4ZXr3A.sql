/*******************************************************
возвращает название головной таблицы для доктипа
*******************************************************/
create function dbo.GetHeadTableGuid(@dd uniqueidentifier)
returns varchar(500)
begin
	declare @t varchar(500)
	set @t = (select top 1 HeadTable from x_DocTypeDef where GUID = @dd)
	return @t
end
go

