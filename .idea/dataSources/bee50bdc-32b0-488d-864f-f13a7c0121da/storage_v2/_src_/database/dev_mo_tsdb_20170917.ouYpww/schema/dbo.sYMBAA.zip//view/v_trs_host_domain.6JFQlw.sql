CREATE VIEW [V_trs_Host_Domain] AS SELECT 
[hDED].[Host_DomainID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_HostID] as [rf_HostID], 
[jT_trs_Host].[HostName] as [SILENT_rf_HostID], 
[hDED].[rf_DomainID] as [rf_DomainID], 
[jT_trs_Domain].[DomainName] as [SILENT_rf_DomainID]
FROM [trs_Host_Domain] as [hDED]
INNER JOIN [trs_Host] as [jT_trs_Host] on [jT_trs_Host].[HostID] = [hDED].[rf_HostID]
INNER JOIN [trs_Domain] as [jT_trs_Domain] on [jT_trs_Domain].[DomainID] = [hDED].[rf_DomainID]
go

