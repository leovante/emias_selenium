CREATE VIEW [V_trs_Events] AS SELECT 
[hDED].[EventsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_HostID] as [rf_HostID], 
[jT_trs_Host].[HostName] as [SILENT_rf_HostID], 
[hDED].[DateTime] as [DateTime], 
[hDED].[Description] as [Description]
FROM [trs_Events] as [hDED]
INNER JOIN [trs_Host] as [jT_trs_Host] on [jT_trs_Host].[HostID] = [hDED].[rf_HostID]
go

