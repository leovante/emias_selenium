CREATE VIEW [V_trs_Canal] AS SELECT 
[hDED].[CanalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DefaultDataStorageID] as [rf_DefaultDataStorageID], 
[jT_trs_DataStorage].[HostAddress] as [SILENT_rf_DefaultDataStorageID], 
[hDED].[CanalName] as [CanalName], 
[hDED].[Packed] as [Packed], 
[hDED].[Priority] as [Priority], 
[hDED].[Ciphered] as [Ciphered], 
[hDED].[Signed] as [Signed], 
[hDED].[Alias] as [Alias], 
[hDED].[Personalized] as [Personalized], 
[hDED].[Description] as [Description], 
[hDED].[LastPackageMode] as [LastPackageMode], 
[hDED].[Flags] as [Flags]
FROM [trs_Canal] as [hDED]
INNER JOIN [trs_DataStorage] as [jT_trs_DataStorage] on [jT_trs_DataStorage].[DataStorageID] = [hDED].[rf_DefaultDataStorageID]
go

