-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION LPUPackages ()
RETURNS TABLE 
AS
RETURN 
(
SELECT HostName, Description, 
 isnull([115], '2010-01-01T00:00:00') as RVR,
 isnull([175], '2010-01-01T00:00:00') as DVN,
 isnull([113], '2010-01-01T00:00:00') as Fiscal
FROM (
    SELECT * FROM (
        SELECT 
          h.HostName, 
          h.Description, 
          p.DateTime,
		  p.rf_canalid chanal
        from  trs_Host h
			left join trs_Package p
				on h.Hostid = p.rf_SenderID
		where rf_canalid in (115, 175, 113)
		and h.Hostid > 0
        ) x
   PIVOT (
        max(DateTime) FOR chanal in ([115], [175], [113])
    ) pvt 
) tb

)
go

