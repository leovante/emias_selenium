CREATE VIEW [V_trs_HostSettings] AS SELECT 
[hDED].[HostSettingsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_HostID] as [rf_HostID], 
[jT_trs_Host].[HostName] as [SILENT_rf_HostID], 
[hDED].[Name] as [Name], 
[hDED].[Value] as [Value]
FROM [trs_HostSettings] as [hDED]
INNER JOIN [trs_Host] as [jT_trs_Host] on [jT_trs_Host].[HostID] = [hDED].[rf_HostID]
go

