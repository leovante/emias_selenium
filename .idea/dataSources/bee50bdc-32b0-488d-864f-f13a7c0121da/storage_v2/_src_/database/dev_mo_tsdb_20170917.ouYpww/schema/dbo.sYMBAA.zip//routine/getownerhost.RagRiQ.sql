
/*******************************************************
возвращает название головной таблицы для доктипа
*******************************************************/
create function dbo.GetOwnerHost(@dd uniqueidentifier)
returns varchar(500)
begin
	declare @ret varchar(500)
	declare @host int
	declare @dtFlags int
	declare @canI bit
	declare @canU bit
	declare @canD bit	
	
	declare cur cursor read_only for
		select HostID, Flags from x_STDO where DocTypeDef = @dd and HostID > 0

	open cur

	fetch next from cur into @host, @dtFlags
	if @@fetch_Status = 0
	begin
		set @canI = @dtFlags & 0x04
		set @canU = @dtFlags & 0x08
		set @canD = @dtFlags & 0x10
		if @canI = 1 or @canU = 1 or @canD = 1
		begin
			set @ret = cast(@host as varchar(500))
			close cur
			deallocate cur
			return @ret
		end    
		
		fetch next from cur into @host, @dtFlags
	end

	close cur
	deallocate cur
	set @ret = '0'
	return @ret	
	
end
go

