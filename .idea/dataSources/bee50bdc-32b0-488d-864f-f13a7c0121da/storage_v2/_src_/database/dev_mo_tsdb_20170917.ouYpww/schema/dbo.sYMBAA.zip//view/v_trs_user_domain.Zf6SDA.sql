CREATE VIEW [V_trs_User_Domain] AS SELECT 
[hDED].[User_DomainID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DomainID] as [rf_DomainID], 
[jT_trs_Domain].[DomainName] as [SILENT_rf_DomainID], 
[hDED].[rf_UserID] as [rf_UserID]
FROM [trs_User_Domain] as [hDED]
INNER JOIN [trs_Domain] as [jT_trs_Domain] on [jT_trs_Domain].[DomainID] = [hDED].[rf_DomainID]
go

