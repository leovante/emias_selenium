/*******************************************************
возвращает имя дефалта для поля
*******************************************************/
create function dbo.GetDefaultName (@tableName varchar(500), @fieldName varchar(500))
returns varchar(500) as
begin
	declare @defaultName varchar(500)
	set @defaultName = (

					select top 1 d.name from sysobjects d
						inner join sysobjects t on t.id = d.parent_obj
						inner join syscolumns c on c.id = t.id and c.cdefault = d.id
						where  d.type = 'D' and t.name = @tableName and c.name = @fieldName
						)
	return @defaultName
end
go

