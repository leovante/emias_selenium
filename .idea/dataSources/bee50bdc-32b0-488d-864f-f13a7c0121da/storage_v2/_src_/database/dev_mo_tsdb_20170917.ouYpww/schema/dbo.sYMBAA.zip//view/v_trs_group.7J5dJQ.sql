CREATE VIEW [V_trs_Group] AS SELECT 
[hDED].[GroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[GroupName] as [GroupName], 
[hDED].[Description] as [Description]
FROM [trs_Group] as [hDED]
go

