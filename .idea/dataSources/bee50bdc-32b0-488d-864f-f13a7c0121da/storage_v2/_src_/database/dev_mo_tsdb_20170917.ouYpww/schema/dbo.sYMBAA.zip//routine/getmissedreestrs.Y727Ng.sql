CREATE PROCEDURE [dbo].[GetMissedReestrs]
	@HostName varchar(8000)	
AS
BEGIN
	SET NOCOUNT ON;
	declare @HostID int
	
    set @HostID=(select top 1 HostID from trs_host where hostName=@hostName)


	select n ,  host_guid ,[ЛПУ] from (
	select  Max(t1.Reestr) as [Предыдущ],t.reestr,  t.host_guid ,t.[ЛПУ] from 
	(
	select 
	substring(RealFileName,6,charindex(']',RealFileName)-5) as host_guid
	,substring(RealFileName,(charindex(']',RealFileName)+2),(charindex('-',RealFileName,(charindex(']',RealFileName)+2))-(charindex(']',RealFileName)+2))) as reestr 
	,realFileName as [файл]
	,host.Description as [ЛПУ]
	 from trs_package 
	 join trs_host host on host.hostid=rf_SenderID
	where rf_canalid = 115 and realFileName  like 'rlpu_10%' and rf_SenderID=@HostID
	) 
	t left outer join   
	( 
	select 
	substring(RealFileName,6,charindex(']',RealFileName)-5) as host_guid
	,substring(RealFileName,(charindex(']',RealFileName)+2),(charindex('-',RealFileName,(charindex(']',RealFileName)+2))-(charindex(']',RealFileName)+2))) as reestr 
	,realFileName as [файл]
	,host.Description as [ЛПУ]
	 from trs_package 
	 join trs_host host on host.hostid=rf_SenderID
	where rf_canalid = 115 and realFileName  like 'rlpu_10%' and rf_SenderID=@HostID
	) 
	t1 on t.reestr> t1.reestr
	group by t.reestr, t.host_guid ,t.[ЛПУ]
	) tt inner join  
	  (	select cast(t1.k + t1.k + t2.k + t3.k + t4.k +t5.k as int) as n 
			 from (select '0' as k union all select '1' union all select '2' union all select '3' union all select '4' union all select '5'
					   union all select '6' union all select '7' union all select '8' union all select '9') t1,
				  (select '0' as k union all select '1' union all select '2' union all select '3' union all select '4' union all select '5'
					   union all select '6' union all select '7' union all select '8' union all select '9') t2, 
				  (select '0' as k union all select '1' union all select '2' union all select '3' union all select '4' union all select '5'
					   union all select '6' union all select '7' union all select '8' union all select '9') t3, 
				  (select '0' as k union all select '1' union all select '2' union all select '3' union all select '4' union all select '5'
					   union all select '6' union all select '7' union all select '8' union all select '9') t4 ,
				(select '0' as k union all select '1' union all select '2' union all select '3' union all select '4' union all select '5'
					   union all select '6' union all select '7' union all select '8' union all select '9') t5 
	) jj on ([Предыдущ] < n  and  reestr > n ) 
	where [Предыдущ] is not null  and ([Предыдущ]+1 != reestr) 
	group by n,  host_guid ,[ЛПУ]
	order by Host_guid, n

END
go

