/*******************************************************
является ли документ документооборотным
*******************************************************/
create function [dbo].[IsDO] (@dd uniqueidentifier)
returns int as
begin
	declare @t int
	set @t = (select count(*) from x_STDO where @dd = DocTypeDef)
	return @t
end
go

