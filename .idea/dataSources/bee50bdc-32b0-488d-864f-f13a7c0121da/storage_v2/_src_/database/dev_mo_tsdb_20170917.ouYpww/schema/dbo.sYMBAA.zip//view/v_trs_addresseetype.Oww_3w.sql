CREATE VIEW [V_trs_AddresseeType] AS SELECT 
[hDED].[AddresseeTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[AddresseeTypeName] as [AddresseeTypeName]
FROM [trs_AddresseeType] as [hDED]
go

