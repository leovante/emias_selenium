CREATE VIEW [V_trs_PackageStatus] AS SELECT 
[hDED].[PackageStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note]
FROM [trs_PackageStatus] as [hDED]
go

