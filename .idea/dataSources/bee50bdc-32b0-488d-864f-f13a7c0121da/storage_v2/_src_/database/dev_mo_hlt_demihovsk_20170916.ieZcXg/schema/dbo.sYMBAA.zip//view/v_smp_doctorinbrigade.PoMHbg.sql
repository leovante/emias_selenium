CREATE VIEW [V_smp_DoctorInBrigade] AS SELECT 
[hDED].[DoctorInBrigadeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_BrigadeID] as [rf_BrigadeID], 
[hDED].[rf_DoctorID] as [rf_DoctorID], 
[hDED].[Flag] as [Flag]
FROM [smp_DoctorInBrigade] as [hDED]
go

