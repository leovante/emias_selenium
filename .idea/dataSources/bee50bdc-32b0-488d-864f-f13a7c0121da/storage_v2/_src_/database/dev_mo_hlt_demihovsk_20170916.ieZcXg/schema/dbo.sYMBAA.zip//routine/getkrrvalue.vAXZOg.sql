
Create FUNCTION [dbo].[GetKRRValue](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int
)
RETURNS  [decimal](38, 3) 

AS

begin

declare @k decimal(18,2)
set @k=1


select @k=@k*value
from [dbo].[GetKRR](@date, @lpuid,@profileId,@typeid,@usl1 ,@usl2,@mkb ,@age,@dlit)
return @k
end
go

