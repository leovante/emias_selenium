CREATE VIEW [V_hlt_Direction] AS SELECT 
[hDED].[DirectionID], [hDED].[x_Edition], [hDED].[x_Status], 
(select hDED.Family+ ' '+ hDED.Name+' '+ hDED.OT) as [V_FIO], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_LPUSenderID] as [rf_LPUSenderID], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_PRVSID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_TypeDirectionID] as [rf_TypeDirectionID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_LPUDoctorZavID] as [rf_LPUDoctorZavID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_DocPRVDZavID] as [rf_DocPRVDZavID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[rf_LPUOtherID] as [rf_LPUOtherID], 
[jT_oms_LPUOther].[ShortName] as [SILENT_rf_LPUOtherID], 
[hDED].[Reason] as [Reason], 
[hDED].[Date] as [Date], 
[hDED].[FAMILY] as [FAMILY], 
[hDED].[NAME] as [NAME], 
[hDED].[Work] as [Work], 
[hDED].[OT] as [OT], 
[hDED].[BD] as [BD], 
[hDED].[Address] as [Address], 
[hDED].[S_POL] as [S_POL], 
[hDED].[N_POL] as [N_POL], 
[hDED].[Num] as [Num], 
[hDED].[Post] as [Post], 
[hDED].[GUID] as [GUID], 
[hDED].[Flag] as [Flag], 
[hDED].[BedProfileCode] as [BedProfileCode], 
[hDED].[DatePlan] as [DatePlan]
FROM [hlt_Direction] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
INNER JOIN [oms_LPUOther] as [jT_oms_LPUOther] on [jT_oms_LPUOther].[LPUOtherID] = [hDED].[rf_LPUOtherID]
go

