CREATE VIEW [V_hlt_ReestrRecipeRegionLG] AS SELECT 
[hDED].[ReestrRecipeRegionLGID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[Recipe_Reestr_Num] as [Recipe_Reestr_Num], 
[hDED].[Recipe_Reestr_Begin_Date] as [Recipe_Reestr_Begin_Date], 
[hDED].[Recipe_Reestr_End_Date] as [Recipe_Reestr_End_Date], 
[hDED].[Recipe_Count] as [Recipe_Count], 
[hDED].[Recipe_Sum] as [Recipe_Sum], 
[hDED].[upload_date] as [upload_date]
FROM [hlt_ReestrRecipeRegionLG] as [hDED]
go

