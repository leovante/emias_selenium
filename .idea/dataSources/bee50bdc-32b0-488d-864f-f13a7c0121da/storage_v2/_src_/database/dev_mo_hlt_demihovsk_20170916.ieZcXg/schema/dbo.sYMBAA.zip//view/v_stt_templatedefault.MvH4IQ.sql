CREATE VIEW [V_stt_TemplateDefault] AS SELECT 
[hDED].[TemplateDefaultID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_TemplateTypeID] as [rf_TemplateTypeID], 
[hDED].[rf_TemplateDefaultID] as [rf_TemplateDefaultID], 
[hDED].[TemplateTag] as [TemplateTag]
FROM [stt_TemplateDefault] as [hDED]
go

