CREATE TRIGGER [LifeTrigger_oms_hs_Hospital] ON [oms_hs_Hospital] FOR DELETE,INSERT,UPDATE
AS 

SET NOCOUNT ON;

DECLARE @userId INT
DECLARE @seanceId INT 

DECLARE @docTypeId INT 
DECLARE @CURDATE DATETIME


declare @app varchar(50)
declare @index1 int
declare @index2 int


/* @userId, @seanceId */

SET @userId = 0
SET @seanceId = 0

EXEC [GetMalibuContext] @seanceId = @seanceId OUTPUT, @userId = @userId OUTPUT

/* @docTypeId */

SET @CURDATE = getdate()

SET @docTypeId = 0

SELECT TOP 1 @docTypeId = [DocTypeDefID], @seanceId=case WHEN [x_STDO].[HostID] IS NULL THEN @seanceId ELSE 0 END
FROM [x_DocTypeDef] left join [x_STDO] on [x_DocTypeDef].[GUID] = [x_STDO].[DocTypeDef] 
WHERE [HeadTable] = 'oms_hs_Hospital'

/* action type */

DECLARE @DEL BIT
DECLARE @INS BIT 

DECLARE @action CHAR(1)


SET @DEL = 0
SET @INS = 0


IF EXISTS (SELECT TOP 1 1 FROM DELETED) SET @DEL=1
IF EXISTS (SELECT TOP 1 1 FROM INSERTED) SET @INS = 1 

IF @INS = 1 AND @DEL = 1 SET @ACTION = 'u'
IF @INS = 1 AND @DEL = 0 SET @ACTION = 'i'
IF @INS = 0 AND @DEL = 1 SET @ACTION = 'd'


IF @ACTION = 'd'
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [hs_HospitalID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM deleted;

	INSERT INTO Life_oms_hs_Hospital([hs_HospitalID],[AdmissionState],[DateExit],[DateExitPlan],[DateTimeFact],[day_hospital],[DirDate],[DirLPU],[DirLPU_1],[DirNumber],[DR],[DS],[DS_discharge],[Extr],[FAM],[GIP_GUID],[AdmissionDateTime],[IM],[kl_hospchanel_Code],[LastUserID],[LPU],[LPU_1],[MedCardNum],[n_doc],[no_hosp],[NPOLIS],[OT],[PROFIL],[ProfilBed],[rejectionReason],[rf_area_typeID],[rf_hs_HospitalID],[rf_hs_LpuDepartmentID],[rf_kl_DepartmentProfileID],[rf_kl_PatientStatusID],[rf_kl_ProfitTypeID],[rf_kl_TipOMSID],[rf_kl_VisitResultID],[rf_LPUID],[rf_MKBID],[rf_SMOID],[rf_TYPEDOCID],[s_Doc],[SMO],[SMO_OK],[Source],[SPOLIS],[SS],[State],[TypeMig],[UGUID],[VisitRes],[VPOLIS],[W],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [hs_HospitalID],[AdmissionState],[DateExit],[DateExitPlan],[DateTimeFact],[day_hospital],[DirDate],[DirLPU],[DirLPU_1],[DirNumber],[DR],[DS],[DS_discharge],[Extr],[FAM],[GIP_GUID],[AdmissionDateTime],[IM],[kl_hospchanel_Code],[LastUserID],[LPU],[LPU_1],[MedCardNum],[n_doc],[no_hosp],[NPOLIS],[OT],[PROFIL],[ProfilBed],[rejectionReason],[rf_area_typeID],[rf_hs_HospitalID],[rf_hs_LpuDepartmentID],[rf_kl_DepartmentProfileID],[rf_kl_PatientStatusID],[rf_kl_ProfitTypeID],[rf_kl_TipOMSID],[rf_kl_VisitResultID],[rf_LPUID],[rf_MKBID],[rf_SMOID],[rf_TYPEDOCID],[s_Doc],[SMO],[SMO_OK],[Source],[SPOLIS],[SS],[State],[TypeMig],[UGUID],[VisitRes],[VPOLIS],[W],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM deleted;
END;
ELSE
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [hs_HospitalID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM inserted;

	INSERT INTO Life_oms_hs_Hospital([hs_HospitalID],[AdmissionState],[DateExit],[DateExitPlan],[DateTimeFact],[day_hospital],[DirDate],[DirLPU],[DirLPU_1],[DirNumber],[DR],[DS],[DS_discharge],[Extr],[FAM],[GIP_GUID],[AdmissionDateTime],[IM],[kl_hospchanel_Code],[LastUserID],[LPU],[LPU_1],[MedCardNum],[n_doc],[no_hosp],[NPOLIS],[OT],[PROFIL],[ProfilBed],[rejectionReason],[rf_area_typeID],[rf_hs_HospitalID],[rf_hs_LpuDepartmentID],[rf_kl_DepartmentProfileID],[rf_kl_PatientStatusID],[rf_kl_ProfitTypeID],[rf_kl_TipOMSID],[rf_kl_VisitResultID],[rf_LPUID],[rf_MKBID],[rf_SMOID],[rf_TYPEDOCID],[s_Doc],[SMO],[SMO_OK],[Source],[SPOLIS],[SS],[State],[TypeMig],[UGUID],[VisitRes],[VPOLIS],[W],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [hs_HospitalID],[AdmissionState],[DateExit],[DateExitPlan],[DateTimeFact],[day_hospital],[DirDate],[DirLPU],[DirLPU_1],[DirNumber],[DR],[DS],[DS_discharge],[Extr],[FAM],[GIP_GUID],[AdmissionDateTime],[IM],[kl_hospchanel_Code],[LastUserID],[LPU],[LPU_1],[MedCardNum],[n_doc],[no_hosp],[NPOLIS],[OT],[PROFIL],[ProfilBed],[rejectionReason],[rf_area_typeID],[rf_hs_HospitalID],[rf_hs_LpuDepartmentID],[rf_kl_DepartmentProfileID],[rf_kl_PatientStatusID],[rf_kl_ProfitTypeID],[rf_kl_TipOMSID],[rf_kl_VisitResultID],[rf_LPUID],[rf_MKBID],[rf_SMOID],[rf_TYPEDOCID],[s_Doc],[SMO],[SMO_OK],[Source],[SPOLIS],[SS],[State],[TypeMig],[UGUID],[VisitRes],[VPOLIS],[W],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM inserted;
END; 

SET NOCOUNT OFF;


go

