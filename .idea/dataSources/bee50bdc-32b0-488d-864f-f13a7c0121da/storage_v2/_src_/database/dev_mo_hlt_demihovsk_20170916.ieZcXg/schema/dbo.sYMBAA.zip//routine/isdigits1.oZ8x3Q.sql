CREATE FUNCTION [dbo].[IsDigits1] (@Field varchar(20))  
RETURNS varchar(20)   AS  
BEGIN 

declare @Like varchar(300)
declare @ii int;

set @Like ='';
set @ii  = 0


while @ii< len(@Field)
begin
     set @Like =@Like + '[0-9]';
     set @ii=@ii+1;
end

set @Like =(select case when PATINDEX ( '%'+@Like+'%' ,@Field) =1  then @Field else '0' end  )
if(@Like ='0' ) 
Begin

set @ii=len(@Field)

set @Like=''
while (@ii>0) 
BEGIN
     if patindex('[0-9]',Substring (@Field,@ii,1) )=0 
            set     @Like= @Like+ Substring (@Field,@ii,1);
       
        set @ii=@ii-1
END
set @ii = len(@Like)
while (@ii>0) 
BEGIN
   set @Field = Replace (@Field,Substring(@Like,@ii,1),'')
   set @ii=@ii-1
END
set @Like = @Field



END


declare @nm decimal(20,2)

--if  ISNUMERIC(@Like)=0     set @Like =0;

set @nm=convert(decimal(20,2),@Like)

--if( @nm >2147483647 )  return 0 
return Convert(bigint,@nm)

END


go

