CREATE VIEW [V_oms_ds_PatDS] AS SELECT 
[hDED].[ds_PatDSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_GUIDLPU] as [rf_GUIDLPU], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_GUIDLPU], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_kl_DiseaseTypeID] as [rf_kl_DiseaseTypeID], 
[jT_oms_kl_DiseaseType].[Name] as [SILENT_rf_kl_DiseaseTypeID], 
[hDED].[rf_GUIDDiagnosType] as [rf_GUIDDiagnosType], 
[jT_oms_kl_DiagnosType].[Code] as [SILENT_rf_GUIDDiagnosType], 
[hDED].[rf_PersonGUID] as [rf_PersonGUID], 
[jT_oms_mn_Person].[V_FIO] as [SILENT_rf_PersonGUID], 
[hDED].[rf_MKABGUID] as [rf_MKABGUID], 
[hDED].[rf_SluchDocTypeDefGUID] as [rf_SluchDocTypeDefGUID], 
[hDED].[rf_SluchDocGUID] as [rf_SluchDocGUID], 
[hDED].[rf_DocTypeDefGUID] as [rf_DocTypeDefGUID], 
[hDED].[rf_DocGUID] as [rf_DocGUID], 
[hDED].[DSComment] as [DSComment], 
[hDED].[DateDS] as [DateDS], 
[hDED].[isActive] as [isActive], 
[hDED].[isSign] as [isSign], 
[hDED].[DateSign] as [DateSign], 
[hDED].[rf_LPUDoctorGUID] as [rf_LPUDoctorGUID], 
[hDED].[rf_DocPRVDGUID] as [rf_DocPRVDGUID], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[PatDSGUID] as [PatDSGUID]
FROM [oms_ds_PatDS] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[GUIDLPU] = [hDED].[rf_GUIDLPU]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_kl_DiseaseType] as [jT_oms_kl_DiseaseType] on [jT_oms_kl_DiseaseType].[kl_DiseaseTypeID] = [hDED].[rf_kl_DiseaseTypeID]
INNER JOIN [oms_kl_DiagnosType] as [jT_oms_kl_DiagnosType] on [jT_oms_kl_DiagnosType].[GUIDDiagnosType] = [hDED].[rf_GUIDDiagnosType]
INNER JOIN [V_oms_mn_Person] as [jT_oms_mn_Person] on [jT_oms_mn_Person].[PersonGUID] = [hDED].[rf_PersonGUID]
go

