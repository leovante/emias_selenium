-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[wlsf_GetWaitingListRecords] (
	@mkabid INT
	,@mcod VARCHAR(10)
	,@dateFrom DATETIME
	,@dateTo DATETIME
	)
RETURNS TABLE
AS
RETURN (
		SELECT wl.DateFrom
			,wl.DateTo
			,wl.HourFrom
			,wl.HourTo
			,st.code StateCode
			,st.NAME StateName
			,wl.WaitingListID id
			,wl.rf_DocPRVDID Docid
			,CASE 
				WHEN wl.rf_DocPRVDID = 0
					OR doc.rf_LPUDoctorID = 0
					THEN ''
				ELSE (
						SELECT FAM_V + ' ' + IM_V + ' ' + OT_V
						FROM hlt_LPUDoctor ld WITH (NOLOCK)
						WHERE ld.LPUDoctorid = doc.rf_LPUDoctorID
						)
				END DocName
			,prvs.PRVSID Prvsid
			,prvs.PRVS_NAME PrvsName
		FROM hlt_waitinglist wl WITH (NOLOCK)
		INNER JOIN oms_LPU lpu  WITH (NOLOCK) ON lpu.LPUID = wl.rf_LPUID
		INNER JOIN hlt_WaitingListState st WITH (NOLOCK) ON wl.rf_WaitingListStateID = st.WaitingListStateID
		INNER JOIN hlt_DocPRVD doc WITH (NOLOCK) ON wl.rf_DocPRVDID = doc.DocPRVDID
		INNER JOIN oms_PRVS prvs WITH (NOLOCK) ON prvs.PRVSID = wl.rf_PRVSID
		WHERE wl.rf_MKABID = @mkabid
			AND (
				(
					wl.DateFrom BETWEEN @dateFrom
						AND @dateTo
					)
				OR (
					wl.DateTo BETWEEN @dateFrom
						AND @dateTo
					)
				)
			AND lpu.mcod = @mcod
		)


go

