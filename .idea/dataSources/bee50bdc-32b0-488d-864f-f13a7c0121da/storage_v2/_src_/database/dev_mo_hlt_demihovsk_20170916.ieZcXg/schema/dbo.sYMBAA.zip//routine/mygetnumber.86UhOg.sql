--отрезает первую числовую часть (номер)
CREATE FUNCTION dbo.MyGetNumber (@fullnum varchar(200))
RETURNS varchar(50) AS
BEGIN 
declare @i int, @f int
set @i=1
set @f=0
while @i<=len(@fullnum) and @f=0
begin
	if (substring(@fullnum,@i,1) not like '[0-9]') set @f=-1
	else set @i=@i+1
end
return left(@fullnum,@i-1)
END
go

