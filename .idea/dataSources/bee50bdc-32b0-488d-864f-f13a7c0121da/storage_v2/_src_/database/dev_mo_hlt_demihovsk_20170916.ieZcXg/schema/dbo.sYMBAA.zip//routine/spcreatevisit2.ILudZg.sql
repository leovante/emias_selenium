
CREATE PROCEDURE [dbo].[spCreateVisit2] @dttid INT
	,@mkabid INT
	,@result INT OUTPUT
	,@stubNum varchar(50) OUTPUT
AS
BEGIN
	SET @stubNum = ''
	-- c 20:00 открываем запись на закрытые ячейки.
	declare @hour int = 20

	/* Есть ли такая временная запись? */
	IF NOT EXISTS (
			SELECT *
			FROM hlt_DoctorTimeTable
			WHERE DoctorTimeTableID = @dttid
			)
	BEGIN
		SET @result = - 8

		RETURN
	END


	/* Проверим права записи */
	-- От 27.09.2017 добавлена Запись на прием после 20:00 на завтрашние ячейки, закрытые для самозаписи.
	-- Запись можно открывать на ячейки расписания врача, если у него есть хотя бы 1 ячейка с возможностью записи через интернет.
	IF (
			   (select (case 
			when (dtt.FlagAccess & 4) > 0 
			then 1 
			else (isnull((select 1 
				  from hlt_DoctorTimeTable dtt2 with(nolock) 
				  where dtt2.Date = dtt.Date 
				  and dtt2.FlagAccess & 4 > 0 
				  and dtt2.rf_DocPRVDID = dtt.rf_DocPRVDID
				  and ((DATEPART(hour, getdate()) >= @hour and dtt.Date = cast(dateadd(d, 1, getdate()) as date))
						or dtt.Date = CAST(getdate() AS date))), 0))
				    end )
   from hlt_DoctorTimeTable dtt with(nolock) 
   where dtt.DoctorTimeTableID = @dttid) = 0
			)
	BEGIN
		SET @result = - 12
		
		RETURN
	END

	/* проверим, не запрещена ли самозапись */
	IF ((select top 1 Blacklabel from hlt_MKAB with(nolock) where MKABID = @mkabid) = 1)
	BEGIN
		SET @result = - 6
		
		RETURN
	END
	
	/*А может уже кого-то записали?*/
	DECLARE @PLAN INT
	DECLARE @NORMA INT

	SET @PLAN = isnull((
				SELECT PLANUE
				FROM hlt_DoctorTimeTable
				WHERE DoctorTimeTableID = @dttid
				), 0)
	SET @NORMA = isnull((
				SELECT sum(NormaUE)
				FROM hlt_DoctorVisitTable
				WHERE rf_DoctorTimeTableID = @dttid
				), 0)

	IF @NORMA >= @PLAN
	BEGIN
		SET @result = - 2

		RETURN
	END

	/*Определяем врача*/
	DECLARE @docPRVDID INT

	SET @docPRVDID = isnull((
				SELECT TOP 1 rf_docPRVDID
				FROM hlt_DoctorTimeTable
				WHERE DoctorTimeTableID = @dttid
				), 0)

	/*И его специальность*/
	DECLARE @PRVSID INT
	SET @PRVSID = isnull((
				SELECT TOP 1 rf_PRVSID
				FROM hlt_DocPRVD
				WHERE DocPRVDID = @docPRVDID
				), 0)

	/*Дата записи*/
	DECLARE @dttDate DATETIME

	SET @dttDate = isnull((
				SELECT TOP 1 [DATE]
				FROM hlt_DoctorTimeTable
				WHERE DoctorTimeTableID = @dttid
				), getdate())

	IF @docPRVDID != 0
		AND EXISTS (
			SELECT 1
			FROM hlt_DoctorTimeTable dtt
			INNER JOIN hlt_DoctorVisitTable dvt ON dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID
			WHERE dvt.rf_MkabID = @mkabid
				AND dtt.DATE = @dttDate
				AND dtt.rf_DocPRVDID = @docPRVDID
			)
	BEGIN
		SET @result = - 7

		RETURN
	END

	/*Уже записаны к врачу такой же специальности*/
	IF EXISTS (
			SELECT 1
			FROM hlt_DoctorTimeTable dtt
			INNER JOIN hlt_DoctorVisitTable dvt ON dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID
			INNER JOIN hlt_DocPRVD ON DocPRVDID = dtt.rf_DocPRVDID
			WHERE dvt.rf_MKABID = @mkabid
				AND hlt_DocPRVD.rf_PRVSID = @PRVSID
				AND dtt.DATE > GETDATE()
			)
	BEGIN
		SET @result = - 101

		RETURN
	END

	--/*Проверим диспансерных пациентов*/
	--IF (
	--		(
	--			SELECT TOP 1 CASE valueStr
	--					WHEN ''
	--						THEN 0
	--					WHEN '0'
	--						THEN 0
	--					ELSE 1
	--					END
	--			FROM x_userSettings
	--			WHERE property LIKE 'Диспансерное наблюдение'
	--			) = 1
	--		)
	--BEGIN
	--	IF @PRVSID IN (
	--			SELECT PRVSID
	--			FROM oms_PRVS
	--			WHERE C_PRVS IN (
	--					'40127' /*Эндокринология*/
	--					,'4020102' /*Детская эндокринология*/
	--					,'4012205' /*Кардиология*/
	--					,'4020103' /*Детская кардиология*/
	--					,'4012209' /*Ревматология*/
	--					,'40109' /*Неврология*/
	--					,'4012201' /*Гастроэнтерология*/
	--					,'4012202' /*Гематология*/
	--					,'4012207' /*Нефрология*/
	--					)
	--			)
	--		OR (
	--			SELECT isnull((
	--						SELECT TOP 1 isSpecial
	--						FROM hlt_lpudoctor
	--						WHERE LPUDoctorID = (
	--								SELECT TOP 1 rf_LPUDoctorID
	--								FROM hlt_docprvd
	--								WHERE docPRVDID = @docPRVDID
	--								)
	--						), 0)
	--			) > 0
	--	BEGIN
	--		/*Самозапись к этим специалистам разрешена только для диспансерных пациентов*/
	--		IF NOT EXISTS (
	--				SELECT TOP 1 1
	--				FROM hlt_RegMedicalCheck
	--				WHERE rf_MKABID = @mkabid
	--					AND @dttDate BETWEEN dateRegistration
	--						AND DateOff
	--					AND rf_PRVSID = @PRVSID
	--				)
	--		BEGIN
	--			SET @result = - 13
	--			RETURN
	--		END
	--	END
	--END
	SET @PLAN = isnull((
				SELECT PLANUE
				FROM hlt_DoctorTimeTable
				WHERE DoctorTimeTableID = @dttid
				), 0)
	SET @NORMA = isnull((
				SELECT sum(NormaUE)
				FROM hlt_DoctorVisitTable
				WHERE rf_DoctorTimeTableID = @dttid
				), 0)

	IF @NORMA >= @PLAN
	BEGIN
		SET @result = - 2

		RETURN
	END

	BEGIN TRAN


	DECLARE @num VARCHAR(200) = ''
	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE NAME = 'spGetDVDStubNum'
				AND type = 'P'
			)
	BEGIN
		DECLARE @RC INT

		EXECUTE @RC = [dbo].[spGetDVDStubNum] @dttid
			,@num OUTPUT
		
	END
	ELSE
	BEGIN
		UPDATE hlt_DoctorTimeTable
		SET LastStubNum = LastStubNum + 1
		WHERE DoctorTimeTableID = @dttid

		SELECT TOP 1 @num =convert(VARCHAR(5), Begin_Time, 108) + '.' + RIGHT('000' + cast(LastStubNum AS VARCHAR(3)), 3)
		FROM hlt_DoctorTimeTable
		WHERE DoctorTimeTableID = @dttid
	END


	/* Создаем записи в hlt_DoctorVisitTable */
	INSERT INTO hlt_DoctorVisitTable (
		rf_DoctorTimeTableID
		,rf_MKABID
		,Comment
		,Flags
		,fromInternet
		,UGUID
		,NormaUE
		,DateTimeCreate
		,StubNum
		)
	SELECT @dttid
		,@mkabid
		,hlt_MKAB.FAMILY + ' ' + hlt_MKAB.NAME + ' ' + hlt_MKAB.OT + ', ' + cast(datepart(yy, hlt_MKAB.DATE_BD) AS VARCHAR(4)) + ' г.р.'
		,4
		,1
		,newid()
		,1
		,getdate()
		,@num
	FROM hlt_MKAB
	WHERE MKABID = @mkabid
		AND (
			SELECT PlanUE - UsedUE
			FROM hlt_DoctorTimeTable
			WHERE DoctorTimeTableID = @dttid
			) > 0

	COMMIT TRAN

	SET @stubNum = @num
	SET @result = 0
END

go

