CREATE VIEW [V_hlt_FluorTypeResearch] AS SELECT 
[hDED].[FluorTypeResearchID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[Dose] as [Dose], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_FluorTypeResearch] as [hDED]
go

