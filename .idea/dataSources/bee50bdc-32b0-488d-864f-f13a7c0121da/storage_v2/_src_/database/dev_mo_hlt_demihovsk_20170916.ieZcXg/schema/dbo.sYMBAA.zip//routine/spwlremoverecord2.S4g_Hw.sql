
CREATE PROCEDURE [dbo].[spwlRemoveRecord2] @id INT
	,@mkabid INT
	,@result INT OUTPUT
AS
BEGIN
	-- Есть ли такая запись?
	IF NOT EXISTS (
			SELECT 1
			FROM hlt_WaitingList
			WHERE WaitingListID = @id
				AND rf_MKABID = @mkabid
			)
	BEGIN
		SET @result = - 21
	END

	-- Обновим статус
	UPDATE hlt_WaitingList
	SET rf_WaitingListStateID = isnull((
				SELECT TOP 1 WaitingListStateID
				FROM hlt_WaitingListState
				WHERE CODE = '3'
				), 0)
	WHERE WaitingListID = @id

	SET @result = 0
END


go

