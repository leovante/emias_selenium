CREATE VIEW [V_oms_reestr_NSI] AS SELECT 
[hDED].[reestr_NSIID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Num] as [Num], 
[hDED].[Date_Create] as [Date_Create], 
[hDED].[GUID] as [GUID], 
[hDED].[OGRN] as [OGRN], 
[hDED].[Info] as [Info], 
[hDED].[Description] as [Description]
FROM [oms_reestr_NSI] as [hDED]
go

