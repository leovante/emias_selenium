CREATE VIEW [V_oms_SMCriterion] AS SELECT 
[hDED].[SMCriterionID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_SMExpertType].[Name] as [V_Name], 
[hDED].[rf_SMExpertTypeID] as [rf_SMExpertTypeID], 
[hDED].[SMCriterionPrior] as [SMCriterionPrior], 
[hDED].[SMCriterionCode] as [SMCriterionCode], 
[hDED].[SMCriterionSetOn] as [SMCriterionSetOn], 
[hDED].[SMCriterionCaption] as [SMCriterionCaption], 
[hDED].[SMCriterionSource] as [SMCriterionSource], 
[hDED].[SMCriterionDescription] as [SMCriterionDescription], 
[hDED].[SMCriterionRem] as [SMCriterionRem], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Osn] as [Osn], 
[hDED].[PG] as [PG], 
[hDED].[IsReestr] as [IsReestr], 
[hDED].[IsSluch] as [IsSluch], 
[hDED].[IsUsl] as [IsUsl], 
[hDED].[IsPatient] as [IsPatient], 
[hDED].[IsCrit] as [IsCrit], 
[hDED].[GuidSMCriterion] as [GuidSMCriterion]
FROM [oms_SMCriterion] as [hDED]
INNER JOIN [oms_SMExpertType] as [jT_oms_SMExpertType] on [jT_oms_SMExpertType].[SMExpertTypeID] = [hDED].[rf_SMExpertTypeID]
go

