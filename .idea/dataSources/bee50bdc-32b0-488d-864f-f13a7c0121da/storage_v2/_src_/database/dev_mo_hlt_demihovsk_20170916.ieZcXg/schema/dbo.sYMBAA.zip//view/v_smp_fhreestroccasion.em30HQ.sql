CREATE VIEW [V_smp_FHReestrOccasion] AS SELECT 
[hDED].[FHReestrOccasionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[hDED].[rf_JournalCallID] as [rf_JournalCallID], 
[hDED].[flag] as [flag], 
[hDED].[Kol_O] as [Kol_O], 
[hDED].[Kol_V] as [Kol_V], 
[hDED].[Num] as [Num], 
[hDED].[NumRepPer] as [NumRepPer], 
[hDED].[Sum_O] as [Sum_O], 
[hDED].[Sum_V] as [Sum_V], 
[hDED].[UGUID] as [UGUID]
FROM [smp_FHReestrOccasion] as [hDED]
go

