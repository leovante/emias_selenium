
create FUNCTION [dbo].[GetKRRInfo](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int
)
RETURNS  varchar(max)
AS
begin
return (
 select '('+convert(varchar(10),vidid)+','+convert(varchar(20),value)/*+','+info*/+')' +';' as 'data()' 
 from [dbo].[GetKRR](@date, @lpuid,@profileId,@typeid,@usl1 ,@usl2,@mkb ,@age,@dlit)
left join oms_krrvid on vidid= krrvidid
for xml path(''))
end
go

