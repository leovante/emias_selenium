CREATE VIEW [V_smp_FHReestrReturns] AS SELECT 
[hDED].[FHReestrReturnsID], [hDED].[x_Edition], [hDED].[x_Status], 
((select [Name] from oms_ExpertType where ExpertTypeID =   (select  rf_ExpertTypeID from hlt_MHExpert where MHExpertID = hded.rf_MHExpertID))
) as [V_ExpertType], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[hDED].[rf_MHExpertID] as [rf_MHExpertID], 
[hDED].[rf_JournalCallID] as [rf_JournalCallID], 
[hDED].[rf_MedServiceID] as [rf_MedServiceID], 
[hDED].[rf_FHReestrOccasionID] as [rf_FHReestrOccasionID], 
[hDED].[Rem] as [Rem], 
[hDED].[Flag] as [Flag]
FROM [smp_FHReestrReturns] as [hDED]
go

