
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Cardio_Analyze_Month] 
	@riskGroupCode varchar(16),
	@beginPeriod datetime,
	@endPeriod datetime,
	@stepNumber int
AS
BEGIN
	SET NOCOUNT ON;

	--объявления
	-- начало периода
	DECLARE @beginPeriodFloat float
	SET @beginPeriodFloat = CONVERT(float,@beginPeriod)

	-- конец периода
	DECLARE @endPeriodFloat float
	SET @endPeriodFloat = CONVERT(float,@endPeriod)

	-- количество шагов в периоде
	-- счетчик
	DECLARE @counter int
	SET @counter = 0

	-- размер шага (Вещественный)
	DECLARE @stepSizeFloat float
	SET @stepSizeFloat = (CONVERT(float,@endPeriod) - CONVERT(float,@beginPeriod))/@stepNumber

	DECLARE @resultTable table(ExamCount int);
	DECLARE @stepCount int

	WHILE (@counter)<@stepNumber
	BEGIN
		SET @stepCount = NULL;
		
		SELECT TOP 1 @stepCount = count(*)
		FROM
			(SELECT count(*) AS tmpCol
			FROM crd_Examination ex
			INNER JOIN crd_RiskGroup rg ON (ex.rf_RiskGroupID = rg.RiskGroupID)
			WHERE (ExaminationID != 0) 
				   AND (ExamDate BETWEEN CONVERT(datetime,@beginPeriodFloat+@counter*@stepSizeFloat) AND CONVERT(datetime,@beginPeriodFloat+(@counter+1)*@stepSizeFloat))
			       AND (rg.CODE = @riskGroupCode)
			GROUP by rf_MKABGUID) AS tmp
		
		INSERT INTO @resultTable (ExamCount) VALUES (ISNULL(@stepCount,0));
		
		SET @counter = @counter+1;
	END

	SELECT * from @resultTable

END


go

