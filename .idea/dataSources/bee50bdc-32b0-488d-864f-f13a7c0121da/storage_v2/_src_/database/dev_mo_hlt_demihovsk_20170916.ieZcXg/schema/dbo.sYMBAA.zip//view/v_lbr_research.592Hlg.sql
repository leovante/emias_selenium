CREATE VIEW [V_lbr_Research] AS SELECT 
[hDED].[ResearchID], [hDED].[x_Edition], [hDED].[x_Status], 
CONVERT(varchar, jT_lbr_LaboratoryResearch.Date_Direction, 104) + ' ' + jT_lbr_LaboratoryResearch.Pat_Family + ' ' + jT_lbr_ResearchType.ResearchName as [V_Caption], 
((select Upper(substring(ltrim(FAM_V), 1, 1))+ CASE WHEN LEN(FAM_V) > 0  THEN LOWER(SUBSTRING(LTRIM(RTRIM(FAM_V)), 2, LEN(LTRIM(RTRIM(FAM_V))) - 1))  ELSE '' END + ' '  + Upper(substring(ltrim(IM_V), 1, 1)) + '. ' + Upper(substring(ltrim(OT_V), 1, 1)) + '.'
from hlt_LPUDoctor join hlt_DocPRVD on rf_LPUDoctorID = LPUDOctorID where DocPRVDID = [hDed].rf_PerformedDocPRVDID)) as [V_PerformedDocFIO], 
(isnull((select TAPID from hlt_TAP where TAPID = [hDED].[rf_TAPID]), '')) as [V_TapNum], 
(isnull((select m.Num from hlt_MKAB m join lbr_LaboratoryResearch lr on lr.rf_MKABID = MKABID where lr.[GUID] = [hDED].[rf_LaboratoryResearchGUID]), '')) as [V_MKABNum], 
[jT_lbr_ResearchType].[Code] as [V_ResearchCode], 
[jT_lbr_LaboratoryResearch].[Number] as [v_LabNumber], 
[jT_lbr_ResearchType].[ResearchName] as [V_ResearchName], 
[jT_lbr_LaboratoryResearch].[Pat_Ot] as [V_Pat_Ot], 
[jT_lbr_LaboratoryResearch].[Pat_Name] as [V_Pat_Name], 
[jT_lbr_LaboratoryResearch].[Pat_Family] as [V_Pat_Family], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_LabDoctorID] as [rf_LabDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_PerformedDocPRVDID] as [rf_PerformedDocPRVDID], 
[hDED].[rf_ResearchTypeUGUID] as [rf_ResearchTypeUGUID], 
[jT_lbr_ResearchType].[ResearchName] as [SILENT_rf_ResearchTypeUGUID], 
[hDED].[rf_PrevResearchGUID] as [rf_PrevResearchGUID], 
[hDED].[rf_LaboratoryResearchGUID] as [rf_LaboratoryResearchGUID], 
[hDED].[LAB_DOCT_FIO] as [LAB_DOCT_FIO], 
[hDED].[LAB_DOCT_PCOD] as [LAB_DOCT_PCOD], 
[hDED].[Date_Complete] as [Date_Complete], 
[hDED].[isComplete] as [isComplete], 
[hDED].[Comment] as [Comment], 
[hDED].[GUID] as [GUID], 
[hDED].[IsPerformed] as [IsPerformed], 
[hDED].[DatePerformed] as [DatePerformed], 
[hDED].[Flag] as [Flag], 
[hDED].[Conclusion] as [Conclusion], 
[hDED].[Number] as [Number], 
[hDED].[isCanceled] as [isCanceled], 
[hDED].[StudyUID] as [StudyUID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID]
FROM [lbr_Research] as [hDED]
INNER JOIN [lbr_ResearchType] as [jT_lbr_ResearchType] on [jT_lbr_ResearchType].[UGUID] = [hDED].[rf_ResearchTypeUGUID]
INNER JOIN [lbr_LaboratoryResearch] as [jT_lbr_LaboratoryResearch] on [jT_lbr_LaboratoryResearch].[GUID] = [hDED].[rf_LaboratoryResearchGUID]
go

