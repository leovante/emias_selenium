CREATE VIEW [V_oms_FileRegistrationCertificate] AS SELECT 
[hDED].[FileRegistrationCertificateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RegistrationCertificateID] as [rf_RegistrationCertificateID], 
[hDED].[FileName] as [FileName], 
[hDED].[ContentType] as [ContentType], 
[hDED].[Content] as [Content]
FROM [oms_FileRegistrationCertificate] as [hDED]
go

