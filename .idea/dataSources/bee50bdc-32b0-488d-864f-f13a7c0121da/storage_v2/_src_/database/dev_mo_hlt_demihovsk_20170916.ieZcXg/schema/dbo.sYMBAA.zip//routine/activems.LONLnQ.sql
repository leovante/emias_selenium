

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[ActiveMS]()
RETURNS @tmp_ActiveMS TABLE (serviceMedicalID int)
AS
begin
	declare @i int , @count int
	insert into  @tmp_ActiveMS (serviceMedicalID)
	select distinct sm.serviceMedicalID from oms_serviceMedical sm
		inner join oms_Tariff t on t.rf_serviceMedicalID = sm.ServiceMedicalID
		where ServiceMedicalID>0 and t.Date_B<Getdate() and t.Date_E>= GetDate()
			  and sm.Date_B<Getdate() and sm.Date_E>= GetDate()


	--select @i=-1,@count =0 -- для дерева из 2-х уровней можно первый раз не считать

	while(@@rowcount>0)
	begin
		insert into @tmp_ActiveMS(ServiceMedicalID)
		select distinct sm.rf_ServiceMedicalID from oms_serviceMedical sm
			INNER JOIN	@tmp_ActiveMS ams  on ams.ServiceMedicalID = sm.serviceMedicalID
			LEFT JOIN @tmp_ActiveMS pams on pams.ServiceMedicalID=sm.rf_ServiceMedicalID
			where sm.Date_B<Getdate() and sm.Date_E>= GetDate()
				  and pams.ServiceMedicalID is null				  
	--	set @i=@count
	--	select @count =count(1) from @tmp_ActiveMS
	end
	
	RETURN 
end


go

