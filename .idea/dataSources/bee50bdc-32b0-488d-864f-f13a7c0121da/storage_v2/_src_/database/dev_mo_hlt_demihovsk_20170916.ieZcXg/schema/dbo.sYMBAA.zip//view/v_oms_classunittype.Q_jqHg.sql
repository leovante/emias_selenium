CREATE VIEW [V_oms_ClassUnitType] AS SELECT 
[hDED].[ClassUnitTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [oms_ClassUnitType] as [hDED]
go

