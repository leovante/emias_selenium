CREATE VIEW [V_stt_Reanimation] AS SELECT 
[hDED].[ReanimationID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_stt_StationarBranch].[V_BranchInfo] as [V_StationarBranchInfo], 
[jT_stt_MigrationPatient].[rf_MedicalHistoryID] as [V_rf_MedicalHistoryID], 
[jT_stt_MigrationPatient].[rf_StationarBranchID] as [V_rf_StationarBranchID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[hDED].[rf_DiagnosID] as [rf_DiagnosID], 
[hDED].[DateIn] as [DateIn], 
[hDED].[DateOut] as [DateOut], 
[hDED].[duration] as [duration], 
[hDED].[isComplete] as [isComplete], 
[hDED].[flag] as [flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Description] as [Description]
FROM [stt_Reanimation] as [hDED]
INNER JOIN [V_stt_StationarBranch] as [jT_stt_StationarBranch] on [jT_stt_StationarBranch].[StationarBranchID] = [hDED].[rf_StationarBranchID]
INNER JOIN [stt_MigrationPatient] as [jT_stt_MigrationPatient] on [jT_stt_MigrationPatient].[MigrationPatientID] = [hDED].[rf_MigrationPatientID]
go

