-- =============================================
-- Author:		
-- Create date: 
-- Description:	Создаем медицинскую карту пациента
-- =============================================
CREATE PROCEDURE [dbo].[spCreateMKAB_RZ_SNPol] @S_POL VARCHAR(20)
	,@N_POL VARCHAR(20)
	,@date_bd DATETIME
	,@result INT OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET ARITHABORT ON;

	-- Ищем в РЗ
	DECLARE @patid INT

	SET @result = 0;
	SET @patid = isnull((
				SELECT TOP 1 patientid
				FROM V_COD_RZ WITH (NOLOCK)
				WHERE s_pol = @s_pol
					AND n_pol = @n_pol
					AND Birthday = @date_bd
				), 0)

	IF @patid = 0
	BEGIN
		SET @result = 0;

		RETURN
	END

	EXECUTE [dbo].[spCreateMKAB_patid] @patid
		,@result OUTPUT

	RETURN;
END
go

