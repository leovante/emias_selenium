-- =============================================
-- Author:		
-- Create date: 
-- Description:	Создаем медицинскую карту пациента
-- =============================================
CREATE PROCEDURE [dbo].[spCreateMKAB_RZ_PatInfo] @info xml
	,@result INT OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET ARITHABORT ON;

	DECLARE @Birthday DATETIME
	DECLARE @S_POL VARCHAR(50)
	DECLARE @N_POL VARCHAR(50)
	DECLARE @Family VARCHAR(50)
	DECLARE @Name VARCHAR(50)
	DECLARE @Ot VARCHAR(50)
	DECLARE @tmp VARCHAR(500)

	SET @S_POL = ''
	SET @N_POL = ''
	/*Серия полиса ОМС*/
	SET @tmp = @info.query('/PatientInfo/S_POL').value('.', 'varchar(50)')

	IF (@tmp != '')
	BEGIN
		SET @n_pol = ltrim(rtrim(@tmp))
	END

	/*Номер полиса ОМС*/
	SET @tmp = @info.query('/PatientInfo/N_POL').value('.', 'varchar(50)')

	IF (@tmp != '')
	BEGIN
		SET @n_pol = ltrim(rtrim(@tmp))
	END

	/*Дата рождения*/
	SET @tmp = @info.query('/PatientInfo/Birthday').value('.', 'varchar(19)')

	IF (@tmp != '')
	BEGIN
		BEGIN TRY
			SET @tmp = Upper(ltrim(rtrim(left(@tmp, 10))))
			SET @Birthday = (
					SELECT convert(DATETIME, @tmp, 120)
					)
		END TRY

		BEGIN CATCH
			--set @result = -4; /*УПС. Не смогли привести строку к дате. Попробуем найти без даты*/
			--return;
		END CATCH
	END

	EXECUTE [dbo].[spCreateMKAB_RZ_SNPol] @s_pol
		,@n_pol
		,@Birthday
		,@result OUTPUT

	IF @result > 0
	BEGIN
		RETURN
	END

	/*Фамилия*/
	SET @tmp = @info.query('/PatientInfo/Family').value('.', 'varchar(40)')

	IF (@tmp != '')
	BEGIN
		SET @Family = ltrim(rtrim(@tmp))
	END

	/*Имя*/
	SET @tmp = @info.query('/PatientInfo/Name').value('.', 'varchar(40)')

	IF (@tmp != '')
	BEGIN
		SET @Name = ltrim(rtrim(@tmp))
	END

	/*Отчество*/
	SET @tmp = @info.query('/PatientInfo/Patronymic').value('.', 'varchar(40)')

	IF (@tmp != '')
	BEGIN
		SET @Ot = ltrim(rtrim(@tmp))
	END

	EXECUTE [dbo].[spCreateMKAB_RZ_FIO] @Family
		,@Name
		,@Ot
		,@Birthday
		,@result OUTPUT

	RETURN;
END
go

