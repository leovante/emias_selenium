CREATE VIEW [V_hlt_disp_ExamMR] AS SELECT 
[hDED].[disp_ExamMRID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MedRecordGuid] as [rf_MedRecordGuid], 
[jT_hlt_MedRecord].[rf_BlankTemplateID] as [SILENT_rf_MedRecordGuid], 
[hDED].[rf_ExamGuid] as [rf_ExamGuid], 
[jT_hlt_disp_Exam].[rf_ServiceGuid] as [SILENT_rf_ExamGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[EhrMedRecordGuid] as [EhrMedRecordGuid]
FROM [hlt_disp_ExamMR] as [hDED]
INNER JOIN [hlt_MedRecord] as [jT_hlt_MedRecord] on [jT_hlt_MedRecord].[Guid] = [hDED].[rf_MedRecordGuid]
INNER JOIN [hlt_disp_Exam] as [jT_hlt_disp_Exam] on [jT_hlt_disp_Exam].[Guid] = [hDED].[rf_ExamGuid]
go

