CREATE PROCEDURE rptCollectEMIASReport 	
AS
BEGIN
	-- Подразделения ЛПУ
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[rpt_lpuList]') AND type in (N'U'))
DROP TABLE [dbo].[rpt_lpuList]

select 
	 db_name() as DBName,
	 l2.LPUID,
	 l2.C_OGRN,
	 l2.MCOD,
	 l2.m_names,
	 l2.tel,
	 l2.adres,
	 case when l1.LPUID = l2.LPUID then 1 else 0 end as MainLPU,
	 getdate() as [DT]
	 into [dbo].[rpt_lpuList]
from oms_lpu l1, oms_lpu l2
where l1.c_ogrn = (select top 1 valuestr from x_usersettings where property = 'ОГРН поликлиники' and rf_userid = 1)
and l1.mcod = (select top 1 valuestr from x_usersettings where property = 'Код поликлиники' and rf_userid = 1)
and (l1.LPUID = l2.rf_MainLPUID OR l1.LPUID = l2.LPUID)


-- Показатели
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[rpt_ParamList]') AND type in (N'U'))
DROP TABLE [dbo].rpt_ParamList

select db_name() as DBName, period.*, Pt.* into rpt_ParamList 
from 
(
select * from 
(
select 	 l2.MCOD
from oms_lpu l1, oms_lpu l2
where l1.c_ogrn = (select top 1 valuestr from x_usersettings where property = 'ОГРН поликлиники' and rf_userid = 1)
and l1.mcod = (select top 1 valuestr from x_usersettings where property = 'Код поликлиники' and rf_userid = 1)
and (l1.LPUID = l2.rf_MainLPUID OR l1.LPUID = l2.LPUID)
) lpuList,
(
 select datepart(year, getdate()) as year
 union select datepart(year, getdate()) - 1 as year
) as YearList,
(
 select 1 as [month]
 union select 2
 union select 3
 union select 4
 union select 5
 union select 6
 union select 7
 union select 8
 union select 9
 union select 10
 union select 11
 union select 12
) as MonthList
) period
CROSS APPLY [dbo].[rpt_GetReportParamList] (period.MCOD, period.[year], period.[month]) as Pt

-- Переносим на demostend
IF @@SERVERNAME = 'DBMIS01'
BEGIN
-- Сервер
delete from [hlt_demostend].dbo.rpt_lpuList where DBName = db_name()

insert into [hlt_demostend].[dbo].[rpt_lpuList] ([DBName], [LPUID], [C_OGRN], [MCOD], [m_names], [tel], [adres], [MainLPU], [DT])
SELECT [DBName], [LPUID], [C_OGRN], [MCOD], [m_names], [tel], [adres], [MainLPU], [DT] from rpt_lpuList

delete from [hlt_demostend].dbo.rpt_ParamList where DBName = db_name() and [year] in (select datepart(year, getdate()) union select datepart(year, getdate())-1) 

INSERT INTO [hlt_demostend].dbo.[rpt_ParamList] ([DBName],[MCOD],[year],[month],[ParamId],[ParamName],[ParamIntValue])
SELECT [DBName],[MCOD],[year],[month],[ParamId],[ParamName],[ParamIntValue] from rpt_ParamList

END
/*ELSE
BEGIN
-- remote

delete from [46.61.230.73,4201].[hlt_demostend].dbo.rpt_lpuList where DBName = db_name()

insert into [46.61.230.73,4201].[hlt_demostend].[dbo].[rpt_lpuList] ([DBName], [LPUID], [C_OGRN], [MCOD], [m_names], [tel], [adres], [MainLPU], [DT])
SELECT [DBName], [LPUID], [C_OGRN], [MCOD], [m_names], [tel], [adres], [MainLPU], [DT] from rpt_lpuList

delete from [46.61.230.73,4201].[hlt_demostend].dbo.rpt_ParamList where DBName = db_name() and [year] in (select datepart(year, getdate()) union select datepart(year, getdate())-1) 

INSERT INTO [46.61.230.73,4201].[hlt_demostend].dbo.[rpt_ParamList] ([DBName],[MCOD],[year],[month],[ParamId],[ParamName],[ParamIntValue])
SELECT [DBName],[MCOD],[year],[month],[ParamId],[ParamName],[ParamIntValue] from rpt_ParamList
END
*/

END

go

