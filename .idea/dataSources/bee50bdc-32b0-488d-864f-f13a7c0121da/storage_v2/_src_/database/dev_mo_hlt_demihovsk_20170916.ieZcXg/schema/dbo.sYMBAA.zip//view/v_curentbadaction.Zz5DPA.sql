

create view [dbo].[v_CurentBadAction] 
as
select ba.* from stt_Bedaction ba
inner join
(
	select rf_BedID,max(date) date from stt_BedAction
	group by  rf_BedID	
) cba on ba.rf_BedID = cba.rf_BedID and ba.date = cba.date
go

