CREATE VIEW [V_dd_DDRstExp] AS SELECT 
[hDED].[DDRstExpID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[hDED].[rf_DDReestrID] as [rf_DDReestrID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[NumExp] as [NumExp], 
[hDED].[OkCount] as [OkCount], 
[hDED].[BadCount] as [BadCount], 
[hDED].[FLAG] as [FLAG], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[InCount] as [InCount], 
[hDED].[InSum] as [InSum], 
[hDED].[UGUID] as [UGUID], 
[hDED].[OkSum] as [OkSum], 
[hDED].[BadSum] as [BadSum]
FROM [dd_DDRstExp] as [hDED]
go

