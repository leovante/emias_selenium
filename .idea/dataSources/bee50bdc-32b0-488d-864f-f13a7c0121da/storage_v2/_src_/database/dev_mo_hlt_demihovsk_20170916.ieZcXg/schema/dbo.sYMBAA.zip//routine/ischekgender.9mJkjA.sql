
/*
 =============================================
 Author:		Швецова Е.А.
 Create date: 31.01.2011
 Description:	Осуществляется проверка пола на соответствие имени и отчеству, в случае положительного результата, функция возвращает 1
 =============================================
*/
CREATE FUNCTION [dbo].[IsChekGender] 
(	@patPatient varchar(200),@sexName varchar(10) )
RETURNS int
AS
BEGIN
	DECLARE @isTrue int

	if ((@patPatient like '%на') and upper(substring(@sexName, 1, 1))='Ж')
		or ((@patPatient like '%ич') and upper(substring(@sexName, 1, 1))='М')
	select @isTrue=1
	else select @isTrue=0

	RETURN @isTrue

END

go

