CREATE VIEW [V_stt_TypePacking] AS SELECT 
[hDED].[TypePackingID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[COD] as [COD]
FROM [stt_TypePacking] as [hDED]
go

