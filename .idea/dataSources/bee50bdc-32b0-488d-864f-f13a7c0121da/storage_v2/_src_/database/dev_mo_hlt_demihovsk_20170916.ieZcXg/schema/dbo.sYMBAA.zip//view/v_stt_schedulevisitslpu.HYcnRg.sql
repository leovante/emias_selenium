CREATE VIEW [V_stt_ScheduleVisitsLPU] AS SELECT 
[hDED].[ScheduleVisitsLPUID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DoctorVisitTableID] as [rf_DoctorVisitTableID], 
[hDED].[rf_MedServicePatientID] as [rf_MedServicePatientID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[Description] as [Description], 
[hDED].[Date] as [Date], 
[hDED].[UGUID] as [UGUID]
FROM [stt_ScheduleVisitsLPU] as [hDED]
go

