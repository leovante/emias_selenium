

CREATE FUNCTION [dbo].[GetColumnDefault] (@objname as varchar(500),@col_name as varchar(500))  
RETURNS varchar(50) AS  
BEGIN 
	declare @finaldefault varchar(50)

	SELECT top 1 @finaldefault = syscomments.text
	FROM  sysobjects INNER JOIN
             	         syscolumns ON sysobjects.id = syscolumns.id INNER JOIN
                      syscomments ON syscolumns.cdefault = syscomments.id
	WHERE     (sysobjects.xtype IN ('U ')) AND (sysobjects.name = @objname) AND (syscolumns.name = @col_name)

	return (substring(@finaldefault,1,2000))
END


go

