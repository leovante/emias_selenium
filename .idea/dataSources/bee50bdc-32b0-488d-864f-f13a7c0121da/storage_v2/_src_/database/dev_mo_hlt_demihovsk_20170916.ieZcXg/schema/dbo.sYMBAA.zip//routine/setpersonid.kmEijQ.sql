CREATE PROCEDURE dbo.SetPersonID  AS
update oms_DPCPolyclinicRecipe  
set rf_PersonId=PersonID 
from oms_Person where  oms_Person.SS = oms_DPCPolyclinicRecipe.ss_FROM_FILE
 and rf_PersonID=0

update   dbo.oms_DPCPharmacyRecipe
set rf_PersonId=PersonID 
from oms_Person where  oms_Person.SS = oms_DPCPharmacyRecipe.ss_FROM_FILE
 and rf_PersonID=0

go

