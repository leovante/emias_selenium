

create view [dbo].[v_CurrentBadAction] 
as
select ba.* from stt_Bedaction ba
inner join
(
	select rf_BedID,max(date) date from stt_BedAction
	group by  rf_BedID	
) cba on ba.rf_BedID = cba.rf_BedID and ba.date = cba.date

/****** Object:  View [dbo].[v_CurrentBadAction]    Script Date: 04/26/2011 12:13:09 ******/
go

