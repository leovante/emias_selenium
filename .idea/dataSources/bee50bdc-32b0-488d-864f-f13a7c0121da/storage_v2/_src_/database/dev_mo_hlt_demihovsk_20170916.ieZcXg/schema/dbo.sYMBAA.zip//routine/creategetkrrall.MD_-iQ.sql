
CREATE procedure [dbo].[createGetKRRAll] 
 AS
 Begin
   declare @sql nvarchar(max)
 set @sql='
 if exists (select * from sys.all_objects where name =''GetKRRAll'')
 drop function GetKRRAll
 '
 execute sp_executesql @sql
 set @sql='
create FUNCTION [dbo].[GetKRRAll](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int
)
RETURNS @result TABLE (
vidID int,
info varchar(max),
[Value] [decimal](38, 3) NULL

)
AS
begin
INSERT INTO @result
'
 set  @sql=@sql+Replace(Replace(Replace(( select  'select (select krrVidId from oms_krrvid where vidK_Code ='''+convert(varchar(10),vidK_Code)+'''),'''','+
 Replace([Source],'@vid', ''''+convert(varchar(10),vidK_Code)+'''') + 
 case when Row_Number() over (order by ExpertAlgorithmID desc)=1 then ' 
 '  else ' union 
 ' end as 'data()' from oms_krrvid
 inner join oms_ExpertAlgorithm on ExpertAlgorithmID= rf_ExpertAlgorithmID
 where ExpertAlgorithmID>0 and AlgType<=0 and oms_krrvid.date_E>getdate() and oms_krrvid.date_B<=getdate()
 order by ExpertAlgorithmID 
 for xml  path('') ),'&gt;','>'),'&lt;','<'),'&#x0D;','
 ')

 select @sql=@sql+'
 '
 set  @sql=@sql+'
 declare @info varchar(max)
 set @info=''''
'
 set  @sql=@sql+ Replace(Replace(Replace(( 
 select  'declare @vid' +convert(varchar(10),vidK_Code)+' decimal(18,6) set @vid'+ +convert(varchar(10),vidK_Code)+'= isnull((select '+
 Replace([Source],'@vid', ''''+convert(varchar(10),vidK_Code)+'''') +'),0) 
 if (@vid'+convert(varchar(10),vidK_Code)+'<=0) set @info= @info +'' '+convert(varchar(10),vidK_Code)+'=''+convert(varchar(30),@vid'+convert(varchar(10),vidK_Code)+')
 '
as 'data()' 
from oms_krrvid
 inner join oms_ExpertAlgorithm on ExpertAlgorithmID= rf_ExpertAlgorithmID
 where ExpertAlgorithmID>0 and AlgType=-1 and oms_krrvid.date_E>getdate() and oms_krrvid.date_B<=getdate()
 order by ExpertAlgorithmID 
 for xml  path('') ),'&gt;','>'),'&lt;','<'),'&#x0D;','
 ')

  set  @sql=@sql+ '
  INSERT INTO @result 
  '



 set  @sql=@sql+Replace(Replace(Replace(( select  'select (select krrVidId from oms_krrvid where vidK_Code ='''+convert(varchar(10),vidK_Code)+'''),@info,'+
'(select '+[Source]+') where (select ' +[Source]+') >0' +
 case when Row_Number() over (order by ExpertAlgorithmID desc)=1 then ' '  else '  union  
 ' end as 'data()' from oms_krrvid
 inner join oms_ExpertAlgorithm on ExpertAlgorithmID= rf_ExpertAlgorithmID
 where ExpertAlgorithmID>0 and AlgType=2 and oms_krrvid.date_E>getdate() and oms_krrvid.date_B<=getdate()
 order by ExpertAlgorithmID 
 for xml  path('') ),'&gt;','>'),'&lt;','<'),'&#x0D;','
 ')


 select @sql=@sql+'
  return end'
select @sql
execute sp_executesql @sql
 END
go

