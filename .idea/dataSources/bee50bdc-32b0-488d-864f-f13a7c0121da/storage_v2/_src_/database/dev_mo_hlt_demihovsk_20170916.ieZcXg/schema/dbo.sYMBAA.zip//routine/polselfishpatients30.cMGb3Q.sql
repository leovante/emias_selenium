create        FUNCTION [dbo].[PolSelfishPatients30] (@PersID int, @period_begin datetime,@period_end datetime,@KolvoRecv int, @KolvoDay int)  
RETURNS  datetime
as
BEGIN 



declare @reports datetime;
--create TABLE reports  ( d1 datetime,d2 int)

select @reports=d1 from
(
select d1,d2,pid from
(SELECT     DATEADD(day, day1,
                          ((SELECT     MIN(date_VR)
                              FROM        oms_DPCPolyclinicRecipe
                              WHERE     rf_personID = @PersID))) AS d1, SUM(ct) AS d2, pid
FROM         (SELECT     tem1.day1, tem2.day1 AS day2, tem2.ct, tem1.PID1 AS pid
                       FROM          (SELECT     datediff(day,
                                                                          (SELECT     MIN(date_VR)
                                                                            FROM          oms_recipe
                                                                            WHERE      rf_personID = @PersID), date_vr) AS day1, COUNT(*) AS ct, rf_PersonId AS pid1
                                               FROM         oms_DPCPolyclinicRecipe
                                               WHERE      rf_personID = @PersID
                                               GROUP BY date_VR, rf_PersonId) tem1 INNER JOIN
                                                  (SELECT     datediff(day,
                                                                               (SELECT     MIN(date_VR)
                                                                                 FROM          oms_DPCPolyclinicRecipe
                                                                                 WHERE      rf_personID = @PersID), date_vr) AS day1, COUNT(*) AS ct
                                                    FROM          oms_DPCPolyclinicRecipe
                                                    WHERE      rf_personID = @PersID
                                                    GROUP BY date_VR) tem2 ON tem2.day1 < tem1.day1 + @KolvoDay AND (tem1.day1 <= tem2.day1)) t
GROUP BY day1, pid
HAVING      (SUM(ct) >= @KolvoRecv)) pp

where  (d1 between @period_begin and @period_end) )dertbl

--INSERT @tab1
 -- SELECT d1,d2,pid 
 --FROM @reports

 RETURN @reports;
END

go

