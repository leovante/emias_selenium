CREATE VIEW [V_dd_DDResearchLFService] AS SELECT 
[hDED].[DDResearchLFServiceID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_DocInfo], 
[hDED].[rf_LPUDoctorGUID] as [rf_LPUDoctorGUID], 
[hDED].[rf_DDResearchLFID] as [rf_DDResearchLFID]
FROM [dd_DDResearchLFService] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[UGUID] = [hDED].[rf_LPUDoctorGUID]
go

