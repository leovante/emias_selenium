

create view [dbo].[v_CurrentMigrationPatient]
as
select mp.* from stt_MigrationPatient mp
inner join
(
	select rf_medicalHistoryID,max(Dateingoing) DateIngoing from stt_MigrationPatient
	group by rf_medicalHistoryID
)cmp on mp.rf_medicalHistoryID = cmp.rf_medicalHistoryID and mp.DateIngoing = cmp.DateIngoing

go

