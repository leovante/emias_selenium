CREATE VIEW [V_rls_Ntfr_Okdp] AS SELECT 
[hDED].[Ntfr_OkdpID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsNtfrUID] as [rf_ClsNtfrUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[OKDP] as [OKDP], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Ntfr_Okdp] as [hDED]
go

