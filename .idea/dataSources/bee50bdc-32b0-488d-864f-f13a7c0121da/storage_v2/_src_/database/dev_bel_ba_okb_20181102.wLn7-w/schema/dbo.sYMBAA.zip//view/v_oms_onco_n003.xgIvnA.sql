CREATE VIEW [V_oms_onco_N003] AS SELECT 
[hDED].[onco_N003ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[ID_T] as [ID_T], 
[hDED].[DS_T] as [DS_T], 
[hDED].[KOD_T] as [KOD_T], 
[hDED].[T_NAME] as [T_NAME], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN003] as [GUIDN003]
FROM [oms_onco_N003] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
go

