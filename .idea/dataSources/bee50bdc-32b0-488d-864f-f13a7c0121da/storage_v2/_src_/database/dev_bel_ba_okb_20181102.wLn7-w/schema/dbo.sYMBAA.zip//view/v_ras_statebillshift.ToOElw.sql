CREATE VIEW [V_ras_StateBillShift] AS SELECT 
[hDED].[StateBillShiftID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Cod] as [Cod], 
[hDED].[Name] as [Name], 
[hDED].[Action] as [Action]
FROM [ras_StateBillShift] as [hDED]
go

