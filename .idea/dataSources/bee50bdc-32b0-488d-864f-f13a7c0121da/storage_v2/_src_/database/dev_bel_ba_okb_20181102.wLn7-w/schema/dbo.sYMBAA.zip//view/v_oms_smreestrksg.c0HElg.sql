CREATE VIEW [V_oms_SMReestrKSG] AS SELECT 
[hDED].[SMReestrKSGID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[N_KSG] as [N_KSG], 
[hDED].[VER_KSG] as [VER_KSG], 
[hDED].[KSG_PG] as [KSG_PG], 
[hDED].[N_KPG] as [N_KPG], 
[hDED].[KOEF_Z] as [KOEF_Z], 
[hDED].[KOEF_Up] as [KOEF_Up], 
[hDED].[BZTSZ] as [BZTSZ], 
[hDED].[KOEF_D] as [KOEF_D], 
[hDED].[KOEF_U] as [KOEF_U], 
[hDED].[DKK1] as [DKK1], 
[hDED].[DKK2] as [DKK2], 
[hDED].[SL_K] as [SL_K], 
[hDED].[IT_SL] as [IT_SL]
FROM [oms_SMReestrKSG] as [hDED]
go

