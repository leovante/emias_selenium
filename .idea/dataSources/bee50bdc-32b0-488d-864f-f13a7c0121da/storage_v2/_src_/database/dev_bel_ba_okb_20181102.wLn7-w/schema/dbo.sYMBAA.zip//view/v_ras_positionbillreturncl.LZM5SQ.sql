CREATE VIEW [V_ras_PositionBillReturnCL] AS SELECT 
[hDED].[PositionBillReturnCLID], [hDED].[HostPositionBillReturnCLID], [hDED].[x_Edition], [hDED].[x_Status], 
(ISNULL((SELECT top 1  TenderType_Name 
FROM oms_TenderType 
join ras_StoredLS on rf_TenderTypeID = TenderTypeID and hDed.rf_StoredLSID = ras_StoredLS.StoredLSID 
			  and hDed.rf_StoredLSIDHost = ras_StoredLS.HostStoredLSID),'')) as [V_TenderTypeName], 
((isnull((Select top 1 NUM from ras_Series where SeriesID = [jT_ras_StoredLS].rf_SeriesID), '') )) as [V_Series], 
((isnull((Select top 1 c_LSProvider from ras_LSFo where LSFOID = [jT_ras_StoredLS].rf_LSFOID), '') )) as [V_C_LSFO], 
(((isnull((Select top 1 NUM from oms_tender where tenderID = [jT_ras_StoredLS].rf_tenderID), '') ))) as [V_TenderNum], 
((isnull((Select top 1 name from ras_organisation where OrganisationID = [jT_ras_StoredLS].rf_organisationOwnerID), '') )) as [V_Owner], 
((isnull((Select top 1 Name from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId), '') )) as [V_Nomenclature], 
(isnull((select top 1 name from ras_Organisation where [jT_ras_StoredLS].rf_OrganisationByDemandID = OrganisationID), '')) as [V_OrganisationByDemand], 
((Select top 1 Name from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId)) as [V_StoredLS], 
[jT_ras_Series].[SertMSG] as [SertMSG], 
[jT_ras_StoredLS].[Consigment] as [V_Consigment], 
[hDED].[rf_NDSID] as [rf_NDSID], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[hDED].[rf_SeriesID] as [rf_SeriesID], 
[hDED].[rf_SeriesIDHost] as [rf_SeriesIDHost], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_LSFOID] as [rf_LSFOID], 
[hDED].[rf_LSFOIDHost] as [rf_LSFOIDHost], 
[hDED].[rf_SubStoreID] as [rf_SubStoreID], 
[hDED].[rf_SubStoreIDHost] as [rf_SubStoreIDHost], 
[hDED].[rf_BillReturnClientID] as [rf_BillReturnClientID], 
[hDED].[rf_BillReturnClientIDHost] as [rf_BillReturnClientIDHost], 
[hDED].[rf_StatePositionBillReturnCLID] as [rf_StatePositionBillReturnCLID], 
[hDED].[rf_PositionStatusID] as [rf_PositionStatusID], 
[hDED].[rf_DeliveryCLSDateID] as [rf_DeliveryCLSDateID], 
[hDED].[Producer] as [Producer], 
[hDED].[Consigment] as [Consigment], 
[hDED].[Price] as [Price], 
[hDED].[ExpDate] as [ExpDate], 
[hDED].[Count] as [Count], 
[hDED].[PriceBase] as [PriceBase], 
[hDED].[Summa] as [Summa], 
[hDED].[SumNDS] as [SumNDS], 
[hDED].[PriceOPT] as [PriceOPT], 
[hDED].[isSert] as [isSert], 
[hDED].[DateReg] as [DateReg], 
[hDED].[SH_Code] as [SH_Code], 
[hDED].[EAN13] as [EAN13], 
[hDED].[NameLS] as [NameLS], 
[hDED].[Note] as [Note], 
[hDED].[GTD] as [GTD], 
[hDED].[FractionCount] as [FractionCount]
FROM [ras_PositionBillReturnCL] as [hDED]
INNER JOIN [ras_Series] as [jT_ras_Series] on [jT_ras_Series].[SeriesID] = [hDED].[rf_SeriesID] AND  [jT_ras_Series].[HostSeriesID] = [hDED].[rf_SeriesIDHost]
INNER JOIN [ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
go

