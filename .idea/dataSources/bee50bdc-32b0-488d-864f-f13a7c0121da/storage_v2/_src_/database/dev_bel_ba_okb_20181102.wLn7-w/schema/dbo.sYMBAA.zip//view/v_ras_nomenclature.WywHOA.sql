CREATE VIEW [V_ras_Nomenclature] AS SELECT 
[hDED].[NomenclatureID], [hDED].[HostNomenclatureID], [hDED].[x_Edition], [hDED].[x_Status], 
Severability1 * Severability2 as [V_N_FV], 
[jT_ras_Producer].[Name] as [V_Producer], 
[jT_ras_NDS].[NDS_Name] as [V_NDSName], 
[jT_ras_NarcLSType].[Name] as [V_NarcLSType], 
[hDED].[rf_LFID] as [rf_LFID], 
[hDED].[rf_DLSID] as [rf_DLSID], 
[hDED].[rf_VLFID] as [rf_VLFID], 
[hDED].[rf_MLFID] as [rf_MLFID], 
[hDED].[rf_LSID] as [rf_LSID], 
[hDED].[rf_NDSID] as [rf_NDSID], 
[hDED].[rf_ProducerID] as [rf_ProducerID], 
[hDED].[rf_ProducerIDHost] as [rf_ProducerIDHost], 
[hDED].[rf_NarcLSTypeID] as [rf_NarcLSTypeID], 
[hDED].[rf_SpecificID] as [rf_SpecificID], 
[hDED].[rf_NomenGroupID] as [rf_NomenGroupID], 
[jT_ras_NomenGroup].[GroupName] as [SILENT_rf_NomenGroupID], 
[hDED].[rf_RequestTypeID] as [rf_RequestTypeID], 
[jT_ras_RequestType].[Name] as [SILENT_rf_RequestTypeID], 
[hDED].[Name] as [Name], 
[hDED].[M_LF] as [M_LF], 
[hDED].[Cod_RAS] as [Cod_RAS], 
[hDED].[Cod_Nom] as [Cod_Nom], 
[hDED].[V_LF] as [V_LF], 
[hDED].[D_LS] as [D_LS], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[Date_B] as [Date_B], 
[hDED].[EAN13] as [EAN13], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Severability3] as [Severability3], 
[hDED].[Guid] as [Guid], 
[hDED].[DOZ_ME] as [DOZ_ME], 
[hDED].[Severability1] as [Severability1], 
[hDED].[Severability2] as [Severability2], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[Barcode] as [Barcode]
FROM [ras_Nomenclature] as [hDED]
INNER JOIN [ras_Producer] as [jT_ras_Producer] on [jT_ras_Producer].[ProducerID] = [hDED].[rf_ProducerID] AND  [jT_ras_Producer].[HostProducerID] = [hDED].[rf_ProducerIDHost]
INNER JOIN [ras_NDS] as [jT_ras_NDS] on [jT_ras_NDS].[NDSID] = [hDED].[rf_NDSID]
INNER JOIN [ras_NarcLSType] as [jT_ras_NarcLSType] on [jT_ras_NarcLSType].[NarcLSTypeID] = [hDED].[rf_NarcLSTypeID]
INNER JOIN [ras_NomenGroup] as [jT_ras_NomenGroup] on [jT_ras_NomenGroup].[NomenGroupID] = [hDED].[rf_NomenGroupID]
INNER JOIN [ras_RequestType] as [jT_ras_RequestType] on [jT_ras_RequestType].[RequestTypeID] = [hDED].[rf_RequestTypeID]
go

