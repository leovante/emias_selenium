CREATE VIEW [V_oms_onco_N015] AS SELECT 
[hDED].[onco_N015ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ID_TLek_L] as [ID_TLek_L], 
[hDED].[TLek_NAME_L] as [TLek_NAME_L], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN015] as [GUIDN015]
FROM [oms_onco_N015] as [hDED]
go

