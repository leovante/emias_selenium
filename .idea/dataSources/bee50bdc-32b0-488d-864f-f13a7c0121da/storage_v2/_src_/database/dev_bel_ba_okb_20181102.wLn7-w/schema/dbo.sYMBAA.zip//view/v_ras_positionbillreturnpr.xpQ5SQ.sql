CREATE VIEW [V_ras_PositionBillReturnPr] AS SELECT 
[hDED].[PositionBillReturnPrID], [hDED].[HostPositionBillReturnPrID], [hDED].[x_Edition], [hDED].[x_Status], 
((ISNULL((SELECT top 1  TenderType_Name 
FROM oms_TenderType 
join ras_StoredLS on rf_TenderTypeID = TenderTypeID and hDed.rf_StoredLSID = ras_StoredLS.StoredLSID 
			  and hDed.rf_StoredLSIDHost = ras_StoredLS.HostStoredLSID),''))) as [V_TenderTypeName], 
((isnull((Select top 1 Date_E from ras_Series where SeriesID = [jT_ras_StoredLS].rf_SeriesID), '1900-01-01') )) as [V_ExpDate], 
((isnull((Select top 1 name from ras_organisation where OrganisationID = [jT_ras_StoredLS].rf_organisationOwnerID), '') )) as [V_Owner], 
((isnull((Select top 1 NUM from oms_tender where tenderID = [jT_ras_StoredLS].rf_tenderID), '') )) as [V_TenderNum], 
((isnull((Select top 1 name from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId), '') )) as [V_Nomenclature], 
(((isnull((Select top 1 Name from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId), '') ))) as [V_StoredLS], 
((isnull((Select top 1 c_LSProvider from ras_LSFo where LSFOID = [jT_ras_StoredLS].rf_LSFOID), '') )) as [V_C_LSFO], 
((isnull((Select top 1 NUM from ras_Series where SeriesID = [jT_ras_StoredLS].rf_SeriesID), '') )) as [V_Series], 
[jT_ras_StoredLS].[Consigment] as [V_Consigment], 
[hDED].[rf_NDSID] as [rf_NDSID], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_PositionBillEx_OtherID] as [rf_PositionBillEx_OtherID], 
[hDED].[rf_PositionBillEx_OtherIDHost] as [rf_PositionBillEx_OtherIDHost], 
[hDED].[rf_BillReturnProviderID] as [rf_BillReturnProviderID], 
[hDED].[rf_BillReturnProviderIDHost] as [rf_BillReturnProviderIDHost], 
[hDED].[rf_StatePosBillReturnPrID] as [rf_StatePosBillReturnPrID], 
[hDED].[rf_PositionStatusID] as [rf_PositionStatusID], 
[hDED].[rf_DeliveryCLSDateID] as [rf_DeliveryCLSDateID], 
[hDED].[NameLS] as [NameLS], 
[hDED].[Count] as [Count], 
[hDED].[Price] as [Price], 
[hDED].[Summa] as [Summa], 
[hDED].[PriceBase] as [PriceBase], 
[hDED].[SumNDS] as [SumNDS], 
[hDED].[PriceOPT] as [PriceOPT], 
[hDED].[Note] as [Note], 
[hDED].[FractionCount] as [FractionCount], 
[hDED].[Measure] as [Measure], 
[hDED].[MeasureCount] as [MeasureCount]
FROM [ras_PositionBillReturnPr] as [hDED]
INNER JOIN [ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
go

