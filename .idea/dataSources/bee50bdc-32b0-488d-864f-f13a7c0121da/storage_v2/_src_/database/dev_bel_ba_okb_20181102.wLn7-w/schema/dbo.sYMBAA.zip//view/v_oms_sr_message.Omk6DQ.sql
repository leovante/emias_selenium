CREATE VIEW [V_oms_sr_Message] AS SELECT 
[hDED].[sr_MessageID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_sr_MessType].[Post] as [V_Post], 
[jT_oms_sr_MessType].[Rem] as [V_Rem], 
[hDED].[rf_sr_MessTypeID] as [rf_sr_MessTypeID], 
[jT_oms_sr_MessType].[Name] as [SILENT_rf_sr_MessTypeID], 
[hDED].[DateMess] as [DateMess], 
[hDED].[MessageInfo] as [MessageInfo], 
[hDED].[Rem] as [Rem], 
[hDED].[Id1] as [Id1], 
[hDED].[Id2] as [Id2], 
[hDED].[XmlQuery] as [XmlQuery], 
[hDED].[XmlAnswer] as [XmlAnswer], 
[hDED].[Flags] as [Flags]
FROM [oms_sr_Message] as [hDED]
INNER JOIN [oms_sr_MessType] as [jT_oms_sr_MessType] on [jT_oms_sr_MessType].[sr_MessTypeID] = [hDED].[rf_sr_MessTypeID]
go

