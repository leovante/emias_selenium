CREATE VIEW [V_ras_NDS] AS SELECT 
[hDED].[NDSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[NDS_Name] as [NDS_Name], 
[hDED].[Rate_Num] as [Rate_Num], 
[hDED].[Rate_Denom] as [Rate_Denom], 
[hDED].[Rate] as [Rate]
FROM [ras_NDS] as [hDED]
go

