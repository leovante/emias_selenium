CREATE VIEW [V_oms_DocumentHistory] AS SELECT 
[hDED].[DocumentHistoryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DocTypeDefGuid] as [rf_DocTypeDefGuid], 
[hDED].[NewValue] as [NewValue], 
[hDED].[Date] as [Date], 
[hDED].[Editor] as [Editor], 
[hDED].[rf_DocumentGuid] as [rf_DocumentGuid], 
[hDED].[OldValue] as [OldValue], 
[hDED].[rf_ClientApplicationGuid] as [rf_ClientApplicationGuid], 
[hDED].[rf_DocElemDefGuid] as [rf_DocElemDefGuid], 
[hDED].[DocumentHistoryGuid] as [DocumentHistoryGuid]
FROM [oms_DocumentHistory] as [hDED]
go

