CREATE VIEW [V_ras_StateExBill] AS SELECT 
[hDED].[StateExBillID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note], 
[hDED].[Action] as [Action]
FROM [ras_StateExBill] as [hDED]
go

