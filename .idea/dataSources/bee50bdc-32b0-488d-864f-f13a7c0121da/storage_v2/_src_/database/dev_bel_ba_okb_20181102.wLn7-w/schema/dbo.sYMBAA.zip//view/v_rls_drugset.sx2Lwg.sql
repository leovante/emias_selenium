CREATE VIEW [V_rls_DrugSet] AS SELECT 
[hDED].[DrugSetID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[FullName] as [FullName], 
[hDED].[ShortName] as [ShortName], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_DrugSet] as [hDED]
go

