
CREATE FUNCTION [dbo].[ras_ViewListForNomkBuild]()
RETURNS    @ras_ViewListForNomkBuild TABLE (n varchar(max) ,k1 int, k2 int) as
BEGIN
insert @ras_ViewListForNomkBuild
Select 'Будет вставлено новых стран в таблицу ras_Country:' , count(*), count(distinct Name_CNF) from(
	Select Name_CNF from oms_LS
	left outer join ras_Country on Name_CNF=BigName
	where BigName is null
	group by Name_CNF)t
UNION
Select 'Будет вставлено новых производителей в таблицу ras_Producer:', count(*),count(distinct Name_FCT+cast(CountryID as varchar)+cast(HostCountryID as varchar))  from (
	Select Name_FCT,isnull(HostCountryID,999) as HostCountryID,isnull(CountryID,0) as CountryID
	from oms_LS
	left outer join (
		Select HostCountryID,CountryID,BigName from ras_Country
		
		UNION
		Select 999 as HostCountryID,0 as CountryID,Name_CNF from oms_LS
		left outer join ras_Country on Name_CNF=BigName
		where BigName is null
		group by Name_CNF
	)tt  on Name_CNF=BigName
	left outer join [ras_Producer] on substring(Name_FCT, 1, 150)=[Name]
	where [Name] is null
	group by Name_FCT,CountryID,HostCountryID)t
UNION
select 'Будет вставлено новых номенклатур по ключевому полю Cod_RAS в таблицу ras_Nomenclature:' ,count(*),count(distinct Cod_RAS)  from (
					Select  distinct ltrim(rtrim(oms_LS.NAME_MED)) as [Name], 
							4 as rf_NDSID, 
							cast(NOMK_LS as varchar(max)) as Cod_Ras,
							cast(NOMK_LS as varchar(max)) as Cod_Nom, 
			
							isnull((Select top 1 ProducerID from ras_Producer where [Name]=Name_FCT ),0) as rf_ProducerID,
							(Select top 1 NarcLSTypeID from ras_NarcLSType where ras_NarcLSType.Code=oms_NarcType.Code) as rf_NarcLSTypeID
							,oms_LS.rf_LFID rf_LFID,
							oms_LS.rf_DLSID f_DLSID,
							oms_LS.LSID LSID,
							oms_LS.rf_MLFID rf_MLFID,
							oms_LS.M_LF M_LF,
							oms_LS.rf_VLFID rf_VLFID,
							oms_LS.V_LF V_LF,
							oms_LS.MSG_text MSG_text,
							oms_LS.Date_B as Date_B,
							oms_LS.Date_E as Date_E,
							ISNULL(
								(select top 1 SpecificID from ras_Specific where ras_Specific.Code=cast(oms_Spec.Code as varchar)),
								(select top 1 SpecificID from ras_Specific where CODE = '0')) as rf_SpecificID,
							1 zt,
							 isnull( case rls_Nomen.DrugsInpPack when 0 then 1 else rls_Nomen.DrugsInpPack end, case oms_LS.N_FV when 0 then 1 else oms_LS.N_FV end) as [Severability1],
			
							 isnull( case PPackInUPack when 0 then 1 else PPackInUPack end *  
									 case UPackInSPack when 0 then 1 else UPackInSPack end , 1 ) as [Severability2] 
			
							from oms_LS
							left join rls_Nomen on oms_LS.RlsNomenUid = rls_Nomen.UID and oms_LS.RlsNomenUid <> '00000000-0000-0000-0000-000000000000'
							inner join oms_NarcType on NarcTypeID=rf_NarcTypeID
							inner join oms_Spec on SpecID=rf_SpecID
							inner join oms_TRName on trnameID=rf_trnameID
							inner join oms_LF on LFID=rf_LFID
							inner join oms_DLS on DLSID=rf_DLSID
							inner join oms_MNName on mnnameID=rf_mnnameID
							left outer join ras_nomenclature on cast(oms_LS.NOMK_LS as varchar(max)) = ras_nomenclature.Cod_RAS
							where nomenclatureID is null 
								and oms_LS.Date_E > getDate()
								and LSID>0.1)t
UNION
	Select 'Будет обновлено номенклатур по ключевому полю Cod_RAS в таблице ras_Nomenclature:' ,count(*) ,count(distinct Cod_RAS) 
from ras_Nomenclature r
inner join oms_LS ls on LSID=r.rf_LSID


	inner join oms_TRName on trnameID=ls.rf_trnameID
	inner join oms_LF on LFID=ls.rf_LFID
	inner join oms_DLS on DLSID=ls.rf_DLSID
	inner join oms_MNName on mnnameID=ls.rf_mnnameID
	
	inner join oms_Spec on SpecID=rf_SpecID
	inner join oms_NarcType on NarcTypeID=rf_NarcTypeID
	left join rls_Nomen on ls.RlsNomenUid = rls_Nomen.UID and ls.RlsNomenUid <> '00000000-0000-0000-0000-000000000000'
where nomenclatureID > 0 and LSID>0.1 --and r.Date_E>getdate() and oms_LS.Date_E > getDate()
	and  ( /*OR r.rf_LFID<>oms_LS.rf_LFID OR  r.rf_DLSID<>oms_LS.rf_DLSID*/
	rf_ProducerID<>isnull((Select top 1 ProducerID from ras_Producer where [Name]=Name_FCT ),0)
	OR rf_SpecificID<>isnull((select top 1 SpecificID from ras_Specific where ras_Specific.Code=cast(oms_Spec.Code as varchar)),0)
	OR rf_NarcLSTypeID<>isnull((Select top 1 NarcLSTypeID from ras_NarcLSType where ras_NarcLSType.Code=oms_NarcType.Code),0)
	OR Severability1 = 0 OR Severability2 = 0 --OR  Severability1*Severability2 != ls.N_FV
		OR r.Name <> ltrim(rtrim(ltrim(rtrim(ls.NAME_MED)) 	)))

UNION
Select 'Будет закрыто номенклатур по ключевому полю Cod_RAS в таблице ras_Nomenclature:',count(*) ,count(distinct Cod_RAS)
from ras_Nomenclature r
inner join oms_LS ls on LSID=r.rf_LSID
where ls.Date_E <= getDate()  and nomenclatureID <> 0 and r.Date_E>getdate()
UNION
Select 'Будет вставлено новых организаций в таблицу ras_Organisation:',count(*) ,count(distinct cast(CODE as varchar)+OGRN) 
from (
	Select FO_NAMES as [NAME],CFO as Code,FO_OGRN as OGRN,0 as rf_DogovorID,Adres as Address,
	1 as IsActive,Fam_Ruk as NameDir,Fam_Bux as NameBUH,oms_SFO.Tel,oms_SFO.Fax,oms_SFO.E_Mail,
	rf_OKATOID as rf_OKATO,FO_NAMEF as [SNAME]
	from oms_SFO
	left outer join [ras_Organisation] on CFO = Code
	where SFOID>0.1 and CFO <> '' and [ras_Organisation].OGRN is NULL
	group by FO_NAMES,CFO,FO_OGRN,Adres,
	Fam_Ruk,Fam_Bux,oms_SFO.Tel,oms_SFO.Fax,oms_SFO.E_Mail,
	rf_OKATOID,FO_NAMEF
)t
UNION
Select 'Будет вставлено новых провайдеров в таблицу ras_Provider:' ,count(*), count(distinct cast(rf_OrganisationIDHost as varchar)+cast(rf_OrganisationID as varchar)+[NAME])  
from (Select tt.[Name],OrganisationID as rf_OrganisationID,
	HostOrganisationID as rf_OrganisationIDHost
	from (
		Select [NAME],Code,OGRN,rf_DogovorID,Address,
		IsActive,NameDir,NameBUH,Tel,Fax,E_Mail,
		rf_OKATO,[SNAME],HostOrganisationID,OrganisationID from [ras_Organisation]
		where OrganisationID>0
		UNION 
		Select FO_NAMES as [NAME],CFO as Code,FO_OGRN as OGRN,0 as rf_DogovorID,Adres as Address,
		1 as IsActive,Fam_Ruk as NameDir,Fam_Bux as NameBUH,oms_SFO.Tel,oms_SFO.Fax,oms_SFO.E_Mail,
		rf_OKATOID as rf_OKATO,FO_NAMEF as [SNAME],999 as HostOrganisationID,0 as OrganisationID
		from oms_SFO
		left outer join [ras_Organisation] on CFO = Code
		where SFOID>0.1 and [ras_Organisation].OGRN is NULL
		group by FO_NAMES,CFO,FO_OGRN,Adres,
		Fam_Ruk,Fam_Bux,oms_SFO.Tel,oms_SFO.Fax,oms_SFO.E_Mail,
		rf_OKATOID,FO_NAMEF
	)tt 
                inner join oms_SFO on Code=CFO
	left outer join ras_Provider on OrganisationID = rf_OrganisationID
	where CFO <> '' and ras_Provider.[Name] is null
	group by tt.[Name],OrganisationID,HostOrganisationID)t 
UNION
Select 'Будет вставлено новых кодов ЛС ФО в таблицу ras_LSFO:',
	count(*) , 
	count(distinct C_LSProvider+cast(rf_NomenclatureID as varchar)+cast(rf_NomenclatureIDHost as varchar)+ cast(rf_ProviderID as varchar)+cast(rf_ProviderIDHost as varchar))
from(	
	Select distinct nom.NomenclatureID as rf_NomenclatureID,nom.cod_ras+'_'+ cast(oms_CLS.C_PFS as varchar(max)) as C_LSProvider, 
		prov.ProviderID as rf_ProviderID,
		nom.rf_ProducerID as [rf_ProducerID], 
		oms_CLS.C_PFS, 
		nom.HostNomenclatureID as rf_NomenclatureIDHost, 
		999 as rf_ProviderIDHost, CLSID
	from ras_Nomenclature nom
		inner join oms_LS ls on LSID=nom.rf_LSID and LSID > 0
		inner join oms_CLS on ls.LSID= oms_CLS.rf_LSID
		
		
		inner join oms_Tender on TenderID=rf_TenderID  and TenderID > 0 and (rf_StateTenderID = 2 --Контракт подписан
			or not exists(select * from oms_CLS where rf_TenderID = oms_Tender.TenderID and isCOD = 1)) --Контракт не из ЦОДА
		inner join oms_SFO sfo on sfo.SFOID = rf_SFOID
		inner join ras_Organisation org on org.OGRN = sfo.FO_OGRN and sfo.CFO = org.Code
		inner join ras_Provider prov on prov.rf_OrganisationID = org.OrganisationID
		left join ras_LSFO lsfo on cod_ras+'_'+ cast(oms_CLS.C_PFS as varchar(max))=C_LSProvider and NomenclatureID=rf_NomenclatureID and HostNomenclatureID=rf_NomenclatureIDHost	
		
	where len(nom.cod_ras)>1 and lsfo.C_LSProvider is null 
		
		and (nom.cod_ras+'_'+ cast(oms_CLS.C_PFS as varchar(max))) not in 
		(	
			Select 
				distinct cod_ras+'_'+ cast(oms_CLS.C_PFS as varchar(max))
			from ras_Nomenclature
				inner join oms_LS on LSID=ras_Nomenclature.rf_LSID and LSID > 0
				inner join oms_CLS on LSID= oms_CLS.rf_LSID
				left join ras_LSFO on cod_ras+'_'+ cast(oms_CLS.C_PFS as varchar(max))=C_LSProvider and NomenclatureID=rf_NomenclatureID and HostNomenclatureID=rf_NomenclatureIDHost 
			where len(cod_ras)>1 and C_LSProvider is null 
			group by cod_ras, oms_CLS.C_PFS
			having count(cod_ras+'_'+ cast(oms_CLS.C_PFS as varchar(max))) > 1
		)
	group by nom.NomenclatureID,nom.cod_ras, nom.rf_ProducerID ,oms_CLS.C_PFS,prov.ProviderID,nom.HostNomenclatureID, clsID
)t



	
	RETURN 
END
go

