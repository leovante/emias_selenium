CREATE VIEW [V_ras_Inventarisation] AS SELECT 
[hDED].[InventarisationID], [hDED].[HostInventarisationID], [hDED].[x_Edition], [hDED].[x_Status], 
((convert( varchar, [hDED].[Date_B], 104) + ' - ' + convert(varchar, [hDED].[Date_E], 104))) as [V_Period], 
[hDED].[rf_TypeDeliveryID] as [rf_TypeDeliveryID], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_OrganisationIDHost] as [rf_OrganisationIDHost], 
[hDED].[rf_ResponsibleID] as [rf_ResponsibleID], 
[hDED].[rf_ResponsibleIDHost] as [rf_ResponsibleIDHost], 
[hDED].[rf_TypeInventarisationID] as [rf_TypeInventarisationID], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[jT_ras_Store].[StoreName] as [SILENT_rf_StoreID], 
[hDED].[rf_PeriodID] as [rf_PeriodID], 
[hDED].[rf_PeriodIDHost] as [rf_PeriodIDHost], 
[hDED].[rf_DocDescriptionID] as [rf_DocDescriptionID], 
[hDED].[rf_StateInvID] as [rf_StateInvID], 
[hDED].[NUM] as [NUM], 
[hDED].[DocGUID] as [DocGUID], 
[hDED].[Sum] as [Sum], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Compiler] as [Compiler], 
[hDED].[Reason] as [Reason], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[Note] as [Note], 
[hDED].[FLAGS] as [FLAGS]
FROM [ras_Inventarisation] as [hDED]
INNER JOIN [ras_Store] as [jT_ras_Store] on [jT_ras_Store].[StoreID] = [hDED].[rf_StoreID] AND  [jT_ras_Store].[HostStoreID] = [hDED].[rf_StoreIDHost]
go

