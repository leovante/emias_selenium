
CREATE VIEW [dbo].[V_ras_StoredLsSimple] as
select 
stls.rf_NomenclatureID NomenclatureId,
stls.rf_StoredId StoredId,
Count CurrentCount,
stls.CountAll AllCount,
stls.Price,
isnull((Select sum(ras_Reserve.Count) col  from ras_reserve where rf_StateReserveID = 1  and count!=0  and rf_StoredLSID = stls.StoredLSID), 0)  Reserve,
stls.rf_SeriesID SeriesId,
stls.rf_DeliveryCLSDateID DeliveryCLSDateId,
stls.rf_TenderID TenderId,
stls.rf_TenderTypeID TenderTypeId,
stls.rf_OrganisationOwnerID  OrganisationOwnerId,
stls.StoredLSID,
stls.Consigment,
stls.Data,
stls.Count * stls.Price Summa
 from ras_Storedls stls
go

