CREATE VIEW [V_ras_TypeDelivery] AS SELECT 
[hDED].[TypeDeliveryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note], 
[hDED].[Code] as [Code]
FROM [ras_TypeDelivery] as [hDED]
go

