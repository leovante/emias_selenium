CREATE VIEW [V_oms_onco_N014] AS SELECT 
[hDED].[onco_N014ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ID_THir] as [ID_THir], 
[hDED].[THir_NAME] as [THir_NAME], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN014] as [GUIDN014]
FROM [oms_onco_N014] as [hDED]
go

