CREATE VIEW [V_oms_mn_contact] AS SELECT 
[hDED].[mn_contactID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_mn_PersonID] as [rf_mn_PersonID], 
[jT_oms_mn_Person].[V_FIO] as [SILENT_rf_mn_PersonID], 
[hDED].[Phone] as [Phone], 
[hDED].[Phone_Dop] as [Phone_Dop], 
[hDED].[Email] as [Email], 
[hDED].[Email_Dop] as [Email_Dop], 
[hDED].[JobPlace] as [JobPlace], 
[hDED].[JobPosition] as [JobPosition], 
[hDED].[JobInsalubrity] as [JobInsalubrity], 
[hDED].[NoRegistration] as [NoRegistration], 
[hDED].[Comment] as [Comment], 
[hDED].[isActive] as [isActive], 
[hDED].[ContactGuid] as [ContactGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[PhoneM] as [PhoneM]
FROM [oms_mn_contact] as [hDED]
INNER JOIN [V_oms_mn_Person] as [jT_oms_mn_Person] on [jT_oms_mn_Person].[mn_PersonID] = [hDED].[rf_mn_PersonID]
go

