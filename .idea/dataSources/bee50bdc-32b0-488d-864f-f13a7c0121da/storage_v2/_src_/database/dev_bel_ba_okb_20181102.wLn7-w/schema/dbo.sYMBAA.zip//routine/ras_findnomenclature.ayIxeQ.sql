
Create FUNCTION [dbo].[ras_FindNomenclature]
(
  @C_LSFO varchar(40), @Nomk_LS bigint, @C_PFS decimal(18,0), @CODEOWNER varchar(50)
)
RETURNS int
AS
BEGIN
    declare @LSFOID int
    set @LSFOID = -1    
	declare @NomenclatureID int
    set @NomenclatureID = -1
/*********************************************************************/
select top 1 @LSFOID = lsfo.LSFOID
from ras_LSFO lsfo
inner join ras_Provider prov on prov.ProviderID = lsfo.rf_ProviderID 
           and prov.HostProviderID = lsfo.rf_ProviderIDHost   
inner join ras_Organisation org on org.OrganisationID = prov.rf_OrganisationID 
           and org.HostOrganisationID = prov.rf_OrganisationIDHost
where C_LSProvider = @C_LSFO and org.code =convert(varchar(max),@CODEOWNER)
if @LSFOID<0
begin
  select top 1 @LSFOID = LSFOID
  from ras_LSFO
  where C_LSProvider = 
    RTrim(Convert(char,@Nomk_LS))+'_'+RTrim(Convert(char,@C_PFS))
end 
/*********************************************************************/
    select @NomenclatureID = rf_NomenclatureID
    from ras_LSFO
    where LSFOID =@LSFOID 
RETURN @NomenclatureID 
END
go

