CREATE VIEW [V_hlt_disp_ServiceType] AS SELECT 
[hDED].[disp_ServiceTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[IsMedRecord] as [IsMedRecord], 
[hDED].[IsHealthIndex] as [IsHealthIndex], 
[hDED].[IsDiagnose] as [IsDiagnose], 
[hDED].[IsMedService] as [IsMedService], 
[hDED].[IsLaboratory] as [IsLaboratory]
FROM [hlt_disp_ServiceType] as [hDED]
go

