CREATE TRIGGER [LifeTrigger_hlt_TAP] ON [hlt_TAP] FOR DELETE,INSERT,UPDATE
AS 

SET NOCOUNT ON;

DECLARE @userId INT
DECLARE @seanceId INT 

DECLARE @docTypeId INT 
DECLARE @CURDATE DATETIME


declare @app varchar(50)
declare @index1 int
declare @index2 int


/* @userId, @seanceId */

SET @userId = 0
SET @seanceId = 0

EXEC [GetMalibuContext] @seanceId = @seanceId OUTPUT, @userId = @userId OUTPUT

/* @docTypeId */

SET @CURDATE = getdate()

SET @docTypeId = 0

SELECT TOP 1 @docTypeId = [DocTypeDefID], @seanceId=case WHEN [x_STDO].[HostID] IS NULL THEN @seanceId ELSE 0 END
FROM [x_DocTypeDef] left join [x_STDO] on [x_DocTypeDef].[GUID] = [x_STDO].[DocTypeDef] 
WHERE [HeadTable] = 'hlt_TAP'

/* action type */

DECLARE @DEL BIT
DECLARE @INS BIT 

DECLARE @action CHAR(1)


SET @DEL = 0
SET @INS = 0


IF EXISTS (SELECT TOP 1 1 FROM DELETED) SET @DEL=1
IF EXISTS (SELECT TOP 1 1 FROM INSERTED) SET @INS = 1 

IF @INS = 1 AND @DEL = 1 SET @ACTION = 'u'
IF @INS = 1 AND @DEL = 0 SET @ACTION = 'i'
IF @INS = 0 AND @DEL = 1 SET @ACTION = 'd'


IF @ACTION = 'd'
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [TAPID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM deleted;

	INSERT INTO Life_hlt_TAP([TAPID],[CareEnd],[CarePersonAge],[CarePersonSex],[CreateUserName],[DateClose],[DateCreateTAP],[DateTAP],[Description],[DisabilityStatus],[EditUserName],[FAMILY],[FlagBill],[Flags],[FlagStatist],[IsClosed],[isDVNClosed],[isWorker],[N_POL],[NumInOtherSystem],[rf_CreateUserID],[rf_DepartmentID],[rf_DirectionID],[rf_DocPRVDID],[rf_EditUserID],[rf_INVID],[rf_KATLID],[rf_kl_DiseaseType2ID],[rf_kl_DiseaseTypeID],[rf_kl_DispRegState2ID],[rf_kl_DispRegStateID],[rf_kl_HealthGroupID],[rf_kl_MedCareTypeID],[rf_kl_PatientStatusID],[rf_kl_ProfitTypeID],[rf_kl_ReasonInvID],[rf_kl_ReasonTypeID],[rf_kl_RegistrationEndReason2ID],[rf_kl_RegistrationEndReasonID],[rf_kl_SanitationID],[rf_kl_SickListReasonID],[rf_kl_SocStatusID],[rf_kl_StatCureResultID],[rf_kl_TraumaTypeID],[rf_kl_VisitPlaceID],[rf_kl_VisitResultID],[rf_LPUDoctor_SID],[rf_LPUDoctorID],[rf_MKABID],[rf_MKABSheetFinalDSID],[rf_MKB2ID],[rf_MKBExternalID],[rf_MKBID],[rf_mkp_CardGUID],[rf_NotWorkDocStatusID],[rf_OtherSMOID],[rf_OutcomeVisitID],[rf_PolisMKABID],[rf_ReasonCareID],[rf_RegistrPatientID],[rf_SMOID],[rf_SpecEventCertID],[rf_TypeTAPID],[S_POL],[CareBegin],[UGUID],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [TAPID],[CareEnd],[CarePersonAge],[CarePersonSex],[CreateUserName],[DateClose],[DateCreateTAP],[DateTAP],[Description],[DisabilityStatus],[EditUserName],[FAMILY],[FlagBill],[Flags],[FlagStatist],[IsClosed],[isDVNClosed],[isWorker],[N_POL],[NumInOtherSystem],[rf_CreateUserID],[rf_DepartmentID],[rf_DirectionID],[rf_DocPRVDID],[rf_EditUserID],[rf_INVID],[rf_KATLID],[rf_kl_DiseaseType2ID],[rf_kl_DiseaseTypeID],[rf_kl_DispRegState2ID],[rf_kl_DispRegStateID],[rf_kl_HealthGroupID],[rf_kl_MedCareTypeID],[rf_kl_PatientStatusID],[rf_kl_ProfitTypeID],[rf_kl_ReasonInvID],[rf_kl_ReasonTypeID],[rf_kl_RegistrationEndReason2ID],[rf_kl_RegistrationEndReasonID],[rf_kl_SanitationID],[rf_kl_SickListReasonID],[rf_kl_SocStatusID],[rf_kl_StatCureResultID],[rf_kl_TraumaTypeID],[rf_kl_VisitPlaceID],[rf_kl_VisitResultID],[rf_LPUDoctor_SID],[rf_LPUDoctorID],[rf_MKABID],[rf_MKABSheetFinalDSID],[rf_MKB2ID],[rf_MKBExternalID],[rf_MKBID],[rf_mkp_CardGUID],[rf_NotWorkDocStatusID],[rf_OtherSMOID],[rf_OutcomeVisitID],[rf_PolisMKABID],[rf_ReasonCareID],[rf_RegistrPatientID],[rf_SMOID],[rf_SpecEventCertID],[rf_TypeTAPID],[S_POL],[CareBegin],[UGUID],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM deleted;
END;
ELSE
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [TAPID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM inserted;

	INSERT INTO Life_hlt_TAP([TAPID],[CareEnd],[CarePersonAge],[CarePersonSex],[CreateUserName],[DateClose],[DateCreateTAP],[DateTAP],[Description],[DisabilityStatus],[EditUserName],[FAMILY],[FlagBill],[Flags],[FlagStatist],[IsClosed],[isDVNClosed],[isWorker],[N_POL],[NumInOtherSystem],[rf_CreateUserID],[rf_DepartmentID],[rf_DirectionID],[rf_DocPRVDID],[rf_EditUserID],[rf_INVID],[rf_KATLID],[rf_kl_DiseaseType2ID],[rf_kl_DiseaseTypeID],[rf_kl_DispRegState2ID],[rf_kl_DispRegStateID],[rf_kl_HealthGroupID],[rf_kl_MedCareTypeID],[rf_kl_PatientStatusID],[rf_kl_ProfitTypeID],[rf_kl_ReasonInvID],[rf_kl_ReasonTypeID],[rf_kl_RegistrationEndReason2ID],[rf_kl_RegistrationEndReasonID],[rf_kl_SanitationID],[rf_kl_SickListReasonID],[rf_kl_SocStatusID],[rf_kl_StatCureResultID],[rf_kl_TraumaTypeID],[rf_kl_VisitPlaceID],[rf_kl_VisitResultID],[rf_LPUDoctor_SID],[rf_LPUDoctorID],[rf_MKABID],[rf_MKABSheetFinalDSID],[rf_MKB2ID],[rf_MKBExternalID],[rf_MKBID],[rf_mkp_CardGUID],[rf_NotWorkDocStatusID],[rf_OtherSMOID],[rf_OutcomeVisitID],[rf_PolisMKABID],[rf_ReasonCareID],[rf_RegistrPatientID],[rf_SMOID],[rf_SpecEventCertID],[rf_TypeTAPID],[S_POL],[CareBegin],[UGUID],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [TAPID],[CareEnd],[CarePersonAge],[CarePersonSex],[CreateUserName],[DateClose],[DateCreateTAP],[DateTAP],[Description],[DisabilityStatus],[EditUserName],[FAMILY],[FlagBill],[Flags],[FlagStatist],[IsClosed],[isDVNClosed],[isWorker],[N_POL],[NumInOtherSystem],[rf_CreateUserID],[rf_DepartmentID],[rf_DirectionID],[rf_DocPRVDID],[rf_EditUserID],[rf_INVID],[rf_KATLID],[rf_kl_DiseaseType2ID],[rf_kl_DiseaseTypeID],[rf_kl_DispRegState2ID],[rf_kl_DispRegStateID],[rf_kl_HealthGroupID],[rf_kl_MedCareTypeID],[rf_kl_PatientStatusID],[rf_kl_ProfitTypeID],[rf_kl_ReasonInvID],[rf_kl_ReasonTypeID],[rf_kl_RegistrationEndReason2ID],[rf_kl_RegistrationEndReasonID],[rf_kl_SanitationID],[rf_kl_SickListReasonID],[rf_kl_SocStatusID],[rf_kl_StatCureResultID],[rf_kl_TraumaTypeID],[rf_kl_VisitPlaceID],[rf_kl_VisitResultID],[rf_LPUDoctor_SID],[rf_LPUDoctorID],[rf_MKABID],[rf_MKABSheetFinalDSID],[rf_MKB2ID],[rf_MKBExternalID],[rf_MKBID],[rf_mkp_CardGUID],[rf_NotWorkDocStatusID],[rf_OtherSMOID],[rf_OutcomeVisitID],[rf_PolisMKABID],[rf_ReasonCareID],[rf_RegistrPatientID],[rf_SMOID],[rf_SpecEventCertID],[rf_TypeTAPID],[S_POL],[CareBegin],[UGUID],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM inserted;
END; 

SET NOCOUNT OFF;


go

