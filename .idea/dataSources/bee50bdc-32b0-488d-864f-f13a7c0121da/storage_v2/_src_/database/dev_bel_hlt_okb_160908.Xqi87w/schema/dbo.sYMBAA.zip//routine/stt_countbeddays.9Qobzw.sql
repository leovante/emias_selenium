create function [dbo].[stt_CountBedDays](@DayBegin datetime, @DayEnd datetime,@StateCode int, @StationarBrunchID int, @BedProfile int)
returns int
/* 
функция считает кол-во койко-дней 
в периоде с @DayBegin по @DayEnd 
так же учитывает статус койки @StateCode
и отделение с профилем койки(@StationarBrunchID, @BedProfile). 
Если отделение или профиль задать как 0, то по этому парраметру считаться не будет.
*/
begin
    declare @bedSum int
    --подсчет количества занятых коек каждого дня
    select  @bedSum=0
    while (@DayBegin<@DayEnd)
    begin
        --считаем количество занятых коек на начало дня
        select @bedSum=@bedSum+count(1) from stt_bed
            inner join stt_Ward on rf_wardID = wardID
            inner join stt_BedStatus stat on rf_bedStatusID = BedStatusID
            inner join stt_BedAction ba on rf_bedid=bedID
            inner join
            (
                select rf_bedID, max(date) Date from stt_BedAction
                where date<=@dayBegin
                group by rf_bedID
            ) lastAction on ba.rf_bedID=lastAction.rf_bedID and ba.Date = lastAction.date
            inner join stt_ActionType at on rf_actionTypeID = ActionTypeID
            where bedID>0  
                  and at.code=@StateCode -- текущее состояние койки(1: занята, 3: на ремонте)
                  and ba.date <= @dayBegin
                  and stat.code = '01'
                   and ((rf_StationarBranchID = @StationarBrunchID)or(@StationarBrunchID = 0 ))
and( (rf_BedProfileID = @BedProfile) or @BedProfile = 0 )

        set @dayBegin= dateadd(day,1,@dayBegin)        
    end

    return @bedSum
end
go

