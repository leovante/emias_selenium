CREATE FUNCTION middleYearBed ( @DateBegin datetime, @BedProfileID int)
RETURNS int
AS
BEGIN
declare @middleYear int /*среднегодовое кол-во коек*/
set @middleYear = (
Select AVG(num) from 
(
    Select COUNT(B.BedID) num from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID where (DATEADD(MONTH,0,B.DateWorkE) >@DateBegin) and B.rf_BedProfileID = @BedProfileID and BS.Code = '01'
    UNION ALL
    Select COUNT(B.BedID) num from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID where (DATEADD(MONTH,1,B.DateWorkE) >@DateBegin) and B.rf_BedProfileID = @BedProfileID and BS.Code = '01'
    UNION ALL
    Select COUNT(B.BedID) num from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID where (DATEADD(MONTH,2,B.DateWorkE) >@DateBegin) and B.rf_BedProfileID = @BedProfileID and BS.Code = '01'
    UNION ALL
    Select COUNT(B.BedID) num from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID where (DATEADD(MONTH,3,B.DateWorkE) >@DateBegin) and B.rf_BedProfileID = @BedProfileID and BS.Code = '01'
    UNION ALL
    Select COUNT(B.BedID) num from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID where (DATEADD(MONTH,4,B.DateWorkE) >@DateBegin) and B.rf_BedProfileID = @BedProfileID and BS.Code = '01'
    UNION ALL
    Select COUNT(B.BedID) num from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID where (DATEADD(MONTH,5,B.DateWorkE) >@DateBegin) and B.rf_BedProfileID = @BedProfileID and BS.Code = '01'
    UNION ALL
    Select COUNT(B.BedID) num from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID where (DATEADD(MONTH,6,B.DateWorkE) >@DateBegin) and B.rf_BedProfileID = @BedProfileID and BS.Code = '01'
    UNION ALL
    Select COUNT(B.BedID) num from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID where (DATEADD(MONTH,7,B.DateWorkE) >@DateBegin) and B.rf_BedProfileID = @BedProfileID and BS.Code = '01'
    UNION ALL
    Select COUNT(B.BedID) num from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID where (DATEADD(MONTH,8,B.DateWorkE) >@DateBegin) and B.rf_BedProfileID = @BedProfileID and BS.Code = '01'
    UNION ALL
    Select COUNT(B.BedID) num from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID where (DATEADD(MONTH,9,B.DateWorkE) >@DateBegin) and B.rf_BedProfileID = @BedProfileID and BS.Code = '01'
    UNION ALL
    Select COUNT(B.BedID) num from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID where (DATEADD(MONTH,10,B.DateWorkE) >@DateBegin)and B.rf_BedProfileID = @BedProfileID and BS.Code = '01'
    UNION ALL
    Select COUNT(B.BedID) num from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID where (DATEADD(MONTH,11,B.DateWorkE) >@DateBegin)and B.rf_BedProfileID = @BedProfileID and BS.Code = '01'
  ) kl
  )
return @middleYear
end
go

