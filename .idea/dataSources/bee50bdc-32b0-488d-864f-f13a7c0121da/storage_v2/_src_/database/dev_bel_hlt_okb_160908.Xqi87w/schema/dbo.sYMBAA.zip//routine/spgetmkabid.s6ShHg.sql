CREATE PROCEDURE [dbo].[spGetMKABID]
	@input xml,
	@result int output
AS
BEGIN
	SET @result = 0
    -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET ARITHABORT ON;

	declare @filtr varchar(4000)
	set @filtr = ''
	/* Формируем фильтр */
	BEGIN TRY		
		
		/*Фамилия*/
		declare @tmp varchar(100)
		set @tmp = @input.query('/PatientInfo/Family').value('.', 'varchar(40)')
		if (@tmp != '')
		begin		
			 set @tmp = replace(@tmp, '''', '''''') /*Экранируем кавычки*/
			 set @filtr = ' (Upper(ltrim(rtrim(Family))) = ''' + Upper(ltrim(rtrim(@tmp))) + ''') '		
		end

		/*Имя*/
		set @tmp = @input.query('/PatientInfo/Name').value('.', 'varchar(40)')
		if (@tmp != '')
		begin
			set @tmp = replace(@tmp, '''', '''''') /*Экранируем кавычки*/
			if (@filtr != '') set @filtr = @filtr + ' AND '
			set @filtr = @filtr + ' (Upper(ltrim(rtrim(Name))) = ''' + Upper(ltrim(rtrim(@tmp))) + ''') '		
		end

		/*Отчество*/
		set @tmp = @input.query('/PatientInfo/Patronymic').value('.', 'varchar(40)')
		if (@tmp != '')
		begin
			set @tmp = replace(@tmp, '''', '''''') /*Экранируем кавычки*/
			if (@filtr != '') set @filtr = @filtr + ' AND '
			set @filtr = @filtr + ' (Upper(ltrim(rtrim(OT))) = ''' + Upper(ltrim(rtrim(@tmp))) + ''') '		
		end

		/*Серия полиса ОМС*/
		set @tmp = @input.query('/PatientInfo/S_POL').value('.', 'varchar(50)')
		if (@tmp != '')
		begin
			set @tmp = replace(@tmp, '''', '''''') /*Экранируем кавычки*/
			if (@filtr != '') set @filtr = @filtr + ' AND '
			set @filtr = @filtr + ' (RIGHT (replace(replace(S_POL , '' '', ''''), ''-'', ''''), 6) = ''' + RIGHT(replace(replace(@tmp , ' ', ''), '-', ''), 6)  + ''') '		
		end

		/*Номер полиса ОМС*/
		set @tmp = @input.query('/PatientInfo/N_POL').value('.', 'varchar(50)')
		if (@tmp != '')
		begin
			set @tmp = replace(@tmp, '''', '''''') /*Экранируем кавычки*/
			if (@filtr != '') set @filtr = @filtr + ' AND '
			set @filtr = @filtr + ' (Upper(ltrim(rtrim(N_POL))) = ''' + Upper(ltrim(rtrim(@tmp))) + ''') '		
		end

		/*Дата рождения*/
		set @tmp = @input.query('/PatientInfo/Birthday').value('.', 'varchar(19)')
		if (@tmp != '')
		begin
			set @tmp = replace(@tmp, '''', '''''') /*Экранируем кавычки*/
			BEGIN TRY
				set @tmp = Upper(ltrim(rtrim(left(@tmp,10))))

				declare @tmpdate datetime
				set @tmpdate = (select convert(datetime, @tmp , 120))

				if (@filtr != '') set @filtr = @filtr + ' AND '
				set @filtr = @filtr + ' (Upper(ltrim(rtrim(DATE_BD))) = convert(datetime, ''' + @tmp   + ''', 120)) '					
			END TRY
			BEGIN CATCH
				--set @result = -4; /*УПС. Не смогли привести строку к дате. Попробуем найти без даты*/
				--return;
			END CATCH
		end

		/* Идентификатор Ш/К */
		set @tmp = @input.query('/PatientInfo/GUID8').value('.', 'varchar(8)')
		if (@tmp != '')
		begin
			set @tmp = replace(@tmp, '''', '''''') /*Экранируем кавычки*/
			if (@filtr != '') set @filtr = @filtr + ' AND '
			set @filtr = @filtr + ' (Upper(left(uguid, 8)) = ''' + Upper(left(@tmp, 8)) + ''') '	
		end

		/* Идентификатор RIDN */
		set @tmp = @input.query('/PatientInfo/RIDN').value('.', 'varchar(4)')
		if ((@tmp != '') and (len(@tmp) = 4))
		begin
			set @tmp = replace(@tmp, '''', '''''') /*Экранируем кавычки*/
			if (@filtr != '') set @filtr = @filtr + ' AND '
			set @filtr = @filtr + ' (Upper(ltrim(rtrim(RIDN))) = ''' + Upper(ltrim(rtrim(@tmp))) + ''') '
		end

		/* Идентификатор Номер телефона */
		set @tmp = @input.query('/PatientInfo/Phone').value('.', 'varchar(20)')
		/*Оставляем только цифры*/
		while patindex('%[^0-9]%',@tmp)<>0
			set @tmp = replace(@tmp,substring(@tmp,patindex('%[^0-9]%',@tmp),1),'')
		if ((@tmp != '') and (Len(@tmp) = 11) and ( CHARINDEX('7', @tmp) = 1))
		begin	
			if (@filtr != '') set @filtr = @filtr + ' AND '
			set @filtr = @filtr + ' (Upper(ltrim(rtrim(contactMPhone))) = ''' + Upper(ltrim(rtrim(@tmp))) + ''') '
		end																				 

	END TRY
	BEGIN CATCH
		set @result = -10; /*УПС. Упали на разборе XML строки*/
		return;
	END CATCH

	/* Фильтр есть, пробуем загрузить данные */

	declare @cnt int;
	declare @MKABID int;
	declare @BlackLabel int;

	
	declare @cmd nvarchar(max)
	set @cmd = '
	select @cnt1 = count(MKABID), @MKABID1 = isnull(min(MKABID), 0), @BlackLabel1=isnull(min(BlackLabel), 0)
	from hlt_MKAB
	where ' + @filtr;

	BEGIN TRY
		exec sp_executesql @cmd, N'@cnt1 int out, @MKABID1 int out, @BlackLabel1 int out', @cnt1 = @cnt out , @MKABID1 = @MKABID out, @BlackLabel1 = @BlackLabel out
	END TRY
	BEGIN CATCH
		set @result = -999; /*УПС. Не смогли выполнить запрос.*/
		return;
	END CATCH

	if (@cnt = 0)
	begin
		/*Нет такой записи. Создадим.*/
		--EXECUTE spCreateMkabFromRZ @input, @result OUTPUT
		set @result = -3;
		return;
	end

	if (@cnt > 1)
	begin
		set @result = -4; --Больше одной МКАБ
		return;
	end

	if (@cnt = 1)
	begin
		set @result = @MKABID;	
/*
		if (@BlackLabel != 0)
			set @result = -6
		else
			set @result = @MKABID;*/
		return;
	end

END
go

