CREATE VIEW [V_lbr_BioM] AS SELECT 
[hDED].[BioMID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[CodeLis] as [CodeLis], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [lbr_BioM] as [hDED]
go

