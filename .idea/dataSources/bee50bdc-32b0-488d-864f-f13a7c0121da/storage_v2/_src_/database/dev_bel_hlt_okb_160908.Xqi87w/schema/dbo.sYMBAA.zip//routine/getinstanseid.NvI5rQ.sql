
CREATE FUNCTION [dbo].[GetInstanseId] 
(
	@Date XML,
	@ID VARCHAR(100)
)
RETURNS VARCHAR(100)
AS
BEGIN
	RETURN ISNULL((select t.n.value('@instanceid', 'nvarchar(max)') as [value]
												from 
												(SELECT @Date as [data])ttt cross apply ttt.data.nodes('*:root/*:element') t(n)
												where t.n.value('@id', 'nvarchar(max)') in (@ID)),'')
END
go

