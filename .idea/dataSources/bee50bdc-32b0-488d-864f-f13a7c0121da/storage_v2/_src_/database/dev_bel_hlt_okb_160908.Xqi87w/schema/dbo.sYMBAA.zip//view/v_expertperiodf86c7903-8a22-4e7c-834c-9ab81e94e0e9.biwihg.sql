CREATE view [V_ExpertPeriodf86c7903-8a22-4e7c-834c-9ab81e94e0e9] as select * from [tmp_ExpertPeriodf86c7903-8a22-4e7c-834c-9ab81e94e0e9]
go

