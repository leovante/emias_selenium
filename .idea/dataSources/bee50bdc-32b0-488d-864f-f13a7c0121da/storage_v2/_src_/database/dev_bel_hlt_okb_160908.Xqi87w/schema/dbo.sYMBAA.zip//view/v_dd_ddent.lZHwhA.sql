CREATE VIEW [V_dd_DDENT] AS SELECT 
[hDED].[DDENTID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[hDED].[rf_OKVEDID] as [rf_OKVEDID], 
[hDED].[rf_DDScheduleGUID] as [rf_DDScheduleGUID], 
[hDED].[NumENT] as [NumENT], 
[hDED].[INN] as [INN], 
[hDED].[KPP] as [KPP], 
[hDED].[OGRN] as [OGRN], 
[hDED].[SName] as [SName], 
[hDED].[NDOG] as [NDOG], 
[hDED].[RNP] as [RNP], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDENT] as [hDED]
go

