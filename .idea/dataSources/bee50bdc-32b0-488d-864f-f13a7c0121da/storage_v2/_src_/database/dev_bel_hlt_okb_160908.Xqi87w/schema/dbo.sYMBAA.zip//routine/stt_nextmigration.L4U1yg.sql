
CREATE function [dbo].[stt_NextMigration](@MedicalHistoryID int,@MigrationPatientID int)
returns int
begin
 
declare @NexMigrationPatientID int
declare @DateIngoing datetime
select @DateIngoing=dateingoing from stt_MigrationPatient where MigrationPatientID = @MigrationPatientID
 
select top 1 @NexMigrationPatientID=MigrationPatientID from stt_MigrationPatient
where rf_MedicalHistoryID = @MedicalHistoryID and DateIngoing > @DateIngoing
order by DateIngoing 
 
      return @NexMigrationPatientID
end
go

