
-- =============================================
-- Author:		Татьяна Абаньшина
-- Create date: 2015-05-05
-- Description:	Проставляет состояние для реестра
-- =============================================
create  PROCEDURE [dbo].[UpdateReportPeriodState](@idReestr int,@idReestrMH int,@code varchar(20), @name varchar(max)='', @xml xml='', @rem varchar(250)='')
	
AS
BEGIN
SET NOCOUNT ON;
DECLARE @userId INT
DECLARE @seanceId INT 
DECLARE @stateId INT 
SET @userId = 0
SET @seanceId = 0

EXEC [GetMalibuContext] @seanceId = @seanceId OUTPUT, @userId = @userId OUTPUT


if not exists (select * from [hlt_ReportPeriodState] where Code = @code)
		insert into hlt_ReportPeriodState (Code, name, Rem) select @code, 
		@name, 
		'Добавлено пользователем '+isnull((select FIO from x_User where UserId =@userId),'Администратор')

select @stateId= ReportPeriodStateId from  hlt_ReportPeriodState
where Code = @code

INSERT INTO [hlt_ReportPeriodDateState]
           ([Date]
           ,[LastUserId]
           ,[Param]
           , Rem           
           ,[rf_ReestrMHID]
           ,[rf_ReportPeriodID]
           ,[rf_ReportPeriodStateID])
    
select     getdate(), @userId, @xml,@rem, @idReestrMH, @idReestr, @stateId



update hlt_ReportPeriod set rf_ReportPeriodStateId = @stateId
where @idReestr = ReportPeriodID



END
go

