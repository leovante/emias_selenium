
CREATE TRIGGER [dbo].[stop_update_protocol]
   ON  [dbo].[x_TransportProtocol] 
   INSTEAD OF UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
	UPDATE [dbo].[x_TransportProtocol]
	SET [TP_GUID] = i.[TP_GUID]
       ,[TP_Name] = i.TP_Name
       ,[TP_DATA] = i.TP_DATA
       ,[DocTypeDefName] = i.DocTypeDefName
       ,[Title] = i.Title
       ,[ProtocolType] = i.ProtocolType
       ,[LinkedTableName] = i.LinkedTableName
       ,[x_Edition] = i.x_Edition
       ,[x_Status] = i.x_Status
	FROM [x_TransportProtocol] tp
		inner join inserted i
			on tp.TransportProtocolID = i.TransportProtocolID
	WHERE substring(i.TP_Data, patindex('%<VER>%', i.TP_Data ) + 5, patindex('%</VER>%', i.TP_Data )-patindex('%<VER>%', i.TP_Data ) -5) > substring(tp.TP_Data, patindex('%<VER>%', tp.TP_Data ) + 5, patindex('%</VER>%', tp.TP_Data )-patindex('%<VER>%', tp.TP_Data ) -5)
END
go

