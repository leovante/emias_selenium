CREATE VIEW [V_atf_FileAttachment] AS SELECT 
[hDED].[FileAttachmentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FileInfoID] as [rf_FileInfoID], 
[jT_atf_FileInfo].[DateDoc] as [SILENT_rf_FileInfoID], 
[hDED].[Num] as [Num], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[rf_CreateUserID] as [rf_CreateUserID], 
[hDED].[CreateUserName] as [CreateUserName], 
[hDED].[Path] as [Path], 
[hDED].[Guid] as [Guid], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags]
FROM [atf_FileAttachment] as [hDED]
INNER JOIN [atf_FileInfo] as [jT_atf_FileInfo] on [jT_atf_FileInfo].[FileInfoID] = [hDED].[rf_FileInfoID]
go

