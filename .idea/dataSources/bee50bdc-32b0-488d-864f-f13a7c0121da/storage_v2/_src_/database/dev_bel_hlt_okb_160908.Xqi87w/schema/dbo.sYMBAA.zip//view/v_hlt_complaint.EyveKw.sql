CREATE VIEW [V_hlt_Complaint] AS SELECT 
[hDED].[ComplaintID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [hlt_Complaint] as [hDED]
go

