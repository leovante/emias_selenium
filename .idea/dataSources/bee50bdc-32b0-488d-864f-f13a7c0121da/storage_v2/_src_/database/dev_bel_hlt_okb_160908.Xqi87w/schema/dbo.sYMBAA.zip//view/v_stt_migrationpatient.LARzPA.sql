CREATE VIEW [V_stt_MigrationPatient] AS SELECT 
[hDED].[MigrationPatientID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_MKB].[DS] as [V_DS], 
[jT_stt_MedicalHistory].[FAMILY] as [V_Family], 
[jT_stt_MedicalHistory].[MedCardNum] as [V_MedCardNum], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[hDED].[rf_AttendingDocPRVSID] as [rf_AttendingDocPRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_AttendingDocPRVSID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_AttendedDoctorID] as [rf_AttendedDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_AttendedDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_AttendingDocPRVDID] as [rf_AttendingDocPRVDID], 
[jT_hlt_DocPRVD1].[Name] as [SILENT_rf_AttendingDocPRVDID], 
[hDED].[rf_kl_VisitResultID] as [rf_kl_VisitResultID], 
[jT_oms_kl_VisitResult].[Name] as [SILENT_rf_kl_VisitResultID], 
[hDED].[rf_kl_StatCureResultID] as [rf_kl_StatCureResultID], 
[jT_oms_kl_StatCureResult].[Name] as [SILENT_rf_kl_StatCureResultID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[rf_MedStandartID] as [rf_MedStandartID], 
[jT_stt_MedStandart].[Name] as [SILENT_rf_MedStandartID], 
[hDED].[rf_InterruptEventID] as [rf_InterruptEventID], 
[jT_stt_InterruptEvent].[Name] as [SILENT_rf_InterruptEventID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[jT_stt_StationarBranch].[V_BranchInfo] as [SILENT_rf_StationarBranchID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_DiagnosID] as [rf_DiagnosID], 
[hDED].[rf_MigrationReasonID] as [rf_MigrationReasonID], 
[hDED].[rf_BedProfileID] as [rf_BedProfileID], 
[jT_stt_BedProfile].[Name] as [SILENT_rf_BedProfileID], 
[hDED].[rf_ExpertKSGCriterionID] as [rf_ExpertKSGCriterionID], 
[jT_oms_ExpertKSGCriterion].[GUIDExpertKSGCriterion] as [SILENT_rf_ExpertKSGCriterionID], 
[hDED].[DateIngoing] as [DateIngoing], 
[hDED].[DateOut] as [DateOut], 
[hDED].[BedDays] as [BedDays], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag], 
[hDED].[IsThrombTherapy] as [IsThrombTherapy], 
[hDED].[OpenDateNWD] as [OpenDateNWD], 
[hDED].[CloseDateNWD] as [CloseDateNWD], 
[hDED].[S_NWD] as [S_NWD], 
[hDED].[N_NWD] as [N_NWD]
FROM [stt_MigrationPatient] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [stt_MedicalHistory] as [jT_stt_MedicalHistory] on [jT_stt_MedicalHistory].[MedicalHistoryID] = [hDED].[rf_MedicalHistoryID]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_AttendingDocPRVSID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_AttendedDoctorID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD1] on [jT_hlt_DocPRVD1].[DocPRVDID] = [hDED].[rf_AttendingDocPRVDID]
INNER JOIN [oms_kl_VisitResult] as [jT_oms_kl_VisitResult] on [jT_oms_kl_VisitResult].[kl_VisitResultID] = [hDED].[rf_kl_VisitResultID]
INNER JOIN [oms_kl_StatCureResult] as [jT_oms_kl_StatCureResult] on [jT_oms_kl_StatCureResult].[kl_StatCureResultID] = [hDED].[rf_kl_StatCureResultID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
INNER JOIN [stt_MedStandart] as [jT_stt_MedStandart] on [jT_stt_MedStandart].[MedStandartID] = [hDED].[rf_MedStandartID]
INNER JOIN [stt_InterruptEvent] as [jT_stt_InterruptEvent] on [jT_stt_InterruptEvent].[InterruptEventID] = [hDED].[rf_InterruptEventID]
INNER JOIN [V_stt_StationarBranch] as [jT_stt_StationarBranch] on [jT_stt_StationarBranch].[StationarBranchID] = [hDED].[rf_StationarBranchID]
INNER JOIN [stt_BedProfile] as [jT_stt_BedProfile] on [jT_stt_BedProfile].[BedProfileID] = [hDED].[rf_BedProfileID]
INNER JOIN [oms_ExpertKSGCriterion] as [jT_oms_ExpertKSGCriterion] on [jT_oms_ExpertKSGCriterion].[ExpertKSGCriterionID] = [hDED].[rf_ExpertKSGCriterionID]
go

