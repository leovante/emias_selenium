-- =============================================
-- Author:		Шумаков Сергей
-- Create date: 03.11.2011
-- Description:	Процедура возвращает все записи листа ожидания
-- в формате xml
-- =============================================
CREATE PROCEDURE [spwlGetWaitingListRecords] 
	@MKABID int,
	@result xml output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from

	SET NOCOUNT ON;

	SET DATEFIRST 1

declare @tmp_tab TABLE
(
	WaitingListId int,	
	V_Family varchar(50),
	V_Name varchar (25), 
	V_Ot varchar (25),		
	PRVSName varchar (255),	
	DateFrom DateTime,
	DateTo DateTime,
	HourFrom int,
	HourTo int,
	TicketCount int,
	TicketNeedToConfirm int,
	TicketID int	
)

insert into @tmp_tab
select WaitingListID as WaitingListId
	,isnull(doc.Fam_V, '') as V_Family
	,isnull(doc.IM_V, '') as V_Name
	,isnull(doc.OT_V, '') as V_Ot
	,case 
		when (wl.rf_PRVSID > 0) and (oms_PRVS.PRVSID is not null) then oms_PRVS.PRVS_NAME
		when (wl.rf_DocPRVDID > 0) and (hlt_DocPRVD.DocPRVDID is not null) then
			case 
				when hlt_DocPRVD.rf_PRVSID > 0 then isnull((select top 1 p.PRVS_NAME from oms_PRVS p where p.prvsid = hlt_DocPRVD.rf_PRVSID), '')
				else ''
			end
		else ''  end as PRVSName
	, wl.DateFrom
	, wl.DateTo
	, wl.HourFrom
	, wl.HourTo
	, wl.TicketCount as TicketCount
	, case when wl.rf_DoctorVisitTableID > 0 and TicketLiveTime > getdate() then 1 else 0 end as TicketNeedToConfirm
	, wl.rf_DoctorVisitTableID as TicketID
from hlt_WaitingList wl	
	left join hlt_DocPRVD 
		on wl.rf_DocPRVDID = hlt_DocPRVD.DocPRVDID and hlt_DocPRVD.DocPRVDID > 0
	left join hlt_LPUDoctor doc
		on doc.LPUDoctorID = hlt_DocPRVD.rf_LPUDoctorID and doc.LPUDoctorID > 0
	left join oms_PRVS
		on wl.rf_PRVSID = oms_PRVS.PRVSID and oms_PRVS.PRVSID > 0
where wl.WaitingListID > 0 and wl.rf_MKABID = @MKABID and wl.DateTo >= getdate()


	set @result =
	(SELECT tt.* FROM 
(
select distinct
		1 as Tag,
		0 as Parent,
		null as [GetWaitingListRecordsResult!1],
		'true'   as [GetWaitingListRecordsResult!1!Result],
		0    as [GetWaitingListRecordsResult!1!Code],		
		null as [Records!2],
		null as [Record!3!WaitingListId!Element],
		null as [Record!3!V_Family!Element],
		null as [Record!3!V_Name!Element],
		null as [Record!3!V_Ot!Element],
		null as [Record!3!PRVSName!Element],
		null as [Record!3!DateFrom!Element],
		null as [Record!3!DateTo!Element],	
		null as [Record!3!HourFrom!Element],	
		null as [Record!3!HourTo!Element],
		null as [Record!3!TicketCount!Element],	
		null as [Record!3!TicketNeedToConfirm!Element],
		null as [Record!3!TicketID!Element]
UNION ALL
	select distinct
		2 as Tag,
		1 as Parent,
		null as [GetWaitingListRecordsResult!1],
		null   as [GetWaitingListRecordsResult!1!Result],
		null    as [GetWaitingListRecordsResult!1!Code],		
		null as [Records!2],
		null as [Record!3!WaitingListId!Element],	
		null as [Record!3!V_Family!Element],
		null as [Record!3!V_Name!Element],
		null as [Record!3!V_Ot!Element],
		null as [Record!3!PRVSName!Element],
		null as [Record!3!DateFrom!Element],
		null as [Record!3!DateTo!Element],	
		null as [Record!3!HourFrom!Element],	
		null as [Record!3!HourTo!Element],
		null as [Record!3!TicketCount!Element],	
		null as [Record!3!TicketNeedToConfirm!Element],
		null as [Record!3!TicketID!Element]
	from @tmp_tab
UNION ALL
	select distinct
		3 as Tag,
		2 as Parent,
		null as [GetWaitingListRecordsResult!1],
		null as [GetWaitingListRecordsResult!1!Result],
		null as [GetWaitingListRecordsResult!1!Code],		
		null as [Records!2],
		WaitingListId as [Record!3!WaitingListId!Element],	
		V_Family as [Record!3!V_Family!Element],
		V_Name as [Record!3!V_Name!Element],
		V_Ot as [Record!3!V_Ot!Element],
		PRVSName as [Record!3!PRVSName!Element],
		DateFrom as [Record!3!DateFrom!Element],
		DateTo as [Record!3!DateTo!Element],	
		HourFrom as [Record!3!HourFrom!Element],	
		HourTo as [Record!3!HourTo!Element],
		TicketCount as [Record!3!TicketCount!Element],	
		TicketNeedToConfirm as [Record!3!TicketNeedToConfirm!Element],
		TicketID as [Record!3!TicketID!Element]
	from @tmp_tab
) tt
ORDER BY TAG,
convert(datetime, isnull([Record!3!DateFrom!Element], '2222-01-01T00:00:00'), 104) desc,
isnull([Record!3!HourFrom!Element], 0) desc
FOR XML EXPLICIT, TYPE
)

END
go

