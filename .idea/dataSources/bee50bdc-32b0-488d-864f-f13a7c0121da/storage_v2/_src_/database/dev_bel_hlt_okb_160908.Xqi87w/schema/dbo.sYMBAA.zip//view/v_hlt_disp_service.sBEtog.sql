CREATE VIEW [V_hlt_disp_Service] AS SELECT 
[hDED].[disp_ServiceID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DispTypeGuid] as [rf_DispTypeGuid], 
[jT_hlt_disp_Type].[Name] as [SILENT_rf_DispTypeGuid], 
[hDED].[rf_ServiceTypeGuid] as [rf_ServiceTypeGuid], 
[jT_hlt_disp_ServiceType].[Name] as [SILENT_rf_ServiceTypeGuid], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[ShortName] as [ShortName], 
[hDED].[Description] as [Description], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Ratio] as [Ratio], 
[hDED].[IsMain] as [IsMain], 
[hDED].[SequenceIndex] as [SequenceIndex]
FROM [hlt_disp_Service] as [hDED]
INNER JOIN [hlt_disp_Type] as [jT_hlt_disp_Type] on [jT_hlt_disp_Type].[Guid] = [hDED].[rf_DispTypeGuid]
INNER JOIN [hlt_disp_ServiceType] as [jT_hlt_disp_ServiceType] on [jT_hlt_disp_ServiceType].[Guid] = [hDED].[rf_ServiceTypeGuid]
go

