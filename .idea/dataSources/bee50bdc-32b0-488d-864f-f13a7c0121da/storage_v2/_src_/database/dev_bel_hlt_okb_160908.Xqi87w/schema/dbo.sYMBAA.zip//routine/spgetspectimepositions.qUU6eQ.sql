


-- =============================================
-- Author:		Шумаков Сергей
-- Create date: 28.08.2008
-- Description:	Процедура возвращает позиции расписания заданного врача за указанный период с флагом "занято" в виде xml
-- =============================================
CREATE PROCEDURE [spGetSpecTimePositions] 
	@PRVS_NAME varchar(100),
	@Date datetime,
	@result xml output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SET DATEFIRST 1

	declare @tmp_tab TABLE
	(
	Date datetime,
	DTTID int,
	BeginTime varchar(5),
	BusyFlag int,
	BusyCode int
	)

	insert into @tmp_tab
	select	dtt.Date  as Date,
			dtt.DoctorTimeTableID  as DTTID,		
			CASE 
			when (DATEPART(hh, dtt.Begin_Time) < 10) 
			then '0' + Convert(varchar(1), DATEPART(hh, dtt.Begin_Time))
			else Convert(varchar(2), DATEPART(hh, dtt.Begin_Time))
			end 
			+ ':'
			+
			CASE 
			when (DATEPART(mi, dtt.Begin_Time) < 10)
			then '0' + Convert(varchar(1), DATEPART(mi, dtt.Begin_Time))
			else Convert(varchar(2), DATEPART(mi, dtt.Begin_Time))
			end  as BeginTime,	
					CASE 
						WHEN isnull(dvt.DoctorVisitTableID, 0) = 0 THEN  0
						WHEN (dtt.FlagAccess & 4) = 0 THEN 1
						ELSE 1
					END as BusyFlag,
			dbt.CODE as BusyCode
	from hlt_DoctorTimeTable dtt
	left join hlt_DoctorVisitTable dvt
		on  dvt.rf_DoctorTimeTableID = dtt.DoctorTimeTableID
	inner join hlt_LPUDoctor doc
		on dtt.rf_LPUDoctorID = doc.LPUDoctorID --		and doc.PCOD = @pcod
	inner join oms_prvs prvs on doc.rf_prvsid = prvs.PRVSID
			and prvs.PRVS_NAME = @PRVS_NAME
	inner join hlt_DocBusyType dbt
		on dtt.rf_DocBusyType = dbt.DocBusyTypeID
/*
2010-05-03 Изменил условие для записи на осмотры в 4 детской поликлиники
*/
		--and dbt.CODE = 4
		and dbt.TypeBusy = 1
		
	where	dtt.date = @date
		and dtt.Begin_Time <> '1900-01-01T00:00:00' -- отсекаем записи вне очереди
		-- Еще фильтр по правам доступа		
		--and (dtt.FlagAccess & 4) > 0
	order by dtt.Date, BeginTime


	set @result = 
	(
		select t.* from 
		(
			SELECT 
				   1    as Tag,
				   NULL as Parent,
				   NULL as [GetDoctorTimePositionsResult!1],	   
				   'true' as [GetDoctorTimePositionsResult!1!Result],
				   0 as [GetDoctorTimePositionsResult!1!Code],
				   NULL as [DayShedul!2],
				   NULL as [DayShedul!2!Date],
				   NULL as [DayShedul!2!DayOfWeek],
				   null as [ShedulPos!3],
				   --null as [ShedulPos!3!PosID],
				   null as [ShedulPos!3!BusyFlag]
				  -- null as [ShedulPos!3!BusyCode]
			UNION ALL
			SELECT distinct
				   2    as Tag,
				   1 as Parent,
				   NULL as [GetDoctorTimePositionsResult!1],	   
				   null as [GetDoctorTimePositionsResult!1!Result],
				   null as [GetDoctorTimePositionsResult!1!Code],
				   null as [DayShedul!2],
				   Date as [DayShedul!2!Date],
				   DATEPART(dw, Date) as [DayShedul!2!DayOfWeek],
				   null as [ShedulPos!3],
				  -- null as [ShedulPos!3!PosID],
				   null as [ShedulPos!3!BusyFlag]
				  -- null as [ShedulPos!3!BusyCode]	
			from @tmp_tab
			UNION ALL
			SELECT distinct
				   3    as Tag,
				   2 as Parent,
				   NULL as [GetDoctorTimePositionsResult!1],	   
				   null as [GetDoctorTimePositionsResult!1!Result],
				   null as [GetDoctorTimePositionsResult!1!Code],
				   null as [DayShedul!2],
				   Date as [DayShedul!2!Date],
				   DATEPART(dw, Date) as [DayShedul!2!DayOfWeek],
				   BeginTime as [ShedulPos!3],
				   --DTTID as [ShedulPos!3!PosID],
				   min(BusyFlag) as [ShedulPos!3!BusyFlag]
				   --BusyCode as [ShedulPos!3!BusyCode]	
			from @tmp_tab 
			group by Date, BeginTime
		) t
		order by [DayShedul!2!Date], [ShedulPos!3]
		FOR XML EXPLICIT, TYPE
	)
	

END


go

