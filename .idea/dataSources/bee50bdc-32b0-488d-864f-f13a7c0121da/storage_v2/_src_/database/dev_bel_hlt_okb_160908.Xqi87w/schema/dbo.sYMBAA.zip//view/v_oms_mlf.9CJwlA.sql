CREATE VIEW [V_oms_MLF] AS SELECT 
[hDED].[MLFID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_MLF] as [C_MLF], 
[hDED].[NAME_MLF] as [NAME_MLF], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[GUIDMLF] as [GUIDMLF]
FROM [oms_MLF] as [hDED]
go

