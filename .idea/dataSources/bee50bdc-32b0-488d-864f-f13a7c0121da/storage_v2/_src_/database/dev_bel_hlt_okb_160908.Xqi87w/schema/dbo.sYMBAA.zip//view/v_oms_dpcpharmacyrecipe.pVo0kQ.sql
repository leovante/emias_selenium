CREATE VIEW [V_oms_DPCPharmacyRecipe] AS SELECT 
[hDED].[DPCPharmacyRecipeID], [hDED].[x_Edition], [hDED].[x_Status], 
Series_Recipe + ' ' + LTRIM(convert(varchar, Num_Recipe)) as [SeriesNum_Recipe], 
((( case hDED.rf_PersonRegLGID WHEN 0 THEN

		(CASE hDED.rf_PersonID WHEN 0 THEN 

		(select top 1 oms_PERSONDLO.SS_DLO 
		from oms_PERSONDLO where PERSONDLOID=hDED.rf_PERSONDLOID) 

		ELSE 
		(select top 1 SS from oms_Person where PersonID=hDED.rf_PersonID) END )
	ELSE 
		(select top 1 SS from oms_PersonRegLG where PersonRegLGID=hDED.rf_PersonRegLGID) END ))) as [SS], 
(case hDED.FLAGS &1
 when 0x1 then 'Удален (' 
 else ''
end + 
((((case hDED.FLAGS & 0x76 
when 0x0 then 'Отпущен' 
when 0x10 then 'Взят на отсроченное обслуживание' 
when 0x20 then ' Отсутствие ЛС' 
when 0x30 then 'Отказ от ЛС' 
when 0x40 then 'Неявка пациента' 
when 0x50 then 'Перевыписать в ЛПУ' 
else 'Некорректные флаги' end)))) +
case hDED.FLAGS &1
 when 0x1 then ')' 
 else ''
end) as [RecipeState], 
((( case hDED.rf_PersonRegLGID WHEN 0 THEN

		(CASE hDED.rf_PersonID WHEN 0 THEN 

		(select top 1 ((([FAM]+' '+ [IM]+' '+[OT])))
		from oms_PERSONDLO where PERSONDLOID=hDED.rf_PERSONDLOID) 

		ELSE 
		(select top 1 FAMILY+' '+NAME+' '+Patronymic from oms_Person where PersonID=hDED.rf_PersonID) END )
	ELSE 
		(select top 1 (FAMILY+' '+NAME+' '+Patronymic)  from oms_PersonRegLG where PersonRegLGID=hDED.rf_PersonRegLGID) END ))) as [V_PatientFIO], 
(( (((((case [hDED].FLAGS ^ 0x100000
	 when 0x100000  then 'Считан со сканера'
	else  
	  'Ручной ввод'
	end))))))) as [V_Status], 
(((( case hDED.rf_PersonRegLGID WHEN 0 THEN

		(CASE hDED.rf_PersonID WHEN 0 THEN 

		(select top 1 (DR )
		from oms_PERSONDLO where PERSONDLOID=hDED.rf_PERSONDLOID) 

		ELSE 
		(select top 1 DR from oms_Person where PersonID=hDED.rf_PersonID) END )
	ELSE 
		(select top 1 (DR)  from oms_PersonRegLG where PersonRegLGID=hDED.rf_PersonRegLGID) END )))) as [V_PatientDR], 
(		((( case hDED.rf_PersonRegLGID WHEN 0 THEN

		(CASE hDED.rf_PersonID WHEN 0 THEN 

		(select top 1 W
		from oms_PERSONDLO where PERSONDLOID=hDED.rf_PERSONDLOID) 

		ELSE 
		(select top 1 case W when 1 then 'М' else 'Ж' end from oms_Person where PersonID=hDED.rf_PersonID) END )
	ELSE 
		(select top 1 case W when 1 then 'М' else 'Ж' end from oms_PersonRegLG where PersonRegLGID=hDED.rf_PersonRegLGID) END )))
) as [V_W], 
[jT_oms_DOCTOR].[V_M_NAMES] as [VV_M_NAMES], 
[jT_oms_CLS].[V_NAME_MED] as [V_NAME_MED], 
[jT_oms_DOCTOR].[V_C_OGRN] as [VV_C_OGRN], 
[jT_oms_MNName].[NAME_MNN] as [V_NAME_MNN], 
[jT_oms_APU].[P_NAMES] as [V_P_NAMES], 
[hDED].[rf_TRNameID] as [rf_TRNameID], 
[hDED].[rf_MNNameID] as [rf_MNNameID], 
[hDED].[rf_LFID] as [rf_LFID], 
[hDED].[rf_DLSID] as [rf_DLSID], 
[hDED].[rf_LSID] as [rf_LSID], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_SFOID] as [rf_SFOID], 
[hDED].[rf_PersonID] as [rf_PersonID], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[hDED].[rf_DOCTORID] as [rf_DOCTORID], 
[jT_oms_DOCTOR].[DOCTOR_FIO] as [SILENT_rf_DOCTORID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[hDED].[rf_RecipeDefinitionID] as [rf_RecipeDefinitionID], 
[hDED].[rf_PR_LRID] as [rf_PR_LRID], 
[hDED].[rf_PeriodID] as [rf_PeriodID], 
[hDED].[rf_ARecipe_ReestrID] as [rf_ARecipe_ReestrID], 
[jT_oms_ARecipe_Reestr].[Recipe_Reestr_Num] as [SILENT_rf_ARecipe_ReestrID], 
[hDED].[rf_APUID] as [rf_APUID], 
[hDED].[rf_DPCPharmacyRecipeReestrID] as [rf_DPCPharmacyRecipeReestrID], 
[hDED].[rf_CLSID] as [rf_CLSID], 
[jT_oms_CLS].[C_PFS] as [SILENT_rf_CLSID], 
[hDED].[rf_AccountID] as [rf_AccountID], 
[hDED].[rf_PERSONDLOID] as [rf_PERSONDLOID], 
[hDED].[rf_DpcLpuPharmacyRecipeReestrID] as [rf_DpcLpuPharmacyRecipeReestrID], 
[hDED].[rf_PersonRegLGID] as [rf_PersonRegLGID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[hDED].[DATE_OTP] as [DATE_OTP], 
[hDED].[PRICE] as [PRICE], 
[hDED].[KO_ALL] as [KO_ALL], 
[hDED].[Delayed_Service] as [Delayed_Service], 
[hDED].[DOZ_LS] as [DOZ_LS], 
[hDED].[DATE_VR] as [DATE_VR], 
[hDED].[KV_ALL] as [KV_ALL], 
[hDED].[KEK_State] as [KEK_State], 
[hDED].[Series_Recipe] as [Series_Recipe], 
[hDED].[Num_Recipe] as [Num_Recipe], 
[hDED].[RecipeGUID] as [RecipeGUID], 
[hDED].[D_Type] as [D_Type], 
[hDED].[NumExport] as [NumExport], 
[hDED].[DateExport] as [DateExport], 
[hDED].[StatusEdition] as [StatusEdition], 
[hDED].[DateObr] as [DateObr], 
[hDED].[Hash] as [Hash], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[SS_From_File] as [SS_From_File], 
[hDED].[Description] as [Description], 
[hDED].[Count_ALL] as [Count_ALL], 
[hDED].[Sum_ALL] as [Sum_ALL], 
[hDED].[Comment] as [Comment], 
[hDED].[attribute] as [attribute], 
[hDED].[LPURecipeGUID] as [LPURecipeGUID], 
[hDED].[DateChange] as [DateChange], 
[hDED].[Phone] as [Phone]
FROM [oms_DPCPharmacyRecipe] as [hDED]
INNER JOIN [V_oms_DOCTOR] as [jT_oms_DOCTOR] on [jT_oms_DOCTOR].[DOCTORID] = [hDED].[rf_DOCTORID]
INNER JOIN [V_oms_CLS] as [jT_oms_CLS] on [jT_oms_CLS].[CLSID] = [hDED].[rf_CLSID]
INNER JOIN [oms_MNName] as [jT_oms_MNName] on [jT_oms_MNName].[MNNameID] = [hDED].[rf_MNNameID]
INNER JOIN [oms_APU] as [jT_oms_APU] on [jT_oms_APU].[APUID] = [hDED].[rf_APUID]
INNER JOIN [oms_ARecipe_Reestr] as [jT_oms_ARecipe_Reestr] on [jT_oms_ARecipe_Reestr].[ARecipe_ReestrID] = [hDED].[rf_ARecipe_ReestrID]
go

