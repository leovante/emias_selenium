CREATE VIEW [V_oms_LF] AS SELECT 
[hDED].[LFID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_LF] as [C_LF], 
[hDED].[NAME_LF] as [NAME_LF], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[GUIDLF] as [GUIDLF], 
[hDED].[NAME_LF_SL] as [NAME_LF_SL]
FROM [oms_LF] as [hDED]
go

