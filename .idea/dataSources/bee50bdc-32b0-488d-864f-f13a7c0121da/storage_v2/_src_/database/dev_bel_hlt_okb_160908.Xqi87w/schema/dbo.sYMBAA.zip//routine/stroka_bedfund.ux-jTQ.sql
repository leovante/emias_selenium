CREATE FUNCTION stroka_BedFund (@DateBegin datetime,@DateEnd datetime, @BedProfileID int)
RETURNS TABLE
AS
RETURN (
SELECT 
(select COUNT(B.BedID) from stt_Bed B inner join stt_BedStatus BS on B.rf_BedStatusID = BS.BedStatusID  and BS.Code = '01' where B.rf_BedProfileID = @BedProfileID) endYear,
dbo.middleYearBed(@DateBegin, @BedProfileID) middleYear,
isnull(sum(1),'') incoming,
isnull(sum(case when Ct.COD ='2' then 1 else 0 end),'') selo,
isnull(sum(case when MH.V_Age <= 17 then 1 else 0 end),'') loverEquals17,
isnull(sum(case when MH.V_Age >= 60 then 1 else 0 end),'') moreEquals60,
isnull(sum(case when MP.rf_StationarBranchID = 0 then 1 else 0 end),'') discharged,
isnull(sum(case when Sep.departmentCode = 206 then 1 else 0 end),'') dayStationar,
isnull(sum(case when (DT.Code = 10) OR (HR.COD = 5) then 1 else 0 end),'') dead,
dbo.stt_CountBedDays(@DateBegin, @DateEnd, 1, 0, @BedProfileID) busyDay,
dbo.stt_CountBedDays(@DateBegin, @DateEnd, 3, 0, @BedProfileID) repairDay
 from stt_MigrationPatient MP 
inner join V_stt_MedicalHistory MH on  MH.MedicalHistoryID = MP.rf_MedicalHistoryID
inner join hlt_Citizen Ct on Ct.CitizenID = MH.rf_CitizenID
inner join stt_StationarBranch SB on MP.rf_StationarBranchID = SB.StationarBranchID
inner join oms_department Sep on Sep.departmentID = SB.rf_departmentID
inner join stt_Diagnos D on D.rf_MedicalHistoryID = MH.MedicalHistoryID
inner join stt_DiagnosType DT on DT.DiagnosTypeID = D.rf_DiagnosTypeID
inner join stt_HospResult HR on HR.HospResultID = MH.rf_HospResultID
inner join stt_BedAction BA on BA.rf_MigrationPatientID = MP.MigrationPatientID
inner join stt_Bed Bed on Bed.BedID = BA.rf_BedID
where (MP.DateIngoing > @DateBegin) and (MP.DateOut <= @DateEnd) and (Bed.rf_BedProfileID = @BedProfileID)
)
go

