CREATE VIEW [V_App_FRPerson] AS SELECT 
[hDED].[FRPersonID], [hDED].[x_Edition], [hDED].[x_Status], 
hDED.[Family] + ' ' + hDED.[Name] + ' ' + hDED.[Pat] as [v_FIO], 
(case (hDED.W)when 1 then 'М' else 'Ж' end) as [v_W], 
[hDED].[rf_FORM_RPXZID] as [rf_FORM_RPXZID], 
[hDED].[_MKABID] as [_MKABID], 
[hDED].[SS] as [SS], 
[hDED].[OKATO] as [OKATO], 
[hDED].[S_POL] as [S_POL], 
[hDED].[N_POL] as [N_POL], 
[hDED].[Family] as [Family], 
[hDED].[Name] as [Name], 
[hDED].[Pat] as [Pat], 
[hDED].[W] as [W], 
[hDED].[DB] as [DB]
FROM [App_FRPerson] as [hDED]
go

