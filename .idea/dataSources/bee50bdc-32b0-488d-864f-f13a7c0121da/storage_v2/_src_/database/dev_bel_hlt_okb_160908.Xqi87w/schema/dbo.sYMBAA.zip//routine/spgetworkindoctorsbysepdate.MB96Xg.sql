-- =============================================
-- Author:		Сергей Шумаков
-- Create date: 26.05.2010
-- Description:	Получаем набор врачей заданной специальности, принимающей в заданное время
-- =============================================
CREATE PROCEDURE [spGetWorkinDoctorsBySepDate] 
	@prvs_name varchar(100), 
	@BeginTime datetime,
	@result xml output
AS
BEGIN	
	SET NOCOUNT ON;

    set @result = 

	(
	select tt.* from
	(
	select distinct
		1 as Tag,
		null as Parent,
		null as [GetWorkinDoctorsBySepDate!1],
		'true' as [GetWorkinDoctorsBySepDate!1!Result],
		0 as [GetWorkinDoctorsBySepDate!1!Code],
		null as [DoctorTimePosition!2],
		null as [DoctorTimePosition!2!DTTID],
		null as [DoctorTimePosition!2!DocFIO]
	UNION SELECT DISTINCT
	    2 as Tag,
		1 as Parent,
		null as [GetWorkinDoctorsBySepDate!1],
		null as [GetWorkinDoctorsBySepDate!1!Result],
		null as [GetWorkinDoctorsBySepDate!1!Code],
		null as [DoctorTimePosition!2],
		dtt.DoctorTimeTableID as [DoctorTimePosition!2!DTTID],
		ltrim(rtrim(doc.Fam_V)) + ' ' + ltrim(rtrim(doc.IM_V)) + ' ' + ltrim(rtrim(doc.OT_V))  [DoctorTimePosition!2!DocFIO]
	from hlt_LPUDoctor doc
		inner join oms_prvs prvs on doc.rf_prvsid = prvs.PRVSID
			and prvs.PRVS_NAME = @prvs_name
		inner join hlt_DoctorTimeTable dtt
			on doc.LPUDoctorID = dtt.rf_LPUDoctorID
			and dtt.Begin_Time = @BeginTime
		left join hlt_DoctorVisitTable dvt
			on  dvt.rf_DoctorTimeTableID = dtt.DoctorTimeTableID
			and dvt.DoctorVisitTableID is null /*Отсекаем занятых*/
		inner join hlt_DocBusyType dbt
			on dtt.rf_DocBusyType = dbt.DocBusyTypeID
			/*
			2010-05-03 Изменил условие для записи на осмотры в 4 детской поликлиники
			*/
					--and dbt.CODE = 4
					and dbt.TypeBusy = 1
) tt
	order by [DoctorTimePosition!2!DocFIO] asc
	FOR XML EXPLICIT, TYPE
	)
END
go

