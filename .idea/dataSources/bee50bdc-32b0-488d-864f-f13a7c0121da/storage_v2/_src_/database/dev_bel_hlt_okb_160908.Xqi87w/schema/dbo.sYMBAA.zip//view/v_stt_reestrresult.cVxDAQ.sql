CREATE VIEW [V_stt_ReestrResult] AS SELECT 
[hDED].[ReestrResultID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrMKSBID] as [rf_ReestrMKSBID], 
[jT_stt_ReestrMKSB].[rf_MedicalHistoryID] as [SILENT_rf_ReestrMKSBID], 
[hDED].[rf_ReestrOccasionID] as [rf_ReestrOccasionID], 
[jT_stt_ReestrOccasion].[Num] as [SILENT_rf_ReestrOccasionID], 
[hDED].[Res_Name] as [Res_Name], 
[hDED].[ID_Rec] as [ID_Rec], 
[hDED].[N_Rec] as [N_Rec]
FROM [stt_ReestrResult] as [hDED]
INNER JOIN [stt_ReestrMKSB] as [jT_stt_ReestrMKSB] on [jT_stt_ReestrMKSB].[ReestrMKSBID] = [hDED].[rf_ReestrMKSBID]
INNER JOIN [stt_ReestrOccasion] as [jT_stt_ReestrOccasion] on [jT_stt_ReestrOccasion].[ReestrOccasionID] = [hDED].[rf_ReestrOccasionID]
go

