CREATE TRIGGER [LifeTrigger_stt_MedicalHistory] ON [stt_MedicalHistory] FOR DELETE,INSERT,UPDATE
AS 

SET NOCOUNT ON;

DECLARE @userId INT
DECLARE @seanceId INT 

DECLARE @docTypeId INT 
DECLARE @CURDATE DATETIME


declare @app varchar(50)
declare @index1 int
declare @index2 int


/* @userId, @seanceId */

SET @userId = 0
SET @seanceId = 0

EXEC [GetMalibuContext] @seanceId = @seanceId OUTPUT, @userId = @userId OUTPUT

/* @docTypeId */

SET @CURDATE = getdate()

SET @docTypeId = 0

SELECT TOP 1 @docTypeId = [DocTypeDefID], @seanceId=case WHEN [x_STDO].[HostID] IS NULL THEN @seanceId ELSE 0 END
FROM [x_DocTypeDef] left join [x_STDO] on [x_DocTypeDef].[GUID] = [x_STDO].[DocTypeDef] 
WHERE [HeadTable] = 'stt_MedicalHistory'

/* action type */

DECLARE @DEL BIT
DECLARE @INS BIT 

DECLARE @action CHAR(1)


SET @DEL = 0
SET @INS = 0


IF EXISTS (SELECT TOP 1 1 FROM DELETED) SET @DEL=1
IF EXISTS (SELECT TOP 1 1 FROM INSERTED) SET @INS = 1 

IF @INS = 1 AND @DEL = 1 SET @ACTION = 'u'
IF @INS = 1 AND @DEL = 0 SET @ACTION = 'i'
IF @INS = 0 AND @DEL = 1 SET @ACTION = 'd'


IF @ACTION = 'd'
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [MedicalHistoryID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM deleted;

	INSERT INTO Life_stt_MedicalHistory([MedicalHistoryID],[Allergy],[BD],[BirthPlace],[BirthWeight],[BloodRhGroupCheked],[CauseDeath],[ChildNum],[CloseDateNWD],[CreateDate],[DateAgreePPD],[DateDirection],[DateExtract],[DateRecipient],[DateRecipientHS],[DurationHosp],[FAMILY],[Flag],[GestationalAge],[InReanimation],[InspectedAIDS],[InspectedRW],[IntoleranceLS],[isAgreePPD],[isWorker],[KBGUID],[LiveAddress],[MedCardNum],[Address],[MHelpBeforeReg],[N_DOC],[N_NWD],[N_POL],[Name],[Note],[NumDirection],[NumGarb],[OpenDateNWD],[OT],[PatientCode],[PercentComplite],[rf_AmbulanceID],[rf_BedProfileID],[rf_BloodGroupID],[rf_CitizenID],[rf_DocPRVDID],[rf_EmerSignID],[rf_GenderTypeID],[rf_HospDegreeID],[rf_HospExitID],[rf_HospPeriodID],[rf_HospResultID],[rf_InjuryID],[rf_InterruptEventID],[rf_IntoxicationID],[rf_KATLID],[rf_kl_HospChanelID],[rf_kl_OS_SluchID],[rf_kl_PatientStatusID],[rf_kl_PrivilegeCategoryID],[rf_kl_ProfitTypeID],[rf_kl_SickListReasonID],[rf_kl_SocStatusID],[rf_kl_StatCureResultID],[rf_kl_TipOMSID],[rf_kl_TransferDirectionID],[rf_kl_TraumaTypeID],[rf_kl_VisitResultID],[rf_LiveAddressID],[rf_LPUDoctorAdmRoomID],[rf_LPUID],[rf_MedCardTypeID],[rf_MedPersonUserID],[rf_MKABID],[rf_MotherMHID],[rf_OKATOID],[rf_OKSMID],[rf_OtherSMOID],[rf_PatTransportID],[rf_PreHospDeffectID],[rf_RegAddressID],[rf_RhID],[rf_SMOID],[rf_SMOOKATOID],[rf_StationarTypeID],[rf_TypeDocID],[rf_UserID],[rf_WorkStatusID],[S_DOC],[S_NWD],[S_POL],[SendingDoctor],[Sex],[SS],[UGUID],[WhenGiveout_DOC],[WhoGiveout_DOC],[WOPatronymic],[WorkInfo],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [MedicalHistoryID],[Allergy],[BD],[BirthPlace],[BirthWeight],[BloodRhGroupCheked],[CauseDeath],[ChildNum],[CloseDateNWD],[CreateDate],[DateAgreePPD],[DateDirection],[DateExtract],[DateRecipient],[DateRecipientHS],[DurationHosp],[FAMILY],[Flag],[GestationalAge],[InReanimation],[InspectedAIDS],[InspectedRW],[IntoleranceLS],[isAgreePPD],[isWorker],[KBGUID],[LiveAddress],[MedCardNum],[Address],[MHelpBeforeReg],[N_DOC],[N_NWD],[N_POL],[Name],[Note],[NumDirection],[NumGarb],[OpenDateNWD],[OT],[PatientCode],[PercentComplite],[rf_AmbulanceID],[rf_BedProfileID],[rf_BloodGroupID],[rf_CitizenID],[rf_DocPRVDID],[rf_EmerSignID],[rf_GenderTypeID],[rf_HospDegreeID],[rf_HospExitID],[rf_HospPeriodID],[rf_HospResultID],[rf_InjuryID],[rf_InterruptEventID],[rf_IntoxicationID],[rf_KATLID],[rf_kl_HospChanelID],[rf_kl_OS_SluchID],[rf_kl_PatientStatusID],[rf_kl_PrivilegeCategoryID],[rf_kl_ProfitTypeID],[rf_kl_SickListReasonID],[rf_kl_SocStatusID],[rf_kl_StatCureResultID],[rf_kl_TipOMSID],[rf_kl_TransferDirectionID],[rf_kl_TraumaTypeID],[rf_kl_VisitResultID],[rf_LiveAddressID],[rf_LPUDoctorAdmRoomID],[rf_LPUID],[rf_MedCardTypeID],[rf_MedPersonUserID],[rf_MKABID],[rf_MotherMHID],[rf_OKATOID],[rf_OKSMID],[rf_OtherSMOID],[rf_PatTransportID],[rf_PreHospDeffectID],[rf_RegAddressID],[rf_RhID],[rf_SMOID],[rf_SMOOKATOID],[rf_StationarTypeID],[rf_TypeDocID],[rf_UserID],[rf_WorkStatusID],[S_DOC],[S_NWD],[S_POL],[SendingDoctor],[Sex],[SS],[UGUID],[WhenGiveout_DOC],[WhoGiveout_DOC],[WOPatronymic],[WorkInfo],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM deleted;
END;
ELSE
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [MedicalHistoryID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM inserted;

	INSERT INTO Life_stt_MedicalHistory([MedicalHistoryID],[Allergy],[BD],[BirthPlace],[BirthWeight],[BloodRhGroupCheked],[CauseDeath],[ChildNum],[CloseDateNWD],[CreateDate],[DateAgreePPD],[DateDirection],[DateExtract],[DateRecipient],[DateRecipientHS],[DurationHosp],[FAMILY],[Flag],[GestationalAge],[InReanimation],[InspectedAIDS],[InspectedRW],[IntoleranceLS],[isAgreePPD],[isWorker],[KBGUID],[LiveAddress],[MedCardNum],[Address],[MHelpBeforeReg],[N_DOC],[N_NWD],[N_POL],[Name],[Note],[NumDirection],[NumGarb],[OpenDateNWD],[OT],[PatientCode],[PercentComplite],[rf_AmbulanceID],[rf_BedProfileID],[rf_BloodGroupID],[rf_CitizenID],[rf_DocPRVDID],[rf_EmerSignID],[rf_GenderTypeID],[rf_HospDegreeID],[rf_HospExitID],[rf_HospPeriodID],[rf_HospResultID],[rf_InjuryID],[rf_InterruptEventID],[rf_IntoxicationID],[rf_KATLID],[rf_kl_HospChanelID],[rf_kl_OS_SluchID],[rf_kl_PatientStatusID],[rf_kl_PrivilegeCategoryID],[rf_kl_ProfitTypeID],[rf_kl_SickListReasonID],[rf_kl_SocStatusID],[rf_kl_StatCureResultID],[rf_kl_TipOMSID],[rf_kl_TransferDirectionID],[rf_kl_TraumaTypeID],[rf_kl_VisitResultID],[rf_LiveAddressID],[rf_LPUDoctorAdmRoomID],[rf_LPUID],[rf_MedCardTypeID],[rf_MedPersonUserID],[rf_MKABID],[rf_MotherMHID],[rf_OKATOID],[rf_OKSMID],[rf_OtherSMOID],[rf_PatTransportID],[rf_PreHospDeffectID],[rf_RegAddressID],[rf_RhID],[rf_SMOID],[rf_SMOOKATOID],[rf_StationarTypeID],[rf_TypeDocID],[rf_UserID],[rf_WorkStatusID],[S_DOC],[S_NWD],[S_POL],[SendingDoctor],[Sex],[SS],[UGUID],[WhenGiveout_DOC],[WhoGiveout_DOC],[WOPatronymic],[WorkInfo],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [MedicalHistoryID],[Allergy],[BD],[BirthPlace],[BirthWeight],[BloodRhGroupCheked],[CauseDeath],[ChildNum],[CloseDateNWD],[CreateDate],[DateAgreePPD],[DateDirection],[DateExtract],[DateRecipient],[DateRecipientHS],[DurationHosp],[FAMILY],[Flag],[GestationalAge],[InReanimation],[InspectedAIDS],[InspectedRW],[IntoleranceLS],[isAgreePPD],[isWorker],[KBGUID],[LiveAddress],[MedCardNum],[Address],[MHelpBeforeReg],[N_DOC],[N_NWD],[N_POL],[Name],[Note],[NumDirection],[NumGarb],[OpenDateNWD],[OT],[PatientCode],[PercentComplite],[rf_AmbulanceID],[rf_BedProfileID],[rf_BloodGroupID],[rf_CitizenID],[rf_DocPRVDID],[rf_EmerSignID],[rf_GenderTypeID],[rf_HospDegreeID],[rf_HospExitID],[rf_HospPeriodID],[rf_HospResultID],[rf_InjuryID],[rf_InterruptEventID],[rf_IntoxicationID],[rf_KATLID],[rf_kl_HospChanelID],[rf_kl_OS_SluchID],[rf_kl_PatientStatusID],[rf_kl_PrivilegeCategoryID],[rf_kl_ProfitTypeID],[rf_kl_SickListReasonID],[rf_kl_SocStatusID],[rf_kl_StatCureResultID],[rf_kl_TipOMSID],[rf_kl_TransferDirectionID],[rf_kl_TraumaTypeID],[rf_kl_VisitResultID],[rf_LiveAddressID],[rf_LPUDoctorAdmRoomID],[rf_LPUID],[rf_MedCardTypeID],[rf_MedPersonUserID],[rf_MKABID],[rf_MotherMHID],[rf_OKATOID],[rf_OKSMID],[rf_OtherSMOID],[rf_PatTransportID],[rf_PreHospDeffectID],[rf_RegAddressID],[rf_RhID],[rf_SMOID],[rf_SMOOKATOID],[rf_StationarTypeID],[rf_TypeDocID],[rf_UserID],[rf_WorkStatusID],[S_DOC],[S_NWD],[S_POL],[SendingDoctor],[Sex],[SS],[UGUID],[WhenGiveout_DOC],[WhoGiveout_DOC],[WOPatronymic],[WorkInfo],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM inserted;
END; 

SET NOCOUNT OFF;


go

