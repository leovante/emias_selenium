CREATE VIEW [V_ras_PositionWPL] AS SELECT 
[hDED].[PositionWPLID], [hDED].[HostPositionWPLID], [hDED].[x_Edition], [hDED].[x_Status], 
((ISNULL((SELECT top 1  TenderType_Name 
FROM oms_TenderType 
join ras_StoredLS on rf_TenderTypeID = TenderTypeID and hDed.rf_StoredLSID = ras_StoredLS.StoredLSID 
			  and hDed.rf_StoredLSIDHost = ras_StoredLS.HostStoredLSID),''))) as [V_TenderTypeName], 
hDED.Count*Price as [V_Summa], 
(IsNull((select top 1 GeneralLogin from x_User where x_User.UserID=hDED.rf_UserID),'')) as [V_User], 
((isnull((Select top 1 name from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId), '') )) as [V_Nomenclature], 
((isnull((Select top 1 NUM from ras_Series where SeriesID = [jT_ras_StoredLS].rf_SeriesID), '') )) as [V_Series], 
[jT_ras_StoredLS].[Price] as [V_Price], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_TypePackingID] as [rf_TypePackingID], 
[hDED].[rf_StatePositionWPLID] as [rf_StatePositionWPLID], 
[jT_ras_StatePositionWPL].[Name] as [SILENT_rf_StatePositionWPLID], 
[hDED].[rf_WriteOffPurposeListID] as [rf_WriteOffPurposeListID], 
[hDED].[rf_WriteOffPurposeListIDHost] as [rf_WriteOffPurposeListIDHost], 
[hDED].[Count] as [Count], 
[hDED].[Date] as [Date], 
[hDED].[GUIDPos] as [GUIDPos], 
[hDED].[GUIDPosList] as [GUIDPosList], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[FractionCount] as [FractionCount], 
[hDED].[Measure] as [Measure], 
[hDED].[MeasureCount] as [MeasureCount], 
[hDED].[docMarkGuid] as [docMarkGuid], 
[hDED].[RequestMarkGuid] as [RequestMarkGuid]
FROM [ras_PositionWPL] as [hDED]
INNER JOIN [ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
INNER JOIN [ras_StatePositionWPL] as [jT_ras_StatePositionWPL] on [jT_ras_StatePositionWPL].[StatePositionWPLID] = [hDED].[rf_StatePositionWPLID]
go

