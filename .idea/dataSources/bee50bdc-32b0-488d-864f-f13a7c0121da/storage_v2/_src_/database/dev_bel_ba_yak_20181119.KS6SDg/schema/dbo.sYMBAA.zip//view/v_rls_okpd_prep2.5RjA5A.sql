CREATE VIEW [V_rls_Okpd_Prep2] AS SELECT 
[hDED].[Okpd_Prep2ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PrepUID] as [rf_PrepUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[rf_OKPD2_UID] as [rf_OKPD2_UID], 
[hDED].[Code] as [Code], 
[hDED].[UID] as [UID]
FROM [rls_Okpd_Prep2] as [hDED]
go

