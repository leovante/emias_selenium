CREATE VIEW [V_ras_Responsible] AS SELECT 
[hDED].[ResponsibleID], [hDED].[HostResponsibleID], [hDED].[x_Edition], [hDED].[x_Status], 
Family+' '+Name+' '+OT as [V_FIO], 
[hDED].[Code] as [Code], 
[hDED].[Family] as [Family], 
[hDED].[Name] as [Name], 
[hDED].[OT] as [OT]
FROM [ras_Responsible] as [hDED]
go

