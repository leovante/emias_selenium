
CREATE PROCEDURE [dbo].[ChangeLsAu_Cls](@oldLsID bigint, @oldCode bigint, @newLsID bigint, @newCode bigint,  @clsId int)
AS
BEGIN

	if (@oldLsID is not null and @newLsID is not null)
	begin		
	    begin tran
			if exists(Select * from oms_cls where rf_LSID in (Select LSID from oms_LS where NOMK_LS = @oldCode))
			begin
			exec [dbo].[CollapseLsCod] @newCode, @oldCode
			end
		commit tran 

		if not exists (select * from oms_CollapseHistory where OldCode = @oldCode and NewCode <> @newCode)
			begin

				declare @lsfoId int;
				declare @oldNomenId int;
				declare @newNomenId int;
				declare @ignoreLsfoAndSeries string_list 
	
				insert into @ignoreLsfoAndSeries (string_item) values ('ras_Lsfo')
				insert into @ignoreLsfoAndSeries (string_item) values ('ras_Series')

				--получаем ID старой номенклатуры
				set @oldNomenId = (select top 1 NomenclatureID from ras_Nomenclature where rf_LSID = @oldLsID and Cod_RAS = convert(varchar(max), @oldCode));
				
				--получаем ID новой номенклатуры
				
				if not exists (select NomenclatureID from ras_Nomenclature
						   where rf_LSID = @newLsID and COD_RAS = convert(varchar(max), @newCode))
				begin
				 execute dbo.[ras_NomenclatureCreate]
				end
                
				set @newNomenId = (select NomenclatureID from ras_Nomenclature where rf_LSID = @newLsID and COD_RAS = convert(varchar(max), @newCode))
				 
				if (@newNomenId is not null and @oldNomenId is not null)
				begin
				declare @cpfs varchar(max);
				set @cpfs = (select C_PFS from oms_CLS where CLSID = @clsId);						
	
	
				--получаем ЛСФО
				set @lsfoId = (select top 1 LSFOID from ras_LSFO where rf_CLSID = @clsId and C_LSProvider = convert(varchar(50),@oldCode)+'_'+convert(varchar(50),@cpfs));
	
				if (@lsfoID is null)
				begin 
					set @lsfoId = (select top 1 LSFOID from ras_LSFO where rf_CLSID = @clsId and rf_NomenclatureID = @newNomenId);
				end

				--перебрасываем тип требования и группу номенклатур со старой на новую
				declare @rf_requestTypeID int,
						@rf_nomenGroupID int;

				Select @rf_requestTypeID  = rf_requestTypeID, @rf_nomenGroupID = rf_nomenGroupID
				from ras_nomenclature where NomenclatureID = @oldNomenId

				Update ras_nomenclature
				set rf_requestTypeID = @rf_requestTypeID, 
				    rf_nomenGroupID = @rf_nomenGroupID
				where  NomenclatureID = @newNomenId

				
				declare @codRasNew varchar(max);
				declare @codRasOld varchar(max);
	
				--получаем коды номенклатур
				set @codRasNew = (select COD_RAS from ras_Nomenclature where NomenclatureID = @newNomenId);
				set @codRasOld = (select COD_RAS from ras_Nomenclature where NomenclatureID = @oldNomenId);
	
	
				if (@codRasNew is null) set @codRasNew = @newCode
				if (@codRasOld is null) set @codRasOld = @oldCode
	
				--получаем код ЛСФО
	
				-- дубли лсфо??
	
				declare @c_lsprovider varchar(max);  -- текущий лсфо
	
				set @c_lsprovider = (select C_LSProvider from ras_LSFO where LSFOID = @lsfoId);
	
				update ras_PositionInventarisation
				set C_LSFO = REPLACE(C_LSFO, @codRasOld + '_', @codRasNew + '_'),
				Name = (select top 1 Name from ras_Nomenclature where Cod_RAS = @codRasNew)
				where C_LSFO = @c_lsprovider
	
				update ras_PositionBillEx_Other
				set C_LSFO = REPLACE(C_LSFO, @codRasOld + '_', @codRasNew + '_')
				where C_LSFO = @c_lsprovider
	
				update ras_ExtractedLSfromReestr
				set C_LSFO = CONVERT(varchar(max), @codRasNew)
				where C_LSFO = @codRasOld and C_PFS = @cpfs
	
				update ras_PositionReport
				set C_LSFO = CONVERT(varchar(max), @codRasNew)
				where C_LSFO = @codRasOld and C_PFS = @cpfs
	
				--обновление ссылок на номенклатуру
				update ras_PositionBill
				set rf_NomenclatureID = @newNomenId
				where rf_LSFOID = @lsfoId
	
				update ras_PositionInventarisation
				set rf_NomenclatureID = @newNomenId
				where rf_LSFOID = @lsfoId
				
				update ras_PositionReport
				set rf_NomenclatureID = @newNomenId
				where C_LSFO = CONVERT(varchar(max), @codRasNew)  and C_PFS = @cpfs
	
				update ras_StoredLS
				set rf_NomenclatureID = @newNomenId
				where rf_LSFOID = @lsfoId
				
				update ras_PositionBillEx_Other
				set rf_NomenclatureID = @newNomenId
				where C_LSFO = @codRasNew + '_' + @cpfs --поле лсфо апдейтили выше, уже по новому коду ищем
	
				update ras_PositionPosting
				set rf_NomenclatureID = @newNomenId
				where rf_LSFOID = @lsfoId
	
				update ras_PositionBillReturnCL
				set rf_NomenclatureID = @newNomenId
				where rf_LSFOID = @lsfoId

				begin try
						-- разруливаем возможные дубли лсфо - все переводим на новый код
						declare @oldLSFOID int;
						declare @newLSFOID int;
	
						declare _lsfo cursor for
						select old.LSFOID oldLsfoID, (select LSFOID from ras_LSFO new where old.C_PFS = new.C_PFS and rf_NomenclatureID = @newNomenID 
																					 and new.C_LSProvider like @codRasNew+'_%') newLSFOID
						from ras_LSFO  old
						where rf_CLSID = @clsId and (rf_NomenclatureID <> @newNomenId or old.C_LSProvider not like @codRasNew+'_%')
	
						open _LSFO
							fetch next from _lsfo into @oldLSFOID, @newLSFOID 
							while (@@fetch_status <> -1)
							begin
	
	
								if (not @newLSFOID is null) 
								begin
									exec ref_update 'RAS', 'rf_LSFOID%', @oldLSFOID, @newLSFOID
	
									delete from ras_LSFO where LSFOID = @oldLSFOID 
								end
								else
								begin
									update ras_LSFO
									set C_LSProvider = REPLACE(C_LSProvider, @codRasOld + '_', CONVERT(varchar(max), @codRasNew) + '_')
										, rf_NomenclatureID = @newNomenID
									where LSFOID = @oldLSFOID
								end 
	
								fetch next from _lsfo into @oldLSFOID, @newLSFOID 
							end
						close _lsfo
						deallocate _lsfo
				end try
				begin catch 
						begin try
							update ras_LSFO
							set C_LSProvider = REPLACE(C_LSProvider, @codRasOld + '_', CONVERT(varchar(max), @codRasNew) + '_')
							, rf_NomenclatureID = @newNomenID
							where LSFOID = @oldLSFOID	
						end try 
						begin catch 
						end catch 
				end catch
				
				declare @oldLSIDBr int;
				declare @newLSIDBr int;
	
			    declare _stls cursor for Select distinct nom.NomenclatureID, nom1.NomenclatureID
									     from v_ras_StoredLS
									     inner join ras_Nomenclature nom on v_ras_StoredLS.rf_NomenclatureID = nom.NomenclatureID
										 inner join ras_LSFO on rf_LSFOID = LSFOID
										 inner join oms_CLS on rf_CLSID = CLSID
										 inner join ras_nomenclature nom1 on nom1.rf_LSID = oms_CLS.rf_LSID
										 where nom.rf_LSID!=oms_cls.rf_LSID and oms_cls.rf_LSID!=0 and oms_CLS.CLSID = @clsId
				open _stls
				fetch next from _stls into @oldLSIDBr, @newLSIDBr 
				while (@@fetch_status <> -1)
				begin	
				 --exec ref_update 'RAS', 'rf_NomenclatureID%', @oldLSIDBr, @newLSIDBr
				 exec RefUpdateWithIgnore 'RAS', 'rf_NomenclatureID%', @ignoreLsfoAndSeries,  @oldLSIDBr, @newLSIDBr					   
				end		
				fetch next from _stls into @oldLSIDBr, @newLSIDBr 
				close _stls
				deallocate _stls	   
			
			-- обрабатываем серии 
			if (select isnull(SUM(c), 0) from
						(
							select ISNULL((COUNT(distinct NUM)), 0) as c from ras_Series 
							where SeriesID  > 0 and (rf_NomenclatureID = @oldNomenID or rf_NomenclatureID = @newNomenID)
							group by NUM
							having COUNT(*) > 1
						)ttt
					) = 0
					begin
						-- обновление серий 
						update ras_Series
						set rf_NomenclatureID = @newNomenId
						where rf_NomenclatureID = @oldNomenId
						and SeriesID in (  select rf_SeriesID from ras_StoredLS where rf_LSFOID = @newLSFOID or rf_LSFOID = @oldLSFOID)
					end
					else
					begin
						-- перебираем все дублирующиеся номера серий для обоих номенклатур
						declare @seriesNum varchar(max);
						declare _serCur cursor for
							select NUM from ras_Series 
							where SeriesID  > 0 and (rf_NomenclatureID = @oldNomenID or rf_NomenclatureID = @newNomenID)
							group by NUM
							having COUNT(*) > 1
						open _serCur
	
						fetch next from _serCur into @seriesNum
						while (@@fetch_status <> -1)
						begin
							declare @minusSerId int;
							declare @plusSerId int;
	
							SELECT @minusSerId = SeriesID from ras_Series where NUM = @seriesNum and rf_NomenclatureID = @oldNomenID 
							SELECT @plusSerId = SeriesID from ras_Series where NUM = @seriesNum and rf_NomenclatureID = @newNomenID 
	
							--перебрасываем все ссылки с отрицательной серии на положительную серию
							exec  Ref_update 'RAS', 'rf_SeriesID%', @minusSerId, @plusSerId
	
							fetch next from _serCur into @seriesNum
						end
						close _serCur		
						deallocate _serCur
					end
					
							
				update oms_CLS
				set rf_LSID = @newLsID
				where CLSID = @clsId
	
				update oms_PharmacyRecipe
				set rf_LSID = @newLsID
				where rf_CLSID = @clsId
	
				update oms_DPCPharmacyRecipe
				set rf_LSID = @newLsID
				where rf_CLSID = @clsId
	
				Update ras_Nomenclature
				set Date_E = GETDATE()
				where Cod_RAS = convert(varchar(150), @oldCode)
				end

				update oms_CollapseHistory 
			    set IsSuccessAu = 1,
				    CollapseDate = GETDATE()
			    where OldCode = @oldCode and NewCode = @newCode
								
				--oms_PolyclinicRecipe
				--oms_Recipe
				--ras_RRecipe
				--oms_DPCPolyclinicRecipe
				--oms_in_LS
				--oms_Nameless_LS
				--ras_Nomenclature
				--oms_LS_Finl
				end
			end
		else
			begin
				
				declare @errorMessage varchar(max)
				set @errorMessage = 'В CollapseHistory существует правило со старым кодом: ' + cast(@oldCode as varchar(max));
				RAISERROR (@errorMessage, 18, 1);
			end
END


go

