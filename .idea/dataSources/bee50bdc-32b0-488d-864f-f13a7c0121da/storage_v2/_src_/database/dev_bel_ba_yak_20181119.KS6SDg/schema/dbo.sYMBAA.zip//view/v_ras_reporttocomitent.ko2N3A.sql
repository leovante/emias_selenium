CREATE VIEW [V_ras_ReportToComitent] AS SELECT 
[hDED].[ReportToComitentID], [hDED].[HostReportToComitentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrganisationProviderID] as [rf_OrganisationProviderID], 
[hDED].[rf_OrganisationProviderIDHost] as [rf_OrganisationProviderIDHost], 
[hDED].[rf_OrganisationClientID] as [rf_OrganisationClientID], 
[hDED].[rf_OrganisationClientIDHost] as [rf_OrganisationClientIDHost], 
[hDED].[rf_DogovorID] as [rf_DogovorID], 
[hDED].[rf_DogovorIDHost] as [rf_DogovorIDHost], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[hDED].[rf_PeriodID] as [rf_PeriodID], 
[hDED].[rf_PeriodIDHost] as [rf_PeriodIDHost], 
[hDED].[rf_DocDescriptionID] as [rf_DocDescriptionID], 
[hDED].[rf_StateReportID] as [rf_StateReportID], 
[hDED].[Date] as [Date], 
[hDED].[PR_Reward] as [PR_Reward], 
[hDED].[Num] as [Num], 
[hDED].[DocGUID] as [DocGUID], 
[hDED].[Load_Send] as [Load_Send], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[isStorned] as [isStorned], 
[hDED].[TypePost] as [TypePost], 
[hDED].[Note] as [Note], 
[hDED].[Summa] as [Summa], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[FLAGS] as [FLAGS]
FROM [ras_ReportToComitent] as [hDED]
go

