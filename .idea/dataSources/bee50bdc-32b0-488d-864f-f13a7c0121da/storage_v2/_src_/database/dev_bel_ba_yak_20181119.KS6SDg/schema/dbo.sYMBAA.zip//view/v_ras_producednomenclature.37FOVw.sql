CREATE VIEW [V_ras_ProducedNomenclature] AS SELECT 
[hDED].[ProducedNomenclatureID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_ras_Nomenclature].[Name] as [V_Name], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[hDED].[rf_ProducedNomcTypeID] as [rf_ProducedNomcTypeID], 
[jT_ras_ProducedNomcType].[Name] as [SILENT_rf_ProducedNomcTypeID], 
[hDED].[PriceScale] as [PriceScale], 
[hDED].[Formula] as [Formula], 
[hDED].[ExpirationDay] as [ExpirationDay], 
[hDED].[CountNomc] as [CountNomc], 
[hDED].[Factor] as [Factor], 
[hDED].[Measure] as [Measure]
FROM [ras_ProducedNomenclature] as [hDED]
INNER JOIN [ras_Nomenclature] as [jT_ras_Nomenclature] on [jT_ras_Nomenclature].[NomenclatureID] = [hDED].[rf_NomenclatureID] AND  [jT_ras_Nomenclature].[HostNomenclatureID] = [hDED].[rf_NomenclatureIDHost]
INNER JOIN [ras_ProducedNomcType] as [jT_ras_ProducedNomcType] on [jT_ras_ProducedNomcType].[ProducedNomcTypeID] = [hDED].[rf_ProducedNomcTypeID]
go

