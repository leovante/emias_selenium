CREATE VIEW [V_oms_MHReturnsType] AS SELECT 
[hDED].[MHReturnsTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Rem] as [Rem]
FROM [oms_MHReturnsType] as [hDED]
go

