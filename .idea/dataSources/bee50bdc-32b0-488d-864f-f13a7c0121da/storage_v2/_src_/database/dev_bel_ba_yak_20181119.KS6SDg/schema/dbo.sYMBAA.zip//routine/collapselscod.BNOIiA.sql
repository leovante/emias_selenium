
CREATE PROCEDURE [dbo].[CollapseLsCod](@newCode bigint, @oldCode bigint)
AS
BEGIN
	;
	exec dbo.ChangeLsCod_NoNameless @oldCode , @newCode 

END
go

