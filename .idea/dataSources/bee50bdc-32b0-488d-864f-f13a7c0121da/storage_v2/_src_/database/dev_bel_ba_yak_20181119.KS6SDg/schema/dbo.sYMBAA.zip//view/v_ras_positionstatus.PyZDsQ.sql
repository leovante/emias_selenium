CREATE VIEW [V_ras_PositionStatus] AS SELECT 
[hDED].[PositionStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [ras_PositionStatus] as [hDED]
go

