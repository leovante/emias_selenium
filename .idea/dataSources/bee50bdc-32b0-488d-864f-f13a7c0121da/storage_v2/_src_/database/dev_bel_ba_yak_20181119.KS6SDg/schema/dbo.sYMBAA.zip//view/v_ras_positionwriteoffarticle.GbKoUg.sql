CREATE VIEW [V_ras_PositionWriteOffArticle] AS SELECT 
[hDED].[PositionWriteOffArticleID], [hDED].[HostPositionWriteOffArticleID], [hDED].[x_Edition], [hDED].[x_Status], 
(((ISNULL((SELECT top 1  TenderType_Name 
FROM oms_TenderType 
join ras_StoredLS on rf_TenderTypeID = TenderTypeID and hDed.rf_StoredLSID = ras_StoredLS.StoredLSID 
			  and hDed.rf_StoredLSIDHost = ras_StoredLS.HostStoredLSID),'')))) as [V_TenderTypeName], 
((isnull((Select top 1 Name from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId), '') )) as [V_Nomenclature], 
((isnull((Select top 1 NUM from ras_Series where SeriesID = [jT_ras_StoredLS].rf_SeriesID), '') )) as [V_Series], 
((Select top 1 name from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId)) as [V_StoredLS], 
((isnull((Select top 1 name from ras_organisation where OrganisationID = [jT_ras_StoredLS].rf_organisationOwnerID), '') )) as [V_Owner], 
([hDED].[Count] * [jT_ras_StoredLS].[Price]) as [V_Summ], 
((isnull((Select top 1 c_LSProvider from ras_LSFo where LSFOID = [jT_ras_StoredLS].rf_LSFOID), '') )) as [V_C_LSFO], 
((isnull((Select top 1 NUM from oms_tender where tenderID = [jT_ras_StoredLS].rf_tenderID ), '') )) as [V_TenderNum], 
[jT_ras_StoredLS].[Consigment] as [V_Consigment], 
[jT_ras_StoredLS].[Price] as [Price], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_WriteOffArticleID] as [rf_WriteOffArticleID], 
[hDED].[rf_WriteOffArticleIDHost] as [rf_WriteOffArticleIDHost], 
[hDED].[rf_StatePositionWriteOffArcticleID] as [rf_StatePositionWriteOffArcticleID], 
[hDED].[rf_PositionStatusID] as [rf_PositionStatusID], 
[hDED].[FractionCount] as [FractionCount], 
[hDED].[Measure] as [Measure], 
[hDED].[MeasureCount] as [MeasureCount], 
[hDED].[Note] as [Note], 
[hDED].[Count] as [Count]
FROM [ras_PositionWriteOffArticle] as [hDED]
INNER JOIN [ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
go

