CREATE VIEW [V_oms_MNName] AS SELECT 
[hDED].[MNNameID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_MNN] as [C_MNN], 
[hDED].[NAME_MNN] as [NAME_MNN], 
[hDED].[Latin_Name] as [Latin_Name], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[GUIDMnn] as [GUIDMnn], 
[hDED].[MNNIsDLO] as [MNNIsDLO]
FROM [oms_MNName] as [hDED]
go

