CREATE VIEW [V_oms_SFO] AS SELECT 
[hDED].[SFOID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[hDED].[FO_OGRN] as [FO_OGRN], 
[hDED].[FO_NAMES] as [FO_NAMES], 
[hDED].[FO_NAMEF] as [FO_NAMEF], 
[hDED].[FAM_RUK] as [FAM_RUK], 
[hDED].[IM_RUK] as [IM_RUK], 
[hDED].[OT_RUK] as [OT_RUK], 
[hDED].[FAM_BUX] as [FAM_BUX], 
[hDED].[IM_BUX] as [IM_BUX], 
[hDED].[OT_BUX] as [OT_BUX], 
[hDED].[TEL] as [TEL], 
[hDED].[FAX] as [FAX], 
[hDED].[E_MAIL] as [E_MAIL], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E], 
[hDED].[CFO] as [CFO], 
[hDED].[ADRES] as [ADRES], 
[hDED].[GUIDSFO] as [GUIDSFO], 
[hDED].[RCode] as [RCode], 
[hDED].[POST_IDP] as [POST_IDP]
FROM [oms_SFO] as [hDED]
go

