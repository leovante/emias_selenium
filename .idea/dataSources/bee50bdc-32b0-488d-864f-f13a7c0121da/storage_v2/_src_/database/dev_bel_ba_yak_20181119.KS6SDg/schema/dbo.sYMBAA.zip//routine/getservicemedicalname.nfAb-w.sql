
Create FUNCTION [dbo].[GetServiceMedicalName] (@Field varchar(50))  
RETURNS varchar(150)   AS  
BEGIN 
return (select ServiceMedicalName from  oms_ServiceMedical where ServiceMedicalCode=@Field)
END
go

