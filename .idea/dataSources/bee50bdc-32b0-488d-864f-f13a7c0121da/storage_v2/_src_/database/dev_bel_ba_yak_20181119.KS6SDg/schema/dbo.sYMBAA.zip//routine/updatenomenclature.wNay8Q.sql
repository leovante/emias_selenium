
Create procedure UpdateNomenclature
	@LsIdTable LsIdTable readonly
as

declare	@n_tab varchar(100), @sql varchar(max), @sql2 varchar(max)

BEGIN TRY

	Update ras_nomenclature
	Set 
	Name = ltrim(rtrim(oms_LS.NAME_MED)) , 
	rf_ProducerID=isnull((Select top 1 ProducerID from ras_Producer where [Name]=Name_FCT ),0),
	rf_SpecificID=isnull((select top 1 SpecificID from ras_Specific where ras_Specific.Code=cast(oms_Spec.Code as varchar)),0),
	rf_NarcLSTypeID=isnull((Select top 1 NarcLSTypeID from ras_NarcLSType where ras_NarcLSType.Code=oms_NarcType.Code),0),
	[Severability1] = isnull( case rls_Nomen.DrugsInpPack when 0 then 1 else rls_Nomen.DrugsInpPack end, case oms_LS.N_FV when 0 then 1 else oms_LS.N_FV end),
	[Severability2] = isnull( case PPackInUPack when 0 then 1 else PPackInUPack end *  
						 case UPackInSPack when 0 then 1 else UPackInSPack end , 1 ) 


	from ras_nomenclature r
	inner join oms_LS on LSID=rf_LSID
	
	inner join oms_TRName on trnameID=oms_LS.rf_trnameID
	inner join oms_LF on LFID=oms_LS.rf_LFID
	inner join oms_DLS on DLSID=oms_LS.rf_DLSID
	inner join oms_MNName on mnnameID=oms_LS.rf_mnnameID
	
	inner join oms_Spec on SpecID=oms_LS.rf_SpecID
	inner join oms_NarcType on NarcTypeID=oms_LS.rf_NarcTypeID
	left join rls_Nomen on oms_LS.RlsNomenUid = rls_Nomen.UID and oms_LS.RlsNomenUid <> '00000000-0000-0000-0000-000000000000'
	where nomenclatureID > 0 and LSID>0.1 --and r.Date_E>getdate() and oms_LS.Date_E > getDate()
	and LSID in (select LSID from @LsIdTable)
	and  ( /*OR r.rf_LFID<>oms_LS.rf_LFID OR  r.rf_DLSID<>oms_LS.rf_DLSID*/
	 rf_ProducerID<>isnull((Select top 1 ProducerID from ras_Producer where [Name]=Name_FCT ),0)
	OR rf_SpecificID<>isnull((select top 1 SpecificID from ras_Specific where ras_Specific.Code=cast(oms_Spec.Code as varchar)),0)
	OR rf_NarcLSTypeID<>isnull((Select top 1 NarcLSTypeID from ras_NarcLSType where ras_NarcLSType.Code=oms_NarcType.Code),0)
	OR Severability1 = 0 OR Severability2 = 0 OR  Severability1*Severability2 != oms_LS.N_FV
	OR r.Name <> ltrim(rtrim(oms_LS.NAME_MED)))

	Update ras_nomenclature SET Date_E=getdate()
	--закрывает текущем числом, если нет действующей цены и ЛС
	from ras_nomenclature r
	join oms_LS on LSID=rf_LSID
	where oms_LS.Date_E <= getDate()  and nomenclatureID <> 0 and r.Date_E>getdate()
		and LSID in (select LSID from @LsIdTable)

	Update ras_Nomenclature Set EAN13 = rlsNom.EanCode
	--Обновляет ЕАН номенклатуры по ЕАНу номенклатуры рлс
	from ras_Nomenclature nom
		inner join oms_LS ls on nom.rf_LSID = ls.LSID
		inner join rls_Nomen rlsNom on ls.RlsNomenUid = rlsNom.UID 
			and ls.RlsNomenUid <> '00000000-0000-0000-0000-000000000000'
    where nom.EAN13 = '' and LSID in (select LSID from @LsIdTable)

	Update ras_nomenclature SET Cod_Nom = Cod_ras
	--Обновляет код номенклатуры по коду рас
	from ras_nomenclature
	where Cod_Nom = '' and rf_LSID in (select LSID from @LsIdTable)

END TRY
--Если запрос таки упал :(
BEGIN CATCH
--ошибка в индексах
	if ERROR_NUMBER()=2601 
	begin 

		SET @sql=null;
		SELECT @sql = ISNULL(@sql,'')+ CASE WHEN @sql IS NULL THEN '' ELSE ', ' END +c.name
			FROM sys.index_columns ic
			LEFT JOIN sys.indexes i ON ic.object_id=i.object_id
			LEFT JOIN sys.columns c ON ic.object_id=c.object_id
			WHERE ic.index_id=i.index_id and ic.column_id=c.column_id
			and i.name like '%UNIQUE'and ic.object_id=object_id(@n_tab)

		Select @sql2='Cod_RAS'
		 
		if exists(select * from sysobjects where [name] = 'tmp_err')
				begin 
					insert into tmp_err
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
		
					end
				else
					begin
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
					into tmp_err
				end
	end
	--другая ошибка
	else 
		if exists(select * from sysobjects where [name] = 'tmp_err')
			begin
				insert into tmp_err
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage, 'Ошибка в таблице ras_nomenclature' as er
			end
		else
			begin
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage, 'Ошибка в таблице ras_nomenclature' as er into tmp_err
			end
END CATCH
go

