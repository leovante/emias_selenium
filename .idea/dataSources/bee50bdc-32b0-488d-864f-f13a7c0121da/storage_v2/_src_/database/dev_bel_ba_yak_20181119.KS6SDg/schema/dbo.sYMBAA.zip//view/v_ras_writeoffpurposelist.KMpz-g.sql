CREATE VIEW [V_ras_WriteOffPurposeList] AS SELECT 
[hDED].[WriteOffPurposeListID], [hDED].[HostWriteOffPurposeListID], [hDED].[x_Edition], [hDED].[x_Status], 
(Select StoreName from ras_Store where StoreID = [hDED].[rf_StoreID] and HostStoreID = [hDED].[rf_StoreIDHost]) as [V_STORENAME], 
[jT_ras_Organisation].[Name] as [V_Organisation], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_OrganisationIDHost] as [rf_OrganisationIDHost], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[hDED].[rf_DocDescriptionID] as [rf_DocDescriptionID], 
[hDED].[rf_StatePurposeListID] as [rf_StatePurposeListID], 
[jT_ras_StatePurposeList].[Name] as [SILENT_rf_StatePurposeListID], 
[hDED].[Num] as [Num], 
[hDED].[Date] as [Date], 
[hDED].[GUIDDoc] as [GUIDDoc], 
[hDED].[GUIDList] as [GUIDList], 
[hDED].[Note] as [Note], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[GUIDHistory] as [GUIDHistory], 
[hDED].[PolisSeria] as [PolisSeria], 
[hDED].[PolisNumber] as [PolisNumber], 
[hDED].[Surname] as [Surname], 
[hDED].[Name] as [Name], 
[hDED].[Secondname] as [Secondname], 
[hDED].[Birthday] as [Birthday], 
[hDED].[docMarkGuid] as [docMarkGuid], 
[hDED].[RequestMarkGuid] as [RequestMarkGuid]
FROM [ras_WriteOffPurposeList] as [hDED]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationIDHost]
INNER JOIN [ras_StatePurposeList] as [jT_ras_StatePurposeList] on [jT_ras_StatePurposeList].[StatePurposeListID] = [hDED].[rf_StatePurposeListID]
go

