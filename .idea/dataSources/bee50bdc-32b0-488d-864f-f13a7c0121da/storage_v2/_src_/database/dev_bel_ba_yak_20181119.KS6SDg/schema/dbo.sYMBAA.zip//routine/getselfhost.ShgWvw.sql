create FUNCTION [dbo].[GetSelfHost]()
									RETURNS int
									AS
									BEGIN
									DECLARE @hostID int
									set @hostID = 999
									RETURN (@hostID)
									END

go

