CREATE VIEW [V_oms_LsType] AS SELECT 
[hDED].[LsTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ParentGUID] as [rf_ParentGUID], 
[hDED].[rf_MainLsTypeID] as [rf_MainLsTypeID], 
[hDED].[LsTypeCode] as [LsTypeCode], 
[hDED].[LsTypeName] as [LsTypeName], 
[hDED].[GUID] as [GUID], 
[hDED].[Pattern] as [Pattern]
FROM [oms_LsType] as [hDED]
go

