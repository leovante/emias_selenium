CREATE VIEW [V_ras_IngridientProduced] AS SELECT 
[hDED].[IngridientProducedID], [hDED].[x_Edition], [hDED].[x_Status], 
((((isnull((select top 1 t.Name 
from ras_ProducedNomenclature p
    inner join ras_ProducedNomcType t on t.ProducedNomcTypeID = p.rf_ProducedNomcTypeID
where p.ProducedNomenclatureID = [hDED].rf_ProducedNomenclatureID),''))))) as [V_ProducedName], 
[jT_ras_Nomenclature].[Name] as [V_IngridientName], 
[hDED].[rf_TRNameID] as [rf_TRNameID], 
[jT_oms_TRName].[NAME_TRN] as [SILENT_rf_TRNameID], 
[hDED].[rf_MNNameID] as [rf_MNNameID], 
[jT_oms_MNName].[NAME_MNN] as [SILENT_rf_MNNameID], 
[hDED].[rf_IngridientNomenclatureID] as [rf_IngridientNomenclatureID], 
[hDED].[rf_IngridientNomenclatureIDHost] as [rf_IngridientNomenclatureIDHost], 
[hDED].[rf_ProducedNomenclatureID] as [rf_ProducedNomenclatureID], 
[hDED].[RateSpending] as [RateSpending], 
[hDED].[Note] as [Note], 
[hDED].[UseInProduction] as [UseInProduction], 
[hDED].[Formula] as [Formula], 
[hDED].[Signature] as [Signature], 
[hDED].[Factor] as [Factor], 
[hDED].[Measure] as [Measure]
FROM [ras_IngridientProduced] as [hDED]
INNER JOIN [ras_Nomenclature] as [jT_ras_Nomenclature] on [jT_ras_Nomenclature].[NomenclatureID] = [hDED].[rf_IngridientNomenclatureID] AND  [jT_ras_Nomenclature].[HostNomenclatureID] = [hDED].[rf_IngridientNomenclatureIDHost]
INNER JOIN [oms_TRName] as [jT_oms_TRName] on [jT_oms_TRName].[TRNameID] = [hDED].[rf_TRNameID]
INNER JOIN [oms_MNName] as [jT_oms_MNName] on [jT_oms_MNName].[MNNameID] = [hDED].[rf_MNNameID]
go

