CREATE VIEW [V_ras_Shelf] AS SELECT 
[hDED].[ShelfID], [hDED].[HostShelfID], [hDED].[x_Edition], [hDED].[x_Status], 
ISNULL((SELECT TOP 1 ras_Zone.Name + '-' + convert(varchar,ras_Rack.Name) + '-' + convert(varchar,rsh.Name) FROM ras_Zone  INNER JOIN ras_Rack ON ras_Rack.rf_ZoneID = ras_Zone.ZoneID  INNER JOIN ras_Shelf rsh ON rsh.rf_RackID = ras_Rack.RackID WHERE rsh.ShelfID = hDED.ShelfID),'') as [V_Name], 
[hDED].[rf_RackID] as [rf_RackID], 
[hDED].[rf_RackIDHost] as [rf_RackIDHost], 
[hDED].[Name] as [Name], 
[hDED].[Barcode] as [Barcode]
FROM [ras_Shelf] as [hDED]
go

