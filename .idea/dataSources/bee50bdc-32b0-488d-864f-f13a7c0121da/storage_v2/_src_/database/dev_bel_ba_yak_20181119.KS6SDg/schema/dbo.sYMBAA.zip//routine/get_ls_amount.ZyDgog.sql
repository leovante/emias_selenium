
/* 	13/12/06 ISidorov */
CREATE FUNCTION get_ls_amount (@StoredLSID int, @Date datetime)
RETURNS decimal(18,2)
AS
BEGIN
	DECLARE @res decimal(18,2)

	Declare @RestDateTime datetime 

--	declare @Date datetime
--	declare @StoredLSID int
--	set @Date = convert(datetime, '14.12.2006', 104)
--	set @StoredLSID = 91783

	set @RestDateTime = (
		select  top 1 min(TransactDateTimeOperation) --p.Date_B)
	 		from ras_transactjournal tj
			inner join ras_period p on p.PeriodID = tj.rf_PeriodID 
			inner join ras_stateperiod sp on sp.StatePeriodID = p.rf_StatePeriodID
	 		where 
			(PositionID = 0) and 
	 		(tj.rf_StoredLSID = @StoredLSID) 
	 		--(@Date >= tj.TransactDateTimeOperation)
			and (sp.EnumName = 'open')
			and (@Date >= p.Date_B) 	
			and (rf_PeriodID <> 0)	
			and periodid <> 0
		)
--	print isnull(@RestDateTime, 0)
	
	if (@RestDateTime  IS NULL) 
	begin
	--	print 'sadsad' 
		set @RestDateTime = (select  top 1 max(TransactDateTimeOperation) --p.Date_B)
	 		from ras_transactjournal tj
			inner join ras_period p on p.PeriodID = tj.rf_PeriodID 
			inner join ras_stateperiod sp on sp.StatePeriodID = p.rf_StatePeriodID
	 		where 
			(PositionID = 0) and 
	 		(tj.rf_StoredLSID = @StoredLSID) 
	 		--(@Date >= tj.TransactDateTimeOperation)
			and (sp.EnumName = 'close')
			and (@Date >= p.Date_B) 	
			and (rf_PeriodID <> 0)	
		)
--		print isnull(@RestDateTime, 0 )
		if (@RestDateTime IS NULL)
		BEGIN
--			print 'asdas'
			set @res = (
			select  top 1 sum(tj.[count])
			from ras_transactjournal as tj
			inner join ras_period on rf_periodID = PeriodID
			where (rf_StoredLSID = @StoredLSID) and
			(TransactDateTimeOperation <= @Date)
			and rf_PeriodID <> 0 )	
		
			if (@res IS NULL) 
			begin
				set @res = 0
			end
--			print @res
			return @res
		END
	end

	set @res = (select top 1 sum(tj.[count])
	from ras_transactjournal as tj
	inner join ras_period on rf_periodID = PeriodID
	where (rf_StoredLSID = @StoredLSID) and
	(TransactDateTimeOperation BETWEEN @restDateTime AND @Date)
	and rf_PeriodID <> 0 )

	if (@res IS NULL) 
	begin
		set @res = 0
	end
	

--	print @res

RETURN @res
END

go

