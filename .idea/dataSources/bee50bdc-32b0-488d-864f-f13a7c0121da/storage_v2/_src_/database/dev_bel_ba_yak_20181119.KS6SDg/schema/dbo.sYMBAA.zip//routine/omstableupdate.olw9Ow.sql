
create PROCEDURE omsTableUpdate
	(
		@oms_t varchar(20),/*Переменная для таблицы ОМС*/
		@tmp_u varchar(20),/*Переменная для вьюшки*/ 
		@date varchar(20), /*Переменная для закрытия по дате*/
		@d_par datetime    /*переменная для даты закрытия*/
	)
AS
	SET NOCOUNT ON
-----------------------------------------------------------------------------------------------------
/*Переменные внутри процедуры*/
Declare @SQL nvarchar(max),@columns nvarchar(max),@columns2 nvarchar(max),@kluch varchar(50);
/*Название ключей для связки в запросе*/
SELECT @kluch=ISNULL(@kluch,'')+ CASE WHEN @kluch IS NULL THEN '' ELSE ' AND ' END + 't1.'+Replace([name],'IX_','')
+'=t2.'+Replace([name],'IX_','')
FROM sys.indexes 
WHERE object_id=object_id(@oms_t) and [name] like 'IX%'
/*Название колонок для запросов*/
SELECT  @columns = ISNULL(@columns,'')+ CASE WHEN @columns IS NULL THEN '' ELSE ', ' END 
+c.[name]+'=t2.'+c.[name] FROM sys.columns c
inner join sys.indexes i on i.object_id=object_id(@oms_t)
WHERE c.object_id=object_id(@tmp_u) and i.[name] like 'IX%'
and c.[name] not in (Replace(i.[name],'IX_',''),'upd')
group by c.[name]
SELECT  @columns2 = ISNULL(@columns2,'')+ CASE WHEN @columns2 IS NULL THEN '' ELSE ', ' END 
+c.[name] FROM sys.columns c
inner join sys.indexes i on i.object_id=object_id(@oms_t)
WHERE c.object_id=object_id(@tmp_u) and i.[name] like 'IX%'
and c.[name] <>'upd'
group by c.[name]
----------------------------------------------------------------------------------------------------
--Само обновление-----------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
----------------
--Вставка-------
----------------
Select @SQL='Insert into '+@oms_t+' Select 1 as x_Edition,1 as x_Status, '+@columns2+' from '+@tmp_u+' where upd=''i'''
print @SQL
EXECUTE sp_executesql @SQL
----------------
--Обновление----
----------------
Select @SQL='Update '+@oms_t+' Set x_Edition=x_Edition+1, '+@columns+' from '+@oms_t+' t1 inner join '+@tmp_u+' t2 on '+@kluch+' where upd=''u'' and '+Replace(@oms_t,'oms_','')+'ID>0'
print @SQL
EXECUTE sp_executesql @SQL
----------------
--Удаление------
----------------
/*Под удалением понимается закрытие по дате, название поля передается в процедуру*/
if @date is not NULL and @d_par is not NULL
BEGIN
Select @SQL='Update '+@oms_t+' Set x_Edition=x_Edition+1, '+@date+'=convert(datetime,'''+convert(varchar,@d_par,105)+''',105) from '+@oms_t+' t1 inner join '+@tmp_u+' t2 on '+@kluch+' where upd=''d'' and '+Replace(@oms_t,'oms_','')+'ID>0'
print @SQL
EXECUTE sp_executesql @SQL
END
------------------
--Запись с историю
------------------
Set @columns=NULL;
/*Правим колонки, теперь под таблицу с историей*/
SELECT  @columns = ISNULL(@columns,'')+ CASE WHEN @columns IS NULL THEN '' ELSE ', ' END 
+case when c.[name] like '%Operation' then 'case when upd=''d'' then ''u'' else upd end as x_Operation'
when c.[name] like '%DateTime' then 'getDate() as x_DateTime' 
when c.[name]='x_Seance' then '0 as x_Seance' else 't1.'+c.[name] end FROM sys.columns c
WHERE c.object_id=object_id('Life_'+@oms_t) and c.[name]<>Replace(@oms_t,'oms_','')+'LifeID'
/*Запрос на вставку в таблицу Life_*/
Select @SQL='Insert into Life_'+@oms_t+' Select '+@columns+' from '+@oms_t+' t1 inner join '+@tmp_u+' t2 on '+@kluch+
case when @date is NULL then ' where upd=''u'' or upd=''i''' else ' where upd=''u'' or upd=''d'' or upd=''i''' end
print @SQL
EXECUTE sp_executesql @SQL
/*Запрос на втавку в таблицу x_ObjLife*/
Select @SQL='Insert into x_ObjLife Select (Select DocTypeDefID from x_DocTypeDef where HeadTable='''+@oms_t+
''') as DocTypeDefID,'+Replace(@oms_t,'oms_','')+'ID as ObjID,x_Edition,getdate() as EditionDt,x_Status,
case when upd=''d'' then ''u'' else upd end as LastOperation, 1 as UserID from '+@oms_t+' t1 inner join '+
@tmp_u+' t2 on '+@kluch+case when @date is NULL then ' where upd<>''d''' else '' end
print @SQL
EXECUTE sp_executesql @SQL
/*Удаление временной таблицы*/
Select @SQL='if exists(select * from sysobjects where [name] like '''+@tmp_u+''') drop table '+@tmp_u
EXECUTE sp_executesql @SQL
RETURN(0)

go

