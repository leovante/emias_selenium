
CREATE PROC [dbo].[ras_RegisterDocumentJournal]
            @docGuid varchar(150),
            @docDescription int,
            @docID int,
            @num varchar(150),
            @organisation int,
            @countUP decimal(24,6),
            @summaDoc decimal(24,6),
            @state varchar(150),
            @kontrSumm decimal(24,6),
            @dateDoc datetime,
            @typPost varchar(150)
            as 
begin
 declare @count int
 Select @count = COUNT(*) from ras_DocumentJournal where DocGUID = @docGuid
 if (@count!=0)
	begin
	  Update ras_DocumentJournal
	  set rf_DocDescriptionID= @docDescription,
          DocID = @docID,
          Num = @num,
          rf_OrganisationID = @organisation,
          CountUP = @countUP,
          SummaDoc = @summaDoc,
          State = @state,
          KontrSumm = @kontrSumm,
          DocGUID = @docGuid,
          Date = @dateDoc,
		  rf_TypeDeliveryID = (select top 1 TypeDeliveryID from ras_TypeDelivery where name = @typPost)
	  where DocGUID = @docGuid
	end
else
    begin
     Insert into ras_DocumentJournal(rf_DocDescriptionID,DocID,Num,rf_OrganisationID,CountUP,SummaDoc,State,KontrSumm,DocGUID,Date, rf_TypeDeliveryID)
     values (@docDescription, @docID, @num, @organisation, @countUP, @summaDoc, @state, @kontrSumm, @docGuid, @dateDoc, 
			 (select top 1 TypeDeliveryID from ras_TypeDelivery where name = @typPost))
    end	
end
go

