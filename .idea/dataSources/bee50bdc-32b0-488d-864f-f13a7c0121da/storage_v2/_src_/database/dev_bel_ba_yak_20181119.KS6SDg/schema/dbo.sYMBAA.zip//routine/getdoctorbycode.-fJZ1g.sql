
create  FUNCTION [dbo].[GetDoctorByCode] (@Field varchar(50))  
RETURNS varchar(150)   AS  
BEGIN 
return ''
end
go

