CREATE VIEW [V_ras_ExtractedLSfromReestr] AS SELECT 
[hDED].[ExtractedLSfromReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrganisationOwnerID] as [rf_OrganisationOwnerID], 
[hDED].[rf_OrganisationOwnerIDHost] as [rf_OrganisationOwnerIDHost], 
[hDED].[rf_OrganisationByDemandID] as [rf_OrganisationByDemandID], 
[hDED].[rf_OrganisationByDemandIDHost] as [rf_OrganisationByDemandIDHost], 
[jT_ras_Organisation].[Name] as [SILENT_rf_OrganisationByDemandID], 
[hDED].[rf_NDSID] as [rf_NDSID], 
[hDED].[rf_DPCPharmacyRecipeID] as [rf_DPCPharmacyRecipeID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[hDED].[Bill_Num] as [Bill_Num], 
[hDED].[Bill_Date] as [Bill_Date], 
[hDED].[OGRN_OUT] as [OGRN_OUT], 
[hDED].[CODE_OUT] as [CODE_OUT], 
[hDED].[OGRN_IN] as [OGRN_IN], 
[hDED].[CODE_IN] as [CODE_IN], 
[hDED].[Count] as [Count], 
[hDED].[Price] as [Price], 
[hDED].[RECIPEGUID] as [RECIPEGUID], 
[hDED].[C_LSFO] as [C_LSFO], 
[hDED].[C_PFS] as [C_PFS], 
[hDED].[DATE_BP] as [DATE_BP], 
[hDED].[GTD] as [GTD], 
[hDED].[SERT_NUM] as [SERT_NUM], 
[hDED].[UPLOAD_DATE] as [UPLOAD_DATE], 
[hDED].[SH_CODE] as [SH_CODE], 
[hDED].[EAN13] as [EAN13], 
[hDED].[SERIES] as [SERIES], 
[hDED].[PARTIA] as [PARTIA], 
[hDED].[SUM_OPL] as [SUM_OPL], 
[hDED].[TYPEPOST] as [TYPEPOST], 
[hDED].[DateExp] as [DateExp]
FROM [ras_ExtractedLSfromReestr] as [hDED]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationByDemandID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationByDemandIDHost]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
go

