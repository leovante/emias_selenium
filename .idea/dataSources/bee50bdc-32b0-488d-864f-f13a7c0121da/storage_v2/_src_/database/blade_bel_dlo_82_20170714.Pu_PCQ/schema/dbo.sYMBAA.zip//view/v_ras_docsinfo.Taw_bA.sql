
create VIEW [dbo].[V_ras_DocsInfo] AS
SELECT 
	tj.TransactJournalID, 
	tj.TransactDateTimeOperation, 
	tj.rf_StoredLSID, 
	tj.rf_StoredLSIDHost,
	isnull(tj.[Count],0.00) count, 
	tj.bInput, 
	tj.bOutput, 
	tj.rf_DocDescriptionID, 
	tj.PositionID, 
	tj.PositionIDHost,
	dd.NameTable,
	case 
		when dd.NameTable = 'BillRevaluation'  and tj.bOutput =1 
		then dd.NameType + ' - Возврат поставщику'
		when dd.NameTable = 'BillRevaluation'  and tj.bInput =1 
		then dd.NameType + ' - Оприходование по новой цене'
		else dd.NameType
	end as NameType, 
	dd.NamePosition,  
	'DocNum' =  CASE  
	WHEN dd.NameTable = 'BillDocument' 
		THEN 
			case jO2.NUM 
			when null then jT2.Num  
			when '' then jT2.Num 
			else jO2.NUM  + ' ('+jT2.Num +')'
			end
	WHEN dd.NameTable = 'BillExtracted' 
		THEN jT3.Num  
	WHEN dd.NameTable = 'BillShift' 
		THEN case jT4_1.NUM 
			when null then jT4.Num 
			when '' then jT4.Num
			else convert(varchar(100), jT4_1.NUM)  + ' ('+jT4.Num +')'
			end 
	WHEN dd.NameTable = 'WriteOffArticle' 
		THEN jT5.Num
	WHEN dd.NameTable = 'Posting' 
		THEN jT6.Num
	WHEN dd.NameTable = 'Report' 
		THEN  r7.Series_Recipe+' '+cast(r7.Num_Recipe as varchar(50))+' (' + jT7.Num +')'
	WHEN dd.NameTable = 'BillReturnProvider' 
		THEN jT8.Num
	WHEN dd.NameTable = 'BillReturnClient' 
		THEN jT9.Num
	WHEN dd.NameTable = 'BillRevaluation' 
		THEN jT10.Num
	WHEN dd.NameTable = 'ReportToComitent' 
		THEN  r11.Series_Recipe+' '+cast(r11.Num_Recipe as varchar(50))+' (' +jT11.Num+')'
	WHEN dd.NameTable = 'WriteOffPurposeList'
		THEN wpl.Num
	--WHEN dd.NameTable = 'BillAktNotSeries' 
	--	THEN jT12.Num

	ELSE NULL 
	END,  
	'DocID'  =  CASE  
	WHEN dd.NameTable = 'BillDocument' 
		THEN 
			jT2.BillDocumentID 
	WHEN dd.NameTable = 'BillExtracted' 
		THEN jT3.BillExtractedID  
	WHEN dd.NameTable = 'BillShift' 
		THEN jT4.BillShiftID
	WHEN dd.NameTable = 'WriteOffArticle' 
		THEN jT5.WriteOffArticleID
	WHEN dd.NameTable = 'Posting' 
		THEN jT6.PostingID
	WHEN dd.NameTable = 'Report' 
		THEN  r7.DPCPharmacyRecipeID
	WHEN dd.NameTable = 'BillReturnProvider' 
		THEN jT8.BillReturnProviderID
	WHEN dd.NameTable = 'BillReturnClient' 
		THEN jT9.BillReturnClientID
	WHEN dd.NameTable = 'BillRevaluation' 
		THEN jT10.BillRevaluationID
	WHEN dd.NameTable = 'ReportToComitent' 
		THEN  r11.PharmacyRecipeID
	WHEN dd.NameTable = 'WriteOffPurposeList'
		THEN wpl.WriteOffPurposeListID
	--WHEN dd.NameTable = 'BillAktNotSeries' 
	--	THEN jT12.Num

	ELSE NULL 
	END,  

	'DocDate' =  CASE  
	WHEN dd.NameTable = 'BillDocument' 
		THEN jT2.Date_fact 
	WHEN dd.NameTable = 'BillExtracted' 
		THEN jT3.[Date]  
	WHEN dd.NameTable = 'BillShift' 
		THEN jT4.[Date]
	WHEN dd.NameTable = 'WriteOffArticle' 
		THEN jT5.[Date]
	WHEN dd.NameTable = 'Posting' 
		THEN jT6.Date_fact 
	WHEN dd.NameTable = 'Report' 
		THEN r7.[Date_Otp]
	WHEN dd.NameTable = 'BillReturnProvider' 
		THEN jT8.[Date]
	WHEN dd.NameTable = 'BillReturnClient' 
		THEN jT9.[Date]
	WHEN dd.NameTable = 'BillRevaluation' 
		THEN jT10.[Date]
	WHEN dd.NameTable = 'ReportToComitent' 
		THEN r11.[Date_otp]
	WHEN dd.NameTable = 'WriteOffPurposeList'
		THEN pwpl.Date
	--WHEN dd.NameTable = 'BillAktNotSeries' 
	--	THEN jT12.[Date]
	ELSE NULL 
	END,  


'DocState' =  CASE  
	WHEN dd.NameTable = 'BillDocument' 
		THEN jS2.[name]
	WHEN dd.NameTable = 'BillExtracted' 
		THEN jS3.[name] 
	WHEN dd.NameTable = 'BillShift' 
		THEN jS4.[name]
	WHEN dd.NameTable = 'WriteOffArticle' 
		THEN jS5.[name]
	WHEN dd.NameTable = 'Posting' 
		THEN jS6.[name]
	WHEN dd.NameTable = 'Report' 
		THEN jS7.[name]
	WHEN dd.NameTable = 'BillReturnProvider' 
		THEN jS8.[name]
	WHEN dd.NameTable = 'BillReturnClient' 
		THEN jS9.[name]
	WHEN dd.NameTable = 'BillRevaluation' 
		THEN jS10.[name]
	WHEN dd.NameTable = 'ReportToComitent' 
		THEN jS11.[name]
	WHEN dd.NameTable = 'WriteOffPurposeList' 
		THEN spwpl.[name]		
	--WHEN dd.NameTable = 'BillAktNotSeries' 
	--	THEN jS12.[name]
	ELSE NULL 
	END,
	'DocDateOP' =  CASE  
	WHEN dd.NameTable = 'BillDocument' 
		THEN jT2.DateOP  
	WHEN dd.NameTable = 'BillExtracted' 
		THEN jT3.DateOP  
	WHEN dd.NameTable = 'BillShift' 
		THEN jT4.DateOP
	WHEN dd.NameTable = 'WriteOffArticle' 
		THEN jT5.DateOP
	WHEN dd.NameTable = 'Posting' 
		THEN jT6.DateOP
	WHEN dd.NameTable = 'Report' 
		THEN NULL
	WHEN dd.NameTable = 'BillReturnProvider' 
		THEN jT8.DateOP
	WHEN dd.NameTable = 'BillReturnClient' 
		THEN jT9.DateOP
	WHEN dd.NameTable = 'BillRevaluation' 
		THEN jT10.Date_OP
	WHEN dd.NameTable = 'ReportToComitent' 
		THEN NULL 
	--WHEN dd.NameTable = 'BillAktNotSeries' 
	--	THEN jT12.DateOP
	ELSE NULL 
	END,  
	'DocStore' =  
	CASE  
	WHEN dd.NameTable = 'BillDocument' 
		THEN (select top 1 StoreName 
		      from ras_store 
		      where StoreID =  jT2.rf_StoreID and HostStoreID =  jT2.rf_StoreIDHost)  
	WHEN dd.NameTable = 'BillExtracted' 
		THEN (select top 1 StoreName 
			from ras_store 
			where StoreID =  jT3.rf_StoreID and HostStoreID =  jT3.rf_StoreIDHost)  
	WHEN dd.NameTable = 'BillShift' 
		THEN (select top 1 'Источник: ' + StoreName 
			from ras_store 
			where StoreID =  jT4.rf_StoreSourseID and HostStoreID =  jT4.rf_StoreSourseIDHost) 
			+ (select top 1 ' Приемник: ' + StoreName 
			from ras_store 
			where StoreID =  jT4.rf_StoreDestinationID and HostStoreID =  jT4.rf_StoreDestinationIDHost) 

	WHEN dd.NameTable = 'WriteOffArticle' 
		THEN (select top 1 StoreName 
			from ras_store 
			where StoreID =  jT5.rf_StoreID and HostStoreID =  jT5.rf_StoreIDHost ) 
	WHEN dd.NameTable = 'Posting' 
		THEN (select top 1 StoreName 
			from ras_store 
			where StoreID =  jT6.rf_StoreID and HostStoreID =  jT6.rf_StoreIDHost ) 
	WHEN dd.NameTable = 'Report' 
		THEN (select top 1 StoreName 
			from ras_store 
			where StoreID =  jT7.rf_StoreID and HostStoreID =  jT7.rf_StoreIDHost  ) 
	WHEN dd.NameTable = 'BillReturnProvider' 
		THEN (select top 1 StoreName 
			from ras_store 
			where StoreID =  jT8.rf_StoreID and HostStoreID =  jT8.rf_StoreIDHost   ) 
	WHEN dd.NameTable = 'BillReturnClient' 
		THEN (select top 1 StoreName 
			from ras_store 
			where StoreID =  jT9.rf_StoreID and HostStoreID =  jT9.rf_StoreIDHost  ) 
	WHEN dd.NameTable = 'BillRevaluation' 
		THEN (select top 1 StoreName 
			from ras_store 
			where StoreID =  jT10.rf_StoreID and HostStoreID =  jT10.rf_StoreIDHost   ) 
	WHEN dd.NameTable = 'ReportToComitent' 
		THEN (select top 1 StoreName 
			from ras_store 
			where StoreID =  jT11.rf_StoreID and HostStoreID =  jT11.rf_StoreIDHost   ) 
	WHEN dd.NameTable = 'WriteOffPurposeList' 
		THEN (select top 1 StoreName 
			from ras_store 
			where StoreID =  wpl.rf_StoreID and HostStoreID =  wpl.rf_StoreIDHost   ) 
	--WHEN dd.NameTable = 'BillAktNotSeries' 
	--	THEN (select top 1 StoreName 
	--		from ras_store 
	--		where StoreID =  jT12.rf_StoreID and StoreID =  jT12.rf_StoreID   ) 
	ELSE NULL 
	END,    
	'Responsible' =  CASE  
	WHEN dd.NameTable = 'BillDocument' 
		THEN (select top 1 (Family + ' ' + [Name] + ' ' + OT)  
		from ras_Responsible where ResponsibleID = jT2.rf_ResponsibleID and HostResponsibleID = jT2.rf_ResponsibleIDHost ) 
	WHEN dd.NameTable = 'BillExtracted' 
		THEN (select top 1 (Family + ' ' + [Name] + ' ' + OT)  
			from ras_Responsible 
			where ResponsibleID = jT3.rf_ResponsibleID and HostResponsibleID = jT3.rf_ResponsibleIDHost) 
	WHEN dd.NameTable = 'BillShift' 
		THEN  (select top 1 (Family + ' ' + [Name] + ' ' + OT)  
			from ras_Responsible 
			where ResponsibleID = jT4.rf_ResponsibleID and HostResponsibleID = jT4.rf_ResponsibleIDHost)
	WHEN dd.NameTable = 'WriteOffArticle' 
		THEN   (select top 1 (Family + ' ' + [Name] + ' ' + OT)  
			from ras_Responsible 
			where ResponsibleID = jT5.rf_ResponsibleID and HostResponsibleID = jT5.rf_ResponsibleIDHost)
	WHEN dd.NameTable = 'Posting' 
		THEN  (select top 1 (Family + ' ' + [Name] + ' ' + OT)  
			from ras_Responsible 
			where ResponsibleID = jT6.rf_ResponsibleID and HostResponsibleID = jT6.rf_ResponsibleIDHost)
	WHEN dd.NameTable = 'Report' 
		THEN  NULL
	WHEN dd.NameTable = 'BillReturnProvider' 
		THEN  (select top 1 (Family + ' ' + [Name] + ' ' + OT)  
			from ras_Responsible 
			where ResponsibleID = jT8.rf_ResponsibleID and HostResponsibleID = jT8.rf_ResponsibleIDHost)
	WHEN dd.NameTable = 'BillReturnClient' 
		THEN  (select top 1 (Family + ' ' + [Name] + ' ' + OT)  
			from ras_Responsible 
			where ResponsibleID = jT9.rf_ResponsibleID and HostResponsibleID = jT9.rf_ResponsibleIDHost)
	WHEN dd.NameTable = 'BillRevaluation' 
		THEN  (select top 1 (Family + ' ' + [Name] + ' ' + OT)  
			from ras_Responsible 
			where ResponsibleID = jT10.rf_ResponsibleID and HostResponsibleID = jT10.rf_ResponsibleIDHost)
	WHEN dd.NameTable = 'ReportToComitent' 
		THEN NULL
	--WHEN dd.NameTable = 'BillAktNotSeries' 
	--	THEN  (select top 1 (Family + ' ' + [Name] + ' ' + OT)  
	--		from ras_Responsible 
	--		where ResponsibleID = jT12.rf_ResponsibleID and HostResponsibleID = jT12.rf_ResponsibleIDHost)
	ELSE NULL 
	END , 
	'OrgClientName' =  CASE  
	WHEN dd.NameTable = 'BillDocument' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT2.rf_OrganisationClientID and HostOrganisationID =  jT2.rf_OrganisationClientIDHost)  
	WHEN dd.NameTable = 'BillExtracted' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT3.rf_OrganisationClientID and HostOrganisationID =  jT3.rf_OrganisationClientIDHost)  
	WHEN dd.NameTable = 'BillShift' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT4.rf_OrganisationID and HostOrganisationID =  jT4.rf_OrganisationIDHost) 
	WHEN dd.NameTable = 'WriteOffArticle' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT5.rf_OrganisationID and HostOrganisationID =  jT5.rf_OrganisationIDHost ) 
	WHEN dd.NameTable = 'Posting' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT6.rf_OrganisationID and HostOrganisationID =  jT6.rf_OrganisationIDHost ) 
	WHEN dd.NameTable = 'Report' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT7.rf_OrganisationClientID and HostOrganisationID =  jT7.rf_OrganisationClientIDHost) 
	WHEN dd.NameTable = 'BillReturnProvider' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT8.rf_OrganisationClientID and HostOrganisationID =  jT8.rf_OrganisationClientIDHost) 
	WHEN dd.NameTable = 'BillReturnClient' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT9.rf_OrganisationClientID and HostOrganisationID =  jT9.rf_OrganisationClientIDHost) 
	WHEN dd.NameTable = 'BillRevaluation' 
		THEN NULL
	WHEN dd.NameTable = 'ReportToComitent' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT11.rf_OrganisationClientID and HostOrganisationID =  jT11.rf_OrganisationClientIDHost) 
	WHEN dd.NameTable = 'WriteOffPurposeList' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  wpl.rf_OrganisationID and HostOrganisationID =  wpl.rf_OrganisationIDHost) 
	--WHEN dd.NameTable = 'BillAktNotSeries' 
	--	THEN  (select top 1 [Name] 
	--		from ras_organisation 
	--		where OrganisationID =  jT12.rf_OrganisationID and HostOrganisationID =  jT12.rf_OrganisationIDHost) 
	ELSE NULL 
	END,  
	'OrgAgentName' =  CASE  
	WHEN dd.NameTable = 'BillDocument' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT2.rf_OrganisationAgentID and HostOrganisationID =  jT2.rf_OrganisationAgentIDHost)  
	WHEN dd.NameTable = 'BillExtracted' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT3.rf_OrganisationAgentID and HostOrganisationID =  jT3.rf_OrganisationAgentIDHost)   
	WHEN dd.NameTable = 'BillShift' 
		THEN NULL 
	WHEN dd.NameTable = 'WriteOffArticle' 
		THEN NULL 
	WHEN dd.NameTable = 'Posting' 
		THEN NULL 
	WHEN dd.NameTable = 'Report' 
		THEN NULL 
	WHEN dd.NameTable = 'BillReturnProvider' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT8.rf_OrganisationAgentID and HostOrganisationID =  jT8.rf_OrganisationAgentIDHost) 
	WHEN dd.NameTable = 'BillReturnClient' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT9.rf_OrganisationAgentID and HostOrganisationID =  jT9.rf_OrganisationAgentIDHost ) 
	WHEN dd.NameTable = 'BillRevaluation' 
		THEN NULL 
	WHEN dd.NameTable = 'ReportToComitent' 
		THEN NULL 
	WHEN dd.NameTable = 'BillAktNotSeries' 
		THEN NULL 
	ELSE NULL 
	END  ,
	'OrgProviderName' =  CASE  
	WHEN dd.NameTable = 'BillDocument' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT2.rf_OrganisationProviderID and HostOrganisationID =  jT2.rf_OrganisationProviderIDHost ) 
	WHEN dd.NameTable = 'BillExtracted' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT3.rf_OrganisationProviderID and HostOrganisationID =  jT3.rf_OrganisationProviderIDHost) 
	WHEN dd.NameTable = 'BillShift' 
		THEN NULL
	WHEN dd.NameTable = 'WriteOffArticle' 
		THEN NULL 
	WHEN dd.NameTable = 'Posting' 
		THEN NULL 
	WHEN dd.NameTable = 'Report' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT7.rf_OrganisationProviderID and HostOrganisationID =  jT7.rf_OrganisationProviderIDHost ) 
	WHEN dd.NameTable = 'BillReturnProvider' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT8.rf_OrganisationProviderID and HostOrganisationID =  jT8.rf_OrganisationProviderIDHost ) 
	WHEN dd.NameTable = 'BillReturnClient' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT9.rf_OrganisationProviderID and HostOrganisationID =  jT9.rf_OrganisationProviderIDHost) 
	WHEN dd.NameTable = 'BillRevaluation' 
		THEN NULL
	WHEN dd.NameTable = 'ReportToComitent' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT11.rf_OrganisationProviderID and HostOrganisationID =  jT11.rf_OrganisationProviderIDHost ) 
	WHEN dd.NameTable = 'BillAktNotSeries' 
		THEN NULL 
	ELSE NULL 
	END,   
	'OrgContragentName' =  CASE  
	WHEN dd.NameTable = 'BillDocument' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT2.rf_OrganisationContragent ) 
	WHEN dd.NameTable = 'BillExtracted' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT3.rf_OrganisationContragent ) 
	WHEN dd.NameTable = 'BillShift' 
		THEN NULL
	WHEN dd.NameTable = 'WriteOffArticle' 
		THEN NULL
	WHEN dd.NameTable = 'Posting' 
		THEN NULL
	WHEN dd.NameTable = 'Report' 
		THEN NULL
	WHEN dd.NameTable = 'BillReturnProvider'  
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT8.rf_OrganisationContragentID ) 
	WHEN dd.NameTable = 'BillReturnClient' 
		THEN (select top 1 [Name] 
			from ras_organisation 
			where OrganisationID =  jT9.rf_OrganisationContragentID ) 
	WHEN dd.NameTable = 'BillRevaluation' 
		THEN NULL
	WHEN dd.NameTable = 'ReportToComitent' 
		THEN NULL
	WHEN dd.NameTable = 'BillAktNotSeries' 
		THEN NULL
		ELSE NULL 
	END,
	'DocNumber' = CASE
	WHEN dd.NameTable = 'BillDocument'
		then jT2.Num
	WHEN dd.NameTable = 'BillExtracted' 
		then jT3.Num
	WHEN dd.NameTable = 'BillShift'
		then jT4.Num
	WHEN dd.NameTable = 'WriteOffArticle' 
		then jT5.Num
	WHEN dd.NameTable = 'Posting' 
		then jT6.Num
	WHEN dd.NameTable = 'Report' 
		then jT7.Num
	WHEN dd.NameTable = 'BillReturnProvider'
		then jT8.Num
	WHEN dd.NameTable = 'BillReturnClient'
		then jT9.Num
	WHEN dd.NameTable = 'BillRevaluation' 
		then jT10.Num
	WHEN dd.NameTable = 'ReportToComitent' 
		then jT11.Num
	END,
	'OrgByDemandName' = CASE
	WHEN dd.NameTable = 'BillDocument'
		then (select top 1 [NAME]
			from ras_Organisation
			where OrganisationID = jT2.rf_OrganisationByDemandID and HostOrganisationID = jT2.rf_OrganisationByDemandIDHost)
	WHEN dd.NameTable = 'BillExtracted' 
		then (select top 1 [NAME]
			from ras_Organisation
			where OrganisationID = jT3.rf_OrganisationByDemandID and HostOrganisationID = jT3.rf_OrganisationByDemandIDHost)
	WHEN dd.NameTable = 'BillShift'
		then (select top 1 [NAME]
			from ras_Organisation
			where OrganisationID = jT4.rf_OrganisationByDemandID and HostOrganisationID = jT4.rf_OrganisationByDemandIDHost)
	WHEN dd.NameTable = 'WriteOffArticle' 
		then NULL
	WHEN dd.NameTable = 'Posting' 
		then (select top 1 [NAME]
			from ras_Organisation
			where OrganisationID = jT6.rf_OrganisationByDemandID and HostOrganisationID = jT6.rf_OrganisationByDemandIDHost)
	WHEN dd.NameTable = 'Report' 
		then NULL
	WHEN dd.NameTable = 'BillReturnProvider'
		then NULL
	WHEN dd.NameTable = 'BillReturnClient'
		then NULL
	WHEN dd.NameTable = 'BillRevaluation' 
		then NULL
	WHEN dd.NameTable = 'ReportToComitent' 
		then NULL
	END
FROM ras_transactjournal tj 
INNER JOIN ras_DocDescription dd 
	ON dd.DocDescriptionID = tj.rf_DocDescriptionID  
-- billdocument приход
LEFT JOIN (ras_PositionBill jP2 
		INNER JOIN ras_BillDocument jT2 
		LEFT JOIN ras_BillEx_Other jO2 on jT2.rf_BillEx_OtherID = jO2.BillEx_OtherID and jT2.rf_BillEx_OtherIDHost = jO2.HostBillEx_OtherID
		inner join ras_state jS2 on jS2.StateID = jT2.rf_StateID
		ON jT2.BillDocumentID = jP2.rf_BillDocumentID and jT2.HostBillDocumentID = jP2.rf_BillDocumentIDHost ) 
	ON jP2.PositionBillID = tj.PositionID  and jP2.HostPositionBillID = tj.PositionIDHost
-- billextracted - расход
LEFT JOIN (ras_PositionBillEx jP3 
		INNER JOIN ras_BillExtracted jT3 
		ON jT3.BillExtractedID = jP3.rf_BillExtractedID and jT3.HostBillExtractedID = jP3.rf_BillExtractedIDHost
inner join ras_StateExBill jS3 on jT3.rf_StateExBillID = jS3.StateExBillID
		) 

	ON jP3.PositionBillExID = tj.PositionID  and jP3.HostPositionBillExID = tj.PositionIDHost  

--BillShift Документ - перемещение 
LEFT JOIN (ras_PositionBillShift jP4 
		INNER JOIN ras_BillShift jT4 
		ON jT4.BillShiftID = jP4.rf_BillShiftID and jT4.HostBillShiftID = jP4.rf_BillShiftIDHost 
		inner join ras_StateBillShift jS4 on jT4.rf_StateBillShiftID = jS4.StateBillShiftID
		LEFT JOIN  ras_BillRequest jT4_1 on jT4.rf_BillRequestID = jT4_1.BillRequestID
) 
	ON jP4.PositionBillShiftID = tj.PositionID  and jP4.HostPositionBillShiftID = tj.PositionIDHost  

--WriteOffArticle Документ - Списание
LEFT JOIN (ras_PositionWriteOffArticle jP5 
		INNER JOIN ras_WriteOffArticle jT5 
		ON jT5.WriteOffArticleID = jP5.rf_WriteOffArticleID and jT5.HostWriteOffArticleID = jP5.rf_WriteOffArticleIDHost 
		inner join ras_StateWriteOffArticle jS5 on jT5.rf_StateWriteOffArticleID = jS5.StateWriteOffArticleID
) 
	ON jP5.PositionWriteOffArticleID = tj.PositionID  and jP5.HostPositionWriteOffArticleID = tj.PositionIDHost  

--Posting Документ - Оприходование
LEFT JOIN (ras_PositionPosting jP6 
		INNER JOIN ras_Posting jT6 
		ON jT6.PostingID = jP6.rf_PostingID and jT6.HostPostingID = jP6.rf_PostingIDHost 
		inner join ras_StatePosting jS6 on jT6.rf_StatePostingID = jS6.StatePostingID
) 
	ON jP6.PositionPostingID = tj.PositionID  and jP6.HostPositionPostingID = tj.PositionIDHost  

--Report Отчет комиссионера
LEFT JOIN (ras_PositionReport jP7 
		INNER JOIN ras_Report jT7 
		ON jT7.ReportID = jP7.rf_ReportID and jT7.HostReportID = jP7.rf_ReportIDHost 
		inner join ras_StateReport jS7 on jT7.rf_StateReportID = jS7.StateReportID) 
	ON jP7.PositionReportID = tj.PositionID  and jP7.HostPositionReportID = tj.PositionIDHost  
left join oms_DPCPharmacyRecipe r7 on jP7.rf_DPCPharmacyRecipeID = r7.DPCPharmacyRecipeID


--BillReturnProvider Возврат поставщику
LEFT JOIN (ras_PositionBillReturnPr jP8 
		INNER JOIN ras_BillReturnProvider jT8 
		ON jT8.BillReturnProviderID = jP8.rf_BillReturnProviderID and jT8.HostBillReturnProviderID = jP8.rf_BillReturnProviderIDHost 
		inner join ras_StateBillRetProv jS8 on jT8.rf_StateBillRetProvID = jS8.StateBillRetProvID ) 
	ON jP8.PositionBillReturnPrID = tj.PositionID  and jP8.HostPositionBillReturnPrID = tj.PositionIDHost  

--BillReturnClient Возврат от клиента
LEFT JOIN (ras_PositionBillReturnCl jP9 
		INNER JOIN ras_BillReturnClient jT9 
		ON jT9.BillReturnClientID = jP9.rf_BillReturnClientID and jT9.HostBillReturnClientID = jP9.rf_BillReturnClientIDHost 
inner join ras_StateBillReturnClient jS9 on jT9.rf_StateBillReturnClientID = jS9.StateBillReturnClientID
) 
	ON jP9.PositionBillReturnClID = tj.PositionID  and jP9.HostPositionBillReturnClID = tj.PositionIDHost  
--Списание по листу назначения

left join (ras_PositionWPL pwpl 
			inner join ras_WriteOffPurposeList wpl on wpl.WriteOffPurposeListID 
											= pwpl.rf_WriteOffPurposeListID and wpl.HostWriteOffPurposeListID 
											= pwpl.rf_WriteOffPurposeListIDHost
left join ras_StatePositionWPL spwpl on spwpl.StatePositionWPLID = pwpl.rf_StatePositionWPLID )
	ON pwpl.PositionWPLID = tj.PositionID  and pwpl.HostPositionWPLID = tj.PositionIDHost  and pwpl.rf_StatePositionWPLID in (2,3,4)


--BillRevaluation Переоценка товара
LEFT JOIN (ras_PositionBillRevaluation jP10 
		INNER JOIN ras_BillRevaluation jT10 
		ON jT10.BillRevaluationID = jP10.rf_BillRevaluationID and jT10.HostBillRevaluationID = jP10.rf_BillRevaluationIDHost 
		inner join ras_StateBillRevaluation jS10 on jT10.rf_StateBillRevaluationID = jS10.StateBillRevaluationID
) 
	ON jP10.PositionBillRevaluationID = tj.PositionID  and jP10.HostPositionBillRevaluationID = tj.PositionIDHost  

--Отчет комитенту
LEFT JOIN (ras_PositionRTC jP11 
		INNER JOIN ras_ReportToComitent jT11 
		ON jT11.ReportToComitentID = jP11.rf_ReportToComitentID and jT11.HostReportToComitentID = jP11.rf_ReportToComitentIDHost 
		inner join ras_StateReport jS11 on JT11.rf_StateReportID = jS11.StateReportID
) 
	ON jP11.PositionRTCID = tj.PositionID  and jP11.HostPositionRTCID = tj.PositionIDHost  
left join oms_PharmacyRecipe r11 on jP11.rf_PharmacyRecipeID = r11.PharmacyRecipeID
WHERE 
tj.TransactJournalID <> 0
and ((pwpl.rf_StatePositionWPLID in (2,3,4) and dd.DocDescriptionID=17) or dd.DocDescriptionID!=17)
and tj.PositionID <> 0
and tj.PositionIDHost <> 0
go

