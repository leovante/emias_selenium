CREATE VIEW [V_oms_LPUList] AS SELECT 
[hDED].[LPUListID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_LPU].[MCOD] as [V_MCOD], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_TypeDoctorListID] as [rf_TypeDoctorListID], 
[jT_oms_TypeDoctorList].[Name] as [SILENT_rf_TypeDoctorListID], 
[hDED].[Date_BP] as [Date_BP], 
[hDED].[Date_EP] as [Date_EP], 
[hDED].[Rem] as [Rem]
FROM [oms_LPUList] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_TypeDoctorList] as [jT_oms_TypeDoctorList] on [jT_oms_TypeDoctorList].[TypeDoctorListID] = [hDED].[rf_TypeDoctorListID]
go

