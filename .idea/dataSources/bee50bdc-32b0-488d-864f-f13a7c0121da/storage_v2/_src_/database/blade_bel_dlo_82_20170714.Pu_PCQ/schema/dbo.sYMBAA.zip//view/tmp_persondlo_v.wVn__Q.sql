CREATE view [tmp_PersonDLO_V] as -- tmp_PersonDLO_V
select
	SS_DLO		as SS,
	S_POL		as S_POL,
	N_POL		as N_POL,
	Fam		as FAM,
	IM		as IM,
	OT		as OT,
	W		as W,
	DR		as DR,
	(case ltrim(c_katl) when '' then '0' else c_katl end) as c_kat, 
	(case ltrim(s_doc) when '' then '0' else s_doc end) as s_doc, 
	(case ltrim(n_doc) when '' then '0' else n_doc end) as n_doc,
	(case ltrim(c_doc) when '' then '0' else c_doc end) as c_doc,
	oms_okat.c_okato    as OKATO_OMS,
	oms_smo.Q_OGRN	    as QM_OGRN,
	reg_okat.c_okato    as OKATO_REG,
	D_TYPE		    as D_TYPE,
	'I'		    as op

from oms_PersonDLO 

inner join oms_TYPEDOC on rf_typedocid = typedocid
inner join oms_smo on rf_smoid = smoid 
inner join oms_okato oms_okat on rf_oms_okatoid = oms_okat.okatoid
inner join oms_okato reg_okat on rf_REG_OKATOID = reg_okat.okatoid
inner join oms_katl katl on rf_KATLID = katl.katlid

where persondloid > 0 and 
	exists(select * from oms_pharmacyrecipe
		   where rf_ARecipe_ReestrID = 1213 and rf_persondloid = persondloid)
union 
select 
	main.SS_DLO	as SS,
	main.S_POL	as S_POL,
	main.N_POL	as N_POL,
	main.Fam	as FAM,
	main.IM		as IM,
	main.OT		as OT,
	main.W		as W,
	main.DR		as DR,
	(case ltrim(c_katl) when '' then '0' else c_katl end) as c_kat, 
	(case ltrim(s_doc) when '' then '0' else s_doc end) as s_doc, 
	(case ltrim(n_doc) when '' then '0' else n_doc end) as n_doc,
	(case ltrim(c_doc) when '' then '0' else c_doc end) as c_doc,
	oms_okat.c_okato as OKATO_OMS,
	oms_smo.Q_OGRN	 as QM_OGRN,
	reg_okat.c_okato as OKATO_REG,
	main.D_TYPE	 as D_TYPE,
	'D'		 as op

from Life_oms_persondlo as main

inner join oms_TYPEDOC on main.rf_typedocid = typedocid
inner join oms_smo on main.rf_smoid = smoid 
inner join oms_okato oms_okat on main.rf_oms_okatoid = oms_okat.okatoid
inner join oms_okato reg_okat on main.rf_REG_OKATOID = reg_okat.okatoid
inner join oms_katl katl on main.rf_KATLID = katl.katlid

where main.x_Edition = (select max(sub.x_edition) 
                        from Life_oms_persondlo as sub
			where sub.persondloid=main.persondloid) 
	  and main.persondloid <> 0 
	  and main.persondloid in (select distinct ObjID from x_ObjLife 
				   where DocTypeDefID = (select doctypedefid from x_doctypedef where HeadTable = 'oms_persondlo') and 
                                         EditionDt > (select top 1 Recipe_Reestr_Begin_Date from oms_ARecipe_Reestr order by ARecipe_ReestrID desc) and 
                                         EditionDt < (select top 1 Recipe_Reestr_End_Date from oms_ARecipe_Reestr order by ARecipe_ReestrID desc) and 
                                         LastOperation='d')
go

