CREATE VIEW [V_oms_sc_MKB] AS SELECT 
[hDED].[sc_MKBID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_MKB].[DS] as [V_DS], 
[jT_oms_sc_StandartCure].[StandartName] as [V_StandartName], 
[jT_oms_MKB].[NAME] as [V_NAME], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_sc_StandartCureID] as [rf_sc_StandartCureID], 
[jT_oms_sc_StandartCure].[StandartName] as [SILENT_rf_sc_StandartCureID], 
[hDED].[Precent] as [Precent], 
[hDED].[Descriptio] as [Descriptio], 
[hDED].[Flags] as [Flags], 
[hDED].[UGuid] as [UGuid]
FROM [oms_sc_MKB] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_sc_StandartCure] as [jT_oms_sc_StandartCure] on [jT_oms_sc_StandartCure].[sc_StandartCureID] = [hDED].[rf_sc_StandartCureID]
go

