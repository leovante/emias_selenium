CREATE VIEW [dbo].[V_x_ObjLife] AS SELECT 
[hDED].[ObjLifeID], [hDED].[x_Edition], [hDED].[x_Status], 
((ISNULL(
			(select [user] = 						
					CASE [x_User].[GeneralLogin]
						WHEN '' THEN [x_User].[WindowsName]
						ELSE [x_User].[GeneralLogin]
					END
				FROM [x_User]
				where  [x_User].UserID = [hDED].UserID),						
			convert(varchar(50), [hDED].[UserID])))) as [V_User], 
(ISNULL(
		(select [docType].HeadTable FROM [x_DocTypeDef] as [docType]
			where [hDED].DocTypeDefID = [docType].DocTypeDefID),
		convert(varchar(50), [hDED].[DocTypeDefID]))) as [V_Table], 
(ISNULL(
		(select [docType].Caption FROM [x_DocTypeDef] as [docType]
			where [hDED].DocTypeDefID = [docType].DocTypeDefID),
		convert(varchar(50), [hDED].[DocTypeDefID]))) as [V_DocType], 
(case [hDED].[LastOperation]
		WHEN 'i' THEN 'Вставка'
		WHEN 'u' THEN 'Обновление'
		WHEN 'd' THEN 'Удаление'
	END) as [V_Operation], 
((ISNULL(
					(select [user] = 						
						CASE [x_User].[GeneralLogin]
							WHEN '' THEN [x_User].[WindowsName] + ' '
							ELSE [x_User].[GeneralLogin] + ' '
						END
					FROM [x_User]
					where  [x_User].UserID = [hDED].UserID),
				'Неизвестный пользователь '))
				
				+			
			(case [hDED].[LastOperation]
				WHEN 'i' THEN 
					(ISNULL(
						(select ('добавил запись в документ "' + 
							(select [docType].Caption FROM [x_DocTypeDef] as [docType]
								where [hDED].DocTypeDefID = [docType].DocTypeDefID) + '" ')),
						'добавил запись в неизвестный документ (номер = ' + 
						convert(varchar(50), [hDED].[DocTypeDefID]) + ')'))
				
				WHEN 'u' THEN 
					(ISNULL(
						(select ('отредактировал запись в документе "' + 
							(select [docType].Caption FROM [x_DocTypeDef] as [docType]
								where [hDED].DocTypeDefID = [docType].DocTypeDefID) + '" ')),
						'отредактировал запись в неизвестном документе (номер = ' + 
						convert(varchar(50), [hDED].[DocTypeDefID]) + N')'))
				
				WHEN 'd' THEN
					(ISNULL(
						(select ('удалил запись из документа "' + 
							(select [docType].Caption FROM [x_DocTypeDef] as [docType]
								where [hDED].DocTypeDefID = [docType].DocTypeDefID) + '" ')),
						'удалил запись из неизвестного документа (номер = ' + 
						convert(varchar(50), [hDED].[DocTypeDefID]) + ')'))
			END) 
				 +
				(ISNULL(
						(select (', таблица "' +
							(select [docType].HeadTable FROM [x_DocTypeDef] as [docType]
								where [hDED].DocTypeDefID = [docType].DocTypeDefID) + '"')),
						', таблица неизвестна'))) as [V_Caption], 
[hDED].[UserID] as [UserID], 
[hDED].[DocTypeDefID] as [DocTypeDefID], 
[hDED].[ObjID] as [ObjID], 
[hDED].[x_Seance] as [x_Seance], 
[hDED].[EditionDt] as [EditionDt], 
[hDED].[LastOperation] as [LastOperation]
FROM [x_ObjLife] as [hDED]
go

