
CREATE VIEW [V_x_Group] AS SELECT 
[hDED].[GroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[GUID] as [GUID], 
[hDED].[Style] as [Style], 
[hDED].[Description] as [Description], 
[hDED].[Name] as [Name]
FROM [x_Group] as [hDED]
go

