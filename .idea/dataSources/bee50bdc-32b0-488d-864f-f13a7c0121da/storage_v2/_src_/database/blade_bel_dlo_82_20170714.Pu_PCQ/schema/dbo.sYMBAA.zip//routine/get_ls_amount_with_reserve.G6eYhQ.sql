

-- Функция получает остаток товара на складе с учётом резерва
--
--
-- 20:38, 16.02.2010  Тарасов, Максименко.
CREATE FUNCTION [dbo].[get_ls_amount_with_reserve] (@StoredLSID int, @HostStoredLSID int, @Date datetime)
RETURNS decimal(18,10)
AS
BEGIN
	DECLARE @res_tj decimal(18,10)
	set @res_tj = [dbo].[get_ls_amount2](@StoredLSID, @HostStoredLSID, @Date)
	
	DECLARE @res_reserve decimal(18,10)
	
	SELECT @res_reserve =
		IsNull(SUM ([Count]), 0)
		FROM ras_Reserve
		WHERE rf_StoredLSID = @StoredLSID
		  AND rf_StoredLSIDHost = @HostStoredLSID
		  AND CreateDate <= @Date
		  AND rf_StateReserveID = 1
	
	RETURN @res_tj - @res_reserve
END
go

