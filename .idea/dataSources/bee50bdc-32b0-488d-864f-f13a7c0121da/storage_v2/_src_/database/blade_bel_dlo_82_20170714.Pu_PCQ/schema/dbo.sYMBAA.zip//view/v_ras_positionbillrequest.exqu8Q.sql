CREATE VIEW [V_ras_PositionBillRequest] AS SELECT 
[hDED].[PositionBillRequestID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[jT_ras_Nomenclature].[Name] as [SILENT_rf_NomenclatureID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID], 
[hDED].[rf_BillRequestID] as [rf_BillRequestID], 
[hDED].[CountRequested] as [CountRequested], 
[hDED].[CountGiven] as [CountGiven], 
[hDED].[Reason] as [Reason], 
[hDED].[CountRequestedDetail] as [CountRequestedDetail], 
[hDED].[CountRequestedMeasure] as [CountRequestedMeasure], 
[hDED].[CountGivenDetail] as [CountGivenDetail], 
[hDED].[CountGivenMeasure] as [CountGivenMeasure], 
[hDED].[isProcessed] as [isProcessed]
FROM [ras_PositionBillRequest] as [hDED]
INNER JOIN [ras_Nomenclature] as [jT_ras_Nomenclature] on [jT_ras_Nomenclature].[NomenclatureID] = [hDED].[rf_NomenclatureID] AND  [jT_ras_Nomenclature].[HostNomenclatureID] = [hDED].[rf_NomenclatureIDHost]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
go

