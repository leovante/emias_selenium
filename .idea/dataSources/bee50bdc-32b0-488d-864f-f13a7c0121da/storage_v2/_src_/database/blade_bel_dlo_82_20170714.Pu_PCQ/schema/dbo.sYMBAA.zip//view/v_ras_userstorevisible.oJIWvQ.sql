CREATE VIEW [V_ras_UserStoreVisible] AS SELECT 
[hDED].[UserStoreVisibleID], [hDED].[x_Edition], [hDED].[x_Status], 
((isnull((select xu.GeneralLogin from x_User xu where UserID = rf_UserID),''))) as [V_UserName], 
[jT_ras_Store].[StoreName] as [V_StoreName], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[IsEnabledSelectInWriteOff] as [IsEnabledSelectInWriteOff]
FROM [ras_UserStoreVisible] as [hDED]
INNER JOIN [ras_Store] as [jT_ras_Store] on [jT_ras_Store].[StoreID] = [hDED].[rf_StoreID] AND  [jT_ras_Store].[HostStoreID] = [hDED].[rf_StoreIDHost]
go

