CREATE VIEW [V_ras_SpecialtyOfResponsible] AS SELECT 
[hDED].[SpecialtyOfResponsibleID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_ras_Specialty].[Name] as [V_NameSpecialty], 
[hDED].[rf_ResponsibleID] as [rf_ResponsibleID], 
[hDED].[rf_ResponsibleIDHost] as [rf_ResponsibleIDHost], 
[hDED].[rf_SpecialtyID] as [rf_SpecialtyID]
FROM [ras_SpecialtyOfResponsible] as [hDED]
INNER JOIN [ras_Specialty] as [jT_ras_Specialty] on [jT_ras_Specialty].[SpecialtyID] = [hDED].[rf_SpecialtyID]
go

