CREATE view [tmp_Recipe_V] as -- tmp_Recipe_V
select * from tmp_upl_Recipe
go

