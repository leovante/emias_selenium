CREATE VIEW [dbo].[sl_sp_lf] AS 

SELECT --[LFID] [c_lf]
      --,[x_Edition]
      --,[x_Status]
     -- ,
		[C_LF]
      ,[NAME_LF]
      ,[MSG_TEXT]
      --,[NAME_LF_SL] 
  FROM [dbo].[oms_LF]

/*

SELECT [c_lf]
      ,[name_lf]
      ,[msg_text]
  FROM [Snsi].[dbo].[sp_lf]

*/
go

