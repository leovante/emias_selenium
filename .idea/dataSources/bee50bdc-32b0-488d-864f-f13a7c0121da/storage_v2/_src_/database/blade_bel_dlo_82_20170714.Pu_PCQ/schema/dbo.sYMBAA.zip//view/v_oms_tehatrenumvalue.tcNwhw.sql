CREATE VIEW [V_oms_TehAtrEnumValue] AS SELECT 
[hDED].[TehAtrEnumValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TehAtrID] as [rf_TehAtrID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [oms_TehAtrEnumValue] as [hDED]
go

