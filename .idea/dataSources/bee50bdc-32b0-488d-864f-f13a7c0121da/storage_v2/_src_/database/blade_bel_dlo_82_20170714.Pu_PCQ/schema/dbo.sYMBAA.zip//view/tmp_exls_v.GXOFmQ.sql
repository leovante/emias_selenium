CREATE view [tmp_Exls_V] as -- tmp_Exls_V
select * from tmp_upl_Exls
go

