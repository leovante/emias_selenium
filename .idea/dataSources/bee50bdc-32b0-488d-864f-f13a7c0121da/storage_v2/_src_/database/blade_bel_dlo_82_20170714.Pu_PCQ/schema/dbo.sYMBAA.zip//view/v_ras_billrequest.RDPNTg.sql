CREATE VIEW [V_ras_BillRequest] AS SELECT 
[hDED].[BillRequestID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResponsibleID] as [rf_ResponsibleID], 
[hDED].[rf_ResponsibleIDHost] as [rf_ResponsibleIDHost], 
[jT_ras_Responsible].[V_FIO] as [SILENT_rf_ResponsibleID], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[jT_ras_Store].[StoreName] as [SILENT_rf_StoreID], 
[hDED].[rf_NomenGroupID] as [rf_NomenGroupID], 
[hDED].[rf_RequestTypeID] as [rf_RequestTypeID], 
[jT_ras_RequestType].[Name] as [SILENT_rf_RequestTypeID], 
[hDED].[rf_StateRequestID] as [rf_StateRequestID], 
[jT_ras_StateRequest].[Name] as [SILENT_rf_StateRequestID], 
[hDED].[rf_RequestKindID] as [rf_RequestKindID], 
[jT_ras_RequestKind].[Name] as [SILENT_rf_RequestKindID], 
[hDED].[Num] as [Num], 
[hDED].[isCITO] as [isCITO], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[DateRequest] as [DateRequest], 
[hDED].[Purpose] as [Purpose], 
[hDED].[Note] as [Note], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[Author] as [Author], 
[hDED].[InnerNum] as [InnerNum]
FROM [ras_BillRequest] as [hDED]
INNER JOIN [V_ras_Responsible] as [jT_ras_Responsible] on [jT_ras_Responsible].[ResponsibleID] = [hDED].[rf_ResponsibleID] AND  [jT_ras_Responsible].[HostResponsibleID] = [hDED].[rf_ResponsibleIDHost]
INNER JOIN [ras_Store] as [jT_ras_Store] on [jT_ras_Store].[StoreID] = [hDED].[rf_StoreID] AND  [jT_ras_Store].[HostStoreID] = [hDED].[rf_StoreIDHost]
INNER JOIN [ras_RequestType] as [jT_ras_RequestType] on [jT_ras_RequestType].[RequestTypeID] = [hDED].[rf_RequestTypeID]
INNER JOIN [ras_StateRequest] as [jT_ras_StateRequest] on [jT_ras_StateRequest].[StateRequestID] = [hDED].[rf_StateRequestID]
INNER JOIN [ras_RequestKind] as [jT_ras_RequestKind] on [jT_ras_RequestKind].[RequestKindID] = [hDED].[rf_RequestKindID]
go

