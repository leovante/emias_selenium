CREATE VIEW [V_ras_DeliveryProcess] AS SELECT 
[hDED].[DeliveryProcessID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note]
FROM [ras_DeliveryProcess] as [hDED]
go

