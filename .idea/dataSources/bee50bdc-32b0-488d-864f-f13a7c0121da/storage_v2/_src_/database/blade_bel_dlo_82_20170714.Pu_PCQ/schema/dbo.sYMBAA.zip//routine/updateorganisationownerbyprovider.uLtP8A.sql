
CREATE PROCEDURE [dbo].[UpdateOrganisationOwnerByProvider]
as
begin
	update pos
	set pos.rf_OrganisationOwnerID = org.OrganisationID
	from ras_PositionBill pos
		inner join ras_LSFO lsfo on lsfo.LSFOID = pos.rf_LSFOID
		inner join oms_CLS cls on cls.CLSID = lsfo.rf_CLSID
		inner join oms_Tender tender on tender.TenderID = cls.rf_TenderID
		inner join oms_SFO sfo on sfo.SFOID = tender.rf_SFOID
		inner join ras_Organisation org on org.OGRN = sfo.FO_OGRN and sfo.CFO = org.Code
		inner join ras_Provider provider on provider.rf_OrganisationID = org.OrganisationID
	where (pos.rf_OrganisationOwnerID != org.OrganisationID or pos.rf_OrganisationOwnerID = 0) and pos.PositionBillID != 0

	update stls
	set stls.rf_OrganisationOwnerID = org.OrganisationID
	from ras_StoredLS stls
		inner join ras_LSFO lsfo on lsfo.LSFOID = stls.rf_LSFOID
		inner join oms_CLS cls on cls.CLSID = lsfo.rf_CLSID
		inner join oms_Tender tender on tender.TenderID = cls.rf_TenderID
		inner join oms_SFO sfo on sfo.SFOID = tender.rf_SFOID
		inner join ras_Organisation org on org.OGRN = sfo.FO_OGRN and sfo.CFO = org.Code
		inner join ras_Provider provider on provider.rf_OrganisationID = org.OrganisationID
	where (stls.rf_OrganisationOwnerID != org.OrganisationID or stls.rf_OrganisationOwnerID = 0) and stls.StoredLSID != 0

	update pos
	set pos.rf_OrganisationOwnerID = org.OrganisationID
	from ras_PositionInventarisation pos
		inner join ras_LSFO lsfo on lsfo.LSFOID = pos.rf_LSFOID
		inner join oms_CLS cls on cls.CLSID = lsfo.rf_CLSID
		inner join oms_Tender tender on tender.TenderID = cls.rf_TenderID
		inner join oms_SFO sfo on sfo.SFOID = tender.rf_SFOID
		inner join ras_Organisation org on org.OGRN = sfo.FO_OGRN and sfo.CFO = org.Code
		inner join ras_Provider provider on provider.rf_OrganisationID = org.OrganisationID
	where (pos.rf_OrganisationOwnerID != org.OrganisationID or pos.rf_OrganisationOwnerID = 0) and pos.PositionInventarisationID != 0

	update pos
	set pos.rf_OrganisationOwnerID = org.OrganisationID
	from ras_PositionBillEx_Other pos
		inner join ras_LSFO lsfo on lsfo.C_LSProvider = pos.C_LSFO 
			and lsfo.rf_NomenclatureID = pos.rf_NomenclatureID
			and lsfo.rf_ProviderID = (select top 1 ProviderID from ras_Provider where rf_OrganisationID = pos.rf_OrganisationOwnerID)
		inner join oms_CLS cls on cls.CLSID = lsfo.rf_CLSID
		inner join oms_Tender tender on tender.TenderID = cls.rf_TenderID
		inner join oms_SFO sfo on sfo.SFOID = tender.rf_SFOID
		inner join ras_Organisation org on org.OGRN = sfo.FO_OGRN and sfo.CFO = org.Code
		inner join ras_Provider provider on provider.rf_OrganisationID = org.OrganisationID
	where (pos.rf_OrganisationOwnerID != org.OrganisationID or pos.rf_OrganisationOwnerID = 0) and pos.PositionBillEx_OtherID != 0


	update pos
	set pos.rf_OrganisationOwnerID = org.OrganisationID
	from ras_PositionPosting pos
		inner join ras_LSFO lsfo on lsfo.LSFOID = pos.rf_LSFOID
		inner join oms_CLS cls on cls.CLSID = lsfo.rf_CLSID
		inner join oms_Tender tender on tender.TenderID = cls.rf_TenderID
		inner join oms_SFO sfo on sfo.SFOID = tender.rf_SFOID
		inner join ras_Organisation org on org.OGRN = sfo.FO_OGRN and sfo.CFO = org.Code
		inner join ras_Provider provider on provider.rf_OrganisationID = org.OrganisationID
	where (pos.rf_OrganisationOwnerID != org.OrganisationID or pos.rf_OrganisationOwnerID = 0) and pos.PositionPostingID != 0

	update ls
	set ls.rf_OrganisationOwnerID = org.OrganisationID
	from ras_ExtractedLSfromReestr ls
		inner join ras_LSFO lsfo on lsfo.C_LSProvider = ls.C_LSFO + '_' + cast(ls.C_PFS as varchar(max))
		inner join oms_CLS cls on cls.CLSID = lsfo.rf_CLSID
		inner join oms_Tender tender on tender.TenderID = cls.rf_TenderID
		inner join oms_SFO sfo on sfo.SFOID = tender.rf_SFOID
		inner join ras_Organisation org on org.OGRN = sfo.FO_OGRN and sfo.CFO = org.Code
		inner join ras_Provider provider on provider.rf_OrganisationID = org.OrganisationID
	where (ls.rf_OrganisationOwnerID != org.OrganisationID or ls.rf_OrganisationOwnerID = 0) and ls.ExtractedLSfromReestrID != 0
end

go

