CREATE VIEW [V_ras_StatePurposeList] AS SELECT 
[hDED].[StatePurposeListID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [ras_StatePurposeList] as [hDED]
go

