CREATE PROCEDURE Recalc  

AS
	DECLARE @clsid int, @seria varchar(30), @partia varchar(30), @count int, @temp int, @id int
	declare @old_count int
	
	delete  from oms_StoredLS

             DECLARE cur1 CURSOR FOR 
	select ExtractedLSID, rf_CLSID, series, partia, [COUNT] from oms_ExtractedLS e where e.rf_BILLID in 
		(SELECT BillsID from oms_Bills b where b.BillsID not in (select rf_BillID from oms_Bills))

	open cur1
	FETCH	NEXT FROM cur1 INTO @id, @clsid, @seria, @partia, @count
	
	while @@FETCH_STATUS = 0
	begin
		select @old_count=[COUNT] from oms_StoredLS where rf_CLSID=@clsid and series=@seria and partia=@partia
		if (select count(StoredLSID) from oms_StoredLS where rf_CLSID=@clsid and series=@seria and partia=@partia) = 0
	     		begin
				INSERT INTO [AU].[dbo].[oms_StoredLS]([x_Edition], [x_Status], [rf_BILLID], [rf_STOREID], [rf_CLSID], [GTD], [C_LSFO], [PRICE], [SUM_BASE], [NDS_PR], [NDS_SUM], [COUNT], [LIFE_DATE], [SERT_NUM], [SH_CODE], [EAN13], [SERIES], [PARTIA], [UPLOAD_DATE], [PRODUCER], [PRODUCER_LAND], [PRICE_BASE], [SUM_OPL], [PRODUCT], [CountFact])
							SELECT              [x_Edition], [x_Status], [rf_BILLID], [rf_STOREID], [rf_CLSID], [GTD], [C_LSFO], [PRICE], [SUM_BASE], [NDS_PR], [NDS_SUM], [COUNT], [LIFE_DATE], [SERT_NUM], [SH_CODE], [EAN13], [SERIES], [PARTIA], [UPLOAD_DATE], [PRODUCER], [PRODUCER_LAND], [PRICE_BASE], [SUM_OPL], [PRODUCT], [CountFact] FROM [AU].[dbo].[oms_ExtractedLS] 
							where [AU].[dbo].[oms_ExtractedLS].[ExtractedLSID]=@id
			end
		else
			begin
				UPDATE oms_StoredLS SET [count]=@old_count+@count where rf_CLSID=@clsid and series=@seria and partia=@partia
			end
		FETCH	NEXT FROM cur1 INTO @id, @clsid, @seria, @partia, @count
	end

             CLOSE cur1
	DEALLOCATE cur1
go

