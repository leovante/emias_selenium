CREATE VIEW [V_ras_RErrorRecipe] AS SELECT 
[hDED].[RErrorRecipeID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_ras_RReestrExpert].[V_NAME] as [V_ExpName], 
[jT_oms_Error].[Name] as [V_NAME], 
[jT_oms_Error].[KOD] as [V_KOD], 
[jT_ras_RRecipe].[Series_Recipe] as [V_Series_Recipe], 
[jT_ras_RRecipe].[Num_Recipe] as [V_Num_Recipe], 
[hDED].[rf_ErrorID] as [rf_ErrorID], 
[hDED].[rf_RRecipeID] as [rf_RRecipeID], 
[hDED].[rf_RReestrExpertID] as [rf_RReestrExpertID], 
[hDED].[Rem] as [Rem]
FROM [ras_RErrorRecipe] as [hDED]
INNER JOIN [V_ras_RReestrExpert] as [jT_ras_RReestrExpert] on [jT_ras_RReestrExpert].[RReestrExpertID] = [hDED].[rf_RReestrExpertID]
INNER JOIN [oms_Error] as [jT_oms_Error] on [jT_oms_Error].[ErrorID] = [hDED].[rf_ErrorID]
INNER JOIN [ras_RRecipe] as [jT_ras_RRecipe] on [jT_ras_RRecipe].[RRecipeID] = [hDED].[rf_RRecipeID]
go

