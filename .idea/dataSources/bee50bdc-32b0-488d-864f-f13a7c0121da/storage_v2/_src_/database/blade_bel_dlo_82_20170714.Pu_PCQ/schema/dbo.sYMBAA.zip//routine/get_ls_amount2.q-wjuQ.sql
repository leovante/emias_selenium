
CREATE FUNCTION [dbo].[get_ls_amount2] (@StoredLSID int, @HostStoredLSID int, @Date datetime)
RETURNS decimal(18,10)
AS
BEGIN
	DECLARE @res decimal(18,10)

	Declare @RestDateTime datetime 

	set @RestDateTime = (
		select  top 1 min(TransactDateTimeOperation)
	 		from ras_transactjournal tj
			inner join ras_period p on p.PeriodID = tj.rf_PeriodID and p.HostPeriodID = tj.rf_PeriodIDHost 
			inner join ras_stateperiod sp on sp.StatePeriodID = p.rf_StatePeriodID
	 		where 
	 		(tj.rf_StoredLSID = @StoredLSID and tj.rf_StoredLSIDHost = @HostStoredLSID) 
			and (sp.EnumName = 'open')
			and (@Date >= p.Date_B) 	
			and (rf_PeriodID <> 0)	
			and periodid <> 0
		)
	
	if (@RestDateTime  IS NULL) 
	begin
		set @RestDateTime = (select  top 1 max(TransactDateTimeOperation) 
	 		from ras_transactjournal tj
			inner join ras_period p on p.PeriodID = tj.rf_PeriodID and p.HostPeriodID = tj.rf_PeriodIDHost 
			inner join ras_stateperiod sp on sp.StatePeriodID = p.rf_StatePeriodID
	 		where 
			(PositionID = 0) and 
	 		(tj.rf_StoredLSID = @StoredLSID and tj.rf_StoredLSIDHost = @HostStoredLSID) 
			and (sp.EnumName = 'close')
			and (@Date >= p.Date_B) 	
			and (rf_PeriodID <> 0)	
		)
		if (@RestDateTime IS NULL)
		BEGIN
			set @res = (
					select top 1
			        isnull(tj.[count],0.00) as Amount
					from 
					ras_StoredLS ls
					left join
					(Select sum(tj.Count) count, tj.rf_StoredLSID, tj.rf_StoredLSIDHost 
						from ras_transactjournal tj
						inner join ras_period p on tj.rf_periodID = p.PeriodID and tj.rf_periodIDHost = p.HostPeriodID
						where  (tj.rf_StoredLSID <> 0) 
						and (TransactDateTimeOperation <=@Date)
						group by tj.rf_StoredLSID, tj.rf_StoredLSIDHost) tj on tj.rf_StoredLSID = ls.StoredLSID and tj.rf_StoredLSIDHost = ls.HostStoredLSID
					 where isnull(tj.[count],0.00)!=0 and ls.StoredLSID = @StoredLSID and ls.HostStoredLSID = @HostStoredLSID)
		
			if (@res IS NULL) 
			begin
				set @res = 0
			end
			return @res
		END
	end

	set @res = ( select top 1 isnull(tj.[count],0.00) as Amount
					from 
					ras_StoredLS ls
					left join
					(Select sum(tj.Count) count, tj.rf_StoredLSID, tj.rf_StoredLSIDHost 
						from ras_transactjournal tj
						inner join ras_period p on tj.rf_periodID = p.PeriodID and tj.rf_periodIDHost = p.HostPeriodID
						where  (tj.rf_StoredLSID <> 0) 
						and (TransactDateTimeOperation <=@Date)
						group by tj.rf_StoredLSID, tj.rf_StoredLSIDHost) tj on tj.rf_StoredLSID = ls.StoredLSID and tj.rf_StoredLSIDHost = ls.HostStoredLSID
					 where isnull(tj.[count],0.00)!=0 and ls.StoredLSID = @StoredLSID and ls.HostStoredLSID = @HostStoredLSID)

	if (@res IS NULL) 

	begin
		set @res = 0
	end

RETURN @res
END

go

