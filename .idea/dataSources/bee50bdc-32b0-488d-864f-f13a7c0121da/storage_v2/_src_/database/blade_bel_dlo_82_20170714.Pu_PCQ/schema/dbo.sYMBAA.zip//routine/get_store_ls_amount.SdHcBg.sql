

/*	
	ISidorov, 13.12.2006
	яюыєўрхЄ юёЄрЄъш ыё эр фрээюь ёъырфх
	тючтЁр•рхЄ ЄрсышЎє (StoredLSID, Amount) 

	юяЁхфхы хЄ ёэрўрыр фрЄє (RestDateTime) эрўрыр яхЁтюую юЄъЁvЄюую яхЁшюфр фы  чрфрээющ фрЄv
	хёыш Єръющ эхЄє (is null)
	юяЁхфхы хЄ фрЄє (RestDateTime) эрўрыр яюёыхфэхую чръЁvЄюую яхЁшюфр 
	
	ёєььшЁєхЄ юяхЁрЎшш яЁшїюф Ёрёїюф фы  яхЁшюфр c RestDateTime яю @Date
	
*/

CREATE FUNCTION get_store_ls_amount(@StoreID int , @Date datetime)
RETURNS @LS TABLE (StoredLSID int not NULL, 	   
		   Amount decimal(18,2) not NULL)
AS
BEGIN
	Declare @RestDateTime datetime 
	set @RestDateTime = (select top 1 min(TransactDateTimeOperation) --p.Date_B)
	 		from ras_transactjournal tj
			inner join ras_period p on p.PeriodID = tj.rf_PeriodID 
			inner join ras_stateperiod sp on sp.StatePeriodID = p.rf_StatePeriodID
			inner join ras_StoredLS sls on tj.rf_StoredLSID = sls.StoredLSID
	 		where 
			--(PositionID = 0) and 
			(sls.rf_StoredID = @StoreID)
	 		--(@Date >= tj.TransactDateTimeOperation)
			and (sp.EnumName = 'open')
			and (@Date >= p.Date_B) 	
			and (rf_PeriodID <> 0)	
		)
	if (@RestDateTime IS NULL) 
		BEGIN
			set @RestDateTime = (select top 1 max(TransactDateTimeOperation) --p.Date_B)
	 			from ras_transactjournal tj
				inner join ras_period p on p.PeriodID = tj.rf_PeriodID 
				inner join ras_stateperiod sp on sp.StatePeriodID = p.rf_StatePeriodID
				inner join ras_StoredLS sls on tj.rf_StoredLSID = sls.StoredLSID
	 			where 
				--(PositionID = 0) and 
				(sls.rf_StoredID = @StoreID)
	 			--(@Date >= tj.TransactDateTimeOperation)
				and (sp.EnumName = 'close')
				and (@Date >= p.Date_B) 	
				and (rf_PeriodID <> 0)	
			)
			if (@RestDateTime IS NULL) 
				BEGIN
					insert @LS
					select rf_StoredLSID as StoredLSID, sum(tj.[count]) as Amount 
					from ras_transactjournal tj
					inner join ras_StoredLS sls on tj.rf_StoredLSID = sls.StoredLSID
					inner join ras_period p on tj.rf_periodID = p.PeriodID

					where   (sls.rf_StoredID = @StoreID) 
					and (TransactDateTimeOperation <= @Date) 
					and tj.rf_PeriodID <> 0 
					GROUP BY rf_StoredID, rf_StoredLSID 
					HAVING (sum(tj.[count]) <> 0) 		
					RETURN	
				END
		END

	insert @LS
	select rf_StoredLSID as StoredLSID, sum(tj.[count]) as Amount 
	from ras_transactjournal tj
	inner join ras_StoredLS sls on tj.rf_StoredLSID = sls.StoredLSID
	inner join ras_period p on tj.rf_periodID = p.PeriodID

	where  	(sls.rf_StoredID = @StoreID) 
		and (TransactDateTimeOperation BETWEEN @RestDateTime and @Date)
		and tj.rf_PeriodID <> 0 
		GROUP BY rf_StoredID, rf_StoredLSID 
		HAVING (sum(tj.[count]) <> 0) 	
	RETURN 
END

go

