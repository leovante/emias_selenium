CREATE VIEW [V_oms_reestr_Sprav] AS SELECT 
[hDED].[reestr_SpravID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Num] as [Num], 
[hDED].[Date_Create] as [Date_Create], 
[hDED].[GUID] as [GUID], 
[hDED].[OGRN] as [OGRN]
FROM [oms_reestr_Sprav] as [hDED]
go

