

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateMTExpertResult](@id int, @idE int)
	
AS
BEGIN
	SET NOCOUNT ON;
if not exists(select * from oms_SMExpertResult where [rf_MTReestrID]=@id and [rf_SMExpertID]=@idE and  Nid ='-100')
begin
declare @Rem varchar(max)
select @Rem =
 'Счет '+ case when Num>0 then ' № '+Convert(varchar,Num)else '' end +' по региону: '+ O_name  from 
oms_MTReestr
inner join oms_Okato on rf_Okato_OMSId = OkatoID
where MTReestrId=@id



INSERT INTO [oms_SMExpertResult]
	([rf_MTReestrID],[rf_SMExpertID],[Code],[Caption],[Usl],[S_U],[Sluch],[S_S],[Pat],[S_P],[Info],[NId])

		select @id ,@idE ,'-' as Code,'Всего по счету :'+@Rem as Rem, count(distinct SMReestrUslID) as Usl, 
                isnull(Sum(isnull(oms_SMReestrUsl.SumV_Usl,0.0)),0) as S_U,  
                count(distinct SMReestrSluchId) as Sluch,
                isnull(Sum(oms_SMReestrSluch.SumV),0) as S_S,
                count(distinct rf_SMReestrPatientId) as Pat,
                isnull(Sum(oms_SMReestrSluch.SumV),0) as S_P,'' as Info,'-200' as ID
		from oms_SMReestrUsl 
		inner join oms_SMReestrSluch  on SMReestrSluchId=rf_SMReestrSluchId
		where  rf_MTReestrID=@id 

INSERT INTO [oms_SMExpertResult]
	([rf_MTReestrID],[rf_SMExpertID],[Code],[Caption],[Usl],[S_U],[Sluch],[S_S],[Pat],[S_P],[Info],[NId])

 
select @id ,@idE ,'-' as Code,'Всего записей без ошибок ' as Rem, Sum(Usl) as Usl,Sum(S_U) as S_U,  Sum(Sluch) as Sluch, 
			Sum(S_S) as S_S ,Sum (Pat) as Pat, Sum(S_P) as S_P, '' as Info,'000' as ID
	from (
		select  count(distinct SMReestrUslID) as Usl, isnull(Sum(oms_SMReestrUsl.SumV_Usl),0) as S_U, 0 as Sluch,0.0 as S_S,0 as Pat,0.0 as S_P
		from oms_SMReestrUsl
		inner join oms_SMReestrSluch  on SMReestrSluchId=rf_SMReestrSluchId
		left join oms_SMError on SMReestrUslId = rf_SMReestrUslID and rf_SMExpertId=@idE 
		where SMErrorId is null and oms_SMReestrSluch.rf_MTreestrId=@id
	union 
       select  0,0,0 ,0, count(distinct SMReestrPatientID), 0 as S_P from oms_SMReestrPatient
		left join oms_SMError  on rf_SMReestrPatientID=SMReestrPatientID and rf_SMExpertId=@idE
		where SMErrorID is null  and   oms_SMReestrPatient.rf_MTReestrID=@id

	union 
		select  0,0, count(distinct SMReestrSluchID),isnull(Sum(isnull(oms_SMReestrSluch.SumV,0)),0),0,0
		from oms_SMReestrSluch		 
			left outer join oms_SMError   on SMReestrSluchID = oms_SMError.rf_SMReestrSluchID and rf_SMExpertId=@idE
		where SMErrorID is null  and  oms_SMReestrSluch.rf_MTReestrID=@id
) t



INSERT INTO [oms_SMExpertResult]
	([rf_MTReestrID],[rf_SMExpertID],[Code],[Caption],[Usl],[S_U],[Sluch],[S_S],[Pat],[S_P],[Info],[NId])

    select @id ,@idE ,'-' as Code,'Всего ошибок по записям счета :'+@Rem as Rem, Sum(Usl) as Usl,Sum(S_U) as S_U,  Sum(Sluch) as Sluch, 
			Sum(S_S) as S_S ,Sum (Pat) as Pat, Sum(S_P) as S_P, '' as Info,'-100' as ID
	from (
		select  count(distinct SMReestrUslID) as Usl, isnull(Sum(isnull(oms_SMReestrUsl.SumV_Usl,0.0)),0) as S_U, 0 as Sluch,0.0 as S_S,0 as Pat,0.0 as S_P
		from oms_SMReestrUsl
			inner join (
				select  rf_SMReestrUslID
					from oms_SMError 			
				where SMErrorID>0 and oms_SMError.rf_SMReestrUslID>0 and  rf_SMExpertID=@idE
				group by rf_SMReestrUslID) 
				t on rf_SMReestrUslID=SMReestrUslID

	
	union 
		select 0,0,0 ,0,count(distinct oms_SMError.rf_SMReestrPatientID),0 as S_P
		from oms_SMError 
		where SMErrorID>0  and    oms_SMError.rf_SMReestrPatientID>0 and oms_SMError.rf_SMExpertID=@idE

	union 
		select  0,0, count(distinct SMReestrSluchID),isnull(Sum(isnull(oms_SMReestrSluch.SumV,0)),0),0,0
		from oms_SMError 
			left outer join oms_SMReestrSluch   on SMReestrSluchID = oms_SMError.rf_SMReestrSluchID
		where SMErrorID>0  and  oms_SMReestrSluch.rf_MTReestrID=@id and  rf_SMReestrSluchID>0 
) t


declare @prev int
set @prev =@@IDENTITY

INSERT INTO [oms_SMExpertResult]
	([rf_MTReestrID],[rf_SMExpertID],[Code],[Caption],[Usl],[S_U],[Sluch],[S_S],[Pat],[S_P],[Info],[NId], rf_SMexpertResultId)

	select  @id , @idE, '-1' as Code,'Ошибок в записях об услугах' as Rem,
         count(distinct SMReestrUslID) , 
		 isnull(Sum(SumV_Usl),0) ,
		 count(distinct SMReestrSluchId) as Sluch,
          isnull(Sum(isnull(oms_SMReestrSluch.SumV,0.0)),0) as S_S,
         count(distinct rf_SMReestrPatientId) as Pat,
          isnull(Sum(oms_SMReestrSluch.SumV),0) as S_P,
		'Ошибок в записях об услугах ' as Info,'-1' as ID,@prev
from oms_SMReestrUsl       
inner join (
select  rf_SMReestrUslID
		from oms_SMError 
		inner join oms_SMExpert on rf_SMExpertId = SMExpertId		
		where SMErrorID>0 and oms_SMError.rf_SMReestrUslID>0 and oms_SMExpert.rf_MTReestrID=@id and SMExpertID=@idE
group by rf_SMReestrUslID) 
t on rf_SMReestrUslID=SMReestrUslID
inner join oms_SMReestrSluch  on SMReestrSluchId=rf_SMReestrSluchId


declare @prevUsl int
set @prevUsl =@@IDENTITY

INSERT INTO [oms_SMExpertResult]
	([rf_MTReestrID],[rf_SMExpertID],[Code],[Caption],[Usl],[S_U],[Sluch],[S_S],[Pat],[S_P],[Info],[NId], rf_SMexpertResultId)
	select @id , @idE, '-2' as Code, 'Ошибок в записях о пациентах',0,0,
            0 , 0,
    count(distinct oms_SMError.rf_SMReestrPatientID),0 as S_P, 'Ошибок в записях о пациентах' as Info,'-2' as ID,@prev
	from oms_SMError 
	where SMErrorID>0  and    oms_SMError.rf_SMReestrPatientID>0 and oms_SMError.rf_SMExpertID=@idE

declare @prevPat int
set @prevPat =@@IDENTITY

INSERT INTO [oms_SMExpertResult]
	([rf_MTReestrID],[rf_SMExpertID],[Code],[Caption],[Usl],[S_U],[Sluch],[S_S],[Pat],[S_P],[Info],[NId], rf_SMexpertResultId)	

	select @id , @idE,  '-3' as Code,'Ошибок в записях о случаях' , 0,0, count(distinct SMReestrSluchID),isnull(Sum(isnull(oms_SMReestrSluch.SumV,0)),0),0,0, 'Ошибок в записях о случаях' as Info,'-3' as ID,@prev
		from oms_SMreestrSluch inner join 
		(select rf_SMreestrSluchId
		from oms_SMError 
		where SMErrorID>0  and rf_SMexpertId=@idE and rf_SMreestrSluchId>0
		group by rf_SMreestrSluchId) t on rf_SMreestrSluchId=SMreestrSluchId

declare @prevSl int
set @prevSl =@@IDENTITY

INSERT INTO [oms_SMExpertResult]
	([rf_MTReestrID],[rf_SMExpertID],[Code],[Caption],[Usl],[S_U],[Sluch],[S_S],[Pat],[S_P],[Info],[NId], rf_SMexpertResultId)
	select @id , @idE,SMCriterionCode as Code,SMCriterionCaption as Rem, Usl, S_U,Sluch, s_s, Pat, S_P, 'Ошибки в записях об услугах.'+SMCriterionRem as Info,Id,Pr
	from 
	(
		select   @prevUsl as Pr,rf_SMcriterionId as ID, count(distinct SMReestrUslID) as Usl, isnull(Sum(isnull(oms_SMReestrUsl.SumV_Usl,0.0)),0) as S_U, 
			0 as Sluch,0.0 as S_S,0 as Pat,0 as S_P
				from oms_SMReestrUsl       
				inner join (
					select  rf_SMReestrUslID,rf_SMcriterionid
					from oms_SMError 
					where SMErrorID>0 and oms_SMError.rf_SMReestrUslID>0 and rf_SMExpertID=@idE
					group by rf_SMReestrUslID,rf_SMcriterionid) 
					t on rf_SMReestrUslID=SMReestrUslID
				group by rf_SMcriterionid
		
			/*union
		select @prevPat  as Pr,rf_SMcriterionId as ID,0,0,0 ,0,count(distinct oms_SMError.rf_SMReestrPatientID),Sum(oms_SMReestrSluch.SumV)
		from oms_SMError 
			inner join oms_SMReestrSluch   on oms_SMReestrSluch.rf_SMReestrPatientID = oms_SMError.rf_SMReestrPatientID
		where SMErrorID>0  and  oms_SMReestrSluch.rf_SMReestrID=@id and  oms_SMError.rf_SMReestrPatientID>0 and oms_SMError.rf_SMExpertID=@idE
		group by rf_SMcriterionid
			Union
		select @prevSl as Pr, rf_SMCriterionID as ID, 0,0, count(distinct SMReestrSluchID),isnull(Sum(isnull(oms_SMReestrSluch.SumV,0)),0),0 ,0
		from oms_SMError 
			left outer join oms_SMReestrSluch   on SMReestrSluchID = oms_SMError.rf_SMReestrSluchID
		where SMErrorID>0  and  oms_SMReestrSluch.rf_SMReestrID=@id and  SMReestrSluchID>0  and oms_SMError.rf_SMExpertID=@idE
		group by rf_SMCriterionID*/
	) t inner join oms_SMCriterion on SMCriterionId = ID

if(exists (
					select  rf_SMcriterionid
					from oms_SMError 
					where SMErrorID>0 and oms_SMError.rf_SMReestrUslID>0 and rf_SMExpertID=@idE
					group by rf_SMcriterionid
					having count(distinct Rem)>1)) 

INSERT INTO [oms_SMExpertResult]
	([rf_MTReestrID],[rf_SMExpertID],[Code],[Caption],[Usl],[S_U],[Sluch],[S_S],[Pat],[S_P],[Info],[NId], rf_SMexpertResultId)
	select @id , @idE,SMcriterionCode as Code,Rem, Usl, S_U,Sluch, s_s, Pat, S_P, 'Ошибки в записях об услугах. Примечания' as Info,Id,
Pr
	from 
	(
		select   isnull((select max(SMExpertResultID) from oms_SMExpertResult
         where rf_SMExpertId =@idE and Nid =rf_SMcriterionId),0)  as Pr,Rem,rf_SMcriterionId as ID, count(distinct SMReestrUslID) as Usl, Sum(isnull(oms_SMReestrUsl.SumV_Usl,0.0)) as S_U, 
			0 as Sluch,0.0 as S_S,0 as Pat,0 as S_P

				from oms_SMReestrUsl       
				inner join (
					select  rf_SMReestrUslID,rf_SMcriterionid, Rem
					from oms_SMError 
					where SMErrorID>0 and oms_SMError.rf_SMReestrUslID>0 and rf_SMExpertID=@idE
					group by rf_SMReestrUslID,rf_SMcriterionid, Rem) 
					t on rf_SMReestrUslID=SMReestrUslID
				group by rf_SMcriterionid, Rem
	) t inner join oms_SMCriterion on SMCriterionId = ID






INSERT INTO [oms_SMExpertResult]
	([rf_MTReestrID],[rf_SMExpertID],[Code],[Caption],[Usl],[S_U],[Sluch],[S_S],[Pat],[S_P],[Info],[NId], rf_SMexpertResultId)
	select @id , @idE, SMCriterionCode as Code,SMCriterionCaption as Rem, Usl, S_U,Sluch, s_s, Pat, S_P, 'Ошибки в записях о пациентах.'+SMCriterionRem as Info,Id,Pr
	from 
	(
select @prevPat  as Pr,rf_SMcriterionId as ID,0 as Usl,0 as S_U,0 as Sluch ,0 as S_S,count(distinct oms_SMError.rf_SMReestrPatientID) as Pat,isnull(Sum(oms_SMReestrSluch.SumV),0) as S_P
		from oms_SMError 
			inner join oms_SMReestrSluch   on oms_SMReestrSluch.rf_SMReestrPatientID = oms_SMError.rf_SMReestrPatientID
		where SMErrorID>0  and  oms_SMReestrSluch.rf_MTReestrID=@id and  oms_SMError.rf_SMReestrPatientID>0 and oms_SMError.rf_SMExpertID=@idE
		group by rf_SMcriterionid
) t inner join oms_SMCriterion on SMCriterionId = ID

if(exists (
 select rf_SMcriterionid from  oms_SMError  
	where SMErrorID>0 and rf_SMExpertId =@idE 
and oms_SMError.rf_SMreestrPatientId>0 
group by rf_SMcriterionid
having count(distinct Rem)>1
))


INSERT INTO [oms_SMExpertResult]
	([rf_MTReestrID],[rf_SMExpertID],[Code],[Caption],[Usl],[S_U],[Sluch],[S_S],[Pat],[S_P],[Info],[NId], rf_SMexpertResultId)
	select @id , @idE,SMcriterionCode as Code,Rem, Usl, S_U,Sluch, s_s, Pat, S_P, 'Ошибки в записях о пациентах. Примечания' as Info,Id,Pr
	from 
	(
		select   isnull((select max(SMExpertResultID) from oms_SMExpertResult
         where rf_SMExpertId =@idE and Nid =rf_SMcriterionId),0) as Pr,Rem,rf_SMcriterionId as ID, 0 as Usl, 0 as S_U, 
			0 as Sluch,0.0 as S_S,count(distinct SMReestrPatientID) as Pat,0 as S_P

				from oms_SMReestrPatient       
				inner join (
					select  rf_SMReestrPatientID,rf_SMcriterionid, Rem
					from oms_SMError 
					where SMErrorID>0 and oms_SMError.rf_SMReestrPatientID>0 and rf_SMExpertID=@idE
					group by rf_SMReestrPatientID,rf_SMcriterionid, Rem) 
					t on rf_SMReestrPatientID=SMReestrPatientID

				group by rf_SMcriterionid, Rem
	) t inner join oms_SMCriterion on SMCriterionId = ID



INSERT INTO [oms_SMExpertResult]
	([rf_MTReestrID],[rf_SMExpertID],[Code],[Caption],[Usl],[S_U],[Sluch],[S_S],[Pat],[S_P],[Info],[NId], rf_SMexpertResultId)
	select @id , @idE, SMCriterionCode as Code,SMCriterionCaption as Rem, Usl, S_U,Sluch, s_s, Pat, S_P, 'Ошибки в записях о случаях.'+SMCriterionRem as Info,Id,Pr
	from 
	(
select @prevSl  as Pr,rf_SMcriterionId as ID,0 as Usl,0 as S_U,count(distinct SMReestrSluchId) as Sluch,isnull(Sum(SumV),0) as S_S ,0 as Pat,0 as S_P
		
from oms_SMReestrSluch
inner join (
select rf_SMreestrSluchId, rf_SMCriterionID from oms_SMError
where SMErrorID>0 and rf_SMExpertId =@idE and oms_SMError.rf_SMreestrSluchId>0
group by   rf_SMreestrSluchId, rf_SMCriterionID
) t  on rf_SMreestrSluchId =SMreestrSluchId  
group by rf_SMCriterionID
) t inner join oms_SMCriterion on SMCriterionId = ID

--declare @prevErrorSl int
--set @prevErrorSl =@@IDENTITY


if(exists (
 select rf_SMcriterionid from  oms_SMError  
	where SMErrorID>0 and rf_SMExpertId =@idE 
and oms_SMError.rf_SMreestrSluchId>0 
group by rf_SMcriterionid
having count(distinct Rem)>1
)) 

INSERT INTO [oms_SMExpertResult]
	([rf_MTReestrID],[rf_SMExpertID],[Code],[Caption],[Usl],[S_U],[Sluch],[S_S],[Pat],[S_P],[Info],[NId], rf_SMexpertResultId)
	select @id , @idE, SMCriterionCode as Code,Rem as Rem, Usl, S_U,Sluch, s_s, Pat, S_P, 'Ошибки в записях о случаях. Примечания'+SMCriterionRem as Info,Id,Pr
	from 
	(
select isnull((select max(SMExpertResultID) from oms_SMExpertResult
         where rf_SMExpertId =@idE and Nid =rf_SMcriterionId),0) 
  as Pr,rf_SMcriterionId as ID,Rem,0 as Usl,0 as S_U,count(distinct SMReestrSluchId) as Sluch,Sum(SumV) as S_S ,0 as Pat,0 as S_P
		
from oms_SMReestrSluch
inner join (
select rf_SMreestrSluchId, rf_SMCriterionID, Rem from oms_SMError
where SMErrorID>0 and rf_SMExpertId =@idE and oms_SMError.rf_SMreestrSluchId>0
group by   rf_SMreestrSluchId, rf_SMCriterionID, Rem
) t  on rf_SMreestrSluchId =SMreestrSluchId  
group by rf_SMCriterionID, Rem
) t inner join oms_SMCriterion on SMCriterionId = ID


end
END

go

