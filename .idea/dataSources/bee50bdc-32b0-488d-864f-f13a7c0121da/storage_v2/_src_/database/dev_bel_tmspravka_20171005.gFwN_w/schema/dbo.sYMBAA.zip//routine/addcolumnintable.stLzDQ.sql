
/****** Object:  StoredProcedure [dbo].[AddColumnInTable]    Script Date: 12/19/2009 10:55:01 ******/

/*
Сравнивает 2 таблицы 
1- темповую и 2-постоянную
и добавляют в темповую все поля, которых нет в постоянной
и проставляет этим полям значения по умолчанию
2- если в темповой какие-либо значения для обязательных полей IsNull 
то им тоже проставятся значения по умолчанию
Внимание !!!
Если вместо имени темповой таблицы внести имя какой-либо oms-вской таблицы
- ничего делаться не будет

*/
CREATE PROCEDURE [dbo].[AddColumnInTable]
	(
	
		@tab_tmp varchar(100),		--Название темповой таблицы
		@tab_oms varchar(100)		--Название постоянной таблицы
	)

AS
	SET NOCOUNT ON
BEGIN 
if (@tab_tmp <> Replace(@tab_tmp,'oms_',''))  return ;
declare @sql1 nvarchar(max)
declare @sql2 nvarchar(max)
DECLARE myCursor
CURSOR FOR 
SELECT 'alter table '+@tab_tmp+' add  '+ Column_Name +' '+DATA_TYPE
+ case when data_type ='decimal' then '('+convert(varchar,Numeric_Precision)+','+convert(varchar,Numeric_Scale)+')'
       when data_type in ('varchar','char') then  '('+convert(varchar,Character_maximum_length) +')'
  else ''
end 
+' NULL ',' Update '+@tab_tmp+' set '+Column_Name +'=' +Replace(Replace(Column_Default,'(',''),')','') 
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = @tab_oms and Column_Name not in ('x_Edition','x_Status') /**/
and Column_Default is not null and Column_name not in
(SELECT Column_Name
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = @tab_tmp	)

Open myCursor
FETCH myCursor INTO @SQL1, @SQL2
WHILE @@FETCH_STATUS = 0
 BEGIN  
  execute sp_executesql @sql1
  execute sp_executesql @sql2	
  FETCH myCursor INTO @SQL1, @SQL2
 END
CLOSE myCursor
DEALLOCATE myCursor

-- Для полей, которые не могут быть is null проставим значения по умолчанию
DECLARE AddDefault
CURSOR FOR 
SELECT ' update '+@tab_tmp+' set ['+ Column_Name+'] = '+ Column_Default +' where ['+Column_Name+'] is null'
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = @tab_oms
and Column_Default is not null and  Is_Nullable ='NO'
and Column_Name not in ('x_Edition','x_Status') 

Open AddDefault
FETCH AddDefault INTO @SQL1
WHILE @@FETCH_STATUS = 0
 BEGIN  
print @SQL1
  execute sp_executesql @sql1
  FETCH AddDefault INTO @SQL1
 END
CLOSE AddDefault
DEALLOCATE AddDefault


End
go

