CREATE VIEW [V_dmc_ValidRule] AS SELECT 
[hDED].[ValidRuleID], [hDED].[x_Edition], [hDED].[x_Status], 
(case when Sex=0 then 'Для женщин' 
when Sex =1 then  'Для мужчин' else 'Для обоих полов' end) as [V_Sex], 
[hDED].[Sex] as [Sex], 
[hDED].[AgeFrom] as [AgeFrom], 
[hDED].[AgeTo] as [AgeTo], 
[hDED].[ValidPeriod] as [ValidPeriod], 
[hDED].[UGUID] as [UGUID], 
[hDED].[IsProfi] as [IsProfi]
FROM [dmc_ValidRule] as [hDED]
go

