-- =============================================
-- Author:		Semenyakin Dmitry
-- Create date: 05.03.2012
-- Description:	Get context_info for malibu triggers use
-- =============================================
CREATE PROCEDURE [dbo].[GetMalibuContext]	
	@seanceId int output,
	@userId int output
AS
BEGIN TRY

	SET @userId = 0
	SET @seanceId = 0

	/* проверяем appName из конфига */
	
	DECLARE @app nvarchar(128)
	SET @app = APP_NAME()
	
	DECLARE @index1 int
	SET @index1 = charindex('-', @app) + 1;
	
	DECLARE @index2 int
	SET @index2 = charindex('-', @app, @index1) + 1;

	/* если есть appName берем его */
	if (@index1 > 1) AND (@index2 > @index1)
	begin
		SET @seanceId = CAST(SUBSTRING(@app, @index1, @index2 - @index1 - 1) as int);
		SET @userId = CAST(SUBSTRING(@app, @index2, LEN(@app)) as int);
		
		RETURN;
	end 
    
    DECLARE @context binary(16)
    SET @context = (select CONTEXT_INFO());    
   
	/* не нашлось контекста - выходим.*/
    if(@context is NULL OR @context = 0x0)
		RETURN;
    
    /* юзер занимает последний 4 байта, поэтому его тупо к инту */ 
    SET @userId = convert(int, @context);
    
    if(@userId is NULL OR @userId < 0)
		RETURN;
    
    DECLARE @temp bigint
    SET @temp = CONVERT(bigint, @context);
    
    /* сеанс занимает вторые 4 байта, поэтому сначала отнимает юзера, потом делим(сдвигаем вправо) на 32 бита */
    
    SET @temp = @temp - @userId;    
    SET @temp = @temp / POWER(2, 30) / 2 / 2;
    
    SET @seanceId = CONVERT(int, @temp);
    
END TRY
BEGIN CATCH

	SET @userId = 0
	SET @seanceId = 0

END CATCH

go

