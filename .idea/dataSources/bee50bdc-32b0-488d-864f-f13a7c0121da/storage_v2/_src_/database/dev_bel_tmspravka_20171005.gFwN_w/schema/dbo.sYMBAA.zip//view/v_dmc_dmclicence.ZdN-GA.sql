CREATE VIEW [V_dmc_DmcLicence] AS SELECT 
[hDED].[DmcLicenceID], [hDED].[x_Edition], [hDED].[x_Status], 
(cast(MinNum as varchar)+' - '+cast(MaxNum as varchar)) as [V_Diap], 
[hDED].[ParentGUID] as [ParentGUID], 
[hDED].[PreviousGUID] as [PreviousGUID], 
[hDED].[rf_MedicalCertificateType] as [rf_MedicalCertificateType], 
[hDED].[MaxCount] as [MaxCount], 
[hDED].[CurrentCount] as [CurrentCount], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[C_Ogrn] as [C_Ogrn], 
[hDED].[Mcod] as [Mcod], 
[hDED].[UGUID] as [UGUID], 
[hDED].[MinNum] as [MinNum], 
[hDED].[MaxNum] as [MaxNum], 
[hDED].[DateEdit] as [DateEdit]
FROM [dmc_DmcLicence] as [hDED]
go

