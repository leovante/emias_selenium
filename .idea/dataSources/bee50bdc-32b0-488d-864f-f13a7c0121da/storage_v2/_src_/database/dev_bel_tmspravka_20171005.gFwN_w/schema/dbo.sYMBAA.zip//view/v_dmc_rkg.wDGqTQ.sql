CREATE VIEW [V_dmc_Rkg] AS SELECT 
[hDED].[RkgID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Surname] as [Surname], 
[hDED].[Name] as [Name], 
[hDED].[Patronymic] as [Patronymic], 
[hDED].[BirthDay] as [BirthDay], 
[hDED].[Sex] as [Sex], 
[hDED].[S_DOC] as [S_DOC], 
[hDED].[N_DOC] as [N_DOC], 
[hDED].[DocDate] as [DocDate], 
[hDED].[C_Katl] as [C_Katl], 
[hDED].[KatlDate] as [KatlDate]
FROM [dmc_Rkg] as [hDED]
go

