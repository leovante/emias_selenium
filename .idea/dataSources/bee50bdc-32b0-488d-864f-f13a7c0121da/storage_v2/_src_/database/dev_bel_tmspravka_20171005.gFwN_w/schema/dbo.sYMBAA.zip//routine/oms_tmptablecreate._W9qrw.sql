CREATE PROCEDURE [dbo].[Oms_tmpTableCreate]
	(
		@Code_T int,				--Код таблицы с данными для загрузки НСИ
		@tab_dbf varchar(100),		--Название файла DBF
		@Result varchar(100)='' OUTPUT
	)
AS
	SET NOCOUNT ON
------------------------------------------------------------------
BEGIN TRY 
/*Переменные для процедуры*/
Declare @tab_oms varchar(100), @key_dbf varchar(400),@key_oms varchar(400),
@desc_table varchar(100),@desc_key varchar(500),@SQL nvarchar(max),@id int,@columns nvarchar(max),
@columns_u nvarchar(max),@columns_k nvarchar(max);
/*Инициализация переменных*/
Select @id=LoadNSITableID,@tab_oms=headtable,@desc_table=caption,
@SQL=Query_DBF,@key_dbf=Key_dbf,@key_oms=key_oms
from oms_LoadNSITable 
inner join x_DocTypeDef on headtable=Table_Name
where Code=@Code_T
/*Описание ключей*/
if exists(select * from sysobjects where [name] = 'tt') drop table tt
Set @SQL='Select x_DocElemDef.Caption,x_DocElemDef.Name into tt from x_DocElemDef
inner join x_DocTypeDef on x_DocElemDef.DocTypeDefID=x_DocTypeDef.DocTypeDefID
where x_DocElemDef.Name in ('+''''+Replace(@key_oms,',',''',''')+''''+') and headtable='''+@tab_oms+ ''''
print @SQL
EXECUTE sp_executesql @SQL
SELECT @desc_key = ISNULL(@desc_key,'')+ CASE WHEN @desc_key IS NULL THEN '' ELSE ', ' END +Caption from tt
/*Получение названия колонок для запроса по обновлению*/
if exists(select * from sysobjects where [name] = 'tt')
SELECT  @columns_u = ISNULL(@columns_u,'')+ CASE WHEN @columns_u IS NULL THEN '' ELSE ' OR ' END 
+case when c.collation_name is null then 't1.['+c.[name]+']<>t2.['+c.[name]+']'
else 'ltrim(rtrim(t1.['+c.[name]+']))<>ltrim(rtrim(t2.['+c.[name]+']))' end
FROM sys.columns c
inner join sys.indexes i on i.object_id=object_id(@tab_oms)
WHERE c.object_id=object_id(@tab_oms) and c.[name] not in ('x_Edition','x_Status',
Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID') and c.[name] not in (
Select [Name] from tt
)
group by c.[name],c.collation_name
/*Все колонки таблицы для вставки*/
SELECT  @columns = ISNULL(@columns,'')+ CASE WHEN @columns IS NULL THEN '' ELSE ', ' END+'t1.['+c.[name]+']' 
FROM sys.columns c
inner join sys.indexes i on i.object_id=object_id(@tab_oms)
WHERE c.object_id=object_id(@tab_oms) and c.[name] not in ('x_Edition','x_Status',
Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID') 
group by c.[name],c.collation_name
/*Колнки для связки по ключам*/
Select @columns_k = ISNULL(@columns_k,'')+ CASE WHEN @columns_k IS NULL THEN '' ELSE ' AND ' END+
'cast(t1.['+[Name]+'] as varchar(250)) COLLATE Cyrillic_General_CS_AS=cast(t2.['+[Name]+'] as varchar(250)) COLLATE Cyrillic_General_CS_AS' from tt
drop table tt
END TRY 
BEGIN CATCH 
Set @Result='Не прошла инициализация параметров для таблицы - '+@tab_oms;
END CATCH;
BEGIN TRY 
Declare @tmp_u varchar(100);
Set @tmp_u=Replace(Replace(@tab_oms,'oms_','tmp_'),'oms_','tmp_')
/*Удалить временную, если такая почему-то осталась*/
Select @SQL='if exists(select * from sysobjects where [name] like '''+@tmp_u+''') drop table '+@tmp_u
print @SQL
EXECUTE sp_executesql @SQL
/*Запрос на вставку*/
---------------------------------------------------------------------------
-- AND ' + @kluch3_2 + ' not in (select id_value from tmp_lsresult)   '
---------------------------------------------------------------------------
set @SQL ='SELECT * into '+@tmp_u+' from(
SELECT '+@columns+', ''i'' as upd  
FROM '+@tab_dbf+' t1 left outer JOIN '+
@tab_oms+' t2 ON '+@columns_k+ ' and t2.'+Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID>0'+
' WHERE t2.'+Replace(@key_oms,',',' is NULL OR t2.')+' is NULL'
/*Запрос на удаление*/
set @SQL =@SQL+' 
UNION ALL SELECT '+@columns+', ''d'' as upd  
FROM '+@tab_oms+' t1 left outer JOIN '+
@tab_dbf+' t2 ON '+@columns_k+
' WHERE (t2.'+Replace(@key_oms,',',' is NULL OR t2.')+' is NULL '+') and '+Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID>0'
/*Запрос на обновление*/
set @SQL =@SQL+' 
UNION ALL SELECT '+@columns+', ''u'' as upd  
FROM '+@tab_dbf+' t1 left outer JOIN '+
@tab_oms+' t2 ON '+@columns_k+
' WHERE '+case when @columns_u is null then '' else '('+@columns_u+') and ' end+Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID>0)t'
/*Выполнение всех запросов*/
print @SQL
EXECUTE sp_executesql @SQL
Set @Result='Проверка прошла успешно для таблицы - '+@tab_oms;
END TRY 
BEGIN CATCH 
Set @Result='Не создалась временная с обновлением для таблицы - '+@tab_oms;
END CATCH;
BEGIN TRY 
/*Запись данных об изменениях во временную таблицу*/
if not exists(select * from sysobjects where [name] = 'inf_tabl') 
Begin
	CREATE TABLE inf_tabl(
	table_n varchar(50),
	desc_table varchar(100),
	insert_n int
	,update_n int
	,close_n int
	)
end
Select @SQL='INSERT INTO inf_tabl Select '''+@tab_oms+''' as table_n,'''+@desc_table+'''as desc_table,
(select count(*) from '+@tmp_u+' where upd=''i'') as insert_n
,(select count(*) from '+@tmp_u+' where upd=''u'') as update_n,(select count(*) from '+@tmp_u+' where upd=''d'') as close_n'
print @SQL
EXECUTE sp_executesql @SQL
Set @Result='Проверка прошла успешно для таблицы - '+@tab_oms;
END TRY 
BEGIN CATCH 
Set @Result='Не создалась временная с результатами обновления для таблицы - '+@tab_oms;
END CATCH;


go

