CREATE VIEW [V_dmc_Personal] AS SELECT 
[hDED].[PersonalID], [hDED].[x_Edition], [hDED].[x_Status], 
((((select Surname + ' ' + Name + ' ' + Patronymic)))) as [V_Fio], 
[hDED].[Pcod] as [Pcod], 
[hDED].[Surname] as [Surname], 
[hDED].[Name] as [Name], 
[hDED].[Patronymic] as [Patronymic], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateEdit] as [DateEdit], 
[hDED].[Ogrn] as [Ogrn], 
[hDED].[Mcod] as [Mcod]
FROM [dmc_Personal] as [hDED]
go

