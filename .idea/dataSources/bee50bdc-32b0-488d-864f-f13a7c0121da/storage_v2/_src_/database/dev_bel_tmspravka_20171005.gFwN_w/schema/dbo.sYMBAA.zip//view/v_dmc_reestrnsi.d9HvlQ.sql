CREATE VIEW [V_dmc_ReestrNSI] AS SELECT 
[hDED].[ReestrNSIID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Num] as [Num], 
[hDED].[Rem] as [Rem], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Date] as [Date]
FROM [dmc_ReestrNSI] as [hDED]
go

