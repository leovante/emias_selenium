CREATE VIEW [V_dmc_MedicalCertificateType] AS SELECT 
[hDED].[MedicalCertificateTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[TypeCode] as [TypeCode], 
[hDED].[TypeName] as [TypeName], 
[hDED].[UGUID] as [UGUID]
FROM [dmc_MedicalCertificateType] as [hDED]
go

