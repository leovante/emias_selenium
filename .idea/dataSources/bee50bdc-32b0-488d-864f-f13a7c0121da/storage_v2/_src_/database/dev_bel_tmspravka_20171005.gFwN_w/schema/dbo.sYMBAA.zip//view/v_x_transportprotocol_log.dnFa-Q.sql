CREATE VIEW [dbo].[V_x_TransportProtocol_Log] as 
select  [TransportProtocol_LogID], [x_Edition], [x_Status], [Version], [TP_GUID], [RunDate], [OperGUID], [Comments], [Error], [LoadedFileName], [rf_UserID], [x_Seance],
(ISNULL((select top 1 GeneralLogin from x_user u where  rf_UserID = u.UserID), convert(varchar(50), rf_UserID))) as [UserVSV],  (ISNULL((select top 1 TP_NAME from x_TransportProtocol tp where  [x_TransportProtocol_Log].[TP_GUID] = tp.[TP_GUID]), '[не найден]')) as [TPNameVSV]
from [x_TransportProtocol_Log]
go

