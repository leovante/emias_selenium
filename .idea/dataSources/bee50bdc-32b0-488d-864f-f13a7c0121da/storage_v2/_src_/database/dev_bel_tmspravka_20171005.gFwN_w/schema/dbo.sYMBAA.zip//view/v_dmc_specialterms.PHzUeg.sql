CREATE VIEW [V_dmc_SpecialTerms] AS SELECT 
[hDED].[SpecialTermsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [dmc_SpecialTerms] as [hDED]
go

