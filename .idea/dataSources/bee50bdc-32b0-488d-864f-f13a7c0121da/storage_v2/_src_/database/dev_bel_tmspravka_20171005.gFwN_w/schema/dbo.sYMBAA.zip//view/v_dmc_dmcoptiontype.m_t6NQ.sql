CREATE VIEW [V_dmc_DmcOptionType] AS SELECT 
[hDED].[DmcOptionTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID]
FROM [dmc_DmcOptionType] as [hDED]
go

