CREATE VIEW [V_dmc_Citizenship] AS SELECT 
[hDED].[CitizenshipID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[NumCode] as [NumCode], 
[hDED].[UGUID] as [UGUID], 
[hDED].[FullName] as [FullName], 
[hDED].[Name] as [Name]
FROM [dmc_Citizenship] as [hDED]
go

