CREATE VIEW [V_dmc_MedicalCertificateReestr] AS SELECT 
[hDED].[MedicalCertificateReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
(((SELECT '№' + ' ' + CONVERT(varchar, ReestrNum) + ' от ' + CONVERT(varchar,ReestrDate)))) as [V_ReestrInfo], 
[jT_dmc_LpuLicence].[M_Namef] as [V_M_Namef], 
[hDED].[rf_LpuLicenceGUID] as [rf_LpuLicenceGUID], 
[hDED].[ReestrDate] as [ReestrDate], 
[hDED].[ReestrNum] as [ReestrNum], 
[hDED].[UGUID] as [UGUID]
FROM [dmc_MedicalCertificateReestr] as [hDED]
INNER JOIN [dmc_LpuLicence] as [jT_dmc_LpuLicence] on [jT_dmc_LpuLicence].[UGUID] = [hDED].[rf_LpuLicenceGUID]
go

