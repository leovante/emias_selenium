CREATE VIEW [V_dmc_DMCOptions] AS SELECT 
[hDED].[DMCOptionsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DmcOptionTypeID] as [rf_DmcOptionTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Description] as [Description], 
[hDED].[UGUID] as [UGUID]
FROM [dmc_DMCOptions] as [hDED]
go

