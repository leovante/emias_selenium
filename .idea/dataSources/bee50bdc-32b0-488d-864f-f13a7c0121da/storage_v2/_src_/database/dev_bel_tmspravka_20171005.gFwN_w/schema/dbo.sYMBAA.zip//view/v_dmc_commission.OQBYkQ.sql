CREATE VIEW [V_dmc_Commission] AS SELECT 
[hDED].[CommissionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DriverMedicalCertificateID] as [rf_DriverMedicalCertificateID], 
[hDED].[rf_PersonalID] as [rf_PersonalID], 
[hDED].[IsChairman] as [IsChairman], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [dmc_Commission] as [hDED]
go

