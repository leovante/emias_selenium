CREATE VIEW [V_dmc_DmcCertificateOptions] AS SELECT 
[hDED].[DmcCertificateOptionsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DriverMedicalCertificateID] as [rf_DriverMedicalCertificateID], 
[hDED].[rf_DMCOptionsID] as [rf_DMCOptionsID]
FROM [dmc_DmcCertificateOptions] as [hDED]
go

