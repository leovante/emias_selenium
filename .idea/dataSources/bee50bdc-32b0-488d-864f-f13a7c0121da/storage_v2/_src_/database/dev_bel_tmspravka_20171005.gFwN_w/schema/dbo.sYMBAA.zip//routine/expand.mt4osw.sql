CREATE procedure [dbo].[expand] (@current char(20)) 
 AS
   SET NOCOUNT ON
   DECLARE @lvl int, @line char(200)
   CREATE TABLE #stack (item char(200), lvl int)
   INSERT INTO #stack VALUES (@current, 1)
   SELECT @lvl = 1
   WHILE @lvl > 0
      BEGIN
         IF EXISTS (SELECT * FROM #stack WHERE lvl = @lvl)
            BEGIN
               SELECT @current = item
               FROM #stack
               WHERE lvl = @lvl

               SELECT @line = space(@lvl - 1) + @current
               update oms_LoadNSITable set Priority= @lvl
                  where Table_Name =@current

               DELETE FROM #stack
               WHERE lvl = @lvl
                  AND item = @current
				INSERT #stack
				select d.HeadTable as D1,@lvl + 1 from x_DocElemDef el
				inner join  x_DocTypeDef d  on d.DocTypeDEfID =el.DocTypeDEfID
				inner join  x_DocTypeDef d1 on el.LinkedDocTypeDefID =d1.DocTypeDEfID
				inner join oms_LoadNSITable ll on ll.Table_Name=d.HeadTable
				left outer join oms_LoadNSITable ll1 on ll1.Table_Name = d1.HeadTable
				where el.LinkedDocTypeDefID>0 and el.ElemType<>3 and ll1.Table_Name is not null
				and ll1.Table_Name =@current

               IF @@ROWCOUNT > 0
                  SELECT @lvl = @lvl + 1
            END
         ELSE
            SELECT @lvl = @lvl - 1


   END -- WHILE
go

