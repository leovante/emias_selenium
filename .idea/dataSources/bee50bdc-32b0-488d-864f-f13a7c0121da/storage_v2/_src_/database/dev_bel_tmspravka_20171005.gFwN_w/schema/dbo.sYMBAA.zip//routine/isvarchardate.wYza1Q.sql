



/* 
Функция проверяет является ли строка датой.
Входные данные:
@strDate - строка, кот надо проверить
@forNULL - переменная, кот используется, если @strDate is NULL. Если @forNULL='e', 
	то ставится дата '01/01/2222', иначе '01/01/1900'
Выходные данные:
@nDate - дата после преобразования строки @strDate
*/
Create FUNCTION [dbo].[IsVarcharDate] (@strDate varchar(20),@forNULL varchar(5))  
RETURNS datetime  AS  
BEGIN 

declare @nDate datetime;
declare @strDateN varchar(20);

if (@strDate is NULL) 
begin
	Set @nDate = case when @forNULL='e' then CONVERT(datetime,'01/01/2222',102)
	else CONVERT(datetime,'01/01/1900',102) end
end
if (charindex(' ',@strDate)>0)
begin
	Set @nDate = case when @forNULL='e' then CONVERT(datetime,'01/01/2222',102)
	else CONVERT(datetime,'01/01/1900',102) end
end
else
begin
	set @strDateN = Replace(Replace(Replace(@strDate,'/00','/01'),'/99','/01'),'9999','2222');
	Set @nDate = case when isDate(@strDateN)=1 then CONVERT(datetime,@strDateN,102)
	else case when @forNULL='e' then CONVERT(datetime,'01/01/2222',102) 
	else CONVERT(datetime,'01/01/1900',102) end end
end

return @nDate

END


go

