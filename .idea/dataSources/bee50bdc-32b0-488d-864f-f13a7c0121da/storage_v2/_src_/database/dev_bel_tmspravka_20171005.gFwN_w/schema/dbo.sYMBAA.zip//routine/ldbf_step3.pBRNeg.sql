
---------------
---------------
-- =============================================
-- Author:		Ranzou
-- Create date: <Create Date,,>
-- Description:	Третий шаг загрузки DBF
-- =============================================
CREATE PROCEDURE [dbo].[LDBF_Step3]
@PathDBF nvarchar (max),
@Priority int,
@iReestr int

AS
BEGIN
Declare @Res nvarchar(max)
Declare @SQL  nvarchar(max)


/*----------------Курсор по таблицам--------------*/

DECLARE cur_Tab SCROLL CURSOR  FOR
Select Code,oms_LoadNSITable.Table_Name,oms_LoadNSITable.Rem,LoadNSITableID
	from oms_LoadNSITable
		inner join [tmp_LoadPrepare] on tablename=Table_Name and LoadNSITableID = tableID
	where LoadNSITableID>0 and 	tmp_LoadPrepare.Priority=@Priority
order by tmp_LoadPrepare.Priority



OPEN cur_Tab
DECLARE @Code   int
DECLARE @ID   int
DECLARE @Name varchar(100)

DECLARE @Rem   varchar(200)

	FETCH FIRST FROM cur_Tab
	INTO @Code,@Name, @Rem,@ID
WHILE @@FETCH_STATUS = 0
BEGIN
begin try
	set @SQL = 'exec  dbo.Oms_omsUpdateRef '''+Convert(varchar,@Code)+'''' ;
	EXECUTE sp_executesql @SQL

	set @SQL ='Declare @Res nvarchar(max); if exists (select * from sys.all_objects where [name] =''rd_'+Convert(varchar, @Code)+''' ) begin exec dbo.Oms_omsTableUpdate  '+Convert(varchar,@Code)+' , @Res OUTPUT, 1'
               set @SQL =@SQL+' INSERT INTO [oms_LoadNSIResult]([x_Edition],[x_Status],[rf_LoadNSITableID],[ErrorName],[Name_LT],[Desc_LT],[Name_Field],[Desc_Field],[Value_Field],[Kol],[Rem],[rf_LoadNSIReestrID]) '
               set @SQL =@SQL+' select 1,1, '+ Convert(varchar,@ID)+', '''',''' + @Name +''', '''+@Rem+ ''','''','''','''',''0'',@Res,'+convert(varchar,@iReestr)+' end'
	EXECUTE sp_executesql @SQL
	print @SQL
	
	

end try

begin CATCH 
	print 'Error'
end Catch

	FETCH NEXT FROM cur_Tab
	INTO @Code,@Name, @Rem,@ID

END

DEALLOCATE cur_Tab;

END
go

