CREATE VIEW [V_dmc_DmcLicenceRanges] AS SELECT 
[hDED].[DmcLicenceRangesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DmcLicenceGUID] as [rf_DmcLicenceGUID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[MinNum] as [MinNum], 
[hDED].[MaxNum] as [MaxNum]
FROM [dmc_DmcLicenceRanges] as [hDED]
go

