



-------------------------
-------------------------
create PROCEDURE [dbo].[Oms_rd_Update]
	(
		@Code_T int,				--Код таблицы с данными для загрузки НСИ
		@tab_dbf varchar(100),		--Название файла DBF
		@Result varchar(100)='' OUTPUT
	)
AS
BEGIN TRY 
/*Переменные для процедуры*/
Declare @tab_oms varchar(100), @key_dbf varchar(400),@key_oms varchar(400),
@desc_table varchar(100),@desc_key varchar(500),@SQL nvarchar(max),@id int,@columns nvarchar(max),
@columns_u nvarchar(max),@columns_k nvarchar(max), @fieldClose nvarchar(50),@tab_name nvarchar (max);
/*Инициализация переменных*/
set @fieldClose = null
set @tab_name = 'rd_'+Convert(varchar,@Code_t)
Select @id=LoadNSITableID,@tab_oms=headtable,@desc_table=oms_LoadNSITable.Rem,
@SQL=Query_DBF,@key_dbf=Ltrim(Rtrim(Key_dbf)),@key_oms=Ltrim(Rtrim(key_oms)),@fieldClose =Ltrim(Rtrim(fieldClose))
from oms_LoadNSITable 
inner join x_DocTypeDef on headtable=Table_Name
where Code=@Code_T

/*Описание ключей*/
if exists(select * from sysobjects where [name] = 'tt') drop table tt
Set @SQL='Select x_DocElemDef.Caption,x_DocElemDef.Name into tt from x_DocElemDef
inner join x_DocTypeDef on x_DocElemDef.DocTypeDefID=x_DocTypeDef.DocTypeDefID
where x_DocElemDef.Name in ('+''''+Replace(@key_oms,',',''',''')+''''+') and headtable='''+@tab_oms+ ''''
print @SQL
EXECUTE sp_executesql @SQL
SELECT @desc_key = ISNULL(@desc_key,'')+ CASE WHEN @desc_key IS NULL THEN '' ELSE ', ' END +Caption from tt
/*Получение названия колонок для запроса по обновлению*/
if exists(select * from sysobjects where [name] = 'tt')
SELECT  @columns_u = ISNULL(@columns_u,'')+ CASE WHEN @columns_u IS NULL THEN '' ELSE ' OR ' END 
+case when c.collation_name is null then 't1.['+c.[name]+']<>t2.['+c.[name]+']'
else 'ltrim(rtrim(t1.['+c.[name]+']))<>ltrim(rtrim(t2.['+c.[name]+']))' end
FROM sys.columns c
inner join sys.indexes i on i.object_id=object_id(@tab_oms)
WHERE c.object_id=object_id(@tab_oms) and c.[name] not in ('x_Edition','x_Status',
Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID') and c.[name] not in (
Select [Name] from tt
)
group by c.[name],c.collation_name

/*Все колонки таблицы для вставки*/
SELECT  @columns = ISNULL(@columns,'')+ CASE WHEN @columns IS NULL THEN '' ELSE ', ' END+'t1.['+c.[name]+']' 
FROM sys.columns c
inner join sys.indexes i on i.object_id=object_id(@tab_oms)
WHERE c.object_id=object_id(@tab_oms) and c.[name] not in ('x_Edition','x_Status',
Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID') 
group by c.[name],c.collation_name
/*Колнки для связки по ключам*/
Select @columns_k = ISNULL(@columns_k,'')+ CASE WHEN @columns_k IS NULL THEN '' ELSE ' AND ' END+
'cast(t1.['+[Name]+'] as varchar(250)) COLLATE Cyrillic_General_CS_AS=cast(t2.['+[Name]+'] as varchar(250)) COLLATE Cyrillic_General_CS_AS' from tt
drop table tt
END TRY 
BEGIN CATCH 
Set @Result='Не прошла инициализация параметров для таблицы - '+@tab_oms;
END CATCH;
BEGIN TRY 
---------------------------------------------------------
print '000'
execute AddColumnInTable @tab_dbf, @tab_oms
print '1111'
---------------------------------------------------------
/*Запрос на вставку*/
--делаем все поля null
set @SQL=''
DECLARE cur_set_null SCROLL CURSOR  FOR 

SELECT 'alter table ['+Table_name +'] ALTER COLUMN ['+Column_Name +'] '+data_type +' '+ case when data_type='int' then '' when data_type='char' then '('+convert(varchar,CHARACTER_MAXIMUM_LENGTH)+')' when data_type='varchar' then '('+convert(varchar,CHARACTER_MAXIMUM_LENGTH)+')'  when data_type='decimal' then '('+convert(varchar,CHARACTER_MAXIMUM_LENGTH)+')' end + ' NULL'
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = @tab_name 

OPEN cur_set_null
	FETCH FIRST FROM cur_set_null 
	INTO @SQL	
WHILE @@FETCH_STATUS = 0 
BEGIN	
	EXECUTE sp_executesql @SQL	
FETCH NEXT FROM cur_set_null 
	INTO @SQL 
END	
DEALLOCATE cur_set_null

--здесь помечаются записи для обновления
set @SQL = 'update rd_'+Convert(varchar,@Code_t)+' set upd=''u'' from rd_'+Convert(varchar,@Code_t)+' t1 left outer join '+@tab_oms+' t2 ON '+@columns_k+' WHERE ('+case when @columns_u is null then '' else '('+@columns_u+') and  ' end+Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID>0)'
print @SQL
EXECUTE sp_executesql @SQL

--здесь помечаются записи для вставки
set @SQL = 'update rd_'+Convert(varchar,@Code_t)+' set upd=''i'' from rd_'+Convert(varchar,@Code_t)+' t1 left outer join '+@tab_oms+' t2 ON '+@columns_k+ ' and t2.'+Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID>0 WHERE t2.'+Replace(@key_oms,',',' is NULL OR t2.')+' is NULL '
print @SQL
EXECUTE sp_executesql @SQL

----вставляются удаляемые записи
set @SQL = 'insert into rd_'+Convert(varchar,@Code_t)+' ('+@key_oms+',upd) select t1.'+replace(@key_oms,',',',t1.')+',''d'' from '+@tab_oms+' t1 left outer join rd_'+Convert(varchar,@Code_t)+' t2 ON '+@columns_k+' WHERE (t2.'+Replace(@key_oms,',',' is NULL OR t2.')+' is NULL '+') and '+Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID>0 '
print @SQL
EXECUTE sp_executesql @SQL

set @SQL = 'update '+@tab_name+' set upd='''' where err like ''%!%'''
print @SQL
EXECUTE sp_executesql @SQL

Set @Result='Проверка прошла успешно для таблицы - '+@tab_oms;
END TRY 
BEGIN CATCH 
Set @Result='Не создалась временная с обновлением для таблицы - '+@tab_oms;
END CATCH;
BEGIN TRY 
/*Запись данных об изменениях во временную таблицу*/
if not exists(select * from sysobjects where [name] = 'inf_tabl')
Begin
	CREATE TABLE inf_tabl(
	table_n varchar(50),
	hidden varchar(50) ,
	desc_table varchar(100),
	insert_n int
	,update_n int
	,close_n int
	,RealClose int
	)
end

declare @sql_delta nvarchar(max)
set @sql_delta=''
Select @SQL='INSERT INTO inf_tabl Select '''+@tab_oms+''' as table_n,'''+@tab_name+''' as hidden,'''+@desc_table+''' as desc_table,
(select count(*) from '+@tab_name+' where upd=''i'') as insert_n
,(select count(*) from '+@tab_name+' where upd=''u'') as update_n,(select count(*) from '+@tab_name+' where upd=''d'') as close_n'
if(@fieldClose is null or Len(@fieldClose)<=0) 
		set @sql_delta =', 0 as RealClose '
else 
		set @sql_delta =', (select count(*) from  '+@tab_name+' where upd=''d'') as RealClose '  
set @SQL = @Sql+@sql_delta
print @SQL
EXECUTE sp_executesql @SQL




Set @Result='Проверка прошла успешно для таблицы - '+@tab_oms;
END TRY 
BEGIN CATCH 
Select @SQL='INSERT INTO inf_tabl Select '''+@tab_oms+''' as table_n,'''+@tab_name+''' as hidden,'''+@desc_table+''' as desc_table,
(''0'') as insert_n
,(''0'') as update_n,(''0'') as close_n, 0 as RealClose'

print @SQL
EXECUTE sp_executesql @SQL



Set @Result='Не создалась временная с результатами обновления для таблицы - '+@tab_oms;
print @Result
END CATCH;


go

