CREATE VIEW [V_dmc_LpuLicence] AS SELECT 
[hDED].[LpuLicenceID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[M_Names] as [M_Names], 
[hDED].[M_Namef] as [M_Namef], 
[hDED].[C_Ogrn] as [C_Ogrn], 
[hDED].[MCod] as [MCod], 
[hDED].[Address] as [Address], 
[hDED].[Phone] as [Phone], 
[hDED].[FamGV] as [FamGV], 
[hDED].[ImGV] as [ImGV], 
[hDED].[OtGV] as [OtGV], 
[hDED].[LicenceNumber] as [LicenceNumber], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[DateEdit] as [DateEdit], 
[hDED].[UGUID] as [UGUID], 
[hDED].[UnloadDate] as [UnloadDate]
FROM [dmc_LpuLicence] as [hDED]
go

