CREATE VIEW [V_dmc_PersonalInfo] AS SELECT 
[hDED].[PersonalInfoID], [hDED].[x_Edition], [hDED].[x_Status], 
(SELECT Surname + ' ' + Name + ' ' + Patronimyc  ) as [V_Fio], 
(case when Sex = 0 then 'Женский' else 'Мужской' end) as [V_Sex], 
(CONVERT(CHAR(10),Birthday,104)) as [V_Birthday], 
((CONVERT(CHAR(10),DocDate,104))) as [V_DocDate], 
[hDED].[Surname] as [Surname], 
[hDED].[Name] as [Name], 
[hDED].[Patronimyc] as [Patronimyc], 
[hDED].[Sex] as [Sex], 
[hDED].[Birthday] as [Birthday], 
[hDED].[Address] as [Address], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Workplace] as [Workplace], 
[hDED].[Post] as [Post], 
[hDED].[S_DOC] as [S_DOC], 
[hDED].[N_DOC] as [N_DOC], 
[hDED].[DocDescription] as [DocDescription], 
[hDED].[DocDate] as [DocDate]
FROM [dmc_PersonalInfo] as [hDED]
go

