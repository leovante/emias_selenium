CREATE VIEW [dbo].[V_x_PermissionScheme] AS SELECT 
[hDED].[PermissionSchemeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RoleGUID] as [rf_RoleGUID], 
[hDED].[rf_ObjectTypeGUID] as [rf_ObjectTypeGUID], 
[hDED].[rf_ObjectGUID] as [rf_ObjectGUID], 
[hDED].[PermissionFlags] as [PermissionFlags], 
[hDED].[isActive] as [isActive]
FROM [x_PermissionScheme] as [hDED]
go

