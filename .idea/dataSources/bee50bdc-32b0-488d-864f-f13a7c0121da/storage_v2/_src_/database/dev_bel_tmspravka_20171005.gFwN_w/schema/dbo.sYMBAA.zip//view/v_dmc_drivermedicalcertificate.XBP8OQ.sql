CREATE VIEW [V_dmc_DriverMedicalCertificate] AS SELECT 
[hDED].[DriverMedicalCertificateID], [hDED].[x_Edition], [hDED].[x_Status], 
(((((Series+' '+Number))))) as [V_SN], 
(((case when Sex=0 then 'жен.'  else 'муж.'  end))) as [V_Sex], 
(((select op.Code+':' +(case
  when co.DmcCertificateOptionsID is not null  then 'V' 
  when co.DmcCertificateOptionsID is null and op.rf_DmcOptionTypeID = 1  then 'Z' 
  else ' ' 
  end)   
  + ' ;' as 'data()' 
  from [dmc_DMCOptions] op  LEFT join [dmc_DmcCertificateOptions] co
  on co.rf_DMCOptionsID = op.DMCOptionsID and rf_DriverMedicalCertificateID = [hDED].[DriverMedicalCertificateID]
  where op.DMCOptionsID >0
  for xml path('')))) as [V_Options], 
( select p.Surname+' '+p.Name + ' ' +p.Patronymic from dmc_Personal p where p.PersonalID = 
  (select top 1 c.rf_PersonalID from [dmc_Commission] c 
  where c.rf_DriverMedicalCertificateID = [hDED].[DriverMedicalCertificateID] and c.IsChairman = 1)) as [V_Doctor], 
(ContractDate+'-'+convert(varchar(10),ContractNum)) as [V_ContractString], 
[hDED].[rf_StatusID] as [rf_StatusID], 
[hDED].[rf_LpuLicenceID] as [rf_LpuLicenceID], 
[hDED].[rf_CitizenshipID] as [rf_CitizenshipID], 
[hDED].[Series] as [Series], 
[hDED].[Number] as [Number], 
[hDED].[Surname] as [Surname], 
[hDED].[Name] as [Name], 
[hDED].[Patronymic] as [Patronymic], 
[hDED].[Sex] as [Sex], 
[hDED].[DateOfBirth] as [DateOfBirth], 
[hDED].[Address] as [Address], 
[hDED].[CreationDate] as [CreationDate], 
[hDED].[ReleaseDate] as [ReleaseDate], 
[hDED].[ValidFor] as [ValidFor], 
[hDED].[ACategory] as [ACategory], 
[hDED].[BCategory] as [BCategory], 
[hDED].[CCategory] as [CCategory], 
[hDED].[DCategory] as [DCategory], 
[hDED].[ECategory] as [ECategory], 
[hDED].[TCategory] as [TCategory], 
[hDED].[SpecCategory] as [SpecCategory], 
[hDED].[SpecialTerm] as [SpecialTerm], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flags] as [Flags], 
[hDED].[S_DOC] as [S_DOC], 
[hDED].[N_DOC] as [N_DOC], 
[hDED].[DocDescription] as [DocDescription], 
[hDED].[IsReleased] as [IsReleased], 
[hDED].[IsProfi] as [IsProfi], 
[hDED].[DocDate] as [DocDate], 
[hDED].[Current] as [Current], 
[hDED].[Unloaded] as [Unloaded], 
[hDED].[History] as [History], 
[hDED].[PersonGUID] as [PersonGUID], 
[hDED].[Step] as [Step], 
[hDED].[Katls] as [Katls], 
[hDED].[IsPrinted] as [IsPrinted], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[Contraindication] as [Contraindication], 
[hDED].[ContractDate] as [ContractDate], 
[hDED].[ContractNum] as [ContractNum]
FROM [dmc_DriverMedicalCertificate] as [hDED]
go

