CREATE VIEW [V_dmc_MedicalCertificate] AS SELECT 
[hDED].[MedicalCertificateID], [hDED].[x_Edition], [hDED].[x_Status], 
(case when [Status]=0 then 'Создана'  else 
case when [Status]=1 then 'Выдана' else
case when [Status]=2 then 'Закрыта' else
case when [Status]=3 then 'Испорчена'
end
end
end
end) as [V_State], 
[hDED].[rf_PersonalInfoGUID] as [rf_PersonalInfoGUID], 
[hDED].[rf_MedicalCertificateTypeGUID] as [rf_MedicalCertificateTypeGUID], 
[hDED].[rf_MedicalCertificateReestrGUID] as [rf_MedicalCertificateReestrGUID], 
[hDED].[XmlData] as [XmlData], 
[hDED].[IsReleased] as [IsReleased], 
[hDED].[ReleaseDate] as [ReleaseDate], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Status] as [Status], 
[hDED].[Series] as [Series], 
[hDED].[Number] as [Number]
FROM [dmc_MedicalCertificate] as [hDED]
go

