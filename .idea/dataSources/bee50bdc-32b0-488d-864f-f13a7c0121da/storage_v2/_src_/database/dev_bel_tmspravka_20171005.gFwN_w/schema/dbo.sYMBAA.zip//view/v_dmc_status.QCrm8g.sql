CREATE VIEW [V_dmc_Status] AS SELECT 
[hDED].[StatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[StatusName] as [StatusName], 
[hDED].[StatusCode] as [StatusCode], 
[hDED].[UGUID] as [UGUID]
FROM [dmc_Status] as [hDED]
go

