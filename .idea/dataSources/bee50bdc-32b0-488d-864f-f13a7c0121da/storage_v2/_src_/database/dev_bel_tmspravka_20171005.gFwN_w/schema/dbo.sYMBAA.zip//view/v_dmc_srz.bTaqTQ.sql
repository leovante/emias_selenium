CREATE VIEW [V_dmc_Srz] AS SELECT 
[hDED].[SrzID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Surname] as [Surname], 
[hDED].[Name] as [Name], 
[hDED].[Patronymic] as [Patronymic], 
[hDED].[BirthDay] as [BirthDay], 
[hDED].[Sex] as [Sex], 
[hDED].[Address] as [Address], 
[hDED].[S_DOC] as [S_DOC], 
[hDED].[N_DOC] as [N_DOC], 
[hDED].[DocDate] as [DocDate], 
[hDED].[DocBy] as [DocBy]
FROM [dmc_Srz] as [hDED]
go

