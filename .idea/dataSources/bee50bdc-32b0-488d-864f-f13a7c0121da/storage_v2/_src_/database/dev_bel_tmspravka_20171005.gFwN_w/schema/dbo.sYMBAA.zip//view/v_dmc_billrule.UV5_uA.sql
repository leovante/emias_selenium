CREATE VIEW [V_dmc_BillRule] AS SELECT 
[hDED].[BillRuleID], [hDED].[x_Edition], [hDED].[x_Status], 
((case when Sex=0 then 'Для женщин' when Sex =1 then  'Для мужчин' else 'Для обоих полов' end)) as [V_Sex], 
[hDED].[rf_MedicalCertificateTypeID] as [rf_MedicalCertificateTypeID], 
[jT_dmc_MedicalCertificateType].[TypeName] as [SILENT_rf_MedicalCertificateTypeID], 
[hDED].[Sex] as [Sex], 
[hDED].[Cost] as [Cost], 
[hDED].[AgeFrom] as [AgeFrom], 
[hDED].[AgeTo] as [AgeTo], 
[hDED].[UGUID] as [UGUID], 
[hDED].[CostString] as [CostString], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [dmc_BillRule] as [hDED]
INNER JOIN [dmc_MedicalCertificateType] as [jT_dmc_MedicalCertificateType] on [jT_dmc_MedicalCertificateType].[MedicalCertificateTypeID] = [hDED].[rf_MedicalCertificateTypeID]
go

