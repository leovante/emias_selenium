CREATE VIEW [V_rls_ActMat_Iic] AS SELECT 
[hDED].[ActMat_IicID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsIicUID] as [rf_ClsIicUID], 
[hDED].[rf_ClsPharmaGroupUID] as [rf_ClsPharmaGroupUID], 
[hDED].[rf_ActMattersUID] as [rf_ActMattersUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_ActMat_Iic] as [hDED]
go

