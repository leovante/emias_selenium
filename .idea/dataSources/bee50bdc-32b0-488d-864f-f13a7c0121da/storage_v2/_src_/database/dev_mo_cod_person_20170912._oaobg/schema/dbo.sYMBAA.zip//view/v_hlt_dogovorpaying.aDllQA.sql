CREATE VIEW [V_hlt_DogovorPaying] AS SELECT 
[hDED].[DogovorPayingID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_DOGOVORID] as [rf_DOGOVORID], 
[jT_oms_DOGOVOR].[V_Info] as [SILENT_rf_DOGOVORID], 
[hDED].[rf_TYPEDOCID] as [rf_TYPEDOCID], 
[jT_oms_TYPEDOC].[C_DOC] as [SILENT_rf_TYPEDOCID], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[jT_oms_Organisation].[ShortName] as [SILENT_rf_OrganisationID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_DogovorPayingTypeID] as [rf_DogovorPayingTypeID], 
[jT_hlt_DogovorPayingType].[Code] as [SILENT_rf_DogovorPayingTypeID], 
[hDED].[Num] as [Num], 
[hDED].[Date] as [Date], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[isLegalEntity] as [isLegalEntity], 
[hDED].[FAMILY] as [FAMILY], 
[hDED].[NAME] as [NAME], 
[hDED].[OT] as [OT], 
[hDED].[S_DOC] as [S_DOC], 
[hDED].[N_DOC] as [N_DOC], 
[hDED].[DateDoc] as [DateDoc], 
[hDED].[DocIssuedBy] as [DocIssuedBy], 
[hDED].[AddressReg] as [AddressReg], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID], 
[hDED].[Balance] as [Balance], 
[hDED].[BalanceDate] as [BalanceDate], 
[hDED].[Description] as [Description]
FROM [hlt_DogovorPaying] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [V_oms_DOGOVOR] as [jT_oms_DOGOVOR] on [jT_oms_DOGOVOR].[DOGOVORID] = [hDED].[rf_DOGOVORID]
INNER JOIN [oms_TYPEDOC] as [jT_oms_TYPEDOC] on [jT_oms_TYPEDOC].[TYPEDOCID] = [hDED].[rf_TYPEDOCID]
INNER JOIN [oms_Organisation] as [jT_oms_Organisation] on [jT_oms_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_DogovorPayingType] as [jT_hlt_DogovorPayingType] on [jT_hlt_DogovorPayingType].[DogovorPayingTypeID] = [hDED].[rf_DogovorPayingTypeID]
go

