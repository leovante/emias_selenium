CREATE VIEW [V_hl7_Catalog] AS SELECT 
[hDED].[CatalogID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[UGUID] as [UGUID], 
[hDED].[OID] as [OID], 
[hDED].[NameNSI] as [NameNSI], 
[hDED].[GroupNSI] as [GroupNSI], 
[hDED].[Organization] as [Organization], 
[hDED].[VersionNSI] as [VersionNSI], 
[hDED].[DateLastChangeNSI] as [DateLastChangeNSI], 
[hDED].[CodeNSI] as [CodeNSI], 
[hDED].[DTDName] as [DTDName], 
[hDED].[rf_DocTypeDefGUID] as [rf_DocTypeDefGUID]
FROM [hl7_Catalog] as [hDED]
go

