CREATE VIEW [V_hlt_CallDoctorStatus] AS SELECT 
[hDED].[CallDoctorStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME]
FROM [hlt_CallDoctorStatus] as [hDED]
go

