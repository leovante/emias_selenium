CREATE VIEW [V_oms_Inshured] AS SELECT 
[hDED].[InshuredID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[jT_oms_Organisation].[ShortName] as [SILENT_rf_OrganisationID], 
[hDED].[InshuredNumber] as [InshuredNumber], 
[hDED].[JurAddress] as [JurAddress], 
[hDED].[RegDate] as [RegDate], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_Inshured] as [hDED]
INNER JOIN [oms_Organisation] as [jT_oms_Organisation] on [jT_oms_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID]
go

