CREATE VIEW [V_hlt_CallDoctor] AS SELECT 
[hDED].[CallDoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_DocInfoLPUDoctor], 
[jT_hlt_LPUDoctor1].[V_DocInfo] as [V_DocInfoFinalizeLPUDoctor], 
[jT_hlt_MKAB].[NAME] as [vName], 
[jT_hlt_MKAB].[FAMILY] as [vFamily], 
[jT_hlt_MKAB].[S_POL] as [S_POL], 
[jT_hlt_MKAB].[N_POL] as [N_POL], 
[jT_hlt_MKAB].[rf_UchastokID] as [V_UchastokCODE], 
[jT_hlt_MKAB].[OT] as [vOt], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_AddressID] as [rf_AddressID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[PCOD] as [SILENT_rf_LPUDoctorID], 
[hDED].[Rf_FinalizeLPUDoctorID] as [Rf_FinalizeLPUDoctorID], 
[hDED].[rf_CallDoctorStatusID] as [rf_CallDoctorStatusID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_FinalizeDocPRVDID] as [rf_FinalizeDocPRVDID], 
[hDED].[rf_TypeCallDoctorID] as [rf_TypeCallDoctorID], 
[hDED].[Address] as [Address], 
[hDED].[Complaint] as [Complaint], 
[hDED].[DateCall] as [DateCall], 
[hDED].[isFinalize] as [isFinalize], 
[hDED].[DateFinalize] as [DateFinalize], 
[hDED].[CodeDomophon] as [CodeDomophon], 
[hDED].[Phone] as [Phone], 
[hDED].[Description] as [Description], 
[hDED].[Entrance] as [Entrance], 
[hDED].[Floor] as [Floor], 
[hDED].[DateVisit] as [DateVisit], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID], 
[hDED].[SourceDvt] as [SourceDvt]
FROM [hlt_CallDoctor] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor1] on [jT_hlt_LPUDoctor1].[LPUDoctorID] = [hDED].[Rf_FinalizeLPUDoctorID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

