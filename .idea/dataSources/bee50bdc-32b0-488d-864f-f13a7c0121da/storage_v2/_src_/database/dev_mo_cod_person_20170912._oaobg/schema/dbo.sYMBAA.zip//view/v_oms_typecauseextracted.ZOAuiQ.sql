CREATE VIEW [V_oms_TypeCauseExtracted] AS SELECT 
[hDED].[TypeCauseExtractedID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Cod] as [Cod], 
[hDED].[Name] as [Name]
FROM [oms_TypeCauseExtracted] as [hDED]
go

