CREATE VIEW [V_hlt_WaitingList] AS SELECT 
[hDED].[WaitingListID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_DocPRVD].[V_FIO] as [V_DocFIO], 
[jT_hlt_MKAB].[OT] as [V_OT], 
[jT_hlt_MKAB].[NAME] as [V_NAME], 
[jT_hlt_MKAB].[FAMILY] as [V_FAMILY], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_PRVSID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_DoctorVisitTableID] as [rf_DoctorVisitTableID], 
[hDED].[rf_HealingRoomID] as [rf_HealingRoomID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_WaitingListStateID] as [rf_WaitingListStateID], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[DateFrom] as [DateFrom], 
[hDED].[DateTo] as [DateTo], 
[hDED].[TicketCreateTime] as [TicketCreateTime], 
[hDED].[TicketLiveTime] as [TicketLiveTime], 
[hDED].[TicketCount] as [TicketCount], 
[hDED].[TicketConfirmed] as [TicketConfirmed], 
[hDED].[FromReg] as [FromReg], 
[hDED].[FromDoc] as [FromDoc], 
[hDED].[FromInfomat] as [FromInfomat], 
[hDED].[FromInternet] as [FromInternet], 
[hDED].[FromTel] as [FromTel], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID], 
[hDED].[HourFrom] as [HourFrom], 
[hDED].[HourTo] as [HourTo], 
[hDED].[Phone] as [Phone], 
[hDED].[DateComplete] as [DateComplete], 
[hDED].[Description] as [Description], 
[hDED].[Complaints] as [Complaints], 
[hDED].[DateLastVisitSpeciality] as [DateLastVisitSpeciality]
FROM [hlt_WaitingList] as [hDED]
INNER JOIN [V_hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
go

