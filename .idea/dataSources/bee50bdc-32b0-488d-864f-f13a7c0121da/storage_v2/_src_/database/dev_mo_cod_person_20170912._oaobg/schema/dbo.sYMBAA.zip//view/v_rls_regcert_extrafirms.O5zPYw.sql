CREATE VIEW [V_rls_RegCert_ExtraFirms] AS SELECT 
[hDED].[RegCert_ExtraFirmsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FirmsUID] as [rf_FirmsUID], 
[hDED].[rf_RegCertUID] as [rf_RegCertUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Number] as [Number], 
[hDED].[Code] as [Code]
FROM [rls_RegCert_ExtraFirms] as [hDED]
go

