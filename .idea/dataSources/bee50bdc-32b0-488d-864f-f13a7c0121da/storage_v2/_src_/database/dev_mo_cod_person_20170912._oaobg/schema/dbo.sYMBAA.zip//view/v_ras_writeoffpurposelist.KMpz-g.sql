CREATE VIEW [V_ras_WriteOffPurposeList] AS SELECT 
[hDED].[WriteOffPurposeListID], [hDED].[HostWriteOffPurposeListID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_ras_Organisation].[Name] as [V_Organisation], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_OrganisationIDHost] as [rf_OrganisationIDHost], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[hDED].[rf_DocDescriptionID] as [rf_DocDescriptionID], 
[hDED].[rf_StatePurposeListID] as [rf_StatePurposeListID], 
[hDED].[Num] as [Num], 
[hDED].[Date] as [Date], 
[hDED].[GUIDDoc] as [GUIDDoc], 
[hDED].[GUIDList] as [GUIDList], 
[hDED].[Note] as [Note], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[GUIDHistory] as [GUIDHistory]
FROM [ras_WriteOffPurposeList] as [hDED]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationIDHost]
go

