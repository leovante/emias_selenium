CREATE VIEW [V_stt_WorkStatus] AS SELECT 
[hDED].[WorkStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [stt_WorkStatus] as [hDED]
go

