CREATE VIEW [V_stt_PatTransport] AS SELECT 
[hDED].[PatTransportID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [stt_PatTransport] as [hDED]
go

