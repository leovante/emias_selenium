-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[RPGUMO2_HealthJournal_USL]
(	
	@p_ser varchar(20),
	@p_nom varchar(20),
	@dr datetime,
	@dateA datetime,
	@dateB datetime
)
RETURNS TABLE 
AS
RETURN 
(

select top 1000 
smtap.rf_TAPID
,smtap.SMTAPID
,isnull(lpu.MCOD, '') as MCOD
,isnull(department.DepartmentCode, '') as Podr
,isnull(department.DepartmentName, '') as PodrName
,isnull(departmentProfile.Code, '') as Profil
,isnull(departmentProfile.Name, '') as ProfilName
,smtap.Date_P as Date_IN
,smtap.Date_P as Date_OUT

,isnull(mkb.DS, '') as DS1
,isnull(mkb.NAME, '') as DS1name

,isnull(ServiceMedical.ServiceMedicalCode, '') as CodeUsl
,isnull(ServiceMedical.ServiceMedicalName, '') as NameUsl
,smtap.[Count] as KolUsl

,isnull(prvs.C_PRVS, '') as Prvs
,isnull(prvs.PRVS_NAME, '') as PrvsName
,isnull(lpudoctor.PCOD, '') as PCOD
,isnull(lpudoctor.Fam_V + ' ' + lpudoctor.IM_V + ' ' + lpudoctor.OT_V, '') as FIODoct

from hlt_mkab mkab
inner join hlt_tap tap on tap.rf_MKABID = mkab.mkabid
inner join hlt_smtap smtap on tap.tapid = smtap.rf_tapid

left join oms_Department department on department.DepartmentID = tap.rf_DepartmentID
left join hlt_LPUDoctor lpudoctor on smtap.rf_LPUDoctorID = lpudoctor.lpudoctorid
left join oms_PRVS prvs on prvs.PRVSID = lpudoctor.rf_PRVSID and prvs.PRVSID > 0
--left join hlt_DocPRVD docprvd on tap.rf_DocPRVDID = docprvd.DocPRVDID --!!!!! НЕТ
left join oms_LPU lpu on department.rf_LPUID = lpu.LPUID--!!!!!!!!!!!! ЛПУ ПО ВРАЧУ, Т.К. НЕТ ОТДЕЛЕНИЙ
left join oms_kl_DepartmentType departmentType on departmentType.kl_DepartmentTypeID = department.rf_kl_DepartmentTypeID and departmentType.kl_DepartmentTypeID > 0
left join oms_kl_DepartmentProfile departmentProfile on departmentProfile.kl_DepartmentProfileID = department.rf_kl_DepartmentProfileID and departmentProfile.kl_DepartmentProfileID > 0

left join oms_MKB mkb on smtap.rf_MKBID = mkb.MKBID
left join oms_ServiceMedical ServiceMedical on smtap.rf_omsServiceMedicalID = ServiceMedical.ServiceMedicalID

where mkab.mkabid > 0
and tap.tapid > 0
and lpu.lpuid > 0
and mkab.S_POL = @p_ser and mkab.N_POL = @p_nom and mkab.Date_BD = @dr
and tap.DateTap between @dateA and @dateB
)
go

