CREATE VIEW [V_hlt_Marking] AS SELECT 
[hDED].[MarkingID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_BlankTemplateID] as [rf_BlankTemplateID], 
[jT_hlt_BlankTemplate].[Caption] as [SILENT_rf_BlankTemplateID], 
[hDED].[rf_MarkingTypeID] as [rf_MarkingTypeID], 
[jT_hlt_MarkingType].[Name] as [SILENT_rf_MarkingTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags]
FROM [hlt_Marking] as [hDED]
INNER JOIN [hlt_BlankTemplate] as [jT_hlt_BlankTemplate] on [jT_hlt_BlankTemplate].[BlankTemplateID] = [hDED].[rf_BlankTemplateID]
INNER JOIN [hlt_MarkingType] as [jT_hlt_MarkingType] on [jT_hlt_MarkingType].[MarkingTypeID] = [hDED].[rf_MarkingTypeID]
go

