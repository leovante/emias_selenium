
create PROCEDURE [dbo].[sp_mkp_IshodInfoBorns]
AS
BEGIN
	-- 1. Создание новой временной таблицы для актуальной выборки 	
	if exists(select * from sys.objects where name = 'mkp_tmp_IshodInfoBorns') drop table mkp_tmp_IshodInfoBorns

	CREATE TABLE [dbo].[mkp_tmp_IshodInfoBorns](
		[MCOD] [varchar](1000) NOT NULL,
		[ogrn] [varchar](1000) NOT NULL,
		[nameLpu] [varchar](1000) NOT NULL,
		[r0] [int] NOT NULL,
		[r1] [int] NOT NULL,
		[r2] [int] NOT NULL,
		[r3] [int] NOT NULL,
		[r4] [int] NOT NULL,
		[r5] [int] NOT NULL,
		[r6] [int] NOT NULL,
		[r7] [int] NOT NULL,
		[r8] [int] NOT NULL,
		[r9] [int] NOT NULL,
		[r10] [int] NOT NULL,
		[r11] [int] NOT NULL,
		[r12] [int] NOT NULL,
		[r13] [int] NOT NULL
	) ON [PRIMARY]
	
	--2. Наполнение временной таблицы с данными по каждой ЛПУ, которая есть в выборке, курсором...
	declare @rank int,
		@lpuid int,
		@string char (7)

	declare rank_cursor cursor
	for select distinct lpuid
		from mkp_tmp
		--order by id_test
	open rank_cursor
	fetch next from rank_cursor into @lpuid
	set @rank = 1
	while (@@fetch_status <> -1)
	begin
		--select @rank, @lpuid

		--select 1 from mkp_tmp where LPUID = @lpuid
		insert into [mkp_tmp_IshodInfoBorns](MCOD, ogrn, nameLpu, r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13)
		Select-- all_, 
		MCOD, ogrn, nameLpu, 
		r0, r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13
		from
					(
						select 
							(select top 1 oms_lpu.MCOD from oms_lpu where lpuid = @lpuid) as MCOD, 
							(select top 1 oms_lpu.C_OGRN from oms_lpu where lpuid = @lpuid) as ogrn, 
							(select top 1 oms_lpu.M_NAMEF from oms_lpu where lpuid = @lpuid) as nameLpu, 
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid) as r0,		
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000') as r1,	
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D') as r2,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = 'AA94BF8F-7778-48B7-9BE2-931857142DD3') as r3,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '34459EB6-2BC9-4BEA-A394-7F2A61C6181A') as r4,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A') as r5,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '222925E8-06B2-4FAB-BFC2-B81A6DFFF14B') as r6,
						
							(select count(*) from hlt_mkp_Born born 
									inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
										 and born.Stillbirth = 1) as [r7],						
							(select count(*) from hlt_mkp_Born born 
									inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
										and born.Alive = 1									
									inner join hlt_mkp_DeathMother death on born.rf_mkp_DeathMotherGUID = death.UGUID 
										and (year(death.DateTimeDeath) != 1900)
										and (DATEDIFF(day, born.DateBirthChild, death.DateTimeDeath) <= 7)
									) as [r8],
							(select count(*) from hlt_mkp_Born born 
									inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
										and born.Alive = 1 and (tmp.V_CountWeeksOnRody > 37)								
									) as [r9],
							(select count(*) from 
							(
								select count(*) as cnt, rf_mkp_CardGUID from hlt_mkp_born born
												inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
								group by rf_mkp_CardGUID having count(*) = 1
							)ttt) as [r10],

							(select count(*) from 
							(
								select count(*) as cnt, rf_mkp_CardGUID from hlt_mkp_born born
												inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
								group by rf_mkp_CardGUID having count(*) = 2
							)ttt) as [r11],

							(select count(*) from 
							(
								select count(*) as cnt, rf_mkp_CardGUID from hlt_mkp_born born
												inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
								group by rf_mkp_CardGUID having count(*) = 3
							)ttt) as [r12],

							(select count(*) from 
							(
								select count(*) as cnt, rf_mkp_CardGUID from hlt_mkp_born born
												inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
								group by rf_mkp_CardGUID having count(*) > 3
							)ttt) as [r13]						
								/*не определено	00000000-0000-0000-0000-000000000000
								Роды в срок	6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D
								Преждевременные роды	AA94BF8F-7778-48B7-9BE2-931857142DD3
								Медицинский аборт до 12 недель	34459EB6-2BC9-4BEA-A394-7F2A61C6181A
								Смерть матери во время/после родов	E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A
								Смерть матери во время/после аборта	222925E8-06B2-4FAB-BFC2-B81A6DFFF14B*/
					)ttt

		set @rank = @rank + 1
		fetch next from rank_cursor into @lpuid
	end
	close rank_cursor
	deallocate rank_cursor

	--3. Добавление XML записи в сводную таблицу mkp_RS_Summary 
	/*
	Using the FOR XML Clause to Return Query Results as XML
	--https://www.simple-talk.com/sql/learn-sql-server/using-the-for-xml-clause-to-return-query-results-as-xml/
	*/
	declare @xml xml
	set @xml = (select * from [mkp_tmp_IshodInfoBorns] FOR XML RAW ('MKPInfo'), ROOT, ELEMENTS XSINIL, XMLSCHEMA)
	--print cast(@xml as varchar(8000))
	insert into mkp_RS_Summary([Data], [Date], [Code], [Description])
	select @xml, GetDate(), 'mkp_tmp_IshodInfoBorns', ''

END

 --execute sp_mkp_IshodInfoBorns
  --select * from [mkp_tmp_IshodInfoBorns]


go

