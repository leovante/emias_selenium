CREATE VIEW [V_rls_Tn_Df_Limp] AS SELECT 
[hDED].[Tn_Df_LimpID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsAtcUID] as [rf_ClsAtcUID], 
[hDED].[rf_ClsDrugFormsUID] as [rf_ClsDrugFormsUID], 
[hDED].[rf_TradeNamesUID] as [rf_TradeNamesUID], 
[hDED].[rf_Cls_PhGr_LimpUID] as [rf_Cls_PhGr_LimpUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Tn_Df_Limp] as [hDED]
go

