CREATE VIEW [V_stt_Rh] AS SELECT 
[hDED].[RhID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [stt_Rh] as [hDED]
go

