CREATE VIEW [V_stt_ActionMove] AS SELECT 
[hDED].[ActionMoveID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_BedStatusID] as [rf_BedStatusID], 
[hDED].[rf_ActionTypeID] as [rf_ActionTypeID], 
[hDED].[rf_NextActionTypeID] as [rf_NextActionTypeID], 
[hDED].[Note] as [Note], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [stt_ActionMove] as [hDED]
go

