
create PROCEDURE [dbo].[sp_mkp_AgeWomen]
AS
BEGIN
	-- 1. Созадние новой временной таблицы для актуальной выборки 
	if exists(select * from sys.objects where name = 'mkp_tmp_AgeWomen') drop table mkp_tmp_AgeWomen

	CREATE TABLE [dbo].[mkp_tmp_AgeWomen](
		[MCOD] [varchar](1000) NOT NULL,
		[ogrn] [varchar](1000) NOT NULL,
		[nameLpu] [varchar](1000) NOT NULL,
		allCards [int] NOT NULL, 
		allCardsNablyudenie [int] NOT NULL,
		allCardsMenshe16 [int] NOT NULL, 
		allCards16_17 [int] NOT NULL, 
		allCards18_21 [int] NOT NULL,
		allCards22_25 [int] NOT NULL,
		allCards26_28 [int] NOT NULL, 
		allCards29_32 [int] NOT NULL, 
		allCards33_35 [int] NOT NULL, 
		allCards36_40 [int] NOT NULL,
		allCards41_50 [int] NOT NULL,
		allCards51_60 [int] NOT NULL,
		allCardsBolshe60 [int] NOT NULL, 
		allCardsWithIshod [int] NOT NULL

	) ON [PRIMARY]

	--2. Наполнение временной таблицы с данными по каждой ЛПУ, которая есть в выборке, курсором...
	declare @rank int,
	@lpuid int,
	@string char (7)

	declare rank_cursor cursor
	for select distinct lpuid
		from mkp_tmp
		--order by id_test
	open rank_cursor
	fetch next from rank_cursor into @lpuid
	set @rank = 1
	while (@@fetch_status <> -1)
	begin
		--select @rank, @lpuid

		--select 1 from tmp_Mkps where LPUID = @lpuid
		insert into mkp_tmp_AgeWomen(MCOD, ogrn, nameLpu, allCards, allCardsNablyudenie, allCardsMenshe16, allCards16_17, allCards18_21, allCards22_25,
		allCards26_28, allCards29_32, allCards33_35, allCards36_40, allCards41_50, allCards51_60, allCardsBolshe60, allCardsWithIshod)
		Select
		MCOD, ogrn, nameLpu, 
		allCards, allCardsNablyudenie, allCardsMenshe16, allCards16_17, allCards18_21, allCards22_25,
		allCards26_28, allCards29_32, allCards33_35, allCards36_40, allCards41_50, allCards51_60,
		allCardsBolshe60, allCardsWithIshod
		from
					(
						select 
							(select top 1 oms_lpu.MCOD from oms_lpu where lpuid = @lpuid) as MCOD, 
							(select top 1 oms_lpu.C_OGRN from oms_lpu where lpuid = @lpuid) as ogrn, 
							(select top 1 oms_lpu.M_NAMEF from oms_lpu where lpuid = @lpuid) as nameLpu, 
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid) as allCards,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000') as allCardsNablyudenie,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000' and Age < 16) as allCardsMenshe16,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000' and (Age >= 16 and Age <= 17)) as allCards16_17,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000' and (Age >= 18 and Age <= 21)) as allCards18_21,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000' and (Age >= 22 and Age <= 25)) as allCards22_25,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000' and (Age >= 26 and Age <= 28)) as allCards26_28,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000' and (Age >= 29 and Age <= 32)) as allCards29_32,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000' and (Age >= 33 and Age <= 35)) as allCards33_35,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000' and (Age >= 36 and Age <= 40)) as allCards36_40,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000' and (Age >= 41 and Age <= 50)) as allCards41_50,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000' and (Age >= 51 and Age <= 60)) as allCards51_60,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID = '00000000-0000-0000-0000-000000000000' and (Age > 60)) as allCardsBolshe60,
							(select count(mkpUGUID) from mkp_tmp where LPUID = @lpuid and PergGUID != '00000000-0000-0000-0000-000000000000') as allCardsWithIshod
					)ttt

		set @rank = @rank + 1
		fetch next from rank_cursor into @lpuid
	end
	close rank_cursor
	deallocate rank_cursor


	--select * from mkp_tmp_Ishod 

	--3. Добавление XML записи в сводную таблицу mkp_RS_Summary 
	/*
	Using the FOR XML Clause to Return Query Results as XML
	--https://www.simple-talk.com/sql/learn-sql-server/using-the-for-xml-clause-to-return-query-results-as-xml/
	*/
	declare @xml xml
	set @xml = (select * from mkp_tmp_AgeWomen FOR XML RAW ('MKPInfo'), ROOT, ELEMENTS XSINIL, XMLSCHEMA)
	--print cast(@xml as varchar(8000))
	insert into mkp_RS_Summary([Data], [Date], [Code], [Description])
	select @xml, GetDate(), 'mkp_tmp_AgeWomen', ''


END

 --execute sp_mkp_AgeWomen
  --select * from mkp_tmp_AgeWomen
 --select M_NAMEF, C_OGRN, m.* from oms_LPU l left join mkp_tmp_AgeWomen m on l.MCOD = m.MCOD


go

