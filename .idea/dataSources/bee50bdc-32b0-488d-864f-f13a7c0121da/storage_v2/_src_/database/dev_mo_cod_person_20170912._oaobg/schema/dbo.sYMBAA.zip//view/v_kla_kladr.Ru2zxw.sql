CREATE VIEW [V_kla_KlAdr] AS SELECT 
[hDED].[KlAdrID], [hDED].[x_Edition], [hDED].[x_Status], 
(hDed.[Name] + ' ' + hDed.[SOCR] ) as [V_FullName], 
[hDED].[rf_ParentID] as [rf_ParentID], 
[hDED].[Name] as [Name], 
[hDED].[SOCR] as [SOCR], 
[hDED].[CODE] as [CODE], 
[hDED].[GNINMB] as [GNINMB], 
[hDED].[UNO] as [UNO], 
[hDED].[OCATD] as [OCATD], 
[hDED].[STATUS] as [STATUS], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[Source] as [Source], 
[hDED].[LEVEL] as [LEVEL], 
[hDED].[AltCode] as [AltCode], 
[hDED].[PostIndex] as [PostIndex]
FROM [kla_KlAdr] as [hDED]
go

