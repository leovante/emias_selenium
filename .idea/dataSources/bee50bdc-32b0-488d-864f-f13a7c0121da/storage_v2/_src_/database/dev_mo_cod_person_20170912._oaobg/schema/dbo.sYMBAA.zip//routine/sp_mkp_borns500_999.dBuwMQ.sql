
create PROCEDURE [dbo].[sp_mkp_Borns500_999]
AS
BEGIN
	-- 1. Создание новой временной таблицы для актуальной выборки 	
	if exists(select * from sys.objects where name = 'mkp_tmp_Borns500_999') drop table mkp_tmp_Borns500_999
	CREATE TABLE [dbo].mkp_tmp_Borns500_999(
		[MCOD] [varchar](1000) NOT NULL,
		[ogrn] [varchar](1000) NOT NULL,
		[nameLpu] [varchar](1000) NOT NULL,
		[borns_alive_ill] [int] NOT NULL, 
		[borns_alive_ill_nedonoshen] [int] NOT NULL, 
		[borns_alive_death] [int] NOT NULL, 
		[borns_alive_death_nedonoshen] [int] NOT NULL, 
		[borns_alive_death_06days] [int] NOT NULL, 
		[borns_deathborn] [int] NOT NULL
	) ON [PRIMARY]
	
	--2. Наполнение временной таблицы с данными по каждой ЛПУ, которая есть в выборке, курсором...
	declare @rank int,
		@lpuid int,
		@string char (7)

	declare rank_cursor cursor
	for select distinct lpuid
		from mkp_tmp
		--order by id_test
	open rank_cursor
	fetch next from rank_cursor into @lpuid
	set @rank = 1
	while (@@fetch_status <> -1)
	begin
		insert into mkp_tmp_Borns500_999(MCOD, ogrn, nameLpu, [borns_alive_ill], [borns_alive_ill_nedonoshen], [borns_alive_death], [borns_alive_death_nedonoshen], [borns_alive_death_06days], [borns_deathborn])
		Select MCOD, ogrn, nameLpu, [borns_alive_ill], [borns_alive_ill_nedonoshen], [borns_alive_death], [borns_alive_death_nedonoshen], [borns_alive_death_06days], [borns_deathborn]
		from
					(
						select 
							(select top 1 oms_lpu.MCOD from oms_lpu where lpuid = @lpuid) as MCOD, 
							(select top 1 oms_lpu.C_OGRN from oms_lpu where lpuid = @lpuid) as ogrn, 
							(select top 1 oms_lpu.M_NAMEF from oms_lpu where lpuid = @lpuid) as nameLpu,
							(select count(*) from hlt_mkp_Born born 
									inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
									and born.Alive = 1 and (born.[Weight] >= 500 and born.[Weight] <= 999)
									and born.UGUID in (select d.rf_mkp_BornGUID from hlt_mkp_DiagnosPreg d where d.rf_mkp_DiagnosPregTypeGUID = 'D6839473-7F5D-4013-91E2-A0ED720623C4')
									) as [borns_alive_ill],	
							(select count(*) from hlt_mkp_Born born 
									inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
									and born.Alive = 1 and born.Pronatis = 1 and (born.[Weight] >= 500 and born.[Weight] <= 999)
									and born.UGUID in (select d.rf_mkp_BornGUID from hlt_mkp_DiagnosPreg d where d.rf_mkp_DiagnosPregTypeGUID = 'D6839473-7F5D-4013-91E2-A0ED720623C4')
									) as [borns_alive_ill_nedonoshen],	
							----------------------
								--из них умерло всего
							(select count(*) from hlt_mkp_Born born 
									inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
										and born.Alive = 1 and (born.[Weight] >= 500 and born.[Weight] <= 999)
										and born.UGUID in (select d.rf_mkp_BornGUID from hlt_mkp_DiagnosPreg d where d.rf_mkp_DiagnosPregTypeGUID = 'D6839473-7F5D-4013-91E2-A0ED720623C4')
									inner join hlt_mkp_DeathMother death on born.rf_mkp_DeathMotherGUID = death.UGUID 
										and (year(death.DateTimeDeath) != 1900)
									) as [borns_alive_death],	
								--в том числе недоношенные
							(select count(*) from hlt_mkp_Born born 
									inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
										and born.Alive = 1 and born.Pronatis = 1 and (born.[Weight] >= 500 and born.[Weight] <= 999)
										and born.UGUID in (select d.rf_mkp_BornGUID from hlt_mkp_DiagnosPreg d where d.rf_mkp_DiagnosPregTypeGUID = 'D6839473-7F5D-4013-91E2-A0ED720623C4')
									inner join hlt_mkp_DeathMother death on born.rf_mkp_DeathMotherGUID = death.UGUID 
										and (year(death.DateTimeDeath) != 1900)
									) as [borns_alive_death_nedonoshen],	
								--в возрасте 0-6 дней
							(select count(*) from hlt_mkp_Born born 
									inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
										and born.Alive = 1 and born.Pronatis = 1 and (born.[Weight] >= 500 and born.[Weight] <= 999)
										and born.UGUID in (select d.rf_mkp_BornGUID from hlt_mkp_DiagnosPreg d where d.rf_mkp_DiagnosPregTypeGUID = 'D6839473-7F5D-4013-91E2-A0ED720623C4')
									inner join hlt_mkp_DeathMother death on born.rf_mkp_DeathMotherGUID = death.UGUID 
										and (year(death.DateTimeDeath) != 1900)
										and (DATEDIFF(day, born.DateBirthChild, death.DateTimeDeath) <= 6)
									) as [borns_alive_death_06days],
								--Родилось мертвыми
							(select count(*) from hlt_mkp_Born born 
									inner join mkp_tmp tmp on born.rf_mkp_CardGUID = tmp.mkpUGUID and tmp.LPUID = @lpuid and pergGuid in ('6F6BFD3F-E9DD-47C5-8FBF-152EEFA8775D', 'AA94BF8F-7778-48B7-9BE2-931857142DD3', 'E34F5E18-38DB-494C-B1A1-FBFFB52B0B2A')
										 and (born.[Weight] >= 500 and born.[Weight] <= 999) and born.Stillbirth = 1) as [borns_deathborn]
					)ttt
		set @rank = @rank + 1
		fetch next from rank_cursor into @lpuid
	end
	close rank_cursor
	deallocate rank_cursor
	
	--3. Добавление XML записи в сводную таблицу mkp_RS_Summary 
	/*
	Using the FOR XML Clause to Return Query Results as XML
	--https://www.simple-talk.com/sql/learn-sql-server/using-the-for-xml-clause-to-return-query-results-as-xml/
	*/
	declare @xml xml
	set @xml = (select * from [mkp_tmp_Borns500_999] FOR XML RAW ('MKPInfo'), ROOT, ELEMENTS XSINIL, XMLSCHEMA)
	--print cast(@xml as varchar(8000))
	insert into mkp_RS_Summary([Data], [Date], [Code], [Description])
	select @xml, GetDate(), 'mkp_tmp_Borns500_999', ''

END

 --execute sp_mkp_Borns500_999
  --select * from [mkp_tmp_Borns500_999]


go

