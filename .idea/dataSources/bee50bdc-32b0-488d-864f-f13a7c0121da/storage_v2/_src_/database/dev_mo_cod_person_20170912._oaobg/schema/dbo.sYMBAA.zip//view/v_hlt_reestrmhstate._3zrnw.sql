CREATE VIEW [V_hlt_ReestrMHState] AS SELECT 
[hDED].[ReestrMHStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrStateID] as [rf_SMReestrStateID], 
[jT_oms_SMReestrState].[Name] as [SILENT_rf_SMReestrStateID], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[jT_hlt_ReestrMH].[DateBegin] as [SILENT_rf_ReestrMHID], 
[hDED].[SetDate] as [SetDate], 
[hDED].[Description] as [Description], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_ReestrMHState] as [hDED]
INNER JOIN [oms_SMReestrState] as [jT_oms_SMReestrState] on [jT_oms_SMReestrState].[SMReestrStateID] = [hDED].[rf_SMReestrStateID]
INNER JOIN [hlt_ReestrMH] as [jT_hlt_ReestrMH] on [jT_hlt_ReestrMH].[ReestrMHID] = [hDED].[rf_ReestrMHID]
go

