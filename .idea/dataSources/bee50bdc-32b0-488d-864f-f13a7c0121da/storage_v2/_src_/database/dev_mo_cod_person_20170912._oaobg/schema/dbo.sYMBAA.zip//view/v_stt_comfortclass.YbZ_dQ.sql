CREATE VIEW [V_stt_ComfortClass] AS SELECT 
[hDED].[ComfortClassID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [stt_ComfortClass] as [hDED]
go

