CREATE VIEW [V_oms_KRRVid] AS SELECT 
[hDED].[KRRVidID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ExpertAlgorithmID] as [rf_ExpertAlgorithmID], 
[jT_oms_ExpertAlgorithm].[Caption] as [SILENT_rf_ExpertAlgorithmID], 
[hDED].[VidK_Code] as [VidK_Code], 
[hDED].[VidK_N_ame] as [VidK_N_ame], 
[hDED].[Rem] as [Rem], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Doc] as [Doc]
FROM [oms_KRRVid] as [hDED]
INNER JOIN [oms_ExpertAlgorithm] as [jT_oms_ExpertAlgorithm] on [jT_oms_ExpertAlgorithm].[ExpertAlgorithmID] = [hDED].[rf_ExpertAlgorithmID]
go

