CREATE VIEW [V_hlt_MKB_RegMedicalCheck] AS SELECT 
[hDED].[MKB_RegMedicalCheckID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_DocInfo], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[PCOD] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_RegMedicalCheckID] as [rf_RegMedicalCheckID], 
[jT_hlt_RegMedicalCheck].[rf_MKABID] as [SILENT_rf_RegMedicalCheckID], 
[hDED].[DateDS] as [DateDS], 
[hDED].[isRepeatedDS] as [isRepeatedDS], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_MKB_RegMedicalCheck] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [hlt_RegMedicalCheck] as [jT_hlt_RegMedicalCheck] on [jT_hlt_RegMedicalCheck].[RegMedicalCheckID] = [hDED].[rf_RegMedicalCheckID]
go

