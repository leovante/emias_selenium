CREATE VIEW [V_stt_MigrationReason] AS SELECT 
[hDED].[MigrationReasonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [stt_MigrationReason] as [hDED]
go

