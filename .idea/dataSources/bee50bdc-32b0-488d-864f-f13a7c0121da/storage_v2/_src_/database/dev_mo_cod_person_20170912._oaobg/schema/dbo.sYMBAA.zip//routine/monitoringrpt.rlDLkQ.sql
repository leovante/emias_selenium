CREATE PROCEDURE [dbo].MonitoringRpt   
AS
BEGIN
   SELECT * FROM tmp_ReportView1
END;
go

