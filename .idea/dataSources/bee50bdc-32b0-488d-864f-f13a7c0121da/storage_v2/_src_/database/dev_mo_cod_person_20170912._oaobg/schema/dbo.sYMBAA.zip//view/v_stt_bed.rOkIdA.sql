CREATE VIEW [V_stt_Bed] AS SELECT 
[hDED].[BedID], [hDED].[x_Edition], [hDED].[x_Status], 
((isNull((select V_BranchInfo from V_stt_stationarBranch sb
inner join stt_ward w on w.rf_StationarBranchID = sb.StationarBranchID
where hDED.rf_WardID = w.WardID),''))) as [V_SeparationName], 
(isnull((select stt_ActionType.Name from v_CurrentBadAction
inner join stt_ActionType on ActionTypeID=rf_ActionTypeID 
and rf_BedID=BedID),'не установлено')
) as [v_BedAction], 
[hDED].[rf_BedTypeID] as [rf_BedTypeID], 
[jT_stt_BedType].[Name] as [SILENT_rf_BedTypeID], 
[hDED].[rf_BedAssigmentID] as [rf_BedAssigmentID], 
[jT_stt_BedAssigment].[Name] as [SILENT_rf_BedAssigmentID], 
[hDED].[rf_BedStatusID] as [rf_BedStatusID], 
[jT_stt_BedStatus].[Name] as [SILENT_rf_BedStatusID], 
[hDED].[rf_WardID] as [rf_WardID], 
[jT_stt_Ward].[Num] as [SILENT_rf_WardID], 
[hDED].[rf_BedProfileID] as [rf_BedProfileID], 
[jT_stt_BedProfile].[Name] as [SILENT_rf_BedProfileID], 
[hDED].[Num] as [Num], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateWorkB] as [DateWorkB], 
[hDED].[DateWorkE] as [DateWorkE]
FROM [stt_Bed] as [hDED]
INNER JOIN [stt_BedType] as [jT_stt_BedType] on [jT_stt_BedType].[BedTypeID] = [hDED].[rf_BedTypeID]
INNER JOIN [stt_BedAssigment] as [jT_stt_BedAssigment] on [jT_stt_BedAssigment].[BedAssigmentID] = [hDED].[rf_BedAssigmentID]
INNER JOIN [stt_BedStatus] as [jT_stt_BedStatus] on [jT_stt_BedStatus].[BedStatusID] = [hDED].[rf_BedStatusID]
INNER JOIN [stt_Ward] as [jT_stt_Ward] on [jT_stt_Ward].[WardID] = [hDED].[rf_WardID]
INNER JOIN [stt_BedProfile] as [jT_stt_BedProfile] on [jT_stt_BedProfile].[BedProfileID] = [hDED].[rf_BedProfileID]
go

