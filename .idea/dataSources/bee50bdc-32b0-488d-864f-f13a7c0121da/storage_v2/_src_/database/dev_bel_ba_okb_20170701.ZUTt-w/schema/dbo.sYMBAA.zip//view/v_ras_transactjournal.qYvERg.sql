CREATE VIEW [V_ras_TransactJournal] AS SELECT 
[hDED].[TransactJournalID], [hDED].[HostTransactJournalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PeriodID] as [rf_PeriodID], 
[hDED].[rf_PeriodIDHost] as [rf_PeriodIDHost], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_DocDescriptionID] as [rf_DocDescriptionID], 
[jT_ras_DocDescription].[NameType] as [SILENT_rf_DocDescriptionID], 
[hDED].[TransactDateTimeSystem] as [TransactDateTimeSystem], 
[hDED].[TransactDateTimeOperation] as [TransactDateTimeOperation], 
[hDED].[Count] as [Count], 
[hDED].[PositionID] as [PositionID], 
[hDED].[bInput] as [bInput], 
[hDED].[bOutput] as [bOutput], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[PositionIDHost] as [PositionIDHost]
FROM [ras_TransactJournal] as [hDED]
INNER JOIN [ras_DocDescription] as [jT_ras_DocDescription] on [jT_ras_DocDescription].[DocDescriptionID] = [hDED].[rf_DocDescriptionID]
go

