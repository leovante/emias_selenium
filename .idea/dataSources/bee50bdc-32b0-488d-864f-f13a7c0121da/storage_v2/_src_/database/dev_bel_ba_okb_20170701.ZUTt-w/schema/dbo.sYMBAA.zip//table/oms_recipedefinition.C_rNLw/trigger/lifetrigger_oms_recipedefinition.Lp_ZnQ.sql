CREATE TRIGGER [LifeTrigger_oms_RecipeDefinition] ON [oms_RecipeDefinition] FOR DELETE,INSERT,UPDATE
AS 

SET NOCOUNT ON;

DECLARE @userId INT
DECLARE @seanceId INT 

DECLARE @docTypeId INT 
DECLARE @CURDATE DATETIME


declare @app varchar(50)
declare @index1 int
declare @index2 int


/* @userId, @seanceId */

SET @userId = 0
SET @seanceId = 0

EXEC [GetMalibuContext] @seanceId = @seanceId OUTPUT, @userId = @userId OUTPUT

/* @docTypeId */

SET @CURDATE = getdate()

SET @docTypeId = 0

SELECT TOP 1 @docTypeId = [DocTypeDefID], @seanceId=case WHEN [x_STDO].[HostID] IS NULL THEN @seanceId ELSE 0 END
FROM [x_DocTypeDef] left join [x_STDO] on [x_DocTypeDef].[GUID] = [x_STDO].[DocTypeDef] 
WHERE [HeadTable] = 'oms_RecipeDefinition'

/* action type */

DECLARE @DEL BIT
DECLARE @INS BIT 

DECLARE @action CHAR(1)


SET @DEL = 0
SET @INS = 0


IF EXISTS (SELECT TOP 1 1 FROM DELETED) SET @DEL=1
IF EXISTS (SELECT TOP 1 1 FROM INSERTED) SET @INS = 1 

IF @INS = 1 AND @DEL = 1 SET @ACTION = 'u'
IF @INS = 1 AND @DEL = 0 SET @ACTION = 'i'
IF @INS = 0 AND @DEL = 1 SET @ACTION = 'd'


IF @ACTION = 'd'
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [RecipeDefinitionID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM deleted;

	INSERT INTO Life_oms_RecipeDefinition([RecipeDefinitionID],[DOC_REASON],[DOCTOR_FAMILY],[DOCTOR_NAME],[DOCTOR_PATRONYMIC],[DR],[PERSON_FAMILY],[PERSON_NAME],[PERSON_PATRONYMIC],[ADRES],[rf_KATLID],[SN_POL],[SS_RD],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [RecipeDefinitionID],[DOC_REASON],[DOCTOR_FAMILY],[DOCTOR_NAME],[DOCTOR_PATRONYMIC],[DR],[PERSON_FAMILY],[PERSON_NAME],[PERSON_PATRONYMIC],[ADRES],[rf_KATLID],[SN_POL],[SS_RD],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM deleted;
END;
ELSE
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [RecipeDefinitionID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM inserted;

	INSERT INTO Life_oms_RecipeDefinition([RecipeDefinitionID],[DOC_REASON],[DOCTOR_FAMILY],[DOCTOR_NAME],[DOCTOR_PATRONYMIC],[DR],[PERSON_FAMILY],[PERSON_NAME],[PERSON_PATRONYMIC],[ADRES],[rf_KATLID],[SN_POL],[SS_RD],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [RecipeDefinitionID],[DOC_REASON],[DOCTOR_FAMILY],[DOCTOR_NAME],[DOCTOR_PATRONYMIC],[DR],[PERSON_FAMILY],[PERSON_NAME],[PERSON_PATRONYMIC],[ADRES],[rf_KATLID],[SN_POL],[SS_RD],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM inserted;
END; 

SET NOCOUNT OFF;


go

