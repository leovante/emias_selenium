CREATE VIEW [V_kla_House] AS SELECT 
[hDED].[HouseID], [hDED].[x_Edition], [hDED].[x_Status], 
(( cast(hDed.Number as varchar) + 
(case when ltrim(rtrim(hDed.Building)) != '' then ', корп. ' +  upper(ltrim(rtrim(hDed.Building))) else '' end) +
(case when ltrim(rtrim(hDed.Construction)) != '' then ', стр. ' +  upper(ltrim(rtrim(hDed.Construction))) else '' end))) as [V_FullNumber], 
[hDED].[rf_StreetID] as [rf_StreetID], 
[jT_kla_Street].[V_FullName] as [SILENT_rf_StreetID], 
[hDED].[CODE] as [CODE], 
[hDED].[Number] as [Number], 
[hDED].[Building] as [Building], 
[hDED].[Construction] as [Construction], 
[hDED].[PostIndex] as [PostIndex], 
[hDED].[Flags] as [Flags]
FROM [kla_House] as [hDED]
INNER JOIN [V_kla_Street] as [jT_kla_Street] on [jT_kla_Street].[StreetID] = [hDED].[rf_StreetID]
go

