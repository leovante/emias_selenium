CREATE VIEW [V_oms_regs_Document] AS SELECT 
[hDED].[regs_DocumentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_CreatorID] as [rf_CreatorID], 
[hDED].[rf_AuthorID] as [rf_AuthorID], 
[hDED].[rf_RegisterMemberID] as [rf_RegisterMemberID], 
[hDED].[rf_FormID] as [rf_FormID], 
[hDED].[Created] as [Created], 
[hDED].[Updated] as [Updated], 
[hDED].[Data] as [Data]
FROM [oms_regs_Document] as [hDED]
go

