CREATE VIEW [V_oms_kl_Vedom] AS SELECT 
[hDED].[kl_VedomID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[IDVED] as [IDVED], 
[hDED].[VEDNAME] as [VEDNAME], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_Vedom] as [hDED]
go

