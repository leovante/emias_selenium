
Create procedure UpdateOrganisationProvider
	@SfoIdTable SfoIdTable readonly
as

declare	@n_tab varchar(100), @sql varchar(max), @sql2 varchar(max)


BEGIN TRY
----------------------------
--Добавление поставщиков в таблицу Организаций, если с таким кодом их еще не было
SET @n_tab='ras_Organisation';	
			INSERT INTO [ras_Organisation]
			([Name]
			,[Code]
			,[OGRN]
			,[rf_DogovorID]
			,[Address]
			,[IsActive]
			,[NameDIR]
			,[NameBUH]
			,[TEL]
			,[FAX]
			,[E_mail]
			,[rf_OKATO]
			,[SName])
			Select distinct FO_NAMES as [NAME],ltrim(rtrim(CFO)) as Code,FO_OGRN as OGRN,0 as rf_DogovorID,Adres as Address,
			1 as IsActive,Fam_Ruk as NameDir,Fam_Bux as NameBUH,oms_SFO.Tel,oms_SFO.Fax,oms_SFO.E_Mail,
			rf_OKATOID as rf_OKATO,FO_NAMEF as [SNAME]
			from oms_SFO
			left outer join [ras_Organisation] on CFO = Code
			where SFOID>0.1 and [ras_Organisation].OGRN is NULL and CFO <> '' and ltrim(rtrim(CFO)) not in (Select ltrim(rtrim(CFO))
			from oms_SFO
			left outer join [ras_Organisation] on CFO = Code
			where SFOID>0.1 and [ras_Organisation].OGRN is NULL and CFO <> '' and [ras_Organisation].Code is NUll
				and SFOID in (select SfoID from @SfoIdTable)
			group by CFO
			having count(ltrim(rtrim(CFO))) > 1)
			group by FO_NAMES,CFO,FO_OGRN,Adres,
			Fam_Ruk,Fam_Bux,oms_SFO.Tel,oms_SFO.Fax,oms_SFO.E_Mail,
			rf_OKATOID,FO_NAMEF
			order by Code

			--ОБНОВЛЕНИЕ ИЗ oms_SFO
			update [ras_Organisation]
			set
			[Name] = ttt.[NAME],
			[OGRN] = ttt.OGRN,		
			[Address] = ttt.Address,			
			[NameDIR] = ttt.NameDir,
			[NameBUH] = ttt.NameBUH, 
			[TEL] = ttt.Tel,
			[FAX] = ttt.Fax, 
			[E_mail] = ttt.E_Mail, 
			[rf_OKATO] = ttt.rf_OKATO, 
			[SName] = ttt.[SNAME]
			from
			(
			Select 
				distinct FO_NAMES as [NAME],				
				FO_OGRN as OGRN,	
				Adres as Address,	
				Fam_Ruk as NameDir,
				Fam_Bux as NameBUH,
				oms_SFO.Tel,
				oms_SFO.Fax,
				oms_SFO.E_Mail,
				rf_OKATOID as rf_OKATO,
				FO_NAMEF as [SNAME],
				[ras_Organisation].OrganisationID
			from oms_SFO
			inner join [ras_Organisation] on CFO = Code
			where SFOID>0 and CFO <> '' 
			and SFOID in (select SfoID from @SfoIdTable)
			and FO_NAMES != [NAME] or				
				FO_OGRN != OGRN or	
				Adres != Address or	
				Fam_Ruk != NameDir or
				Fam_Bux != NameBUH or
				oms_SFO.Tel != [ras_Organisation].Tel or
				oms_SFO.Fax != [ras_Organisation].Fax or
				oms_SFO.E_Mail != [ras_Organisation].E_Mail or
				rf_OKATOID != rf_OKATO or
				FO_NAMEF != [SNAME]
			group by FO_NAMES,CFO,FO_OGRN,Adres,
			Fam_Ruk,Fam_Bux,oms_SFO.Tel,oms_SFO.Fax,oms_SFO.E_Mail,
			rf_OKATOID,FO_NAMEF, [ras_Organisation].OrganisationID		
			)ttt
			where ttt.OrganisationID = [ras_Organisation].OrganisationID

END TRY
--Если запрос таки упал :(
BEGIN CATCH
--ошибка в индексах
	if ERROR_NUMBER()=2601 
	begin 

		SET @sql=null;
		SELECT @sql = ISNULL(@sql,'')+ CASE WHEN @sql IS NULL THEN '' ELSE ', ' END +c.name
			FROM sys.index_columns ic
			LEFT JOIN sys.indexes i ON ic.object_id=i.object_id
			LEFT JOIN sys.columns c ON ic.object_id=c.object_id
			WHERE ic.index_id=i.index_id and ic.column_id=c.column_id
			and i.name like '%UNIQUE'and ic.object_id=object_id(@n_tab)

		Select @sql2='CODE,OGRN'
		 
		if exists(select * from sysobjects where [name] = 'tmp_err')
				begin 
					insert into tmp_err
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
		
					end
				else
					begin
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
					into tmp_err
				end
	end
	--другая ошибка
	else 
		if exists(select * from sysobjects where [name] = 'tmp_err')
			begin
				insert into tmp_err
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage, '' as er
			end
		else
			begin
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage, '' as er into tmp_err
			end
END CATCH
go

