CREATE VIEW [V_oms_CHOICES_SMReestr] AS SELECT 
[hDED].[CHOICES_SMReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[field] as [field], 
[hDED].[Caption] as [Caption], 
[hDED].[Rem] as [Rem], 
[hDED].[Field1] as [Field1], 
[hDED].[Field2] as [Field2]
FROM [oms_CHOICES_SMReestr] as [hDED]
go

