
CREATE FUNCTION [dbo].[get_monitoring_ls](@BeginDate datetime, @EndDate datetime)
RETURNS @LS TABLE (
			Code varchar(50) not NULL,
            P_NAMES varchar(150) not NULL,
			recipe_COUNT int not null,
		    rcpCount int, 
			ost_onls decimal(18,10),	   
		    ost_vzn decimal(18,10),
			ost_rl decimal(18,10),
			max_date Date)
AS
BEGIN
insert @LS
Select apu.A_COD,
       apu.P_NAMES, 
	   rcp.rcpCount recipe_COUNT,
		rcp_otsp.rcpCount,
	   SUM(
	   case when deliv.Name like '%онлс%' then isnull(onls.Amount*ls_onls.Price,0)
	   else 0
	   end
	   ) ost_onls,
	   SUM(
	   case when deliv.Name like '%взн%' then isnull(onls.Amount*ls_onls.Price,0)
	   else 0
	   end
	   ) ost_vzn,
	   SUM(
	   case when deliv.Name like '%рл%' then isnull(onls.Amount*ls_onls.Price,0)
	   else 0
	   end
	   ) ost_rl,
	   convert(varchar, rcp.maxDate, 104) max_date
from oms_APU apu 
inner join ras_Organisation org on org.OGRN = apu.P_OGRN and org.Code = apu.A_COD
inner join ras_Store store on store.rf_OrganisationID = org.OrganisationID
inner join ras_TypeDelivery deliv on deliv.TypeDeliveryID = store.rf_TypeDeliveryID
left join get_all_ls_amount2(CONVERT(datetime, @EndDate, 104)) onls on onls.StoreID = store.StoreID 
left join ras_storedLS ls_onls on (ls_onls.StoredLSID = onls.StoredLSID)									
inner join (
select APUID, COUNT(distinct recipe.Num_Recipe) rcpCount, MAX(rc.Date_Create) maxDate 
from oms_DPCPharmacyRecipe recipe
inner join oms_APU on rf_APUID = apuID and Recipe.StatusEdition=0 and (Recipe.FLAGS&1)=0 and Recipe.Delayed_Service=0  
inner join oms_DPCPharmacyRecipeReestr rc on rc.DPCPharmacyRecipeReestrID = recipe.rf_DPCPharmacyRecipeReestrID
where APUID > 0 and recipe.DATE_OTP between @BeginDate and @EndDate
group by APUID) rcp on rcp.APUID = apu.APUID
left join (
select APUID, COUNT(recipe.Num_Recipe) rcpCount
from oms_DPCPharmacyRecipe recipe
inner join oms_APU on rf_APUID = apuID
 where 

 recipe.Delayed_Service=1 
       and statusedition=0 
       and (recipe.flags &1)=0
	   and ((recipe.FLAGS & 0x77) = 0x10 /*Берется на заказ*/
	   or  (recipe.FLAGS & 0x77)  = 0x50)  /*Отправлен на заявку*/
	   and recipe.DATE_OTP between @BeginDate and @EndDate
 group by APUID ) rcp_otsp on rcp_otsp.APUID = apu.APUID

group by apu.A_COD, apu.P_NAMES, rcp.rcpCount,rcp_otsp.rcpCount, rcp.maxDate
RETURN
END
go

