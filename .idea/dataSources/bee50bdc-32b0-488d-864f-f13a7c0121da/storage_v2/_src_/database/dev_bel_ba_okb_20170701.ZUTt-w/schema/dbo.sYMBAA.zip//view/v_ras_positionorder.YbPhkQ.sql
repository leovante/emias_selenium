CREATE VIEW [V_ras_PositionOrder] AS SELECT 
[hDED].[PositionOrderID], [hDED].[x_Edition], [hDED].[x_Status], 
(((isnull((Select sum(Count) from ras_PositionBillEx where rf_PositionOrderID = [hDED].PositionOrderID), 0)))) as [V_CountGiven], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[jT_ras_Nomenclature].[Name] as [SILENT_rf_NomenclatureID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID], 
[hDED].[rf_OrderID] as [rf_OrderID], 
[jT_ras_Order].[NUM] as [SILENT_rf_OrderID], 
[hDED].[rf_StatePositionOrderID] as [rf_StatePositionOrderID], 
[hDED].[CountOrder] as [CountOrder]
FROM [ras_PositionOrder] as [hDED]
INNER JOIN [ras_Nomenclature] as [jT_ras_Nomenclature] on [jT_ras_Nomenclature].[NomenclatureID] = [hDED].[rf_NomenclatureID] AND  [jT_ras_Nomenclature].[HostNomenclatureID] = [hDED].[rf_NomenclatureIDHost]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
INNER JOIN [ras_Order] as [jT_ras_Order] on [jT_ras_Order].[OrderID] = [hDED].[rf_OrderID]
go

