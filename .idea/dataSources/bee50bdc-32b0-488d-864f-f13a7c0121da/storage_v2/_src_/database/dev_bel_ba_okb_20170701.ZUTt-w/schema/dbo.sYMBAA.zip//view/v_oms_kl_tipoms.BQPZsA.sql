CREATE VIEW [V_oms_kl_TipOMS] AS SELECT 
[hDED].[kl_TipOMSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[IDDOC] as [IDDOC], 
[hDED].[DOCNAME] as [DOCNAME], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_TipOMS] as [hDED]
go

