CREATE PROCEDURE [dbo].[Oms_omsTableUpdate]
	(
		@Code_T int,				--Код таблицы с данными для загрузки НСИ
		@Result varchar(100) OUTPUT,
		@del int					--Признак удаления записей, которых нет в файле DBF			
	)
AS SET NOCOUNT ON

BEGIN TRY 
/*Переменные для процедуры*/
Declare @tab_oms varchar(100), @key_dbf varchar(400),@key_oms varchar(400),
@desc_table varchar(50),@desc_key varchar(500),@SQL nvarchar(max),@id int,@columns nvarchar(max),
@columns_u nvarchar(max),@columns_k nvarchar(max),@FieldClose nvarchar(50);
/*Инициализация переменных*/
Select @id=LoadNSITableID,@tab_oms=headtable,@desc_table=caption,
@SQL=Query_DBF,@key_dbf=Ltrim(Rtrim(Key_dbf)),@key_oms=Ltrim(Rtrim(key_oms)),@FieldClose=Ltrim(Rtrim(FieldClose))
from oms_LoadNSITable 
inner join x_DocTypeDef on headtable=Table_Name
where Code=@Code_T

/*Описание ключей*/
if exists(select * from sysobjects where [name] = 'tt') drop table tt
Set @SQL='Select x_DocElemDef.Caption,x_DocElemDef.Name into tt from x_DocElemDef
inner join x_DocTypeDef on x_DocElemDef.DocTypeDefID=x_DocTypeDef.DocTypeDefID
where x_DocElemDef.Name in ('+''''+Replace(@key_oms,',',''',''')+''''+') and headtable='''+@tab_oms+ ''''
EXECUTE sp_executesql @SQL
SELECT @desc_key = ISNULL(@desc_key,'')+ CASE WHEN @desc_key IS NULL THEN '' ELSE ', ' END +Caption from tt
/*Все колонки таблицы для вставки и обновления*/
SELECT  @columns_u = ISNULL(@columns_u,'')+ CASE WHEN @columns_u IS NULL THEN '' ELSE ', ' END 
+'['+c.[name]+']=t2.['+c.[name]+']',
@columns = ISNULL(@columns,'')+ CASE WHEN @columns IS NULL THEN '' ELSE ', ' END+'['+c.[name]+']' 
FROM sys.columns c
inner join sys.indexes i on i.object_id=object_id(@tab_oms)
WHERE c.object_id=object_id(@tab_oms) and c.[name] not in ('x_Edition','x_Status',
Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID') 
group by c.[name],c.collation_name
/*Колнки для связки по ключам*/
Select @columns_k = ISNULL(@columns_k,'')+ CASE WHEN @columns_k IS NULL THEN '' ELSE ' AND ' END+
't1.['+[Name]+']=t2.['+[Name]+']' from tt
drop table #tt
END TRY 
BEGIN CATCH 
Set @Result='Не прошла инициализация параметров для таблицы - '+@tab_oms;
END CATCH;
BEGIN TRY 

----------------
--Обновление----
----------------
Select @SQL='Update '+@tab_oms+' Set x_Edition=x_Edition+1, x_Status = 1, ' + @columns_u + 
             ' from '+@tab_oms+' t1 inner join rd_'+convert(varchar,@Code_T)+' t2 on '
             +@columns_k+' where upd=''u'' and '+Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID>0'
print @SQL
Set @Result='скрипт Update не прошел'
EXECUTE sp_executesql @SQL
----------------
--Вставка-------
----------------
Select @SQL='Insert into '+@tab_oms+'('+@columns+')'+' Select '+@columns+' from rd_'+convert(varchar,@Code_T)+' where upd=''i'''
print @SQL
Set @Result='скрипт Insert не прошел'
EXECUTE sp_executesql @SQL

/*Правим колонки, теперь под таблицу с историей*/
Set @columns=NULL
SELECT  @columns = ISNULL(@columns,'')+ CASE WHEN @columns IS NULL THEN '' ELSE ', ' END 
+case when c.[name] like '%Operation' then ' upd as x_Operation'
when c.[name] like '%DateTime' then 'getDate() as x_DateTime' 
when c.[name]='x_Seance' then '0 as x_Seance' 
when c.[name] ='x_User' then '1 as x_User'
else 't1.['+c.[name]+']' end FROM sys.columns c
WHERE c.object_id=object_id('Life_'+@tab_oms) and c.[name]<>Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'LifeID'
/*Запрос на вставку в таблицу Life_*/
/*Select @SQL='Insert into Life_'+@tab_oms+' Select '+@columns+' from '+@tab_oms+' t1 inner join rd_'+convert(varchar,@Code_T)+' t2 on '+@columns_k+
' where upd<>''d''' 
*/
--print @SQL
--Set @Result='не прошле вставка в историю Life'
--EXECUTE sp_executesql @SQL
/*Запрос на втавку в таблицу x_ObjLife*/
/*Select @SQL='Insert into x_ObjLife([DocTypeDefID],[ObjID],[x_Edition],[EditionDt],[x_Status],[LastOperation],[UserID]) Select (Select DocTypeDefID from x_DocTypeDef where HeadTable='''+@tab_oms+
''') as DocTypeDefID,'+Replace(Replace(@tab_oms,'oms_',''),'oms_','')+'ID as ObjID,x_Edition,getdate() as EditionDt,x_Status,
case when upd=''d'' then ''u'' else upd end as LastOperation, 1 as UserID from '+@tab_oms+' t1 inner join rd_'+convert(varchar,@Code_T)+' t2 on '+@columns_k+
' where upd<>''d''' 
*/
--print @SQL
--Set @Result='не прошла вставка в историю ObjLife'
--EXECUTE sp_executesql @SQL
----------------
--Удаление------
----------------
if @FieldClose is not null and @FieldClose <>''
begin
Select @SQL='Update '+@tab_oms+' Set x_Edition=x_Edition+1, '+@FieldClose+'=convert(datetime,'''+
convert(varchar,GETDATE(),121)+''',121) from '+@tab_oms+' t1 inner join rd_'+convert(varchar,@Code_T)+' t2 on '+@columns_k+
' where upd=''d''  and t1.'+@FieldClose+'>getDate() and '+Replace(@tab_oms,'oms_','')+'ID>0'
print @SQL
Set @Result='скрипт Delete не прошел'
EXECUTE sp_executesql @SQL
end
Set @Result='Обновление завершено успешно для таблицы - '+@tab_oms;
END TRY 
BEGIN CATCH 
Set @Result='Не прошло обновление для таблицы - '+@tab_oms+' по причине: '+@Result;
END CATCH;
go

