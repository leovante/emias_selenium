CREATE VIEW [V_ras_NomenGroup] AS SELECT 
[hDED].[NomenGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[GroupName] as [GroupName]
FROM [ras_NomenGroup] as [hDED]
go

