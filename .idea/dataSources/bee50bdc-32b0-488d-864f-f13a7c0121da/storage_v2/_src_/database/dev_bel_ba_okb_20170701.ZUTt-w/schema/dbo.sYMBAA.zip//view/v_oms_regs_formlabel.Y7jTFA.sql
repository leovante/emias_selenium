CREATE VIEW [V_oms_regs_FormLabel] AS SELECT 
[hDED].[regs_FormLabelID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FormID] as [rf_FormID], 
[hDED].[rf_LabelID] as [rf_LabelID], 
[hDED].[ElementId] as [ElementId]
FROM [oms_regs_FormLabel] as [hDED]
go

