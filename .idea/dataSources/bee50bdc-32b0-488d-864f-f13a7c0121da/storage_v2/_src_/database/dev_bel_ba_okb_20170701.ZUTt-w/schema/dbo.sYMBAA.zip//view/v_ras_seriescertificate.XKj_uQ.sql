CREATE VIEW [V_ras_SeriesCertificate] AS SELECT 
[hDED].[SeriesCertificateID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_ras_StorageCertificateBook].[Num] as [V_Num], 
[hDED].[rf_SeriesID] as [rf_SeriesID], 
[hDED].[rf_SeriesIDHost] as [rf_SeriesIDHost], 
[hDED].[rf_SeriesCertificateTypeID] as [rf_SeriesCertificateTypeID], 
[hDED].[rf_StorageCertificateBookID] as [rf_StorageCertificateBookID], 
[hDED].[Num] as [Num]
FROM [ras_SeriesCertificate] as [hDED]
INNER JOIN [ras_StorageCertificateBook] as [jT_ras_StorageCertificateBook] on [jT_ras_StorageCertificateBook].[StorageCertificateBookID] = [hDED].[rf_StorageCertificateBookID]
go

