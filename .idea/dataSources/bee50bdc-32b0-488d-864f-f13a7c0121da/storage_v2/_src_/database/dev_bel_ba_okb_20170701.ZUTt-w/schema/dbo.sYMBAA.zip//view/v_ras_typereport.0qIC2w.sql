CREATE VIEW [V_ras_TypeReport] AS SELECT 
[hDED].[TypeReportID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [ras_TypeReport] as [hDED]
go

