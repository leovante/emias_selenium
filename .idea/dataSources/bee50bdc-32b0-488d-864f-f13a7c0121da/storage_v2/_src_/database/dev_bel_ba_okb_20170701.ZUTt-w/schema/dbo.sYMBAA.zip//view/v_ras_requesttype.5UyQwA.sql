CREATE VIEW [V_ras_RequestType] AS SELECT 
[hDED].[RequestTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[isExtemporal] as [isExtemporal]
FROM [ras_RequestType] as [hDED]
go

