CREATE VIEW [V_oms_sc_StandartMKBProfile] AS SELECT 
[hDED].[sc_StandartMKBProfileID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[rf_StandartMKBID] as [rf_StandartMKBID], 
[jT_oms_sc_StandartMKB].[V_MKB] as [SILENT_rf_StandartMKBID], 
[hDED].[Flags] as [Flags], 
[hDED].[UGuid] as [UGuid]
FROM [oms_sc_StandartMKBProfile] as [hDED]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
INNER JOIN [V_oms_sc_StandartMKB] as [jT_oms_sc_StandartMKB] on [jT_oms_sc_StandartMKB].[sc_StandartMKBID] = [hDED].[rf_StandartMKBID]
go

