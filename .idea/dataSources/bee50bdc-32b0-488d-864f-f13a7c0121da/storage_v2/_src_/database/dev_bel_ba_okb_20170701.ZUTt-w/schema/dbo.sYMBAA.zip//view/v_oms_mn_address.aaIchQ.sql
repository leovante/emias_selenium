CREATE VIEW [V_oms_mn_Address] AS SELECT 
[hDED].[mn_AddressID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RegAddressID] as [rf_RegAddressID], 
[jT_kla_Address].[CODE] as [SILENT_rf_RegAddressID], 
[hDED].[rf_LiveAddressID] as [rf_LiveAddressID], 
[jT_kla_Address1].[CODE] as [SILENT_rf_LiveAddressID], 
[hDED].[rf_mn_PersonID] as [rf_mn_PersonID], 
[jT_oms_mn_Person].[V_FIO] as [SILENT_rf_mn_PersonID], 
[hDED].[RegAddress_Str] as [RegAddress_Str], 
[hDED].[LiveAddress_Str] as [LiveAddress_Str], 
[hDED].[isActive] as [isActive], 
[hDED].[AddressGuid] as [AddressGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[LiveAddress_Str_Find] as [LiveAddress_Str_Find], 
[hDED].[RegAddress_Str_Find] as [RegAddress_Str_Find]
FROM [oms_mn_Address] as [hDED]
INNER JOIN [kla_Address] as [jT_kla_Address] on [jT_kla_Address].[AddressID] = [hDED].[rf_RegAddressID]
INNER JOIN [kla_Address] as [jT_kla_Address1] on [jT_kla_Address1].[AddressID] = [hDED].[rf_LiveAddressID]
INNER JOIN [V_oms_mn_Person] as [jT_oms_mn_Person] on [jT_oms_mn_Person].[mn_PersonID] = [hDED].[rf_mn_PersonID]
go

