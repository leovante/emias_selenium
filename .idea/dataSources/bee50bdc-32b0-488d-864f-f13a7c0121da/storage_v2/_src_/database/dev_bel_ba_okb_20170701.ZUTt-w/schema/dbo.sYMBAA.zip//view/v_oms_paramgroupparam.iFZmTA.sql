CREATE VIEW [V_oms_ParamGroupParam] AS SELECT 
[hDED].[ParamGroupParamID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ParamGroupID] as [rf_ParamGroupID], 
[jT_oms_ParamGroup].[Name] as [SILENT_rf_ParamGroupID], 
[hDED].[rf_ParamID] as [rf_ParamID], 
[jT_oms_Param].[Name] as [SILENT_rf_ParamID], 
[hDED].[GuidParamGroupParam] as [GuidParamGroupParam]
FROM [oms_ParamGroupParam] as [hDED]
INNER JOIN [oms_ParamGroup] as [jT_oms_ParamGroup] on [jT_oms_ParamGroup].[ParamGroupID] = [hDED].[rf_ParamGroupID]
INNER JOIN [oms_Param] as [jT_oms_Param] on [jT_oms_Param].[ParamID] = [hDED].[rf_ParamID]
go

