CREATE VIEW [V_oms_TenderKind] AS SELECT 
[hDED].[TenderKindID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[TKind_Code] as [TKind_Code], 
[hDED].[TKind_Name] as [TKind_Name], 
[hDED].[GUIDKIND] as [GUIDKIND], 
[hDED].[TKind_Rem] as [TKind_Rem], 
[hDED].[TKind_FullName] as [TKind_FullName], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Date_B] as [Date_B]
FROM [oms_TenderKind] as [hDED]
go

