
Create procedure UpdateProvider
	@ProviderSfoIdTable ProviderSfoIdTable readonly
as

declare	@n_tab varchar(100), @sql varchar(max), @sql2 varchar(max)

BEGIN TRY
------------------------
--Добавление записей в таблицу с провайдерами, если с таким кодом еще не было
SET @n_tab='ras_Provider';	
			INSERT INTO [ras_Provider]
			([Name]
			,[rf_OrganisationID]
			,rf_SFOID
			,[rf_OrganisationIDHost])
			Select  distinct FO_NAMES as [Name],OrganisationID as rf_OrganisationID, sfoID as rf_SFOID,
			HostOrganisationID as rf_OrganisationIDHost
			from oms_SFO
			inner join ras_Organisation on Code=CFO and FO_OGRN=OGRN
			left outer join ras_Provider on OrganisationID = rf_OrganisationID --and FO_NAMES = ras_Provider.[Name]
			where OrganisationID>0.1 and ras_Provider.[Name] is null
				and oms_SFO.SFOID in (select ProviderSfoID from  @ProviderSfoIdTable)
			group by FO_NAMES,sfoID,OrganisationID,HostOrganisationID

			update [ras_Provider]
			set		[Name] = ttt.Name
			from
			(
						Select  distinct FO_NAMES as [Name], ras_Provider.ProviderID
						from oms_SFO
						inner join ras_Organisation on Code=CFO and FO_OGRN=OGRN
						inner join ras_Provider on OrganisationID = rf_OrganisationID
						where OrganisationID>0
						group by FO_NAMES, ras_Provider.ProviderID
			)ttt
			where ttt.ProviderID = [ras_Provider].ProviderID

			update ras_Provider
			set	rf_SfoID = SfoID
			from ras_Provider
			inner join ras_Organisation on OrganisationID = rf_OrganisationID
			inner join oms_SFO on Code=CFO and FO_OGRN=OGRN
			where rf_OrganisationID>0 and rf_SFOID = 0
				and oms_SFO.SFOID in (select ProviderSfoID from  @ProviderSfoIdTable)
END TRY
--Если запрос таки упал :(
BEGIN CATCH
--ошибка в индексах
	if ERROR_NUMBER()=2601 
	begin 

		SET @sql=null;
		SELECT @sql = ISNULL(@sql,'')+ CASE WHEN @sql IS NULL THEN '' ELSE ', ' END +c.name
			FROM sys.index_columns ic
			LEFT JOIN sys.indexes i ON ic.object_id=i.object_id
			LEFT JOIN sys.columns c ON ic.object_id=c.object_id
			WHERE ic.index_id=i.index_id and ic.column_id=c.column_id
			and i.name like '%UNIQUE'and ic.object_id=object_id(@n_tab)

		Select @sql2='rf_OrganisationIDHost,rf_OrganisationID'

		if exists(select * from sysobjects where [name] = 'tmp_err')
				begin 
					insert into tmp_err
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
		
					end
				else
					begin
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
					into tmp_err
				end
	end
	--другая ошибка
	else 
		if exists(select * from sysobjects where [name] = 'tmp_err')
			begin
				insert into tmp_err
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage, '' as er
			end
		else
			begin
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage, '' as er into tmp_err
			end
END CATCH
go

