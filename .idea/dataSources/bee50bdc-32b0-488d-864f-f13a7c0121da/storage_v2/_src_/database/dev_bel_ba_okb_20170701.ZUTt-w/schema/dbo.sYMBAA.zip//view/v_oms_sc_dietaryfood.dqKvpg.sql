CREATE VIEW [V_oms_sc_DietaryFood] AS SELECT 
[hDED].[sc_DietaryFoodID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_DietaryFood].[Name] as [V_Name], 
[hDED].[rf_sc_StandartCureID] as [rf_sc_StandartCureID], 
[jT_oms_sc_StandartCure].[StandartName] as [SILENT_rf_sc_StandartCureID], 
[hDED].[rf_DietaryFoodID] as [rf_DietaryFoodID], 
[jT_oms_DietaryFood].[Name] as [SILENT_rf_DietaryFoodID], 
[hDED].[Percent] as [Percent], 
[hDED].[Count] as [Count], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_sc_DietaryFood] as [hDED]
INNER JOIN [oms_DietaryFood] as [jT_oms_DietaryFood] on [jT_oms_DietaryFood].[DietaryFoodID] = [hDED].[rf_DietaryFoodID]
INNER JOIN [oms_sc_StandartCure] as [jT_oms_sc_StandartCure] on [jT_oms_sc_StandartCure].[sc_StandartCureID] = [hDED].[rf_sc_StandartCureID]
go

