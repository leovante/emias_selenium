CREATE VIEW [V_oms_ipra_TypeEvent] AS SELECT 
[hDED].[ipra_TypeEventID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ipra_EventGroupID] as [rf_ipra_EventGroupID], 
[jT_oms_ipra_EventGroup].[SHName] as [SILENT_rf_ipra_EventGroupID], 
[hDED].[Name] as [Name], 
[hDED].[SHName] as [SHName], 
[hDED].[Code] as [Code], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [oms_ipra_TypeEvent] as [hDED]
INNER JOIN [oms_ipra_EventGroup] as [jT_oms_ipra_EventGroup] on [jT_oms_ipra_EventGroup].[ipra_EventGroupID] = [hDED].[rf_ipra_EventGroupID]
go

