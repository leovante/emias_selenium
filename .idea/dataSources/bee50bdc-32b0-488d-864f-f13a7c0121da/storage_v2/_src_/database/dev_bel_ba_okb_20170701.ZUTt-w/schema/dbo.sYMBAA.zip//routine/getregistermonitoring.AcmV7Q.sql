CREATE PROCEDURE [dbo].[GetRegisterMonitoring]
	(
		@register varchar(250), -- регистр
		@periodBegin datetime, -- начало периода
		@periodEnd datetime -- конец периода
	)
AS
BEGIN

	/* регистр, по которому будем работать */

	declare @registerId integer
	set @registerId = (select top 1 regs_RegisterID from oms_regs_Register where EnumName = @register)

	/* Таблица для отчета */

	declare @t table(
		Area varchar(500), 
		Lpu varchar(200), 
		LpuId integer, 
		UserCount int, 
		ActiveUserCount int, 
		RecordPlan int, 
		RecordPeriodStart int, 
		RecordAdded int, 
		RecordChanged int, 
		RecordExcluded int, 
		RecordPeriodEnd int, 
		LastActionDate datetime)
	
	/* пользователи регистра */
	declare @registerUsers table (UserID int)
	insert into @registerUsers (UserID) select distinct rf_UserDoctorID from oms_regs_RegisterUserRole where rf_RegisterTypeID = @registerId

	/* пользователи, работавшие в период */
	declare @workedUsers table(UserID int)
	insert into @workedUsers (UserID) select distinct UserID from x_ObjLife where EditionDt >= @periodBegin and EditionDt <= @periodEnd

	/* Всего пользователей + активных + план*/

	insert into @t 
		(Area
		,Lpu
		,LpuId
		,UserCount
		,ActiveUserCount
		,RecordPlan
		,RecordPeriodStart
		,RecordAdded
		,RecordChanged
		,RecordExcluded
		,RecordPeriodEnd
		,LastActionDate)
	select 
		okato.O_NAME
		,lpu.M_names
		,lpu.LPUID
		,1
		,(select count(*) from @workedUsers where UserID = ud.regs_UserDoctorID)
		,(plans.Targets)
		,0
		,0
		,0
		,0
		,0
		,@periodBegin
	from oms_regs_UserDoctor ud
	inner join oms_doctor doc on doc.doctorid = ud.rf_doctorId
	inner join oms_lpu lpu on doc.rf_lpuid = lpu.LPUID
	left join oms_regs_Plans plans on lpu.LPUID = plans.rf_LPUID and plans.rf_RegisterId = @registerId
	inner join oms_OKATO  okato on lpu.rf_OKATOID = okato.OKATOID	
	where ud.regs_UserDoctorID in (select UserID from @registerUsers)
	

	/* записей на начало периода */
	insert into @t 
		(Area
		,Lpu
		,LpuId
		,UserCount
		,ActiveUserCount
		,RecordPlan
		,RecordPeriodStart
		,RecordAdded
		,RecordChanged
		,RecordExcluded
		,RecordPeriodEnd
		,LastActionDate)
	select 
		okato.O_NAME
		,org.M_names
		,org.LPUID
		,0
		,0
		,0
		,1
		,0
		,0
		,0
		,0
		,@periodBegin
	from  oms_regs_RegisterMember rm	
	inner join oms_lpu org on rm.rf_lpuid = org.LPUID
	inner join oms_OKATO  okato on org.rf_OKATOID = okato.OKATOID
	where rm.regs_RegisterMemberID > 0 	
		and rm.IncludeDate < @periodBegin 
		and rm.Actual = 1
		and rm.rf_RegisterID = @registerId

	/* записей добавлено за период */
	insert into @t 
		(Area
		,Lpu
		,LpuId
		,UserCount
		,ActiveUserCount
		,RecordPlan
		,RecordPeriodStart
		,RecordAdded
		,RecordChanged
		,RecordExcluded
		,RecordPeriodEnd
		,LastActionDate)
	select 
		okato.O_NAME
		,org.M_names
		,org.LPUID
		,0
		,0
		,0
		,0
		,1
		,0
		,0
		,0
		,rm.IncludeDate
	from  oms_regs_RegisterMember rm
	inner join oms_lpu org on rm.rf_lpuid = org.LPUID
	inner join oms_OKATO  okato on org.rf_OKATOID = okato.OKATOID
	where rm.regs_RegisterMemberID > 0 	
		and rm.IncludeDate >= @periodBegin 
		and rm.IncludeDate <= @periodEnd
		and rm.rf_RegisterID = @registerId
	

	/* записей изменено за период */
	

	/* член регистра + последняя дата его изменения */
	declare @changedMembers table(MemberId int, LastDate datetime)	

	insert into @changedMembers (MemberId, LastDate)
	select RegisterMemberId , MAX (LastDate) from
		(
			select 
				ol.regs_RegisterMemberID as RegisterMemberId,
				ol.x_DateTime as LastDate
			from Life_oms_regs_RegisterMember ol where ol.x_DateTime >= @periodBegin and ol.x_DateTime <= @periodEnd and ol.x_Operation = N'u'

			union
	
			select 
				ol.rf_AuthorID as RegisterMemberId,
				ol.x_DateTime as LastDate
			from life_oms_regs_Document ol where ol.x_DateTime >= @periodBegin and ol.x_DateTime <= @periodEnd

			union
	
			select 
				ol.rf_RegisterMemberID as RegisterMemberId,
				ol.x_DateTime as LastDate
			from Life_oms_regs_Medication ol where ol.x_DateTime >= @periodBegin and ol.x_DateTime <= @periodEnd 

			--union

			--select 
			--	(select top 1 regs_RegisterMemberID from oms_regs_RegisterMember where rf_LiveAddressID = ol.ObjID or rf_AddressRegID = ol.objID),
			--	ol.EditionDt as LastDate
			--from Life_kla_Address ol where ol.x_DateTime >= @periodBegin and ol.x_DateTime <= @periodEnd 			
			

		) t4 group by RegisterMemberId
	

	/* записей изменено за период */
	insert into @t 
		(Area
		,Lpu
		,LpuId
		,UserCount
		,ActiveUserCount
		,RecordPlan
		,RecordPeriodStart
		,RecordAdded
		,RecordChanged
		,RecordExcluded
		,RecordPeriodEnd
		,LastActionDate)
	select 
		okato.O_NAME
		,org.M_names
		,org.LPUID
		,0
		,0
		,0
		,0
		,0
		,1
		,0
		,0
		,cm.LastDate
	from  oms_regs_RegisterMember rm
	inner join @changedMembers cm on rm.regs_RegisterMemberID = cm.MemberId
	inner join oms_lpu org on rm.rf_lpuid = org.LPUID
	inner join oms_OKATO  okato on org.rf_OKATOID = okato.OKATOID
	where rm.regs_RegisterMemberID in (select regs_RegisterMemberID from @changedMembers) and rm.rf_RegisterId = @registerId

	/* записей исключено за период */
	insert into @t 
		(Area
		,Lpu
		,LpuId
		,UserCount
		,ActiveUserCount
		,RecordPlan
		,RecordPeriodStart
		,RecordAdded
		,RecordChanged
		,RecordExcluded
		,RecordPeriodEnd
		,LastActionDate)
	select 
		okato.O_NAME
		,org.M_names
		,org.LPUID
		,0
		,0
		,0
		,0
		,0
		,0
		,1
		,0
		,rm.ExcludeDate
	from  oms_regs_RegisterMember rm	
	inner join oms_lpu org on rm.rf_lpuid = org.LPUID
	inner join oms_OKATO  okato on org.rf_OKATOID = okato.OKATOID
	where rm.regs_RegisterMemberID > 0 	
		and rm.ExcludeDate >= @periodBegin 
		and rm.ExcludeDate <= @periodEnd
		and rm.ExcludeDate > rm.IncludeDate
		and rm.rf_RegisterID = @registerId
	

	select 
		 Area
		,Lpu
		,LpuId
		,Sum(UserCount) as TotalUser
		,Sum(ActiveUserCount) as TotalActiveUser
		,MAX(RecordPlan) as TotalRecordPlan
		,Sum(RecordPeriodStart) as TotalRecordPeriodStart
		,Sum(RecordAdded) as TotalRecordAdded
		,Sum(RecordChanged) as TotalRecordChanged
		,Sum(RecordExcluded) as TotalExcluded 
		,Sum(RecordPeriodStart) + Sum(RecordAdded) - Sum(RecordExcluded) as TotalPeriodEnd
		,Max(LastActionDate) as LastActionDate from @t group by Area, Lpu, LpuId
END


go

