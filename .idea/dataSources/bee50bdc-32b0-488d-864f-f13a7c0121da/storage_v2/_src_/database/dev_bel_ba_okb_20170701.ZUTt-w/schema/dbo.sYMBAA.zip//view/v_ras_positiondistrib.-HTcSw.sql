CREATE VIEW [V_ras_PositionDistrib] AS SELECT 
[hDED].[PositionDistribID], [hDED].[HostPositionDistribID], [hDED].[x_Edition], [hDED].[x_Status], 
((isnull((Select top 1 c_LSProvider from ras_LSFo where LSFOID = [jT_ras_StoredLS].rf_LSFOID), '') )) as [V_C_LSFO], 
((isnull((select top 1 t.Num from ras_StoredLS s 
inner join oms_Tender t on t.[TenderID] = s.[rf_TenderID]
where  s.[StoredLSID] =[hDED].[rf_StoredLSID]),''))
) as [V_TenderNum], 
((isnull((Select top 1 name from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId), '') )) as [V_Nomenclature], 
((isnull((select top 1 type.TenderType_Name from ras_StoredLS s 
inner join oms_Tender t on t.[TenderID] = s.[rf_TenderID]
inner join oms_TenderType type on type.TenderTypeID = s.[rf_tendertypeID]
where  s.[StoredLSID] =[hDED].[rf_StoredLSID]),''))) as [V_TenderTypeName], 
((isnull((Select top 1 NUM from ras_Series where SeriesID = [jT_ras_StoredLS].rf_SeriesID), '') )) as [V_Series], 
((isnull((Select top 1 name from ras_organisation where OrganisationID = [jT_ras_StoredLS].rf_organisationOwnerID), '') )) as [V_Owner], 
[jT_ras_StoredLS].[Consigment] as [V_Consigment], 
[jT_ras_StoredLS].[Price] as [V_Price], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_StatePosDistribID] as [rf_StatePosDistribID], 
[jT_ras_StatePosDistrib].[Name] as [SILENT_rf_StatePosDistribID], 
[hDED].[rf_DistribID] as [rf_DistribID], 
[hDED].[rf_DistribIDHost] as [rf_DistribIDHost], 
[jT_ras_Distrib].[Num] as [SILENT_rf_DistribID], 
[hDED].[Count] as [Count], 
[hDED].[Summa] as [Summa]
FROM [ras_PositionDistrib] as [hDED]
INNER JOIN [ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
INNER JOIN [ras_StatePosDistrib] as [jT_ras_StatePosDistrib] on [jT_ras_StatePosDistrib].[StatePosDistribID] = [hDED].[rf_StatePosDistribID]
INNER JOIN [ras_Distrib] as [jT_ras_Distrib] on [jT_ras_Distrib].[DistribID] = [hDED].[rf_DistribID] AND  [jT_ras_Distrib].[HostDistribID] = [hDED].[rf_DistribIDHost]
go

