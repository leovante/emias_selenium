CREATE VIEW [V_ras_PositionBill] AS SELECT 
[hDED].[PositionBillID], [hDED].[HostPositionBillID], [hDED].[x_Edition], [hDED].[x_Status], 
((ISNULL((Select TenderType_Name from dbo.oms_TenderType where TenderTypeID = hDED.rf_tendertypeID), ''))) as [V_TenderTypeName], 
((Select top 1 Name from ras_SubStore where SubStoreID = [hDED].[rf_SubStoreID])) as [V_SubStore], 
((isnull((Select GroupName from ras_nomenGroup where NomenGroupID 
in (Select rf_NomenGroupID from ras_Nomenclature where NomenclatureID = [hDED].[rf_NomenclatureID])),0))) as [V_NomenGroup], 
((isnull((Select Name from ras_RequestType where RequestTypeID 
in (Select rf_RequestTypeID from ras_Nomenclature where NomenclatureID = [hDED].[rf_NomenclatureID])),0))) as [V_RequestType], 
(isnull((select top 1 ras_Zone.name from ras_Zone
	inner join ras_Rack on rf_ZoneID = ZoneID
	inner join ras_Shelf on rf_RackID = RackId
		and jT_ras_SubStore.rf_ShelfID = ShelfID),'')) as [V_ZoneNum], 
(isnull((select top 1 ras_Rack.name from ras_Rack
	inner join ras_Shelf on rf_RackID = RackId
		and jT_ras_SubStore.rf_ShelfID = ShelfID),'')) as [V_RackNum], 
(isnull((select top 1 ras_Shelf.name from ras_Shelf
	where jT_ras_SubStore.rf_ShelfID = ShelfID),'')) as [V_ShelfNum], 
((Select top 1 name from ras_producer where rf_producerID = producerID)) as [Producer], 
[jT_ras_Nomenclature].[Cod_RAS] as [V_COD_LS], 
[jT_ras_Organisation].[Name] as [V_Owner], 
[jT_oms_Tender].[Num] as [V_TenderNum], 
[jT_ras_SubStore].[Name] as [V_Name], 
[jT_ras_Nomenclature].[Name] as [NameLS], 
[jT_ras_BillDocument].[NUM] as [V_NUM], 
[jT_ras_Series].[SertMSG] as [SertMSG], 
[jT_ras_Series].[Date_E] as [ExpDate], 
[jT_ras_Nomenclature].[Name] as [V_NAME_LS], 
[hDED].[rf_OrganisationOwnerID] as [rf_OrganisationOwnerID], 
[hDED].[rf_OrganisationOwnerIDHost] as [rf_OrganisationOwnerIDHost], 
[hDED].[rf_OrganisationByDemandID] as [rf_OrganisationByDemandID], 
[hDED].[rf_OrganisationByDemandIDHost] as [rf_OrganisationByDemandIDHost], 
[jT_ras_Organisation1].[Name] as [SILENT_rf_OrganisationByDemandID], 
[hDED].[rf_StateID] as [rf_StateID], 
[hDED].[rf_BillDocumentID] as [rf_BillDocumentID], 
[hDED].[rf_BillDocumentIDHost] as [rf_BillDocumentIDHost], 
[hDED].[rf_NDSID] as [rf_NDSID], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[hDED].[rf_SeriesID] as [rf_SeriesID], 
[hDED].[rf_SeriesIDHost] as [rf_SeriesIDHost], 
[jT_ras_Series].[NUM] as [SILENT_rf_SeriesID], 
[hDED].[rf_LSFOID] as [rf_LSFOID], 
[hDED].[rf_LSFOIDHost] as [rf_LSFOIDHost], 
[hDED].[rf_SubStoreID] as [rf_SubStoreID], 
[hDED].[rf_SubStoreIDHost] as [rf_SubStoreIDHost], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[hDED].[rf_PositionStatusID] as [rf_PositionStatusID], 
[hDED].[rf_DeliveryCLSDateID] as [rf_DeliveryCLSDateID], 
[hDED].[Price] as [Price], 
[hDED].[Count] as [Count], 
[hDED].[Summa] as [Summa], 
[hDED].[PriceBase] as [PriceBase], 
[hDED].[PriceOPT] as [PriceOPT], 
[hDED].[SumNDS] as [SumNDS], 
[hDED].[DateReg] as [DateReg], 
[hDED].[SH_Code] as [SH_Code], 
[hDED].[EAN13] as [EAN13], 
[hDED].[Note] as [Note], 
[hDED].[GTD] as [GTD], 
[hDED].[DateOUT] as [DateOUT], 
[hDED].[FractionCount] as [FractionCount], 
[hDED].[SGTIN] as [SGTIN], 
[hDED].[SSCC] as [SSCC], 
[hDED].[Measure] as [Measure], 
[hDED].[Guid] as [Guid], 
[hDED].[RegNum] as [RegNum], 
[hDED].[Consigment] as [Consigment]
FROM [ras_PositionBill] as [hDED]
INNER JOIN [ras_Nomenclature] as [jT_ras_Nomenclature] on [jT_ras_Nomenclature].[NomenclatureID] = [hDED].[rf_NomenclatureID] AND  [jT_ras_Nomenclature].[HostNomenclatureID] = [hDED].[rf_NomenclatureIDHost]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationOwnerID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationOwnerIDHost]
INNER JOIN [oms_Tender] as [jT_oms_Tender] on [jT_oms_Tender].[TenderID] = [hDED].[rf_TenderID]
INNER JOIN [ras_SubStore] as [jT_ras_SubStore] on [jT_ras_SubStore].[SubStoreID] = [hDED].[rf_SubStoreID] AND  [jT_ras_SubStore].[HostSubStoreID] = [hDED].[rf_SubStoreIDHost]
INNER JOIN [ras_BillDocument] as [jT_ras_BillDocument] on [jT_ras_BillDocument].[BillDocumentID] = [hDED].[rf_BillDocumentID] AND  [jT_ras_BillDocument].[HostBillDocumentID] = [hDED].[rf_BillDocumentIDHost]
INNER JOIN [ras_Series] as [jT_ras_Series] on [jT_ras_Series].[SeriesID] = [hDED].[rf_SeriesID] AND  [jT_ras_Series].[HostSeriesID] = [hDED].[rf_SeriesIDHost]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation1] on [jT_ras_Organisation1].[OrganisationID] = [hDED].[rf_OrganisationByDemandID] AND  [jT_ras_Organisation1].[HostOrganisationID] = [hDED].[rf_OrganisationByDemandIDHost]
go

