CREATE VIEW [V_kla_SocrBase] AS SELECT 
[hDED].[SocrBaseID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[LEVEL] as [LEVEL], 
[hDED].[SCNAME] as [SCNAME], 
[hDED].[SOCRNAME] as [SOCRNAME], 
[hDED].[KOD_T_ST] as [KOD_T_ST]
FROM [kla_SocrBase] as [hDED]
go

