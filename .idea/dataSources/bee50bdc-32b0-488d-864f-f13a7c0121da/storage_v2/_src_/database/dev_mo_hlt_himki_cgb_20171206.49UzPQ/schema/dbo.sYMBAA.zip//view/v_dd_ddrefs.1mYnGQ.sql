CREATE VIEW [V_dd_DDRefs] AS SELECT 
[hDED].[DDRefsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[TableName] as [TableName], 
[hDED].[RefName] as [RefName], 
[hDED].[DBFFileName] as [DBFFileName], 
[hDED].[SQLQuery] as [SQLQuery], 
[hDED].[Rem] as [Rem], 
[hDED].[Priority] as [Priority]
FROM [dd_DDRefs] as [hDED]
go

