CREATE VIEW [V_dd_DDStateOfHealthIndex] AS SELECT 
[hDED].[DDStateOfHealthIndexID], [hDED].[x_Edition], [hDED].[x_Status], 
((Select Name from hlt_GroupOfBloodRH where GroupOfBloodRHID=rf_GroupOfBloodRHID)) as [V_GroupOfBlood], 
[hDED].[rf_GroupOfBloodRHID] as [rf_GroupOfBloodRHID], 
[hDED].[rf_DDFormID] as [rf_DDFormID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag], 
[hDED].[RhFactor] as [RhFactor]
FROM [dd_DDStateOfHealthIndex] as [hDED]
go

