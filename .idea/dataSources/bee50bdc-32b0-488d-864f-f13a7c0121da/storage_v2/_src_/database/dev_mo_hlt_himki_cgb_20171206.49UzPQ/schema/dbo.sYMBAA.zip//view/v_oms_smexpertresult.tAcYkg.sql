CREATE VIEW [V_oms_SMExpertResult] AS SELECT 
[hDED].[SMExpertResultID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrID] as [rf_SMReestrID], 
[jT_oms_SMReestr].[V_SMReestr] as [SILENT_rf_SMReestrID], 
[hDED].[rf_SMExpertID] as [rf_SMExpertID], 
[jT_oms_SMExpert].[V_SMExpert] as [SILENT_rf_SMExpertID], 
[hDED].[rf_SMExpertResultID] as [rf_SMExpertResultID], 
[hDED].[rf_MTReestrID] as [rf_MTReestrID], 
[hDED].[Caption] as [Caption], 
[hDED].[Usl] as [Usl], 
[hDED].[S_U] as [S_U], 
[hDED].[Sluch] as [Sluch], 
[hDED].[S_S] as [S_S], 
[hDED].[Pat] as [Pat], 
[hDED].[S_P] as [S_P], 
[hDED].[Code] as [Code], 
[hDED].[Info] as [Info], 
[hDED].[NID] as [NID]
FROM [oms_SMExpertResult] as [hDED]
INNER JOIN [V_oms_SMReestr] as [jT_oms_SMReestr] on [jT_oms_SMReestr].[SMReestrID] = [hDED].[rf_SMReestrID]
INNER JOIN [V_oms_SMExpert] as [jT_oms_SMExpert] on [jT_oms_SMExpert].[SMExpertID] = [hDED].[rf_SMExpertID]
go

