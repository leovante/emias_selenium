-- =============================================
-- Author:		
-- Create date: 
-- Description:	Создаем медицинскую карту пациента
-- =============================================
CREATE PROCEDURE [dbo].[spCreateMKAB_RZ] @N_POL VARCHAR(20)
	,@date_bd DATETIME
	,@result INT OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET ARITHABORT ON;

	DECLARE @iddoc INT = 3 --Для полиса нового образца ИД = 3
	DECLARE @profitTypeCode VARCHAR(10) = '1' --ОМС
		-- Ищем в РЗ
	DECLARE @patid INT

	SET @result = 0;
	SET @patid = isnull((
				SELECT TOP 1 patientid
				FROM V_COD_RZ WITH (NOLOCK)
				WHERE n_pol = @n_pol
					AND Birthday = @date_bd
				), 0)

	IF @patid = 0
	BEGIN
		SET @result = 0;

		RETURN
	END

	-- Проверяем ЛПУ
	-- 
	DECLARE @lpucode VARCHAR(20)

	SET @lpucode = isnull((
				SELECT TOP 1 LPUCode
				FROM V_COD_RZ WITH (NOLOCK)
				WHERE patientid = @patid
				), '')

	IF len(ltrim(rtrim(@lpucode))) != 6
	BEGIN
		SET @result = 0;

		RETURN
	END

	-- Мы сейчас в этом ЛПУ?
	IF isnull((
				SELECT TOP 1 valuestr
				FROM x_usersettings WITH (NOLOCK)
				WHERE property = 'ОГРН поликлиники'
					AND rf_userid = 1
				), '-2') != isnull((
				SELECT TOP 1 c_ogrn
				FROM oms_LPU WITH (NOLOCK)
				WHERE mcod = @lpucode
				), '-1')
	BEGIN
		SET @result = 0;

		RETURN
	END

	DECLARE @fam VARCHAR(50)
	DECLARE @im VARCHAR(50)
	DECLARE @ot VARCHAR(50)

	SELECT TOP 1 @fam = family
		,@im = NAME
		,@ot = ot
	FROM V_COD_RZ
	WHERE patientid = @patid

	DECLARE @mkabid INT

	SET @mkabid = isnull((
				SELECT TOP 1 mkabid
				FROM hlt_mkab WITH (NOLOCK)
				WHERE family = @fam
					AND NAME = @im
					AND ot = @ot
					AND date_bd = @date_bd
				), 0)

	-- Есть ли карта со старым полисом?
	-- Обновить существующую карту 
	IF @mkabid > 0
	BEGIN
		-- Если полис нормальный - выходим.
		IF (select top 1 N_POL from hlt_MKAB where MKABID = @mkabid) = @n_pol
		BEGIN
			SET @result = @mkabid
			RETURN
		END

		UPDATE hlt_mkab
		SET s_pol = ''
			,n_pol = @N_POL
			,rf_kl_tipomsid = isnull((
					SELECT TOP 1 kl_TipOMSID
					FROM oms_kl_tipoms WITH (NOLOCK)
					WHERE IDDOC = @iddoc
					), 0)
		WHERE mkabid = @mkabid
	END
	ELSE -- Добавить новую карту
	BEGIN
		INSERT INTO [dbo].[hlt_MKAB] (
			[x_Edition]
			,[x_Status]
			,[FAMILY]
			,[NAME]
			,[OT]
			,[SS]
			,[W]
			,[DATE_BD]
			,[ADRES]
			,[rf_SMOID]
			,[rf_LPUID]
			,[S_POL]
			,[N_POL]
			,[UGUID]
			,[DatePolBegin]
			,[DatePolEnd]
			,[rf_OKATOID]
			,[FLAGS]
			,[rf_kl_SexID]
			,[CreateUserName]
			,[DateMKAB]
			,Dependent
			,IsWorker
			,KindCod
			,MilitaryCOD
			,N_DOC
			,PhoneHome
			,PhoneWork
			,Post
			,Profession
			,rf_CitizenID
			,rf_EnterpriseID
			,rf_INVID
			,rf_kl_SocStatusID
			,rf_TYPEDOCID
			,S_DOC
			,[WORK]
			,ConfirmAgree
			)
		SELECT 1 x_Edition
			,1 [x_Status]
			,[FAMILY]
			,[NAME]
			,[OT]
			,[SS]
			,[W]
			,birthday [DATE_BD]
			,[ADRES]
			,isnull((
					SELECT TOP 1 smoid
					FROM oms_smo WITH (NOLOCK)
					WHERE oms_smo.smocod = V_COD_RZ.smocod
					), 0) AS [rf_SMOID]
			,isnull((
					SELECT TOP 1 LPUID
					FROM oms_LPU WITH (NOLOCK)
					WHERE mcod = @lpucode
					), 0)
			,[S_POL]
			,[N_POL]
			,newid() [UGUID]
			,[DatePolBegin]
			,[DatePolEnd]
			,[rf_OKATOID]
			,[FLAGS]
			,[rf_kl_SexID]
			,'URZ_MO' [CreateUserName]
			,getdate() [DateMKAB]
			,Dependent
			,IsWorker
			,KindCod
			,MilitaryCOD
			,N_DOC
			,PhoneHome
			,PhoneWork
			,Post
			,Profession
			,rf_CitizenID
			,rf_EnterpriseID
			,rf_INVID
			,rf_kl_SocStatusID
			,rf_TYPEDOCID
			,S_DOC
			,PlaceEmployment
			,0 ConfirmAgree
		FROM V_COD_RZ WITH (NOLOCK)
		where patientid = @patid

		SET @mkabid = SCOPE_IDENTITY()
	END

	-- Добавим полис
	UPDATE hlt_polismkab
	SET isActive = 0
	WHERE rf_mkabid = @mkabid

	INSERT INTO [dbo].[hlt_PolisMKAB] (
		[x_Edition]
		,[x_Status]
		,[rf_MKABID]
		,[S_POL]
		,[N_POL]
		,[rf_kl_ProfitTypeID]
		,[DatePolBegin]
		,[DatePolEnd]
		,[rf_SMOID]
		,[isActive]
		,[GUID]
		,[Flags]
		,[rf_kl_TipOMSID]
		)
	SELECT 1 [x_Edition]
		,1 [x_Status]
		,@mkabid [rf_MKABID]
		,'' [S_POL]
		,@n_pol [N_POL]
		,isnull((
				SELECT TOP 1 kl_ProfitTypeID
				FROM oms_kl_ProfitType WITH (NOLOCK)
				WHERE CODE = @profitTypeCode
				), 0)
		,[DatePolBegin]
		,[DatePolEnd]
		,[rf_SMOID]
		,1 [isActive]
		,newid() [GUID]
		,[Flags]
		,[rf_kl_TipOMSID]
	FROM hlt_MKAB WITH (NOLOCK)
	WHERE mkabid = @mkabid

	SET @result = @mkabid

	RETURN;
END
go

