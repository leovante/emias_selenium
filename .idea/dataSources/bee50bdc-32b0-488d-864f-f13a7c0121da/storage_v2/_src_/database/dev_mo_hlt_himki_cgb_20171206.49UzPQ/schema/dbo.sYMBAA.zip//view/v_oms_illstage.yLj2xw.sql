CREATE VIEW [V_oms_IllStage] AS SELECT 
[hDED].[IllStageID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_IllStageCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_IllStage] as [hDED]
go

