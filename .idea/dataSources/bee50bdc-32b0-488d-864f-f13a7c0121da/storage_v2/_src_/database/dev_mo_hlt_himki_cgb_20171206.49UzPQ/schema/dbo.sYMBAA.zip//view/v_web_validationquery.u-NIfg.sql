CREATE VIEW [V_web_ValidationQuery] AS SELECT 
[hDED].[ValidationQueryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ValidationQueryTypeGuid] as [rf_ValidationQueryTypeGuid], 
[hDED].[Query] as [Query], 
[hDED].[Guid] as [Guid]
FROM [web_ValidationQuery] as [hDED]
go

