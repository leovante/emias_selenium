CREATE VIEW [V_oms_Tender] AS SELECT 
[hDED].[TenderID], [hDED].[x_Edition], [hDED].[x_Status], 
((IsNull((select sum(cls.V_Summa) from V_oms_CLS cls where cls.rf_TenderID=hDED.TenderID),0))) as [V_Summa], 
((isNull((select sum(pt.Summa) from oms_PayTender pt where pt.rf_TenderID = hDED.TenderID),0))) as [V_PaySumma], 
(ISNULL((SELECT hDED.SumDelivery-hDED.Penalty-hDED.Fine-IsNull(SUM(pt.Summa),0) FROM oms_PayTender pt WHERE pt.rf_TenderID = hDED.TenderID HAVING hDED.SumDelivery-hDED.Penalty-hDED.Fine-IsNull(SUM(pt.Summa),0)>0),0)) as [V_ToPay], 
((isnull((Select TOP 1 ShortName from oms_Organisation where OrganisationID = [hDED].[rf_OrganisationClientID]), 0)
)) as [V_OrganisationClient], 
((isnull((Select TOP 1 ShortName from oms_Organisation where OrganisationID = [hDED].[rf_OrganisationOwnerID]), 0))) as [V_OrganisationOwner], 
(((isnull((Select TOP 1 ShortName from oms_Organisation where OrganisationID = [hDED].[rf_OrganisationPayerID]), 0)))) as [V_OrganisationPayer], 
(IsNull(case when  (select top 1 Max(cls.IsCod) from V_oms_CLS cls where cls.rf_TenderID=hDED.TenderID)=1 then 'ЦОД' else 'Самозакуп' end, 'Самозакуп')) as [V_IsCod], 
[jT_oms_Organisation].[GUIDOrg] as [V_GUIDPayer], 
[jT_oms_SFO].[FO_OGRN] as [V_FO_OGRN], 
[jT_oms_Organisation1].[GUIDOrg] as [V_GUIDOwner], 
[jT_oms_SFO].[FO_NAMES] as [V_FO_NAMES], 
[jT_oms_Organisation2].[GUIDOrg] as [V_GUIDClient], 
[hDED].[rf_SFOID] as [rf_SFOID], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[jT_oms_Finl].[NAME] as [SILENT_rf_FinlID], 
[hDED].[rf_SpecID] as [rf_SpecID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID], 
[hDED].[rf_OrganisationClientID] as [rf_OrganisationClientID], 
[hDED].[rf_OrganisationPayerID] as [rf_OrganisationPayerID], 
[hDED].[rf_OrganisationOwnerID] as [rf_OrganisationOwnerID], 
[hDED].[rf_StateTenderID] as [rf_StateTenderID], 
[jT_oms_StateTender].[StateTender_Name] as [SILENT_rf_StateTenderID], 
[hDED].[rf_TenderKindID] as [rf_TenderKindID], 
[jT_oms_TenderKind].[TKind_Name] as [SILENT_rf_TenderKindID], 
[hDED].[rf_ProtokolID] as [rf_ProtokolID], 
[jT_oms_Protokol].[Num] as [SILENT_rf_ProtokolID], 
[hDED].[rf_SendStateID] as [rf_SendStateID], 
[jT_oms_SendState].[Description] as [SILENT_rf_SendStateID], 
[hDED].[Rem] as [Rem], 
[hDED].[Date_BP] as [Date_BP], 
[hDED].[Date_EP] as [Date_EP], 
[hDED].[GUID] as [GUID], 
[hDED].[Num] as [Num], 
[hDED].[BreachPenalty] as [BreachPenalty], 
[hDED].[Date] as [Date], 
[hDED].[ExpirePenalty] as [ExpirePenalty], 
[hDED].[RejectPenalty] as [RejectPenalty], 
[hDED].[Penalty] as [Penalty], 
[hDED].[Fine] as [Fine], 
[hDED].[SumDelivery] as [SumDelivery], 
[hDED].[Author] as [Author], 
[hDED].[ProtokolNum] as [ProtokolNum], 
[hDED].[DateProtokol] as [DateProtokol], 
[hDED].[FinYear] as [FinYear], 
[hDED].[AuctionInfo] as [AuctionInfo], 
[hDED].[Flags] as [Flags], 
[hDED].[CreateDate] as [CreateDate]
FROM [oms_Tender] as [hDED]
INNER JOIN [oms_Organisation] as [jT_oms_Organisation] on [jT_oms_Organisation].[OrganisationID] = [hDED].[rf_OrganisationPayerID]
INNER JOIN [oms_SFO] as [jT_oms_SFO] on [jT_oms_SFO].[SFOID] = [hDED].[rf_SFOID]
INNER JOIN [oms_Organisation] as [jT_oms_Organisation1] on [jT_oms_Organisation1].[OrganisationID] = [hDED].[rf_OrganisationOwnerID]
INNER JOIN [oms_Organisation] as [jT_oms_Organisation2] on [jT_oms_Organisation2].[OrganisationID] = [hDED].[rf_OrganisationClientID]
INNER JOIN [oms_Finl] as [jT_oms_Finl] on [jT_oms_Finl].[FinlID] = [hDED].[rf_FinlID]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
INNER JOIN [oms_StateTender] as [jT_oms_StateTender] on [jT_oms_StateTender].[StateTenderID] = [hDED].[rf_StateTenderID]
INNER JOIN [oms_TenderKind] as [jT_oms_TenderKind] on [jT_oms_TenderKind].[TenderKindID] = [hDED].[rf_TenderKindID]
INNER JOIN [oms_Protokol] as [jT_oms_Protokol] on [jT_oms_Protokol].[ProtokolID] = [hDED].[rf_ProtokolID]
INNER JOIN [oms_SendState] as [jT_oms_SendState] on [jT_oms_SendState].[SendStateID] = [hDED].[rf_SendStateID]
go

