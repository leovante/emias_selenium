CREATE VIEW [V_smp_Brigade] AS SELECT 
[hDED].[BrigadeID], [hDED].[x_Edition], [hDED].[x_Status], 
(((( '['+[hDED].Number+'] ' + (select Name from smp_BrigadeProfile where BrigadeProfileID=[hDED].rf_BrigadeProfileID) )))
) as [V_BrigadeInfo], 
[jT_smp_BrigadeProfile].[Name] as [V_ProfileName], 
[hDED].[rf_BrigadeProfileID] as [rf_BrigadeProfileID], 
[hDED].[Number] as [Number], 
[hDED].[Flag] as [Flag]
FROM [smp_Brigade] as [hDED]
INNER JOIN [smp_BrigadeProfile] as [jT_smp_BrigadeProfile] on [jT_smp_BrigadeProfile].[BrigadeProfileID] = [hDED].[rf_BrigadeProfileID]
go

