-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[spGetDVDStubNum] @dttid INT
	,@num VARCHAR(200) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET @num = ''

	DECLARE @dbtcode INT = '4' -- КОД ТИПА ПРИЕМА ПО ОЧЕРЕДИ.
	DECLARE @btime DATETIME
	DECLARE @date DATETIME
	DECLARE @docprvd INT
	DECLARE @planue INT
	DECLARE @lastnum INT

	SELECT @btime = Begin_Time
		,@date = [date]
		,@docprvd = rf_DocPRVDID
		,@planue = PlanUE
		,@lastnum = LastStubNum
	FROM hlt_DoctorTimeTable WITH (NOLOCK)
	WHERE DoctorTimeTableID = @dttid

	--Определим префикс--
	DECLARE @LPUDoctorID INT
		,@roomid INT
		,@type INT

	SELECT @LPUDoctorID = rf_LPUDoctorID
		,@roomid = rf_HealingRoomID
		,@type = rf_ResourceTypeID
	FROM hlt_DocPRVD WITH (NOLOCK)
	WHERE DocPRVDID = @docprvd

	IF @type = 1
	BEGIN
		-- ВРАЧ
		SELECT @num = LEFT(LTRIM(FAM_V), 1) + LEFT(LTRIM(IM_V), 1)
		FROM hlt_LPUDoctor WITH (NOLOCK)
		WHERE LPUDoctorID = @LPUDoctorID
	END
	ELSE
	BEGIN
		-- Кабинет
		SELECT @num = RIGHT('00' + RTRIM(NUM), 2)
		FROM hlt_HealingRoom WITH (NOLOCK)
		WHERE HealingRoomID = @roomid
	END

	----
	DECLARE @basenum INT = 0
	DECLARE @addnum INT = @lastnum + 1

	-- Определим номер --
	IF DATEPART(hour, @btime) != 0
	BEGIN
		-- Прием по расписанию
		SELECT @basenum = count(DoctorTimeTableID)
		FROM hlt_DoctorTimeTable dtt WITH (NOLOCK)
		WHERE dtt.Begin_Time <= @btime
			AND dtt.rf_DocPRVDID = @docprvd
			AND dtt.[Date] = @date
			AND DATEPART(hour, dtt.Begin_Time) != 0	
	END
	ELSE
	BEGIN
		-- Прием вне очереди
		SET @num = 'Э!'

		-- Прием по расписанию
		SELECT @basenum = count(DoctorTimeTableID)
		FROM hlt_DoctorTimeTable dtt WITH (NOLOCK)
		WHERE dtt.[Date] = @date
			AND DATEPART(hour, dtt.Begin_Time) = 0
			AND rf_DocBusyType IN (
				SELECT DocBusyTypeID
				FROM hlt_DocBusyType
				WHERE CODE = @dbtcode
					AND dateE > getdate()
				)
	END

	SET @num = @num /*+ '.'*/ + RIGHT('000' + cast(@basenum AS VARCHAR(3)), 3)

	IF @addnum > 1
	BEGIN
		SET @num = @num + '.' + RIGHT(cast(@addnum AS VARCHAR(3)), 3)
	END

	SET @num = UPPER(@num)

	UPDATE hlt_DoctorTimeTable set LastStubNum = LastStubNum + 1
	FROM hlt_DoctorTimeTable WITH (NOLOCK)
	WHERE DoctorTimeTableID = @dttid

	RETURN
	
END

go

