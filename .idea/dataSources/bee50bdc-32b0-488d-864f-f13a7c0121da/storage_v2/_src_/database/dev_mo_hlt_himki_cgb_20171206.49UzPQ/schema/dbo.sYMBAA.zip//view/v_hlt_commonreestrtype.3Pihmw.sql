CREATE VIEW [V_hlt_CommonReestrType] AS SELECT 
[hDED].[CommonReestrTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[COD] as [COD], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description]
FROM [hlt_CommonReestrType] as [hDED]
go

