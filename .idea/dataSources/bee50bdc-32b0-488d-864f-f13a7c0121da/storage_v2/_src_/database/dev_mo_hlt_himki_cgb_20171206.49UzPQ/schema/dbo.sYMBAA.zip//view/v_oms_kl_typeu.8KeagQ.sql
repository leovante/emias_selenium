CREATE VIEW [V_oms_kl_TypeU] AS SELECT 
[hDED].[kl_TypeUID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Type_U] as [Type_U], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[isPFin] as [isPFin]
FROM [oms_kl_TypeU] as [hDED]
go

