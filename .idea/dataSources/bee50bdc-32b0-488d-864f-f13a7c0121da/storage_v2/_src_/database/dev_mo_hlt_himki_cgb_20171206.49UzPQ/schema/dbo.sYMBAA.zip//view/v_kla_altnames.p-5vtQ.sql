CREATE VIEW [V_kla_AltNames] AS SELECT 
[hDED].[AltNamesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[LEVEL] as [LEVEL], 
[hDED].[OLDCODE] as [OLDCODE], 
[hDED].[NEWCODE] as [NEWCODE]
FROM [kla_AltNames] as [hDED]
go

