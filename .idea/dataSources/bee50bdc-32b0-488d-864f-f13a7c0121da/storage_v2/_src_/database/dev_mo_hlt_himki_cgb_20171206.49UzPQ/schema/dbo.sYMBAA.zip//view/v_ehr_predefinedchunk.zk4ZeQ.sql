CREATE VIEW [V_ehr_PredefinedChunk] AS SELECT 
[hDED].[PredefinedChunkID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TemplateID] as [rf_TemplateID], 
[hDED].[Guid] as [Guid], 
[hDED].[Name] as [Name], 
[hDED].[Chunk] as [Chunk]
FROM [ehr_PredefinedChunk] as [hDED]
go

