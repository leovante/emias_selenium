
-- =========================================================================
-- Добавляется запись с 0-м Id-шником в таблицы, в котором таких записей нет
-- =========================================================================
-- Author:		Татьяна Абаньшина
-- Create date: Август 2008
-- Description:	Добавляет запись в таблицу @tab с 0-м ID-шником в поле @fld 
--              Кроме этого, если для этой таблице в Таблице x_DocTypeDef
--              описано поле для вывода в референсах, и такое поле строковое 
--              и действительно есть в такой таблице, то в него записывается 
--              значение 'Без указания'
-- ==========================================================================
Create PROCEDURE dbo.InsBlankRecord (@tab varchar(100), @fld varchar(100))
AS
BEGIN
	Declare @SQL varchar(max)
    Declare @FldVal Varchar(100)
    set @Fldval  = ''
    select @FldVal= case when CharIndex('+',FieldName)=0 then  FieldName 
         else   Substring (fieldName,1,CharIndex('+',FieldName)-1) 
         end 
         from x_DocElemDEf e
         inner join x_DocTypeDef d on d.DocTypeDefID = e.DocTypeDefID
         inner join x_ValueType v  on v.ValueTypeID  = e.ValueType
         where HeadTable =@Tab and DocElemDefID = ToString
         and v.Name in ('varchar','nvarchar','ntext','nchar','char')

    if(@FldVal<>'' 
    and 
       (Exists(SELECT  *
                FROM   sysobjects o1   
                       INNER JOIN syscolumns c  ON   o1.id = c.cdefault    
                       INNER JOIN sysobjects o2 ON    c.id = o2.id 
                       where o2.Name = @Tab and c.Name =@FldVal
      )))

       set @SQL ='set identity_insert '+@tab+' on  INSERT INTO ['+@tab+'] (' +@fld+','+@FldVal+') VALUES (0,''Без указания'') set identity_insert '+@tab+' off'
    else 
       set @SQL ='set identity_insert '+@tab+' on  INSERT INTO ['+@tab+'] (' +@fld+') VALUES (0) set identity_insert '+@tab+' off'
    Exec(@SQL)

END
go

