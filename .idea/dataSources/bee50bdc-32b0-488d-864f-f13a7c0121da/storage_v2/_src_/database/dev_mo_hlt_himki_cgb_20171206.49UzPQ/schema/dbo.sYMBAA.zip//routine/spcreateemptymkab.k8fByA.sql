CREATE PROCEDURE [dbo].[spCreateEmptyMKAB]
	@input xml,
	@result int output
AS
BEGIN
     -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET ARITHABORT ON;

	DECLARE @RC int

	-- TODO: Set parameter values here.

	EXECUTE @RC = [dbo].[spGetMKABID] 
	   @input
	  ,@result OUTPUT

	-- Если МКАБ уже был - просто вернем его номер
	if (@result > 0)
	begin
	  return;	
	end

	-- Если довим ошибку, отличную от "Не найдена МКАБ" - возвращаем её
	if (@result != -3)
	begin
	  return;		
	end

	-- Создадим новую карту
	
    -- Получим поликлинику
	DECLARE @LPUID int;
	set @lpuid = 
    (
      SELECT top 1 ISNULL(lp.LPUID, 0) FROM oms_LPU lp
      WHERE lp.C_OGRN =
      (
          SELECT top 1 isnull(us.ValueStr, '') from x_UserSettings us
          where us.Property = 'ОГРН поликлиники'
      )
      and lp.MCOD = 
      (
          SELECT top 1 isnull(us.ValueStr, '') from x_UserSettings us
          where us.Property = 'Код поликлиники'
      )
      and lp.DATE_E > GETDATE()
    )


	declare @cnt int;
	declare @PATID varchar(25);
    
	declare @mkabid int;
    -- Код ошибка "Ошибка разбора входной xml-строки". Если упадем - вернем его
	set @mkabid = -10; 

	begin try

		/*Фамилия*/
		declare @family varchar(40)
		declare @name varchar(40)
		declare @patronymic varchar(40)
		declare @addres varchar(255)
		declare @s_pol varchar(50)
		declare @n_pol varchar(50)

		declare @sbirthday varchar(20)
		declare @birthday datetime
		set @birthday = LEFT(CONVERT(VARCHAR, getdate(), 126), 10) + 'T00:00:00'
		declare @date_now datetime
		set @date_now = @birthday

		declare @phone varchar(20)
	
		declare @CallCenter varchar(40)
		set @CallCenter = @input.query('/PatientInfo/CallCenter').value('.', 'varchar(40)')


		set @family = @input.query('/PatientInfo/Family').value('.', 'varchar(40)')
		
		/*Адрес*/
		set @addres = @input.query('/PatientInfo/AdresFact').value('.', 'varchar(255)')

		/*Имя*/
		set @name = @input.query('/PatientInfo/Name').value('.', 'varchar(40)')
		
		/*Отчество*/
		set @patronymic = @input.query('/PatientInfo/Patronymic').value('.', 'varchar(40)')
		
		/*Серия полиса ОМС*/
		set @s_pol = @input.query('/PatientInfo/S_POL').value('.', 'varchar(50)')
		
		/*Номер полиса ОМС*/
		set @n_pol = @input.query('/PatientInfo/N_POL').value('.', 'varchar(50)')
		
		/*Дата рождения*/
		set @sbirthday = @input.query('/PatientInfo/Birthday').value('.', 'varchar(19)')
		if (@sbirthday != '')
		begin		
			BEGIN TRY
				set @sbirthday = Upper(ltrim(rtrim(left(@sbirthday,10))))
				set @birthday = (select convert(datetime, @sbirthday , 120))
			END TRY
			BEGIN CATCH
				--set @result = -4; /*УПС. Не смогли привести строку к дате. Попробуем найти без даты*/
				--return;
			END CATCH
		end
	
		/* Идентификатор Номер телефона */
		set @phone = @input.query('/PatientInfo/Phone').value('.', 'varchar(20)')
		/*Оставляем только цифры*/
		while patindex('%[^0-9]%',@phone)<>0
			set @phone = replace(@phone,substring(@phone, patindex('%[^0-9]%',@phone),1),'')

		-- Если в номере не 11 символов или номер начинается не с "7" - считаем некорректным номером
		if ((Len(@phone) != 11) or ( CHARINDEX('7', @phone) != 1))
		begin	
		  set @phone = ''	
		end		

	if (@CallCenter = '1' and (select count(*) from hlt_Patient where S_POL = @s_pol and N_POL = @n_pol and Birthday = @birthday) != 1)
	begin
		set @result = -3;
		return;
	end

	insert into hlt_MKAB 
    (
    	FAMILY,
        [NAME],
        OT,
        DATE_BD,
        S_POL,
        N_POL, 
		rf_LPUID,
		contactMPhone,
		datePolBegin,
		datePolEnd,
		ADRES
    )
    (
	    SELECT @family
			,@name
			,@patronymic
			,@birthday
			,@s_pol
			,@n_pol
			,@LPUID
			,@phone 
			,'1900-01-01'
			,'2222-01-01'
			,@addres
    )

		/* сохраняем ID записи*/
		SET @mkabid = (SELECT IDENT_CURRENT('hlt_MKAB'))

		if ((select count(*) from hlt_Patient where S_POL = @s_pol and N_POL = @n_pol and Birthday = @birthday) = 1)
		begin
			update hlt_MKAB set
				FAMILY = case len(hlt_MKAB.FAMILY) when 0 then hlt_Patient.FAMILY else hlt_MKAB.FAMILY end,
				[NAME] = case len(hlt_MKAB.[NAME]) when 0 then hlt_Patient.[NAME] else hlt_MKAB.[NAME] end,
				OT = case len(hlt_MKAB.OT) when 0 then hlt_Patient.OT else hlt_MKAB.OT end,
				DATE_BD = case when @date_now = @birthday then hlt_Patient.Birthday else hlt_MKAB.DATE_BD end,
				rf_SMOID = hlt_Patient.rf_SMOID,
				SS = hlt_Patient.SS,
				W = hlt_Patient.W,
				rf_OKATOID = hlt_Patient.rf_OKATOID
			from hlt_MKAB
			join hlt_Patient on hlt_MKAB.S_POL = hlt_Patient.S_POL and hlt_MKAB.N_POL = hlt_Patient.N_POL and hlt_MKAB.DATE_BD = hlt_Patient.Birthday
			where hlt_Patient.S_POL = @s_pol and hlt_Patient.N_POL = @n_pol and hlt_Patient.Birthday = @birthday and MKABID = @mkabid

		end

	end try
	begin catch
		set @result = @mkabid;
		return;
	end catch

  	-- Возвращаем идентификатор карты
	set @result = @mkabid;
	return;
END


go

