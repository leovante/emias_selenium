
CREATE PROCEDURE [dbo].[sp2dr_CancelHomeVisit2] @id INT
	,@mkabid INT
	,@result INT OUTPUT
AS
BEGIN
	DECLARE @CallDocDTDID INT = isnull((
				SELECT DocTypeDefID
				FROM x_DocTypeDef
				WHERE GUID = '743F4CC3-29A1-4F24-882B-33CC9D0ED8FE'
				), 0)
	DECLARE @AtiveCode INT = isnull((
				SELECT CallDoctorStatusID
				FROM hlt_CallDoctorStatus WITH (NOLOCK)
				WHERE CODE = '1'
				), 0)
	DECLARE @CanceledCode INT = isnull((
				SELECT CallDoctorStatusID
				FROM hlt_CallDoctorStatus WITH (NOLOCK)
				WHERE CODE = '3'
				), 0)

	-- Есть ли такая запись?
	IF NOT EXISTS (
			SELECT 1
			FROM hlt_CallDoctor
			WHERE CallDoctorID = @id
				AND rf_MKABID = @mkabid
				AND ([rf_CallDoctorStatusID] = @AtiveCode OR [rf_CallDoctorStatusID] = (SELECT CallDoctorStatusID	FROM hlt_CallDoctorStatus WITH (NOLOCK)	WHERE CODE = '0')) -- добавил предварительный
			)
	BEGIN
		SET @result = - 21

		RETURN
	END

	BEGIN TRAN

	/* Удаляем запись */
	UPDATE [hlt_CallDoctor]
	SET [rf_CallDoctorStatusID] = @CanceledCode
	WHERE CallDoctorID = @id
		AND rf_mkabid = @mkabID
		AND ([rf_CallDoctorStatusID] = @AtiveCode OR [rf_CallDoctorStatusID] = (SELECT CallDoctorStatusID	FROM hlt_CallDoctorStatus WITH (NOLOCK)	WHERE CODE = '0')) -- добавил предварительный

	DECLARE @dvtid INT = isnull((
				SELECT TOP 1 rf_DoctorvisittableID
				FROM [hlt_ActionSchedule] acsh WITH (NOLOCK)
				WHERE acsh.[rf_DocTypeID] = @id
					AND acsh.[DocTypeDefID] = @CallDocDTDID
				), 0)

	IF (@dvtid > 0)
	BEGIN
		DELETE
		FROM hlt_DoctorVisitTable
		WHERE doctorvisittableid = @dvtid
	END

	COMMIT TRAN

	SET @result = 0
END
go

