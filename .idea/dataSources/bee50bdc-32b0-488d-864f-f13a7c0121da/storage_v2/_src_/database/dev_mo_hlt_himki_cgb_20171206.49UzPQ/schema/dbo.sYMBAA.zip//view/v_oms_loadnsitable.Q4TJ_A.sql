CREATE VIEW [V_oms_LoadNSITable] AS SELECT 
[hDED].[LoadNSITableID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Table_Name] as [Table_Name], 
[hDED].[Name_DBF] as [Name_DBF], 
[hDED].[Query_DBF] as [Query_DBF], 
[hDED].[Key_DBF] as [Key_DBF], 
[hDED].[Key_oms] as [Key_oms], 
[hDED].[Rem] as [Rem], 
[hDED].[Priority] as [Priority], 
[hDED].[DBFFields] as [DBFFields], 
[hDED].[UpdateOnly] as [UpdateOnly], 
[hDED].[Query_UnDBF] as [Query_UnDBF], 
[hDED].[Qwery_XML] as [Qwery_XML], 
[hDED].[FieldClose] as [FieldClose], 
[hDED].[IsService] as [IsService], 
[hDED].[S_Version] as [S_Version], 
[hDED].[V_Date] as [V_Date], 
[hDED].[XPath] as [XPath]
FROM [oms_LoadNSITable] as [hDED]
go

