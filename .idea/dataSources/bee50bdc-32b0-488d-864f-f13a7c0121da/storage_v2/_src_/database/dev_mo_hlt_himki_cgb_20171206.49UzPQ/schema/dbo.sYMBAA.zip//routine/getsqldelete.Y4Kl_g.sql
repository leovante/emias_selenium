
/* 
Функция генерит запрос для удаление записи 
перчисленных  доктипов



HeadTable				Description

hlt_TAP					Таблица амбулаторного посещения
hlt_DoctorTimeTable		Таблица режима работы врача
hlt_DoctorVisitTable	Таблица посещения для врача
hlt_Uchastok			Участок
hlt_Separation			Отделение
hlt_LPUDoctor			Медицинский персонал
hlt_HealingRoom			Кабинет
hlt_ServiceMedical		Содержит информацию о медицинских услугах
hlt_SMTAP				Оказанная медицинская помощь
--hlt_NotWorkDoc			Документ временной нетрудоспособности
*/


CREATE FUNCTION [dbo].[GetSQLDelete]
( @name varchar(50), @Id int )
RETURNS varchar(8000) 
AS
BEGIN
	declare @rez varchar(8000)
    set @rez=''
if(@name ='hlt_TAP')
	begin
		select top 1 @rez=
			'delete from hlt_Tap where TapId>0 and UGUID = '''
			+convert(varchar(100),[UGUID])+''''
			from Life_hlt_Tap
			where TapId= @id
			order by TapLifeID
end 
if(@name ='hlt_HealingRoom')
	begin
		select top 1 @rez=
			'delete from hlt_HealingRoom where HealingRoomId>0 and UGUID = '''
			+convert(varchar(100),[UGUID])+''''
			from Life_hlt_HealingRoom
			where HealingRoomId= @id
			order by HealingRoomLifeID
end 
if(@name ='hlt_Separation')
	begin
		select top 1 @rez=
			'delete from hlt_Separation where SeparationId>0 and UGUID = '''
			+convert(varchar(100),[UGUID])+''''
			from Life_hlt_Separation
			where SeparationId= @id
			order by SeparationLifeID
end 
if(@name ='hlt_Uchastok')
	begin
		select top 1 @rez=
			'delete from hlt_Uchastok where UchastokId>0 and UGUID = '''
			+convert(varchar(100),[UGUID])+''''
			from Life_hlt_Uchastok
			where UchastokId= @id
			order by UchastokLifeID
end 
if(@name ='hlt_SMTAP')
	begin
		select top 1 @rez=
			'delete from hlt_SMTap where SMTapId>0 and SMTAPGuid = '''
			+convert(varchar(100),[SMTAPGuid])+''''
			from Life_hlt_SMTap
			where SMTapId= @id
			order by SMTapLifeID
end 
if(@name ='hlt_DoctorVisitTable')
	begin
		select top 1 @rez=
			'delete from hlt_DoctorVisitTable where DoctorVisitTableId>0 and UGuid = '''
			+convert(varchar(100),[UGuid])+''''
			from Life_hlt_DoctorVisitTable
			where DoctorVisitTableId= @id
			order by DoctorVisitTableLifeID
end 
if(@name ='hlt_DoctorTimeTable')
	begin
		select top 1 @rez=
			'delete from hlt_DoctorTimeTable where DoctorTimeTableId>0 and UGuid = '''
			+convert(varchar(100),[UGuid])+''''
			from Life_hlt_DoctorTimeTable
			where DoctorTimeTableId= @id
			order by DoctorTimeTableLifeID
   end 
if(@name ='hlt_LPUDoctor')
	begin
		select top 1 @rez=
			'delete from hlt_LPUDoctor where LPUDoctorId>0 and UGuid = '''
			+convert(varchar(100),[UGuid])+''''
			from Life_hlt_LPUDoctor
			where LPUDoctorId= @id
			order by LPUDoctorLifeID
    end 
if(@name ='hlt_ServiceMedical')
	begin
		select top 1 @rez=
			'delete from hlt_ServiceMedical where ServiceMedicalId>0 and UGuid = '''
			+convert(varchar(100),[UGuid])+''''
			from Life_hlt_ServiceMedical
			where ServiceMedicalId= @id
			order by ServiceMedicalLifeID
    end 
if(@name ='hlt_PolyclinicRecipeFederalLG')
	begin
		select top 1 @rez=
			'delete from hlt_PolyclinicRecipeFederalLG where PolyclinicRecipeFederalLGId>0 and RecipeGuid = '''
			+convert(varchar(100),[RecipeGuid])+''''
			from Life_hlt_PolyclinicRecipeFederalLG
			where PolyclinicRecipeFederalLGId= @id
			order by PolyclinicRecipeFederalLGLifeID
    end 
/*if(@name ='hlt_NotWorkDoc')
	begin
		select top 1 @rez=
			'delete from hlt_NotWorkDoc where NotWorkDocId>0 and UGuid = '''
			+convert(varchar(100),[UGuid])+''''
			from Life_hlt_NotWorkDoc
			where NotWorkDocId= @id
			order by NotWorkDocLifeID
    end */
RETURN @rez

END
go

