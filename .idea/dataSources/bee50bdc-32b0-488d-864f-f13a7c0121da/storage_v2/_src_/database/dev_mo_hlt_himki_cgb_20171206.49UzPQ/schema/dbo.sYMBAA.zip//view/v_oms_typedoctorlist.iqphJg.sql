CREATE VIEW [V_oms_TypeDoctorList] AS SELECT 
[hDED].[TypeDoctorListID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Rem] as [Rem]
FROM [oms_TypeDoctorList] as [hDED]
go

