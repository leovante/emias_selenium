CREATE VIEW [dbo].[IV_Schedul]
AS
SELECT dtt.DoctorTimeTableID
	,dtt.Begin_Time AS DTT_Begin_Time
	,dtt.End_Time AS DTT_End_Time
	,dtt.DATE AS DTT_Date
	,dtt.FlagAccess AS DTT_FlagAccess
	,dtt.PlanUE AS DTT_PlanUE
	,dtt.rf_DocPRVDID AS DTT_DocPrVdID
	,(
		SELECT TOP 1 DocBusyTypeID
		FROM hlt_DocBusyType
		WHERE code = '4'
		) /*dbt.DocBusyTypeID*/ DocBusyTypeID
	,dtt.rf_HealingRoomID AS DTT_HealingRoomID
	,dtt.UsedUE /*dvt.NormaUE*/ AS DVT_NormaUE
FROM dbo.hlt_DoctorTimeTable AS dtt
INNER JOIN dbo.hlt_DocPRVD AS dprvd ON dtt.rf_DocPRVDID = dprvd.DocPRVDID
	AND dprvd.InTime = 1
INNER JOIN dbo.hlt_DocBusyType AS dbt WITH (NOLOCK) ON dbt.DocBusyTypeID = dtt.rf_DocBusyType
	AND dbt.DocBusyTypeID <> 0
WHERE dtt.DoctorTimeTableID <> 0
	AND dtt.PlanUE > 0
	AND (dbt.TypeBusy IN (1, 2)	)
	and dtt.DoctorTimeTableID <> 0  
	AND dtt.Begin_Time <> '1900-01-01T00:00:00' AND datepart(hour, dtt.Begin_Time) > 0 --отсекаем записи вне очереди		
	AND dtt.rf_DocPRVDID <> 0

go

