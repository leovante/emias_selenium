CREATE VIEW [V_kla_Address] AS SELECT 
[hDED].[AddressID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_HouseID] as [rf_HouseID], 
[hDED].[CODE] as [CODE], 
[hDED].[AddressString] as [AddressString], 
[hDED].[Appartment] as [Appartment], 
[hDED].[DopData] as [DopData]
FROM [kla_Address] as [hDED]
go

