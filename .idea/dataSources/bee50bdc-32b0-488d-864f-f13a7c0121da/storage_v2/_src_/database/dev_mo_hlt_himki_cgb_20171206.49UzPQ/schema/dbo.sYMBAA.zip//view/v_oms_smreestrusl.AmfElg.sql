CREATE VIEW [V_oms_SMreestrUsl] AS SELECT 
[hDED].[SMreestrUslID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_SMReestrSluch].[V_SMReestrTypeCode] as [V_SMReestrTypeCode], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[jT_oms_SMReestrSluch].[IDCase] as [SILENT_rf_SMReestrSluchID], 
[hDED].[IDServ] as [IDServ], 
[hDED].[Profil] as [Profil], 
[hDED].[Podr] as [Podr], 
[hDED].[Det] as [Det], 
[hDED].[Date_IN] as [Date_IN], 
[hDED].[Code_USL] as [Code_USL], 
[hDED].[Date_OUT] as [Date_OUT], 
[hDED].[DS] as [DS], 
[hDED].[Usl] as [Usl], 
[hDED].[Kol_USL] as [Kol_USL], 
[hDED].[PRVS] as [PRVS], 
[hDED].[Tarif_Usl] as [Tarif_Usl], 
[hDED].[Code_MD] as [Code_MD], 
[hDED].[LPU] as [LPU], 
[hDED].[SumV_Usl] as [SumV_Usl], 
[hDED].[LPU_1] as [LPU_1], 
[hDED].[ComentU] as [ComentU], 
[hDED].[NOM_USL] as [NOM_USL], 
[hDED].[VID_ME] as [VID_ME], 
[hDED].[VID_VME] as [VID_VME], 
[hDED].[NPL] as [NPL], 
[hDED].[P_OTK] as [P_OTK]
FROM [oms_SMreestrUsl] as [hDED]
INNER JOIN [V_oms_SMReestrSluch] as [jT_oms_SMReestrSluch] on [jT_oms_SMReestrSluch].[SMReestrSluchID] = [hDED].[rf_SMReestrSluchID]
go

