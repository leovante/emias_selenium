CREATE VIEW [V_oms_ParamType] AS SELECT 
[hDED].[ParamTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[GUIDParamType] as [GUIDParamType]
FROM [oms_ParamType] as [hDED]
go

