CREATE VIEW [V_hlt_disp_ExamParamValue] AS SELECT 
[hDED].[disp_ExamParamValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ParamValuedGuid] as [rf_ParamValuedGuid], 
[jT_oms_ParamValue].[Value] as [SILENT_rf_ParamValuedGuid], 
[hDED].[rf_ExamGuid] as [rf_ExamGuid], 
[jT_hlt_disp_Exam].[rf_ServiceGuid] as [SILENT_rf_ExamGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_ExamParamValue] as [hDED]
INNER JOIN [oms_ParamValue] as [jT_oms_ParamValue] on [jT_oms_ParamValue].[GUIDParamValue] = [hDED].[rf_ParamValuedGuid]
INNER JOIN [hlt_disp_Exam] as [jT_hlt_disp_Exam] on [jT_hlt_disp_Exam].[Guid] = [hDED].[rf_ExamGuid]
go

