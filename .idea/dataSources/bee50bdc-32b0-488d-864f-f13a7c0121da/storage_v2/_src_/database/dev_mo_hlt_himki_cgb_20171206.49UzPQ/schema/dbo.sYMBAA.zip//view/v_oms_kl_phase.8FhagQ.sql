CREATE VIEW [V_oms_kl_Phase] AS SELECT 
[hDED].[kl_PhaseID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_PhaseCode], 
[hDED].[rf_kl_PhaseTreeID] as [rf_kl_PhaseTreeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_Phase] as [hDED]
go

