CREATE VIEW [V_stt_StationarBranch] AS SELECT 
[hDED].[StationarBranchID], [hDED].[x_Edition], [hDED].[x_Status], 
('['+[jT_oms_Department].[DepartmentCODE]+'] ' +[jT_oms_Department].[DepartmentNAME]) as [V_BranchInfo], 
[jT_oms_Department].[DepartmentNAME] as [V_Name], 
[jT_stt_StationarType].[Name] as [NameStationarType], 
[jT_oms_Department].[DepartmentCODE] as [V_Code], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[hDED].[rf_StationarTypeID] as [rf_StationarTypeID], 
[jT_stt_StationarType].[Name] as [SILENT_rf_StationarTypeID], 
[hDED].[rf_TransportHostID] as [rf_TransportHostID], 
[hDED].[rf_BedProfileID] as [rf_BedProfileID], 
[hDED].[Flag] as [Flag], 
[hDED].[ConnectionString] as [ConnectionString], 
[hDED].[Password] as [Password], 
[hDED].[Login] as [Login]
FROM [stt_StationarBranch] as [hDED]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [stt_StationarType] as [jT_stt_StationarType] on [jT_stt_StationarType].[StationarTypeID] = [hDED].[rf_StationarTypeID]
go

