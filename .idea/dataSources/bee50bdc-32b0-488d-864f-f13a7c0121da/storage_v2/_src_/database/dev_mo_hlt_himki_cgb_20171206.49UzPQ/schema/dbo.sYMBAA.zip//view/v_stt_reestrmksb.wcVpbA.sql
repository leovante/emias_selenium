CREATE VIEW [V_stt_ReestrMKSB] AS SELECT 
[hDED].[ReestrMKSBID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[jT_hlt_ReestrMH].[DateBegin] as [SILENT_rf_ReestrMHID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[jT_hlt_ReportPeriod].[Year_Month] as [SILENT_rf_ReportPeriodID], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[hDED].[rf_MedServicePatientID] as [rf_MedServicePatientID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_ServiceTypeID] as [rf_ServiceTypeID], 
[hDED].[rf_ReestrOccasionID] as [rf_ReestrOccasionID], 
[jT_stt_ReestrOccasion].[Num] as [SILENT_rf_ReestrOccasionID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flag] as [flag], 
[hDED].[Num] as [Num], 
[hDED].[Sum_V] as [Sum_V], 
[hDED].[Sum_O] as [Sum_O], 
[hDED].[Kol_V] as [Kol_V], 
[hDED].[Kol_O] as [Kol_O], 
[hDED].[NumRepPer] as [NumRepPer]
FROM [stt_ReestrMKSB] as [hDED]
INNER JOIN [hlt_ReestrMH] as [jT_hlt_ReestrMH] on [jT_hlt_ReestrMH].[ReestrMHID] = [hDED].[rf_ReestrMHID]
INNER JOIN [V_hlt_ReportPeriod] as [jT_hlt_ReportPeriod] on [jT_hlt_ReportPeriod].[ReportPeriodID] = [hDED].[rf_ReportPeriodID]
INNER JOIN [stt_ReestrOccasion] as [jT_stt_ReestrOccasion] on [jT_stt_ReestrOccasion].[ReestrOccasionID] = [hDED].[rf_ReestrOccasionID]
go

