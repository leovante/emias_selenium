CREATE VIEW [V_oms_kl_AgeGroup] AS SELECT 
[hDED].[kl_AgeGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_AgeGroupCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[GUIDAgeGroup] as [GUIDAgeGroup], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_AgeGroup] as [hDED]
go

