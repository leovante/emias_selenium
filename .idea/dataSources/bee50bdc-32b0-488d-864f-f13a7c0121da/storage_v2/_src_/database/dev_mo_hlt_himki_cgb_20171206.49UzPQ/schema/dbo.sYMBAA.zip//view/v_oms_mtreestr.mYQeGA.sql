CREATE VIEW [V_oms_MTReestr] AS SELECT 
[hDED].[MTReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
((((case when MTReestrID>0 then 
((((Convert(varchar,[Data],102)+  
	case when Num >0 then   ' № ' +
		convert(varchar,Num) else '' end +' от 

['+jT_oms_OKATO1.O_Name +'] для ['+  jT_oms_OKATO.O_Name+']'  ))))
else ' Не указан ' end	)))) as [V_MTReestr], 
[hDED].[rf_OKATO_OMSID] as [rf_OKATO_OMSID], 
[jT_oms_OKATO].[C_OKATO] as [SILENT_rf_OKATO_OMSID], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[jT_oms_OKATO1].[C_OKATO] as [SILENT_rf_OKATOID], 
[hDED].[rf_STFID] as [rf_STFID], 
[jT_oms_STF].[TF_NAME] as [SILENT_rf_STFID], 
[hDED].[rf_STF_PlatID] as [rf_STF_PlatID], 
[jT_oms_STF1].[TF_NAME] as [SILENT_rf_STF_PlatID], 
[hDED].[rf_SMReestrTypeID] as [rf_SMReestrTypeID], 
[hDED].[rf_SMReestrStateID] as [rf_SMReestrStateID], 
[jT_oms_SMReestrState].[Name] as [SILENT_rf_SMReestrStateID], 
[hDED].[C_OKATO1] as [C_OKATO1], 
[hDED].[OKATO_OMS] as [OKATO_OMS], 
[hDED].[FileName] as [FileName], 
[hDED].[Data] as [Data], 
[hDED].[Num] as [Num], 
[hDED].[Num_dop] as [Num_dop], 
[hDED].[Num_Exp] as [Num_Exp], 
[hDED].[MTRGuid] as [MTRGuid]
FROM [oms_MTReestr] as [hDED]
INNER JOIN [oms_OKATO] as [jT_oms_OKATO] on [jT_oms_OKATO].[OKATOID] = [hDED].[rf_OKATO_OMSID]
INNER JOIN [oms_OKATO] as [jT_oms_OKATO1] on [jT_oms_OKATO1].[OKATOID] = [hDED].[rf_OKATOID]
INNER JOIN [oms_STF] as [jT_oms_STF] on [jT_oms_STF].[STFID] = [hDED].[rf_STFID]
INNER JOIN [oms_STF] as [jT_oms_STF1] on [jT_oms_STF1].[STFID] = [hDED].[rf_STF_PlatID]
INNER JOIN [oms_SMReestrState] as [jT_oms_SMReestrState] on [jT_oms_SMReestrState].[SMReestrStateID] = [hDED].[rf_SMReestrStateID]
go

