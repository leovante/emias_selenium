CREATE PROCEDURE [dbo].[rptRaspBrak] 	
AS
BEGIN

declare @date_rep date;

Set @date_rep=getdate();

insert into [hlt_demostend].dbo.RaspBrak
Select @date_rep as dat,*  from(
Select oms_lpu.MCOd,
	oms_PRVS.PRVS_Name as [Специализация],
	FAM_V+' '+IM_V+' '+OT_V as [ФИОВрача],
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= @date_rep and dtt.date<dateadd(day,14,@date_rep)
	and dtt.rf_DocPRVDID=DocPRVDID
	),0) as tall,isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= @date_rep and dtt.date<dateadd(day,14,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_brall,
		isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= @date_rep and dtt.date<dateadd(day,1,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br1,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,1,@date_rep) and dtt.date<dateadd(day,2,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br2,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,2,@date_rep) and dtt.date<dateadd(day,3,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br3,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,3,@date_rep) and dtt.date<dateadd(day,4,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br4,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,4,@date_rep) and dtt.date<dateadd(day,5,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br5,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,5,@date_rep) and dtt.date<dateadd(day,6,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br6,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,6,@date_rep) and dtt.date<dateadd(day,7,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br7,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,7,@date_rep) and dtt.date<dateadd(day,8,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br8,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,8,@date_rep) and dtt.date<dateadd(day,9,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br9,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,9,@date_rep) and dtt.date<dateadd(day,10,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br10,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,10,@date_rep) and dtt.date<dateadd(day,11,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br11,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,11,@date_rep) and dtt.date<dateadd(day,12,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br12,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,12,@date_rep) and dtt.date<dateadd(day,13,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br13,
	isnull((Select sum(dtt.PlanUE) from hlt_DoctorTimeTable dtt WITH(NOLOCK)
	inner join hlt_DocBusyType WITH(NOLOCK) on DocBusyTypeID=rf_DocBusyType and hlt_DocBusyType.TypeBusy>0
	inner join life_hlt_DoctorTimeTable life on dtt.DoctorTimeTableID=life.DoctorTimeTableID and x_Operation='i'
	where DATEPART(hour, dtt.Begin_Time) > 0 and dtt.date >= dateadd(day,13,@date_rep) and dtt.date<dateadd(day,14,@date_rep)
	and x_Datetime>dateadd(day,-14,dtt.date) and dtt.rf_DocPRVDID=DocPRVDID
	),0) as t_br14
	/*,--dtt.date,
	case when dtt.date=@date_rep then 
	convert(decimal(15,2),isnull(sum(case when DATEPART(hour, dtt.Begin_Time) > 0 then dtt.PlanUE else 0 end),0)) as [Талонов],
	convert(decimal(15,2),isnull(sum(case when DATEPART(hour, dtt.Begin_Time) > 0 and x_Datetime>dateadd(day,-14,dtt.date) then dtt.PlanUE else 0 end),0)) as [Талонов1]
*/from hlt_DocPRVD WITH(NOLOCK)
inner join hlt_LPUDoctor  WITH(NOLOCK)on LPUDoctorID=hlt_DocPRVD.rf_LPUDoctorID
inner join oms_PRVS  WITH(NOLOCK)on PRVSID=hlt_DocPRVD.rf_PRVSID
inner join oms_Department dept  WITH(NOLOCK)on DepartmentID=hlt_DocPRVD.rf_DepartmentID
inner join oms_lpu   WITH(NOLOCK) on dept.rf_LPUID=oms_lpu.LPUID and LPUID>0
where DocPRVDID>0 and LPUDoctorID>0
)t
where tall>0
--order by lpu,[Специализация],[ФИОВрача]
end
go

