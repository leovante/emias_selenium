CREATE VIEW [V_stt_OperationType] AS SELECT 
[hDED].[OperationTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Name] as [Name], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_OperationType] as [hDED]
go

