CREATE VIEW [V_stt_PatientsDiaries] AS SELECT 
[hDED].[PatientsDiariesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[jT_stt_MigrationPatient].[rf_StationarBranchID] as [SILENT_rf_MigrationPatientID], 
[hDED].[Date] as [Date], 
[hDED].[Note] as [Note], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [stt_PatientsDiaries] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [stt_MigrationPatient] as [jT_stt_MigrationPatient] on [jT_stt_MigrationPatient].[MigrationPatientID] = [hDED].[rf_MigrationPatientID]
go

