CREATE VIEW [V_stt_BedAction] AS SELECT 
[hDED].[BedActionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PatientID] as [rf_PatientID], 
[jT_hlt_Patient].[FAMILY] as [SILENT_rf_PatientID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[hDED].[rf_BedID] as [rf_BedID], 
[hDED].[rf_ActionTypeID] as [rf_ActionTypeID], 
[hDED].[rf_MedStageID] as [rf_MedStageID], 
[hDED].[Date] as [Date], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [stt_BedAction] as [hDED]
INNER JOIN [hlt_Patient] as [jT_hlt_Patient] on [jT_hlt_Patient].[PatientID] = [hDED].[rf_PatientID]
go

