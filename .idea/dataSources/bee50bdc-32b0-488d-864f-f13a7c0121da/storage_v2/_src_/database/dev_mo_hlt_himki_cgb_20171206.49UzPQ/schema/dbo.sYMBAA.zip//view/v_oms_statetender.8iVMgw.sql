CREATE VIEW [V_oms_StateTender] AS SELECT 
[hDED].[StateTenderID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[StateTender_Code] as [StateTender_Code], 
[hDED].[StateTender_Name] as [StateTender_Name], 
[hDED].[GUIDStateTender] as [GUIDStateTender]
FROM [oms_StateTender] as [hDED]
go

