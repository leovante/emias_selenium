CREATE VIEW [V_dd_ServiceDependence] AS SELECT 
[hDED].[ServiceDependenceID], [hDED].[x_Edition], [hDED].[x_Status], 
((select 
CASE DatePartType
WHEN 0  THEN 'Минута'
WHEN 1 THEN 'Час'
WHEN 2 THEN 'День'
END)) as [V_DatePartType], 
[hDED].[rf_CategoryServiceID] as [rf_CategoryServiceID], 
[jT_dd_CategoryService].[V_DDServiceName] as [SILENT_rf_CategoryServiceID], 
[hDED].[rf_DependsOnID] as [rf_DependsOnID], 
[jT_dd_CategoryService1].[V_DDServiceName] as [SILENT_rf_DependsOnID], 
[hDED].[rf_CategoryServiceUGUID] as [rf_CategoryServiceUGUID], 
[hDED].[rf_DependsOnCategoryServiceUGUID] as [rf_DependsOnCategoryServiceUGUID], 
[hDED].[DatePartType] as [DatePartType], 
[hDED].[DatePartValue] as [DatePartValue], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [dd_ServiceDependence] as [hDED]
INNER JOIN [V_dd_CategoryService] as [jT_dd_CategoryService] on [jT_dd_CategoryService].[CategoryServiceID] = [hDED].[rf_CategoryServiceID]
INNER JOIN [V_dd_CategoryService] as [jT_dd_CategoryService1] on [jT_dd_CategoryService1].[CategoryServiceID] = [hDED].[rf_DependsOnID]
go

