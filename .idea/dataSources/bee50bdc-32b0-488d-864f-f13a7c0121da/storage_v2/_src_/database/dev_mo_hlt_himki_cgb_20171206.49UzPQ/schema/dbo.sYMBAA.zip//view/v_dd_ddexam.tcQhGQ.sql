CREATE VIEW [V_dd_DDExam] AS SELECT 
[hDED].[DDExamID], [hDED].[x_Edition], [hDED].[x_Status], 
(((Select DDServiceName from dd_DDService
where dd_DDService.UGUID=rf_DDServiceGUID))) as [V_DDServiceName], 
(case when SanResort=1 then 'Да' else 'Нет' end) as [V_SanResort], 
((case when Lechenie=1 then 'Да' else 'Нет' end)) as [V_Lechenie], 
((case when DopDiagnIssl=1 then 'Да' else 'Нет' end)) as [V_DopDiagnIssl], 
((case when SpecVisokoTehnHelp=1 then 'Да' else 'Нет' end)) as [V_SpecVisokoTehnHelp], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_DocInfo], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_HealthGroupGUID] as [rf_HealthGroupGUID], 
[hDED].[rf_LPUDoctorGUID] as [rf_LPUDoctorGUID], 
[hDED].[rf_SMTAPID] as [rf_SMTAPID], 
[jT_hlt_SMTAP].[REG_S] as [SILENT_rf_SMTAPID], 
[hDED].[rf_SMTAPGuid] as [rf_SMTAPGuid], 
[hDED].[rf_SportGroupID] as [rf_SportGroupID], 
[hDED].[rf_DDFormID] as [rf_DDFormID], 
[hDED].[rf_DDFormGUID] as [rf_DDFormGUID], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[hDED].[rf_DDServiceGUID] as [rf_DDServiceGUID], 
[hDED].[rf_DDChildFormID] as [rf_DDChildFormID], 
[jT_dd_DDChildForm].[v_FIO] as [SILENT_rf_DDChildFormID], 
[hDED].[rf_CategoryServiceID] as [rf_CategoryServiceID], 
[hDED].[Recomendations] as [Recomendations], 
[hDED].[DDExamGUID] as [DDExamGUID], 
[hDED].[DateExam] as [DateExam], 
[hDED].[SanResort] as [SanResort], 
[hDED].[RowID] as [RowID], 
[hDED].[IsOtkaz] as [IsOtkaz], 
[hDED].[OtkazDate] as [OtkazDate], 
[hDED].[StatusRecord] as [StatusRecord], 
[hDED].[IsOtherLPU] as [IsOtherLPU], 
[hDED].[AddInfo] as [AddInfo], 
[hDED].[Lechenie] as [Lechenie], 
[hDED].[DopDiagnIssl] as [DopDiagnIssl], 
[hDED].[SpecVisokoTehnHelp] as [SpecVisokoTehnHelp]
FROM [dd_DDExam] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[UGUID] = [hDED].[rf_LPUDoctorGUID]
INNER JOIN [hlt_SMTAP] as [jT_hlt_SMTAP] on [jT_hlt_SMTAP].[SMTAPID] = [hDED].[rf_SMTAPID]
INNER JOIN [V_dd_DDChildForm] as [jT_dd_DDChildForm] on [jT_dd_DDChildForm].[DDChildFormID] = [hDED].[rf_DDChildFormID]
go

