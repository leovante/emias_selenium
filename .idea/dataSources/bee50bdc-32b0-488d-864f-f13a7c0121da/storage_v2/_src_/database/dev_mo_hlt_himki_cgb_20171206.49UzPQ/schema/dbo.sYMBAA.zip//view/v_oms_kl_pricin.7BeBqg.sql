CREATE VIEW [V_oms_kl_Pricin] AS SELECT 
[hDED].[kl_PricinID], [hDED].[x_Edition], [hDED].[x_Status], 
((Code)) as [V_KL_PricinCode], 
[hDED].[Kod] as [Kod], 
[hDED].[Opis] as [Opis], 
[hDED].[Code] as [Code], 
[hDED].[date_b] as [date_b], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_Pricin] as [hDED]
go

