CREATE VIEW [V_web_ValidationQueryType] AS SELECT 
[hDED].[ValidationQueryTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Guid] as [Guid], 
[hDED].[Code] as [Code]
FROM [web_ValidationQueryType] as [hDED]
go

