CREATE VIEW [V_oms_SMExpertType] AS SELECT 
[hDED].[SMExpertTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[SankName] as [SankName], 
[hDED].[IDVID] as [IDVID], 
[hDED].[S_TIP] as [S_TIP], 
[hDED].[Rem] as [Rem], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_SMExpertType] as [hDED]
go

