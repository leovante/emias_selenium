CREATE VIEW [V_hlt_NotWorkDocPeriod] AS SELECT 
[hDED].[NotWorkDocPeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PRVDID] as [rf_PRVDID], 
[hDED].[rf_PR_VS_DocCloseID] as [rf_PR_VS_DocCloseID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_LPUDoctorVKID] as [rf_LPUDoctorVKID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_DocPRVDVkID] as [rf_DocPRVDVkID], 
[jT_hlt_DocPRVD1].[Name] as [SILENT_rf_DocPRVDVkID], 
[hDED].[rf_NotWorkDocID] as [rf_NotWorkDocID], 
[hDED].[BeginDate] as [BeginDate], 
[hDED].[EndDate] as [EndDate], 
[hDED].[DocCloseNWDS_FIO] as [DocCloseNWDS_FIO], 
[hDED].[PeriodNumber] as [PeriodNumber], 
[hDED].[KEK] as [KEK], 
[hDED].[DocCloseNWDS_PCOD] as [DocCloseNWDS_PCOD], 
[hDED].[Flag] as [Flag], 
[hDED].[DoctorPRVD] as [DoctorPRVD], 
[hDED].[DoctorVK_PRVD] as [DoctorVK_PRVD], 
[hDED].[DoctorVK_FIO] as [DoctorVK_FIO], 
[hDED].[GUID] as [GUID], 
[hDED].[isSignedDoc] as [isSignedDoc], 
[hDED].[isSignedVK] as [isSignedVK]
FROM [hlt_NotWorkDocPeriod] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD1] on [jT_hlt_DocPRVD1].[DocPRVDID] = [hDED].[rf_DocPRVDVkID]
go

