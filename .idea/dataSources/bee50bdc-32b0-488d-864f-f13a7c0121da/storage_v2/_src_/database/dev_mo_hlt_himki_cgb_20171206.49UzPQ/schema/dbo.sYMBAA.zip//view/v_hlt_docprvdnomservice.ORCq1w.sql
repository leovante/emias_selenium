CREATE VIEW [V_hlt_DocPrvdNomService] AS SELECT 
[hDED].[DocPrvdNomServiceID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_kl_NomServiceID] as [rf_kl_NomServiceID], 
[hDED].[Flags] as [Flags]
FROM [hlt_DocPrvdNomService] as [hDED]
go

