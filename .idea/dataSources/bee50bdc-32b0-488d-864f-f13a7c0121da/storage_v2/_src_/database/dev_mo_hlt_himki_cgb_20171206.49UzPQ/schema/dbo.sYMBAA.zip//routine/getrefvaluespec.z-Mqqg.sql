
CREATE  PROCEDURE [dbo].[GetRefValueSpec]
	@txt varchar(250), --искомое поле (ссылочное)
	@dtdid int,   -- ид доктипа, к которому относится поле
	@id	varchar(50),   -- идентификатор текущего объекта доктипа
	@Result varchar(max) output	,	
	@linkedDEDID int = 0 output -- является ли ссылочным
AS
BEGIN

	DECLARE @ResultVar varchar(max)
	DECLARE @ResultRefDT varchar(max)	-- гуид доктипа сущности для ссылочного поля

	DECLARE @selElem varchar(1000)
	DECLARE @ElemCollection varchar(1000)
	DECLARE @name NVARCHAR(255)
    DECLARE @pos INT	
	DECLARE @cnt INT	
	DECLARE @newDTDID int
	
	DECLARE @dtFormat varchar(10)
	SET @dtFormat = ''
	SET @selElem = ''
	SET @ElemCollection= @txt+'.'
	SET @ResultRefDT=''
	
	

	WHILE CHARINDEX('.', @ElemCollection) > 0
		BEGIN
		SELECT @pos  = CHARINDEX('.', @ElemCollection)  
		SELECT @name = SUBSTRING(@ElemCollection, 1, @pos-1)

		if (isnull((select top 1 ValueType from x_docElemDef WHERE DocTypeDefID = @dtdid AND FieldName = @name), 0) = 5)
			SET @dtFormat = ', 104'
		ELSE  SET @dtFormat = ''
	
		if @selElem=''		
			SET @selElem=' convert(varchar(max), ' + @name + @dtFormat + ') '		
		ELSE		
			SET @selElem=@selElem+' + ''###'' + convert(varchar(max), ' + @name + @dtFormat + ') '				

		SELECT @ElemCollection = SUBSTRING(@ElemCollection, @pos+1, LEN(@ElemCollection)-@pos)

		SET @newDTDID = 0
		SELECT @newDTDID = isnull(linkedDocTypeDefID,0) FROM x_docElemDef 
			WHERE DocTypeDefID = @dtdid AND FieldName = @name
		SET @ResultRefDT = @ResultRefDT + convert(varchar(50),@newDTDID) +'###'
	END
	
		SELECT @ResultRefDT = SUBSTRING(@ResultRefDT, 0, LEN(@ResultRefDT)-2)



	/* Имя таблицы, ПК */
	DECLARE @tbName varchar(50), @PKfldName varchar(50)	
	SELECT @tbName  = [headTable], @PKfldName=PK_Name from x_docTypeDef where docTypeDefID = @dtdid

	/* Команда выбора данных */
	DECLARE @cmd nvarchar(4000)	
    SET @cmd = 'select @res1='+@selElem+'  from ' + @tbName + ' where '
	IF (@tbName = 'hlt_TAP' and @PKfldName = 'TAPID')	
		SET @cmd =  @cmd +   @PKfldName + '  = ' + @id 	
	ELSE IF (@tbName = 'hlt_MKAB' and @PKfldName = 'MKABID')	
		SET @cmd =  @cmd + @PKfldName + '  = ' + @id 	 
	ELSE	
		SET @cmd =  @cmd + ' cast(' +  @PKfldName + ' as varchar(50))  = ''' + @id + ''''		

	EXEC sp_executesql @cmd, N'@res1 varchar(255) out', @res1 = @ResultVar out 	

	/*Выбирали значение поля */
	SET @Result =@ResultRefDT+'#$#'+ @ResultVar
	RETURN 0
END
go

