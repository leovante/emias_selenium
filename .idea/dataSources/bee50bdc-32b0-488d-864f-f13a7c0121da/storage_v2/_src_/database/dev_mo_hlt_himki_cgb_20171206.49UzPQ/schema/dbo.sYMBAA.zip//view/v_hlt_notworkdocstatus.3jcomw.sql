CREATE VIEW [V_hlt_NotWorkDocStatus] AS SELECT 
[hDED].[NotWorkDocStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[COD] as [COD], 
[hDED].[NAME] as [NAME]
FROM [hlt_NotWorkDocStatus] as [hDED]
go

