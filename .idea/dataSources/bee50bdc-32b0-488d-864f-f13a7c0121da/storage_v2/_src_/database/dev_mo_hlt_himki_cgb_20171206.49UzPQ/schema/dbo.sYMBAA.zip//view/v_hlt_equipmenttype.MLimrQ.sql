CREATE VIEW [V_hlt_EquipmentType] AS SELECT 
[hDED].[EquipmentTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_EquipmentType] as [hDED]
go

