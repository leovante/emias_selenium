CREATE VIEW [V_hlt_SportGroup] AS SELECT 
[hDED].[SportGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags]
FROM [hlt_SportGroup] as [hDED]
go

