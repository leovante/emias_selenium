CREATE VIEW [V_dd_DDHealthIndexDataType] AS SELECT 
[hDED].[DDHealthIndexDataTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[DataTypeName] as [DataTypeName], 
[hDED].[Flag] as [Flag], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DataTypeCode] as [DataTypeCode]
FROM [dd_DDHealthIndexDataType] as [hDED]
go

