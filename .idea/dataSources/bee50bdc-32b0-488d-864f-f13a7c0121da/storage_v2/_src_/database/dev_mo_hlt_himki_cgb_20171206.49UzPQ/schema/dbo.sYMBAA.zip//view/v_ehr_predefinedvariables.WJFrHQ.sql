CREATE VIEW [V_ehr_PredefinedVariables] AS SELECT 
[hDED].[PredefinedVariablesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TemplateID] as [rf_TemplateID], 
[hDED].[Guid] as [Guid], 
[hDED].[Caption] as [Caption], 
[hDED].[Variable] as [Variable], 
[hDED].[Type] as [Type]
FROM [ehr_PredefinedVariables] as [hDED]
go

