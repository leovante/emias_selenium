CREATE VIEW [V_hlt_UchastokMkabPosition] AS SELECT 
[hDED].[UchastokMkabPositionID], [hDED].[x_Edition], [hDED].[x_Status], 
(isnull((select rtrim(ltrim(family + ' ' + name + ' ' + ot)) from hlt_MKAB where MKABID = [jT_hlt_UchastokMKAB].rf_MKABID), '')) as [V_FIO], 
(isnull((select rtrim(ltrim(UchastoCaption)) from hlt_Uchastok where UchastokID = [jT_hlt_UchastokMKAB].rf_UchastokID), '')) as [V_Uchastok], 
(isnull((select '[' + ltrim(rtrim(PCOD)) + '] '+ 
Upper(substring(ltrim(FAM_V), 1, 1))+ CASE WHEN 
LEN(FAM_V) > 0  THEN 
LOWER(SUBSTRING(LTRIM(RTRIM(FAM_V)), 2, 
LEN(LTRIM(RTRIM(FAM_V))) - 1))  ELSE '' END + ' '  + 
Upper(substring(ltrim(IM_V), 1, 1)) + '. ' + 
Upper(substring(ltrim(OT_V), 1, 1)) + '.' from hlt_LPUDoctor join hlt_Uchastok u on u.rf_LPUDoctorID = LPUDoctorID where UchastokID = [jT_hlt_UchastokMKAB].rf_UchastokID), '')) as [V_DocInfo], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[jT_oms_SMCriterion].[SMCriterionCaption] as [SILENT_rf_SMCriterionID], 
[hDED].[rf_UchastokMKABID] as [rf_UchastokMKABID], 
[jT_hlt_UchastokMKAB].[V_FIO] as [SILENT_rf_UchastokMKABID], 
[hDED].[rf_UchastokMkabReestrID] as [rf_UchastokMkabReestrID], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags]
FROM [hlt_UchastokMkabPosition] as [hDED]
INNER JOIN [oms_SMCriterion] as [jT_oms_SMCriterion] on [jT_oms_SMCriterion].[SMCriterionID] = [hDED].[rf_SMCriterionID]
INNER JOIN [V_hlt_UchastokMKAB] as [jT_hlt_UchastokMKAB] on [jT_hlt_UchastokMKAB].[UchastokMKABID] = [hDED].[rf_UchastokMKABID]
go

