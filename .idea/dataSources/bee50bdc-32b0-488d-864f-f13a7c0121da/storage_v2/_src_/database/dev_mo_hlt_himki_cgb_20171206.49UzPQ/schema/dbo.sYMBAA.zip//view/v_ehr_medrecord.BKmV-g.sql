CREATE VIEW [V_ehr_MedRecord] AS SELECT 
[hDED].[MedRecordID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TemplateID] as [rf_TemplateID], 
[hDED].[Guid] as [Guid], 
[hDED].[rf_DoctorId] as [rf_DoctorId], 
[hDED].[rf_DoctorTypeGuid] as [rf_DoctorTypeGuid], 
[hDED].[Signed] as [Signed], 
[hDED].[Signature] as [Signature], 
[hDED].[CRC] as [CRC], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[SignedDate] as [SignedDate], 
[hDED].[InputData] as [InputData], 
[hDED].[ResultData] as [ResultData], 
[hDED].[rf_GlobalTemplateGuid] as [rf_GlobalTemplateGuid], 
[hDED].[EventDate] as [EventDate], 
[hDED].[rf_EventId] as [rf_EventId], 
[hDED].[rf_EventTypeGuid] as [rf_EventTypeGuid], 
[hDED].[rf_PatientId] as [rf_PatientId], 
[hDED].[rf_PatientTypeGuid] as [rf_PatientTypeGuid], 
[hDED].[IsUpload] as [IsUpload], 
[hDED].[rf_EventGuid] as [rf_EventGuid], 
[hDED].[rf_PatientGuid] as [rf_PatientGuid]
FROM [ehr_MedRecord] as [hDED]
go

