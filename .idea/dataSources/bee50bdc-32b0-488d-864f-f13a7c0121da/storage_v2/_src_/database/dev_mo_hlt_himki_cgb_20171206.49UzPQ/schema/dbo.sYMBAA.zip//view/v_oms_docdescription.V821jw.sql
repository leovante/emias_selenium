CREATE VIEW [V_oms_DocDescription] AS SELECT 
[hDED].[DocDescriptionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[NameTable] as [NameTable], 
[hDED].[NameType] as [NameType]
FROM [oms_DocDescription] as [hDED]
go

