
CREATE FUNCTION GetCatalogValue 
(
	@OID VARCHAR(100),
	@InternalCode VARCHAR(30),
	@DefaultName VARCHAR(100)
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	RETURN ISNULL((SELECT C.NameNSI
								FROM hl7_CatalogValue C
							JOIN hl7_Catalog H ON H.UGUID = C.rf_CatalogGUID
								WHERE H.OID = @OID
							AND C.InternalCode = @InternalCode)
					,@DefaultName)
END
go

