CREATE VIEW [V_lbr_ResearchParamValues] AS SELECT 
[hDED].[ResearchParamValuesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResearchTypeParamUGUID] as [rf_ResearchTypeParamUGUID], 
[hDED].[Value] as [Value]
FROM [lbr_ResearchParamValues] as [hDED]
go

