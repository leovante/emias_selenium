CREATE VIEW [V_hlt_UchastokMKAB] AS SELECT 
[hDED].[UchastokMKABID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_Uchastok].[UchastoCaption] as [V_UchastokName], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_UchastokID] as [rf_UchastokID], 
[jT_hlt_Uchastok].[CODE] as [SILENT_rf_UchastokID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_TypeAttachmentID] as [rf_TypeAttachmentID], 
[jT_hlt_TypeAttachment].[Name] as [SILENT_rf_TypeAttachmentID], 
[hDED].[rf_DetachReasonID] as [rf_DetachReasonID], 
[hDED].[DateIn] as [DateIn], 
[hDED].[DateOut] as [DateOut], 
[hDED].[isDetach] as [isDetach], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_UchastokMKAB] as [hDED]
INNER JOIN [hlt_Uchastok] as [jT_hlt_Uchastok] on [jT_hlt_Uchastok].[UchastokID] = [hDED].[rf_UchastokID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_TypeAttachment] as [jT_hlt_TypeAttachment] on [jT_hlt_TypeAttachment].[TypeAttachmentID] = [hDED].[rf_TypeAttachmentID]
go

