CREATE VIEW [V_hlt_MKABSheetFinalDS] AS SELECT 
[hDED].[MKABSheetFinalDSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[PCOD] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_MKABSheetFinalDSSpecifiedID] as [rf_MKABSheetFinalDSSpecifiedID], 
[hDED].[DateFinalDS] as [DateFinalDS], 
[hDED].[FirstSetDS] as [FirstSetDS], 
[hDED].[SetFirstResearch] as [SetFirstResearch]
FROM [hlt_MKABSheetFinalDS] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
go

