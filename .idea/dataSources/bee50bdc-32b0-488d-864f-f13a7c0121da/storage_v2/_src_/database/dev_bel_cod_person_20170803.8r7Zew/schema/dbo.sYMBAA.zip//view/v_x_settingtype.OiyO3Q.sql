CREATE VIEW [dbo].[V_x_SettingType] AS SELECT 
[hDED].[SettingTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Caption] as [Caption]
FROM [x_SettingType] as [hDED]
go

