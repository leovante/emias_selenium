CREATE VIEW [V_stt_UseSOHardware] AS SELECT 
[hDED].[UseSOHardwareID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SurgicalOperationID] as [rf_SurgicalOperationID], 
[hDED].[rf_SurgOperationhardwareID] as [rf_SurgOperationhardwareID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag]
FROM [stt_UseSOHardware] as [hDED]
go

