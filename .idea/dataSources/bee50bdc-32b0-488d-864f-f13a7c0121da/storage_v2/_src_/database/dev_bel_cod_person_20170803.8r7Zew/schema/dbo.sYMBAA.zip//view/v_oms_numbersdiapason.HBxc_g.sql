CREATE VIEW [V_oms_NumbersDiapason] AS SELECT 
[hDED].[NumbersDiapasonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[dt_input] as [dt_input], 
[hDED].[series] as [series], 
[hDED].[msg_text] as [msg_text], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[num_begin] as [num_begin], 
[hDED].[num_end] as [num_end]
FROM [oms_NumbersDiapason] as [hDED]
go

