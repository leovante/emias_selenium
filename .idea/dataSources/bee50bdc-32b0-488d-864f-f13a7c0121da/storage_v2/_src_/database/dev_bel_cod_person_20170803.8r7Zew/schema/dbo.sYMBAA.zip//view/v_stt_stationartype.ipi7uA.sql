CREATE VIEW [V_stt_StationarType] AS SELECT 
[hDED].[StationarTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_CalculateMethodID] as [rf_CalculateMethodID], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [stt_StationarType] as [hDED]
go

