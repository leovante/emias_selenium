CREATE VIEW [V_stt_FamilyTies] AS SELECT 
[hDED].[FamilyTiesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [stt_FamilyTies] as [hDED]
go

