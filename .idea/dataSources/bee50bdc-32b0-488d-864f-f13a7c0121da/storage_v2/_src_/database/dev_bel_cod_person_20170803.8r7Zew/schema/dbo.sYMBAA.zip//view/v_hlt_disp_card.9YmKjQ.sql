CREATE VIEW [V_hlt_disp_Card] AS SELECT 
[hDED].[disp_CardID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MkabGuid] as [rf_MkabGuid], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MkabGuid], 
[hDED].[rf_DispTypeGuid] as [rf_DispTypeGuid], 
[jT_hlt_disp_Type].[Name] as [SILENT_rf_DispTypeGuid], 
[hDED].[rf_MainCardGuid] as [rf_MainCardGuid], 
[jT_hlt_disp_Card].[rf_MkabGuid] as [SILENT_rf_MainCardGuid], 
[hDED].[DateOpen] as [DateOpen], 
[hDED].[DateClose] as [DateClose], 
[hDED].[IsClosed] as [IsClosed], 
[hDED].[IsOtkaz] as [IsOtkaz], 
[hDED].[DateAccept] as [DateAccept], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Number] as [Number], 
[hDED].[DopPriznak] as [DopPriznak]
FROM [hlt_disp_Card] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[UGUID] = [hDED].[rf_MkabGuid]
INNER JOIN [hlt_disp_Type] as [jT_hlt_disp_Type] on [jT_hlt_disp_Type].[Guid] = [hDED].[rf_DispTypeGuid]
INNER JOIN [hlt_disp_Card] as [jT_hlt_disp_Card] on [jT_hlt_disp_Card].[Guid] = [hDED].[rf_MainCardGuid]
go

