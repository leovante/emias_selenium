
CREATE FUNCTION GetCatalogCode 
(
	@OID VARCHAR(100),
	@InternalCode VARCHAR(100),
	@DefaultCode VARCHAR(30)
)
RETURNS VARCHAR(30)
AS
BEGIN
	RETURN ISNULL((SELECT C.CodeNSI
								FROM hl7_CatalogValue C
							JOIN hl7_Catalog H ON H.UGUID = C.rf_CatalogGUID
									WHERE H.OID = @OID
							AND C.InternalCode = @InternalCode)
					,@DefaultCode)
END
go

