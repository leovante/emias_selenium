
CREATE FUNCTION GetCatalogOID 
(
	@OID VARCHAR(100),
	@InternalCode VARCHAR(100),
	@DefaultOID VARCHAR(100)
)
RETURNS VARCHAR(100)
AS
BEGIN
	RETURN ISNULL((SELECT C.OID
								FROM hl7_CatalogValue C
							JOIN hl7_Catalog H ON H.UGUID = C.rf_CatalogGUID
									WHERE H.OID = @OID
								AND C.InternalCode = @InternalCode)
					,@DefaultOID)
END
go

