CREATE VIEW [V_stt_HospPeriod] AS SELECT 
[hDED].[HospPeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flag] as [Flag]
FROM [stt_HospPeriod] as [hDED]
go

