CREATE PROCEDURE [dbo].ras_StartUp
	-- Add the parameters for the stored procedure here
AS	
begin
-- RefreshDateInput
	begin tran tran1
		update ras_StoredLS
		set Data=t.date
		from 
		(select StoredLSID, HostStoredLSID,min(TransactDateTimeOperation) as Date
		from ras_StoredLS st
			left join ras_TransactJournal tr on 
			  tr.rf_StoredLSID=st.StoredLSID and tr.rf_StoredLSIDHost=st.HostStoredLSID
		where bInput=1
		group by StoredLSID, HostStoredLSID
		--order by StoredLSID,TransactDateTimeOperation
		) t
		where ras_StoredLS.StoredLSID = t.StoredLSID 
		and ras_StoredLS.HostStoredLSID = t.HostStoredLSID
	commit tran tran1
-- RefreshSummNDS
	begin tran tran2
		--ras_StoredLS
		update ras_StoredLS
		set SumNDS=Summa*t.Rate/(1+t.Rate)
		from 
		(
		   select StoredLSID,Rate
		   from ras_StoredLS t
			  inner join ras_NDS nds on t.rf_NDSID=nds.NDSID
		) t
		where t.StoredLSID = ras_StoredLS.StoredLSID

		--dbo.ras_PositionBill
		update ras_PositionBill
		set SumNDS=Summa*t.Rate/(1+t.Rate) 
		from 
		(
		   select PositionBillID,Rate
		   from ras_PositionBill t
			  inner join ras_NDS nds on t.rf_NDSID=nds.NDSID
		) t
		where t.PositionBillID = ras_PositionBill.PositionBillID


		--dbo.ras_PositionBillEx
		update ras_PositionBillEx
		set SumNDS=Summa*t.Rate/(1+t.Rate)  
		from 
		(
		   select PositionBillExID,Rate
		   from ras_PositionBillEx t
			  inner join ras_NDS nds on t.rf_NDSID=nds.NDSID
		) t
		where t.PositionBillExID = ras_PositionBillEx.PositionBillExID

		--dbo.ras_PositionBillReturnCL
		update ras_PositionBillReturnCL
		set SumNDS=Summa*t.Rate/(1+t.Rate) 
		from 
		(
		   select PositionBillReturnCLID,Rate
		   from ras_PositionBillReturnCL t
			  inner join ras_NDS nds on t.rf_NDSID=nds.NDSID
		) t
		where t.PositionBillReturnCLID = ras_PositionBillReturnCL.PositionBillReturnCLID

		--dbo.ras_PositionBillReturnPr
		update ras_PositionBillReturnPr
		set SumNDS=Summa*t.Rate/(1+t.Rate)
		from 
		(
		   select PositionBillReturnPrID,Rate
		   from ras_PositionBillReturnPr t
			  inner join ras_NDS nds on t.rf_NDSID=nds.NDSID
		) t
		where t.PositionBillReturnPrID = ras_PositionBillReturnPr.PositionBillReturnPrID
		--dbo.ras_PositionBillShift
		update ras_PositionBillShift
		set SumNDS=Summa*t.Rate/(1+t.Rate)
		from 
		(
		   select PositionBillShiftID,Rate
		   from ras_PositionBillShift t
			  inner join ras_NDS nds on t.rf_NDSID=nds.NDSID
		) t
		where t.PositionBillShiftID = ras_PositionBillShift.PositionBillShiftID
	commit tran tran2	
-- DeleteFRes	
	begin tran tran3
		delete from ras_PositionBillEx
		where PositionBillExID>0 and rf_BillExtractedID 
		 not in (
		select BillExtractedID
		from  ras_BillExtracted
		where BillExtractedID > 0 
		)

		delete from ras_PositionWriteOffArticle
		where PositionWriteOffArticleID>0 and  rf_WriteOffArticleID 
		 not in (
		select WriteOffArticleID
		from  ras_WriteOffArticle
		where WriteOffArticleID>0
		)

		delete from ras_PositionBillReturnPr
		where PositionBillReturnPrID>0 and rf_BillReturnProviderID
		 not in (
		select BillReturnProviderID
		from  ras_BillReturnProvider
		where BillReturnProviderID>0
		)

		delete from ras_PositionBillReturnCl
		where PositionBillReturnClID>0 and rf_BillReturnClientID
		 not in (
		select BillReturnClientID
		from  ras_BillReturnClient
		where BillReturnClientID>0
		)

		delete from ras_PositionBillRevaluation
		where PositionBillRevaluationID>0 and  rf_BillRevaluationID
		 not in (
		select BillRevaluationID
		from  ras_BillRevaluation
		where BillRevaluationID>0
		)

		----------------------------------------------------------------
		update ras_Reserve
		set rf_PositionID = rf_PositionBillExID
		where rf_DocDescriptionID = 4
		 and rf_PositionID <= 0 
		 and rf_PositionBillExID > 0

		update ras_Reserve
		set rf_PositionID = rf_PositionWriteOffArticleID
		where rf_DocDescriptionID = 6
		 and rf_PositionID <= 0 
		 and rf_PositionWriteOffArticleID > 0

		update ras_Reserve
		set rf_PositionID = rf_PositionBillReturnPrID
		where rf_DocDescriptionID = 10
		 and rf_PositionID <= 0 
		 and rf_PositionBillReturnPrID > 0

		----------------------------------------------------------------
		delete from ras_Reserve
		where (rf_PositionBillExID < 0 
		 or rf_PositionWriteOffArticleID < 0
		 or rf_PositionBillReturnPrID < 0
		 or rf_PositionID<0)
		and ReserveID>0

		----------------------------------------------------------------


		delete from ras_Reserve
		where rf_DocDescriptionID = 4  and 
		  rf_PositionID
		 not in (
		select PositionBillExID
		from ras_PositionBillEx
		where PositionBillExID>0
		)

		delete from ras_Reserve
		where rf_DocDescriptionID = 6 and rf_PositionID
		 not in (
		select PositionWriteOffArticleID
		from ras_PositionWriteOffArticle
		where PositionWriteOffArticleID>0
		)

		delete from ras_Reserve
		where rf_DocDescriptionID = 10 and rf_PositionID
		 not in (
		select PositionBillReturnPrID
		from ras_PositionBillReturnPr
		where PositionBillReturnPrID>0
		)

		delete from ras_Reserve
		where rf_DocDescriptionID = 11 and rf_PositionID
		 not in (
		select PositionBillReturnClID
		from ras_PositionBillReturnCl
		where PositionBillReturnClID>0
		)


		
		delete from ras_Reserve
		where rf_DocDescriptionID = 12 and rf_PositionID
		 not in (
		select PositionBillRevaluationID
		from ras_PositionBillRevaluation
		where PositionBillRevaluationID>0
		)
				
		update ras_Reserve
        set rf_PositionIDHost = dbo.GetSelfHost()
        where ReserveID>0
        
        delete from ras_Reserve
        where ReserveID in 
        (
		  select ReserveID
		  from ras_Reserve
		  where  convert(varchar,rf_PositionID) + convert(varchar,rf_DocDescriptionID) in (

		  select convert(varchar,rf_PositionID) + convert(varchar,rf_DocDescriptionID)
	      from ras_Reserve
		  where ReserveID>0
		  group by rf_PositionID,rf_DocDescriptionID
		  having count(*)>1

		  )
		
        ) and ReserveID not in 
        (
		   select top 1 ReserveID
		   from ras_Reserve
		   where  convert(varchar,rf_PositionID) + convert(varchar,rf_DocDescriptionID) in (

		   select convert(varchar,rf_PositionID) + convert(varchar,rf_DocDescriptionID)
		   from ras_Reserve
		   where ReserveID>0
		   group by rf_PositionID,rf_DocDescriptionID
		   having count(*)>1

		   )
		 order by rf_PositionID
         )
	commit tran tran3
	
-- UpdateBillOther
	begin tran tran4
		update ras_BillEx_Other
		set rf_DocDescriptionID = 3
		where BillEx_OtherID>0
	commit tran tran4
-- RefreshStoredLS
	begin tran tran5
		/*
		Автор: Ганичев Р.А.
		Дата: 26.06.2008
		*/
		/* подчищаем позиции транзакжурнала для записей, у которых есть запись в отчете комитента, а ссылка на не действующий рецепт */
		delete 
		FROM ras_TransactJournal
		where rf_DocDescriptionID=13 and 
		PositionID in (
		SELECT positionRTCID 
		FROM ras_PositionRTC
		inner join oms_PharmacyRecipe on rf_PharmacyRecipeID=PharmacyRecipeID
		where 

		oms_PharmacyRecipe.recipeGUID ='00000000-0000-0000-0000-000000000000'
		)

		/* подчищаем позиции транзакжурнала для записей, у которых есть запись в отчете комитента, а ссылка на не существующий рецепт */
		delete 

		FROM ras_TransactJournal
		where rf_DocDescriptionID=13 and 
		PositionID in (
		SELECT positionRTCID 
		FROM ras_PositionRTC
		where rf_PharmacyRecipeID not in
		(SELECT PharmacyRecipeID FROM oms_PharmacyRecipe)
		)

		/* удаляем позиции отчета комитенту, у которых ссылка на не действующий рецепт */
		delete 

		FROM ras_PositionRTC
		where positionRTCID in (
		SELECT positionRTCID
		FROM ras_PositionRTC
		inner join oms_PharmacyRecipe on rf_PharmacyRecipeID=PharmacyRecipeID
		where 
		oms_PharmacyRecipe.recipeGUID ='00000000-0000-0000-0000-000000000000'
		)
		/* удаляем позиции отчета комитенту, у которых ссылка на не существующий рецепт */
		delete 

		FROM ras_PositionRTC
		where positionRTCID in (
		SELECT positionRTCID 
		FROM ras_PositionRTC
		where rf_PharmacyRecipeID not in
		(SELECT PharmacyRecipeID FROM oms_PharmacyRecipe)
		)


		/*подчищаем  позиции транзакжурнала для записей, у которых есть запись в отчете комитента, а ссылка на не действующий рецепт  */
		delete 
		FROM ras_TransactJournal
		where rf_DocDescriptionID=13 and  
		PositionID in (
		SELECT positionRTCID
		  FROM ras_PositionRTC
		inner join oms_PharmacyRecipe  on rf_PharmacyRecipeID=PharmacyRecipeID
		where 
		statusedition=1)

		/*удаляем позиции отчета комитенту, у которых ссылка на не действующий рецепт  */
		delete FROM ras_PositionRTC
		where positionRTCID in (
		SELECT positionRTCID
		  FROM ras_PositionRTC
		inner join oms_PharmacyRecipe  on rf_PharmacyRecipeID=PharmacyRecipeID
		where 
		statusedition=1)

		/*возврат товара на склад - происходит автоматически, при первом же запуске программы (пересчет остатков)*/



		UPDATE [ras_StoredLS]
		   SET [Count] = st.[count]
		 from 
		(
		select st.StoredLSID as [id], st.HostStoredLSID as host, sum(isnull(tr.Count,0)) as [count]
		from [ras_StoredLS] st
		 left join ras_TransactJournal tr ON tr.rf_StoredLSID = st.StoredLSID
		group by st.StoredLSID, st.HostStoredLSID
		) st
		where st.[id]=[ras_StoredLS].[StoredLSID] and st.[host] = [ras_StoredLS].[HostStoredLSID]

		UPDATE [ras_StoredLS]
        SET   [Summa] = dbo.ras_CalcSumma(Count,Price),
              [SumNDS] =dbo.ras_CalcSumNds(Count,Price,ras_NDS.Rate),
              PriceBase = dbo.ras_CalcPriceBase(Price,ras_NDS.Rate)  
		from [ras_StoredLS] st
		 inner join ras_NDS on ras_NDS.NDSID=st.rf_NDSID
	commit tran tran5
-- RefreshExpDate
	begin tran tran6		
		-------------------------------------------------------------------------------------------------
		--PositionBillReturnCL
		update ras_PositionBillReturnCL
		set ExpDate = series.Date_E
		from 
		(
		select SeriesID,HostSeriesID , Date_E
		from ras_Series
		where SeriesID > 0
		) series
		where series.SeriesID = ras_PositionBillReturnCL.rf_SeriesID 
		   and series.HostSeriesID = ras_PositionBillReturnCL.rf_SeriesIDHost
		-------------------------------------------------------------------------------------------------
	commit tran tran6
end
go

