CREATE VIEW [V_stt_DisabilityCause] AS SELECT 
[hDED].[DisabilityCauseID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [stt_DisabilityCause] as [hDED]
go

