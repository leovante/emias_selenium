
------------------
------------------
-- =================================================================================
-- Author:		Ranzou
-- Create date: 30.04.2010
-- Description:	 Поиск различающихся полей
-- =================================================================================
CREATE PROCEDURE [dbo].[CheckFieldsUnivers] 
	@Table1 varchar (100),
	@Table2 varchar (100)
AS
BEGIN
	declare @Code varchar (100)/*oms таблица*/
	declare @IX varchar (MAX)/*поля с индексом по которым мы сравниваем таблицы*/
	declare @FName varchar (250)/*имя поля по которому просматриваем различия*/
	declare @FCapt varchar (250)/*заголовок этого поля*/
	declare @SQL nvarchar (MAX)
	declare @IXStr varchar (MAX)/*строка условия для конечного запроса,в которой учитываем количество полей с индексом*/
	declare @TCapt varchar (100)/*заголовок таблицы oms*/
	--получаем значения переменных по коду из oms_LoadNSITable
	select
	@Code=Code,
	@TCapt=Rem,
	@IX=key_oms
	from oms_LoadNSITable 
	where @Table1=Table_name
	--преобразеум строку полей с индексом к виду в кавычках
	set @IX=''''+Replace(@IX,',',''',''' )+''''
	set @IXStr=''
	--выбираем те поля с индексом из общего списка,которые содержатся в нашей строке
	if exists(select * from sys.all_objects where [name]='tmp_IX') drop table tmp_IX
	set @SQL='select [Name] into tmp_IX
			  from dbo.x_DocElemDef
		      where [Name] in ('+@IX+')
		      group by [Name]'
	--print @SQL
	execute sp_executesql @SQL
	--курсор для формирования строки условия для конечного запроса
	declare IXCursor cursor for
		select * from dbo.tmp_IX
	open IXCursor
		fetch next from IXCursor into @IX
			
	while @@FETCH_STATUS=0
	begin
		set @IXStr=@IXStr+' and '+@Table1+'.'+@IX+'='+@Table2+'.'+@IX+''/*с каждым проходом наращиеваем строку*/
		--print @IXStr
		fetch next from IXCursor into @IX
	end
	close IXCursor
	deallocate IXCursor
	
	if exists(select * from sys.all_objects where [name]='tmp_CheckFieldsUnivers') drop table tmp_CheckFieldsUnivers

	create table dbo.tmp_CheckFieldsUnivers(
	[Table] varchar (max),
	[Column] varchar (max),
	[Value 1]  varchar (max),
	[Value 2] varchar (max),
	[Count] int)

	--курсор для прохода по всем существующим полям для поиска несовпадающих 		
	declare ForEachCursor cursor for
		select dbo.x_DocElemDef.Name,dbo.x_DocElemDef.Caption
		from dbo.x_DocElemDef,dbo.x_DocTypeDef
		where dbo.x_DocElemDef.DocTypeDefID=dbo.x_DocTypeDef.DocTypeDefID
		and dbo.x_DocTypeDef.HeadTable=@Table1
		and dbo.x_DocElemDef.ElemType<3
		and dbo.x_DocElemDef.Name not in (select * from dbo.tmp_IX) /*учитываем что нам не нужно проверять индексные поля*/
			
	open ForEachCursor
	fetch next from ForEachCursor into @FName,@FCapt /*с каждым проходом записываем новые значения имени поля и заголовка в переменные*/  
	while @@FETCH_STATUS=0
	begin	--запрос формирует временную табличку с результатом поиска разнящихся полей
		set @SQL='insert into dbo.tmp_CheckFieldsUnivers
		select '''+@TCapt+''' as [Table],'''+@FCapt+''' as [Column],convert(varchar (250),'+@Table1+'.'+@FName+',104) as [Value 1],convert(varchar (250),'+@Table2+'.'+@FName+',104) as [Value 2],COUNT (*) as [Count]  
		from '+@Table1+','+@Table2+'
		where '+@Table1+'.'+@FName+'<>'+@Table2+'.'+@FName+'
		'+@IXStr+'
		group by '+@Table1+'.'+@FName+','+@Table2+'.'+@FName+''
		print @SQL
		execute sp_executesql @SQL	
		fetch next from ForEachCursor into @FName,@FCapt				
	end	
	close ForEachCursor
	deallocate ForEachCursor
	drop table dbo.tmp_IX	/*убираем временную табличку*/
END
go

