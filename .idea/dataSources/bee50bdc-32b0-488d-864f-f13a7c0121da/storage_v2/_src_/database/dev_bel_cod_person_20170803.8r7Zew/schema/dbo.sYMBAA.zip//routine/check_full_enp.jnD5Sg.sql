CREATE PROCEDURE CHECK_FULL_ENP 
	-- Add the parameters for the stored procedure here
	@enp varchar(50), 
	@birthdate datetime output	,	
	@sex varchar(1) output	
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE   @y int
 DECLARE @m int
 DECLARE @d int
 DECLARE @s varchar(20)
 DECLARE @res int
set  @res = 0

BEGIN TRY    
  set  @y = cast (SUBSTRING(@enp,5,4) as int)
  set  @s = REVERSE(cast((9999 - @y+10000) as varchar))
  set @y = cast(SUBSTRING(@s,1,4) as int)
  set @m = cast(SUBSTRING(@enp,3,2) as int)
  if @y <= 1950 set  @m = 99 -(@m+20)
  else
	if @y <= 2000 
		set @m = 99 -(@m+40)
	else
		set @m = 99 -@m
  
 set @d = cast(SUBSTRING(@enp,9,2) as int)
  if(@d > 50) 
  begin 
	set @d = 99-@d
	set @sex='ж'
  end;
  else
   begin 
  set @d= 99-@d-50
  set @sex='м'
  end
  declare @str varchar(20);
  set @str = cast(@d as varchar)+'.'+cast(@m as varchar)+'.'+cast(@y as varchar) 
 set @birthdate = CONVERT(datetime, @str, 104)
END TRY 
BEGIN CATCH  
     set @res = -1
END CATCH 
return @res 
END
go

