
CREATE PROCEDURE [dbo].[spCreateVisitWOExpert]
	@dttid int,
	@mkabid int,
	@result int output
AS
BEGIN

	/* Есть ли такая временная запись? */
	IF NOT EXISTS
	(
		SELECT * FROM hlt_DoctorTimeTable WHERE DoctorTimeTableID = @dttid
	)
	BEGIN
		SET @result = -8	
		RETURN
	END

		

BEGIN TRAN

declare @dvtID int
declare @TAPID int


	DECLARE @num VARCHAR(200) = ''
	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE NAME = 'spGetDVDStubNum'
				AND type = 'P'
			)
	BEGIN
		DECLARE @RC INT

		EXECUTE @RC = [dbo].[spGetDVDStubNum] @dttid
			,@num OUTPUT
		
	END
	ELSE
	BEGIN
		UPDATE hlt_DoctorTimeTable
		SET LastStubNum = LastStubNum + 1
		WHERE DoctorTimeTableID = @dttid

		SELECT TOP 1 @num =convert(VARCHAR(5), Begin_Time, 108) + '.' + RIGHT('000' + cast(LastStubNum AS VARCHAR(3)), 3)
		FROM hlt_DoctorTimeTable
		WHERE DoctorTimeTableID = @dttid
	END
    
	/* Создаем записи в hlt_DoctorVisitTable */
	INSERT INTO hlt_DoctorVisitTable (
		rf_DoctorTimeTableID
		,rf_MKABID
		,Comment
		,Flags
		,fromInternet
		,UGUID
		,NormaUE
		,DateTimeCreate
		,StubNum
		)
	SELECT @dttid
		,@mkabid
		,hlt_MKAB.FAMILY + ' ' + hlt_MKAB.NAME + ' ' + hlt_MKAB.OT + ', ' + cast(datepart(yy, hlt_MKAB.DATE_BD) AS VARCHAR(4)) + ' г.р.'
		,4
		,1
		,newid()
		,1
		,getdate()
		,@num
	FROM hlt_MKAB
	WHERE MKABID = @mkabid

/* сохраняем ID записи*/
SET @dvtid = (SELECT IDENT_CURRENT('hlt_DoctorVisitTable'))

COMMIT TRAN
SET @result = 0

END
go

