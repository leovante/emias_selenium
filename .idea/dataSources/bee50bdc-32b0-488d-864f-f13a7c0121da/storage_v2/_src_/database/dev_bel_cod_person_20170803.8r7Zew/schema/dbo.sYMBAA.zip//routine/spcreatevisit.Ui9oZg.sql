
CREATE PROCEDURE [dbo].[spCreateVisit]
	@dttid int,
	@mkabid int,
	@result int output
AS
BEGIN

	/* Есть ли такая временная запись? */
	IF NOT EXISTS
	(
		SELECT * FROM hlt_DoctorTimeTable WHERE DoctorTimeTableID = @dttid
	)
	BEGIN
		SET @result = -8	
		RETURN
	END

	/*А может уже кого-то записали?*/
	DECLARE @PLAN int
	DECLARE @NORMA int

	SET @PLAN = isnull((SELECT PLANUE FROM hlt_DoctorTimeTable WHERE DoctorTimeTableID = @dttid), 0)	
	SET @NORMA = isnull((SELECT sum(NormaUE) FROM hlt_DoctorVisitTable WHERE rf_DoctorTimeTableID = @dttid),0)

	IF @NORMA >= @PLAN	
	BEGIN
		SET @result = -2
		RETURN
	END

	/*Определяем врача*/
	DECLARE @docPRVDID int
	SET @docPRVDID = isnull((select top 1 rf_docPRVDID from hlt_DoctorTimeTable where DoctorTimeTableID = @dttid),0)

	/*И его специальность*/
	DECLARE @PRVSID	int
	SET @PRVSID = isnull((select top 1 rf_PRVSID from hlt_DocPRVD where DocPRVDID = @docPRVDID),0)

	/*Дата записи*/
	DECLARE @dttDate DATETIME
	SET @dttDate = isnull((SELECT TOP 1 [DATE] FROM hlt_DoctorTimeTable where DoctorTimeTableID =  @dttid), getdate())	

	IF @docPRVDID != 0 and EXISTS
	(
		SELECT 1
		FROM hlt_DoctorTimeTable dtt
			INNER JOIN hlt_DoctorVisitTable dvt
				ON dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID
		WHERE dvt.rf_MkabID = @mkabid
			AND dtt.Date = @dttDate
			AND dtt.rf_DocPRVDID = @docPRVDID		
	)
	BEGIN	
		SET @result = -7
		RETURN
	END


	/*Уже записаны к врачу такой же специальности*/
	IF EXISTS
	(
		 SELECT 1
		 FROM hlt_DoctorTimeTable dtt
			INNER JOIN hlt_DoctorVisitTable dvt
				ON dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID
			INNER JOIN hlt_DocPRVD 
				ON DocPRVDID = dtt.rf_DocPRVDID
		 WHERE dvt.rf_MKABID=@mkabid 
			and hlt_DocPRVD.rf_PRVSID = @PRVSID
			and dtt.DATE>GETDATE() 
	)
	BEGIN		
		SET @result = -101
		RETURN
	END

	/* Проверим права записи */
	IF NOT EXISTS
	(
		SELECT 1 FROM hlt_DoctorTimeTable WHERE DoctorTimeTableID = @dttid AND (FlagAccess & 4) > 0
	)
	begin
		SET @result = -12		
		RETURN 		
	end

	/*Проверим диспансерных пациентов*/
	IF (
		(select top 1 case valueStr when '' then 0 when '0' then 0 else 1 end 
		 from x_userSettings where property like 'Диспансерное наблюдение') = 1
	)  
	BEGIN
		
		IF ((select isnull((select top 1 isSpecial from hlt_docprvd where docPRVDID = @docPRVDID),0))=1)
				
		BEGIN
			/*Самозапись к этим специалистам разрешена только для диспансерных пациентов*/
			IF NOT EXISTS
				(
					SELECT TOP 1 1 from hlt_RegMedicalCheck			
					WHERE rf_MKABID = @mkabid 
					--AND @dttDate BETWEEN dateRegistration AND DateOff 
					AND rf_PRVSID = @PRVSID
					AND ((isClosed = 0 AND @dttDate >= dateRegistration) OR (isClosed = 1 AND @dttDate <= DateOff) )
				)
			BEGIN				
				SET @result = -13
				RETURN
			END
		END
	END 


BEGIN TRAN

declare @dvtID int
declare @TAPID int


	DECLARE @num VARCHAR(200) = ''
	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE NAME = 'spGetDVDStubNum'
				AND type = 'P'
			)
	BEGIN
		DECLARE @RC INT

		EXECUTE @RC = [dbo].[spGetDVDStubNum] @dttid
			,@num OUTPUT
		
	END
	ELSE
	BEGIN
		UPDATE hlt_DoctorTimeTable
		SET LastStubNum = LastStubNum + 1
		WHERE DoctorTimeTableID = @dttid

		SELECT TOP 1 @num =convert(VARCHAR(5), Begin_Time, 108) + '.' + RIGHT('000' + cast(LastStubNum AS VARCHAR(3)), 3)
		FROM hlt_DoctorTimeTable
		WHERE DoctorTimeTableID = @dttid
	END


	/* Создаем записи в hlt_DoctorVisitTable */
	INSERT INTO hlt_DoctorVisitTable (
		rf_DoctorTimeTableID
		,rf_MKABID
		,Comment
		,Flags
		,fromInternet
		,UGUID
		,NormaUE
		,DateTimeCreate
		,StubNum
		)
	SELECT @dttid
		,@mkabid
		,hlt_MKAB.FAMILY + ' ' + hlt_MKAB.NAME + ' ' + hlt_MKAB.OT + ', ' + cast(datepart(yy, hlt_MKAB.DATE_BD) AS VARCHAR(4)) + ' г.р.'
		,4
		,1
		,newid()
		,1
		,getdate()
		,@num
	FROM hlt_MKAB
	WHERE MKABID = @mkabid

/*Life не пишем - это будет происходить на триггерах*/

COMMIT TRAN
SET @result = 0

END
go

