CREATE VIEW [V_hlt_PatientRegisterType] AS SELECT 
[hDED].[PatientRegisterTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_PatientRegisterType] as [hDED]
go

