CREATE VIEW [V_stt_WardType] AS SELECT 
[hDED].[WardTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [stt_WardType] as [hDED]
go

