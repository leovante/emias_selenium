
create function hl7_GetCompliants
(
	@DocumentGuid VARCHAR(100),
	@TemplateCode VARCHAR(50)
 )
RETURNS VARCHAR(MAX)
AS
BEGIN
	DECLARE     @result  VARCHAR(max)
	DECLARE		@XmlData xml	
	SET @result = '' 
	
	SET @XmlData = 
		(select TOP(1) CONVERT(XML,mr.Data) from hlt_MedRecord mr 
			join hlt_BlankTemplate bt on mr.rf_BlankTemplateID = bt.BlankTemplateID
		where bt.Code = @TemplateCode AND mr.DescGuid = @DocumentGuid )
	
	DECLARE @text VARCHAR(MAX)
	SET @text = 
'                            <text>
                                <table border="1">
                                    <thead>
                                        <tr>
                                            <th>Дата возникновения симтомов</th>
                                            <th>Жалоба</th>
                                            <th>Кем зафиксирована жалоба</th>
                                        </tr>
                                    </thead>
                                    <tbody>'
	
			

				IF not((dbo.GetValueFromXMl(@XmlData,'TextComplaints') = '' OR dbo.GetValueFromXMl(@XmlData,'DateComplaints') = '' ))
				BEGIN
				SET @text = @text + '
                                        <tr>
                                            <td align="center">' + CONVERT(VARCHAR,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateComplaints'),104),105) +'</td>
                                            <td align="center">'+ dbo.GetValueFromXMl(@XmlData,'TextComplaints') +'</td>
                                            <td align="center">'+dbo.GetValueFromXMl(@XmlData,'TextSymptomsComplaints')+'</td>
                                        </tr>'
				
					 
				SET @result = @result +
'
                            <entry typeCode="COMP">
                                <templateId root="1.2.643.5.1.13.2.7.5.4.4"/>
                                <observation classCode="OBS" moodCode="EVN">
                                    <templateId root="1.2.643.5.1.13.2.7.5.3.5"/>
                                    <code code="COMPLNT" codeSystem="1.2.643.5.1.13.2.7.1.12" codeSystemName="Система кодирования событий" displayName="Жалоба">
                                    </code>
                                    <statusCode code="completed"/>
                                    <effectiveTime value="'+replace(replace(replace(convert(varchar,CONVERT(DATETIME,dbo.GetValueFromXMl(@XmlData,'DateComplaints'),104),120),'-',''),':',''),' ','')+'"/>'
				DECLARE @CODE CHAR	
				SET @CODE = ISNULL(dbo.GetValueFromXMl(@XmlData,'CodeSymptomsComplaints'),'')
				IF @CODE != '0' AND @CODE != ''
					SET @result = @result + 
							'
                                    <value code="'+@CODE+'" codeSystem="1.2.643.5.1.13.2.1.1.270" codeSystemName="Классификатор лиц, зафиксировавших симптомы у больного (ОНМК)" displayName="'+dbo.GetValueFromXMl(@XmlData,'TextSymptomsComplaints')+'" xsi:type="CD">
                                        <originalText>'+ dbo.GetValueFromXMl(@XmlData,'TextComplaints') +'</originalText>
                                    </value>'
				SET @result = @result + 
'
                                </observation>
                            </entry>'
				END

	IF (ISNULL(@result,'') = '')
		RETURN '                            <text/>'

	SET @text = @text  +
'
                                    </tbody>
                                </table>
                            </text>'
	RETURN @text + @result
          
END
go

