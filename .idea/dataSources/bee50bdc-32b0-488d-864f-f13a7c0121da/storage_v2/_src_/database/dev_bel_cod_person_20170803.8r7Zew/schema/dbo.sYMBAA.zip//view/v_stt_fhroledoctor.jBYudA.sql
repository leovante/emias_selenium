CREATE VIEW [V_stt_FHRoleDoctor] AS SELECT 
[hDED].[FHRoleDoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [stt_FHRoleDoctor] as [hDED]
go

