CREATE VIEW [V_stt_GenderType] AS SELECT 
[hDED].[GenderTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Gender] as [Gender]
FROM [stt_GenderType] as [hDED]
go

