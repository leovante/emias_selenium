CREATE VIEW [V_hlt_disp_ExamSM] AS SELECT 
[hDED].[disp_ExamSMID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OmsServiceMedicalGuid] as [rf_OmsServiceMedicalGuid], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_OmsServiceMedicalGuid], 
[hDED].[rf_ExamGuid] as [rf_ExamGuid], 
[jT_hlt_disp_Exam].[rf_ServiceGuid] as [SILENT_rf_ExamGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_ExamSM] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[GUIDSM] = [hDED].[rf_OmsServiceMedicalGuid]
INNER JOIN [hlt_disp_Exam] as [jT_hlt_disp_Exam] on [jT_hlt_disp_Exam].[Guid] = [hDED].[rf_ExamGuid]
go

