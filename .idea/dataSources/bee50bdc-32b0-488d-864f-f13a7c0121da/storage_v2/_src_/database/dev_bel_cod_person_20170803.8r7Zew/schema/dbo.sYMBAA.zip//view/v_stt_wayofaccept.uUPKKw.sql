CREATE VIEW [V_stt_WayOfAccept] AS SELECT 
[hDED].[WayOfAcceptID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flag] as [Flag]
FROM [stt_WayOfAccept] as [hDED]
go

