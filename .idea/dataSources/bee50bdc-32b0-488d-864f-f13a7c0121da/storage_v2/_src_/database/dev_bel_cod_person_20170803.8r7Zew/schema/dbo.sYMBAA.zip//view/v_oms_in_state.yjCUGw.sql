CREATE VIEW [V_oms_in_State] AS SELECT 
[hDED].[in_StateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Type] as [Type]
FROM [oms_in_State] as [hDED]
go

