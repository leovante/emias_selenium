

create view [dbo].[v_CurentMigrationPatient]
as
select mp.* from stt_MigrationPatient mp
inner join
(
	select rf_medicalHistoryID,max(Dateingoing) DateIngoing from stt_MigrationPatient
	group by rf_medicalHistoryID
)cmp on mp.rf_medicalHistoryID = cmp.rf_medicalHistoryID and mp.DateIngoing = cmp.DateIngoing

/****** Object:  View [dbo].[v_CurentMigrationPatient]    Script Date: 04/26/2011 12:11:38 ******/
go

