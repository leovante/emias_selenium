CREATE VIEW [V_oms_reestr_StoredLS] AS SELECT 
[hDED].[reestr_StoredLSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_APUID] as [rf_APUID], 
[jT_oms_APU].[P_NAMES] as [SILENT_rf_APUID], 
[hDED].[PackageNum] as [PackageNum], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[HostGuid] as [HostGuid], 
[hDED].[DateImport] as [DateImport], 
[hDED].[SendGUID] as [SendGUID]
FROM [oms_reestr_StoredLS] as [hDED]
INNER JOIN [oms_APU] as [jT_oms_APU] on [jT_oms_APU].[APUID] = [hDED].[rf_APUID]
go

