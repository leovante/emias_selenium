CREATE VIEW [V_stt_StatCardCatPrivilege] AS SELECT 
[hDED].[StatCardCatPrivilegeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flag] as [Flag]
FROM [stt_StatCardCatPrivilege] as [hDED]
go

