CREATE VIEW [V_oms_sc_ServiceType] AS SELECT 
[hDED].[sc_ServiceTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_sc_ServiceTypeCode], 
[hDED].[rf_sc_ServiceTypeTreeID] as [rf_sc_ServiceTypeTreeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_sc_ServiceType] as [hDED]
go

