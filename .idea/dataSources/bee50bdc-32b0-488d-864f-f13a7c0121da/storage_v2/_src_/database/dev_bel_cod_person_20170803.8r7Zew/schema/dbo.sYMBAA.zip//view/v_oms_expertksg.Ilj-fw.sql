CREATE VIEW [V_oms_ExpertKSG] AS SELECT 
[hDED].[ExpertKSGID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_SopMKBID] as [rf_SopMKBID], 
[hDED].[rf_OperationServiceMedicalID] as [rf_OperationServiceMedicalID], 
[hDED].[rf_KSGServiceMedicalID] as [rf_KSGServiceMedicalID], 
[hDED].[rf_VMPServiceMedicalID] as [rf_VMPServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_VMPServiceMedicalID], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[rf_TariffTargetID] as [rf_TariffTargetID], 
[jT_oms_TariffTarget].[TariffTargetCode] as [SILENT_rf_TariffTargetID], 
[hDED].[Year1] as [Year1], 
[hDED].[Year2] as [Year2], 
[hDED].[IsAgeDay] as [IsAgeDay], 
[hDED].[Flags] as [Flags], 
[hDED].[Doc] as [Doc], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[GuidExpertKSG] as [GuidExpertKSG], 
[hDED].[Name] as [Name], 
[hDED].[Norm] as [Norm], 
[hDED].[Value] as [Value]
FROM [oms_ExpertKSG] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_VMPServiceMedicalID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
INNER JOIN [oms_TariffTarget] as [jT_oms_TariffTarget] on [jT_oms_TariffTarget].[TariffTargetID] = [hDED].[rf_TariffTargetID]
go

