CREATE VIEW [V_stt_DenialCause] AS SELECT 
[hDED].[DenialCauseID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [stt_DenialCause] as [hDED]
go

