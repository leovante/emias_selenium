
CREATE PROCEDURE [dbo].[spCreateVisitFromOtherLPU]
	@dttid int,
	@mkabid int,
	@newmkab bit,
	@hist xml,
	@dirNum varchar(20),
	@result int output
AS
BEGIN

	/* Есть ли такой пациент? */
	IF NOT EXISTS
	(
		SELECT * FROM hlt_MKAB WHERE mkabID = @mkabid
	)
	BEGIN
		SET @result = -3	
		RETURN
	END

	/* Есть ли такая временная запись? */
	IF NOT EXISTS
	(
		SELECT * FROM hlt_DoctorTimeTable WHERE DoctorTimeTableID = @dttid
	)
	BEGIN
		SET @result = -8	
		RETURN
	END

	/*А может уже кого-то записали?*/
	DECLARE @Empty int	
	SET @Empty = isnull((SELECT PLANUE - UsedUE FROM hlt_DoctorTimeTable WHERE DoctorTimeTableID = @dttid), 0)	
	

	IF @Empty <= 0	
	BEGIN
		SET @result = -2
		RETURN
	END

	/*Определяем врача*/
	DECLARE @docPRVDID int
	SET @docPRVDID = isnull((select top 1 rf_docPRVDID from hlt_DoctorTimeTable where DoctorTimeTableID = @dttid),0)

	/*И его специальность*/
	DECLARE @PRVSID	int
	SET @PRVSID = isnull((select top 1 rf_PRVSID from hlt_DocPRVD where DocPRVDID = @docPRVDID),0)

	/*Дата записи*/
	DECLARE @dttDate DATETIME
	SET @dttDate = isnull((SELECT TOP 1 [DATE] FROM hlt_DoctorTimeTable where DoctorTimeTableID =  @dttid), getdate())	

	/*Есть запись в этот день к этому врачу*/
	IF @docPRVDID != 0 and EXISTS
	(
		SELECT 1
		FROM hlt_DoctorTimeTable dtt
			INNER JOIN hlt_DoctorVisitTable dvt
				ON dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID
		WHERE dvt.rf_MkabID = @mkabid
			AND dtt.Date = @dttDate
			AND dtt.rf_DocPRVDID = @docPRVDID		
	)
	BEGIN	
		SET @result = -7
		RETURN
	END


	/*Уже записаны к врачу такой же специальности*/
	IF EXISTS
	(
		 SELECT 1
		 FROM hlt_DoctorTimeTable dtt
			INNER JOIN hlt_DoctorVisitTable dvt
				ON dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID
			INNER JOIN hlt_DocPRVD 
				ON DocPRVDID = dtt.rf_DocPRVDID
		 WHERE dvt.rf_MKABID=@mkabid 
			and hlt_DocPRVD.rf_PRVSID = @PRVSID
			and dtt.DATE>GETDATE() 
	)
	BEGIN		
		SET @result = -101
		RETURN
	END


	/* Проверим права записи */
	IF NOT EXISTS
	(
		SELECT 1 FROM hlt_DoctorTimeTable WHERE DoctorTimeTableID = @dttid AND (FlagAccess & 8) > 0
	)
	begin
		SET @result = -12		
		RETURN 		
	end

BEGIN TRAN

declare @dirid int
SET @dirid = 0

declare @comment varchar(200)
set @comment = (SELECT 
					CASE WHEN len(ltrim(rtrim(Family))) > 0
					THEN FAMILY + ' ' + [NAME] + ' ' + OT + ' ' + S_POL + ' ' + N_POL + ', ' + cast (datepart(yy, hlt_MKAB.DATE_BD) as varchar(4)) + ' г.р.'
					ELSE S_POL + ' ' + N_POL + ', ' + cast (datepart(yy, hlt_MKAB.DATE_BD) as varchar(4)) + ' г.р.'
					END
				FROM hlt_MKAB WHERE mkabID = @mkabid)

if len(@dirNum) > 0
begin
	SET @comment = 'Напр. №' + @dirNum + ', ' + @comment

	/* Запишем направление в базу */
	INSERT INTO [hlt_Direction]
           ([Date]
           ,[rf_MKABID]
           ,[rf_LPUID]           
           ,[FAMILY]
           ,[NAME]
           ,[OT]
           ,[BD]           
           ,[S_POL]
           ,[N_POL]           
           ,[Num])
     SELECT
            getdate() as [Date]
           ,@mkabid as [rf_MKABID]
           ,[rf_LPUID]           
           ,[FAMILY]
           ,[NAME]
           ,[OT]
           ,[DATE_BD]           
           ,[S_POL]
           ,[N_POL]           
           ,@dirNum as [Num]  
	FROM hlt_MKAB where mkabid = @mkabid
	SET @dirid = (SELECT IDENT_CURRENT('hlt_Direction'))
end

	DECLARE @num VARCHAR(200) = ''
	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE NAME = 'spGetDVDStubNum'
				AND type = 'P'
			)
	BEGIN
		DECLARE @RC INT

		EXECUTE @RC = [dbo].[spGetDVDStubNum] @dttid
			,@num OUTPUT
		
	END
	ELSE
	BEGIN
		UPDATE hlt_DoctorTimeTable
		SET LastStubNum = LastStubNum + 1
		WHERE DoctorTimeTableID = @dttid

		SELECT TOP 1 @num =convert(VARCHAR(5), Begin_Time, 108) + '.' + RIGHT('000' + cast(LastStubNum AS VARCHAR(3)), 3)
		FROM hlt_DoctorTimeTable
		WHERE DoctorTimeTableID = @dttid
	END

/* Создаем записи в hlt_DoctorVisitTable */
INSERT INTO hlt_DoctorVisitTable 
(
	rf_DoctorTimeTableID, 
	rf_MKABID, 
	Comment,
	Flags,
	[fromOtherLPU],
	UGUID,
	NormaUE,
	[confirmRequired],
    [editHistory],
    [rf_DirectionID],
	DateTimeCreate,
	StubNum
)
SELECT 
	@dttid, 
	@mkabid, 
	@comment,
	4 as Flags,
	1 as [fromOtherLPU],
	newid() as UGUID,
	1 as NormaUE,
	case @newmkab when 0 then 0 else 1 end as [confirmRequired],
	@hist as [editHistory],
	@dirid as [rf_DirectionID],
	getdate(),
	@num
FROM hlt_MKAB WHERE MKABID = @mkabid

/*Life не пишем - это будет происходить на триггерах*/

COMMIT TRAN
SET @result = 0

END
go

