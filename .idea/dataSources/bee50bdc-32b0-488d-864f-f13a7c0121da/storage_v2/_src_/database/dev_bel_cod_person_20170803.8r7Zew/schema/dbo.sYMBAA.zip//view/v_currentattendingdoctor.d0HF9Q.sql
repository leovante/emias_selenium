

Create view [dbo].[v_CurrentAttendingDoctor]
as 
select  ad.* from stt_AttendingDoctor ad
inner join 
(
	select rf_MedicalHistoryID, max(date) date from stt_AttendingDoctor
	group by rf_MedicalHistoryID
)lastAD on ad.rf_MedicalHistoryID = lastAD.rf_MedicalHistoryID and ad.date = lastAD.date

go

