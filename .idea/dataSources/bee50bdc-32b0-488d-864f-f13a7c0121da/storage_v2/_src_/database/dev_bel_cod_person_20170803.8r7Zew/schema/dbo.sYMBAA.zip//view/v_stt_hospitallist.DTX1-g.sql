CREATE VIEW [V_stt_HospitalList] AS SELECT 
[hDED].[HospitalListID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RefLPUID] as [rf_RefLPUID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_DirectionID] as [rf_DirectionID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[PCOD] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_CanselLPUDoctorID] as [rf_CanselLPUDoctorID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[jT_stt_StationarBranch].[V_BranchInfo] as [SILENT_rf_StationarBranchID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_PlanBedID] as [rf_PlanBedID], 
[jT_stt_Bed].[Num] as [SILENT_rf_PlanBedID], 
[hDED].[rf_BedID] as [rf_BedID], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[PlanHospDateTime] as [PlanHospDateTime], 
[hDED].[ReserveFlags] as [ReserveFlags], 
[hDED].[DirectionNum] as [DirectionNum], 
[hDED].[CanselDate] as [CanselDate], 
[hDED].[isComlite] as [isComlite], 
[hDED].[flags] as [flags], 
[hDED].[isConfirm] as [isConfirm]
FROM [stt_HospitalList] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [V_stt_StationarBranch] as [jT_stt_StationarBranch] on [jT_stt_StationarBranch].[StationarBranchID] = [hDED].[rf_StationarBranchID]
INNER JOIN [stt_Bed] as [jT_stt_Bed] on [jT_stt_Bed].[BedID] = [hDED].[rf_PlanBedID]
go

