CREATE VIEW [V_stt_TypeComplication] AS SELECT 
[hDED].[TypeComplicationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flag] as [Flag]
FROM [stt_TypeComplication] as [hDED]
go

