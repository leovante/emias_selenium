
-- =============================================
-- Create date: 12.12.2011
-- Description:	Процедура возвращает недельное расписание врачей поликлиники для инфомата 
-- =============================================
CREATE PROCEDURE [dbo].[spGetWeekShedulerInfomat] 	
	@result xml output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @tmp_tab TABLE
(
	Uchastok varchar(255),
	SpecName varchar (255), 
	SeparationName varchar (255),
	DolgName varchar (150),
	RoomNum varchar (10),
	Fam varchar (100),
	Im varchar (25),
	Ot varchar (25),
	PCOD int/*varchar (20)*/,
	DayOfWeek int,
	ShortDate varchar(10), 
	FullDate varchar(19), 
	Hour_from varchar(10),
	Minute_from varchar(10),
	Hour_to varchar(10),
	Minute_to varchar(10)
)


SET DATEFIRST 1

declare @dateA datetime
declare @dateB datetime

set @dateA = CAST(floor(CAST(getdate() as float)) as datetime)  /*Убрали время*/
set @dateB = DateAdd(d, 6, @dateA)

/* Строим таблицу дат */
declare @Dates table (date datetime, dayOfWeek int)
insert into @Dates values (DateAdd(d, 0, @dateA), 0)
insert into @Dates values (DateAdd(d, 1, @dateA), 0)
insert into @Dates values (DateAdd(d, 2, @dateA), 0)
insert into @Dates values (DateAdd(d, 3, @dateA), 0)
insert into @Dates values (DateAdd(d, 4, @dateA), 0)
insert into @Dates values (DateAdd(d, 5, @dateA), 0)
insert into @Dates values (DateAdd(d, 6, @dateA), 0)

update @Dates set dayOfWeek = DATEPART(dw, date)

delete from @Dates where dayOfWeek > 5




/**/
insert into  @tmp_tab
select 
'' as Uchastok, 
'' as SpecName, 
'' as SeparationName, 
'' as DolgName, 
'' as RoomNum,
'___XXX___XXX___' as Fam,
'' as IM,
'' as OT,
s.DTT_DocPrVdID as PCOD,
0 as DayOfWeek,
'' as ShortDate ,
s.DTT_Date as FullDate,
-- Час начала
CASE isnull(min(s.DBT_Code), 0)
when 0 then NULL
when 1 then 'Отп.'
when 2 then 'Вых.'
when 3 then 'Бол.'
else
  case 
	when (min(s.DTT_Begin_Time) = null) or (DATEPART(hh, (min(s.DTT_Begin_Time))) = 0)
	then NULL 
	else Convert(varchar(2), DATEPART(hh, (min(s.DTT_Begin_Time))), 2)
  end
end
as Hour_from,
-- Минута начала
CASE 
when (min(s.DTT_Begin_Time) = null) or (DATEPART(hh, min(s.DTT_Begin_Time)) = 0)
then NULL
else right('0' + convert(varchar(2), DATEPART(mi, min(s.DTT_Begin_Time))), 2)
end 
as Minute_from,

CASE
when (min(s.DTT_Begin_Time) = null) or (DATEPART(hh, min(s.DTT_Begin_Time)) = 0)
then NULL
else
Convert(varchar(2), DATEPART(hh, max(s.DTT_End_Time)), 2) 
end
as Hour_to,
CASE 
when (min(s.DTT_Begin_Time) = null) or (DATEPART(hh, min(s.DTT_Begin_Time)) = 0)
then null
else right('0' + convert(varchar(2), DATEPART(mi, max(s.DTT_End_Time))), 2)
end 
as Minute_to
from iv_schedul s
where s.DTT_Date between @dateA and @dateB
group by s.DTT_Date, s.DTT_DocPrVdID

insert into  @tmp_tab
select 
	'' /*isnull(u.Code, '')*/ as Uchastok, 	
	isnull(prvs.prvs_name, '') as SpecName, 
	isnull(dp.DepartmentName, '') as SeparationName, 
	isnull(prvd.name, '') as DolgName, 
	isnull(hr.Num, '') as RoomNum,
	isnull(Upper(substring( doc.FAM_V,1,1)) + lower(substring( doc.FAM_V,2, 50 )), '' ) as Fam,
	isnull(Upper(substring( doc.IM_V ,1,1)) + lower(substring( doc.IM_V ,2, 50 )), '' ) as IM,
	isnull(Upper(substring( doc.OT_V ,1,1)) + lower(substring( doc.OT_V ,2, 50 )), '' ) as OT,
	tt.PCOD,	
	d.dayOfWeek as dayOfWeek,
		right('0' + convert(varchar(2), DATEPART(d, d.Date)), 2)
		+ '.' + 
		right('0' + convert(varchar(2), DATEPART(m, d.Date)), 2)
	as ShortDate, 
	convert(varchar(19), d.Date, 126) as FullDate, 
	isnull(t.Hour_from, '') as Hour_from,
	isnull(t.Minute_from, '') as Minute_from,
	isnull(t.Hour_to, '') as Hour_to,
	isnull(t.Minute_to, '') as Minute_to
from @dates d cross join 
(select distinct pcod from @tmp_tab) tt
inner join hlt_DocPrVD p on p.DocPrVdID = tt.pcod
inner join hlt_LpuDoctor doc on doc.LPUDoctorID = p.rf_LPUDoctorID and p.rf_LPUDoctorID != 0
left join oms_Department dp on dp.DepartmentID = p.rf_DepartmentID 
left join oms_prvd prvd on prvd.PRVDID = p.rf_PRVDID
left join oms_prvs prvs on prvs.PRVSID = p.rf_PRVSID
left join hlt_HealingRoom hr on hr.HealingRoomID = p.rf_HealingRoomID
left join @tmp_tab t
on d.Date = t.FullDate and tt.PCOD = t.PCOD


DECLARE curDocPrvd CURSOR
KEYSET
FOR SELECT DISTINCT PCOD FROM @tmp_tab

DECLARE @prvdid int

OPEN curDocPrvd

FETCH NEXT FROM curDocPrvd INTO @prvdid
WHILE (@@fetch_status = 0)
BEGIN
	DECLARE @uch VARCHAR(1024) 
	SET @uch = null
	SELECT @uch =  isnull(@uch + ', ', '') + ltrim(rtrim(Code)) FROM hlt_Uchastok
	WHERE rf_DocPRVDID = @prvdid

	IF len(@uch) != 0 
	BEGIN
		UPDATE @tmp_tab SET Uchastok = @uch WHERE PCOD = @prvdid
	END

	FETCH NEXT FROM curDocPrvd INTO @prvdid
END

CLOSE curDocPrvd
DEALLOCATE curDocPrvd





delete from @tmp_tab where FAM = '___XXX___XXX___'


set @result = 
	(
		select tt.* from 
			(
				-- Уровень 1 - тэг LPUShedulerTableResult
				SELECT 
					   1    AS Tag,
					   NULL AS Parent,
					   NULL AS [LPUShedulerTableResult!1],	   
					   'true' AS [LPUShedulerTableResult!1!Result],
					   0 AS [LPUShedulerTableResult!1!Code],
					   NULL AS [Specialization!2!SpecName!ELEMENT],
					   NULL AS [Dolgnost!3!DolgName!ELEMENT],
					   NULL AS [Doctor!4!Fam!ELEMENT],
					   NULL AS [Doctor!4!Im!ELEMENT],
					   NULL AS [Doctor!4!Ot!ELEMENT],
					   NULL AS [Doctor!4!PCOD!ELEMENT],
					   NULL AS [Doctor!4!Uchastok!ELEMENT],
					   NULL AS [Doctor!4!RoomNum!ELEMENT],
					   NULL AS [Doctor!4!SeparationName!ELEMENT],
					   NULL AS [DocShedul!5],
					   NULL AS [RowShedul!6!ShortDate!ELEMENT],
					   NULL AS [RowShedul!6!FullDate!ELEMENT],
					   NULL AS [RowShedul!6!DayOfWeek!ELEMENT],
					   NULL AS [RowShedul!6!Hour_from!ELEMENT],
					   NULL AS [RowShedul!6!Minute_from!ELEMENT],
					   NULL AS [RowShedul!6!Hour_to!ELEMENT],
					   NULL AS [RowShedul!6!Minute_to!ELEMENT]				
				UNION ALL
				-- Уровень 2 - тэг - Specialization
				SELECT distinct
					   2 AS Tag,
					   1 AS Parent,
					   NULL AS [LPUShedulerTableResult!1],
					   NULL AS [LPUShedulerTableResult!1!Result],
					   NULL AS [LPUShedulerTableResult!1!Code],
					   SpecName AS [Specialization!2!SpecName!ELEMENT],         
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL
				from @tmp_tab
				union all
				-- уровень 3 - тэг Dolgnost
				SELECT distinct
					   3 AS Tag,
					   2 AS Parent,
					   NULL AS [LPUShedulerTableResult!1],
					   NULL AS [LPUShedulerTableResult!1!Result],
					   NULL AS [LPUShedulerTableResult!1!Code],
					   SpecName AS [Specialization!2!SpecName!ELEMENT],
					   DolgName AS [Dolgnost!3!DolgName!ELEMENT],
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL
				from @tmp_tab
				union all
				--уровень 4 - тэг Doctor
				SELECT distinct
					   4 AS Tag,
					   3 AS Parent,
					   NULL AS [LPUShedulerTableResult!1],
					   NULL AS [LPUShedulerTableResult!1!Result],
					   NULL AS [LPUShedulerTableResult!1!Code],
					   SpecName AS [Specialization!2!SpecName!ELEMENT],
					   DolgName AS [Dolgnost!3!DolgName!ELEMENT],
					   Fam AS [Doctor!4!Fam!ELEMENT],
					   Im AS [Doctor!4!Im!ELEMENT],
					   Ot AS [Doctor!4!Ot!ELEMENT],
					   PCOD AS [Doctor!4!PCOD!ELEMENT],
					   Uchastok AS [Doctor!4!Uchastok!ELEMENT],
					   RoomNum AS [Doctor!4!RoomNum!ELEMENT],
					   SeparationName AS [Doctor!4!SeparationName!ELEMENT],
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL
				from @tmp_tab
				union all
				-- уровень 5 - тэг DocShedul
				SELECT distinct
					   5		AS Tag,
					   4		AS Parent,
					   NULL		AS [LPUShedulerTableResult!1],
					   NULL		AS [LPUShedulerTableResult!1!Result],
					   NULL		AS [LPUShedulerTableResult!1!Code],
					   SpecName AS [Specialization!2!SpecName!ELEMENT],
					   DolgName AS [Dolgnost!3!DolgName!ELEMENT],
					   Fam		AS [Doctor!4!Fam!ELEMENT],
					   Im		AS [Doctor!4!Im!ELEMENT],
					   Ot		AS [Doctor!4!Ot!ELEMENT],
					   PCOD		AS [Doctor!4!PCOD!ELEMENT],
					   Uchastok AS [Doctor!4!Uchastok!ELEMENT],
					   RoomNum	AS [Doctor!4!RoomNum!ELEMENT],
					   SeparationName AS [Doctor!4!SeparationName!ELEMENT],
					   NULL		AS [DocShedul!5],
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL
				from @tmp_tab t2
				union all
				-- уровень 6 - тэг RowShedul
				SELECT distinct 
					   6		AS Tag,
					   5		AS Parent,
					   NULL		AS [LPUShedulerTableResult!1],
					   NULL		AS [LPUShedulerTableResult!1!Result],
					   NULL		AS [LPUShedulerTableResult!1!Code],
					   SpecName AS [Specialization!2!SpecName!ELEMENT],
					   DolgName AS [Dolgnost!3!DolgName!ELEMENT],
					   Fam		AS [Doctor!4!Fam!ELEMENT],
					   Im		AS [Doctor!4!Im!ELEMENT],
					   Ot		AS [Doctor!4!Ot!ELEMENT],
					   PCOD		AS [Doctor!4!PCOD!ELEMENT],
					   Uchastok AS [Doctor!4!Uchastok!ELEMENT],
					   RoomNum	AS [Doctor!4!RoomNum!ELEMENT],
					   SeparationName AS [Doctor!4!SeparationName!ELEMENT],
					   NULL		AS [DocShedul!5],
					   ShortDate	AS [RowShedul!6!ShortDate!ELEMENT], 
					   FullDate		AS [RowShedul!6!FullDate!ELEMENT],
					   DayOfWeek	AS [RowShedul!6!DayOfWeek!ELEMENT], 
					   Hour_from	AS [RowShedul!6!Hour_from!ELEMENT],
					   Minute_from	AS [RowShedul!6!Minute_from!ELEMENT],
					   Hour_to		AS [RowShedul!6!Hour_to!ELEMENT],
					   Minute_to	AS [RowShedul!6!Minute_to!ELEMENT]
				from @tmp_tab
			) tt
order by [Specialization!2!SpecName!ELEMENT],
 [Dolgnost!3!DolgName!ELEMENT],
 [Doctor!4!Fam!ELEMENT],
 [Doctor!4!Im!ELEMENT],
 [Doctor!4!Ot!ELEMENT],
 [Doctor!4!PCOD!ELEMENT],
 [RowShedul!6!DayOfWeek!ELEMENT]

FOR XML EXPLICIT
	)

END
go

