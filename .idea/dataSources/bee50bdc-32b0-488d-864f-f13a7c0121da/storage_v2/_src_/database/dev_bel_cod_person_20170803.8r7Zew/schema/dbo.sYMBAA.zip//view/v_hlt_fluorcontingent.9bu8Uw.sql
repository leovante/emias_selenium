CREATE VIEW [V_hlt_FluorContingent] AS SELECT 
[hDED].[FluorContingentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[Name] as [Name], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_FluorContingent] as [hDED]
go

