CREATE VIEW [V_stt_HospitalQuota] AS SELECT 
[hDED].[HospitalQuotaID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[PCOD] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[jT_stt_StationarBranch].[V_BranchInfo] as [SILENT_rf_StationarBranchID], 
[hDED].[rf_QuotaTypeID] as [rf_QuotaTypeID], 
[jT_stt_QuotaType].[Name] as [SILENT_rf_QuotaTypeID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Qty] as [Qty], 
[hDED].[RestCol] as [RestCol], 
[hDED].[SorceDesc] as [SorceDesc], 
[hDED].[flags] as [flags]
FROM [stt_HospitalQuota] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [V_stt_StationarBranch] as [jT_stt_StationarBranch] on [jT_stt_StationarBranch].[StationarBranchID] = [hDED].[rf_StationarBranchID]
INNER JOIN [stt_QuotaType] as [jT_stt_QuotaType] on [jT_stt_QuotaType].[QuotaTypeID] = [hDED].[rf_QuotaTypeID]
go

