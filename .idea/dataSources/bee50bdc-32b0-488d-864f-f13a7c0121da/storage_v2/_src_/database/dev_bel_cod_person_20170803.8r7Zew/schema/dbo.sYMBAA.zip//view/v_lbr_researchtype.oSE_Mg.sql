CREATE VIEW [V_lbr_ResearchType] AS SELECT 
[hDED].[ResearchTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_LaboratoryTypeID] as [rf_LaboratoryTypeID], 
[jT_lbr_LaboratoryType].[Name] as [SILENT_rf_LaboratoryTypeID], 
[hDED].[rf_ResearchTypeKindID] as [rf_ResearchTypeKindID], 
[jT_lbr_ResearchTypeKind].[Name] as [SILENT_rf_ResearchTypeKindID], 
[hDED].[rf_BioMID] as [rf_BioMID], 
[hDED].[ResearchName] as [ResearchName], 
[hDED].[Report] as [Report], 
[hDED].[Period] as [Period], 
[hDED].[Code] as [Code], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flags] as [Flags], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [lbr_ResearchType] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [lbr_LaboratoryType] as [jT_lbr_LaboratoryType] on [jT_lbr_LaboratoryType].[LaboratoryTypeID] = [hDED].[rf_LaboratoryTypeID]
INNER JOIN [lbr_ResearchTypeKind] as [jT_lbr_ResearchTypeKind] on [jT_lbr_ResearchTypeKind].[ResearchTypeKindID] = [hDED].[rf_ResearchTypeKindID]
go

