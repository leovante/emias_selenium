CREATE VIEW [V_hlt_RegMedicalCheck] AS SELECT 
[hDED].[RegMedicalCheckID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_MKAB].[OT] as [V_OT], 
[jT_hlt_MKAB].[FAMILY] as [V_Family], 
[jT_hlt_MKAB].[NAME] as [V_Name], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_PRVSID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DDDiscoveryDisease] as [rf_DDDiscoveryDisease], 
[jT_hlt_DDDiscoveryDisease].[Name] as [SILENT_rf_DDDiscoveryDisease], 
[hDED].[rf_CauseOfStrikeID] as [rf_CauseOfStrikeID], 
[jT_hlt_CauseOfStrike].[Code] as [SILENT_rf_CauseOfStrikeID], 
[hDED].[Comment] as [Comment], 
[hDED].[DateRegistration] as [DateRegistration], 
[hDED].[DateOff] as [DateOff], 
[hDED].[CauseOfStrike] as [CauseOfStrike], 
[hDED].[DateMKB] as [DateMKB], 
[hDED].[Concomitant] as [Concomitant], 
[hDED].[isClosed] as [isClosed], 
[hDED].[isRepeatedDS] as [isRepeatedDS]
FROM [hlt_RegMedicalCheck] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
INNER JOIN [hlt_DDDiscoveryDisease] as [jT_hlt_DDDiscoveryDisease] on [jT_hlt_DDDiscoveryDisease].[DDDiscoveryDiseaseID] = [hDED].[rf_DDDiscoveryDisease]
INNER JOIN [hlt_CauseOfStrike] as [jT_hlt_CauseOfStrike] on [jT_hlt_CauseOfStrike].[CauseOfStrikeID] = [hDED].[rf_CauseOfStrikeID]
go

