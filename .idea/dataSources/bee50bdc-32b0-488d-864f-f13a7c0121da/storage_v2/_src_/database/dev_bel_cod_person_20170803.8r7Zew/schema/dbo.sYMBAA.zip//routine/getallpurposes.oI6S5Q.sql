
--функция выдает все назначения на указанного пациента на указанную дату
CREATE FUNCTION [dbo].[GetAllPurposes] (@MedicalHistoryID varchar(20),@Date varchar(30))
RETURNS  Table as
	RETURN
	( 
		select * from
		(

		--лекарственные назначения
		select 
			mh.medicalHistoryID as PAT,
			case when lp.Signature='' then 'Без описания' else lp.Signature end as [SIGN],
			'(Доза '+substring(convert(varchar (20),lp.dose),0,5)+', крат. ' +convert(varchar (20),lp.TimesInDay)+') '+pls.Name   as [NAME],		
			substring(convert(varchar,PLP.date,21),0,11)  as [DATE]
		from V_stt_medicalhistory mh
		inner join stt_ListOfPurpose lp on lp.rf_MedicalHistoryID = mh.MedicalHistoryID
		inner join stt_PurposeLS pls on lp.rf_PurposeLSID = pls.PurposeLSID 
		inner join stt_PLPosition plp on plp.rf_ListOfPurposeID = lp.ListOfPurposeID
		inner join V_currentmigrationpatient cmp on cmp.rf_MedicalHistoryID = mh.MedicalHistoryID
		inner join stt_stationarbranch sb on cmp.rf_stationarbranchID=sb.stationarbranchID --and sb.stationarbranchID=2--@Branch.StationarBranchID 
		left join stt_lsoutlay lso on plp.rf_lsoutlayID=lsoutlayID
		where medicalhistoryID>0 
		 -- and ((rf_lsoutlayID=0) or (plp.rf_lsoutlayID<>0 and lso.realcount=0)) --проверка на факт завершенности - лекарство списано
			and medicalhistoryID not in (select rf_medicalhistoryID from stt_denial) --проверка на отказ от госпитализации
			and rf_cancelDoctorID=0 --проверка на отмену назначения
			
		UNION ALL

		--процедурные назначения
		select
			mh.medicalHistoryID as PAT,
			case when pl.Signature='' then 'Без описания' else pl.Signature end as [SIGN],
			ServiceMedicalName  as [NAME],
			substring(convert(varchar,PP.Date,21),0,11) as [Date]
		from V_stt_MedicalHistory MH
		inner join stt_ProcedureList PL on PL.rf_MedicalHistoryID=MH.MedicalHistoryID
		inner join oms_ServiceMedical SM on PL.rf_ServiceMedicalID=SM.ServiceMedicalID
		inner join stt_ProcedurePosition PP on PP.rf_ProcedureListID =PL.ProcedureListID 
		inner join V_currentmigrationpatient cmp on cmp.rf_MedicalHistoryID = mh.MedicalHistoryID
		inner join stt_stationarbranch sb on cmp.rf_stationarbranchID=sb.stationarbranchID --and sb.stationarbranchID=2--@Branch.StationarBranchID    
		left join stt_medservicepatient msp on msp.rf_ProcedurePositionID=ProcedurePositionID    
		--возможна ситуация с назначенными лекарствами у процедуры, тогда
		left join stt_PLPosition plp on plp.rf_ProcedurePositionID=ProcedurePositionID
		left join stt_lsoutlay lso on plp.rf_lsoutlayID=lsoutlayID

		where medicalhistoryID>0 
			and isnull(msp.flagcomplete,0)=0	--проверка на факт завершенности - назначение выполнено
			and medicalhistoryID not in (select rf_medicalhistoryID from stt_denial)--проверка на отказ от госпитализации
			and isnull(lso.realcount,0)=0 --проверка лекарства на списание
			and rf_cancelDoctorID=0 --проверка на отмену назначения

		UNION ALL

		--мероприятия
		select
			mh.medicalHistoryID as PAT,
			case when ev.description='' then 'Без описания' else ev.description end as [SIGN],
			evt.Name  as [NAME],
			substring(convert(varchar,[Date],21),0,11) as Date
		from V_stt_MedicalHistory MH
		inner join stt_event ev on ev.rf_MedicalHistoryID=MedicalHistoryID
		inner join stt_eventtype evt on ev.rf_EventTypeID=EventTypeID
		inner join V_currentmigrationpatient cmp on cmp.rf_MedicalHistoryID = mh.MedicalHistoryID
		inner join stt_stationarbranch sb on cmp.rf_stationarbranchID=sb.stationarbranchID --and sb.stationarbranchID=2--@Branch.StationarBranchID    
		where medicalhistoryID>0 
			and ev.complete=0
			and medicalhistoryID not in (select rf_medicalhistoryID from stt_denial)--проверка на отказ от госпитализации
			and rf_cancelDoctorID=0 --проверка на отмену назначения
				
		)cont
		where substring(convert(varchar,[Date],21),0,11)>=SUBSTRING(@Date,0,11)
			and substring(convert(varchar,[Date],21),0,11)<=SUBSTRING(convert(varchar,dateadd(day,30,convert(datetime,@Date)),21),0,11)
			and PAT=@MedicalHistoryID
	)
go

