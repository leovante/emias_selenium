CREATE VIEW [V_hlt_FluorTypeGroupRisk] AS SELECT 
[hDED].[FluorTypeGroupRiskID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[Name] as [Name], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_FluorTypeGroupRisk] as [hDED]
go

