CREATE VIEW [V_oms_MedicalArticle] AS SELECT 
[hDED].[MedicalArticleID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_MedArticleCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_MedicalArticle] as [hDED]
go

