

--первая строка отчета 
-- учет занятости коек и смены состояний определяется на 8 часов утра
-- 9:00 -  считается началом новых суток, и не входи в предыдущие
Create function [dbo].[stt_AVGMonthCountBeds](@month int,@StationarBranchID int)
returns float

begin
	if(@month<1 or @month>12) return 0

	declare @DayBegin datetime,@monthend datetime,
			@bedSum int,@daycount int

	select  @DayBegin = convert(datetime,'01.'+cast(@month as varchar)+'.'+cast(datepart(year,getdate()) as varchar(100))+' 09:00:00:000',104),
			@monthEnd = dateadd(month,1,@dayBegin)		


	--подсчет количества занятых коек каждого дня
	select @daycount = datediff(day,@DayBegin,@monthEnd)	

	select  @bedSum=0
	while (@DayBegin<@monthEnd)
	begin
		--считаем количество занятых коек на начало дня
		select @bedSum=@bedSum+count(1) from stt_bed
			inner join stt_Ward on rf_wardID = wardID
			inner join stt_BedStatus stat on rf_bedStatusID = BedStatusID
			inner join stt_BedAction ba on rf_bedid=bedID
			inner join
			(
				select rf_bedID, max(date) Date from stt_BedAction
				where date<=@dayBegin
				group by rf_bedID
			) lastAction on ba.rf_bedID=lastAction.rf_bedID and ba.Date = lastAction.date
			inner join stt_ActionType at on rf_actionTypeID = ActionTypeID
			where bedID>0  
				  and at.code=1-- текущее состояние койки - занята
				  and ba.date <= @dayBegin
				  and stat.code = '01'
				  and (rf_StationarBranchID = @StationarBranchID or -1= @StationarBranchID)

		set @dayBegin= dateadd(day,1,@dayBegin)		
	end

	return cast(@bedSum as float)/@daycount
end

go

