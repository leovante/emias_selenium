CREATE VIEW [V_oms_kl_VisitResult] AS SELECT 
[hDED].[kl_VisitResultID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_VisitResultCode], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_VisitResult] as [hDED]
go

