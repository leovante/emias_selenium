CREATE VIEW [V_oms_mn_Info] AS SELECT 
[hDED].[mn_InfoID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[rf_mn_PersonID] as [rf_mn_PersonID], 
[jT_oms_mn_Person].[V_FIO] as [SILENT_rf_mn_PersonID], 
[hDED].[Surname] as [Surname], 
[hDED].[Name] as [Name], 
[hDED].[Patronymic] as [Patronymic], 
[hDED].[BithDayDate] as [BithDayDate], 
[hDED].[BithDayPlace] as [BithDayPlace], 
[hDED].[DeathDate] as [DeathDate], 
[hDED].[Surname_Find] as [Surname_Find], 
[hDED].[Name_Find] as [Name_Find], 
[hDED].[Patronymic_Find] as [Patronymic_Find], 
[hDED].[InfoGuid] as [InfoGuid], 
[hDED].[IsActive] as [IsActive], 
[hDED].[Flags] as [Flags], 
[hDED].[FIO_Find] as [FIO_Find]
FROM [oms_mn_Info] as [hDED]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
INNER JOIN [V_oms_mn_Person] as [jT_oms_mn_Person] on [jT_oms_mn_Person].[mn_PersonID] = [hDED].[rf_mn_PersonID]
go

