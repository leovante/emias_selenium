

/* 	13/12/06 ISidorov */
CREATE FUNCTION [dbo].[RAS_Get_LS_Amount] (@StoredLSID int, @Date datetime)
RETURNS decimal(18,2)
AS
BEGIN
	DECLARE @res decimal(18,2)

	Declare @RestDateTime datetime 
	SET @RestDateTime = convert(datetime,'1900-01-01T00:00:00')

	set @res = (select top 1 sum(tj.[count])
	from ras_transactjournal as tj
	inner join ras_period on rf_periodID = PeriodID
	where (rf_StoredLSID = @StoredLSID) and
	(TransactDateTimeOperation BETWEEN @restDateTime AND @Date)
	and rf_PeriodID <> 0 )

	if (@res IS NULL) 
	begin
		set @res = 0
	end

RETURN @res
END

go

