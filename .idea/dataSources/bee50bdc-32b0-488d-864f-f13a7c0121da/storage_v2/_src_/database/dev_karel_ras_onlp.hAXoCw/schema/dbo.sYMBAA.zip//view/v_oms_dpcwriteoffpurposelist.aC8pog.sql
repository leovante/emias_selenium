CREATE VIEW [V_oms_DPCWriteOffPurposeList] AS SELECT 
[hDED].[DPCWriteOffPurposeListID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ConsolidatedWPLID] as [rf_ConsolidatedWPLID], 
[hDED].[GUIDDoc] as [GUIDDoc], 
[hDED].[GUIDList] as [GUIDList], 
[hDED].[OrganisationCode] as [OrganisationCode], 
[hDED].[Num] as [Num], 
[hDED].[Date] as [Date], 
[hDED].[Note] as [Note], 
[hDED].[FLAGS] as [FLAGS]
FROM [oms_DPCWriteOffPurposeList] as [hDED]
go

