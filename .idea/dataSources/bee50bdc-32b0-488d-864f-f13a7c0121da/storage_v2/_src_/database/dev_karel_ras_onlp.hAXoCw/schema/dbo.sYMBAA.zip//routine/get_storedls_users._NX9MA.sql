
CREATE FUNCTION [dbo].[get_storedls_users](@userID int)
returns table
as 
return
(
select ras_StoredLS.StoredLSID, ras_Store.StoreID from ras_storedls 

join ras_store on rf_StoredID = StoreID and rf_StoredIDHost = HostStoreID 

where exists (
			SELECT TOP 1 'Сопоставлен' from ras_UserStoreVisible 
				WHERE rf_StoreID = ras_store.StoreID  AND 
				rf_UserID = @userID

			union all 
			SELECT TOP 1 'Админ'
			where @userID = 1 or 
			(
				select COUNT(*) from x_UserRole where UserID = @userID and RoleID = 
					(select RoleID from x_Role where [GUID] = '11111111-1111-1111-1111-111111111111')
			) = 1 
	)
)
go

