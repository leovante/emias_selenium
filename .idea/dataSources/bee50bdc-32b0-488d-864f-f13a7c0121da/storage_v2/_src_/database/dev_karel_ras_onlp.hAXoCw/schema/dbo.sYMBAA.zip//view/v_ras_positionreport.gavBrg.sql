CREATE VIEW [V_ras_PositionReport] AS SELECT 
[hDED].[PositionReportID], [hDED].[HostPositionReportID], [hDED].[x_Edition], [hDED].[x_Status], 
((ISNULL((SELECT top 1  TenderType_Name 
FROM oms_TenderType 
join ras_StoredLS on rf_TenderTypeID = TenderTypeID and hDed.rf_StoredLSID = ras_StoredLS.StoredLSID 
			  and hDed.rf_StoredLSIDHost = ras_StoredLS.HostStoredLSID),''))) as [V_TenderTypeName], 
(dbo.ras_ConvertToFraction(hDED.Count,(select top 1 Severability1 * Severability2 from ras_Nomenclature nom 	INNER JOIN ras_StoredLS ON ras_StoredLS.rf_NomenclatureID = nom.NomenclatureID 	and ras_StoredLS.rf_NomenclatureIDHost = nom.HostNomenclatureID))) as [V_FractionCount], 
[jT_ras_NDS].[NDS_Name] as [V_NDSName], 
[jT_ras_Nomenclature].[Name] as [V_NomenclatureName], 
[hDED].[rf_NDS] as [rf_NDS], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[hDED].[rf_ReportID] as [rf_ReportID], 
[hDED].[rf_ReportIDHost] as [rf_ReportIDHost], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_DPCPharmacyRecipeID] as [rf_DPCPharmacyRecipeID], 
[hDED].[rf_StatePositionReportID] as [rf_StatePositionReportID], 
[hDED].[rf_StateSenderPositionReportID] as [rf_StateSenderPositionReportID], 
[hDED].[rf_StateExpertPositionReportID] as [rf_StateExpertPositionReportID], 
[hDED].[rf_PositionStatusID] as [rf_PositionStatusID], 
[hDED].[Price] as [Price], 
[hDED].[Count] as [Count], 
[hDED].[PriceIN] as [PriceIN], 
[hDED].[Summa] as [Summa], 
[hDED].[Reward] as [Reward], 
[hDED].[C_PFS] as [C_PFS], 
[hDED].[SERIES] as [SERIES], 
[hDED].[Consigment] as [Consigment], 
[hDED].[SERT_NUM] as [SERT_NUM], 
[hDED].[GTD] as [GTD], 
[hDED].[SH_CODE] as [SH_CODE], 
[hDED].[EAN13] as [EAN13], 
[hDED].[RecipeGUID] as [RecipeGUID], 
[hDED].[IsMinus] as [IsMinus], 
[hDED].[C_LSFO] as [C_LSFO]
FROM [ras_PositionReport] as [hDED]
INNER JOIN [ras_NDS] as [jT_ras_NDS] on [jT_ras_NDS].[NDSID] = [hDED].[rf_NDS]
INNER JOIN [ras_Nomenclature] as [jT_ras_Nomenclature] on [jT_ras_Nomenclature].[NomenclatureID] = [hDED].[rf_NomenclatureID] AND  [jT_ras_Nomenclature].[HostNomenclatureID] = [hDED].[rf_NomenclatureIDHost]
go

