CREATE VIEW [V_oms_SMReestr] AS SELECT 
[hDED].[SMReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
((((((('Cчет '+  case when NSchet != 'не определено' then '№ '+NSchet+' ' else ' ' end+
case when rf_LPUID >0 then  ([jT_oms_LPU].[M_NAMES])
     when rf_STFID >0 then  ([jT_oms_STF].[TF_NAME])
     when rf_SMOID >0 then  ([jT_oms_SMO].[Q_NAME])
else ''
end
))))))) as [V_SMReestr], 
[jT_oms_SMO].[Q_NAME] as [V_Q_NAME], 
[jT_oms_LPU].[M_NAMES] as [V_M_NAMES], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_STFID] as [rf_STFID], 
[jT_oms_STF].[TF_NAME] as [SILENT_rf_STFID], 
[hDED].[rf_SMReestrTypeID] as [rf_SMReestrTypeID], 
[hDED].[rf_SMReestrStateID] as [rf_SMReestrStateID], 
[jT_oms_SMReestrState].[Name] as [SILENT_rf_SMReestrStateID], 
[hDED].[rf_MTReestrID] as [rf_MTReestrID], 
[hDED].[rf_SMReestrLoadStatusID] as [rf_SMReestrLoadStatusID], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[DateIn] as [DateIn], 
[hDED].[Data] as [Data], 
[hDED].[FileName] as [FileName], 
[hDED].[NSchet] as [NSchet], 
[hDED].[DSchet] as [DSchet], 
[hDED].[Code] as [Code], 
[hDED].[SumMav] as [SumMav], 
[hDED].[SumMap] as [SumMap], 
[hDED].[Coments] as [Coments], 
[hDED].[Flags] as [Flags], 
[hDED].[SMGuid] as [SMGuid], 
[hDED].[CODE_MO] as [CODE_MO], 
[hDED].[PLAT] as [PLAT], 
[hDED].[SANK_MEK] as [SANK_MEK], 
[hDED].[SANK_MEE] as [SANK_MEE], 
[hDED].[SANK_EKMP] as [SANK_EKMP], 
[hDED].[FileH] as [FileH], 
[hDED].[FileL] as [FileL]
FROM [oms_SMReestr] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_STF] as [jT_oms_STF] on [jT_oms_STF].[STFID] = [hDED].[rf_STFID]
INNER JOIN [oms_SMReestrState] as [jT_oms_SMReestrState] on [jT_oms_SMReestrState].[SMReestrStateID] = [hDED].[rf_SMReestrStateID]
go

