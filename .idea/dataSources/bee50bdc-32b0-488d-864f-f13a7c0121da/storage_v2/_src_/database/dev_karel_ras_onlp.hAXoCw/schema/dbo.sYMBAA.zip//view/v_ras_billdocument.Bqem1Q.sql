CREATE VIEW [V_ras_BillDocument] AS SELECT 
[hDED].[BillDocumentID], [hDED].[HostBillDocumentID], [hDED].[x_Edition], [hDED].[x_Status], 
(Select case
	   when count(us.ValueInt) > 0 and sum(us.ValueInt)>=1 and LEFT([hDED].[NUM],1)='p' then replace(Ltrim(Replace(RIGHT([hDED].[NUM],6),0, ' ')),' ',0)
	   else
	   [hDED].[NUM]
	   end
from x_UserSettings us where us.Property = 'TypeNumber') as [V_NUM], 
(Select StoreName from ras_Store where StoreID = [hDED].[rf_StoreID] and HostStoreID = [hDED].[rf_StoreIDHost]) as [V_STORENAME], 
[hDED].[rf_TypeDeliveryID] as [rf_TypeDeliveryID], 
[hDED].[rf_OrganisationClientID] as [rf_OrganisationClientID], 
[hDED].[rf_OrganisationClientIDHost] as [rf_OrganisationClientIDHost], 
[hDED].[rf_OrganisationProviderID] as [rf_OrganisationProviderID], 
[hDED].[rf_OrganisationProviderIDHost] as [rf_OrganisationProviderIDHost], 
[jT_ras_Organisation].[Name] as [SILENT_rf_OrganisationProviderID], 
[hDED].[rf_OrganisationOwnerID] as [rf_OrganisationOwnerID], 
[hDED].[rf_OrganisationOwnerIDHost] as [rf_OrganisationOwnerIDHost], 
[hDED].[rf_OrganisationByDemandID] as [rf_OrganisationByDemandID], 
[hDED].[rf_OrganisationByDemandIDHost] as [rf_OrganisationByDemandIDHost], 
[jT_ras_Organisation1].[Name] as [SILENT_rf_OrganisationByDemandID], 
[hDED].[rf_OrganisationAgentID] as [rf_OrganisationAgentID], 
[hDED].[rf_OrganisationAgentIDHost] as [rf_OrganisationAgentIDHost], 
[hDED].[rf_OrganisationContragent] as [rf_OrganisationContragent], 
[hDED].[rf_OrganisationContragentHost] as [rf_OrganisationContragentHost], 
[hDED].[rf_ResponsibleID] as [rf_ResponsibleID], 
[hDED].[rf_ResponsibleIDHost] as [rf_ResponsibleIDHost], 
[hDED].[rf_ResponsibleTempID] as [rf_ResponsibleTempID], 
[hDED].[rf_ResponsibleTempIDHost] as [rf_ResponsibleTempIDHost], 
[hDED].[rf_StateID] as [rf_StateID], 
[hDED].[rf_DogovorID] as [rf_DogovorID], 
[hDED].[rf_DogovorIDHost] as [rf_DogovorIDHost], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[jT_ras_Store].[StoreName] as [SILENT_rf_StoreID], 
[hDED].[rf_PeriodID] as [rf_PeriodID], 
[hDED].[rf_PeriodIDHost] as [rf_PeriodIDHost], 
[hDED].[rf_DocDescriptionID] as [rf_DocDescriptionID], 
[hDED].[rf_DocumentJournalID] as [rf_DocumentJournalID], 
[hDED].[rf_DocumentJournalIDHost] as [rf_DocumentJournalIDHost], 
[hDED].[rf_BillEx_OtherID] as [rf_BillEx_OtherID], 
[hDED].[rf_BillEx_OtherIDHost] as [rf_BillEx_OtherIDHost], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[hDED].[rf_SendStateID] as [rf_SendStateID], 
[hDED].[NUM] as [NUM], 
[hDED].[DocGUID] as [DocGUID], 
[hDED].[Date] as [Date], 
[hDED].[Date_fact] as [Date_fact], 
[hDED].[RapleUPR] as [RapleUPR], 
[hDED].[RapleNAL] as [RapleNAL], 
[hDED].[RapleBUH] as [RapleBUH], 
[hDED].[Temperature] as [Temperature], 
[hDED].[Author] as [Author], 
[hDED].[Consigment] as [Consigment], 
[hDED].[DateOP] as [DateOP], 
[hDED].[CodeProvider] as [CodeProvider], 
[hDED].[Sum] as [Sum], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[Note] as [Note], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[FLAGS] as [FLAGS]
FROM [ras_BillDocument] as [hDED]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationProviderID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationProviderIDHost]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation1] on [jT_ras_Organisation1].[OrganisationID] = [hDED].[rf_OrganisationByDemandID] AND  [jT_ras_Organisation1].[HostOrganisationID] = [hDED].[rf_OrganisationByDemandIDHost]
INNER JOIN [ras_Store] as [jT_ras_Store] on [jT_ras_Store].[StoreID] = [hDED].[rf_StoreID] AND  [jT_ras_Store].[HostStoreID] = [hDED].[rf_StoreIDHost]
go

