
CREATE PROCEDURE [dbo].[ChangeLsCod_NoNameless](@oldCode bigint, @newCode bigint)
AS
declare @errorMessage varchar(max)

BEGIN
	if (@newCode = @oldCode)
		begin
			set @errorMessage = 'Нельзя схлопнуть ЛС. Новый код равен старому: ' + cast(@newCode as varchar(max));
			RAISERROR (@errorMessage, 18, 1);
		end
	else
		begin
			if not exists (select * from oms_CollapseHistory where OldCode = @oldCode and NewCode <> @newCode)
				begin
					BEGIN TRY 
					declare @newLsID int; --ID ЛС с положительным кодом
					select @newLsID = LSID from oms_LS where NOMK_LS = @newCode;
					declare @oldLsID int; --ID ЛС с отрицательным кодом
					select @oldLsID = LSID from oms_LS where NOMK_LS = @oldCode;
					--обезличенные наименования
					declare @OldNameLSID int;
					Select @OldNameLSID = rf_NamelessID from oms_Nameless_LS where rf_LSID = @oldLsID;
					declare @NewNameLSID int;
					Select @NewNameLSID = rf_NamelessID from oms_Nameless_LS where rf_LSID = @newLsID

					--
					if (@newLsID is null)
					begin
						-- добавляем положительный ЛС из РЛС
						exec dbo.ImportLSFromRLS @newCode
						select @newLsID = LSID from oms_LS where NOMK_LS = @newCode;
					end
	
					if (@newLsID is not null and @oldLsID is not null)
					begin
	
						declare @ignoredTables string_list;
						insert into @ignoredTables(string_item)
						values ('oms_in_LS'), ('oms_Nameless_LS')

						exec  RefUpdateWithIgnore 'OMS', 'rf_LSID%', @ignoredTables, @oldLsID, @newLsID
		        
						if (@OldNameLSID is not null and @NewNameLSID is null)
						begin
						  Update oms_Nameless_LS
						  set rf_LSID = @newLsID
						  where rf_LSID =  @oldLsID
						end

						exec  Ref_update 'DEMAND', 'rf_LSID%', @oldLsID, @newLsID
		
					end
					END TRY
					BEGIN CATCH
						SELECT 
							ERROR_NUMBER() AS ErrorNumber,
							ERROR_MESSAGE() AS ErrorMessage;
					END CATCH

					update oms_LS
					set rf_GroupIMNID = 
							isnull((
								select top 1 rf_GroupIMNID from oms_LS where LSID = @oldLsID
							), 0)
					where LSID = @newLsID and rf_GRoupImnID = 0

					update oms_LS
					set FCode = 
						isnull((
							select top 1 FCode from oms_LS where LSID = @oldLsID
						), 0)
					where LSID = @newLsID and FCode = 0

					begin try 
						if (SELECT COUNT(*) from oms_CollapseHistory where OldCode = @oldCode and NewCode = @newCode) = 0
						begin
							insert into oms_CollapseHistory(x_Edition, x_Status, OldCode, NewCode, CollapseDate, UGUID, IsSuccessCod, IsSuccessAu)
							values(1, 1, @oldCode, @newCode, GETDATE(), NEWID(), 1, 0)
						end
						else
						begin
							update oms_CollapseHistory 
							set CollapseDate = GETDATE(), IsSuccessCod = 1
							where OldCode = @oldCode and NewCode = @newCode
						end

						Update oms_LS
						set Date_E = GETDATE()
						where nomk_ls = @oldCode

					end try
					begin catch
						SELECT 
							ERROR_NUMBER() AS ErrorNumber,
							ERROR_MESSAGE() AS ErrorMessage;
					end catch
				end
			else
				begin
					set @errorMessage = 'В CollapseHistory существует правило со старым кодом: ' + cast(@oldCode as varchar(max));
					RAISERROR (@errorMessage, 18, 1);
				end
		end
END
go

