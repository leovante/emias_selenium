CREATE VIEW [V_ras_Production] AS SELECT 
[hDED].[ProductionID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_ras_ProducedNomenclature].[V_Name] as [V_Name], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[hDED].[rf_WriteOffArticleID] as [rf_WriteOffArticleID], 
[hDED].[rf_WriteOffArticleIDHost] as [rf_WriteOffArticleIDHost], 
[hDED].[rf_PostingID] as [rf_PostingID], 
[hDED].[rf_PostingIDHost] as [rf_PostingIDHost], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID], 
[hDED].[rf_ProducedNomenclatureID] as [rf_ProducedNomenclatureID], 
[hDED].[Num] as [Num], 
[hDED].[Count] as [Count], 
[hDED].[Price] as [Price], 
[hDED].[Date] as [Date], 
[hDED].[DocGUID] as [DocGUID]
FROM [ras_Production] as [hDED]
INNER JOIN [V_ras_ProducedNomenclature] as [jT_ras_ProducedNomenclature] on [jT_ras_ProducedNomenclature].[ProducedNomenclatureID] = [hDED].[rf_ProducedNomenclatureID]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
go

