CREATE VIEW [V_oms_Period] AS SELECT 
[hDED].[PeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Period_Length] as [Period_Length], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Flags] as [Flags], 
[hDED].[Code] as [Code]
FROM [oms_Period] as [hDED]
go

