CREATE VIEW [Склады_список] AS SELECT	ras_Store.StoreName as [Склад]
FROM 	ras_Store
WHERE   ras_Store.StoreName <> ''
go

