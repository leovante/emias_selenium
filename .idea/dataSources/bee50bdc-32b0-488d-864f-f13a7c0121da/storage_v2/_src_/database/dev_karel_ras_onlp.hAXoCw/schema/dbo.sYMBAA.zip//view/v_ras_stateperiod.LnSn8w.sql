CREATE VIEW [V_ras_StatePeriod] AS SELECT 
[hDED].[StatePeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [ras_StatePeriod] as [hDED]
go

