CREATE VIEW [V_ras_PositionPosting] AS SELECT 
[hDED].[PositionPostingID], [hDED].[HostPositionPostingID], [hDED].[x_Edition], [hDED].[x_Status], 
((((ISNULL((Select TenderType_Name from dbo.oms_TenderType where TenderTypeID = hDED.rf_tendertypeID), ''))))) as [V_TenderTypeName], 
(dbo.ras_ConvertToFraction(hDED.Count,jT_ras_Nomenclature.Severability1*jT_ras_Nomenclature.Severability2)) as [V_FractionCount], 
[jT_ras_Nomenclature].[V_Producer] as [Producer], 
[jT_ras_Nomenclature].[Name] as [NameLS], 
[jT_ras_Organisation].[Name] as [V_Owner], 
[jT_ras_Nomenclature].[Cod_RAS] as [V_Cod_RAS], 
[jT_ras_Series].[Date_E] as [ExpDate], 
[jT_oms_Tender].[Num] as [V_TenderNum], 
[jT_ras_Series].[SertMSG] as [SertMSG], 
[hDED].[rf_OrganisationOwnerID] as [rf_OrganisationOwnerID], 
[hDED].[rf_OrganisationOwnerIDHost] as [rf_OrganisationOwnerIDHost], 
[hDED].[rf_OrganisationByDemandID] as [rf_OrganisationByDemandID], 
[hDED].[rf_OrganisationByDemandIDHost] as [rf_OrganisationByDemandIDHost], 
[jT_ras_Organisation1].[Name] as [SILENT_rf_OrganisationByDemandID], 
[hDED].[rf_NDSID] as [rf_NDSID], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[jT_ras_Nomenclature].[Name] as [SILENT_rf_NomenclatureID], 
[hDED].[rf_SeriesID] as [rf_SeriesID], 
[hDED].[rf_SeriesIDHost] as [rf_SeriesIDHost], 
[jT_ras_Series].[NUM] as [SILENT_rf_SeriesID], 
[hDED].[rf_LSFOID] as [rf_LSFOID], 
[hDED].[rf_LSFOIDHost] as [rf_LSFOIDHost], 
[jT_ras_LSFO].[C_LSProvider] as [SILENT_rf_LSFOID], 
[hDED].[rf_SubStoreID] as [rf_SubStoreID], 
[hDED].[rf_SubStoreIDHost] as [rf_SubStoreIDHost], 
[hDED].[rf_PostingID] as [rf_PostingID], 
[hDED].[rf_PostingIDHost] as [rf_PostingIDHost], 
[hDED].[rf_StatePositionPostingID] as [rf_StatePositionPostingID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[hDED].[rf_PositionStatusID] as [rf_PositionStatusID], 
[hDED].[rf_DeliveryCLSDateID] as [rf_DeliveryCLSDateID], 
[hDED].[Price] as [Price], 
[hDED].[Count] as [Count], 
[hDED].[Summa] as [Summa], 
[hDED].[EAN13] as [EAN13], 
[hDED].[Note] as [Note], 
[hDED].[DateReg] as [DateReg], 
[hDED].[GTD] as [GTD], 
[hDED].[SH_Code] as [SH_Code], 
[hDED].[Consigment] as [Consigment], 
[hDED].[Series] as [Series], 
[hDED].[PriceBase] as [PriceBase], 
[hDED].[PriceOPT] as [PriceOPT], 
[hDED].[RegNum] as [RegNum], 
[hDED].[Count_Up] as [Count_Up], 
[hDED].[SumNDS] as [SumNDS]
FROM [ras_PositionPosting] as [hDED]
INNER JOIN [V_ras_Nomenclature] as [jT_ras_Nomenclature] on [jT_ras_Nomenclature].[NomenclatureID] = [hDED].[rf_NomenclatureID] AND  [jT_ras_Nomenclature].[HostNomenclatureID] = [hDED].[rf_NomenclatureIDHost]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationOwnerID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationOwnerIDHost]
INNER JOIN [ras_Series] as [jT_ras_Series] on [jT_ras_Series].[SeriesID] = [hDED].[rf_SeriesID] AND  [jT_ras_Series].[HostSeriesID] = [hDED].[rf_SeriesIDHost]
INNER JOIN [oms_Tender] as [jT_oms_Tender] on [jT_oms_Tender].[TenderID] = [hDED].[rf_TenderID]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation1] on [jT_ras_Organisation1].[OrganisationID] = [hDED].[rf_OrganisationByDemandID] AND  [jT_ras_Organisation1].[HostOrganisationID] = [hDED].[rf_OrganisationByDemandIDHost]
INNER JOIN [ras_LSFO] as [jT_ras_LSFO] on [jT_ras_LSFO].[LSFOID] = [hDED].[rf_LSFOID] AND  [jT_ras_LSFO].[HostLSFOID] = [hDED].[rf_LSFOIDHost]
go

