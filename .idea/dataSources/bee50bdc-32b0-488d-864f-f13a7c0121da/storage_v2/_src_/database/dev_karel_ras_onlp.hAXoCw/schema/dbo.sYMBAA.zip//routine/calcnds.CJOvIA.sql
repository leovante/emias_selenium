

-- =============================================
-- Author:			<Author,,Name>
-- Create date:		<Create Date,,>
-- Description:		процедура расчета суммы НДС
-- Obsolete true	лучше не используйте
-- Last update:		15:29, 30.10.2009, Максименко Ал.
-- =============================================
CREATE PROCEDURE [dbo].[CalcNDS] 
@summa float,
@rate float
AS
BEGIN
     select @summa * (@rate/(1+@rate))
END
go

