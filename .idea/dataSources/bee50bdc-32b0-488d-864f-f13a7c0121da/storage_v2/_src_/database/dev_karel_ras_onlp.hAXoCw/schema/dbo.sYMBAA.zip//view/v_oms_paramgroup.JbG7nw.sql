CREATE VIEW [V_oms_ParamGroup] AS SELECT 
[hDED].[ParamGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[GUID] as [GUID]
FROM [oms_ParamGroup] as [hDED]
go

