CREATE VIEW [V_oms_Param] AS SELECT 
[hDED].[ParamID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ParamGroupID] as [rf_ParamGroupID], 
[jT_oms_ParamGroup].[Name] as [SILENT_rf_ParamGroupID], 
[hDED].[rf_UnitID] as [rf_UnitID], 
[jT_oms_Unit].[Name] as [SILENT_rf_UnitID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[MinValue] as [MinValue], 
[hDED].[MaxValue] as [MaxValue], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags]
FROM [oms_Param] as [hDED]
INNER JOIN [oms_ParamGroup] as [jT_oms_ParamGroup] on [jT_oms_ParamGroup].[ParamGroupID] = [hDED].[rf_ParamGroupID]
INNER JOIN [oms_Unit] as [jT_oms_Unit] on [jT_oms_Unit].[UnitID] = [hDED].[rf_UnitID]
go

