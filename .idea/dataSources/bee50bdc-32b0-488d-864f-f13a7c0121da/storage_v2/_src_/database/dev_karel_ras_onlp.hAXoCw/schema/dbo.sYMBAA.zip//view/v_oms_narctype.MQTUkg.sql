CREATE VIEW [V_oms_NarcType] AS SELECT 
[hDED].[NarcTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[GUIDNarc] as [GUIDNarc]
FROM [oms_NarcType] as [hDED]
go

