------------------------------------------------------------------------------
---Возвращает КРР по ИД отделения (DepartmentId) и дате 
------------------------------------------------------------------------------
create  FUNCTION  [dbo].[GetDepartmentKRR] (   @departmentID int, @dt datetime ) 
Returns decimal(18,2)  AS
begin
declare @r decimal(18,2)
 select @r=isnull(KrrDep.ValueKRR,1)* isnull( KrrType.valueKRR,1) * isnull(KrrLpu.ValueKRR,1)* isnull(KrrMainLpu.valueKRR,1) from oms_Department 
 left join oms_LPU on LPUID = oms_Department.rf_LPUID
 left join oms_Krr KrrDep on KrrDep.rf_DepartmentId= DepartmentId  and KrrDep.rf_DepartmentId>0 and  KrrDep.krrID>0 and KrrDep.Date_B<=@dt and KrrDep.Date_E>@dt
 left join oms_Krr KrrType on KrrType.rf_DepartmentId= 0 and KrrType.rf_LPUID=0 and KrrType.krrID>0 and   KrrType.Date_B<=@dt and KrrType.Date_E>@dt
 and KrrType.rf_kl_DepartmentTypeId =oms_Department.rf_kl_DepartmentTypeID 
 left join oms_Krr KrrLpu on KrrLpu.rf_LpuId= lpuid and KrrLpu.rf_kl_DepartmentTypeId =oms_Department.rf_kl_DepartmentTypeID and KrrLpu.KRRID>0 and   KrrLpu.Date_B<=@dt and KrrLpu.Date_E>@dt
 left join oms_Krr KrrMainLpu on KrrLpu.rf_LpuId= 0 and KrrLpu.rf_kl_DepartmentTypeId =oms_Department.rf_kl_DepartmentTypeID and KrrMainLpu.KRRID>0 and   KrrMainLpu.Date_B<=@dt and KrrMainLpu.Date_E>@dt
where departmentID=@departmentID 
return @r
END
go

