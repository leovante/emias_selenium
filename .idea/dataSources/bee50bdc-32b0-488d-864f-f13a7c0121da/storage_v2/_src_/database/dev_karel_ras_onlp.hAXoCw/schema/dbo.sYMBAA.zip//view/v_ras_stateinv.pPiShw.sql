CREATE VIEW [V_ras_StateInv] AS SELECT 
[hDED].[StateInvID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note]
FROM [ras_StateInv] as [hDED]
go

