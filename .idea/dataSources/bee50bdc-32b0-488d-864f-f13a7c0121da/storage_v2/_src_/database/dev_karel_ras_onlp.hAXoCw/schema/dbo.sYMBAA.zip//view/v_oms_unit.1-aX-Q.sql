CREATE VIEW [V_oms_Unit] AS SELECT 
[hDED].[UnitID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_sc_AgeRangeID] as [rf_sc_AgeRangeID], 
[jT_oms_sc_AgeRange].[V_Range] as [SILENT_rf_sc_AgeRangeID], 
[hDED].[rf_AmountID] as [rf_AmountID], 
[jT_oms_Amount].[Name] as [SILENT_rf_AmountID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Koef] as [Koef], 
[hDED].[DescRu] as [DescRu], 
[hDED].[DescInter] as [DescInter], 
[hDED].[Flags] as [Flags], 
[hDED].[Rate] as [Rate]
FROM [oms_Unit] as [hDED]
INNER JOIN [V_oms_sc_AgeRange] as [jT_oms_sc_AgeRange] on [jT_oms_sc_AgeRange].[sc_AgeRangeID] = [hDED].[rf_sc_AgeRangeID]
INNER JOIN [oms_Amount] as [jT_oms_Amount] on [jT_oms_Amount].[AmountID] = [hDED].[rf_AmountID]
go

