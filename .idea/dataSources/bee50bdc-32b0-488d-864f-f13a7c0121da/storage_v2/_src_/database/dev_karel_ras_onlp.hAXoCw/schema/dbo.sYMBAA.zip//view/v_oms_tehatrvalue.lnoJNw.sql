CREATE VIEW [V_oms_TehAtrValue] AS SELECT 
[hDED].[TehAtrValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_TehAtrID] as [rf_TehAtrID], 
[hDED].[Value] as [Value], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_TehAtrValue] as [hDED]
go

