
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateFromLife](@themeName varchar(max), @tableName varchar(max), @id int, @lifeid int)
AS
BEGIN
	declare @columns varchar(max)
	set @columns = 
	(select
	(
	select elem.Name + ' = ttt.' + elem.Name + ', ' from x_DocTypeDef doc
	join x_DocElemDef elem on doc.DocTypeDefID = elem.DocTypeDefID
	where HeadTable = @themename + '_' + @tablename and ElemType in (1, 2)
	for xml path('')
	) as columns)

	set @columns = SUBSTRING(@columns, 1, LEN(@columns) - 1)

	declare @SQL nvarchar(max);

	set @SQL = (select 'UPDATE ' + @themename + '_' + @tablename + ' SET ' + @columns + 
	' FROM ' + '(SELECT * FROM Life_' + @themename + '_' + @tablename + ' WHERE ' + @tablename +'LifeID = ' + 
	CONVERT(varchar(max), @lifeid) + ')ttt WHERE ttt.' + @tablename + 'ID = ' + CONVERT(varchar(max), @id))
	
	print @SQL

	EXECUTE sp_executesql @SQL
END
go

