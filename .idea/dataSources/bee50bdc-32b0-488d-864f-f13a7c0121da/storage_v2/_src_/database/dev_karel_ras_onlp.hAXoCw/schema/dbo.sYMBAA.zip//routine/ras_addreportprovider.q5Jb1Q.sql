
-- =============================================
-- Author:		Ганичев, Максименко
-- Create date: 18.02.1010
-- Description:	Добавляет отчеты комиссионера по новым поставщикам по всем складам
-- =============================================
CREATE PROCEDURE [dbo].[RAS_AddReportProvider] 
AS

insert into ras_report
	 ( [x_Edition]
      ,[x_Status]
      ,[Date]
      ,[rf_StoreID]
      ,[rf_OrganisationProviderID]
      ,[rf_OrganisationClientID]
      ,[rf_DogovorID]
      ,[rf_TypeReportID]
      ,[PR_Reward]
      ,[Num]
      ,[V_TypeReport]
      ,[Load_Send]
      ,[rf_StateReportID]
      ,[rf_UserID]
      ,[isStorned]
      ,[rf_PeriodID]
      ,[TypePost]
      ,[Note]
      ,[Summa]
      ,[rf_OrganisationProviderIDHost]
      ,[rf_OrganisationClientIDHost]
      ,[rf_PeriodIDHost]
      ,[rf_StoreIDHost]
      ,[rf_DogovorIDHost]      
      ,[DateCreate]
      , [rf_DocDescriptionID] 
      ) 
			select 
				1 as x_Edition, 
				1 as x_Status, 
				(
					select 
						Date_B 
					from ras_Period 
					where 
						Date_B = 
						(
							select 
								max(Date_B) 
							from ras_Period
						)
				) as Date,
				ras_Store.StoreID as rf_storeID,
				prov.OrganisationID as rf_OrganisationProviderID ,
				client.OrganisationID as rf_OrganisationClientID, 
				client.rf_DogovorID as rf_DogovorID,
				2 as rf_TypeReportID, 
				5.00 as PR_Reward,
				( 
					(
						select substring(MAX(NUM), 1, 5) from ras_Report
					)
					---Вставляем 0
					+
					Replace(Space( 6-len( convert (varchar,
					(
						select 
							convert(int, substring(MAX(NUM), 6, 11)) 
						from ras_Report
					)
					+ ROW_NUMBER() OVER (ORDER BY storeID )) )),' ','0') 
					--Выводим значение инкрименированного номера 
					+
					convert (varchar,
					(
						select 
							convert(int, substring(MAX(NUM), 6, 11)) 
						from ras_Report
					) 
					+ ROW_NUMBER() OVER (ORDER BY storeID ))) as NUm ,

				'' as V_TypeReport,
				0 as Load_Send,
				1 as rf_StateReportID,
				
				0 as rf_UserID,
				0 as isStorned,
				(
					select 
						PeriodID 
					from ras_Period 
					where 
						Date_B = 
						(
							select 
								max(Date_B) 
							from ras_Period
						)
				) as rf_PeriodID,
				ras_TypeDelivery.code  as TypePost, 
				'' as Note,
				0.00 as Summa
				,999 as [rf_OrganisationProviderIDHost]
				,999 as [rf_OrganisationClientIDHost]
				,999 as [rf_PeriodIDHost]				
				,dbo.GetSelfHost() as [rf_StoreIDHost]
				,999 as [rf_DogovorIDHost]				
				,getdate() as [DateCreate]
				, 9 as [rf_DocDescriptionID]

			-- select *
			FROM ras_Organisation client
				INNER JOIN ras_Store ON 
					client.OrganisationID = ras_Store.rf_OrganisationID and 
					client.HostOrganisationID = ras_Store.rf_OrganisationIDHost 				
				INNER JOIN ras_TypeDelivery ON ras_Store.rf_TypeDeliveryID = ras_TypeDelivery.TypeDeliveryID

				INNER JOIN ras_Organisation prov on prov.OrganisationID > 0 
				inner join oms_SFO on oms_SFO.CFO=prov.CODE and oms_SFO.FO_OGRN=prov.OGRN
				inner join ras_Provider on prov.OrganisationID =ras_Provider.rf_OrganisationID

				left join ras_Report on ras_Report.rf_StoreID=StoreID and ras_Report.rf_OrganisationProviderID = prov.OrganisationID
							and ras_Report.rf_PeriodID = (
										select 
											PeriodID 
										from ras_Period 
										where 
											Date_B = 
											(
												select 
													max(Date_B) 
												from ras_Period
											)
									)
			where 
				client.OrganisationID != 0 
				and client.isActive = 1 
				and TypeDeliveryID <> 6
				--and TypeDeliveryID in (3,5,6)
				and ras_Report.rf_StoreID is null
go

