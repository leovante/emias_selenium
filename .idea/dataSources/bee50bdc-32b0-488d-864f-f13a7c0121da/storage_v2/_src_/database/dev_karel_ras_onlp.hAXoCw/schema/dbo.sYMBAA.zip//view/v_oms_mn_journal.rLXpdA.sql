CREATE VIEW [V_oms_mn_Journal] AS SELECT 
[hDED].[mn_JournalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_mn_PersonID] as [rf_mn_PersonID], 
[jT_oms_mn_Person].[V_FIO] as [SILENT_rf_mn_PersonID], 
[hDED].[rf_mn_InfoID] as [rf_mn_InfoID], 
[jT_oms_mn_Info].[InfoGuid] as [SILENT_rf_mn_InfoID], 
[hDED].[rf_mn_IdentID] as [rf_mn_IdentID], 
[jT_oms_mn_Ident].[SS] as [SILENT_rf_mn_IdentID], 
[hDED].[rf_mn_AddressID] as [rf_mn_AddressID], 
[jT_oms_mn_Address].[RegAddress_Str] as [SILENT_rf_mn_AddressID], 
[hDED].[rf_mn_contactID] as [rf_mn_contactID], 
[jT_oms_mn_contact].[Phone] as [SILENT_rf_mn_contactID], 
[hDED].[rf_mn_DocIdentID] as [rf_mn_DocIdentID], 
[jT_oms_mn_DocIdent].[rf_TypeDocID] as [SILENT_rf_mn_DocIdentID], 
[hDED].[rf_mn_PolisID] as [rf_mn_PolisID], 
[jT_oms_mn_Polis].[rf_SMOID] as [SILENT_rf_mn_PolisID], 
[hDED].[rf_mn_DocLPUID] as [rf_mn_DocLPUID], 
[jT_oms_mn_DocLPU].[Name] as [SILENT_rf_mn_DocLPUID], 
[hDED].[SourceGuid] as [SourceGuid], 
[hDED].[RegNum] as [RegNum], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Flags] as [Flags]
FROM [oms_mn_Journal] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [V_oms_mn_Person] as [jT_oms_mn_Person] on [jT_oms_mn_Person].[mn_PersonID] = [hDED].[rf_mn_PersonID]
INNER JOIN [oms_mn_Info] as [jT_oms_mn_Info] on [jT_oms_mn_Info].[mn_InfoID] = [hDED].[rf_mn_InfoID]
INNER JOIN [oms_mn_Ident] as [jT_oms_mn_Ident] on [jT_oms_mn_Ident].[mn_IdentID] = [hDED].[rf_mn_IdentID]
INNER JOIN [oms_mn_Address] as [jT_oms_mn_Address] on [jT_oms_mn_Address].[mn_AddressID] = [hDED].[rf_mn_AddressID]
INNER JOIN [oms_mn_contact] as [jT_oms_mn_contact] on [jT_oms_mn_contact].[mn_contactID] = [hDED].[rf_mn_contactID]
INNER JOIN [oms_mn_DocIdent] as [jT_oms_mn_DocIdent] on [jT_oms_mn_DocIdent].[mn_DocIdentID] = [hDED].[rf_mn_DocIdentID]
INNER JOIN [oms_mn_Polis] as [jT_oms_mn_Polis] on [jT_oms_mn_Polis].[mn_PolisID] = [hDED].[rf_mn_PolisID]
INNER JOIN [oms_mn_DocLPU] as [jT_oms_mn_DocLPU] on [jT_oms_mn_DocLPU].[mn_DocLPUID] = [hDED].[rf_mn_DocLPUID]
go

