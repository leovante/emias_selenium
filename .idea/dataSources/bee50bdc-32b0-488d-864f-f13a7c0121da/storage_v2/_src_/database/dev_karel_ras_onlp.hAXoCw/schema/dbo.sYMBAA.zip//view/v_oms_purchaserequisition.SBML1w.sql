CREATE VIEW [V_oms_PurchaseRequisition] AS SELECT 
[hDED].[PurchaseRequisitionID], [hDED].[x_Edition], [hDED].[x_Status], 
((select SUM(delivery.Count * pos.Price)
	from oms_ProtokolDelivery delivery
		inner join oms_ProtokolPos pos on delivery.rf_ProtokolPosID = pos.ProtokolPosID		
	where delivery.rf_PurchaseRequisitionID = PurchaseRequisitionID)) as [V_SummBefore], 
((select SUM(delivery.Count * pos.PriceAfter)
	from oms_ProtokolDelivery delivery
		inner join oms_ProtokolPos pos on delivery.rf_ProtokolPosID = pos.ProtokolPosID		
	where delivery.rf_PurchaseRequisitionID = PurchaseRequisitionID)) as [V_SummAfter], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[jT_oms_Tender].[Num] as [SILENT_rf_TenderID], 
[hDED].[rf_ProtokolID] as [rf_ProtokolID], 
[jT_oms_Protokol].[Num] as [SILENT_rf_ProtokolID], 
[hDED].[rf_SendStateID] as [rf_SendStateID], 
[jT_oms_SendState].[Description] as [SILENT_rf_SendStateID]
FROM [oms_PurchaseRequisition] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_Tender] as [jT_oms_Tender] on [jT_oms_Tender].[TenderID] = [hDED].[rf_TenderID]
INNER JOIN [oms_Protokol] as [jT_oms_Protokol] on [jT_oms_Protokol].[ProtokolID] = [hDED].[rf_ProtokolID]
INNER JOIN [oms_SendState] as [jT_oms_SendState] on [jT_oms_SendState].[SendStateID] = [hDED].[rf_SendStateID]
go

