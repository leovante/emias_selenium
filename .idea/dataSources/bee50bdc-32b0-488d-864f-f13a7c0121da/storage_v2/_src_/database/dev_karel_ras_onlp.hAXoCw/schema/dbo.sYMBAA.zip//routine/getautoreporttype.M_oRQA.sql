-- получение режима списания товара со склада
create function GetAutoReportType()
	returns int
as
begin
	declare @type int
	set @type = (select ValueStr from x_UserSettings
	where 
		[Property] = 'AutoReportType' and
		[OwnerGUID] =  '{00000000-0000-0000-0000-000000000000}' and
		[DocTypeDefGUID] = '{00000000-0000-0000-0000-000000000000}' and
		[rf_SettingTypeID] = 7)
	return @type
end
go

