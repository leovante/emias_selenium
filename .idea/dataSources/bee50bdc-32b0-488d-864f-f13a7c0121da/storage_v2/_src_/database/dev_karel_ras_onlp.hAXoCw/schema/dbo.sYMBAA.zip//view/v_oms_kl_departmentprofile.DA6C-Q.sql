CREATE VIEW [V_oms_kl_DepartmentProfile] AS SELECT 
[hDED].[kl_DepartmentProfileID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_DepartmentProfileCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_DepartmentProfile] as [hDED]
go

