CREATE VIEW [V_ras_DocumentJournal] AS SELECT 
[hDED].[DocumentJournalID], [hDED].[HostDocumentJournalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TypeDeliveryID] as [rf_TypeDeliveryID], 
[jT_ras_TypeDelivery].[Name] as [SILENT_rf_TypeDeliveryID], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_OrganisationIDHost] as [rf_OrganisationIDHost], 
[hDED].[rf_DocDescriptionID] as [rf_DocDescriptionID], 
[hDED].[Num] as [Num], 
[hDED].[Date] as [Date], 
[hDED].[DocID] as [DocID], 
[hDED].[SummaDoc] as [SummaDoc], 
[hDED].[CountUP] as [CountUP], 
[hDED].[KontrSumm] as [KontrSumm], 
[hDED].[State] as [State], 
[hDED].[DocGUID] as [DocGUID]
FROM [ras_DocumentJournal] as [hDED]
INNER JOIN [ras_TypeDelivery] as [jT_ras_TypeDelivery] on [jT_ras_TypeDelivery].[TypeDeliveryID] = [hDED].[rf_TypeDeliveryID]
go

