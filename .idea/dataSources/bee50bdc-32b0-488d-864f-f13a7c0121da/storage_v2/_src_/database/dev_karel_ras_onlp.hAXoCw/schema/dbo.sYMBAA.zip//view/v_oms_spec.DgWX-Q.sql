CREATE VIEW [V_oms_Spec] AS SELECT 
[hDED].[SpecID], [hDED].[x_Edition], [hDED].[x_Status], 
(((Code))) as [Code_Spec], 
[hDED].[Spec_Name] as [Spec_Name], 
[hDED].[Spec_Rem] as [Spec_Rem], 
[hDED].[Code] as [Code], 
[hDED].[GUIDSpec] as [GUIDSpec]
FROM [oms_Spec] as [hDED]
go

