CREATE VIEW [V_oms_ParamValue] AS SELECT 
[hDED].[ParamValueID], [hDED].[x_Edition], [hDED].[x_Status], 
(((select FIO from x_User where UserId = MedUserID))) as [V_UserFIO], 
[jT_oms_ParamVar].[rf_ParamID] as [V_rf_ParamID], 
[hDED].[rf_ParamVarID] as [rf_ParamVarID], 
[jT_oms_ParamVar].[Code] as [SILENT_rf_ParamVarID], 
[hDED].[Value] as [Value], 
[hDED].[Date] as [Date], 
[hDED].[GUIDParamValue] as [GUIDParamValue], 
[hDED].[MedUserID] as [MedUserID], 
[hDED].[DocGUID] as [DocGUID], 
[hDED].[PatientGUID] as [PatientGUID], 
[hDED].[Flags] as [Flags]
FROM [oms_ParamValue] as [hDED]
INNER JOIN [oms_ParamVar] as [jT_oms_ParamVar] on [jT_oms_ParamVar].[ParamVarID] = [hDED].[rf_ParamVarID]
go

