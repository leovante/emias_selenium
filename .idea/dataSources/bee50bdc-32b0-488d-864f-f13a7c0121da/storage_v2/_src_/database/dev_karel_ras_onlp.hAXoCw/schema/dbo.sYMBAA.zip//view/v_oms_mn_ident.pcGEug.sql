CREATE VIEW [V_oms_mn_Ident] AS SELECT 
[hDED].[mn_IdentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_mn_PersonID] as [rf_mn_PersonID], 
[jT_oms_mn_Person].[V_FIO] as [SILENT_rf_mn_PersonID], 
[hDED].[SS] as [SS], 
[hDED].[SocialNumber] as [SocialNumber], 
[hDED].[ENP] as [ENP], 
[hDED].[INN] as [INN], 
[hDED].[IdentGuid] as [IdentGuid], 
[hDED].[IsActive] as [IsActive], 
[hDED].[Flags] as [Flags], 
[hDED].[SS_Find] as [SS_Find]
FROM [oms_mn_Ident] as [hDED]
INNER JOIN [V_oms_mn_Person] as [jT_oms_mn_Person] on [jT_oms_mn_Person].[mn_PersonID] = [hDED].[rf_mn_PersonID]
go

