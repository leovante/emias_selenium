CREATE VIEW [V_ras_StatePositionWriteOffArticle] AS SELECT 
[hDED].[StatePositionWriteOffArticleID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Cod] as [Cod], 
[hDED].[Name] as [Name]
FROM [ras_StatePositionWriteOffArticle] as [hDED]
go

