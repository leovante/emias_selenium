-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[f263_tfReport_Direction]
(	
 @dateA datetime,
 @dateB datetime
)
RETURNS TABLE 
AS
RETURN 
(
select 
		oms_OKATO.C_OKATO,
		oms_OKATO.O_NAME,
		l1.LPUID,
		l1.MCOD,
		l1.M_NAMES,
		bf.Name as BedProfileName,
		(select count(1) from oms_hs_Direction d where d.DirDate between @dateA and @dateB and d.ProfilBed = dir.ProfilBed  and d.rf_DirLPUID = l1.LPUID)					as DirAllCount,
		(select count(1) from oms_hs_Direction d where d.DirDate between @dateA and @dateB and d.ProfilBed = dir.ProfilBed  and d.rf_DirLPUID = l1.LPUID and d.state = 2) as DirHospCount,
		(select count(1) from oms_hs_Direction d where d.DirDate between @dateA and @dateB and d.ProfilBed = dir.ProfilBed  and d.rf_DirLPUID = l1.LPUID and d.state = 3) as DirAnulCount,
		(select count(1) from oms_hs_Direction d where d.DirDate between @dateA and @dateB and d.ProfilBed = dir.ProfilBed  and d.rf_DirLPUID = l1.LPUID and d.state = 1) as DirWaitCount,(
		(select count(1) from oms_hs_Direction d where d.DirDate between @dateA and @dateB and d.ProfilBed = dir.ProfilBed  and d.rf_DirLPUID = l1.LPUID and d.state = 1 and (datediff(day, d.DateHospPlan, getdate()) > 15)) +
		(select count(1) from oms_hs_Direction d where d.DirDate between @dateA and @dateB and d.ProfilBed = dir.ProfilBed  and d.rf_DirLPUID = l1.LPUID and d.state = 2 and (datediff(day, d.DateHospPlan, d.DateFact) > 15))
		) as DirLateCount
	from oms_LPU l1
		inner join oms_OKATO on l1.rf_OKATOID = oms_OKATO.OKATOID
		left join oms_hs_Direction dir on l1.LPUID = dir.rf_DirLPUID
		left join stt_BedProfile bf on dir.ProfilBed = bf.code
	where l1.lpuid > 0
	group by 
		oms_OKATO.C_OKATO,
		oms_OKATO.O_NAME,
		l1.LPUID,
		l1.MCOD,
		l1.M_NAMES,
		bf.Name,
		dir.ProfilBed 

)

go

