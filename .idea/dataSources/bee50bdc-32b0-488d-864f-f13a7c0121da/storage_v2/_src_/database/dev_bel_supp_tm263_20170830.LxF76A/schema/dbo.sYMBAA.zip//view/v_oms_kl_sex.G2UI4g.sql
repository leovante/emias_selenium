CREATE VIEW [V_oms_kl_Sex] AS SELECT 
[hDED].[kl_SexID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_SexCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [oms_kl_Sex] as [hDED]
go

