-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[f263_TFReport_HospByPeriod_Reg_LPU_Prof_20150128]
(
	@dateA datetime, @dateB datetime
)
RETURNS xml
AS
BEGIN

declare @LateDayCnt int = 14

declare @TempTable table (
	id int ,
	id2 int,

	OKATOID int,
	O_NAME varchar(200),

	LPUID int,
	M_NAMES varchar(250),

	BedProfileID int,
	BedProfileName varchar(250),

	[HospAllCnt] int,
	[HospLate] int,
	[Extr] int,
	[Plan] int,
	[PlanLate] int,
	[Canceld] int,
	[CanceldLate] int,	

	[OutPat] int,	

	level_field int,
	parent_id_field varchar(10),
	leaf_field varchar(10),
	expanded_field varchar(10)
	)


	insert into @TempTable
	SELECT
		0 as id,
		0 as id2,

		oms_OKATO.OKATOID,
		oms_OKATO.O_NAME,

		oms_LPU.LPUID,
		oms_LPU.M_NAMES,

		stt_BedProfile.BedProfileID,
		stt_BedProfile.Name,

		(select count(*) from oms_hs_Hospital h0 where h0.DateTimeFact between @dateA and @dateB and h0.rf_LPUID = oms_LPU.LPUID and h0.ProfilBed = stt_BedProfile.Code) as HospAllCnt,
		(select count(*) from oms_hs_Hospital h0 inner join oms_hs_Direction d on d.rf_hs_HospitalID = h0.hs_HospitalID where h0.DateTimeFact between @dateA and @dateB and h0.rf_LPUID = oms_LPU.LPUID and h0.ProfilBed = stt_BedProfile.Code and DATEDIFF(day, d.DateHospPlan, h0.DateTimeFact) >= @LateDayCnt) as HospLate,
		(select count(*) from oms_hs_Hospital h0 where h0.DateTimeFact between @dateA and @dateB and h0.rf_LPUID = oms_LPU.LPUID and h0.ProfilBed = stt_BedProfile.Code and h0.Extr = 3) as Extr,

		(select count(*) from oms_hs_Direction d where d.State = 1 and d.DateHospPlan <= @dateB and d.rf_LPUID = oms_LPU.LPUID and d.ProfilBed = stt_BedProfile.Code ) as [Plan],
		(select count(*) from oms_hs_Direction d where d.State = 1 and d.DateHospPlan <= @dateB and d.rf_LPUID = oms_LPU.LPUID and d.ProfilBed = stt_BedProfile.Code and DATEDIFF(day, d.DateHospPlan, d.RevocationDate) >= @LateDayCnt) as PlanLate,

		(select count(*) from oms_hs_Direction d where d.State = 3 and d.RevocationDate between @dateA and @dateB and d.rf_LPUID = oms_LPU.LPUID and d.ProfilBed = stt_BedProfile.Code) as Canceld,
		(select count(*) from oms_hs_Direction d where d.State = 3 and d.RevocationDate between @dateA and @dateB and d.rf_LPUID = oms_LPU.LPUID and d.ProfilBed = stt_BedProfile.Code and DATEDIFF(day, d.DateHospPlan, d.RevocationDate) >= @LateDayCnt) as CanceldLate,

		(select count(*) from oms_hs_Hospital h0 where h0.DateExit between @dateA and @dateB and h0.rf_LPUID = oms_LPU.LPUID and h0.ProfilBed = stt_BedProfile.Code and h0.State = 2) as [OutPat],

		2,
		'',
		'true',
		'false'
	from
		stt_BedProfile
		inner join oms_hs_DepartmentBed on oms_hs_DepartmentBed.rf_ProfileID = stt_BedProfile.BedProfileID
		inner join oms_hs_LpuDepartment on oms_hs_DepartmentBed.rf_hs_LpuDepartmentID = oms_hs_LpuDepartment.hs_LpuDepartmentID
		inner join oms_LPU on oms_LPU.LPUID = oms_hs_LpuDepartment.rf_LPUID
		inner join oms_OKATO on oms_LPU.rf_OKATOID = oms_OKATO.OKATOID	
		WHERE oms_LPU.LPUID > 0
	GROUP BY oms_OKATO.OKATOID, oms_OKATO.O_NAME, oms_LPU.LPUID, oms_LPU.M_NAMES, stt_BedProfile.BedProfileID, stt_BedProfile.Code, stt_BedProfile.Name
	
	union all
	SELECT
		0 as id,
		0 as id2,

		oms_OKATO.OKATOID,
		oms_OKATO.O_NAME,

		oms_LPU.LPUID,
		oms_LPU.M_NAMES,

		9999 as BedProfileID,
		'<Без профиля или отсутствующий профиль>' as Name,

		0 as HospAllCnt,
		0 as HospLate,
		0 as Extr,

		(select count(*) from oms_hs_Direction d where d.State = 1 and d.DateHospPlan <= @dateB and d.rf_LPUID = oms_LPU.LPUID and d.ProfilBed not in 
			(
				select distinct stt_BedProfile.Code from stt_BedProfile
				inner join oms_hs_DepartmentBed on oms_hs_DepartmentBed.rf_ProfileID = stt_BedProfile.BedProfileID
				inner join oms_hs_LpuDepartment on oms_hs_DepartmentBed.rf_hs_LpuDepartmentID = oms_hs_LpuDepartment.hs_LpuDepartmentID
				where oms_hs_LpuDepartment.rf_LPUID = oms_LPU.LPUID					
			) 
		) as [Plan],
		(select count(*) from oms_hs_Direction d where d.State = 1 and d.DateHospPlan <= @dateB and d.rf_LPUID = oms_LPU.LPUID and d.ProfilBed not in 
			(
				select distinct stt_BedProfile.Code from stt_BedProfile
				inner join oms_hs_DepartmentBed on oms_hs_DepartmentBed.rf_ProfileID = stt_BedProfile.BedProfileID
				inner join oms_hs_LpuDepartment on oms_hs_DepartmentBed.rf_hs_LpuDepartmentID = oms_hs_LpuDepartment.hs_LpuDepartmentID
				where oms_hs_LpuDepartment.rf_LPUID = oms_LPU.LPUID					
			) 
		 and DATEDIFF(day, d.DateHospPlan, @dateB) >= @LateDayCnt) as PlanLate,

		(select count(*) from oms_hs_Direction d where d.State = 3 and d.RevocationDate between @dateA and @dateB and d.rf_LPUID = oms_LPU.LPUID and d.ProfilBed not in 
			(
				select distinct stt_BedProfile.Code from stt_BedProfile
				inner join oms_hs_DepartmentBed on oms_hs_DepartmentBed.rf_ProfileID = stt_BedProfile.BedProfileID
				inner join oms_hs_LpuDepartment on oms_hs_DepartmentBed.rf_hs_LpuDepartmentID = oms_hs_LpuDepartment.hs_LpuDepartmentID
				where oms_hs_LpuDepartment.rf_LPUID = oms_LPU.LPUID					
			) 
		) as Canceld,
		(select count(*) from oms_hs_Direction d where d.State = 3 and d.RevocationDate between @dateA and @dateB and d.rf_LPUID = oms_LPU.LPUID and d.ProfilBed not in 
			(
				select distinct stt_BedProfile.Code from stt_BedProfile
				inner join oms_hs_DepartmentBed on oms_hs_DepartmentBed.rf_ProfileID = stt_BedProfile.BedProfileID
				inner join oms_hs_LpuDepartment on oms_hs_DepartmentBed.rf_hs_LpuDepartmentID = oms_hs_LpuDepartment.hs_LpuDepartmentID
				where oms_hs_LpuDepartment.rf_LPUID = oms_LPU.LPUID					
			) 
		 and DATEDIFF(day, d.DateHospPlan, d.RevocationDate) >= @LateDayCnt) as CanceldLate,
		0 as [OutPat],

		2,
		'',
		'true',
		'false'
	from oms_LPU 
		inner join oms_OKATO on oms_LPU.rf_OKATOID = oms_OKATO.OKATOID	
		inner join oms_hs_Direction on oms_hs_Direction.rf_LPUID = oms_LPU.LPUID
		WHERE oms_LPU.LPUID > 0 and oms_hs_Direction.DateHospPlan <= @dateB and oms_hs_Direction.State = 1 and oms_hs_Direction.ProfilBed = '0' 
	GROUP BY oms_OKATO.OKATOID, oms_OKATO.O_NAME, oms_LPU.LPUID, oms_LPU.M_NAMES
	
	
	order by oms_OKATO.O_NAME, oms_LPU.M_NAMES, stt_BedProfile.Name




	
-- Добавляем уровень 0 - Region
insert into @TempTable  
select  0 as id,
		0 as id2,

		OKATOID,
		O_NAME,

		0 as LPUID,
		'' as M_NAMES,

		0 as BedProfileID,
		'' as BedProfileName,

		sum(HospAllCnt),
		sum(HospLate),
		sum(Extr),
		sum([Plan]),
		sum(PlanLate),
		sum(Canceld),
		sum(CanceldLate),
		sum([OutPat]),

		0,
		'',
		case when count(1) = 0 then 'true' else 'false' end,
		'false'
 from @TempTable where level_field = 2
 group by OkatoID, O_NAME



 -- Добавляем уровень 1 - LPU
insert into @TempTable
select  0 as id,
		0 as id2,

		OKATOID,
		O_NAME,

		LPUID as LPUID,
		M_NAMES as M_NAMES,

		0 as BedProfileID,
		'' as BedProfileName,

		sum(HospAllCnt),
		sum(HospLate),
		sum(Extr),
		sum([Plan]),
		sum(PlanLate),
		sum(Canceld),
		sum(CanceldLate),
		sum([OutPat]),

		1,
		'',
		case when count(1) = 0 then 'true' else 'false' end,
		'false'
 from @TempTable where level_field = 2
 group by OkatoID, O_NAME, LPUID, M_NAMES

-- Проставляем ID-шники 
UPDATE tt
set id = t.RowID,
	id2 = t.RowID
FROM @TempTable tt
inner join
(
	select ROW_NUMBER() OVER(ORDER BY  O_NAME, m_names, BedProfileName) AS RowID, BedProfileID, OkatoID, LPUID from @TempTable
) as t

on tt.BedProfileID = t.BedProfileID and tt.OkatoID = t.OkatoID and tt.LPUID = t.LPUID

-- Проставляем ID для уровня 1
UPDATE tt 
set parent_id_field = cast(t.id as varchar)
FROM @TempTable tt	
	inner join @TempTable t on tt.OkatoID = t.OkatoID and t.level_field = 0
where tt.level_field = 1 

-- Проставляем ID для уровня 2
UPDATE tt 
set parent_id_field = cast(t.id as varchar)
FROM @TempTable tt
	inner join @TempTable t on tt.OkatoID = t.OkatoID and tt.LPUID = t.LPUID  and t.level_field = 1
where tt.level_field = 2 



DECLARE @result xml

SET @result = (
select	id as cell, null,
		id as cell, null,

		case level_field when 0 then O_NAME when 1 then M_NAMES when 2 then BedProfileName end  as cell, null,
		[HospAllCnt] as cell, null,
		[HospLate] as cell, null,
		[Extr] as cell, null,
		[Plan] as cell, null,
		[PlanLate] as cell, null,
		[Canceld] as cell, null,
		[CanceldLate] as cell, null,
		[OutPat] as cell, null,

		level_field as cell, null,
		parent_id_field as cell, null,
		leaf_field as cell, null,
		expanded_field as cell, null 	 
		 
from @TempTable
order by id
for xml PATH, root('rows'))

RETURN @result

END


go

