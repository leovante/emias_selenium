
create FUNCTION [dbo].[GetPRVSName] (@Field varchar(50))  
RETURNS varchar(150)   AS  
BEGIN 
return (select top 1 PRVS_NAME from  oms_PRVS where C_PRVS=@Field )
END
go

