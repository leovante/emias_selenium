CREATE VIEW [V_oms_DPCPolyclinicRecipeReestrRegionLg] AS SELECT 
[hDED].[DPCPolyclinicRecipeReestrRegionLgID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[Num] as [Num], 
[hDED].[Date_Create] as [Date_Create], 
[hDED].[OGRN] as [OGRN], 
[hDED].[GUID] as [GUID]
FROM [oms_DPCPolyclinicRecipeReestrRegionLg] as [hDED]
go

