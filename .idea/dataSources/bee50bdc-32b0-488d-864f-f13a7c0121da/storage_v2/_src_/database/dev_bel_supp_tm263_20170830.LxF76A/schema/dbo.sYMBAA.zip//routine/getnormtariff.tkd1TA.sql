
CREATE FUNCTION [dbo].[GetNormTariff](@dat datetime, @ogrn  varchar(20) )
RETURNS @TabNorm TABLE (
           [rf_ServiceMedicalID] int not null
           ,[rf_TariffTargetID] int not null
           ,[rf_DepartmentID]  int not null
           ,[Value1]   decimal(18,2) not null
           ,[Date_B]   datetime not null
           ,[Value2]   decimal(18,2) not null
           ,[Date_E]   datetime null
           ,[rf_LPUID]  int not null
		       ,[Doc]       varchar(150) not null
		       ,rf_tariffnormID int not null
)

AS
Begin
  insert  @TabNorm
	select  n.[rf_ServiceMedicalID]
	       ,n.[rf_TariffTargetID] 
	       ,d.rf_DepartmentID 
	       ,[Value1]
           ,n.[Date_B]
           ,[Value2]
           ,n.[Date_E]
           ,d.[rf_LPUID]
           
           ,n.[Doc]
           ,tariffnormId
          
	from oms_LPUTarget l
inner join oms_lpu on l.rf_lpuid = lpuid and C_OGRN =@ogrn
	inner join (
		select oms_Department.rf_kl_ageGroupId, 
		       oms_LicenceReestr.rf_lpuid, 
		       isnull(dep.DepartmentId,lic.rf_DepartmentID) as rf_DepartmentID, 
		       lic.rf_kl_DepartmentProfileId,lic.rf_kl_DepartmentTypeId,
					 lic.rf_servicemedicalID, lic.Flags
					 
    from oms_LicenceReestrSM lic
            inner join oms_LicenceReestr on LicenceReestrId = rf_LicenceReestrID
            inner join oms_Department on rf_DepartmentId = oms_Department.DepartmentID and oms_Department.rf_LPUID = oms_LicenceReestr.rf_LPUID 
            left join oms_Department dep on rf_DepartmentId = dep.DepartmentID         and oms_Department.rf_LPUID = oms_LicenceReestr.rf_LPUID and 
                     ( lic.rf_kl_DepartmentProfileID<>oms_Department.rf_kl_DepartmentProfileID
                        or lic.rf_kl_DepartmentTypeID<>oms_Department.rf_kl_DepartmentTypeID ) 
            inner join oms_lpu on oms_LicenceReestr.rf_lpuid = lpuid and C_OGRN =@ogrn
    group by oms_Department.rf_kl_ageGroupId, 
		         oms_LicenceReestr.rf_lpuid, 
						 isnull(dep.DepartmentId,lic.rf_DepartmentID), 
		         lic.rf_kl_DepartmentProfileId,
						 lic.rf_kl_DepartmentTypeId,
						 lic.rf_servicemedicalID,
						 lic.Flags    
  ) d on l.rf_lpuid = lpuid and  d.rf_lpuid = lpuid and l.rf_kl_departmentTypeId = d.rf_kl_departmentTypeId 
		
	inner join oms_tariffnorm n   on n.rf_tarifftargetid = l.rf_tarifftargetid  and n.rf_lpuid=0 and n.date_E>@dat
	inner join oms_servicemedical on n.rf_servicemedicalid = servicemedicalid   and 
	((d.rf_servicemedicalid = oms_servicemedical.servicemedicalid and d.rf_servicemedicalid>0 and d.Flags=1) or
	             ((d.rf_servicemedicalid = 0 or  (d.rf_servicemedicalid > 0 and d.Flags=0))  							
	             and  l.rf_kl_departmentTypeId = oms_servicemedical.rf_kl_departmentTypeId 
	 	           and oms_servicemedical.rf_kl_departmentProfileId = d.rf_kl_departmentProfileId))                                                  
		
	inner join oms_kl_agegroup ag  on d.rf_kl_agegroupid=  ag.kl_agegroupid
	inner join oms_kl_agegroup ag1 on  d.rf_kl_departmenttypeid    = oms_servicemedical.rf_kl_departmenttypeid 
                                     and d.rf_kl_departmentprofileid = oms_servicemedical.rf_kl_departmentprofileid
                                     and ((oms_servicemedical.rf_kl_agegroupid=ag1.kl_agegroupid	)
			 or (ag.name <> 'Дети' and ag1.code<>'Дети')
			 or (ag.name = 'Смешанные')
			 or (ag1.name = 'Смешанные')) and oms_servicemedical.rf_kl_agegroupid = ag1.kl_agegroupid 

group by  n.[rf_ServiceMedicalID]
	       ,n.[rf_TariffTargetID] 
	 		   ,d.rf_DepartmentID 
         ,[Value1]
         ,n.[Date_B]
         ,[Value2]
         ,n.[Date_E]
         ,d.[rf_LPUID]
         ,n.[Doc]
         ,tariffnormID

return
end
go

