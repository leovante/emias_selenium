CREATE VIEW [V_oms_hs_BedFond] AS SELECT 
[hDED].[hs_BedFondID], [hDED].[x_Edition], [hDED].[x_Status], 
(hDed.Men+hDed.Women+hDed.Kids+hDed.Mixed) as [V_FreeCountAll], 
[jT_oms_hs_DepartmentBed].[Count] as [V_Count], 
[hDED].[rf_hs_DepartmentBedID] as [rf_hs_DepartmentBedID], 
[hDED].[Cons] as [Cons], 
[hDED].[Men] as [Men], 
[hDED].[Received] as [Received], 
[hDED].[Women] as [Women], 
[hDED].[Depart] as [Depart], 
[hDED].[Kids] as [Kids], 
[hDED].[Date] as [Date], 
[hDED].[Mixed] as [Mixed], 
[hDED].[Flags] as [Flags], 
[hDED].[Active] as [Active], 
[hDED].[Date_Edit] as [Date_Edit], 
[hDED].[BedCount] as [BedCount], 
[hDED].[LastUserID] as [LastUserID]
FROM [oms_hs_BedFond] as [hDED]
INNER JOIN [oms_hs_DepartmentBed] as [jT_oms_hs_DepartmentBed] on [jT_oms_hs_DepartmentBed].[hs_DepartmentBedID] = [hDED].[rf_hs_DepartmentBedID]
go

