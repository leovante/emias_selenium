-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[f263_tfReport]
(	
 @dateA datetime,
 @dateB datetime
)
RETURNS TABLE 
AS
RETURN 
(
select 
	oms_OKATO.C_OKATO,
	oms_OKATO.O_NAME,
	oms_LPU.MCOD,
	oms_LPU.M_NAMES,
	(select count(1) from oms_hs_Direction d where d.DirDate between @dateA and @dateB and d.rf_DirLPUID = oms_LPU.LPUID)					as DirAllCount,
	(select count(1) from oms_hs_Direction d where d.DirDate between @dateA and @dateB and d.rf_DirLPUID = oms_LPU.LPUID and d.state = 1) as DirWaitCount,
	(select count(1) from oms_hs_Direction d where d.DirDate between @dateA and @dateB and d.rf_DirLPUID = oms_LPU.LPUID and d.state = 3) as DirAnulCount,
	(select count(1) from oms_hs_Direction d where d.DirDate between @dateA and @dateB and d.rf_DirLPUID = oms_LPU.LPUID and d.state = 3) as DirHospCount,
	(select count(*) from oms_hs_Hospital h where h.DateTimeFact between @dateA and @dateB and h.rf_LPUID = oms_LPU.LPUID) as Hosp,
	(select count(*) from oms_hs_Hospital h where h.DateTimeFact between @dateA and @dateB and h.rf_LPUID = oms_LPU.LPUID and h.State = 2) as HospExit 
from oms_LPU
	inner join oms_OKATO on oms_LPU.rf_OKATOID = oms_OKATO.OKATOID
where oms_lpu.lpuid > 0
)

go

