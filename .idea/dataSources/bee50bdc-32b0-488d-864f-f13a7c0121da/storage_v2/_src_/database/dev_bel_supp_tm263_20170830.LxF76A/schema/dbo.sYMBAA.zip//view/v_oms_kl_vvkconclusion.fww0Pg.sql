CREATE VIEW [V_oms_kl_VVKConclusion] AS SELECT 
[hDED].[kl_VVKConclusionID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_VVKConclusionCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_VVKConclusion] as [hDED]
go

