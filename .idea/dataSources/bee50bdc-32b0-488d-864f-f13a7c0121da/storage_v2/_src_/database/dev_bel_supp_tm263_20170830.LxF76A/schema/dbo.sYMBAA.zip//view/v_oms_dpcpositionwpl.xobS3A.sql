CREATE VIEW [V_oms_DPCPositionWPL] AS SELECT 
[hDED].[DPCPositionWPLID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TypePackingID] as [rf_TypePackingID], 
[hDED].[rf_DPCWriteOffPurposeListID] as [rf_DPCWriteOffPurposeListID], 
[hDED].[Count] as [Count], 
[hDED].[Date] as [Date], 
[hDED].[GUIDPosList] as [GUIDPosList], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[Price] as [Price], 
[hDED].[Summa] as [Summa], 
[hDED].[ExpDate] as [ExpDate], 
[hDED].[Series] as [Series], 
[hDED].[NomenclatureName] as [NomenclatureName], 
[hDED].[Code_Nom] as [Code_Nom], 
[hDED].[Code_RAS] as [Code_RAS], 
[hDED].[Consigment] as [Consigment], 
[hDED].[GUIDPos] as [GUIDPos]
FROM [oms_DPCPositionWPL] as [hDED]
go

