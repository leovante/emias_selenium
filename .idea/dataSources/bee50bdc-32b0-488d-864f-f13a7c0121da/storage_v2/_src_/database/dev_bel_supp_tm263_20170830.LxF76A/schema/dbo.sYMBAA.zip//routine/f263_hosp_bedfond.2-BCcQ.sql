-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[f263_HOSP_BedFond] (@mcod varchar(20), @date datetime)
RETURNS xml
AS
BEGIN

	--declare @lpuid int
	--declare @date datetime
	--set @lpuid = 1081
	--set @date = '2014-09-18T00:00:00'


	declare @TempTable table (
		id int ,

		hs_BedFondID int,
		rf_ProfileID int,
		LPUID int,

		Name_LPU varchar(250),
		Name_Dept varchar(250),
		Name_Prof varchar(250),

		BedCount int,
		Cons int,
		Received int,
		Depart int,
		FreeCount int,
		Mixed int,
		Women int,
		Men int,
		Kids int,
		hs_DepartmentBedID int,
		hs_LPUDepartmentID int,

		level_field int,
		parent_id_field varchar(10),
		leaf_field varchar(10),
		expanded_field varchar(10)
		)

	insert into @TempTable
	(	
		id,

		hs_BedFondID ,
		rf_ProfileID,
		LPUID,

		Name_LPU,
		Name_Dept,
		Name_Prof,

		BedCount,
		Cons,
		Received,
		Depart,
		FreeCount,
		Mixed,
		Women,
		Men,
		Kids,
		hs_DepartmentBedID,
		hs_LPUDepartmentID,

		level_field,
		parent_id_field,
		leaf_field,
		expanded_field
	)
	select 
	 0,
	 isnull(bf.hs_BedFondID, 0) as hs_BedFondID,
	 rf_ProfileID,
	 lpu.LPUID,

	 lpu.M_NAMES,
	 ld.Name,
	 bp.Name,

	 isnull(db.[Count], 0) as BedCount,
	 isnull(bf.Cons, 0) as Cons,
	 isnull(bf.Received,  0) as Received,
	 isnull(bf.Depart,  0) as Depart,
	 isnull(bf.Mixed, 0) + isnull(bf.Men, 0) + isnull(bf.Women, 0) + isnull(bf.Kids, 0) as FreeAll,
	 isnull(bf.Mixed, 0) as Mixed,
	 isnull(bf.Men,  0) as Men,
	 isnull(bf.Women,  0) as Women,
	 isnull(bf.Kids, 0) as Kids,
	 db.hs_DepartmentBedID,
	 ld.hs_LPUDepartmentID,

	 2,
	'',
	'true',
	'false'
	from oms_LPU lpu 
		inner join oms_hs_LPUDepartment ld on lpu.LPUID = ld.rf_LPUID
		left join oms_hs_DepartmentBed db on ld.hs_LPUDepartmentID = db.rf_hs_LpuDepartmentID
		left join stt_BedProfile bp on bp.BedProfileID = db.rf_ProfileID
		left join oms_hs_BedFond bf on bf.rf_hs_DepartmentBedID = db.hs_DepartmentBedID and bf.date = @date
	where lpu.MCOD = @mcod AND ld.Date_E > GETDATE() AND db.Date_E > GETDATE()
	and (bf.Date_Edit = (select max(Date_Edit) from oms_hs_BedFond where oms_hs_BedFond.rf_hs_DepartmentBedID = db.hs_DepartmentBedID and oms_hs_BedFond.date = @date)
	or bf.Date_Edit is null )
	and NOT(db.Count = 0 and (bp.Date_E < GETDATE() or bp.Date_B >= GETDATE() ) )

	-- Добавляем нулевой уровень - ЛПУ
	insert into @TempTable
	(	
		id,

		hs_BedFondID ,
		rf_ProfileID,
		LPUID,

		Name_LPU,
		Name_Dept,
		Name_Prof,

		BedCount,
		Cons,
		Received,
		Depart,
		FreeCount,
		Mixed,
		Women,
		Men,
		Kids,
		hs_DepartmentBedID,
		hs_LPUDepartmentID,

		level_field,
		parent_id_field,
		leaf_field,
		expanded_field
	)
	SELECT
		0,

		0 as hs_BedFondID ,
		0 as rf_ProfileID,
		LPUID,

		Name_LPU,
		'' as Name_Dept,
		'' as Name_Prof,

		sum(BedCount),
		sum(Cons),
		sum(Received),
		sum(Depart),
		sum(FreeCount),
		sum(Mixed),
		sum(Women),
		sum(Men),
		sum(Kids),
		0 as hs_DepartmentBedID,
		0 as hs_LPUDepartmentID,

		0 as level_field,
		'' as parent_id_field,
		case when count(1) = 0 then 'true' else 'false' end as leaf_field,
		'true'
	from @TempTable
	where level_field = 2
	group by LPUID, Name_LPU


	-- Добавляем 1 уровень - отделение
	insert into @TempTable
	(	
		id,

		hs_BedFondID ,
		rf_ProfileID,
		LPUID,

		Name_LPU,
		Name_Dept,
		Name_Prof,

		BedCount,
		Cons,
		Received,
		Depart,
		FreeCount,
		Mixed,
		Women,
		Men,
		Kids,
		hs_DepartmentBedID,
		hs_LPUDepartmentID,

		level_field,
		parent_id_field,
		leaf_field,
		expanded_field
	)
	SELECT
		0,

		0 as hs_BedFondID ,
		0 as rf_ProfileID,
		LPUID,

		Name_LPU,
		Name_Dept as Name_Dept,
		'' as Name_Prof,

		sum(BedCount),
		sum(Cons),
		sum(Received),
		sum(Depart),
		sum(FreeCount),
		sum(Mixed),
		sum(Women),
		sum(Men),
		sum(Kids),
		0 as hs_DepartmentBedID,
		hs_LPUDepartmentID,

		1 as level_field,
		'' as parent_id_field,
		case when count(rf_ProfileID) = 0 then 'true' else 'false' end as leaf_field,
		'true'
	from @TempTable
	where level_field = 2
	group by LPUID, Name_LPU, hs_LPUDepartmentID, Name_Dept

	delete from @TempTable where rf_ProfileID is null


	-- Проставляем ID-шники 
	UPDATE tt
	set id = t.RowID - 1
	FROM @TempTable tt
	inner join
	(
		select ROW_NUMBER() OVER(ORDER BY  Name_LPU, Name_Dept, Name_Prof)  AS RowID, LPUID, hs_LPUDepartmentID, hs_DepartmentBedID from @TempTable
	) as t
	on tt.LPUID = t.LPUID and tt.hs_LPUDepartmentID = t.hs_LPUDepartmentID and tt.hs_DepartmentBedID = t.hs_DepartmentBedID
	


	-- Проставляем ID для уровня 1
	UPDATE tt 
	set parent_id_field = cast(t.id as varchar)
	FROM @TempTable tt	
		inner join @TempTable t on tt.LPUID = t.LPUID and t.level_field = 0
	where tt.level_field = 1 

	-- Проставляем ID для уровня 2
	UPDATE tt 
	set parent_id_field = cast(t.id as varchar)
	FROM @TempTable tt
		inner join @TempTable t on tt.LPUID = t.LPUID and tt.hs_LPUDepartmentID = t.hs_LPUDepartmentID  and t.level_field = 1
	where tt.level_field = 2 


	--select * from @TempTable order by id



	DECLARE @result xml

	SET @result = (
	select	id as cell, null,
			case level_field when 2 then cast(hs_BedFondID as varchar(10)) else '' end as cell, null,
			case level_field when 2 then cast(rf_ProfileID as varchar(10)) else '' end as cell, null,
			case level_field when 2 then cast(LPUID        as varchar(10)) else '' end as cell, null,
			case level_field when 0 then Name_LPU when 1 then Name_Dept when 2 then NAME_PROF end  as cell, null,
			[BedCount] as cell, null,
			Cons as cell, null,
			Received as cell, null,
			Depart as cell, null,
			FreeCount as cell, null,
			Mixed as cell, null,
			Women as cell, null,
			Men as cell, null,
			Kids as cell, null,
			case level_field when 2 then cast(hs_DepartmentBedID as varchar(10)) else '' end as cell, null,
--			hs_LPUDepartmentID as cell, null,

			level_field as cell, null,
			parent_id_field as cell, null,
			leaf_field as cell, null,
			expanded_field as cell, null		 
		 
	from @TempTable
	order by id
	for xml PATH, root('rows'))

	-- Return the result of the function
	RETURN @result

END
go

