CREATE VIEW [V_oms_STD_MKBMNN] AS SELECT 
[hDED].[STD_MKBMNNID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[MKB] as [MKB], 
[hDED].[C_MNN] as [C_MNN]
FROM [oms_STD_MKBMNN] as [hDED]
go

