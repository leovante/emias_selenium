
CREATE PROCEDURE my_procedure
AS
DECLARE @M_cod varchar
SET @M_cod = '580201'


select m_names,m_namef from oms_lpu where mcod='580201'
/*update oms_lpu set
m_names='ГБУЗ МО "Краснознаменская ГП"',
m_namef='Государственное бюджетное учреждение здравоохранения Московской области "Краснознаменская городская поликлиника"'
where mcod='580201'
select m_names,m_namef from oms_lpu where mcod='580201'
//------------------------------------------------
select * from x_hs_users where org_cod ='580201'

update x_hs_users set org_name='580201 - ГБУЗ МО "Краснознаменская ГП"' where org_cod='580201'
select * from x_hs_users where org_cod ='580201'*/
go

