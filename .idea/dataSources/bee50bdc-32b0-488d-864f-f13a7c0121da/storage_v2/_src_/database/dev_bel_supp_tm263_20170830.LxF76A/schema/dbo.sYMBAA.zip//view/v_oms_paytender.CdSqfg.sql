CREATE VIEW [V_oms_PayTender] AS SELECT 
[hDED].[PayTenderID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[hDED].[rf_TypePayTenderID] as [rf_TypePayTenderID], 
[hDED].[PayDate] as [PayDate], 
[hDED].[PayNum] as [PayNum], 
[hDED].[Summa] as [Summa], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[Note] as [Note], 
[hDED].[Name] as [Name]
FROM [oms_PayTender] as [hDED]
go

