-- =============================================
-- Author:		Shumer
-- Create date: 19.04.2014
-- Description:	Поиск пациента по данным полиса
-- =============================================
CREATE PROCEDURE [dbo].[spPatientService]
	 @spol		varchar(20)
	,@npol		varchar(20)
	,@FAM		varchar(40)			output
	,@IM		varchar(40)			output
	,@OT		varchar(40)			output
	,@W			int					output
	,@DR		datetime			output
	,@MR		varchar(100)		output
	,@SS		varchar(14) 		output
	,@DOCTP		varchar(3)			output
	,@DOCS		varchar(20)			output
	,@DOCN		varchar(20)			output
	,@ENP		varchar(16) 		output
	,@Q			varchar(5) 			output
	,@OPDOC		int 				output
	,@S_POL		varchar(20) 		output
	,@N_POL		varchar(20) 		output
	,@ADRES_R	varchar(550)		output
	,@STATUS	varchar(1) 			output
	,@OKATO		varchar(5) 			output
	,@dbeg		datetime 			output
	,@dstop		datetime			output
AS		
BEGIN

	if not exists (select top 1 1 from [10.3.126.72].hlt_demostend.dbo.hlt_patient p where p.s_pol = @spol and p.N_POL = @npol)
	return -1

	
	select top 1
	 @FAM		= FAMILY
	,@IM		= NAME
	,@OT		= OT
	,@W			= W
	,@DR		= Birthday
	,@MR		= Birthplace
	,@SS		= SS
	,@DOCTP		= ''
	,@DOCS		= S_DOC
	,@DOCN		= N_DOC
	,@ENP		= case when (len(N_POL) = 16) then N_POL else '' end
	,@Q			= s.COD + right('000' + cast(s.CODE_CMO as varchar(3)), 3)
	,@OPDOC		= 3
	,@S_POL		= S_POL
	,@N_POL		= N_POL
	,@ADRES_R	= p.ADRES
	,@STATUS	= isWorker
	,@OKATO		= '46000'
	,@dbeg		= DatePolBegin
	,@dstop		= DatePolEnd
	from [10.3.126.72].hlt_demostend.dbo.hlt_patient p 
		left join [10.3.126.72].hlt_demostend.dbo.oms_smo s on s.SMOID = p.rf_SMOID
	where p.s_pol = @spol and p.N_POL = @npol

	return 0
END


go

