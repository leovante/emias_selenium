create function GS916_FN_StringIsEmpty(@String varchar(max))
	returns bit
	begin
		if (@String is null) return 0;
		declare @s varchar(max) = ltrim(rtrim(@String))
		if(@s = '') return 0;
		if(@s = '0') return 0;
		if(@s = '00000000-0000-0000-0000-000000000000') return 0;
		if(@s = '1900-01-01') return 0;
		if(@s = '2222-01-01') return 0;
		return 1;
	end
go

