
---Преобразуется строки, разделенные разделителем в табличку
CREATE FUNCTION [dbo].[TableFromString] (
	@List		NVarChar(4000)
,	@Delimeter	NChar(1) = N','
) RETURNS TABLE AS RETURN	
WITH [List] ([No],[Pos],[To]) AS (
	SELECT	0,0,0
UNION ALL
	SELECT	L.[No] + 1
	,	L.[To] + 1
	,	I.[To]
	FROM	[List] L CROSS APPLY (SELECT CharIndex(@Delimeter,@List + @Delimeter,L.[To] + 1)) I ([To])
	WHERE	I.[To] > 0
)	SELECT	[No]
	,	SubString(@List,[Pos],[To]-[Pos])	AS Item
	,	[Pos]
	FROM	[List]
	WHERE	[To] > [Pos]
go

