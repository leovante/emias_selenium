-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fnc_BedFounf]
(	
	-- Add the parameters for the function here
	@dt datetime, 
	@LPUID int
)
RETURNS TABLE 
AS
RETURN 
(
select 
 bf.hs_BedFondID as hs_BedFondID
,dept.Name as DepartmentName
,bp.Name
,bp.BedProfileID as rf_ProfileID
,deptB.Count as countAll

,isnull(bf.cons, isnull((
	select top 1 case when (cons - depart + received) < 0 then 0 else (cons - depart + received) end
	from oms_hs_BedFond bf0 
	where	bf0.rf_hs_DepartmentBedID =  deptB.hs_DepartmentBedID			
			and datediff(day, bf0.date, @dt) = 1
	), 0)) as Cons --Состояло

,isnull(bf.received, (
	select count(*) 
	from oms_hs_Hospital h 
	where	h.rf_LPUID = @LPUID 
			and datediff(day, h.DateTimeFact, @dt) = 1
	)) as received

,isnull(bf.depart,  (
	select count(*) 
	from [dbo].[oms_hs_Hospital] h
		where h.rf_LPUID = @LPUID and datediff(day, h.DateExit, @dt) = 1
	)) as depart
,isnull(bf.V_FreeCountAll, 0) as FreeCountAll
,isnull(bf.men, 0) as Men
,isnull(bf.women, 0) as Women
,isnull(bf.kids, 0) as Kids
from oms_hs_LpuDepartment dept
	inner join oms_hs_DepartmentBed deptB on dept.hs_LpuDepartmentID = deptB.rf_hs_LpuDepartmentID
	inner join stt_BedProfile bp on bp.BedProfileID = deptB.rf_ProfileID
		left join v_oms_hs_BedFond bf
		on bf.rf_hs_DepartmentBedID = deptB.hs_DepartmentBedID
			
			and (bf.Date is null or datediff(day, bf.Date, @dt) = 0)
where dept.rf_LPUID = @LPUID  and bp.BedProfileID > 0 and bp.CODE != '0'
)


go

