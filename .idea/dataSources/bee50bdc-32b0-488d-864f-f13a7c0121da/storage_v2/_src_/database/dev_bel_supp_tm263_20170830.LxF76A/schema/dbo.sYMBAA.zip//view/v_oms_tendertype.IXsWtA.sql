CREATE VIEW [V_oms_TenderType] AS SELECT 
[hDED].[TenderTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[jT_oms_Finl].[NAME] as [SILENT_rf_FinlID], 
[hDED].[TenderType_Name] as [TenderType_Name], 
[hDED].[FullName] as [FullName], 
[hDED].[InDemand] as [InDemand], 
[hDED].[GUIDTYPE] as [GUIDTYPE], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[FinCode] as [FinCode], 
[hDED].[DopEK] as [DopEK], 
[hDED].[DopKR] as [DopKR], 
[hDED].[KVR] as [KVR], 
[hDED].[KodTarget] as [KodTarget], 
[hDED].[KVFO] as [KVFO], 
[hDED].[KCSR] as [KCSR], 
[hDED].[DopFK] as [DopFK], 
[hDED].[KOSGU] as [KOSGU], 
[hDED].[Flags] as [Flags], 
[hDED].[Info] as [Info]
FROM [oms_TenderType] as [hDED]
INNER JOIN [oms_Finl] as [jT_oms_Finl] on [jT_oms_Finl].[FinlID] = [hDED].[rf_FinlID]
go

