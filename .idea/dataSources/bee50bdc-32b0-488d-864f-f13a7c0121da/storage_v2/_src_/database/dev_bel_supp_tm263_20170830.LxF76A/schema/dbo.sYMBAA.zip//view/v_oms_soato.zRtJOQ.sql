CREATE VIEW [V_oms_SOATO] AS SELECT 
[hDED].[SOATOID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[COD_FOMS] as [COD_FOMS], 
[hDED].[C_SOATO] as [C_SOATO], 
[hDED].[SOATO_TER] as [SOATO_TER]
FROM [oms_SOATO] as [hDED]
go

