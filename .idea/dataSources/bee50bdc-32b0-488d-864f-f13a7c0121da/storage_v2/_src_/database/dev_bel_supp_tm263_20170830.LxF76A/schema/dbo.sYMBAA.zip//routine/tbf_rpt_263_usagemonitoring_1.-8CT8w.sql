
CREATE FUNCTION [dbo].[tbf_rpt_263_UsageMonitoring_1]
(
	 @dateA datetime
,	 @dateB datetime
) RETURNS TABLE AS RETURN	

select 
isnull(ltrim(rtrim(omain.O_Name)),ltrim(rtrim(okato.O_NAME))) as O_NAME,
lpu.MCod,
lpu.m_names,
isnull(DateAct.LastDate, '1900-01-01T00:00:00') as LastDate,
isnull(Rep.BedCount, 0)  as BedCount,
(select count(*) from oms_hs_direction dir where dir.rf_DirLPUID = lpu.LPUID and dir.DirDate  BETWEEN @dateA and @dateB) as DirCount,--направлений
(select count(*) from oms_hs_Hospital  hosp
inner join oms_hs_LpuDepartment on rf_hs_LpuDepartmentID=hs_LpuDepartmentID
where hosp.lpu_1=lpu.mcod and convert(date,hosp.DateTimeFact) BETWEEN @dateA and @dateB) as hospcount,--госпитализаций
(select count(*) from x_hs_users uss where cast(uss.org_cod as varchar)=lpu.mcod)/*переписала с Code_MO  на org_cod*/ as CountUsers,
/*(select count(*) from x_hs_users uss1 where cast(uss1.org_cod as varchar)=lpu.mcod /*переписала с Code_MO  на org_cod*/
and uss1.last_login >= DATEADD(ww,-1, current_timestamp)) as CountActiveUsers_last,*/
(select count(distinct id) from x_hs_users
left join tm263_logs on userID = id and DateTime>= DATEADD(ww,-1, current_timestamp)
--where cast(x_hs_users.org_cod as varchar)=lpu.mcod and isnull(DateTime,last_login) >= DATEADD(ww,-1, current_timestamp)
where cast(x_hs_users.org_cod as varchar)=lpu.mcod and 
(isnull(DateTime,last_login) >= DATEADD(ww,-1, current_timestamp)
OR cast(x_hs_users.org_cod as varchar) in (
Select distinct MCOD from oms_hs_direction dir
inner join oms_LPU lpu on dir.rf_DirLPUID = lpu.LPUID
where dir.DirDate>= DATEADD(ww,-1, current_timestamp)
and dir.DirDate<getdate()
)and role=3 OR 
cast(x_hs_users.org_cod as varchar) in ( 
Select distinct hosp.lpu_1 as MCOD from oms_hs_Hospital  hosp
inner join oms_hs_LpuDepartment on rf_hs_LpuDepartmentID=hs_LpuDepartmentID
where hosp.DateTimeFact>= DATEADD(ww,-1, current_timestamp)
and hosp.DateTimeFact<getdate()
) and role=4
)
) as CountActiveUsers

from oms_LPU lpu
inner join oms_Okato okato on lpu.rf_OkatoID = okato.OKATOID
left join oms_OKATO omain on omain.C_OKATO=left(okato.C_OKATO,5)+'000000'
left join
(
	select ld.rf_LPUID as rf_LPUID, max(bf.date) as LastDate
	from oms_hs_BedFond bf
	inner join oms_hs_DepartmentBed db on bf.rf_hs_DepartmentBedID = db.hs_DepartmentBedID
	inner join oms_hs_LPUDepartment ld on ld.hs_LPUDepartmentID = db.rf_hs_LPUDepartmentID
	--inner join oms_LPU  lpu1 on LPUID=ld.rf_LPUID
	--left join oms_LPU mainl  WITH(NOLOCK) on (lpu1.rf_MainLPUID=mainl.LPUID and mainl.LPUID>0 ) and mainl.rf_MainLPUID=0

	where ld.Date_E > bf.date and db.Date_E > bf.date and ld.rf_LPUID > 0
	group by  ld.rf_LPUID--isnull(mainl.LPUID,ld.rf_LPUID)
) DateAct on lpu.LPUID = DateAct.rf_LPUID

left join 
(
	select ld.rf_LPUID, sum(db.Count) as BedCount
	from oms_hs_DepartmentBed db
	inner join oms_hs_LPUDepartment ld on ld.hs_LPUDepartmentID = db.rf_hs_LPUDepartmentID
	where ld.Date_E > getdate() and db.Date_E > getdate() and ld.rf_LPUID > 0
	group by ld.rf_LPUID

) Rep on lpu.LPUID = Rep.rf_LPUID

where lpu.LPUID != 0 --and lpu.Date_E > getdate()
go

