CREATE VIEW [V_oms_kl_DepartmentType] AS SELECT 
[hDED].[kl_DepartmentTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_DepartmentTypeCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_DepartmentType] as [hDED]
go

