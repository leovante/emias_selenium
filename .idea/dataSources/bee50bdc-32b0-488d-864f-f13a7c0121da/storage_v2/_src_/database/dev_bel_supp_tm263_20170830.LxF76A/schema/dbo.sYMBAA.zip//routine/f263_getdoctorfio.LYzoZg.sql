-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[f263_GetDoctorFio]
(	
	@MCOD varchar(20), 
	@PCOD varchar(20)
)
RETURNS TABLE 
AS
RETURN 
(
	--SELECT 'Домашний Григорий Иванович' as FIO, 'Врач общей практики' as PRVD_Name
	SELECT TOP 1 * FROM (
	select isnull(Fam_V + ' ' + IM_V + ' ' + OT_V, '') as FIO, isnull(oms_PRVD.NAME, '')  as PRVD_Name
	from 
	cod_MO.dbo.hlt_lpudoctor
	inner join cod_MO.dbo.oms_LPU on rf_LPUID = LPUID
	left join cod_MO.dbo.oms_PRVD on rf_PRVDID = PRVDID
	where pcod = @PCOD and mcod = @mcod
union all
	select 'Врач не найден', 'должность не нейдена'
	) t	
)

go

