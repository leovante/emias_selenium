CREATE VIEW [V_oms_Region_LG_Person] AS SELECT 
[hDED].[Region_LG_PersonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[hDED].[rf_PersonREGLGID] as [rf_PersonREGLGID], 
[jT_oms_PersonRegLG].[Person_FIO] as [SILENT_rf_PersonREGLGID], 
[hDED].[DATE_BL] as [DATE_BL], 
[hDED].[DATE_EL] as [DATE_EL], 
[hDED].[NAME_DL] as [NAME_DL], 
[hDED].[SN_DL] as [SN_DL], 
[hDED].[S_DL] as [S_DL], 
[hDED].[N_DL] as [N_DL], 
[hDED].[Name] as [Name]
FROM [oms_Region_LG_Person] as [hDED]
INNER JOIN [V_oms_PersonRegLG] as [jT_oms_PersonRegLG] on [jT_oms_PersonRegLG].[PersonRegLGID] = [hDED].[rf_PersonREGLGID]
go

