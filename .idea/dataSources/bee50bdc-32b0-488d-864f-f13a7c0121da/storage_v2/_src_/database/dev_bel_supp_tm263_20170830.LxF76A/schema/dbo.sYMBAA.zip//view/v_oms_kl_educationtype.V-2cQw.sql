CREATE VIEW [V_oms_kl_EducationType] AS SELECT 
[hDED].[kl_EducationTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_EducationTypeCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_EducationType] as [hDED]
go

