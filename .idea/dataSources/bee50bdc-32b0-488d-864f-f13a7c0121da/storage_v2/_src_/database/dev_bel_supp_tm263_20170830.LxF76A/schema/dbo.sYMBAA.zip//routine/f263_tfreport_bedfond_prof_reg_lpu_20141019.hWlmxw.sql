-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[f263_TFReport_BedFond_Prof_Reg_LPU_20141019] ()
RETURNS xml
AS
BEGIN

	declare @TempTable table (
	id int ,
	id2 int,
	BedProfileID int,
	Name varchar(250),
	OkatoID int,
	O_NAME varchar(200),
	LPUID int,
	M_NAMES varchar(250),
	[date] datetime,
	[Count] int,
	FreeCount int,
	Mixed int,
	Women int,
	Men int,
	Kids int,
	Received int,
	Depart int,

	level_field int,
	parent_id_field varchar(10),
	leaf_field varchar(10),
	expanded_field varchar(10)
	)


insert into @TempTable 
 (
	id,
	id2,

	BedProfileID,
	Name,

	OkatoID,
	O_NAME,

	LPUID,
	M_NAMES,
	[date],
	[Count],
	FreeCount,
	Mixed,
	Women ,
	Men ,
	Kids ,
	Received,
	Depart,

	level_field,
	parent_id_field,
	leaf_field,
	expanded_field
	)
select  0, 0,

		stt_BedProfile.BedProfileID,
		stt_BedProfile.Name, 
		oms_OKATO.OKATOID,
		oms_OKATO.O_NAME,
		oms_LPU.LPUID,
		oms_LPU.M_NAMES,
		oms_hs_BedFond.Date, 
		sum(oms_hs_DepartmentBed.Count) as [Count],
		sum(oms_hs_BedFond.Mixed) + sum(oms_hs_BedFond.Women) + sum(oms_hs_BedFond.Men)  + sum(oms_hs_BedFond.Kids) as  FreeCount,		
		sum(oms_hs_BedFond.Mixed) as Mixed, 
		sum(oms_hs_BedFond.Women) as Women,  
		sum(oms_hs_BedFond.Men) as Men, 	
		sum(oms_hs_BedFond.Kids) as Kids, 
		sum(oms_hs_BedFond.Received) as Received,	
		sum(oms_hs_BedFond.Depart) as Depart,

		2,
		'',
		'true',
		'true'

 from stt_BedProfile
inner join oms_hs_DepartmentBed on oms_hs_DepartmentBed.rf_ProfileID = stt_BedProfile.BedProfileID
inner join oms_hs_LpuDepartment on oms_hs_DepartmentBed.rf_hs_LpuDepartmentID = oms_hs_LpuDepartment.hs_LpuDepartmentID
inner join oms_LPU on oms_LPU.LPUID = oms_hs_LpuDepartment.rf_LPUID
inner join oms_OKATO on oms_LPU.rf_OKATOID = oms_OKATO.OKATOID
left JOIN oms_hs_BedFond ON oms_hs_BedFond.rf_hs_DepartmentBedID = OMS_hs_DepartmentBed.hs_DepartmentBedID 
inner join (
			SELECT oms_hs_LPUDepartment.rf_LPUID, max(oms_hs_BedFond.date) as [date]
			FROM
				oms_hs_BedFond
				INNER JOIN OMS_hs_DepartmentBed ON rf_hs_DepartmentBedID = hs_DepartmentBedID
				inner join oms_hs_LPUDepartment on rf_hs_LPUDepartmentid = hs_LPUDepartmentid
			WHERE
				date <= getdate() and hs_BedFondID > 0
			GROUP BY rf_LPUID) t
on oms_hs_BedFond.Date = t.date and oms_hs_LPUDepartment.rf_LPUID = t.rf_LPUID
where stt_BedProfile.BedProfileID > 0 and oms_OKATO.OKATOID > 0 and oms_LPU.LPUID > 0
group by stt_BedProfile.BedProfileID, stt_BedProfile.Name, oms_OKATO.OKATOID, oms_OKATO.O_NAME, oms_LPU.LPUID, oms_LPU.M_NAMES, oms_hs_BedFond.Date, oms_hs_LPUDepartment.rf_LPUID, OMS_hs_DepartmentBed.rf_ProfileID 



-- Добавляем уровень 0 - Профиль
insert into @TempTable 
 (
	id,
	id2,

	BedProfileID,
	Name,

	OkatoID,
	O_NAME,

	LPUID,
	M_NAMES,
	[date],
	[Count],
	FreeCount,
	Mixed,
	Women ,
	Men ,
	Kids ,
	Received,
	Depart,

	level_field,
	parent_id_field,
	leaf_field,
	expanded_field
	)
select  0, 0,

		BedProfileID,
		Name,

		0 as OkatoID,
		'' as O_NAME,

		0 as LPUID,
		'' as M_NAMES,
		max(date) as [date],
		sum([Count]),
		sum(FreeCount),
		sum(Mixed),
		sum(Women),
		sum(Men),
		sum(Kids),
		sum(Received),
		sum(Depart),

		0,
		'',
		case when count(1) = 0 then 'true' else 'false' end,
		'false'

 from @TempTable where level_field = 2
 group by BedProfileID, Name



 -- Добавляем уровень 1 - Район
insert into @TempTable 
 (
	id,
	id2,

	BedProfileID,
	Name,

	OkatoID,
	O_NAME,

	LPUID,
	M_NAMES,
	[date],
	[Count],
	FreeCount,
	Mixed,
	Women ,
	Men ,
	Kids ,
	Received,
	Depart,

	level_field,
	parent_id_field,
	leaf_field,
	expanded_field
	)
select  0, 0,

		BedProfileID,
		Name,

		OkatoID,
		O_NAME,

		0 as LPUID,
		'' as M_NAMES,
		max(date) as [date],
		sum([Count]),
		sum(FreeCount),
		sum(Mixed),
		sum(Women),
		sum(Men),
		sum(Kids),
		sum(Received),
		sum(Depart),

		1,
		'',
		case when count(1) = 0 then 'true' else 'false' end,
		'false'

 from @TempTable where level_field = 2
 group by BedProfileID, Name, OkatoID, O_NAME

-- Проставляем ID-шники 
UPDATE tt
set id = t.RowID,
	id2 = t.RowID
FROM @TempTable tt
inner join
(
	select ROW_NUMBER() OVER(ORDER BY  Name, O_NAME, m_names)  AS RowID, BedProfileID, OkatoID, LPUID from @TempTable
) as t

on tt.BedProfileID = t.BedProfileID and tt.OkatoID = t.OkatoID and tt.LPUID = t.LPUID

-- Проставляем ID для уровня 1
UPDATE tt 
set parent_id_field = cast(t.id as varchar)
FROM @TempTable tt	
	inner join @TempTable t on tt.BedProfileID = t.BedProfileID and t.level_field = 0
where tt.level_field = 1 

-- Проставляем ID для уровня 2
UPDATE tt 
set parent_id_field = cast(t.id as varchar)
FROM @TempTable tt
	inner join @TempTable t on tt.BedProfileID = t.BedProfileID and tt.OkatoID = t.OkatoID  and t.level_field = 1
where tt.level_field = 2 


DECLARE @result xml

SET @result = (
select	id as cell, null,
		id as cell, null,

		case level_field when 0 then Name when 1 then O_NAME when 2 then M_NAMES end  as cell, null,
		convert(varchar(10), [date], 104) as cell, null,
		[Count] as cell, null,
		FreeCount as cell, null,
		Mixed as cell, null,
		Women as cell, null,
		Men as cell, null,
		Kids as cell, null,
		Received as cell, null,
		Depart as cell, null,

		level_field as cell, null,
		parent_id_field as cell, null,
		leaf_field as cell, null,
		expanded_field as cell, null
		 
		 
		 
from @TempTable
order by id
for xml PATH, root('rows'))


	-- Return the result of the function
	RETURN @result

END

go

