CREATE VIEW [V_rls_SizeUnits] AS SELECT 
[hDED].[SizeUnitsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[FullName] as [FullName], 
[hDED].[UID] as [UID], 
[hDED].[ShortName] as [ShortName], 
[hDED].[Code] as [Code]
FROM [rls_SizeUnits] as [hDED]
go

