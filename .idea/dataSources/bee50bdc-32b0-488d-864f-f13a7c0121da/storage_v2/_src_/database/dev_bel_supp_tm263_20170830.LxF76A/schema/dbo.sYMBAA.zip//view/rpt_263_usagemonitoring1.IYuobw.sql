



CREATE VIEW [dbo].[rpt_263_UsageMonitoring1]
AS
select okato.O_NAME,
lpu.MCod,
lpu.m_names,
isnull(DateAct.LastDate, '1900-01-01T00:00:00') as LastDate,
isnull(Rep.BedCount, 0) as BedCount,
(select count(*) from oms_hs_direction dir where dir.rf_DirLPUID = lpu.LPUID) as DirCount,--направлений
(select count(*) from oms_hs_Hospital  hosp where hosp.dirlpu_1=lpu.mcod) as hospcount,--госпитализаций
(select count(*) from x_hs_users uss where uss.Code_MO=lpu.mcod) as CountUsers,
(select count(*) from x_hs_users uss1 where uss1.Code_MO=lpu.mcod 
  and uss1.last_login >= DATEADD(ww,-1, current_timestamp)) as CountActiveUsers
from oms_LPU lpu
inner join oms_Okato okato on lpu.rf_OkatoID = okato.OKATOID
left join
(
	select ld.rf_LPUID, max(bf.date) as LastDate
	from oms_hs_BedFond bf
	inner join oms_hs_DepartmentBed db on bf.rf_hs_DepartmentBedID = db.hs_DepartmentBedID
	inner join oms_hs_LPUDepartment ld on ld.hs_LPUDepartmentID = db.rf_hs_LPUDepartmentID
	where ld.Date_E > bf.date and db.Date_E > bf.date and ld.rf_LPUID > 0
	group by ld.rf_LPUID
) DateAct on lpu.LPUID = DateAct.rf_LPUID

left join 
(
		select ld.rf_LPUID, sum(db.Count) as BedCount
	from oms_hs_DepartmentBed db
	inner join oms_hs_LPUDepartment ld on ld.hs_LPUDepartmentID = db.rf_hs_LPUDepartmentID
	where ld.Date_E > getdate() and db.Date_E > getdate() and ld.rf_LPUID > 0
	group by ld.rf_LPUID

	--select ld.rf_LPUID, sum(bf.BedCount) as BedCount, bf.date as RepDate	
	--from oms_hs_BedFond bf
	--inner join oms_hs_DepartmentBed db on bf.rf_hs_DepartmentBedID = db.hs_DepartmentBedID
	--inner join oms_hs_LPUDepartment ld on ld.hs_LPUDepartmentID = db.rf_hs_LPUDepartmentID
	--where ld.Date_E > bf.date and db.Date_E > bf.date and ld.rf_LPUID > 0
	--group by ld.rf_LPUID, bf.date
) Rep on lpu.LPUID = Rep.rf_LPUID --and DateAct.LastDate = Rep.RepDate

where lpu.LPUID != 0
and lpu.Date_E > getdate()


go

