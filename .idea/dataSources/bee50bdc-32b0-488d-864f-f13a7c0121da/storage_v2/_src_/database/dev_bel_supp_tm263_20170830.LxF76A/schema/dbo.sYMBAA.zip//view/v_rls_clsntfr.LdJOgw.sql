CREATE VIEW [V_rls_ClsNtfr] AS SELECT 
[hDED].[ClsNtfrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsNtfrUID] as [rf_ClsNtfrUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[INFO] as [INFO]
FROM [rls_ClsNtfr] as [hDED]
go

