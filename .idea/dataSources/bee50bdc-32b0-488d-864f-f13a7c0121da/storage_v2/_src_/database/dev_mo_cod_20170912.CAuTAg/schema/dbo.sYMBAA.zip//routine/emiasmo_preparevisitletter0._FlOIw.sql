-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION EMIASMO_PrepareVisitLetter 
(
	@uguid uniqueidentifier
)
RETURNS varchar(max)
AS
BEGIN
	
	declare @template varchar(max) = 
'<!DOCTYPE html>

<html>
<head>
    <title></title>
    <style type="text/css">
        .auto-style1 {
            text-align: center;
        }
        .auto-style2 {
            font-size: small;
        }
        #Button1 {
            text-align: center;
        }
    </style>
</head>

<body>

    <p class="auto-style1">
        <strong>Уважаем__PatW __PatIO!<br />
            Спасибо, что воспользовались услугами<br />
            __LPUName<br />
            __VisitDate</strong>
    </p>


    <p>
        Прошу Вас ответить на несколько вопросов, которые помогут улучшить качество работы медицинского учреждения.<br />
        Это займет не более 2-3 минуты. Ваше мнение важно для нас. Конфиденциальность ответов гарантируется.
    </p>

    <a href="https://uslugi.mosreg.ru/zdrav/exit_poll?Visit=__VisitID">Ответить на вопросы</a>

    <p style="text-align: left">
        С уважением,<br />
        Главный врач<br />
        __GV_FIO
        <br />
        Телефон: __LPUPhone
    </p>
</body>
</html>
'
	DECLARE @visitid INT
	DECLARE @mkabid INT
	DECLARE @dttid INT

	SELECT @visitid = doctorvisittableid
		,@dttid = rf_DoctorTimeTableID
		,@mkabid = rf_MKABID
	FROM hlt_DoctorVisitTable
	WHERE UGUID = @uguid

	IF (@visitid = 0)
		RETURN ''

	IF (@mkabid = 0)
		RETURN ''

	IF (@dttid = 0)
		RETURN ''

	DECLARE @PatFio VARCHAR(500)
	DECLARE @PatW INT = - 1

	

	SELECT @PatFio = ltrim(rtrim(Family)) + ' ' + ltrim(rtrim(NAME)) + ' ' + ltrim(rtrim(Ot))
		,@PatW = w
	FROM hlt_mkab
	WHERE mkabid = @mkabid

	IF (@PatW = - 1)
		RETURN ''


	
	SET @template = REPLACE(@template, '__VisitID', cast(@uguid AS VARCHAR(50)))
	SET @template = REPLACE(@template, '__PatIO', @PatFio)

	

	IF @PatW = 0
		SET @template = REPLACE(@template, '__PatW', 'ая')
	ELSE IF @PatW = 1
		SET @template = REPLACE(@template, '__PatW', 'ый')
	ELSE
		RETURN ''

	declare @docprvdid int = 0
	declare @date datetime 

	select @docprvdid = rf_DocPRVDID, @date = date from hlt_doctortimetable where doctortimetableid = @dttid
	
	IF @docprvdid = 0 
		RETURN ''

	SET @template = REPLACE(@template, '__VisitDate',  convert(varchar(10), @date, 104))
	

	declare @depid int = 0
	SET @depid = (SELECT rf_DepartmentID from hlt_DocPRVD where DocPRVDID = @docprvdid)
	
	IF @depid = 0 
		RETURN ''

	declare @lpuid int = 0
	SET @lpuid = (SELECT rf_LPUID from oms_Department where departmentid = @depid)

	IF @lpuid = 0 
		RETURN ''

	declare @mcod varchar(20) = (select ltrim(rtrim(MCOD)) from oms_LPU where lpuid = @lpuid)

	declare @nsilpuid int = 0
	set @nsilpuid = (select case when rf_mainlpuid != 0 then rf_mainlpuid else lpuid end from cod_NSI.dbo.oms_lpu where mcod = @mcod)

	IF @nsilpuid = 0 
		RETURN ''

		

	declare @lpuname varchar(500)
	declare @gv_FIO varchar(500)
	declare @PHONE varchar(500)

	SELECT @lpuname = ltrim(rtrim(M_NAMES)), @PHONE = ltrim(rtrim(TEL)), @gv_FIO = ltrim(rtrim(ltrim(rtrim(FAM_GV)) + ' ' + ltrim(rtrim(IM_GV)) + ' ' + ltrim(rtrim(OT_GV)))) from cod_NSI.dbo.oms_lpu where lpuid = @nsilpuid
	
	if @lpuname = '' return ''
	if @PHONE = '' return ''
	if @gv_FIO = '' return ''
	
	SET @template = REPLACE(@template, '__LPUName',  @lpuname)
	SET @template = REPLACE(@template, '__LPUPhone',  @PHONE)
	SET @template = REPLACE(@template, '__GV_FIO',  @gv_FIO)
	
	-- Return the result of the function
	RETURN @template

END
go

