CREATE VIEW [V_oms_reestr_Registr] AS SELECT 
[hDED].[reestr_RegistrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Num] as [Num], 
[hDED].[Date_Create] as [Date_Create], 
[hDED].[OGRN] as [OGRN], 
[hDED].[GUID] as [GUID]
FROM [oms_reestr_Registr] as [hDED]
go

