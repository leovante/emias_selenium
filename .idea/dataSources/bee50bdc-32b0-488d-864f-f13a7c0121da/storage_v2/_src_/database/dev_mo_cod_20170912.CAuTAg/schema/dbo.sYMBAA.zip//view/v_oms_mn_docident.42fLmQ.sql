CREATE VIEW [V_oms_mn_DocIdent] AS SELECT 
[hDED].[mn_DocIdentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TypeDocID] as [rf_TypeDocID], 
[jT_oms_TYPEDOC].[C_DOC] as [SILENT_rf_TypeDocID], 
[hDED].[rf_mn_PersonID] as [rf_mn_PersonID], 
[jT_oms_mn_Person].[V_FIO] as [SILENT_rf_mn_PersonID], 
[hDED].[Series] as [Series], 
[hDED].[Number] as [Number], 
[hDED].[AuthorName] as [AuthorName], 
[hDED].[AuthorCode] as [AuthorCode], 
[hDED].[DateD] as [DateD], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Comment] as [Comment], 
[hDED].[isActive] as [isActive], 
[hDED].[DocIdentGuid] as [DocIdentGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[SNDoc_Find] as [SNDoc_Find]
FROM [oms_mn_DocIdent] as [hDED]
INNER JOIN [oms_TYPEDOC] as [jT_oms_TYPEDOC] on [jT_oms_TYPEDOC].[TYPEDOCID] = [hDED].[rf_TypeDocID]
INNER JOIN [V_oms_mn_Person] as [jT_oms_mn_Person] on [jT_oms_mn_Person].[mn_PersonID] = [hDED].[rf_mn_PersonID]
go

