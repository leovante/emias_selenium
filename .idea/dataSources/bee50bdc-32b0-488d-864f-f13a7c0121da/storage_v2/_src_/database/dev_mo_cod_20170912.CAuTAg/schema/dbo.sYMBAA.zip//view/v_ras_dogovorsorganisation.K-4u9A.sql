CREATE VIEW [V_ras_DogovorsOrganisation] AS SELECT 
[hDED].[DogovorsOrganisationID], [hDED].[HostDogovorsOrganisationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_OrganisationIDHost] as [rf_OrganisationIDHost], 
[hDED].[rf_DogovorID] as [rf_DogovorID], 
[hDED].[rf_DogovorIDHost] as [rf_DogovorIDHost]
FROM [ras_DogovorsOrganisation] as [hDED]
go

