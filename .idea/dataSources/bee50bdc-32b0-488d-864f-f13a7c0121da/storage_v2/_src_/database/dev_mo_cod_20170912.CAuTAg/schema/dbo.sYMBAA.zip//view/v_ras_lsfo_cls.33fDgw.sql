CREATE VIEW [V_ras_LSFO_CLS] AS SELECT 
[hDED].[LSFO_CLSID], [hDED].[HostLSFO_CLSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_CLSID] as [rf_CLSID], 
[hDED].[rf_LSFOID] as [rf_LSFOID], 
[hDED].[rf_LSFOIDHost] as [rf_LSFOIDHost], 
[hDED].[LSFO] as [LSFO], 
[hDED].[C_PFS] as [C_PFS]
FROM [ras_LSFO_CLS] as [hDED]
go

