CREATE VIEW [V_ras_StatePositionWPL] AS SELECT 
[hDED].[StatePositionWPLID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [ras_StatePositionWPL] as [hDED]
go

