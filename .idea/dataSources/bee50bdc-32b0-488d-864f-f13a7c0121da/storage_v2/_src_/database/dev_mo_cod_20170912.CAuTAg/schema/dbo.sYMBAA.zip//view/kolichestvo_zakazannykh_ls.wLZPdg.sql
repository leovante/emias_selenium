CREATE VIEW [Количество_заказанных_ЛС] AS select 
nom.[name] as [Название ЛС],
pos.c_pfs as [Код позиции перечня ФС],
pos.c_lsfo as [Код ЛС фарморгранизации],
sum(pos.[count])as [Количество упаковок ЛС]

from 
	ras_demand as dem,
	ras_organisation as org, 
	ras_PositionDemand as pos,
	ras_Nomenclature as nom,
	ras_TypeDemand as Dtype
where 
(dem.rf_OrganisationClientID=org.OrganisationID)and
(pos.rf_NomenclatureID=nom.NomenclatureID)and
(dem.rf_typedemandID=dtype.typedemandid)and
(dem.rf_OrganisationProviderID<>0)and
(dem.rf_OrganisationClientID<>0)and(pos.[count]>0)
group by nom.[name],pos.c_pfs,pos.c_lsfo
go

