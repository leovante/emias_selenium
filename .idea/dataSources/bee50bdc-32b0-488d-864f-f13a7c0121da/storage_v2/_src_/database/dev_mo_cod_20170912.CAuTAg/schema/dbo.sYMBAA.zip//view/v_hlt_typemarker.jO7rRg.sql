CREATE VIEW [V_hlt_TypeMarker] AS SELECT 
[hDED].[TypeMarkerID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[COD] as [COD], 
[hDED].[Name] as [Name], 
[hDED].[DefResult] as [DefResult], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[GUID] as [GUID]
FROM [hlt_TypeMarker] as [hDED]
go

