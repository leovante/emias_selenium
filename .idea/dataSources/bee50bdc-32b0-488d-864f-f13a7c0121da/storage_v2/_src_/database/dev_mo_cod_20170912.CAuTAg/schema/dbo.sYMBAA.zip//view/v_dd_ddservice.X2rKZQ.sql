CREATE VIEW [V_dd_DDService] AS SELECT 
[hDED].[DDServiceID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_dd_ServiceType].[ServiceTypeName] as [V_ServiceTypeName], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_ServiceMedicalGUIDSM] as [rf_ServiceMedicalGUIDSM], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[jT_dd_DDType].[Name] as [SILENT_rf_DDTypeGUID], 
[hDED].[rf_ServiceTypeID] as [rf_ServiceTypeID], 
[hDED].[rf_ServiceTypeUGUID] as [rf_ServiceTypeUGUID], 
[hDED].[DDServiceTypeCode] as [DDServiceTypeCode], 
[hDED].[ParamCode] as [ParamCode], 
[hDED].[DDServiceCode] as [DDServiceCode], 
[hDED].[DDServiceName] as [DDServiceName], 
[hDED].[IsParaclinic] as [IsParaclinic], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateBoundary] as [DateBoundary], 
[hDED].[GenderBoundary] as [GenderBoundary], 
[hDED].[AgeMinBoundary] as [AgeMinBoundary], 
[hDED].[AgeMaxBoundary] as [AgeMaxBoundary], 
[hDED].[Q_MU] as [Q_MU], 
[hDED].[HLRCode] as [HLRCode], 
[hDED].[Description] as [Description], 
[hDED].[PrvsCode] as [PrvsCode], 
[hDED].[IsMainInDDType] as [IsMainInDDType], 
[hDED].[IsMedicalServices] as [IsMedicalServices], 
[hDED].[IsResourceDocPrvd] as [IsResourceDocPrvd]
FROM [dd_DDService] as [hDED]
INNER JOIN [dd_ServiceType] as [jT_dd_ServiceType] on [jT_dd_ServiceType].[UGUID] = [hDED].[rf_ServiceTypeUGUID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [dd_DDType] as [jT_dd_DDType] on [jT_dd_DDType].[UGUID] = [hDED].[rf_DDTypeGUID]
go

