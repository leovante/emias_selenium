CREATE VIEW [V_dd_DDChildForm] AS SELECT 
[hDED].[DDChildFormID], [hDED].[x_Edition], [hDED].[x_Status], 
(((Surname + ' ' + [Name] + ' ' + Patronimic))) as [v_FIO], 
(case  
when IndividualRehabilitationRealization=0 and IndividualRehabilitationDate=convert(datetime,'1900-01-01') then 'Не назначена' 
when IndividualRehabilitationRealization=0 and IndividualRehabilitationDate>convert(datetime,'1900-01-01') then 'Полностью' 
when IndividualRehabilitationRealization=1 then 'Частично' 
when IndividualRehabilitationRealization=2 then 'Начато' 
when IndividualRehabilitationRealization=3 then 'Не выполнено' 
else '' end) as [V_IndividualRehabilitationRealization], 
(case when sex=1 then 'мужской' else 'женский' end) as [V_Sex], 
(case when COMMITTED=1 then 'Да' else 'Нет' end) as [V_COMMITTED], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_DocInfo], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_kl_SocStatusID] as [rf_kl_SocStatusID], 
[hDED].[rf_HealthGroupGUID] as [rf_HealthGroupGUID], 
[hDED].[rf_LPUDoctorGUID] as [rf_LPUDoctorGUID], 
[hDED].[rf_CitizenGUID] as [rf_CitizenGUID], 
[hDED].[rf_DispEndReasonGUID] as [rf_DispEndReasonGUID], 
[hDED].[rf_DDRRGGUID] as [rf_DDRRGGUID], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[hDED].[rf_DDReestrID] as [rf_DDReestrID], 
[hDED].[rf_DDScheduleGUID] as [rf_DDScheduleGUID], 
[hDED].[rf_DDStationarInstitutionGUID] as [rf_DDStationarInstitutionGUID], 
[hDED].[rf_DDInvalidityID] as [rf_DDInvalidityID], 
[hDED].[rf_DDVaccinationStatusGUID] as [rf_DDVaccinationStatusGUID], 
[hDED].[rf_DDAbsenceReasonGUID] as [rf_DDAbsenceReasonGUID], 
[hDED].[rf_DDNIRRGGUID] as [rf_DDNIRRGGUID], 
[hDED].[rf_DDNormCostGUID] as [rf_DDNormCostGUID], 
[hDED].[SS] as [SS], 
[hDED].[Surname] as [Surname], 
[hDED].[Name] as [Name], 
[hDED].[Patronimic] as [Patronimic], 
[hDED].[Sex] as [Sex], 
[hDED].[DateOfBirth] as [DateOfBirth], 
[hDED].[S_POL] as [S_POL], 
[hDED].[N_POL] as [N_POL], 
[hDED].[DispensaryDate] as [DispensaryDate], 
[hDED].[SocialCorrectionNeeds] as [SocialCorrectionNeeds], 
[hDED].[PedagogicCorrectionNeeds] as [PedagogicCorrectionNeeds], 
[hDED].[IndividualRehabilitationDate] as [IndividualRehabilitationDate], 
[hDED].[IndividualRehabilitationRealization] as [IndividualRehabilitationRealization], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag], 
[hDED].[InGoodHealth] as [InGoodHealth], 
[hDED].[IsIndividualRehabilitationRecomended] as [IsIndividualRehabilitationRecomended], 
[hDED].[IsHealthInstability] as [IsHealthInstability], 
[hDED].[IsClosed] as [IsClosed], 
[hDED].[DateClose] as [DateClose], 
[hDED].[IsInvalidity] as [IsInvalidity], 
[hDED].[COMMITTED] as [COMMITTED], 
[hDED].[DatePolBegin] as [DatePolBegin], 
[hDED].[DatePolEnd] as [DatePolEnd]
FROM [dd_DDChildForm] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[UGUID] = [hDED].[rf_LPUDoctorGUID]
go

