CREATE VIEW [V_ras_RReestrPay] AS SELECT 
[hDED].[RReestrPayID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RReestrID] as [rf_RReestrID], 
[hDED].[Date_Pay] as [Date_Pay], 
[hDED].[Pay] as [Pay], 
[hDED].[Rem] as [Rem]
FROM [ras_RReestrPay] as [hDED]
go

