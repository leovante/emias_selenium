CREATE VIEW [V_oms_regs_Register] AS SELECT 
[hDED].[regs_RegisterID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[TypeName] as [TypeName], 
[hDED].[Description] as [Description]
FROM [oms_regs_Register] as [hDED]
go

