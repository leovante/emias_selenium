
-- =============================================
-- Author:		Alexandr E. Plaksin
-- Create date: 2017-07-04
-- Description:	Формирует xml из БД cod_MO данные из истории посещений пациента для рейтинга (Москва)
-- =============================================
CREATE PROCEDURE [dbo].[sp_Get_Visit_Rating_Data]
	@TAPID int
as
begin	
	SET NOCOUNT ON;
	--declare @xml xml; -- Для тестов
	--@TAPID int = 1944436

	;WITH XMLNAMESPACES ('http://www.w3.org/2001/XMLSchema' as xsd, 'http://www.w3.org/2001/XMLSchema-instance' AS xsi)
	select cast
	(
		(
			select top 1 
			tap.TAPID as 'id'
			,isnull(ltrim(rtrim(lpu.MCOD)), '') as 'lpu_id'
			,isnull(lpudoctor.Fam_V + ' ' + lpudoctor.IM_V + ' ' + lpudoctor.OT_V, '') as 'fio'
			,tap.UGUID as 'guid'
			from hlt_mkab mkab WITH (NOLOCK) 
			inner join hlt_tap tap  WITH (NOLOCK) on tap.rf_MKABID = mkab.mkabid
			left join oms_Department department  WITH (NOLOCK) on department.DepartmentID = tap.rf_DepartmentID
			left join hlt_LPUDoctor lpudoctor  WITH (NOLOCK) on tap.rf_LPUDoctorID = lpudoctor.lpudoctorid
			left join oms_PRVS prvs  WITH (NOLOCK) on prvs.PRVSID = lpudoctor.rf_PRVSID and prvs.PRVSID > 0
			left join oms_LPU lpu  WITH (NOLOCK) on department.rf_LPUID = lpu.LPUID
			where mkab.mkabid > 0
			and tap.tapid > 0
			and lpu.lpuid > 0
			and tap.TAPID = @TAPID
			for xml path(''), root('DoctorVisitRatingData')
		) as xml
	)
	return;
end;
go

