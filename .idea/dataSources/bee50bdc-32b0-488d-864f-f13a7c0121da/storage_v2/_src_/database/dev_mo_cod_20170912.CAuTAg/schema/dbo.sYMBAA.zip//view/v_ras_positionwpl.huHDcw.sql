CREATE VIEW [V_ras_PositionWPL] AS SELECT 
[hDED].[PositionWPLID], [hDED].[HostPositionWPLID], [hDED].[x_Edition], [hDED].[x_Status], 
hDED.Count*Price as [V_Summa], 
dbo.ras_ConvertToFraction(hDED.Count,(select top 1 Severability1 * Severability2  from ras_Nomenclature nom where jT_ras_StoredLS.rf_NomenclatureID = nom.NomenclatureID and jT_ras_StoredLS.rf_NomenclatureIDHost = nom.HostNomenclatureID)) as [V_FractionCount], 
[jT_ras_StoredLS].[V_Series] as [V_Series], 
[jT_ras_StoredLS].[V_Nomenclature] as [V_Nomenclature], 
[jT_ras_StoredLS].[Price] as [V_Price], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_TypePackingID] as [rf_TypePackingID], 
[hDED].[rf_StatePositionWPLID] as [rf_StatePositionWPLID], 
[hDED].[rf_WriteOffPurposeListID] as [rf_WriteOffPurposeListID], 
[hDED].[rf_WriteOffPurposeListIDHost] as [rf_WriteOffPurposeListIDHost], 
[hDED].[Count] as [Count], 
[hDED].[Date] as [Date], 
[hDED].[GUIDPos] as [GUIDPos], 
[hDED].[GUIDPosList] as [GUIDPosList], 
[hDED].[FLAGS] as [FLAGS]
FROM [ras_PositionWPL] as [hDED]
INNER JOIN [V_ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
go

