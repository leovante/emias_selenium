CREATE VIEW [V_ras_Order] AS SELECT 
[hDED].[OrderID], [hDED].[HostOrderID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Rf_OrganisationProviderID] as [rf_OrganisationProviderID], 
[hDED].[Rf_OrganisationProviderIDHost] as [rf_OrganisationProviderIDHost], 
[jT_ras_Organisation].[Name] as [SILENT_rf_OrganisationProviderID], 
[hDED].[rf_TypeDemandID] as [rf_TypeDemandID], 
[jT_ras_TypeDemand].[Name] as [SILENT_rf_TypeDemandID], 
[hDED].[rf_StateOrderID] as [rf_StateOrderID], 
[jT_ras_StateOrder].[Name] as [SILENT_rf_StateOrderID], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[SendDate] as [SendDate], 
[hDED].[DatePeriodBegin] as [DatePeriodBegin], 
[hDED].[PeriodLen] as [PeriodLen], 
[hDED].[Num] as [Num], 
[hDED].[isBasic] as [isBasic]
FROM [ras_Order] as [hDED]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[Rf_OrganisationProviderID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[Rf_OrganisationProviderIDHost]
INNER JOIN [ras_TypeDemand] as [jT_ras_TypeDemand] on [jT_ras_TypeDemand].[TypeDemandID] = [hDED].[rf_TypeDemandID]
INNER JOIN [ras_StateOrder] as [jT_ras_StateOrder] on [jT_ras_StateOrder].[StateOrderID] = [hDED].[rf_StateOrderID]
go

