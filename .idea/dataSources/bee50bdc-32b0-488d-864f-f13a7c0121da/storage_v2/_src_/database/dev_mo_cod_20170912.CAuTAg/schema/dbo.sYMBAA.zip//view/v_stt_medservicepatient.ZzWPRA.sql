CREATE VIEW [V_stt_MedServicePatient] AS SELECT 
[hDED].[MedServicePatientID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_stt_MedicalHistory].[FAMILY] as [V_Family], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [V_ServiceMedicalName], 
[jT_stt_MedicalHistory].[MedCardNum] as [V_MedCardNum], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode], 
[jT_oms_MKB].[DS] as [V_DS], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[rf_TariffID] as [rf_TariffID], 
[jT_oms_Tariff].[Value1] as [SILENT_rf_TariffID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_InvoiceID] as [rf_InvoiceID], 
[jT_hlt_Invoice].[Num] as [SILENT_rf_InvoiceID], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[jT_stt_MigrationPatient].[rf_StationarBranchID] as [SILENT_rf_MigrationPatientID], 
[hDED].[rf_MedStandartID] as [rf_MedStandartID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[jT_stt_StationarBranch].[V_BranchInfo] as [SILENT_rf_StationarBranchID], 
[hDED].[rf_SurgicalOperationID] as [rf_SurgicalOperationID], 
[jT_stt_SurgicalOperation].[Date] as [SILENT_rf_SurgicalOperationID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_ServiceTypeID] as [rf_ServiceTypeID], 
[jT_stt_ServiceType].[Name] as [SILENT_rf_ServiceTypeID], 
[hDED].[rf_TransfusionID] as [rf_TransfusionID], 
[jT_stt_Transfusion].[rf_MedicalHistoryID] as [SILENT_rf_TransfusionID], 
[hDED].[rf_ProcedurePositionID] as [rf_ProcedurePositionID], 
[jT_stt_ProcedurePosition].[Date] as [SILENT_rf_ProcedurePositionID], 
[hDED].[rf_FHJournalCallID] as [rf_FHJournalCallID], 
[hDED].[rf_ReanimationID] as [rf_ReanimationID], 
[hDED].[rf_MedStageID] as [rf_MedStageID], 
[hDED].[rf_DogovorPayingID] as [rf_DogovorPayingID], 
[jT_hlt_DogovorPaying].[Num] as [SILENT_rf_DogovorPayingID], 
[hDED].[rf_BillServiceID] as [rf_BillServiceID], 
[jT_hlt_BillService].[rf_ServiceMedicalID] as [SILENT_rf_BillServiceID], 
[hDED].[Count] as [Count], 
[hDED].[Date] as [Date], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag], 
[hDED].[flagPay] as [flagPay], 
[hDED].[flagStatic] as [flagStatic], 
[hDED].[flagComplete] as [flagComplete], 
[hDED].[flagBill] as [flagBill], 
[hDED].[PercentComplete] as [PercentComplete], 
[hDED].[Norm] as [Norm], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Sum_Usl] as [Sum_Usl]
FROM [stt_MedServicePatient] as [hDED]
INNER JOIN [stt_MedicalHistory] as [jT_stt_MedicalHistory] on [jT_stt_MedicalHistory].[MedicalHistoryID] = [hDED].[rf_MedicalHistoryID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
INNER JOIN [oms_Tariff] as [jT_oms_Tariff] on [jT_oms_Tariff].[TariffID] = [hDED].[rf_TariffID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_Invoice] as [jT_hlt_Invoice] on [jT_hlt_Invoice].[InvoiceID] = [hDED].[rf_InvoiceID]
INNER JOIN [stt_MigrationPatient] as [jT_stt_MigrationPatient] on [jT_stt_MigrationPatient].[MigrationPatientID] = [hDED].[rf_MigrationPatientID]
INNER JOIN [V_stt_StationarBranch] as [jT_stt_StationarBranch] on [jT_stt_StationarBranch].[StationarBranchID] = [hDED].[rf_StationarBranchID]
INNER JOIN [stt_SurgicalOperation] as [jT_stt_SurgicalOperation] on [jT_stt_SurgicalOperation].[SurgicalOperationID] = [hDED].[rf_SurgicalOperationID]
INNER JOIN [stt_ServiceType] as [jT_stt_ServiceType] on [jT_stt_ServiceType].[ServiceTypeID] = [hDED].[rf_ServiceTypeID]
INNER JOIN [stt_Transfusion] as [jT_stt_Transfusion] on [jT_stt_Transfusion].[TransfusionID] = [hDED].[rf_TransfusionID]
INNER JOIN [stt_ProcedurePosition] as [jT_stt_ProcedurePosition] on [jT_stt_ProcedurePosition].[ProcedurePositionID] = [hDED].[rf_ProcedurePositionID]
INNER JOIN [hlt_DogovorPaying] as [jT_hlt_DogovorPaying] on [jT_hlt_DogovorPaying].[DogovorPayingID] = [hDED].[rf_DogovorPayingID]
INNER JOIN [hlt_BillService] as [jT_hlt_BillService] on [jT_hlt_BillService].[BillServiceID] = [hDED].[rf_BillServiceID]
go

