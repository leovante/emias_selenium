
CREATE TRIGGER [dbo].[mkab_ReturnsTypeID] 
   ON [dbo].[hlt_MKAB]
   AFTER INSERT, UPDATE
AS 
BEGIN
    SET NOCOUNT ON;

    update hlt_ReestrTAPMH
    set rf_ReestrMHReturnsTypeID = 0
    from hlt_ReestrTAPMH 
 join hlt_TAP on TAPID=rf_TAPID
    join inserted i on i.MKABID = hlt_TAP.rf_MKABID
END
go

