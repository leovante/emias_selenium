CREATE VIEW [V_ras_PositionBillShift] AS SELECT 
[hDED].[PositionBillShiftID], [hDED].[HostPositionBillShiftID], [hDED].[x_Edition], [hDED].[x_Status], 
dbo.ras_ConvertToFraction(hDED.Count,(select top 1 Severability1 * Severability2  from ras_Nomenclature nom where jT_ras_StoredLS.rf_NomenclatureID = nom.NomenclatureID and jT_ras_StoredLS.rf_NomenclatureIDHost = nom.HostNomenclatureID)) as [V_FractionCount], 
[jT_ras_StoredLS].[V_TenderNum] as [V_TenderNum], 
[jT_ras_StoredLS].[V_Owner] as [V_Owner], 
[jT_ras_StoredLS].[V_Series] as [V_Series], 
[jT_ras_StoredLS].[V_Producer] as [V_Produсer], 
[jT_ras_StoredLS].[V_Cod_RAS] as [V_COD], 
[jT_ras_StoredLS].[V_Nomenclature] as [V_Nomenclature], 
[jT_ras_StoredLS].[Consigment] as [V_Consigment], 
[hDED].[rf_NDSID] as [rf_NDSID], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_BillShiftID] as [rf_BillShiftID], 
[hDED].[rf_BillShiftIDHost] as [rf_BillShiftIDHost], 
[hDED].[rf_StatePosBillIShiftID] as [rf_StatePosBillIShiftID], 
[hDED].[rf_PositionStatusID] as [rf_PositionStatusID], 
[hDED].[Count] as [Count], 
[hDED].[Price] as [Price], 
[hDED].[Summa] as [Summa], 
[hDED].[SumNDS] as [SumNDS], 
[hDED].[PriceBase] as [PriceBase], 
[hDED].[PriceOPT] as [PriceOPT], 
[hDED].[Note] as [Note]
FROM [ras_PositionBillShift] as [hDED]
INNER JOIN [V_ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
go

