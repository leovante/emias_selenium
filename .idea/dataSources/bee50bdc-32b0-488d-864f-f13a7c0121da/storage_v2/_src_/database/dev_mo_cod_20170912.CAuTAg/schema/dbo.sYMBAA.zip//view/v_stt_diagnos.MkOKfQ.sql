CREATE VIEW [V_stt_Diagnos] AS SELECT 
[hDED].[DiagnosID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_stt_MedicalHistory].[MedCardNum] as [V_MedCardNum], 
[jT_stt_MedicalHistory].[FAMILY] as [V_Family], 
[jT_oms_MKB].[DS] as [V_DS], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_kl_DiseaseTypeID] as [rf_kl_DiseaseTypeID], 
[jT_oms_kl_DiseaseType].[Name] as [SILENT_rf_kl_DiseaseTypeID], 
[hDED].[rf_sc_StandartCureID] as [rf_sc_StandartCureID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_DiagnosTypeID] as [rf_DiagnosTypeID], 
[jT_stt_DiagnosType].[Name] as [SILENT_rf_DiagnosTypeID], 
[hDED].[rf_DiseasePhaseID] as [rf_DiseasePhaseID], 
[jT_stt_DiseasePhase].[Name] as [SILENT_rf_DiseasePhaseID], 
[hDED].[rf_DisageStageID] as [rf_DisageStageID], 
[jT_stt_DisageStage].[Name] as [SILENT_rf_DisageStageID], 
[hDED].[Date] as [Date], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Description] as [Description]
FROM [stt_Diagnos] as [hDED]
INNER JOIN [stt_MedicalHistory] as [jT_stt_MedicalHistory] on [jT_stt_MedicalHistory].[MedicalHistoryID] = [hDED].[rf_MedicalHistoryID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_kl_DiseaseType] as [jT_oms_kl_DiseaseType] on [jT_oms_kl_DiseaseType].[kl_DiseaseTypeID] = [hDED].[rf_kl_DiseaseTypeID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [stt_DiagnosType] as [jT_stt_DiagnosType] on [jT_stt_DiagnosType].[DiagnosTypeID] = [hDED].[rf_DiagnosTypeID]
INNER JOIN [stt_DiseasePhase] as [jT_stt_DiseasePhase] on [jT_stt_DiseasePhase].[DiseasePhaseID] = [hDED].[rf_DiseasePhaseID]
INNER JOIN [stt_DisageStage] as [jT_stt_DisageStage] on [jT_stt_DisageStage].[DisageStageID] = [hDED].[rf_DisageStageID]
go

