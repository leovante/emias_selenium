CREATE VIEW [V_ras_PositionOrgOrder] AS SELECT 
[hDED].[PositionOrgOrderID], [hDED].[HostPositionOrgOrderID], [hDED].[x_Edition], [hDED].[x_Status], 
Realisation*PrNZ/100 as [V_NZ], 
isnull((SELECT SUM(r.[Count]) AS [Count] FROM ras_Reserve r WHERE  r.rf_StateReserveID = 1 AND r.rf_PositionOrgOrderID > 0 AND r.rf_PositionOrgOrderID = hDED.PositionOrgOrderID AND r.rf_PositionOrgOrderIDHost = hDED.HostPositionOrgOrderID GROUP BY r.rf_PositionOrgOrderID ),0) as [V_ResPos], 
isnull((SELECT SUM(r.[Count])FROM ras_reserve r WHERE     r.rf_StateReserveID in( 2,3) AND r.rf_PositionOrgOrderID > 0 AND r.rf_PositionOrgOrderID = hDED.PositionOrgOrderID AND r.rf_PositionOrgOrderIDHost = hDED.HostPositionOrgOrderID GROUP BY r.rf_PositionOrgOrderID,r.rf_PositionOrgOrderIDHost),0) as [V_DelivCount], 
AgreeCount - isnull((SELECT CASE WHEN hDED.AgreeCount >= SUM(r.[Count]) THEN SUM(r.[Count]) ELSE hDED.AgreeCount END FROM ras_reserve r WHERE r.rf_StateReserveID in (2,3) AND r.rf_PositionOrgOrderID > 0 AND r.rf_PositionOrgOrderID = hDED.PositionOrgOrderID and r.rf_PositionOrgOrderIDHost = hDED.HostPositionOrgOrderID GROUP BY r.rf_PositionOrgOrderID,r.rf_PositionOrgOrderIDHost), 0) as [V_Defect], 
isNull((select top 1  sum(LS.[count])as sm from V_ras_StoredLS ls inner join ras_Nomenclature n on ls.rf_NomenclatureID =n.NomenclatureID and ls.rf_NomenclatureIDHost =n.HostNomenclatureID inner join oms_CLS cls on n.rf_CLS=cls.CLSID inner join ras_Store s on ls.rf_StoredID=s.StoreID and ls.rf_StoredIDHost=s.HostStoreID inner join ras_CardOrganisation  c on c.rf_OrganisationID=s.rf_OrganisationID and c.rf_OrganisationIDHost=s.rf_OrganisationIDHost inner join ras_OrgOrder o on o.rf_CardOrganisationID=c.CardOrganisationID and o.rf_CardOrganisationIDHost=c.HostCardOrganisationID where (cls.Date_BP<=convert(datetime,convert(char,getdate(),105),105)) and (cls.date_ep>=convert(datetime,convert(char,getdate(),105),105)) and (ls.Expdate>convert(datetime,convert(char,getdate(),105),105)) and s.isVirtual=1 and (s.rf_TypeDeliveryID =1 or s.rf_TypeDeliveryID =2) and ls.rf_LSFOID=hDED.rf_LSFOID and ls.rf_LSFOIDHost=hDED.rf_LSFOIDHost and o.OrgOrderID = hDED.rf_OrgOrderID and o.HostOrgOrderID = hDED.rf_OrgOrderIDHost group by ls.rf_LSFOID),0) as [V_CountLSAU], 
isNull((SELECT top 1 SUM(LS.[count] - isnull(res.[Count], 0)) AS sm FROM V_ras_StoredLS ls INNER JOIN ras_LSFO lsfo on ls.rf_LSFOID=lsfo.LSFOID and ls.rf_LSFOIDHost=lsfo.HostLSFOID INNER JOIN ras_Nomenclature n ON lsfo.rf_NomenclatureID = n.NomenclatureID and lsfo.rf_NomenclatureIDHost = n.HostNomenclatureID INNER JOIN oms_CLS cls ON n.rf_CLS = cls.CLSID INNER JOIN ras_Store s ON ls.rf_StoredID = s.StoreID and ls.rf_StoredIDHost = s.HostStoreID LEFT JOIN (SELECT r.rf_StoredLSID, r.rf_StoredLSIDHost, SUM(r.[Count]) AS [Count] FROM ras_Reserve r WHERE r.rf_StateReserveID = 1 GROUP BY r.rf_StoredLSID,r.rf_StoredLSIDHost ) res ON res.rf_StoredLSID = LS.StoredLSID and res.rf_StoredLSIDHost = LS.HostStoredLSID WHERE (cls.Date_BP <= convert(datetime,convert(char,getdate(),105),105))AND(cls.date_ep >= convert(datetime,convert(char,getdate(),105),105)) AND (ls.Expdate > convert(datetime,convert(char,getdate(),105),105)) AND s.isVirtual = 0 AND (s.rf_TypeDeliveryID = 1 OR s.rf_TypeDeliveryID = 2) AND ls.rf_LSFOID = hDED.rf_LSFOID AND ls.rf_LSFOIDHost = hDED.rf_LSFOIDHost AND LS.[count] > isnull(res.[Count], 0) GROUP BY ls.rf_LSFOID),0) as [V_CountStoreLS], 
[hDED].[rf_CLSID] as [rf_CLSID], 
[jT_oms_CLS].[C_PFS] as [SILENT_rf_CLSID], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[jT_ras_Nomenclature].[Name] as [SILENT_rf_NomenclatureID], 
[hDED].[rf_LSFOID] as [rf_LSFOID], 
[hDED].[rf_LSFOIDHost] as [rf_LSFOIDHost], 
[jT_ras_LSFO].[C_LSProvider] as [SILENT_rf_LSFOID], 
[hDED].[rf_OrgOrderID] as [rf_OrgOrderID], 
[hDED].[rf_OrgOrderIDHost] as [rf_OrgOrderIDHost], 
[jT_ras_OrgOrder].[NUM] as [SILENT_rf_OrgOrderID], 
[hDED].[rf_StatePositionOrgOrderID] as [rf_StatePositionOrgOrderID], 
[jT_ras_StatePositionOrgOrder].[Name] as [SILENT_rf_StatePositionOrgOrderID], 
[hDED].[Count] as [Count], 
[hDED].[AgreeCount] as [AgreeCount], 
[hDED].[Realisation] as [Realisation], 
[hDED].[Rest] as [Rest], 
[hDED].[PrNZ] as [PrNZ]
FROM [ras_PositionOrgOrder] as [hDED]
INNER JOIN [oms_CLS] as [jT_oms_CLS] on [jT_oms_CLS].[CLSID] = [hDED].[rf_CLSID]
INNER JOIN [ras_Nomenclature] as [jT_ras_Nomenclature] on [jT_ras_Nomenclature].[NomenclatureID] = [hDED].[rf_NomenclatureID] AND  [jT_ras_Nomenclature].[HostNomenclatureID] = [hDED].[rf_NomenclatureIDHost]
INNER JOIN [ras_LSFO] as [jT_ras_LSFO] on [jT_ras_LSFO].[LSFOID] = [hDED].[rf_LSFOID] AND  [jT_ras_LSFO].[HostLSFOID] = [hDED].[rf_LSFOIDHost]
INNER JOIN [ras_OrgOrder] as [jT_ras_OrgOrder] on [jT_ras_OrgOrder].[OrgOrderID] = [hDED].[rf_OrgOrderID] AND  [jT_ras_OrgOrder].[HostOrgOrderID] = [hDED].[rf_OrgOrderIDHost]
INNER JOIN [ras_StatePositionOrgOrder] as [jT_ras_StatePositionOrgOrder] on [jT_ras_StatePositionOrgOrder].[StatePositionOrgOrderID] = [hDED].[rf_StatePositionOrgOrderID]
go

