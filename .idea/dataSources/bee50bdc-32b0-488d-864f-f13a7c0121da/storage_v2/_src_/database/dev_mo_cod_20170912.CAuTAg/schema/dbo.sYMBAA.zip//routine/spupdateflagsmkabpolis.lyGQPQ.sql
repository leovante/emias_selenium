CREATE PROCEDURE [dbo].[spUpdateFlagsMkabPolis]
  (@Flags AS INT,
   @Family AS VARCHAR(100),
   @Polis AS VARCHAR(100)) AS
BEGIN
	IF OBJECT_ID(N'temp_ca_mkab','U') IS NULL
		SELECT (select TOP 1 mkabid from hlt_mkab with(nolock) where family = @Family AND N_POL = @Polis) as mkabid,@Flags as flags
		INTO temp_ca_mkab
	ELSE
		INSERT INTO temp_ca_mkab VALUES ((select TOP 1 mkabid from hlt_mkab with(nolock) where family = @Family AND N_POL = @Polis),@Flags)
END
go

