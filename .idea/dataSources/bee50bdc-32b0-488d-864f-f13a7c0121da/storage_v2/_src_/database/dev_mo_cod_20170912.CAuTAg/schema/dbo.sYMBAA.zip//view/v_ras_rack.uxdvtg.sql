CREATE VIEW [V_ras_Rack] AS SELECT 
[hDED].[RackID], [hDED].[HostRackID], [hDED].[x_Edition], [hDED].[x_Status], 
ISNULL((SELECT TOP 1 ras_Zone.Name + '-' + convert(varchar, rck.Name) FROM ras_Zone INNER JOIN ras_Rack rck ON rck.rf_ZoneID = ras_Zone.ZoneID WHERE rck.RackID = hDED.RackID),'') as [V_Name], 
[hDED].[rf_ZoneID] as [rf_ZoneID], 
[hDED].[rf_ZoneIDHost] as [rf_ZoneIDHost], 
[hDED].[Name] as [Name], 
[hDED].[Barcode] as [Barcode]
FROM [ras_Rack] as [hDED]
go

