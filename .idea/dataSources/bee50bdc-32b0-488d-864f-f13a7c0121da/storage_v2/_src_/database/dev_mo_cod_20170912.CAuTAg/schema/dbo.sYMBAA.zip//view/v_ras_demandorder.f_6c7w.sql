CREATE VIEW [V_ras_DemandOrder] AS SELECT 
[hDED].[DemandOrderID], [hDED].[HostDemandOrderID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PositionOrgOrderID] as [rf_PositionOrgOrderID], 
[hDED].[rf_PositionOrgOrderIDHost] as [rf_PositionOrgOrderIDHost], 
[hDED].[rf_PositionOrderID] as [rf_PositionOrderID], 
[hDED].[rf_PositionOrderIDHost] as [rf_PositionOrderIDHost], 
[hDED].[Count] as [Count]
FROM [ras_DemandOrder] as [hDED]
go

