
CREATE PROCEDURE [dbo].[spMarkRequestAsSuccessfullyProceeded]
  (@OID AS VARCHAR(100),
   @Response AS VARCHAR(MAX)) AS
BEGIN
  UPDATE dbo.hl7_Document SET Flags = 1|Flags, Response = @Response WHERE OID = @OID
END
go

