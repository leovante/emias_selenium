CREATE VIEW [V_hlt_PolisMKAB] AS SELECT 
[hDED].[PolisMKABID], [hDED].[x_Edition], [hDED].[x_Status], 
((select [hded].S_POL + ' ' + [hded].N_POL)) as [V_SN_POL], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_DOGOVORID] as [rf_DOGOVORID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[rf_kl_TipOMSID] as [rf_kl_TipOMSID], 
[jT_oms_kl_TipOMS].[IDDOC] as [SILENT_rf_kl_TipOMSID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[S_POL] as [S_POL], 
[hDED].[N_POL] as [N_POL], 
[hDED].[DatePolBegin] as [DatePolBegin], 
[hDED].[DatePolEnd] as [DatePolEnd], 
[hDED].[isActive] as [isActive], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags]
FROM [hlt_PolisMKAB] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
INNER JOIN [oms_kl_TipOMS] as [jT_oms_kl_TipOMS] on [jT_oms_kl_TipOMS].[kl_TipOMSID] = [hDED].[rf_kl_TipOMSID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
go

