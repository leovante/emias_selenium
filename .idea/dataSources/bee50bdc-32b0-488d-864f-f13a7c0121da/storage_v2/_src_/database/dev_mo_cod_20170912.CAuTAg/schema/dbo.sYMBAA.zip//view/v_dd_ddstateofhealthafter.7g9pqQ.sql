CREATE VIEW [V_dd_DDStateOfHealthAfter] AS SELECT 
[hDED].[DDStateOfHealthAfterID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_MKB].[NAME] as [V_NAME], 
[jT_oms_MKB].[DS] as [V_DS], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_DDTypeDiseaseGUID] as [rf_DDTypeDiseaseGUID], 
[hDED].[rf_DDChildFormID] as [rf_DDChildFormID], 
[hDED].[VMPBefore] as [VMPBefore], 
[hDED].[VMPAfter] as [VMPAfter], 
[hDED].[Flag] as [Flag], 
[hDED].[IsAdjustedMKB] as [IsAdjustedMKB], 
[hDED].[PreviouslyRegistered] as [PreviouslyRegistered], 
[hDED].[IsResearchRecomended] as [IsResearchRecomended], 
[hDED].[IsCureRecomended] as [IsCureRecomended], 
[hDED].[IsCuredBefore] as [IsCuredBefore], 
[hDED].[IsMainDiagnosis] as [IsMainDiagnosis], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDStateOfHealthAfter] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
go

