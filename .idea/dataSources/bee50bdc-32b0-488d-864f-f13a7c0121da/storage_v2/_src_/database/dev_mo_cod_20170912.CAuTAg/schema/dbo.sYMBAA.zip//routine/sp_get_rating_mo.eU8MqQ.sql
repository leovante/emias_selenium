
-- =============================================
-- Author:		Alexandr E. Plaksin
-- Create date: 2017-07-04
-- Description:	Формирует JSON из БД cod_MO данные для рейтинга МО (Москва)
-- =============================================
CREATE PROCEDURE [dbo].[sp_Get_Rating_MO] @typeQuiz uniqueidentifier = '76C90E4D-7692-415C-AD55-8DB50775D77E'
AS 
	BEGIN
		SET NOCOUNT ON;
		select Count(r.value) as col
			, r.orderNumber + 1 as paramt
			, r.value as mark
			, rtrim(ltrim(q.mcod)) as mcode
		into #t
		from rpt_quizResult r
			join rpt_quizMessage q on r.qMessageGuid = q.uguid
		where r.qTypeGuid = @typeQuiz 
		and q.docFIO in
		( 
			select distinct m.docFIO --select *
			from rpt_quizMessage m
			where m.isNotVisit != 1		
		)
		and q.mcod != '' and q.mcod is not null
		group by r.orderNumber, r.value, q.mcod
		order by q.mcod, r.orderNumber, r.value
		
		--select * from #t --drop table #t
		
		declare @xml xml
		set @xml =
		(select 
			mcode as 'lpuCode'
			, cast((cast(sum(tt.col * tt.mark) as float) / sum(tt.col)) as float) as 'rating'
			, (
				select t.paramt as 'NumQuestion'
				, cast((cast(sum(t.col * t.mark) as float) / sum(t.col)) as float) as 'Avg'
				, sum(t.col) as 'VoteCount'
				, sum(t.col * t.mark) as 'summa'
				, (					
					select ('"' + cast(mark as varchar(10))+ '":"'+ cast( col as varchar(10)) + '",' ) 
					from #t r
					where r.mcode = tt.mcode and r.paramt = t.paramt
					for xml path(''),root('DetailResult'), type			
				)
				from #t t
				where t.mcode = tt.mcode
				group by t.paramt
				for xml path('qri'), root('quizResult'), type
			)
		from #t tt
		group by mcode
		for xml path('item'), root('root'))
		
		--select @xml		
		
		SELECT REPLACE(REPLACE(REPLACE('[' + Stuff(  
		  (SELECT * from  
		    (SELECT ',
		    {'+  
		      Stuff((SELECT ',"'+coalesce(b.c.value('local-name(.)', 'NVARCHAR(MAX)'),'') +
		                    (CASE WHEN b.c.value('text()[1]','NVARCHAR(MAX)') IS NULL 
							THEN 
							'":['+ 
							((SELECT  ' {'+  
								  Stuff((SELECT ',"'+coalesce(k.l.value('local-name(.)', 'NVARCHAR(MAX)'),'')+'":"'+										
												k.l.value('text()[1]','NVARCHAR(MAX)') +'"'
		               
										 from t.y.nodes('*') k(l)  
										 for xml path(''),TYPE).value('(./text())[1]','NVARCHAR(MAX)')
									,1,1,'')+'},' 
							   from b.c.nodes('*') t(y)
							   for xml Path(''), type).value('.','NVARCHAR(MAX)' )
							   )+']'
							ELSE '":"'+ b.c.value('text()[1]','NVARCHAR(MAX)')+'"' END)
		               
		             from x.a.nodes('*') b(c)  
		             for xml path(''),TYPE).value('(./text())[1]','NVARCHAR(MAX)')
		        ,1,1,'')+'}' 
		   from @xml.nodes('/root/*') x(a)  
		   ) JSON(theLine)  
		  for xml path(''),TYPE).value('.','NVARCHAR(MAX)' )
		,1,1,'') + ']', ',"}', '} }'), '"DetailResult":"', '"DetailResult": {'), '} },]}', '} }]}')
		RETURN;
	END;
go

