CREATE VIEW [V_oms_pr_ProfPlan] AS SELECT 
[hDED].[pr_ProfPlanID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_pr_Person].[V_Person] as [V_V_Person], 
[jT_oms_pr_ProcRes].[Name] as [V_NameFLK], 
[jT_oms_pr_ProfType].[Name] as [V_NameType], 
[hDED].[rf_pr_ProfTypeID] as [rf_pr_ProfTypeID], 
[hDED].[rf_pr_ReestrID] as [rf_pr_ReestrID], 
[hDED].[rf_pr_PersonID] as [rf_pr_PersonID], 
[hDED].[rf_pr_ProcResID] as [rf_pr_ProcResID], 
[hDED].[ID_PAC] as [ID_PAC], 
[hDED].[isActual] as [isActual], 
[hDED].[Year] as [Year], 
[hDED].[Quarter] as [Quarter], 
[hDED].[Reject_DATE] as [Reject_DATE], 
[hDED].[INOUT] as [INOUT], 
[hDED].[Rem] as [Rem]
FROM [oms_pr_ProfPlan] as [hDED]
INNER JOIN [V_oms_pr_Person] as [jT_oms_pr_Person] on [jT_oms_pr_Person].[pr_PersonID] = [hDED].[rf_pr_PersonID]
INNER JOIN [oms_pr_ProcRes] as [jT_oms_pr_ProcRes] on [jT_oms_pr_ProcRes].[pr_ProcResID] = [hDED].[rf_pr_ProcResID]
INNER JOIN [oms_pr_ProfType] as [jT_oms_pr_ProfType] on [jT_oms_pr_ProfType].[pr_ProfTypeID] = [hDED].[rf_pr_ProfTypeID]
go

