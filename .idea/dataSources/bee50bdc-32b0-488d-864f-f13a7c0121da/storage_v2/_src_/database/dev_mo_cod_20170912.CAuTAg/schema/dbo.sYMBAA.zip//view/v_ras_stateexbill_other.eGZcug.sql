CREATE VIEW [V_ras_StateExBill_Other] AS SELECT 
[hDED].[StateExBill_OtherID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Action] as [Action]
FROM [ras_StateExBill_Other] as [hDED]
go

