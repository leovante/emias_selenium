CREATE VIEW [dbo].[sl_Recipe] AS

SELECT 

[DPCPharmacyRecipeID]													as IdRecipe		,
	'' 																	as IdS		
,	''																	as Dt		
,ltrim(rtrim(P_OGRN))+' '+ ltrim(rtrim(A_COD))							as IdOrg		
,	''																	as IrRec		
,	''																	as estate	
,[StatusEdition]														as s_status
,[DateObr]																as dt_create		
,	''																	as dt_change	
,	'' 																	as isvalid	
,[KO_ALL]																as k_cnt		
,[nomk_ls]																as k_code_ls
,[DATE_VR]																as k_dateobr	
,[DATE_OTP]																as k_dateotp	
,round([PRICE]*[KO_ALL],2)												as k_sum		
,	''																	as k_manual	
,oms_Person.ADRES														as p_adres	
,oms_Person.dr															as p_dr		
,oms_Person.ss															as p_snils	
,oms_Person.FAMILY														as p_fam		
,oms_Person.NAME														as p_im		
,oms_Person.Patronymic													as p_ot		
,C_KATL																	as p_katl	
,ltrim(rtrim(C_OGRN))+' '+ ltrim(rtrim(	MCOD))							as p_lpu		
,SUBSTRING(SN_POL,1,abs(LEN(SN_POL)-(CHARINDEX(' ',REVERSE (SN_POL)))))	as p_pser	
,SUBSTRING (SN_POL, 
LEN(SN_POL)+1-(CHARINDEX(' ', REVERSE (SN_POL))),
CHARINDEX(' ', REVERSE (SN_POL)))										as p_pnom	
,SUBSTRING (SN_doc,1 , LEN(SN_DOC)-(CHARINDEX(' ',REVERSE (SN_DOC))))	as p_passer	
,SUBSTRING(SN_DOC,LEN(SN_DOC)+1-(CHARINDEX(' ',REVERSE (SN_DOC))),
CHARINDEX(' ',REVERSE (SN_DOC)))										as p_pasnom	
,oms_Person.W 															as p_pol		
,	''																	as p_sverka		
,C_OKATO																as p_reg		
,   ''																	as p_phone		
,[KV_ALL]																as s_cnt		
,[nomk_ls]																as s_codels		
,[DATE_VR]																as s_datevid		
,oms_doctor.PCOD														as s_doctor		
,oms_doctor.FAM_V														as s_fam
,oms_doctor.IM_V														as s_im
,oms_doctor.OT_V														as s_ot	
,oms_MKB.DS																as s_mkb	
,oms_MNName.C_MNN														as s_mnn	
,[Num_Recipe]															as s_rnom
,[Series_Recipe]														as s_rser
,[rf_PeriodID]															as s_srok
,(case when D_LS!='0' 
then D_LS+' '+NAME_DLS else '' end +
case when M_LF>0 then ' / '
+convert(varchar,M_LF)+' '+NAME_MLF 
else '' end +
case when V_LF>0 then ' / '
+convert(varchar,V_LF)+' '+NAME_VLF 
else ''end +
case when N_DOZA>0 then ' / '
+convert(varchar,N_DOZa)+' доз' 
else '' end +
case when N_FV>0 then ' № '
+convert(varchar,N_FV) else '' end )									as s_doz	
,	''																	as s_type
,oms_MLF.C_MLF															as s_mlf	
,oms_VLF.C_VLF															as s_vlf	
,	''																	as s_cdls
,oms_MLF.NAME_MLF														as s_cmlf	
,oms_VLF.NAME_VLF														as s_cvlf
,oms_LF.C_LF															as s_clf		
,[StatusEdition]														as actual		
,	''																	as idotper	
,	''																	as fg		
,	''																	as idotper2	
,[rf_DPCPharmacyRecipeReestrID]											as idreestr	
,lgota.NAME_DL															as p_sprav	
,lgota.SN_DL															as p_sprnom	
,lgota.DATE_BL															as p_sprdat	
,lgota.DATE_BL															as p_sprd1	
,lgota.DATE_EL															as p_sprd2	
,	''																	as c_err		
,	''																	as k_dateotl	
,	''																	as k_dateann	
,ltrim(rtrim(FO_OGRN))+' '+ ltrim(rtrim(CFO))							as owner		
					
  FROM [oms_DPCPharmacyRecipe]		
inner join oms_Ls on [LSID]=[oms_DPCPharmacyRecipe].[rf_LSID]
inner join oms_DLS on oms_Ls.rf_DLSID = DLSId
inner join oms_VLF on rf_VLFID = VLFID
inner join oms_MLF on rf_MLFID = MLFID
inner join  oms_person on personID=rf_personID
inner join (
select oms_LG_Person.*
from oms_LG_Person inner join
(select rf_PersonID, Min(LG_PersonID) as ID from oms_LG_Person
where Getdate()> Date_BL  and GetDate()< Date_EL
group by rf_PersonID
) p on p.ID = LG_PersonID
) lgota on lgota.rf_PersonID = personID
inner join oms_lpu on lpuID=rf_lpuID
inner join oms_doctor  on doctorID=rf_doctorID
inner join oms_apu on apuID=rf_apuID
inner join oms_sfo on sfoID=oms_DPCPharmacyRecipe.rf_sfoID
inner join oms_okato on okatoID=oms_person.rf_OKATO_OMS_ID
inner join oms_katl on katlID=oms_DPCPharmacyRecipe.rf_katlID
inner join oms_mkb on mkbID=rf_mkbID
inner join oms_MNName on MNNameID=oms_ls.rf_MNNameID
inner join oms_LF on LFID=oms_ls.rf_lfid
where statusedition=0 and DPCPharmacyRecipeid<>0
go

