CREATE VIEW [V_ras_OrgOrder] AS SELECT 
[hDED].[OrgOrderID], [hDED].[HostOrgOrderID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrganisationProviderID] as [rf_OrganisationProviderID], 
[hDED].[rf_OrganisationProviderIDHost] as [rf_OrganisationProviderIDHost], 
[jT_ras_Organisation].[Name] as [SILENT_rf_OrganisationProviderID], 
[hDED].[rf_TypeDemandID] as [rf_TypeDemandID], 
[jT_ras_TypeDemand].[Name] as [SILENT_rf_TypeDemandID], 
[hDED].[rf_CardOrganisationID] as [rf_CardOrganisationID], 
[hDED].[rf_CardOrganisationIDHost] as [rf_CardOrganisationIDHost], 
[jT_ras_CardOrganisation].[Organisation] as [SILENT_rf_CardOrganisationID], 
[hDED].[rf_StateOrgOrderID] as [rf_StateOrgOrderID], 
[jT_ras_StateOrgOrder].[Name] as [SILENT_rf_StateOrgOrderID], 
[hDED].[DatePeriodBegin] as [DatePeriodBegin], 
[hDED].[PerionLen] as [PerionLen], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[LockDate] as [LockDate], 
[hDED].[NUM] as [NUM], 
[hDED].[Priority] as [Priority]
FROM [ras_OrgOrder] as [hDED]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationProviderID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationProviderIDHost]
INNER JOIN [ras_TypeDemand] as [jT_ras_TypeDemand] on [jT_ras_TypeDemand].[TypeDemandID] = [hDED].[rf_TypeDemandID]
INNER JOIN [ras_CardOrganisation] as [jT_ras_CardOrganisation] on [jT_ras_CardOrganisation].[CardOrganisationID] = [hDED].[rf_CardOrganisationID] AND  [jT_ras_CardOrganisation].[HostCardOrganisationID] = [hDED].[rf_CardOrganisationIDHost]
INNER JOIN [ras_StateOrgOrder] as [jT_ras_StateOrgOrder] on [jT_ras_StateOrgOrder].[StateOrgOrderID] = [hDED].[rf_StateOrgOrderID]
go

