CREATE VIEW [V_oms_sc_AgeRange] AS SELECT 
[hDED].[sc_AgeRangeID], [hDED].[x_Edition], [hDED].[x_Status], 
((((Name+ ' ('+convert(varchar, AgeFrom) + ' - ' + convert(varchar, AgeTo)+')' )))) as [V_Range], 
[hDED].[rf_kl_AgeGroupID] as [rf_kl_AgeGroupID], 
[hDED].[AgeFrom] as [AgeFrom], 
[hDED].[AgeTo] as [AgeTo], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Filter] as [Filter], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[GUIDAgeRange] as [GUIDAgeRange]
FROM [oms_sc_AgeRange] as [hDED]
go

