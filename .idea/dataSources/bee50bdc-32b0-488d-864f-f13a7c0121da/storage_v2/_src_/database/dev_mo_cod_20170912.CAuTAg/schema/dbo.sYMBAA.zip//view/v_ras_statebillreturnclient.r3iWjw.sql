CREATE VIEW [V_ras_StateBillReturnClient] AS SELECT 
[hDED].[StateBillReturnClientID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [ras_StateBillReturnClient] as [hDED]
go

