CREATE VIEW [V_stt_MedicalHistory] AS SELECT 
[hDED].[MedicalHistoryID], [hDED].[x_Edition], [hDED].[x_Status], 
((([hDED].Family + ' ' + [hDED].Name + ' ' + [hDED].OT))) as [FIO], 
((isNull
( 
	(select bed.Num BedNum from stt_MigrationPatient mp
	inner join
		(	
			select rf_medicalHistoryID,max(DateIngoing) lastDateIn from stt_MigrationPatient
			group by rf_medicalHistoryID
		) lmp on lmp.rf_medicalHistoryID = mp.rf_medicalHistoryID and lastDateIn = DateIngoing
	inner join 
		(
			select BedAct.* from stt_BedAction BedAct
			inner join
			(
				select rf_BedID,max(date) date from stt_BedAction
				group by rf_BedID	 
			) lastBedAct on LastBedAct.rf_BedID = bedAct.rf_BedID and LastBedAct.date = bedAct.date
			inner join stt_ActionType at on at.ActionTypeID = BedAct.rf_ActionTypeID
			where at.code = 1
		) BedAction on rf_MigrationPatientID = mp.MigrationPatientID
	inner join stt_bed bed on rf_bedID = BedID 
where MigrationPatientID>0 and BedID>0  and  mp.rf_medicalHistoryID =hDED.medicalHistoryID ),''
))) as [V_BedNum], 
((isNull
(
	(
		select Ward.Num WardNum  from stt_MigrationPatient mp
		inner join
		(	
			select rf_medicalHistoryID,max(DateIngoing) lastDateIn from stt_MigrationPatient
			group by rf_medicalHistoryID
		) lmp on lmp.rf_medicalHistoryID = mp.rf_medicalHistoryID and lastDateIn = DateIngoing
		inner join 
		(
			select BedAct.* from stt_BedAction BedAct
			inner join
			(
				select rf_BedID,max(date) date from stt_BedAction
				group by rf_BedID	 
			) lastBedAct on LastBedAct.rf_BedID = bedAct.rf_BedID and LastBedAct.date = bedAct.date
			inner join stt_ActionType at on at.ActionTypeID = BedAct.rf_ActionTypeID
			where at.code = 1
		) BedAction on rf_MigrationPatientID = mp.MigrationPatientID
		inner join stt_bed bed on rf_bedID = BedID 
		inner join stt_ward ward on rf_wardID = WardID 
		where MigrationPatientID>0 and BedID>0 and WardID>0 and mp.rf_medicalHistoryID =hDED.medicalHistoryID 
	)
,''))) as [V_WardNum], 
(isNull((SELECT 
				Case When rf_DepartmentID>0 then '['+d.DepartmentCODE+'] ' + d.DepartmentNAME
				else 
					( 
					    select top 1 '['+ldp.DepartmentCODE+'] ' + ldp.DepartmentNAME from v_PredLastMigration plm
						join stt_StationarBranch plsb on plm.rf_StationarBranchID =plsb.StationarBranchID
						join oms_Department ldp on plsb.rf_DepartmentID = ldp.DepartmentID
						where hded.MedicalHistoryID = plm.rf_MedicalHistoryID
					)
			   end  
		FROM [v_CurentMigrationPatient] m
        inner join stt_StationarBranch br on br.StationarBranchID = m.rf_StationarBranchID   
        inner join oms_Department d on br.rf_DepartmentID = d.DepartmentID     
		where hDed.MedicalHistoryID = m.rf_MedicalHistoryID),'')) as [V_StationarBranchInfo], 
((((isNull((select v_DocInfo from V_hlt_LPUDoctor 
where LPUDoctorID = (select rf_LPUDoctorID from v_CurentAttendingDoctor where rf_MedicalHistoryID = MedicalHistoryID)
),''))))) as [V_AtendDoc], 
((select
[dbo].[FullYearAge](BD,DateRecipient)
from stt_medicalHistory where MedicalHistoryID=[hDED].MedicalHistoryID )) as [V_Age], 
(isNull
(
	(
		select ('['+[oms_Department].[DepartmentCODE]+'] ' +[oms_Department].[DepartmentNAME]) from stt_MigrationPatient mp
		inner join
		(	
			select rf_medicalHistoryID,max(DateIngoing) lastDateIn from stt_MigrationPatient
			group by rf_medicalHistoryID
		) lmp on lmp.rf_medicalHistoryID = mp.rf_medicalHistoryID and lastDateIn = DateIngoing
		inner join 
		(
			select BedAct.* from stt_BedAction BedAct
			inner join
			(
				select rf_BedID,max(date) date from stt_BedAction
				group by rf_BedID	 
			) lastBedAct on LastBedAct.rf_BedID = bedAct.rf_BedID and LastBedAct.date = bedAct.date
			inner join stt_ActionType at on at.ActionTypeID = BedAct.rf_ActionTypeID
			where at.code = 1
		) BedAction on rf_MigrationPatientID = mp.MigrationPatientID
		inner join stt_bed bed on rf_bedID = BedID 
		inner join stt_ward ward on rf_wardID = WardID 
		inner join stt_StationarBranch statBranch on  ward.rf_stationarBranchID = StationarBranchID
		inner join [oms_Department] on statBranch.rf_DepartmentID = oms_Department.DepartmentID
		where MigrationPatientID>0 and BedID>0 and WardID>0 and
		statBranch.StationarBranchID>0 and DepartmentID>0
		and mp.rf_medicalHistoryID =hDED.medicalHistoryID 
	)
,'')) as [V_AssignedBranch], 
(((select case when exists(select  1 from stt_diagnos d
inner join stt_DiagnosType dt on d.rf_DiagnosTypeid=dt.DiagnosTypeID
where rf_medicalHistoryID = hDED.medicalHistoryID
and dt.code = '03' 
and d.rf_sc_StandartCureID>0) then 1 else 0 end))) as [V_IsStandart], 
(isnull((select top 1 DS from stt_Diagnos d
  join Oms_mkb mkb on d.rf_MKBID =mkb.MKBID
  join stt_DiagnosType dt on d.rf_DiagnosTypeID =dt.DiagnosTypeID
  where 
  d.rf_MedicalHistoryID = MedicalHistoryID
  and ltrim(rtrim(dt.Code)) in ('03','07','10')
  order by d.Date desc
 ),'')) as [V_DS], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[hDED].[rf_SMOOKATOID] as [rf_SMOOKATOID], 
[jT_oms_OKATO].[C_OKATO] as [SILENT_rf_SMOOKATOID], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_TypeDocID] as [rf_TypeDocID], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[jT_oms_KATL].[C_KATL] as [SILENT_rf_KATLID], 
[hDED].[rf_kl_SocStatusID] as [rf_kl_SocStatusID], 
[hDED].[rf_kl_TraumaTypeID] as [rf_kl_TraumaTypeID], 
[hDED].[rf_kl_HospChanelID] as [rf_kl_HospChanelID], 
[hDED].[rf_kl_VisitResultID] as [rf_kl_VisitResultID], 
[jT_oms_kl_VisitResult].[Name] as [SILENT_rf_kl_VisitResultID], 
[hDED].[rf_kl_StatCureResultID] as [rf_kl_StatCureResultID], 
[hDED].[rf_kl_SickListReasonID] as [rf_kl_SickListReasonID], 
[hDED].[rf_kl_TransferDirectionID] as [rf_kl_TransferDirectionID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[rf_kl_PrivilegeCategoryID] as [rf_kl_PrivilegeCategoryID], 
[hDED].[rf_LiveAddressID] as [rf_LiveAddressID], 
[hDED].[rf_RegAddressID] as [rf_RegAddressID], 
[hDED].[rf_kl_PatientStatusID] as [rf_kl_PatientStatusID], 
[hDED].[rf_kl_TipOMSID] as [rf_kl_TipOMSID], 
[jT_oms_kl_TipOMS].[IDDOC] as [SILENT_rf_kl_TipOMSID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_CitizenID] as [rf_CitizenID], 
[hDED].[rf_LPUDoctorAdmRoomID] as [rf_LPUDoctorAdmRoomID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorAdmRoomID], 
[hDED].[rf_MedPersonUserID] as [rf_MedPersonUserID], 
[hDED].[rf_OtherSMOID] as [rf_OtherSMOID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_IntoxicationID] as [rf_IntoxicationID], 
[hDED].[rf_HospResultID] as [rf_HospResultID], 
[hDED].[rf_HospExitID] as [rf_HospExitID], 
[hDED].[rf_PreHospDeffectID] as [rf_PreHospDeffectID], 
[hDED].[rf_AmbulanceID] as [rf_AmbulanceID], 
[hDED].[rf_StationarTypeID] as [rf_StationarTypeID], 
[hDED].[rf_HospPeriodID] as [rf_HospPeriodID], 
[hDED].[rf_InterruptEventID] as [rf_InterruptEventID], 
[hDED].[rf_InjuryID] as [rf_InjuryID], 
[hDED].[rf_MotherMHID] as [rf_MotherMHID], 
[hDED].[rf_GenderTypeID] as [rf_GenderTypeID], 
[jT_stt_GenderType].[Gender] as [SILENT_rf_GenderTypeID], 
[hDED].[rf_EmerSignID] as [rf_EmerSignID], 
[hDED].[rf_HospDegreeID] as [rf_HospDegreeID], 
[hDED].[rf_BloodGroupID] as [rf_BloodGroupID], 
[hDED].[rf_RhID] as [rf_RhID], 
[jT_stt_Rh].[Name] as [SILENT_rf_RhID], 
[hDED].[rf_PatTransportID] as [rf_PatTransportID], 
[jT_stt_PatTransport].[Name] as [SILENT_rf_PatTransportID], 
[hDED].[rf_WorkStatusID] as [rf_WorkStatusID], 
[jT_stt_WorkStatus].[Name] as [SILENT_rf_WorkStatusID], 
[hDED].[rf_BedProfileID] as [rf_BedProfileID], 
[jT_stt_BedProfile].[Name] as [SILENT_rf_BedProfileID], 
[hDED].[rf_MedCardTypeID] as [rf_MedCardTypeID], 
[hDED].[rf_OKSMID] as [rf_OKSMID], 
[hDED].[rf_kl_OS_SluchID] as [rf_kl_OS_SluchID], 
[jT_oms_kl_OS_Sluch].[Name] as [SILENT_rf_kl_OS_SluchID], 
[hDED].[FAMILY] as [FAMILY], 
[hDED].[Name] as [Name], 
[hDED].[OT] as [OT], 
[hDED].[Sex] as [Sex], 
[hDED].[BD] as [BD], 
[hDED].[S_POL] as [S_POL], 
[hDED].[N_POL] as [N_POL], 
[hDED].[S_DOC] as [S_DOC], 
[hDED].[N_DOC] as [N_DOC], 
[hDED].[WhoGiveout_DOC] as [WhoGiveout_DOC], 
[hDED].[WhenGiveout_DOC] as [WhenGiveout_DOC], 
[hDED].[Address] as [Address], 
[hDED].[WorkInfo] as [WorkInfo], 
[hDED].[NumDirection] as [NumDirection], 
[hDED].[DateDirection] as [DateDirection], 
[hDED].[NumGarb] as [NumGarb], 
[hDED].[DateRecipient] as [DateRecipient], 
[hDED].[DateRecipientHS] as [DateRecipientHS], 
[hDED].[DateExtract] as [DateExtract], 
[hDED].[DurationHosp] as [DurationHosp], 
[hDED].[InspectedRW] as [InspectedRW], 
[hDED].[InspectedAIDS] as [InspectedAIDS], 
[hDED].[isWorker] as [isWorker], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[CauseDeath] as [CauseDeath], 
[hDED].[MedCardNum] as [MedCardNum], 
[hDED].[SS] as [SS], 
[hDED].[LiveAddress] as [LiveAddress], 
[hDED].[BloodRhGroupCheked] as [BloodRhGroupCheked], 
[hDED].[Allergy] as [Allergy], 
[hDED].[GestationalAge] as [GestationalAge], 
[hDED].[Note] as [Note], 
[hDED].[SendingDoctor] as [SendingDoctor], 
[hDED].[PercentComplite] as [PercentComplite], 
[hDED].[isAgreePPD] as [isAgreePPD], 
[hDED].[DateAgreePPD] as [DateAgreePPD], 
[hDED].[PatientCode] as [PatientCode], 
[hDED].[InReanimation] as [InReanimation], 
[hDED].[BirthPlace] as [BirthPlace], 
[hDED].[MHelpBeforeReg] as [MHelpBeforeReg], 
[hDED].[WOPatronymic] as [WOPatronymic], 
[hDED].[ChildNum] as [ChildNum], 
[hDED].[BirthWeight] as [BirthWeight], 
[hDED].[OpenDateNWD] as [OpenDateNWD], 
[hDED].[CloseDateNWD] as [CloseDateNWD], 
[hDED].[S_NWD] as [S_NWD], 
[hDED].[N_NWD] as [N_NWD], 
[hDED].[IntoleranceLS] as [IntoleranceLS], 
[hDED].[KBGUID] as [KBGUID], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[CreateDate] as [CreateDate]
FROM [stt_MedicalHistory] as [hDED]
INNER JOIN [oms_OKATO] as [jT_oms_OKATO] on [jT_oms_OKATO].[OKATOID] = [hDED].[rf_SMOOKATOID]
INNER JOIN [oms_KATL] as [jT_oms_KATL] on [jT_oms_KATL].[KATLID] = [hDED].[rf_KATLID]
INNER JOIN [oms_kl_VisitResult] as [jT_oms_kl_VisitResult] on [jT_oms_kl_VisitResult].[kl_VisitResultID] = [hDED].[rf_kl_VisitResultID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
INNER JOIN [oms_kl_TipOMS] as [jT_oms_kl_TipOMS] on [jT_oms_kl_TipOMS].[kl_TipOMSID] = [hDED].[rf_kl_TipOMSID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorAdmRoomID]
INNER JOIN [stt_GenderType] as [jT_stt_GenderType] on [jT_stt_GenderType].[GenderTypeID] = [hDED].[rf_GenderTypeID]
INNER JOIN [stt_Rh] as [jT_stt_Rh] on [jT_stt_Rh].[RhID] = [hDED].[rf_RhID]
INNER JOIN [stt_PatTransport] as [jT_stt_PatTransport] on [jT_stt_PatTransport].[PatTransportID] = [hDED].[rf_PatTransportID]
INNER JOIN [stt_WorkStatus] as [jT_stt_WorkStatus] on [jT_stt_WorkStatus].[WorkStatusID] = [hDED].[rf_WorkStatusID]
INNER JOIN [stt_BedProfile] as [jT_stt_BedProfile] on [jT_stt_BedProfile].[BedProfileID] = [hDED].[rf_BedProfileID]
INNER JOIN [oms_kl_OS_Sluch] as [jT_oms_kl_OS_Sluch] on [jT_oms_kl_OS_Sluch].[kl_OS_SluchID] = [hDED].[rf_kl_OS_SluchID]
go

