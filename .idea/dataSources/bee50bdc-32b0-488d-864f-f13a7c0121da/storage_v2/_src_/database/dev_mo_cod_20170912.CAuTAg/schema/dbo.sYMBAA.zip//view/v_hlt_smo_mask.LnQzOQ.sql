CREATE VIEW [V_hlt_SMO_Mask] AS SELECT 
[hDED].[SMO_MaskID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[S_Mask] as [S_Mask], 
[hDED].[N_Mask] as [N_Mask], 
[hDED].[Flag] as [Flag]
FROM [hlt_SMO_Mask] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
go

