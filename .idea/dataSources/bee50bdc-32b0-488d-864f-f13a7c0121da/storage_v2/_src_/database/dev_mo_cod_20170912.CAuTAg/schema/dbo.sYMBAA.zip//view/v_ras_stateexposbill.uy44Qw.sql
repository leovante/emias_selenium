CREATE VIEW [V_ras_StateExPosBill] AS SELECT 
[hDED].[StateExPosBillID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note]
FROM [ras_StateExPosBill] as [hDED]
go

