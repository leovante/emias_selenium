CREATE VIEW [V_hlt_ActionSchedule] AS SELECT 
[hDED].[ActionScheduleID], [hDED].[x_Edition], [hDED].[x_Status], 
(SELECT dtd.[NAME] 
FROM x_DocTypeDef dtd
WHERE dtd.DocTypeDefID = hDED.DocTypeDefID
 ) as [V_DocTypeDef], 
[hDED].[rf_DoctorVisitTableID] as [rf_DoctorVisitTableID], 
[hDED].[DocTypeDefID] as [DocTypeDefID], 
[hDED].[rf_DocTypeID] as [rf_DocTypeID], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_ActionSchedule] as [hDED]
go

