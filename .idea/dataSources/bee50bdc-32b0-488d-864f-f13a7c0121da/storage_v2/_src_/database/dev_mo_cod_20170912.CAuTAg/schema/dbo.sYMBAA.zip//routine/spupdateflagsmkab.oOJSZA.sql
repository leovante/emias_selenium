CREATE PROCEDURE [dbo].[spUpdateFlagsMkab]
  (@Flags AS INT,
   @mkabid AS int) AS
BEGIN
	IF OBJECT_ID(N'temp_ca_mkab','U') IS NULL
		SELECT @mkabid as mkabid,@Flags as flags
		INTO temp_ca_mkab
	ELSE
		INSERT INTO temp_ca_mkab VALUES (@mkabid,@Flags)
END
go

