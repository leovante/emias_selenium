CREATE FUNCTION [dbo].RMIS_GetPatientId
(
	@s_pol VARCHAR(50)
	,@n_pol VARCHAR(50)
	,@date_bd DATETIME
	,@family VARCHAR(50)
	,@name VARCHAR(50)
	,@ot VARCHAR(50)
) RETURNS TABLE AS
RETURN    
	SELECT UGUID 
		FROM hlt_mkab 
	WHERE  
		n_pol = @n_pol 
	AND S_POL = @s_pol 
		AND DATE_BD = @date_bd
	AND FAMILY = @family
		AND NAME = @name
	AND OT = @ot
go

