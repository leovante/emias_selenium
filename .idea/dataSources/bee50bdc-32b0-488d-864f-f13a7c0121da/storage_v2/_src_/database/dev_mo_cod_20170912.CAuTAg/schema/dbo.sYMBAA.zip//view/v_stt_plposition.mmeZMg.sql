CREATE VIEW [V_stt_PLPosition] AS SELECT 
[hDED].[PLPositionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_ListOfPurposeID] as [rf_ListOfPurposeID], 
[hDED].[rf_PurposeLSID] as [rf_PurposeLSID], 
[jT_stt_PurposeLS].[Name] as [SILENT_rf_PurposeLSID], 
[hDED].[rf_LSOutlayID] as [rf_LSOutlayID], 
[jT_stt_LSOutlay].[Name] as [SILENT_rf_LSOutlayID], 
[hDED].[rf_ProcedurePositionID] as [rf_ProcedurePositionID], 
[hDED].[Date] as [Date], 
[hDED].[PurposeCount] as [PurposeCount], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[IsFullFilled] as [IsFullFilled], 
[hDED].[IsManual] as [IsManual], 
[hDED].[Dose] as [Dose]
FROM [stt_PLPosition] as [hDED]
INNER JOIN [stt_PurposeLS] as [jT_stt_PurposeLS] on [jT_stt_PurposeLS].[PurposeLSID] = [hDED].[rf_PurposeLSID]
INNER JOIN [stt_LSOutlay] as [jT_stt_LSOutlay] on [jT_stt_LSOutlay].[LSOutlayID] = [hDED].[rf_LSOutlayID]
go

