CREATE VIEW [V_ras_Reserve] AS SELECT 
[hDED].[ReserveID], [hDED].[HostReserveID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_DocDescriptionID] as [rf_DocDescriptionID], 
[hDED].[rf_PositionBillExID] as [rf_PositionBillExID], 
[hDED].[rf_PositionBillExIDHost] as [rf_PositionBillExIDHost], 
[hDED].[rf_BillExtractedID] as [rf_BillExtractedID], 
[hDED].[rf_BillExtractedIDHost] as [rf_BillExtractedIDHost], 
[hDED].[rf_PositionOrgOrderID] as [rf_PositionOrgOrderID], 
[hDED].[rf_PositionOrgOrderIDHost] as [rf_PositionOrgOrderIDHost], 
[hDED].[rf_StateReserveID] as [rf_StateReserveID], 
[hDED].[rf_PositionWriteOffArticleID] as [rf_PositionWriteOffArticleID], 
[hDED].[rf_PositionWriteOffArticleIDHost] as [rf_PositionWriteOffArticleIDHost], 
[hDED].[rf_PositionBillReturnPrID] as [rf_PositionBillReturnPrID], 
[hDED].[rf_PositionBillReturnPrIDHost] as [rf_PositionBillReturnPrIDHost], 
[hDED].[Count] as [Count], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[rf_PositionID] as [rf_PositionID], 
[hDED].[rf_PositionIDHost] as [rf_PositionIDHost]
FROM [ras_Reserve] as [hDED]
go

