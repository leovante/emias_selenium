
CREATE PROCEDURE [dbo].[spUpdateResponceCode]
  (@OID AS VARCHAR(100),
   @ResponseCode AS VARCHAR(100)) AS
BEGIN
  UPDATE dbo.hl7_Document SET ResponseCode = @ResponseCode WHERE OID = @OID
END
go

