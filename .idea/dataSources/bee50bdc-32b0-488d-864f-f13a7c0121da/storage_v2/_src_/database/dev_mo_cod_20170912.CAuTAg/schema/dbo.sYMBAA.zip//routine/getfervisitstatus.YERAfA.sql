
CREATE FUNCTION GetFERVisitStatus 
(
	@UGUID uniqueidentifier
)
RETURNS VARCHAR(20)
AS
BEGIN
	RETURN
	(SELECT	
	CASE 
		WHEN VisitStatus = -1 THEN 'PATIENT_NOT_ARRIVED'
		WHEN VisitStatus = 2 OR VisitStatus = 3 OR VisitStatus = 4 THEN 'SUCCESS'
		-- ищем услуги по посещению
		WHEN (SELECT 
				count(distinct dvt.DoctorVisitTableid)
			FROM hlt_DoctorVisitTable dvt with(nolock)
				JOIN hlt_SMTAP smt with(nolock) ON smt.rf_DoctorVisitTableID = dvt.DoctorVisitTableID
			WHERE dvt.UGUID = @UGUID) > 0 THEN 'SUCCESS'
		--ищем услуги по ТАПу и дате посещения		
		WHEN (SELECT 
				count(distinct dvt.DoctorVisitTableid)
			FROM hlt_DoctorVisitTable dvt with(nolock)
				JOIN hlt_doctortimetable dtt with(nolock) on dvt.rf_doctortimetableid = dtt.doctortimetableid
				JOIN hlt_TAP tap with(nolock) ON tap.tapid = dvt.rf_tapid
				JOIN hlt_SMTAP smt with(nolock) ON smt.rf_tapid = tap.tapid AND CONVERT(VARCHAR,smt.Date_P,104) = CONVERT(VARCHAR,dtt.date,104)
			WHERE dvt.UGUID = @UGUID) > 0 THEN 'SUCCESS'	
		--ищем медицинскую запись по дате посещения
		WHEN (SELECT 
				count(distinct dvt.DoctorVisitTableid)
			FROM hlt_DoctorVisitTable dvt with(nolock)
				JOIN hlt_doctortimetable dtt with(nolock) on dvt.rf_doctortimetableid = dtt.doctortimetableid
				JOIN hlt_TAP tap with(nolock) ON tap.tapid = dvt.rf_tapid
				JOIN hlt_VisitHistory vh with(nolock) on vh.rf_TAPID = tap.tapid
			    JOIN hlt_MedRecord mr with(nolock) ON mr.rf_VisitHistoryID = vh.VisitHistoryID AND CONVERT(VARCHAR,mr.Date,104) = CONVERT(VARCHAR,dtt.date,104)
			WHERE dvt.UGUID = @UGUID) > 0 THEN 'SUCCESS'
		--ищем направление по дате посещения
		WHEN (SELECT 
				count(distinct dvt.DoctorVisitTableid)
			FROM hlt_DoctorVisitTable dvt with(nolock)
				JOIN hlt_doctortimetable dtt with(nolock) on dvt.rf_doctortimetableid = dtt.doctortimetableid
				JOIN hlt_TAP tap with(nolock) ON tap.tapid = dvt.rf_tapid
				JOIN hlt_Direction dir with(nolock) ON dir.directionid = tap.rf_directionid AND CONVERT(VARCHAR,dir.Date,104) = CONVERT(VARCHAR,dtt.date,104)
			WHERE dvt.UGUID = @UGUID) > 0 THEN 'SUCCESS'
		--ищем направление на исследование по дате посещения
		WHEN (SELECT 
				count(distinct dvt.DoctorVisitTableid)
			FROM hlt_DoctorVisitTable dvt with(nolock)
				JOIN hlt_doctortimetable dtt with(nolock) on dvt.rf_doctortimetableid = dtt.doctortimetableid
				JOIN hlt_TAP tap with(nolock) ON tap.tapid = dvt.rf_tapid
			    JOIN lbr_LaboratoryResearch lr with(nolock) ON lr.rf_TAPID = tap.tapid AND CONVERT(VARCHAR,lr.Date_Direction,104) = CONVERT(VARCHAR,dtt.date,104)
			WHERE dvt.UGUID = @UGUID) > 0 THEN 'SUCCESS'
		--ищем выписанный региональный рецепт по дате посещения
		WHEN (SELECT 
				count(distinct dvt.DoctorVisitTableid)
			FROM hlt_DoctorVisitTable dvt with(nolock)
				JOIN hlt_doctortimetable dtt with(nolock) on dvt.rf_doctortimetableid = dtt.doctortimetableid
				JOIN hlt_TAP tap with(nolock) ON tap.tapid = dvt.rf_tapid
			    JOIN hlt_PolyclinicRecipeRegionLG regrec with(nolock) ON regrec.rf_TAPID = tap.tapid AND CONVERT(VARCHAR,regrec.DATE_VR,104) = CONVERT(VARCHAR,dtt.date,104)
			WHERE dvt.UGUID = @UGUID) > 0 THEN 'SUCCESS'
		--ищем выписанный федеральный рецепт по дате посещения
		WHEN (SELECT 
				count(distinct dvt.DoctorVisitTableid)
			FROM hlt_DoctorVisitTable dvt with(nolock)
				JOIN hlt_doctortimetable dtt with(nolock) on dvt.rf_doctortimetableid = dtt.doctortimetableid
				JOIN hlt_TAP tap with(nolock) ON tap.tapid = dvt.rf_tapid
			    JOIN hlt_PolyclinicRecipeFederalLG fedrec with(nolock) ON fedrec.rf_TAPID = tap.tapid AND CONVERT(VARCHAR,fedrec.DATE_VR,104) = CONVERT(VARCHAR,dtt.date,104)
			WHERE dvt.UGUID = @UGUID) > 0 THEN 'SUCCESS'
		ELSE 'PATIENT_NOT_ARRIVED'
	END
FROM hlt_DoctorVisitTable
WHERE UGUID = @UGUID)
END
go

