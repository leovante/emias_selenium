CREATE VIEW [V_ras_PositionOrder] AS SELECT 
[hDED].[PositionOrderID], [hDED].[HostPositionOrderID], [hDED].[x_Edition], [hDED].[x_Status], 
Realisation*PrNZ/1000 as [V_NZ], 
[hDED].[rf_CLSID] as [rf_CLSID], 
[jT_oms_CLS].[C_PFS] as [SILENT_rf_CLSID], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[jT_ras_Nomenclature].[Name] as [SILENT_rf_NomenclatureID], 
[hDED].[rf_TypeDemandID] as [rf_TypeDemandID], 
[jT_ras_TypeDemand].[Name] as [SILENT_rf_TypeDemandID], 
[hDED].[rf_LSFOID] as [rf_LSFOID], 
[hDED].[rf_LSFOIDHost] as [rf_LSFOIDHost], 
[jT_ras_LSFO].[C_LSProvider] as [SILENT_rf_LSFOID], 
[hDED].[rf_OrderID] as [rf_OrderID], 
[hDED].[rf_OrderIDHost] as [rf_OrderIDHost], 
[jT_ras_Order].[Num] as [SILENT_rf_OrderID], 
[hDED].[rf_StatePositionOrderID] as [rf_StatePositionOrderID], 
[jT_ras_StatePositionOrder].[Name] as [SILENT_rf_StatePositionOrderID], 
[hDED].[Count] as [Count], 
[hDED].[AgreeCount] as [AgreeCount], 
[hDED].[Realisation] as [Realisation], 
[hDED].[Rest] as [Rest], 
[hDED].[PrNZ] as [PrNZ]
FROM [ras_PositionOrder] as [hDED]
INNER JOIN [oms_CLS] as [jT_oms_CLS] on [jT_oms_CLS].[CLSID] = [hDED].[rf_CLSID]
INNER JOIN [ras_Nomenclature] as [jT_ras_Nomenclature] on [jT_ras_Nomenclature].[NomenclatureID] = [hDED].[rf_NomenclatureID] AND  [jT_ras_Nomenclature].[HostNomenclatureID] = [hDED].[rf_NomenclatureIDHost]
INNER JOIN [ras_TypeDemand] as [jT_ras_TypeDemand] on [jT_ras_TypeDemand].[TypeDemandID] = [hDED].[rf_TypeDemandID]
INNER JOIN [ras_LSFO] as [jT_ras_LSFO] on [jT_ras_LSFO].[LSFOID] = [hDED].[rf_LSFOID] AND  [jT_ras_LSFO].[HostLSFOID] = [hDED].[rf_LSFOIDHost]
INNER JOIN [ras_Order] as [jT_ras_Order] on [jT_ras_Order].[OrderID] = [hDED].[rf_OrderID] AND  [jT_ras_Order].[HostOrderID] = [hDED].[rf_OrderIDHost]
INNER JOIN [ras_StatePositionOrder] as [jT_ras_StatePositionOrder] on [jT_ras_StatePositionOrder].[StatePositionOrderID] = [hDED].[rf_StatePositionOrderID]
go

