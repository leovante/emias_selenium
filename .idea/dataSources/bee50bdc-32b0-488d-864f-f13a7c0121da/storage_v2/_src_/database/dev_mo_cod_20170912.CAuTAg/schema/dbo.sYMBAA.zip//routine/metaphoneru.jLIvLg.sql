CREATE FUNCTION dbo.MetaPhoneRu
(@W VARCHAR(4000)
)
RETURNS VARCHAR(4000)
AS
     BEGIN
         DECLARE @alf VARCHAR(4000), @cns1 VARCHAR(4000), @cns2 VARCHAR(4000), @cns3 VARCHAR(4000), @ch VARCHAR(4000), @ct VARCHAR(4000);
         SET @alf = 'ОЕАИУЭЮЯПСТРКЛМНБВГДЖЗЙФХЦЧШЩЁЫ';
         SET @cns1 = 'БЗДВГ';
         SET @cns2 = 'ПСТФК';
         SET @cns3 = 'ПСТКБВГДЖЗФХЦЧШЩ';
         SET @ch = 'ОЮЕЭЯЁЫ';
         SET @ct = 'АУИИАИА'; -- @alf - алфавит кроме исключаемых букв, -- @cns1 и @cns2 - звонкие и глухие согласные, -- @cns3 - согласные, перед которыми звонкие оглушаются, -- @ch, @ct - образец и замена гласных 
         DECLARE @S VARCHAR(4000), @V VARCHAR(4000), @i INT, @B INT, @c CHAR(1), @old_c CHAR(1); 
         -- @S, @V - промежуточные строки, @i-счётчик цикла, -- @B - позиция найденного элемента, @c - текущий символ 
         SET @W = UPPER(@W);
         SET @S = '';
         SET @V = '';
         SET @i = 1;
         WHILE @i <= LEN(@W)
             BEGIN
                 SET @c = SUBSTRING(@W, @i, 1);
                 IF CHARINDEX(@c, @alf) > 0
                     SET @S = @S + @c;
                 SET @i = @i + 1;
             END;
         IF LEN(@S) = 0
             RETURN ''; 
         -- Заменяем окончания 
         IF LEN(@S) > 6
             SET @S = LEFT(@S, LEN(@S) - 6)+CASE RIGHT(@S, 6)
                                                WHEN 'ОВСКИЙ'
                                                THEN '@'
                                                WHEN 'ЕВСКИЙ'
                                                THEN '#'
                                                WHEN 'ОВСКАЯ'
                                                THEN '$'
                                                WHEN 'ЕВСКАЯ'
                                                THEN '%'
                                                ELSE RIGHT(@S, 6)
                                            END;
         IF LEN(@S) > 4
             SET @S = LEFT(@S, LEN(@S) - 4)+CASE RIGHT(@S, 4)
                                                WHEN 'ИЕВА'
                                                THEN '9'
                                                WHEN 'ЕЕВА'
                                                THEN '9'
                                                ELSE RIGHT(@S, 4)
                                            END;
         IF LEN(@S) > 3
             SET @S = LEFT(@S, LEN(@S) - 3)+CASE RIGHT(@S, 3)
                                                WHEN 'ОВА'
                                                THEN '9'
                                                WHEN 'ЕВА'
                                                THEN '9'
                                                WHEN 'ИНА'
                                                THEN '1'
                                                WHEN 'ИЕВ'
                                                THEN '4'
                                                WHEN 'ЕЕВ'
                                                THEN '4'
                                                WHEN 'НКО'
                                                THEN '3'
                                                ELSE RIGHT(@S, 3)
                                            END;
         IF LEN(@S) > 2
             SET @S = LEFT(@S, LEN(@S) - 2)+CASE RIGHT(@S, 2)
                                                WHEN 'ОВ'
                                                THEN '4'
                                                WHEN 'ЕВ'
                                                THEN '4'
                                                WHEN 'АЯ'
                                                THEN '6'
                                                WHEN 'ИЙ'
                                                THEN '7'
                                                WHEN 'ЫЙ'
                                                THEN '7'
                                                WHEN 'ЫХ'
                                                THEN '5'
                                                WHEN 'ИХ'
                                                THEN '5'
                                                WHEN 'ИН'
                                                THEN '8'
                                                WHEN 'ИК'
                                                THEN '2'
                                                WHEN 'ЕК'
                                                THEN '2'
                                                WHEN 'УК'
                                                THEN '0'
                                                WHEN 'ЮК'
                                                THEN '0'
                                                ELSE RIGHT(@S, 2)
                                            END; 
         -- Оглушаем последний символ, если он - звонкий согласный: 
         SET @B = CHARINDEX(RIGHT(@S, 1), @cns1);
         IF @B > 0
             SET @S = LEFT(@S, LEN(@S) - 1) + SUBSTRING(@cns2, @B, 1);
         SET @old_c = ' ';
         SET @i = 1;
         WHILE @i <= LEN(@S)
             BEGIN
                 SET @c = SUBSTRING(@S, @i, 1);
                 SET @B = CHARINDEX(@c, @ch);
                 IF @B > 0
                     BEGIN
                         IF @old_c = 'Й'
                            OR @old_c = 'И'
                             BEGIN
                                 IF @c = 'О'
                                    OR @c = 'Е'
                                     BEGIN
                                         SET @old_c = 'И';
                                         SET @S = LEFT(@S, LEN(@S) - 1) + @old_c;
                                     END;
                                 ELSE
                                 IF @c <> @old_c
                                     SET @V = @V + SUBSTRING(@ct, @B, 1);
                             END;
                         ELSE
                             BEGIN
                                 IF @c <> @old_c
                                     SET @V = @V + SUBSTRING(@ct, @B, 1);
                             END;
                     END;
                 ELSE
                     BEGIN
                         IF @c <> @old_c
                            AND CHARINDEX(@c, @cns3) > 0
                             BEGIN
                                 SET @B = CHARINDEX(@old_c, @cns1);
                                 IF @B > 0
                                     BEGIN
                                         SET @old_c = SUBSTRING(@cns2, @B, 1);
                                         SET @V = LEFT(@V, LEN(@V) - 1) + @old_c;
                                     END;
                             END;
                         IF @c <> @old_c
                             SET @V = @V + @c;
                     END;
                 SET @old_c = @c;
                 SET @i = @i + 1;
             END;
         RETURN(@V);
     END;
go

