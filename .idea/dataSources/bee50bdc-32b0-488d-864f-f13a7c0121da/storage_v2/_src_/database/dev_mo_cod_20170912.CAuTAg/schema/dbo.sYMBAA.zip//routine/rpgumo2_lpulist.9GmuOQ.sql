-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[RPGUMO2_LPUList] ()
RETURNS 
@tb TABLE 
(	
	LpuInfo varchar(8000)	
)
AS
BEGIN

if exists(select * from sys.tables where name ='rpt_LPUList_LpuInfo')
begin
INSERT INTO @tb(LPUInfo)
SELECT LPUInfo from rpt_LPUList_LpuInfo
end
else
begin

DECLARE @tmptable TABLE (
	LPUID INT
	,MainLPUID INT
	,mcod VARCHAR(50)
	,okato VARCHAR(50)
	,NAME VARCHAR(5000)
	,address VARCHAR(5000)
	,email varchar(5000)
	,town VARCHAR(5000)
	,wsdl VARCHAR(5000)
	,phone VARCHAR(5000)
	,coords VARCHAR(5000)
	,site VARCHAR(5000)
	,active VARCHAR(5000)
	,isOtherLpuRec INT
	,isWaitingList INT
	,isChild INT
	,isCallDocHome INT
	)


INSERT INTO @tmptable
SELECT
		LPUID,
		rf_MainLPUID,
		ltrim(rtrim(mcod)),
		ltrim(rtrim(c_okato)),
		case when [2dr_name] is null or ltrim(rtrim([2dr_name])) = '' then ltrim(rtrim(m_names)) else ltrim(rtrim([2dr_name])) end,
		case when [2dr_adres] is null or ltrim(rtrim([2dr_adres])) = '' then ltrim(rtrim(adres)) else ltrim(rtrim([2dr_adres])) end,
		ltrim(rtrim(E_MAIL)),
		isnull(substring(isnull([2dr_town], ''), 9, 20),''),
		isnull(Lower([2dr_wsdl]), ''),
		case when [2dr_phone] is null or ltrim(rtrim([2dr_phone])) = '' then ltrim(rtrim(TEL)) else ltrim(rtrim([2dr_phone])) end,
		isnull([2dr_gps], ''),
		isnull([2dr_www], ''),
		isnull([2dr_active], 0),
		isnull([2dr_other], 0),
		isnull([2dr_w_list], 0),
		isnull([2dr_child], 0),
		isnull([2dr_caldoc], 0)
FROM (
	SELECT LPUID
		,rf_MainLPUID
		,mcod
		,m_names
		,adres
		,E_MAIL
		,TEL
		,okato.C_OKATO
		,val.value
		,atr.Code
	FROM [cod_NSI].dbo.oms_LPU lpu  WITH (NOLOCK) 
	INNER JOIN [cod_NSI].dbo.Oms_OKATO okato  WITH (NOLOCK) ON lpu.rf_OKATOID = okato.OKATOID
	INNER JOIN [cod_NSI].dbo.oms_TehAtrValue val  WITH (NOLOCK) ON lpu.lpuid = val.rf_LPUID
	INNER JOIN [cod_NSI].dbo.oms_TehAtr atr  WITH (NOLOCK) ON val.rf_TehAtrid = atr.TehAtrid
	INNER JOIN [cod_NSI].dbo.oms_Project prj  WITH (NOLOCK) ON atr.rf_ProjectID = prj.ProjectID
	WHERE prj.NAME = 'Сайт самозаписи' and lpu.DATE_E > getdate()
	) AS SourceTable
PIVOT(max(Value) FOR Code IN (
			[2dr_name]
			,[2dr_other]
			,[2dr_town]
			,[2dr_wsdl]
			,[2dr_phone]
			,[2dr_active]
			,[2dr_gps]
			,[2dr_www]
			,[2dr_w_list]
			,[2dr_child]
			,[2dr_caldoc]
			,[2dr_adres]
			)) AS PivotTable

UPDATE l
SET okato = m.okato
	,town = m.town
FROM @tmptable l
INNER JOIN @tmptable m ON m.LPUID = l.MainLPUID
WHERE l.MainLPUID > 0

UPDATE l
SET wsdl = m.wsdl
FROM @tmptable l
INNER JOIN @tmptable m ON m.LPUID = l.MainLPUID
WHERE l.MainLPUID > 0
	AND (
		l.wsdl IS NULL
		OR l.wsdl = ''
		)

UPDATE l
SET site = m.site
FROM @tmptable l
INNER JOIN @tmptable m ON m.LPUID = l.MainLPUID
WHERE l.MainLPUID > 0
	AND (
		l.site IS NULL
		OR l.site = ''
		)

UPDATE l
SET email = m.email
FROM @tmptable l
INNER JOIN @tmptable m ON m.LPUID = l.MainLPUID
WHERE l.MainLPUID > 0
	AND (
		l.email IS NULL
		OR l.email = ''
		)


INSERT INTO @tb(LPUInfo)
SELECT '{' + 
		'"ID":"'		+ cast(lpuid as varchar(10)) + '",' + 
		'"LPUCODE":"'	+ dbo.json_escape(mcod) + '",' + 
		'"EMAIL":"'		+ dbo.json_escape(email) + '",' + 
		'"SITEURL":"'	+ dbo.json_escape(site) + '",' +
		'"NAME":"'		+ dbo.json_escape(name) + '",' +
		'"IP":"'		+ dbo.json_escape(wsdl) + '",' +
		'"ADDRESS":"'	+ dbo.json_escape(address) + '",' +
		'"PHONE":"'		+ dbo.json_escape(phone) + '",' +
		'"ACCESSIBILITY":"'		+  cast(Active as varchar(10)) + '",' +
		'"CHILDREN":"'	+ case isChild	when '1' then '1'  else '0' end+ '",' + 
		'"CITY":"'		+ dbo.json_escape(town) + '",' +

		'"C_OKATO":"'		+ dbo.json_escape(okato) + '",' +			
		'"COORDS":"'	+ dbo.json_escape(coords) + '",' +		
		'"isOtherLpuRec":"' + case isOtherLpuRec	when '1' then '1'  else '0' end+ '",' + 
		'"isWaitingList":"' + case isWaitingList	when '1' then '1'  else '0' end+ '",' + 		
		'"isCallDocHome":"' + case isCallDocHome	when '1' then '1'  else '0' end +'"' + 
		+ '}' as LpuInfo 
FROM @tmptable
where active = 1

end


	RETURN 
END
go

