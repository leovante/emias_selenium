CREATE VIEW [V_oms_SMReestrONK_USL] AS SELECT 
[hDED].[SMReestrONK_USLID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[rf_SMreestrUslID] as [rf_SMreestrUslID], 
[hDED].[PR_CONS] as [PR_CONS], 
[hDED].[USL_TIP] as [USL_TIP], 
[hDED].[HIR_TIP] as [HIR_TIP], 
[hDED].[LEK_TIP_L] as [LEK_TIP_L], 
[hDED].[LEK_TIP_V] as [LEK_TIP_V], 
[hDED].[LUCH_TIP] as [LUCH_TIP]
FROM [oms_SMReestrONK_USL] as [hDED]
go

