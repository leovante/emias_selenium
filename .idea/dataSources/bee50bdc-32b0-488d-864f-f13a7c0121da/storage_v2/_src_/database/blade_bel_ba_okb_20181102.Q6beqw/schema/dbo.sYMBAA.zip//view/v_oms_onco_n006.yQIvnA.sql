CREATE VIEW [V_oms_onco_N006] AS SELECT 
[hDED].[onco_N006ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_onco_N002ID] as [rf_onco_N002ID], 
[jT_oms_onco_N002].[KOD_St] as [SILENT_rf_onco_N002ID], 
[hDED].[rf_onco_N003ID] as [rf_onco_N003ID], 
[jT_oms_onco_N003].[T_NAME] as [SILENT_rf_onco_N003ID], 
[hDED].[rf_onco_N004ID] as [rf_onco_N004ID], 
[jT_oms_onco_N004].[N_NAME] as [SILENT_rf_onco_N004ID], 
[hDED].[rf_onco_N005ID] as [rf_onco_N005ID], 
[jT_oms_onco_N005].[M_NAME] as [SILENT_rf_onco_N005ID], 
[hDED].[ID_gr] as [ID_gr], 
[hDED].[DS_gr] as [DS_gr], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN006] as [GUIDN006]
FROM [oms_onco_N006] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_onco_N002] as [jT_oms_onco_N002] on [jT_oms_onco_N002].[onco_N002ID] = [hDED].[rf_onco_N002ID]
INNER JOIN [oms_onco_N003] as [jT_oms_onco_N003] on [jT_oms_onco_N003].[onco_N003ID] = [hDED].[rf_onco_N003ID]
INNER JOIN [oms_onco_N004] as [jT_oms_onco_N004] on [jT_oms_onco_N004].[onco_N004ID] = [hDED].[rf_onco_N004ID]
INNER JOIN [oms_onco_N005] as [jT_oms_onco_N005] on [jT_oms_onco_N005].[onco_N005ID] = [hDED].[rf_onco_N005ID]
go

