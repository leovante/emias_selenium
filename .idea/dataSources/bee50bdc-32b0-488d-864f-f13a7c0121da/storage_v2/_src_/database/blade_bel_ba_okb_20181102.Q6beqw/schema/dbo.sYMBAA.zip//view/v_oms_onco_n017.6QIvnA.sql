CREATE VIEW [V_oms_onco_N017] AS SELECT 
[hDED].[onco_N017ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ID_TLuch] as [ID_TLuch], 
[hDED].[TLuch_NAME] as [TLuch_NAME], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN017] as [GUIDN017]
FROM [oms_onco_N017] as [hDED]
go

