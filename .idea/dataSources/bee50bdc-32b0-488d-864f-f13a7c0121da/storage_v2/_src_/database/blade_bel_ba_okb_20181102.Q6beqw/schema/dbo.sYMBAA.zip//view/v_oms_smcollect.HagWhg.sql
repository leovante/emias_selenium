CREATE VIEW [V_oms_SMCollect] AS SELECT 
[hDED].[SMCollectID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[SMCollectName] as [SMCollectName], 
[hDED].[SMCollectCode] as [SMCollectCode], 
[hDED].[SMCollectRem] as [SMCollectRem]
FROM [oms_SMCollect] as [hDED]
go

