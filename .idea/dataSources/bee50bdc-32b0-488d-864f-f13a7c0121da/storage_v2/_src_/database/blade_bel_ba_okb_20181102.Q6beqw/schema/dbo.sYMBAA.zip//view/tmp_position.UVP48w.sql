CREATE view [tmp_POSITION] as select    isnull(p.rf_BillExtractedID,0) as beid,
          --Номенклатурный Код ЛС 
          isnull(ls.NOMK_LS,0) as NOMK_LS, --????
          --Количество
          isnull(p.Count,0) as  COUNT,
          --Номер серии
          ltrim(rtrim(p.V_Series))  as SERIES , 
          --Срок годности 
          sls.ExpDate as LIFE_DATE,     
          --партия   
          isnull(p.V_Consigment,0) as  PARTIA,
          --Цена
          isnull(p.Price,0) as PRICE,
          --Цена без НДС
          isnull(p.PriceBase,0) as PRICE_BASE,
          --Цена оптовая
          isnull(p.PriceOPT,0) as PRICE_OPT,
          --Сумма позиций накладной
          isnull(p.Summa,0) as SUM_BASE,
          --Ставка НДС
          isnull(convert(int,nds.Rate_Num),0) as NDS_PR,
          --Сумма НДС по позиции накладной 
          isnull(p.SumNDS,0)as NDS_SUM,
          --Сумма по позиции накладной с налогами
          isnull(p.Summa+p.SumNDS,0) as SUM_OPL,
          --предельная цена ЛС
          0 as PRICE_REES,
          --Наименование ЛС
          isnull(p.v_nomenclature,'') as PRODUCT,
          --Наименование производителя
          isnull(sls.V_Producer,'') as PRODUCER,
          --Номер сертификата
          sls.sertMSG as SERT_NUM,
          --ШК EAN13
          isnull(sls.EAN13,'') as EAN13,
          --Номер грузовой таможенной декларации
          isnull(sls.GTD,'') as GTD,
          --Код ЛС в кодировке учетной системы поставщика
          isnull(lsfo.C_LSProvider,0) as C_LSFO,
          --ШК склада
          isnull(sls.SH_Code,'') as SH_CODE,
          --Код цены по контракту 
          isnull(cls.C_PFS,0) as C_PFS,
          --Номер контракта
          isnull(ten.NUM,0) as TENDER_NUM,
          --Дата контракта
          ten.Date as TENDER_DATE, 
					--наименование программы финансирования
		  		typ.TenderType_Name as TenderType_Name, 
		  		--гуид программы финансирвоания
		  		typ.GUIDTYPE as TenderType_GUID,
          --ОГРН владельца
           isnull(org.OGRN,0) as OGRNOWNER,
           --Ко владельца
           isnull(org.CODE,0) as CODEOWNER,
					 isnull(orgDemand.OGRN, '') as OGRN_DEMAND,
					 isnull(orgDemand.CODE, '') as CODE_DEMAND
from  V_ras_PositionBillEx p

left join V_ras_StoredLS sls on sls.StoredLSID=p.rf_StoredLSID 
     and sls.HostStoredLSID=p.rf_StoredLSIDHost
left join ras_Nomenclature nn on nn.NomenclatureID=sls.rf_NomenclatureID 
     and nn.HostNomenclatureID=sls.rf_NomenclatureIDHost
left join ras_LSFO lsfo on lsfo.LSFOID = sls.rf_LSFOID      and sls.rf_LSFOIDHost=lsfo.HostLSFOID	
left join oms_CLS cls ON lsfo.rf_CLSID=cls.CLSID 
inner join oms_LS ls ON cls.rf_LSID = ls.LSID
left join ras_NDS nds ON p.rf_NDSID=nds.NDSID	  

left join oms_Tender  ten on ten.TenderID= sls.rf_TenderID
inner join oms_TenderType typ on sls.rf_TenderTypeID = typ.TenderTypeID
left join ras_organisation org on org.OrganisationID=sls.rf_OrganisationOwnerID
left join ras_organisation orgDemand on orgDemand.OrganisationID=p.rf_OrganisationByDemandID
	and orgDemand.HostOrganisationID=p.rf_OrganisationByDemandIDHost

where p.rf_BillExtractedID=6089 
and p.rf_BillExtractedIDHost = 999
and rf_StateExPosBillID in(15,25)
go

