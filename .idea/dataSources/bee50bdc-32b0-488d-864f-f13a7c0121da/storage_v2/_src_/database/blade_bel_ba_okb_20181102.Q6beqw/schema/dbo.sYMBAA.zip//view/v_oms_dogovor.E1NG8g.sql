CREATE VIEW [V_oms_DOGOVOR] AS SELECT 
[hDED].[DOGOVORID], [hDED].[x_Edition], [hDED].[x_Status], 
(('№ '+Num +' '+[jT_oms_LPU].M_Names+' / '+[jT_oms_SMO].Q_Name)) as [V_Info], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[hDED].[rf_TYPEDOGID] as [rf_TYPEDOGID], 
[jT_oms_TYPEDOG].[NAME] as [SILENT_rf_TYPEDOGID], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[jT_oms_Organisation].[ShortName] as [SILENT_rf_OrganisationID], 
[hDED].[rf_TenderKindID] as [rf_TenderKindID], 
[jT_oms_TenderKind].[TKind_Name] as [SILENT_rf_TenderKindID], 
[hDED].[rf_kl_MedCareTypeID] as [rf_kl_MedCareTypeID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E], 
[hDED].[Num] as [Num], 
[hDED].[DogGuid] as [DogGuid], 
[hDED].[Rem] as [Rem], 
[hDED].[State] as [State], 
[hDED].[DateSign] as [DateSign], 
[hDED].[Flags] as [Flags], 
[hDED].[Name] as [Name]
FROM [oms_DOGOVOR] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_TYPEDOG] as [jT_oms_TYPEDOG] on [jT_oms_TYPEDOG].[TYPEDOGID] = [hDED].[rf_TYPEDOGID]
INNER JOIN [oms_Organisation] as [jT_oms_Organisation] on [jT_oms_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID]
INNER JOIN [oms_TenderKind] as [jT_oms_TenderKind] on [jT_oms_TenderKind].[TenderKindID] = [hDED].[rf_TenderKindID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
go

