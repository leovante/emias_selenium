CREATE VIEW [V_oms_Project] AS SELECT 
[hDED].[ProjectID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Rem] as [Rem], 
[hDED].[GuidProject] as [GuidProject]
FROM [oms_Project] as [hDED]
go

