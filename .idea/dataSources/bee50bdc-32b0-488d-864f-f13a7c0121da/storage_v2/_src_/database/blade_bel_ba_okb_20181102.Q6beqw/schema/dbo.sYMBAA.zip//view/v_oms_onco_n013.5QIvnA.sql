CREATE VIEW [V_oms_onco_N013] AS SELECT 
[hDED].[onco_N013ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ID_TLech] as [ID_TLech], 
[hDED].[TLech_NAME] as [TLech_NAME], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN013] as [GUIDN013]
FROM [oms_onco_N013] as [hDED]
go

