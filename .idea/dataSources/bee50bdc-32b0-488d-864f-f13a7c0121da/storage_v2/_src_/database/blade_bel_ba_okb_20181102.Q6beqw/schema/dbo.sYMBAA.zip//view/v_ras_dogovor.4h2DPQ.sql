CREATE VIEW [V_ras_Dogovor] AS SELECT 
[hDED].[DogovorID], [hDED].[HostDogovorID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_ras_Currency].[C_Name] as [V_Currency], 
[hDED].[rf_DogovorOsnID] as [rf_DogovorOsnID], 
[hDED].[rf_DogovorOsnIDHost] as [rf_DogovorOsnIDHost], 
[hDED].[rf_CurrencyID] as [rf_CurrencyID], 
[hDED].[D_Name] as [D_Name], 
[hDED].[PR_Commis] as [PR_Commis], 
[hDED].[IsYE] as [IsYE], 
[hDED].[Date] as [Date], 
[hDED].[DateEx] as [DateEx], 
[hDED].[Summa] as [Summa], 
[hDED].[Note] as [Note]
FROM [ras_Dogovor] as [hDED]
INNER JOIN [ras_Currency] as [jT_ras_Currency] on [jT_ras_Currency].[CurrencyID] = [hDED].[rf_CurrencyID]
go

