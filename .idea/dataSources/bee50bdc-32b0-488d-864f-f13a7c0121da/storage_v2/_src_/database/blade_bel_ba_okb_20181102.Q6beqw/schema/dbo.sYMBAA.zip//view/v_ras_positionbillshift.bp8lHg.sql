CREATE VIEW [V_ras_PositionBillShift] AS SELECT 
[hDED].[PositionBillShiftID], [hDED].[HostPositionBillShiftID], [hDED].[x_Edition], [hDED].[x_Status], 
((ISNULL((SELECT top 1  TenderType_Name 
FROM oms_TenderType 
join ras_StoredLS on rf_TenderTypeID = TenderTypeID and hDed.rf_StoredLSID = ras_StoredLS.StoredLSID 
			  and hDed.rf_StoredLSIDHost = ras_StoredLS.HostStoredLSID),''))) as [V_TenderTypeName], 
((isnull((Select top 1 cod_ras from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId), '') )) as [V_COD], 
((isnull((Select top 1 Date_E from ras_Series where SeriesID = [jT_ras_StoredLS].rf_SeriesID), '1900-01-01') )) as [V_ExpDate], 
((isnull((Select top 1 NUM from oms_tender where tenderID = [jT_ras_StoredLS].rf_tenderID), '') )) as [V_TenderNum], 
((isnull((Select top 1 name from ras_organisation where OrganisationID = [jT_ras_StoredLS].rf_organisationOwnerID), '') )) as [V_Owner], 
((isnull((Select top 1 Name from ras_producer where ProducerID = (Select top 1 producerID from ras_nomenclature where nomenclatureID = [jT_ras_StoredLS].rf_NomenclatureId)), '') )) as [V_Producer], 
((isnull((Select top 1 Name from ras_nomenclature where NomenclatureId = [jT_ras_StoredLS].rf_NomenclatureId), '') )) as [V_Nomenclature], 
((isnull((Select top 1 NUM from ras_Series where SeriesID = [jT_ras_StoredLS].rf_SeriesID), '') )) as [V_Series], 
[jT_ras_StoredLS].[Consigment] as [V_Consigment], 
[hDED].[rf_OrganisationByDemandID] as [rf_OrganisationByDemandID], 
[hDED].[rf_OrganisationByDemandIDHost] as [rf_OrganisationByDemandIDHost], 
[hDED].[rf_NDSID] as [rf_NDSID], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_BillShiftID] as [rf_BillShiftID], 
[hDED].[rf_BillShiftIDHost] as [rf_BillShiftIDHost], 
[hDED].[rf_StatePosBillIShiftID] as [rf_StatePosBillIShiftID], 
[hDED].[rf_PositionStatusID] as [rf_PositionStatusID], 
[hDED].[rf_PositionBillRequestID] as [rf_PositionBillRequestID], 
[hDED].[Price] as [Price], 
[hDED].[Count] as [Count], 
[hDED].[Summa] as [Summa], 
[hDED].[PriceBase] as [PriceBase], 
[hDED].[SumNDS] as [SumNDS], 
[hDED].[PriceOPT] as [PriceOPT], 
[hDED].[Note] as [Note], 
[hDED].[FractionCount] as [FractionCount], 
[hDED].[CountGivenDetail] as [CountGivenDetail], 
[hDED].[CountGivenMeasure] as [CountGivenMeasure]
FROM [ras_PositionBillShift] as [hDED]
INNER JOIN [ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
go

