CREATE VIEW [V_oms_onco_N010] AS SELECT 
[hDED].[onco_N010ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ID_Igh] as [ID_Igh], 
[hDED].[KOD_Igh] as [KOD_Igh], 
[hDED].[Igh_NAME] as [Igh_NAME], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN010] as [GUIDN010]
FROM [oms_onco_N010] as [hDED]
go

