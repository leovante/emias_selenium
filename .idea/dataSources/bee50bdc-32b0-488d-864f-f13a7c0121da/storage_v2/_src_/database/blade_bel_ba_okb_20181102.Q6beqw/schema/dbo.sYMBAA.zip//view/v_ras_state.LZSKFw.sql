CREATE VIEW [V_ras_State] AS SELECT 
[hDED].[StateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note], 
[hDED].[Guid] as [Guid]
FROM [ras_State] as [hDED]
go

