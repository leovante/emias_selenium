CREATE VIEW [V_oms_CLS] AS SELECT 
[hDED].[CLSID], [hDED].[x_Edition], [hDED].[x_Status], 
IsNull((select sum(oms_StoredLS.[Count])  from oms_StoredLS  where oms_StoredLS.rf_CLSID=hDED.CLSID),0) as [Remains], 
((   ((( Cast ((hDED.PR_REG*hDED.Count_All) as decimal(18,2))))))) as [V_Summa], 
((((isnull((select top 1 'Да '  from life_oms_cls 
	where x_datetime<(select max(date_Create)  
						from oms_reestr_sprav) 
	and life_oms_cls.clsid = hded.Clsid
	), 'Нет'))))) as [V_IsNotEdit], 
[jT_oms_LS].[V_C_MNN] as [V_C_MNN], 
[jT_oms_LS].[V_C_TRN] as [VV_C_TRN], 
[jT_oms_Tender].[Num] as [V_Num], 
[jT_oms_LS].[rf_MNNameID] as [V_rf_MNNameID], 
[jT_oms_NDSRate].[NDS_Code] as [V_NDS_Code], 
[jT_oms_NDSRate].[NDS_Name] as [V_NDS_Name], 
[jT_oms_LS].[NOMK_LS] as [V_NOMK_LS], 
[jT_oms_LS].[NAME_MED] as [V_NAME_MED], 
[hDED].[rf_LSID] as [rf_LSID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[jT_oms_Tender].[Num] as [SILENT_rf_TenderID], 
[hDED].[rf_ProtokolPosID] as [rf_ProtokolPosID], 
[jT_oms_ProtokolPos].[rf_LSID] as [SILENT_rf_ProtokolPosID], 
[hDED].[rf_ClassUnitID] as [rf_ClassUnitID], 
[jT_oms_ClassUnit].[Name] as [SILENT_rf_ClassUnitID], 
[hDED].[rf_NDSRateID] as [rf_NDSRateID], 
[hDED].[C_PFS] as [C_PFS], 
[hDED].[PR_REG] as [PR_REG], 
[hDED].[DATE_BP] as [DATE_BP], 
[hDED].[DATE_EP] as [DATE_EP], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[Doz_Me] as [Doz_Me], 
[hDED].[Count_All] as [Count_All], 
[hDED].[CountDelivery] as [CountDelivery], 
[hDED].[GUIDCLS] as [GUIDCLS], 
[hDED].[isCOD] as [isCOD], 
[hDED].[LotPositionGuid] as [LotPositionGuid], 
[hDED].[SumDelivery] as [SumDelivery], 
[hDED].[Count_EI] as [Count_EI], 
[hDED].[Price_EI] as [Price_EI], 
[hDED].[Koeff] as [Koeff], 
[hDED].[Sum] as [Sum]
FROM [oms_CLS] as [hDED]
INNER JOIN [V_oms_LS] as [jT_oms_LS] on [jT_oms_LS].[LSID] = [hDED].[rf_LSID]
INNER JOIN [oms_Tender] as [jT_oms_Tender] on [jT_oms_Tender].[TenderID] = [hDED].[rf_TenderID]
INNER JOIN [oms_NDSRate] as [jT_oms_NDSRate] on [jT_oms_NDSRate].[NDSRateID] = [hDED].[rf_NDSRateID]
INNER JOIN [oms_ProtokolPos] as [jT_oms_ProtokolPos] on [jT_oms_ProtokolPos].[ProtokolPosID] = [hDED].[rf_ProtokolPosID]
INNER JOIN [oms_ClassUnit] as [jT_oms_ClassUnit] on [jT_oms_ClassUnit].[ClassUnitID] = [hDED].[rf_ClassUnitID]
go

