CREATE VIEW [V_oms_MKB] AS SELECT 
[hDED].[MKBID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[DS] as [DS], 
[hDED].[Date_B] as [Date_B], 
[hDED].[NAME] as [NAME], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Flags] as [Flags], 
[hDED].[Rem] as [Rem]
FROM [oms_MKB] as [hDED]
go

