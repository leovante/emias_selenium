CREATE view [tmp_TENDER] as select    
	ten.TenderID,
	typ.GUIDTYPE, 
	ten.Num,
	ten.Rem,
	ten.Date_BP,
	ten.Date_EP,
	sfo.CFO,
	ten.GUID,
	ten.rf_FinlID,
	ten.Date,
	ten.ExpirePenalty, 
	ten.BreachPenalty, 
	ten.RejectPenalty, 
	ten.Penalty, 
	ten.Fine,
	ten.SumDelivery,
	ten.rf_StateTenderID,
	spec.GUIDSpec,
	ten.Author
from  V_ras_PositionBillEx p

left join V_ras_StoredLS sls on sls.StoredLSID=p.rf_StoredLSID 
     and sls.HostStoredLSID=p.rf_StoredLSIDHost
left join ras_LSFO lsfo on lsfo.LSFOID = sls.rf_LSFOID      
	and sls.rf_LSFOIDHost=lsfo.HostLSFOID	
left join oms_CLS cls ON lsfo.rf_CLSID=cls.CLSID and cls.isCOD = 0
inner join oms_LS ls ON cls.rf_LSID = ls.LSID

left join oms_Tender  ten on ten.TenderID= cls.rf_TenderID
inner join oms_TenderType typ on ten.rf_TenderTypeID = typ.TenderTypeID
inner join oms_SFO sfo on ten.rf_SFOID = sfo.SFOID
inner join oms_Spec spec on spec.SpecID = ten.rf_SpecID

where p.rf_BillExtractedID=6089 
and p.rf_BillExtractedIDHost = 999 and
 rf_StateExPosBillID in(15,25)
go

