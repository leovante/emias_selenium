
create FUNCTION dbo.ras_ConvertToGR(@LSID int, @countLS decimal) 
RETURNS DECIMAL(18, 10)
begin
	declare @countGR DECIMAL(18, 10)
	set @countGR =(select 
		case rtrim(ltrim(mlf.Name_MLF))
		when 'мкг' then 0.000001 * ls.M_LF
		when 'мг' then 0.001 * ls.M_LF
		when 'г' then 1 * ls.M_LF
		when 'кг' then 1000 * ls.M_LF
		when 'т' then  1000000 * ls.M_LF
		else 0
		end
		from oms_LS ls
		inner join oms_MLF mlf on mlf.MLFID = ls.rf_MLFID
		where ls.LSID = @LSID)
	set @countGR = @countGR * @countLS
	return @countGR
end


go

