CREATE VIEW [V_oms_kl_StatCureResult] AS SELECT 
[hDED].[kl_StatCureResultID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_StatCureResultCode], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[CODE_Region] as [CODE_Region], 
[hDED].[StatCureResultGUID] as [StatCureResultGUID], 
[hDED].[CODE_Federal] as [CODE_Federal]
FROM [oms_kl_StatCureResult] as [hDED]
go

