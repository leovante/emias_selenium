CREATE VIEW [V_ras_Series] AS SELECT 
[hDED].[SeriesID], [hDED].[HostSeriesID], [hDED].[x_Edition], [hDED].[x_Status], 
((Select top 1 Name from ras_producer where ProducerID = [jT_ras_Nomenclature].rf_producerID)) as [V_Producer], 
[jT_ras_Nomenclature].[Name] as [V_NAME_LS], 
[jT_ras_Nomenclature].[Cod_RAS] as [V_COD], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[hDED].[NUM] as [NUM], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Note] as [Note], 
[hDED].[SertMSG] as [SertMSG], 
[hDED].[IsDefect] as [IsDefect], 
[hDED].[IsFake] as [IsFake], 
[hDED].[Barcode] as [Barcode], 
[hDED].[IsStopped] as [IsStopped], 
[hDED].[SertPath] as [SertPath], 
[hDED].[Guid] as [Guid]
FROM [ras_Series] as [hDED]
INNER JOIN [ras_Nomenclature] as [jT_ras_Nomenclature] on [jT_ras_Nomenclature].[NomenclatureID] = [hDED].[rf_NomenclatureID] AND  [jT_ras_Nomenclature].[HostNomenclatureID] = [hDED].[rf_NomenclatureIDHost]
go

