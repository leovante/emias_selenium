CREATE view [tmp_CLS] as select    
	cls.rf_TenderID as TenderID,
	cls.PR_REG, 
	cls.DATE_BP,
	cls.DATE_EP,
	cls.MSG_TEXT,
	LS.NOMK_LS,
	cls.C_PFS,
	cls.Doz_Me,
	ten.GUID as TENDERGUID,
	cls.Count_All,
	cls.SumDelivery,
	cls.CountDelivery,
	cls.GUIDCLS,
	cls.LotPositionGuid	
from  V_ras_PositionBillEx p

left join V_ras_StoredLS sls on sls.StoredLSID=p.rf_StoredLSID 
     and sls.HostStoredLSID=p.rf_StoredLSIDHost
left join ras_LSFO lsfo on lsfo.LSFOID = sls.rf_LSFOID      
	and sls.rf_LSFOIDHost=lsfo.HostLSFOID	
left join oms_CLS cls ON lsfo.rf_CLSID=cls.CLSID and cls.isCOD = 0
inner join oms_LS ls ON cls.rf_LSID = ls.LSID
left join oms_Tender  ten on ten.TenderID= sls.rf_TenderID
where p.rf_BillExtractedID=6089 
and p.rf_BillExtractedIDHost = 999 and
 rf_StateExPosBillID in(15,25)
go

