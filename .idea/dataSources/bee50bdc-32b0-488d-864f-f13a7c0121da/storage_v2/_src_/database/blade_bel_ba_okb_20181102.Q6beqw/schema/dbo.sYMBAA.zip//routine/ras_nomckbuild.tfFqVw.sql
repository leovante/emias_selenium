
CREATE PROCEDURE [dbo].[ras_NomckBuild]
as
begin
if exists(select * from sysobjects where [name] = 'tmp_err') drop table tmp_err

Declare @n_tab varchar(100);
Declare @sql varchar(max),@sql2 varchar(max);

BEGIN TRY;
WITH GetLiquidMass(LSID, MLF, MLFID) as
(
	select ttt.LSID, ttt.M_LF, ttt.MLFID from 
	(
	select ls.LSID,
	(
		case when con.Code = 1 -- %
		then 
			10 * CONVERT(decimal(7,3), REPLACE(pr.DfConc, ',', '.')) * n.PPackVolume
		else
			case when con.Code = 2 or con.Code = 3 --мг/мл или мкг/мл
			then
				CONVERT(decimal(7,3), REPLACE(pr.DfConc, ',', '.')) * n.PPackVolume
			else
				case when con.ShortName like 'мг/%мл' 
				then
					CONVERT(decimal(7,3), REPLACE(pr.DfConc, ',', '.')) * n.PPackVolume / 
						CONVERT(decimal(7,3), REPLACE(
						SUBSTRING(con.ShortName, patindex('%[0-9]%', con.ShortName), patindex('% мл%', con.ShortName) - patindex('%[0-9]%', con.ShortName)),
						 ',',
						  '.'))
				else
					case when con.ShortName like 'мкг/%мл' 
					then
						CONVERT(decimal(7,3), REPLACE(pr.DfConc, ',', '.')) * n.PPackVolume / 
							CONVERT(decimal(7,3), REPLACE(
							SUBSTRING(con.ShortName, patindex('%[0-9]%', con.ShortName), patindex('% мл%', con.ShortName) - patindex('%[0-9]%', con.ShortName)),
							 ',',
							  '.'))
					end
				end
			end
		end
	) as M_LF,
	(
		case when con.Code = 1 or con.Code = 2 -- % или мг/мл
		then 
			(select top 1 MLFID from oms_MLF where C_MLF = 2)
		else
			case when con.Code = 3 --мкг/мл
			then
				(select top 1 MLFID from oms_MLF where C_MLF = 4)
			else
				case when con.ShortName like 'мг/%мл' 
				then
					(select top 1 MLFID from oms_MLF where C_MLF = 2)
				else
					case when con.ShortName like 'мкг/%мл' 
					then
						(select top 1 MLFID from oms_MLF where C_MLF = 4)
					end
				end
			end
		end
	) as MLFID
	from rls_Nomen n
	inner join oms_LS ls on ls.RlsNomenUid = n.UID
	inner join rls_Prep pr on n.rf_PrepUID = pr.UID
	inner join rls_CubicUnits cub on cub.UID = n.rf_CubicUnitsUID
	inner join rls_ConcenUnits con on con.UID = pr.rf_ConcenUnitsUID
	where n.NomenID > 0 and
	pr.DFMass = 0 and
	n.PPackMass = 0 and
	n.PPackVolume <> 0 and
	cub.Code = 1 and
	pr.DfConc <> ''
	) ttt
	where ttt.M_LF is not null
)

update oms_LS
set 
	M_LF = GetLiquidMass.MLF,
	rf_MLFID = GetLiquidMass.MLFID
from oms_LS
join GetLiquidMass on oms_LS.LSID = GetLiquidMass.LSID;
END TRY
BEGIN CATCH
if ERROR_NUMBER()=2601 
begin 
	if exists(select * from sysobjects where [name] = 'tmp_err')
		begin 
			insert into tmp_err
			SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка установки массы установки массы для растворов' as er
		end
end
END CATCH

BEGIN TRY
--Добавляется страна -производитель, если такой еще не было
SET @n_tab='ras_Country';
INSERT INTO ras_Country (Code, SmallName ,BigName)
Select distinct 
	((select max(Code) from ras_Country)+ROW_NUMBER() OVER(ORDER BY oms_LS.Name_CNF)) as code,
	left(Name_CNF,3) as SmallName,
	Name_CNF as BigName
	from oms_LS
	left outer join ras_Country on Name_CNF=BigName
where BigName is null
group by Name_CNF

END TRY
--Если запрос таки упал :(
BEGIN CATCH
--ошибка в индексах
if ERROR_NUMBER()=2601 
begin 
	SET @sql=null;
	SELECT @sql = ISNULL(@sql,'')+ CASE WHEN @sql IS NULL THEN '' ELSE ', ' END +c.name
		FROM sys.index_columns ic
		LEFT JOIN sys.indexes i ON ic.object_id=i.object_id
		LEFT JOIN sys.columns c ON ic.object_id=c.object_id
		WHERE ic.index_id=i.index_id and ic.column_id=c.column_id
		and i.name like '%UNIQUE'and ic.object_id=object_id(@n_tab)
	Select @sql2= 'Name_CNF'  

	if exists(select * from sysobjects where [name] = 'tmp_err')
		begin 
			insert into tmp_err
			SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
		
			end
		else
			begin
			SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
			into tmp_err
		end
end
--другая ошибка
else 
	if exists(select * from sysobjects where [name] = 'tmp_err')
		begin
			insert into tmp_err
			SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage,'' as er
		end
	else
		begin
			SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage,'' as er into tmp_err
		end
END CATCH

BEGIN TRY
		--Добавляется фирма-производитель, если такой еще не было
		SET @n_tab='ras_Producer';
		INSERT INTO [ras_Producer]
				   ([rf_OrganisationID]
				   ,[Name]
				   ,[rf_CountryIDHost]
				   ,[rf_CountryID])
		Select distinct 0,substring(Name_FCT, 1, 150), isnull(HostCountryID,999) as HostCountryID,isnull(CountryID,0)
		from oms_LS
		left outer join ras_Country  on Name_CNF=BigName
		left outer join [ras_Producer] on substring(Name_FCT, 1, 150)=[Name]
		where [Name] is null and NAME_CNF+'_'+convert(varchar,rf_CountryID) not in (Select (NAME_CNF+'_'+convert(varchar,rf_CountryID))
																			from oms_LS
																			left outer join ras_Country  on Name_CNF=BigName
																			left outer join [ras_Producer] on substring(Name_FCT, 1, 150)=[Name]
																			where [Name] is null
																			group by NAME_CNF, rf_CountryID
																			having count(NAME_CNF+'_'+convert(varchar,rf_CountryID)) > 1)
		group by Name_FCT,CountryID,HostCountryID

END TRY
		--Если запрос таки упал :(
BEGIN CATCH
		--ошибка в индексах
		if ERROR_NUMBER()=2601 
		begin 

		SET @sql=null;
		SELECT @sql = ISNULL(@sql,'')+ CASE WHEN @sql IS NULL THEN '' ELSE ', ' END +c.name
			FROM sys.index_columns ic
			LEFT JOIN sys.indexes i ON ic.object_id=i.object_id
			LEFT JOIN sys.columns c ON ic.object_id=c.object_id
			WHERE ic.index_id=i.index_id and ic.column_id=c.column_id
			and i.name like '%UNIQUE'and ic.object_id=object_id(@n_tab)
		Select @sql2='Name_FCT,CountryID,HostCountryID'
		 
		if exists(select * from sysobjects where [name] = 'tmp_err')
		begin 
			insert into tmp_err
			SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
		
		end
		else
			begin
			SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
			into tmp_err
			end
		end
		else 
		if exists(select * from sysobjects where [name] = 'tmp_err')
			begin
				insert into tmp_err
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage,'' as er
			end
		else
			begin
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage,'' as er into tmp_err
			end
END CATCH

--Добавление номенклатуры
Execute dbo.ras_NomenclatureCreate;
-----------------------------------
--Обновление Номенклатуры
declare @LsIdTable LsIdTable
insert into @LsIdTable(LSID)
select LSID from oms_LS

Execute UpdateNomenclature @LsIdTable

-----------------------------------
--Добавление и обновление организации у поставщика
declare @SfoIdTable SfoIdTable
insert into @SfoIdTable(SfoID)
select SFOID from oms_SFO

Execute UpdateOrganisationProvider @SfoIdTable




BEGIN TRY
----------------------------
--Добавление АПТЕК в таблицу Организаций, если с таким кодом их еще не было
SET @n_tab='ras_Organisation';	
if (select ValueStr from x_UserSettings where Property = 'OrgType') in ('BOTH', 'APU')
begin
			INSERT INTO [ras_Organisation]
			([Name]
			,[Code]
			,[OGRN]
			,[rf_DogovorID]
			,[Address]
			,[IsActive]
			,[NameDIR]
			,[NameBUH]
			,[TEL]
			,[FAX]
			,[E_mail]
			,[rf_OKATO]
			,[SName])
			Select distinct 
				P_NAMES as [NAME],
				ltrim(rtrim(A_COD)) as Code,
				P_OGRN as OGRN,
				0 as rf_DogovorID,
				Adres as Address,
				1 as IsActive,
				case when  fam_zav+' '+substring(im_zav,1,1)+'.'+' '+substring(ot_zav,1,1)+'.'=' . . ' then '' 
		                 else fam_zav+' '+substring(im_zav,1,1)+'.'+' '+substring(ot_zav,1,1)+'.' end as NameDir,
				'' as NameBUH,
				oms_APU.Tel,
				oms_APU.Fax,
				oms_APU.E_Mail,
				rf_OKATOID as rf_OKATO,
				oms_APU.P_NAMEF as [SNAME]
				-- select * 
			from oms_APU
			left outer join [ras_Organisation] on oms_APU.A_COD = [ras_Organisation].Code
			where APUID>0 and [ras_Organisation].OGRN is NULL and A_COD <> ''
			--order by A_COD

			--ОБНОВЛЕНИЕ ИЗ oms_APU
			update [ras_Organisation]
			set
			[Name] = ttt.[NAME]
			,[OGRN] = ttt.OGRN
			,[Address] = ttt.Address
			,[NameDIR] = ttt.NameDir
			,[TEL] = ttt.Tel
			,[FAX] = ttt.Fax
			,[E_mail] = ttt.E_Mail
			,[rf_OKATO] = ttt.rf_OKATO
			,[SName] = ttt.[SNAME]
			,[IsActive] = ttt.[IsActive]
			from
			(
				Select distinct 
					P_NAMES as [NAME],		
					P_OGRN as OGRN,		
					Adres as Address,		
					case when  fam_zav+' '+substring(im_zav,1,1)+'.'+' '+substring(ot_zav,1,1)+'.'=' . . ' then '' 
		                   else fam_zav+' '+substring(im_zav,1,1)+'.'+' '+substring(ot_zav,1,1)+'.' end as NameDir,		
					oms_APU.Tel,
					oms_APU.Fax,
					oms_APU.E_Mail,
					rf_OKATOID as rf_OKATO,
					oms_APU.P_NAMEF as [SNAME],
					[ras_Organisation].OrganisationID,
					case
						when getdate() between oms_APU.Date_B and oms_APU.Date_E
							then 1
							else 0					 
					end as IsActive	
				from oms_APU
				inner join [ras_Organisation] on oms_APU.A_COD = [ras_Organisation].Code
				where APUID>0 and A_COD <> ''
			)ttt
			where ttt.OrganisationID = [ras_Organisation].OrganisationID
end
END TRY
--Если запрос таки упал :(
BEGIN CATCH
--ошибка в индексах
	if ERROR_NUMBER()=2601 
	begin 

		SET @sql=null;
		SELECT @sql = ISNULL(@sql,'')+ CASE WHEN @sql IS NULL THEN '' ELSE ', ' END +c.name
			FROM sys.index_columns ic
			LEFT JOIN sys.indexes i ON ic.object_id=i.object_id
			LEFT JOIN sys.columns c ON ic.object_id=c.object_id
			WHERE ic.index_id=i.index_id and ic.column_id=c.column_id
			and i.name like '%UNIQUE'and ic.object_id=object_id(@n_tab)

		Select @sql2='CODE,OGRN'
		 
		if exists(select * from sysobjects where [name] = 'tmp_err')
				begin 
					insert into tmp_err
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
		
					end
				else
					begin
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
					into tmp_err
				end
	end
	--другая ошибка
	else 
		if exists(select * from sysobjects where [name] = 'tmp_err')
			begin
				insert into tmp_err
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage, '' as er
			end
		else
			begin
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage, '' as er into tmp_err
			end
END CATCH



BEGIN TRY
----------------------------
--Добавление ЛПУ в таблицу Организаций, если с таким кодом их еще не было
SET @n_tab='ras_Organisation';	
if (select ValueStr from x_UserSettings where Property = 'OrgType') in ('BOTH', 'LPU')
begin
			INSERT INTO [ras_Organisation]
	   ([Name]
	   ,[Code]
	   ,[OGRN]
	   ,[rf_DogovorID]
	   ,[Address]
	   ,[IsActive]
	   ,[NameDIR]
	   ,[NameBUH]
	   ,[TEL]
	   ,[FAX]
	   ,[E_mail]
	   ,[rf_OKATO]
	   ,[SName])
	   Select distinct 
	    M_NAMES as [NAME],
	    ltrim(rtrim(MCOD)) as Code,
	    C_OGRN as OGRN,
	    0 as rf_DogovorID,
	    Adres as Address,
	    1 as IsActive,
	    case 
           when  fam_GV+' '+substring(im_gv,1,1)+'.'+' '+substring(ot_gv,1,1)+'.'=' . . ' then '' 
		        else fam_gv+' '+substring(im_gv,1,1)+'.'+' '+substring(ot_gv,1,1)+'.' end as NameDir,
	   case 
           when  fam_BUX+' '+substring(im_BUX,1,1)+'.'+' '+substring(ot_BUX,1,1)+'.'=' . . ' then '' 
		        else fam_BUX+' '+substring(im_BUX,1,1)+'.'+' '+substring(ot_BUX,1,1)+'.' end as NameBUH,
	    oms_LPU.Tel,
	    oms_LPU.Fax,
	    oms_LPU.E_Mail,
	    rf_OKATOID as rf_OKATO,
	    oms_LPU.M_NAMEF as [SNAME]
	    -- select * 
	   from oms_LPU
	   left join [ras_Organisation] on oms_LPU.C_OGRN=[ras_Organisation].OGRN and ltrim(rtrim(MCOD)) = [ras_Organisation].Code
	   where LPUID>0 and [ras_Organisation].OGRN is NULL and MCOD <> ''

			update [ras_Organisation]
			set
			[Name] = ttt.[NAME]
			,[OGRN] = ttt.OGRN
			,[Address] = ttt.Address
			,[TEL] = ttt.Tel
			,[FAX] = ttt.Fax
			,[E_mail] = ttt.E_Mail
			,[rf_OKATO] = ttt.rf_OKATO
			,[SName] = ttt.[SNAME]
			,[IsActive] = ttt.[IsActive]
			,[NameDIR] = ttt.[FAM_GV]
			,[NameBUH] = ttt.[FAM_BUX]
			from
			(
				Select distinct 
					M_NAMES as [NAME],		
					C_OGRN as OGRN,		
					Adres as Address,					
					oms_LPU.Tel,
					oms_LPU.Fax,
					oms_LPU.E_Mail,
					rf_OKATOID as rf_OKATO,
					oms_LPU.M_NAMEF as [SNAME],
					[ras_Organisation].OrganisationID,
					case 
                       when  fam_BUX+' '+substring(im_BUX,1,1)+'.'+' '+substring(ot_BUX,1,1)+'.'=' . . ' then '' 
		               else fam_BUX+' '+substring(im_BUX,1,1)+'.'+' '+substring(ot_BUX,1,1)+'.' end  FAM_BUX,
					case 
                       when  fam_GV+' '+substring(im_gv,1,1)+'.'+' '+substring(ot_gv,1,1)+'.'=' . . ' then '' 
		                  else fam_gv+' '+substring(im_gv,1,1)+'.'+' '+substring(ot_gv,1,1)+'.' end [FAM_GV] ,
					case
						when getdate() between oms_LPU.Date_B and oms_LPU.Date_E
							then 1
							else 0					 
					end as IsActive	
				from oms_LPU
				inner join [ras_Organisation] on oms_LPU.C_OGRN=[ras_Organisation].OGRN and ltrim(rtrim(oms_LPU.MCOD)) = [ras_Organisation].Code
				where LPUID>0 and oms_LPU.MCOD <> ''
			)ttt
			where ttt.OrganisationID = [ras_Organisation].OrganisationID
end
END TRY
--Если запрос таки упал :(
BEGIN CATCH
--ошибка в индексах
	if ERROR_NUMBER()=2601 
	begin 

		SET @sql=null;
		SELECT @sql = ISNULL(@sql,'')+ CASE WHEN @sql IS NULL THEN '' ELSE ', ' END +c.name
			FROM sys.index_columns ic
			LEFT JOIN sys.indexes i ON ic.object_id=i.object_id
			LEFT JOIN sys.columns c ON ic.object_id=c.object_id
			WHERE ic.index_id=i.index_id and ic.column_id=c.column_id
			and i.name like '%UNIQUE'and ic.object_id=object_id(@n_tab)

		Select @sql2='CODE,OGRN'
		 
		if exists(select * from sysobjects where [name] = 'tmp_err')
				begin 
					insert into tmp_err
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
		
					end
				else
					begin
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
					into tmp_err
				end
	end
	--другая ошибка
	else 
		if exists(select * from sysobjects where [name] = 'tmp_err')
			begin
				insert into tmp_err
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage, '' as er
			end
		else
			begin
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage, '' as er into tmp_err
			end
END CATCH

-----------------------------------
--Добавление поставщиков Provider
declare @ProviderSfoIdTable ProviderSfoIdTable
insert into @ProviderSfoIdTable(ProviderSfoID)
select SFOID from oms_SFO

Execute UpdateProvider @ProviderSfoIdTable

BEGIN TRY
---------------------------
--Вставка в ras_LSFO, изменилось ключевое поле, теперь туда входит код цены
	
	SET @n_tab='ras_LSFO';	
	INSERT INTO [ras_LSFO]
		([rf_NomenclatureID]
		,[C_LSProvider]
		,[rf_ProviderID]
		,[rf_ProduсerID]
		,[C_PFS],rf_NomenclatureIDHost,rf_ProviderIDHost, rf_CLSID)
	Select distinct nom.NomenclatureID as rf_NomenclatureID,nom.cod_ras+'_'+ cast(oms_CLS.C_PFS as varchar(max)) as C_LSProvider, 
		prov.ProviderID as rf_ProviderID,
		nom.rf_ProducerID as [rf_ProducerID], 
		oms_CLS.C_PFS, 
		nom.HostNomenclatureID as rf_NomenclatureIDHost, 
		999 as rf_ProviderIDHost, CLSID
	from ras_Nomenclature nom
	inner join oms_LS ls on LSID=nom.rf_LSID and LSID > 0
	inner join oms_CLS on ls.LSID= oms_CLS.rf_LSID
	
	-- не создаем лсфо по неподписанным контрактам
	inner join oms_Tender on TenderID=rf_TenderID  and TenderID > 0 and (rf_StateTenderID = 2 --Контракт подписан
		or not exists(select * from oms_CLS where rf_TenderID = oms_Tender.TenderID and isCOD = 1)) --Контракт не из ЦОДА
	inner join oms_SFO sfo on sfo.SFOID = rf_SFOID
	inner join ras_Organisation org on org.OGRN = sfo.FO_OGRN and sfo.CFO = org.Code
	inner join ras_Provider prov on prov.rf_OrganisationID = org.OrganisationID
	left join ras_LSFO lsfo on cod_ras+'_'+ cast(oms_CLS.C_PFS as varchar(max))=C_LSProvider and NomenclatureID=rf_NomenclatureID and HostNomenclatureID=rf_NomenclatureIDHost	
	
	where len(nom.cod_ras)>1 and lsfo.C_LSProvider is null 
	
	and (nom.cod_ras+'_'+ cast(oms_CLS.C_PFS as varchar(max))) not in (	Select distinct 
	       cod_ras+'_'+ cast(oms_CLS.C_PFS as varchar(max))
	from ras_Nomenclature
	inner join oms_LS on LSID=ras_Nomenclature.rf_LSID and LSID > 0
	inner join oms_CLS on LSID= oms_CLS.rf_LSID
	left join ras_LSFO on cod_ras+'_'+ cast(oms_CLS.C_PFS as varchar(max))=C_LSProvider and NomenclatureID=rf_NomenclatureID and HostNomenclatureID=rf_NomenclatureIDHost 
	where len(cod_ras)>1 and C_LSProvider is null 
	group by cod_ras, oms_CLS.C_PFS
	having count(cod_ras+'_'+ cast(oms_CLS.C_PFS as varchar(max))) > 1)
	group by nom.NomenclatureID,nom.cod_ras, nom.rf_ProducerID ,oms_CLS.C_PFS,prov.ProviderID,nom.HostNomenclatureID, clsID
	
	Update ras_LSFO
	set rf_ProviderID = c.ProviderID
	from
	 (
	Select lsfo.LSFOID, prov.ProviderID, org.Name, sfo.FO_NAMES
	from ras_LSFO lsfo
	inner join oms_CLS cls on cls.CLSID = lsfo.rf_CLSID
	inner join oms_Tender tend on tend.TenderID = cls.rf_TenderID  and TenderID > 0
	inner join oms_SFO sfo on sfo.SFOID = tend.rf_SFOID
	inner join ras_Organisation org on org.OGRN = sfo.FO_OGRN and sfo.CFO = org.Code
	inner join ras_Provider prov on prov.rf_OrganisationID = org.OrganisationID
	) c
	where c.LSFOID = ras_lsfo.LSFOID and ras_lsfo.LSFOID > 0 and (ras_lsfo.rf_ProviderID = 0 or ras_lsfo.rf_ProviderID <> c.ProviderID)

	execute UpdateOrganisationOwnerByProvider

	execute UpdateLSFObyClsTender

END TRY
--Если запрос таки упал :(
BEGIN CATCH
--ошибка в индексах
	if ERROR_NUMBER()=2601 
	begin 

		SET @sql=null;
		SELECT @sql = ISNULL(@sql,'')+ CASE WHEN @sql IS NULL THEN '' ELSE ', ' END +c.name
			FROM sys.index_columns ic
			LEFT JOIN sys.indexes i ON ic.object_id=i.object_id
			LEFT JOIN sys.columns c ON ic.object_id=c.object_id
			WHERE ic.index_id=i.index_id and ic.column_id=c.column_id
			and i.name like '%UNIQUE'and ic.object_id=object_id(@n_tab)

		Select @sql2='C_LSProvider,rf_NomenclatureID,rf_NomenclatureIDHost,rf_ProviderID,rf_ProviderIDHost' 

		if exists(select * from sysobjects where [name] = 'tmp_err')
				begin 
					insert into tmp_err
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
		
					end
				else
					begin
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
					into tmp_err
				end
	end
	--другая ошибка
	else 
		if exists(select * from sysobjects where [name] = 'tmp_err')
			begin
				insert into tmp_err
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage, '' as er
			end
		else
			begin
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage, '' as er into tmp_err
			end
END CATCH

begin tran
update [ras_Organisation]
			set
			NameBuh = ttt.[FAM_BUX],
			NameDir =ttt.[FAM_RUK]
from (select case 
               when  fam_BUX+' '+substring(im_BUX,1,1)+'.'+' '+substring(ot_BUX,1,1)+'.'=' . . ' then '' 
		        else fam_BUX+' '+substring(im_BUX,1,1)+'.'+' '+substring(ot_BUX,1,1)+'.'
			  end FAM_BUX,
			  case 
                when  fam_ruk+' '+substring(im_ruk,1,1)+'.'+' '+substring(ot_ruk,1,1)+'.'=' . . ' then '' 
		        else fam_ruk+' '+substring(im_ruk,1,1)+'.'+' '+substring(ot_ruk,1,1)+'.' 
			  end FAM_RUK,cfo
			from [ras_Organisation] 
			inner  join [oms_sfo] sfo on sfo.Rcode = [ras_Organisation].Code
			where SFOID>0 and cfo <> '' and (sfo.FAM_BUX != NameBuh or sfo.[FAM_RUK] != NameDir)
	 ) ttt 
	 where  ttt.cfo=Code
commit tran

if exists (select * from sys.tables where name = 'tmp_err')
begin 
	select * from tmp_err
end
end
go

