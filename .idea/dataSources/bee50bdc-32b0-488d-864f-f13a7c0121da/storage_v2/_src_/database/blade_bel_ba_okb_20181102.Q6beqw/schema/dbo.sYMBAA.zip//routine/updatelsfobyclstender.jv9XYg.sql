
CREATE PROCEDURE [dbo].[UpdateLSFObyClsTender]
as
begin

update stls
set 
	stls.rf_LSFOID = lsfo.LSFOID
from ras_StoredLS stls
	inner join ras_Nomenclature nom on stls.rf_NomenclatureID = nom.NomenclatureID
	inner join oms_LS ls on nom.rf_LSID = ls.LSID
	
	inner join ras_TransactJournal tj on tj.rf_StoredLSID = stls.StoredLSID
	inner join ras_PositionBill posBill on tj.PositionID = posBill.PositionBillID 
		and tj.rf_DocDescriptionID = 2
	inner join oms_Tender tender on posBill.rf_TenderID = tender.TenderID

	inner join oms_CLS cls on cls.rf_LSID = ls.LSID and cls.rf_TenderID = tender.TenderID and cls.PR_REG = stls.Price

	inner join ras_LSFO lsfo on cls.C_PFS = lsfo.C_PFS
where stls.rf_LSFOID = 0

update posBill
set 
	posBill.rf_LSFOID = lsfo.LSFOID
from ras_StoredLS stls
	inner join ras_Nomenclature nom on stls.rf_NomenclatureID = nom.NomenclatureID
	inner join oms_LS ls on nom.rf_LSID = ls.LSID
	
	inner join ras_TransactJournal tj on tj.rf_StoredLSID = stls.StoredLSID
	inner join ras_PositionBill posBill on tj.PositionID = posBill.PositionBillID 
		and tj.rf_DocDescriptionID = 2
	inner join oms_Tender tender on posBill.rf_TenderID = tender.TenderID

	inner join oms_CLS cls on cls.rf_LSID = ls.LSID and cls.rf_TenderID = tender.TenderID and cls.PR_REG = stls.Price

	inner join ras_LSFO lsfo on cls.C_PFS = lsfo.C_PFS
where posBill.rf_LSFOID = 0

end
go

