CREATE VIEW [V_oms_onco_N011] AS SELECT 
[hDED].[onco_N011ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_onco_N010ID] as [rf_onco_N010ID], 
[jT_oms_onco_N010].[Igh_NAME] as [SILENT_rf_onco_N010ID], 
[hDED].[ID_R_I] as [ID_R_I], 
[hDED].[KOD_R_I] as [KOD_R_I], 
[hDED].[R_I_NAME] as [R_I_NAME], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN011] as [GUIDN011]
FROM [oms_onco_N011] as [hDED]
INNER JOIN [oms_onco_N010] as [jT_oms_onco_N010] on [jT_oms_onco_N010].[onco_N010ID] = [hDED].[rf_onco_N010ID]
go

