CREATE VIEW [V_oms_TYPEDOC] AS SELECT 
[hDED].[TYPEDOCID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_DOC] as [C_DOC], 
[hDED].[NAME_PFR] as [NAME_PFR], 
[hDED].[DocSer] as [DocSer], 
[hDED].[NAME] as [NAME], 
[hDED].[DocNum] as [DocNum], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_TYPEDOC] as [hDED]
go

