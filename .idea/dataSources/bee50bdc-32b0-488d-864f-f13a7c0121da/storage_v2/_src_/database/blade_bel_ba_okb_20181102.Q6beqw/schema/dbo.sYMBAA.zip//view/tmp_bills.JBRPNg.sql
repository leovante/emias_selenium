CREATE view [tmp_BILLS] as select 
     b.BillExtractedID as beid, 
      --Номер накладной
      b.NUM as BILL_NUM,
      --Дата накладной 
      b.Date as BILL_DATE,
      --ОГРН фармоорганизации
      ow.OGRN as OGRN_FO,
      --Код фармоорганизации
      ow.CODE as CODE_FO,
      --ОГРН организации-грузополучатель
      opr.OGRN as OGRN_OUT,
      --Код  организации-грузополучатель
      opr.CODE as CODE_OUT,
      --ОГРН организации-грузоотправителя
      oc.OGRN as OGRN_IN,
      --Код организации-грузоотправителя
      oc.CODE as CODE_IN,
      --Примечание
      do.Note as NOTE,
      --Договор
      do.D_Name  as DOGOVOR,
      --тип документа
      2 as DOCUMENT_TYPE,
      --Тип поставки
      isnull(td.Code,0) as TYPEPOST  
from ras_BillExtracted b
          inner join ras_Organisation as ow on b.rf_OrganisationProviderID=ow.OrganisationID 
                and b.rf_OrganisationProviderIDHost=ow.HostOrganisationID
          inner join ras_Organisation as opr on    b.rf_OrganisationAgentID=opr.OrganisationID 
                and b.rf_OrganisationAgentIDHost=opr.HostOrganisationID 
          inner join ras_Organisation as oc on b.rf_OrganisationContragent=oc.OrganisationID 
                and b.rf_OrganisationContragentHost=oc.HostOrganisationID
          inner join ras_Dogovor  as do on b.rf_DogovorID=do.DogovorID
          inner join ras_TypeDelivery td ON b.rf_TypeDeliveryID=td.TypeDeliveryID
          
where b.BillExtractedID=6089 
           and b.HostBillExtractedID=999
go

