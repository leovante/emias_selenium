CREATE VIEW [V_trs_Package_Host] AS SELECT 
[hDED].[Package_HostID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PackageID] as [rf_PackageID], 
[jT_trs_Package].[Description] as [SILENT_rf_PackageID], 
[hDED].[rf_HostID] as [rf_HostID], 
[jT_trs_Host].[HostName] as [SILENT_rf_HostID], 
[hDED].[rf_PackageStatusID] as [rf_PackageStatusID], 
[jT_trs_PackageStatus].[Name] as [SILENT_rf_PackageStatusID], 
[hDED].[DateTime] as [DateTime], 
[hDED].[StateMessage] as [StateMessage]
FROM [trs_Package_Host] as [hDED]
INNER JOIN [trs_Package] as [jT_trs_Package] on [jT_trs_Package].[PackageID] = [hDED].[rf_PackageID]
INNER JOIN [trs_Host] as [jT_trs_Host] on [jT_trs_Host].[HostID] = [hDED].[rf_HostID]
INNER JOIN [trs_PackageStatus] as [jT_trs_PackageStatus] on [jT_trs_PackageStatus].[PackageStatusID] = [hDED].[rf_PackageStatusID]
go

