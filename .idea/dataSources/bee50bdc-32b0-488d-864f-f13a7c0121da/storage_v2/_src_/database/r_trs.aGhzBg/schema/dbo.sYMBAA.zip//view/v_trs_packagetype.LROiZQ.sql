CREATE VIEW [V_trs_PackageType] AS SELECT 
[hDED].[PackageTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [trs_PackageType] as [hDED]
go

