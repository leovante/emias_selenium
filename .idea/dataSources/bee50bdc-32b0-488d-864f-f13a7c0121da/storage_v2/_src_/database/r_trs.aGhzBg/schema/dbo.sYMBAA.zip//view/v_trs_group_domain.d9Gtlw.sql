CREATE VIEW [V_trs_Group_Domain] AS SELECT 
[hDED].[Group_DomainID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_GroupID] as [rf_GroupID], 
[jT_trs_Group].[GroupName] as [SILENT_rf_GroupID], 
[hDED].[rf_DomainID] as [rf_DomainID], 
[jT_trs_Domain].[DomainName] as [SILENT_rf_DomainID]
FROM [trs_Group_Domain] as [hDED]
INNER JOIN [trs_Group] as [jT_trs_Group] on [jT_trs_Group].[GroupID] = [hDED].[rf_GroupID]
INNER JOIN [trs_Domain] as [jT_trs_Domain] on [jT_trs_Domain].[DomainID] = [hDED].[rf_DomainID]
go

