CREATE VIEW [V_trs_Package] AS SELECT 
[hDED].[PackageID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SenderID] as [rf_SenderID], 
[jT_trs_Host].[HostName] as [SILENT_rf_SenderID], 
[hDED].[rf_ReceiverID] as [rf_ReceiverID], 
[jT_trs_Host1].[HostName] as [SILENT_rf_ReceiverID], 
[hDED].[rf_CanalID] as [rf_CanalID], 
[jT_trs_Canal].[CanalName] as [SILENT_rf_CanalID], 
[hDED].[rf_DataStorageID] as [rf_DataStorageID], 
[jT_trs_DataStorage].[HostAddress] as [SILENT_rf_DataStorageID], 
[hDED].[Description] as [Description], 
[hDED].[DateTime] as [DateTime], 
[hDED].[Closed] as [Closed], 
[hDED].[Message] as [Message], 
[hDED].[RealFileName] as [RealFileName], 
[hDED].[UniqueFileName] as [UniqueFileName], 
[hDED].[PartsAmount] as [PartsAmount], 
[hDED].[DeletedFromCache] as [DeletedFromCache]
FROM [trs_Package] as [hDED]
INNER JOIN [trs_Host] as [jT_trs_Host] on [jT_trs_Host].[HostID] = [hDED].[rf_SenderID]
INNER JOIN [trs_Host] as [jT_trs_Host1] on [jT_trs_Host1].[HostID] = [hDED].[rf_ReceiverID]
INNER JOIN [trs_Canal] as [jT_trs_Canal] on [jT_trs_Canal].[CanalID] = [hDED].[rf_CanalID]
INNER JOIN [trs_DataStorage] as [jT_trs_DataStorage] on [jT_trs_DataStorage].[DataStorageID] = [hDED].[rf_DataStorageID]
go

