
CREATE PROCEDURE [dbo].[x_AddScript]
(
		@name varchar(MAX) = '',
		@GUID uniqueidentifier = '00000000-0000-0000-0000-000000000000',
		@result varchar(50) = '',
		@antipod varchar(MAX) = '')
AS
BEGIN
	-- Declare the return variable here

	-- Add the T-SQL statements to compute the return value here
	delete from x_ScriptHistory where GUID = @GUID
	insert into x_ScriptHistory Values (@name, @GUID, @result, @antipod)
END
go

