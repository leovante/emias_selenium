
CREATE VIEW [dbo].[V_x_UserGroupRole] AS SELECT 
[hDED].[UserGroupRoleID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RoleGUID] as [rf_RoleGUID], 
[jT_x_Role].[Name] as [SILENT_rf_RoleGUID], 
[hDED].[rf_UserGroupGUID] as [rf_UserGroupGUID]
FROM [x_UserGroupRole] as [hDED]
INNER JOIN [x_Role] as [jT_x_Role] on [jT_x_Role].[GUID] = [hDED].[rf_RoleGUID]
go

