CREATE VIEW [V_trs_Canal_Domain] AS SELECT 
[hDED].[Canal_DomainID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DomainID] as [rf_DomainID], 
[jT_trs_Domain].[DomainName] as [SILENT_rf_DomainID], 
[hDED].[rf_CanalID] as [rf_CanalID], 
[jT_trs_Canal].[CanalName] as [SILENT_rf_CanalID]
FROM [trs_Canal_Domain] as [hDED]
INNER JOIN [trs_Domain] as [jT_trs_Domain] on [jT_trs_Domain].[DomainID] = [hDED].[rf_DomainID]
INNER JOIN [trs_Canal] as [jT_trs_Canal] on [jT_trs_Canal].[CanalID] = [hDED].[rf_CanalID]
go

