CREATE view [dbo].[V_x_UserSettings] as select UserSettingID, x_Edition, x_Status, 
[rf_UserID],[OwnerGUID],[DocTypeDefGUID],[rf_SettingTypeID],[Property],[ValueInt],[ValueStr],[ValueText],[ValueImg],[ValueDate] from [x_UserSettings]
go

