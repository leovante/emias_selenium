
CREATE view [V_x_MalibuDll] as select MalibuDllID, x_Edition, x_Status, 
[AssemblyName], [Type], [GUID], [Hash] from [x_MalibuDll]
go

