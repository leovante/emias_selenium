
CREATE FUNCTION [dbo].[x_IsScriptExists]
( @GUID uniqueidentifier = '00000000-0000-0000-0000-000000000000')
RETURNS int
AS
BEGIN
	DECLARE @ret int
	set @ret = (select top 1 count(*) from x_ScriptHistory where GUID = @GUID)
	RETURN @ret
END
go

