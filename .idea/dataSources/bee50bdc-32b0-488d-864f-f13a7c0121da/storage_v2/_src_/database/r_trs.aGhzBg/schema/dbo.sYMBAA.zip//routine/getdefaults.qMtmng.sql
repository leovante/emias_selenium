
/*  -   -     ,       */
create proc dbo.GetDefaults
    @objname nvarchar(776)			-- the table to check for constraints
	,@col_name nvarchar(500)
as
	-- PRELIM
	set nocount on

	declare	@objid			int           -- the object id of the table
			,@cnstdes		nvarchar(4000)-- string to build up index desc
			,@cnstname		sysname       -- name of const. currently under consideration
			,@i				int
			,@cnstid		int
			,@cnsttype		character(2)
			,@keys			nvarchar(2126)	--Length (16*max_identifierLength)+(15*2)+(16*3)
			,@dbname		sysname

	-- Create temp table
	create table #spcnsttab
	(
		cnst_id			int			NOT NULL
		,column_name			nvarchar(146) collate database_default NOT NULL   -- 128 for name + text for DEFAULT
		,cnst_bounded bit not null
		,cnst_name			sysname		collate database_default NOT NULL
		,cnst_nonblank_name	sysname		collate database_default NOT NULL
		,cnst_2type			character(2)	collate database_default NULL
		,cnst_keys			nvarchar(2126)	collate database_default NULL	-- see @keys above for length descr
	)

	-- Check to see that the object names are local to the current database.
	select @dbname = parsename(@objname,3)

	if @dbname is not null and @dbname <> db_name()
	begin
		raiserror(15250,-1,-1)
		return (1)
	end

	-- Check to see if the table exists and initialize @objid.
	select @objid = object_id(@objname)
	if @objid is NULL
	begin
		select @dbname=db_name()
		raiserror(15009,-1,-1,@objname,@dbname)
		return (1)
	end

	-- STATIC CURSOR OVER THE TABLE'S CONSTRAINTS
	declare ms_crs_cnst cursor local static for
		select id, xtype, name from sysobjects where parent_obj = @objid
			and xtype in ( 'D ')	-- ONLY 6.5 sysconstraints objects
		for read only

	-- Now check out each constraint, figure out its type and keys and
	-- save the info in a temporary table that we'll print out at the end.
	open ms_crs_cnst
	fetch ms_crs_cnst into @cnstid ,@cnsttype ,@cnstname
	while @@fetch_status >= 0
	begin

		if (@cnsttype = 'D ')
		begin
			select @i = 1
			select @cnstdes = text from syscomments where id = @cnstid and colid = @i
			while @cnstdes is not null
			begin
				if @i=1
					insert into	#spcnsttab
						(cnst_id,column_name ,cnst_name ,cnst_nonblank_name ,cnst_keys, cnst_2type,cnst_bounded)
					select @cnstid, col_name(@objid ,colid),
						@cnstname ,@cnstname ,substring(@cnstdes,1,2000), @cnsttype,0
					from syscolumns where cdefault = @cnstid
				else
					insert into #spcnsttab (cnst_id,column_name,cnst_name,cnst_nonblank_name,cnst_keys, cnst_2type,cnst_bounded)
					select	@cnstid,' ' ,' ' ,@cnstname ,substring(@cnstdes,1,2000), @cnsttype,0

				if len(@cnstdes) > 2000
					insert into #spcnsttab (cnst_id,column_name,cnst_name,cnst_nonblank_name,cnst_keys, cnst_2type,cnst_bounded)
					select	@cnstid,' ' ,' ' ,@cnstname ,substring(@cnstdes,2001,2000), @cnsttype,0

				select @i = @i + 1
				select @cnstdes = null
				select @cnstdes = text from syscomments where id = @cnstid and colid = @i
			end
		end

		fetch ms_crs_cnst into @cnstid ,@cnsttype ,@cnstname
	end		--of major loop
	deallocate ms_crs_cnst

	-- Find any rules or defaults bound by the sp_bind... method.

	insert into #spcnsttab (cnst_id,column_name,cnst_name,cnst_nonblank_name,cnst_keys, cnst_2type,cnst_bounded)
	select c.cdefault, c.name,
		object_name(c.cdefault),object_name(c.cdefault), text, 'D ',1
	from	syscolumns c,syscomments m
	where	c.id = @objid and m.id = c.cdefault and ObjectProperty(c.cdefault, 'IsConstraint') = 0

	select * from #spcnsttab where column_name=@col_name
	return (0) -- sp_helpconstraint
go

