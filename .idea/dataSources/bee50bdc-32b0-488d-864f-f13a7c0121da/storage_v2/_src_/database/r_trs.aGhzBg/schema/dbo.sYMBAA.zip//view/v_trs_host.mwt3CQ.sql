CREATE VIEW [V_trs_Host] AS SELECT 
[hDED].[HostID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[HostName] as [HostName], 
[hDED].[Password] as [Password], 
[hDED].[Description] as [Description], 
[hDED].[Certificate] as [Certificate], 
[hDED].[CertificateVersion] as [CertificateVersion], 
[hDED].[ConnectionString] as [ConnectionString], 
[hDED].[ServiceUrl] as [ServiceUrl]
FROM [trs_Host] as [hDED]
go

