CREATE VIEW [V_trs_DataStorage] AS SELECT 
[hDED].[DataStorageID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DataStorageTypeID] as [rf_DataStorageTypeID], 
[jT_trs_DataStorageType].[DataStorageTypeName] as [SILENT_rf_DataStorageTypeID], 
[hDED].[HostAddress] as [HostAddress], 
[hDED].[UserName] as [UserName], 
[hDED].[Password] as [Password], 
[hDED].[Directory] as [Directory]
FROM [trs_DataStorage] as [hDED]
INNER JOIN [trs_DataStorageType] as [jT_trs_DataStorageType] on [jT_trs_DataStorageType].[DataStorageTypeID] = [hDED].[rf_DataStorageTypeID]
go

