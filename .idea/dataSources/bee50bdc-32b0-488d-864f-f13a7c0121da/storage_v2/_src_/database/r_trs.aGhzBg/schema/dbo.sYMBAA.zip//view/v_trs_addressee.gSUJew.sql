CREATE VIEW [V_trs_Addressee] AS SELECT 
[hDED].[AddresseeID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_trs_Canal].[Alias] as [V_Alias], 
[hDED].[rf_HostID] as [rf_HostID], 
[jT_trs_Host].[HostName] as [SILENT_rf_HostID], 
[hDED].[rf_CanalID] as [rf_CanalID], 
[jT_trs_Canal].[CanalName] as [SILENT_rf_CanalID], 
[hDED].[rf_AddresseeTypeID] as [rf_AddresseeTypeID], 
[jT_trs_AddresseeType].[AddresseeTypeName] as [SILENT_rf_AddresseeTypeID]
FROM [trs_Addressee] as [hDED]
INNER JOIN [trs_Canal] as [jT_trs_Canal] on [jT_trs_Canal].[CanalID] = [hDED].[rf_CanalID]
INNER JOIN [trs_Host] as [jT_trs_Host] on [jT_trs_Host].[HostID] = [hDED].[rf_HostID]
INNER JOIN [trs_AddresseeType] as [jT_trs_AddresseeType] on [jT_trs_AddresseeType].[AddresseeTypeID] = [hDED].[rf_AddresseeTypeID]
go

