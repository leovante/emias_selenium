create view V_x_PackageType as
select hDED.PackageTypeID,hDED.x_Edition,hDED.x_Status  from x_PackageType as hDED
go

