CREATE VIEW [V_oms_kl_StatOpl] AS SELECT 
[hDED].[kl_StatOplID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[IDIDST] as [IDIDST], 
[hDED].[STNAME] as [STNAME], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_StatOpl] as [hDED]
go

