CREATE VIEW [V_oms_kl_VisitPlace] AS SELECT 
[hDED].[kl_VisitPlaceID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_VisitPlaceCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_VisitPlace] as [hDED]
go

