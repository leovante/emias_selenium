CREATE VIEW [V_ras_ProducedNomcType] AS SELECT 
[hDED].[ProducedNomcTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [ras_ProducedNomcType] as [hDED]
go

