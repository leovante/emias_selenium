CREATE VIEW [V_ras_Distrib] AS SELECT 
[hDED].[DistribID], [hDED].[HostDistribID], [hDED].[x_Edition], [hDED].[x_Status], 
(select FIO from x_user where UserID = rf_UserID) as [V_User], 
[hDED].[rf_OrganisationContragentID] as [rf_OrganisationContragentID], 
[hDED].[rf_OrganisationContragentIDHost] as [rf_OrganisationContragentIDHost], 
[jT_ras_Organisation].[Name] as [SILENT_rf_OrganisationContragentID], 
[hDED].[rf_OrganisationByDemandID] as [rf_OrganisationByDemandID], 
[hDED].[rf_OrganisationByDemandIDHost] as [rf_OrganisationByDemandIDHost], 
[jT_ras_Organisation1].[Name] as [SILENT_rf_OrganisationByDemandID], 
[hDED].[rf_OrganisationAgentID] as [rf_OrganisationAgentID], 
[hDED].[rf_OrganisationAgentIDHost] as [rf_OrganisationAgentIDHost], 
[jT_ras_Organisation2].[Name] as [SILENT_rf_OrganisationAgentID], 
[hDED].[rf_ResponsibleID] as [rf_ResponsibleID], 
[hDED].[rf_ResponsibleIDHost] as [rf_ResponsibleIDHost], 
[jT_ras_Responsible].[V_FIO] as [SILENT_rf_ResponsibleID], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[jT_ras_Store].[StoreName] as [SILENT_rf_StoreID], 
[hDED].[rf_PeriodID] as [rf_PeriodID], 
[hDED].[rf_PeriodIDHost] as [rf_PeriodIDHost], 
[jT_ras_Period].[Date_B] as [SILENT_rf_PeriodID], 
[hDED].[rf_DocDescriptionID] as [rf_DocDescriptionID], 
[hDED].[rf_StateDistribID] as [rf_StateDistribID], 
[jT_ras_StateDistrib].[Name] as [SILENT_rf_StateDistribID], 
[hDED].[Num] as [Num], 
[hDED].[Date] as [Date], 
[hDED].[Summa] as [Summa], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[Note] as [Note], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[DocGUID] as [DocGUID]
FROM [ras_Distrib] as [hDED]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationContragentID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationContragentIDHost]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation1] on [jT_ras_Organisation1].[OrganisationID] = [hDED].[rf_OrganisationByDemandID] AND  [jT_ras_Organisation1].[HostOrganisationID] = [hDED].[rf_OrganisationByDemandIDHost]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation2] on [jT_ras_Organisation2].[OrganisationID] = [hDED].[rf_OrganisationAgentID] AND  [jT_ras_Organisation2].[HostOrganisationID] = [hDED].[rf_OrganisationAgentIDHost]
INNER JOIN [V_ras_Responsible] as [jT_ras_Responsible] on [jT_ras_Responsible].[ResponsibleID] = [hDED].[rf_ResponsibleID] AND  [jT_ras_Responsible].[HostResponsibleID] = [hDED].[rf_ResponsibleIDHost]
INNER JOIN [ras_Store] as [jT_ras_Store] on [jT_ras_Store].[StoreID] = [hDED].[rf_StoreID] AND  [jT_ras_Store].[HostStoreID] = [hDED].[rf_StoreIDHost]
INNER JOIN [ras_Period] as [jT_ras_Period] on [jT_ras_Period].[PeriodID] = [hDED].[rf_PeriodID] AND  [jT_ras_Period].[HostPeriodID] = [hDED].[rf_PeriodIDHost]
INNER JOIN [ras_StateDistrib] as [jT_ras_StateDistrib] on [jT_ras_StateDistrib].[StateDistribID] = [hDED].[rf_StateDistribID]
go

