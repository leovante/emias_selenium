
create function [dbo].[NumTranslate](@Source decimal(18,2), @Rod int, 
	@whole1 varchar(40), @whole2 varchar(40), @whole3 varchar(40),
	@fract1 varchar(40), @fract2 varchar(40), @fract3 varchar(40))
		returns varchar(4000)
as begin
/*
	Преобразование вещественного числа в строку
	select dbo.NumTranslate(1234.37, 1, 'рубль','рубля','рублей','копейка','копейки','копеек');
	select dbo.NumTranslate(634.67, 1, 'рубль','рубля','рублей','коп.','коп.','коп.');
*/
	declare @whole bigint; 
	declare @fract int;	   
	declare @SourceStr varchar(40); 
	declare @pointPosition int; 
	declare @fractEndWord varchar(40);
	
	--Целая и дробная часть числа
	Set @SourceStr = cast(@Source as varchar(40));
	Set @pointPosition = CHARINDEX('.',@SourceStr,0);
	Set @whole = CAST(SUBSTRING(@SourceStr, 0, @pointPosition) as bigint);
	Set @fract = CAST(SUBSTRING(@SourceStr, @pointPosition+1, 2) as bigint);

	--Слово после дробной части
	if @fract % 10 = 1
		set @fractEndWord = @fract1
	else if @fract % 10 between 2 and 4
		set @fractEndWord = @fract2
		else
			set @fractEndWord = @fract3

	return dbo.SumStr(@whole,@Rod,@whole1,@whole2,@whole3) + ' ' + 
			Cast(@fract as varchar(40)) + ' ' + @fractEndWord;
end;
go

