
CREATE FUNCTION [dbo].[get_age_person](@DOB datetime,@Date datetime) 
RETURNS smallint
AS
-- * select dbo.get_age_person('1989-05-11',GetDate())

BEGIN 
RETURN (SELECT 
	CASE 
		WHEN MONTH(@DOB)>MONTH(@Date) THEN DATEDIFF(YYYY,@DOB,@Date)-1 
		WHEN MONTH(@DOB)<MONTH(@Date) THEN DATEDIFF(YYYY,@DOB,@Date) 
		WHEN MONTH(@DOB)=MONTH(@Date) THEN 
             CASE 
		WHEN DAY(@DOB)>DAY(@Date) THEN DATEDIFF(YYYY,@DOB,@Date)-1 
		ELSE DATEDIFF(YYYY,@DOB,@Date) 
	 END

    END) 
END
go

