CREATE VIEW [V_oms_VLF] AS SELECT 
[hDED].[VLFID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_VLF] as [C_VLF], 
[hDED].[NAME_VLF] as [NAME_VLF], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[GUIDVLF] as [GUIDVLF]
FROM [oms_VLF] as [hDED]
go

