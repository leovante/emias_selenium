

/*
	13.12.06
	яюыєўрхЄ юёЄрЄъш ыё эр тёхї ёъырфрї
	тючтЁр•рхЄ ЄрсышЎє (StoreID, StoredLSID, Amount) 
	єўшЄvтр  ўЄю яхЁшюф юс•шщ фы  тёхї ёъырфют..
*/

CREATE FUNCTION get_all_ls_amount(@Date datetime)
RETURNS @LS TABLE (StoreID int not NULL,
		   StoredLSID int not NULL, 	   
		   Amount decimal(18,2) not NULL)
AS
BEGIN
	Declare @RestDateTime datetime 
		
	set @RestDateTime = (select top 1 min(TransactDateTimeOperation) --p.Date_B)
	 		from ras_transactjournal tj
			inner join ras_period p on p.PeriodID = tj.rf_PeriodID 
			inner join ras_stateperiod sp on sp.StatePeriodID = p.rf_StatePeriodID
	 		where (sp.EnumName = 'open')
			--(PositionID = 0) and 
	 		--(@Date >= tj.TransactDateTimeOperation)		
			and (@Date >= p.Date_B) 	
			and (rf_PeriodID <> 0)	
		)
	if (@RestDateTime IS NULL) 
		BEGIN


			set @RestDateTime = (select top 1 min(TransactDateTimeOperation) --p.Date_B)
	 			from ras_transactjournal tj
				inner join ras_period p on p.PeriodID = tj.rf_PeriodID 
				inner join ras_stateperiod sp on sp.StatePeriodID = p.rf_StatePeriodID
	 			where (sp.EnumName = 'open')
			--(PositionID = 0) and 
	 		--(@Date >= tj.TransactDateTimeOperation)		
				and (@Date >= p.Date_B) 	
				and (rf_PeriodID <> 0)	
			)
			if (@RestDateTime IS NULL) BEGIN
				insert @LS
				select rf_StoredID as StoreID, rf_StoredLSID as StoredLSID, sum(tj.[count]) as Amount 
				from ras_transactjournal tj
				inner join ras_StoredLS sls on tj.rf_StoredLSID = sls.StoredLSID
				inner join ras_period p on tj.rf_periodID = p.PeriodID
				where  (tj.rf_StoredLSID <> 0)
				and (TransactDateTimeOperation <= @Date) 
				and tj.rf_PeriodID <> 0 
				GROUP BY rf_StoredID, rf_StoredLSID 
				HAVING (sum(tj.[count]) <> 0) 		
				RETURN	
			END
	END

	insert @LS
	select rf_StoredID as StoreID, rf_StoredLSID as StoredLSID, sum(tj.[count]) as Amount 
	from ras_transactjournal tj
	inner join ras_StoredLS sls on tj.rf_StoredLSID = sls.StoredLSID
	inner join ras_period p on tj.rf_periodID = p.PeriodID

	where  	(tj.rf_StoredLSID <> 0) 
	and (TransactDateTimeOperation BETWEEN @RestDateTime and @Date)
	and tj.rf_PeriodID <> 0 
	GROUP BY rf_StoredID, rf_StoredLSID 
	HAVING (sum(tj.[count]) <> 0) 	

	RETURN 

END

go

