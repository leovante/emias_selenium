-- =============================================
-- Author:		Кононенко Степан
-- Create date: 17.09.2010
-- Description:	процедура массовой отправки писем с результатами запроса
-- =============================================
CREATE PROCEDURE [dbo].[kf_dbmail]
	@m_subject nvarchar(255),
	@m_body varchar(max),
	@sql_acod nvarchar(max),
	@execute_query_db sysname,
	@debug bit = 1
AS
BEGIN
	SET NOCOUNT ON;
	declare @email varchar(50),	@a_cod varchar(7), @sn_lr varchar(30), @sn_lrs varchar(254),
		@sql_ nvarchar(max)

    declare c_email cursor for
		select E_MAIL, A_COD from oms_APU where E_MAIL != '' and A_COD != ''
	OPEN c_email
	FETCH NEXT FROM c_email INTO @email, @a_cod
	WHILE @@FETCH_STATUS = 0
	BEGIN
		set @sql_ = replace(@sql_acod, '@a_cod', @a_cod)
		--print @sql_
	
		EXECUTE sp_executesql @sql_
		IF @@ROWCOUNT > 0
			IF @debug = 1
				exec msdb..sp_send_dbmail
					@profile_name = 'default', 
					--@recipients = @email,
					@recipients = 'vas@karelfarm.ru', 
					--@blind_copy_recipients = 'vas@karelfarm.ru',
					@subject = @m_subject, 
					@body = @m_body,
					@importance = 'High',
					@execute_query_database = @execute_query_db,
					@query = @sql_
			ELSE
				exec msdb..sp_send_dbmail
					@profile_name = 'default', 
					@recipients = @email,
					@blind_copy_recipients = 'vas@karelfarm.ru',
					@subject = @m_subject, 
					@body = @m_body,
					@importance = 'High',
					@execute_query_database = @execute_query_db,
					@query = @sql_
		FETCH NEXT FROM c_email INTO @email, @a_cod;
	END
	CLOSE c_email
	DEALLOCATE c_email
END
go

