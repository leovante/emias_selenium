
CREATE PROCEDURE [dbo].[ChangeLsCod_NoNameless](@oldCode bigint, @newCode bigint)
AS
BEGIN
	

	if not exists (select * from oms_CollapseHistory where OldCode = @oldCode and NewCode <> @newCode)
		begin
			begin try 
				if (select COUNT(1) from sys.triggers where name like '%trItogRegDemand%') = 1
				DISABLE TRIGGER trItogRegDemand ON dm_RegDemand;
				if (select COUNT(1) from sys.triggers where name like '%TrChangeLPUDemand%') = 1
				DISABLE TRIGGER TrChangeLPUDemand ON dm_LPUDemand;
				if (select COUNT(1) from sys.triggers where name like '%tRegionCatalog%') = 1
				DISABLE TRIGGER tRegionCatalog ON dm_LSCatalog;
				if (select COUNT(1) from sys.triggers where name like '%TrChangedmUnit%') = 1
				DISABLE TRIGGER TrChangedmUnit ON dm_Unit;
				if (select COUNT(1) from sys.triggers where name like '%insert_LS_Finl%') = 1
				DISABLE TRIGGER insert_LS_Finl ON oms_LS;
				if (select COUNT(1) from sys.triggers where name like '%insert_Nameless_LS%') = 1
					DISABLE TRIGGER insert_Nameless_LS ON oms_LS;	
			end try
			begin catch 
			end catch

			BEGIN TRY 
			declare @newLsID int; --ID ЛС с положительным кодом
			select @newLsID = LSID from oms_LS where NOMK_LS = @newCode;
			declare @oldLsID int; --ID ЛС с отрицательным кодом
			select @oldLsID = LSID from oms_LS where NOMK_LS = @oldCode;

			--
			if (@newLsID is null)
			begin
				-- добавляем положительный ЛС из РЛС
				exec dbo.ImportLSFromRLS @newCode
				select @newLsID = LSID from oms_LS where NOMK_LS = @newCode;
			end
	
			if (@newLsID is not null and @oldLsID is not null)
			begin
	
				declare @ignoredTables string_list;
				insert into @ignoredTables(string_item)
				values ('oms_in_LS'), ('oms_Nameless_LS')

				exec  RefUpdateWithIgnore 'OMS', 'rf_LSID%', @ignoredTables, @oldLsID, @newLsID
		
				exec  Ref_update 'DEMAND', 'rf_LSID%', @oldLsID, @newLsID
		
			end
			END TRY
			BEGIN CATCH
				SELECT 
					ERROR_NUMBER() AS ErrorNumber,
					ERROR_MESSAGE() AS ErrorMessage;
			END CATCH

			update oms_LS
			set rf_GroupIMNID = 
					isnull((
						select top 1 rf_GroupIMNID from oms_LS where LSID = @oldLsID
					), 0)
			where LSID = @newLsID and rf_GRoupImnID = 0

			update oms_LS
			set FCode = 
				isnull((
					select top 1 FCode from oms_LS where LSID = @oldLsID
				), 0)
			where LSID = @newLsID and FCode = 0

			begin try
				;
				if (select COUNT(1) from sys.triggers where name like '%trItogRegDemand%') = 1
				ENABLE TRIGGER trItogRegDemand ON dm_RegDemand;
				if (select COUNT(1) from sys.triggers where name like '%TrChangeLPUDemand%') = 1
				ENABLE TRIGGER TrChangeLPUDemand ON dm_LPUDemand;
				if (select COUNT(1) from sys.triggers where name like '%tRegionCatalog%') = 1
				ENABLE TRIGGER tRegionCatalog ON dm_LSCatalog;
				if (select COUNT(1) from sys.triggers where name like '%TrChangedmUnit%') = 1
				ENABLE TRIGGER TrChangedmUnit ON dm_Unit;
				if (select COUNT(1) from sys.triggers where name like '%insert_LS_Finl%') = 1
				ENABLE TRIGGER insert_LS_Finl ON oms_LS;

				if (select COUNT(1) from sys.triggers where name like '%insert_Nameless_LS%') = 1
					ENABLE TRIGGER insert_Nameless_LS ON oms_LS;	
			end try
			begin catch 
			end catch

			begin try 
				if (SELECT COUNT(*) from oms_CollapseHistory where OldCode = @oldCode and NewCode = @newCode) = 0
				begin
					insert into oms_CollapseHistory(x_Edition, x_Status, OldCode, NewCode, CollapseDate, UGUID, IsSuccessCod, IsSuccessAu)
					values(1, 1, @oldCode, @newCode, GETDATE(), NEWID(), 1, 0)
				end
				else
				begin
					update oms_CollapseHistory 
					set CollapseDate = GETDATE(), IsSuccessCod = 1
					where OldCode = @oldCode and NewCode = @newCode
				end

				Update oms_LS
				set Date_E = GETDATE()
				where nomk_ls = @oldCode

			end try
			begin catch
				SELECT 
					ERROR_NUMBER() AS ErrorNumber,
					ERROR_MESSAGE() AS ErrorMessage;
			end catch

			
		end
	else
		begin
		
			declare @errorMessage varchar(max)
			set @errorMessage = 'В CollapseHistory существует правило со старым кодом: ' + cast(@oldCode as varchar(max));
			RAISERROR (@errorMessage, 18, 1);
		end
END
go

