CREATE VIEW [V_ras_StoredLS] AS SELECT 
[hDED].[StoredLSID], [hDED].[HostStoredLSID], [hDED].[x_Edition], [hDED].[x_Status], 
(((([Count] - ISNULL((SELECT     SUM(Count) AS Count FROM         dbo.ras_Reserve AS r WHERE     (rf_StoredLSID = hDED.StoredLSID and  rf_StateReserveID = 1)), 0))))) as [Delta], 
((ISNULL((Select TenderType_Name from dbo.oms_TenderType where TenderTypeID = hDED.rf_tendertypeID), ''))) as [V_TenderTypeName], 
ISNULL((SELECT top 1     SUM(Count) AS Count FROM         dbo.ras_Reserve AS r WHERE     (rf_StoredLSID = hDED.StoredLSID and  rf_StateReserveID = 1)), 0) as [Reserve], 
(dbo.ras_ConvertToFraction(((([Count] - ISNULL((SELECT SUM(Count) AS Count FROM  dbo.ras_Reserve AS r WHERE (rf_StoredLSID = hDED.StoredLSID and  rf_StateReserveID = 1)), 0)))),jT_ras_Nomenclature.Severability1*jT_ras_Nomenclature.Severability2)) as [V_FractionCount], 
(isnull((Select GroupName from ras_nomenGroup where NomenGroupID in (Select rf_NomenGroupID from ras_Nomenclature where NomenclatureID = [hDED].[rf_NomenclatureID])),0)) as [V_NomenGroup], 
[jT_ras_Nomenclature].[V_Producer] as [V_Producer], 
[jT_ras_Nomenclature].[V_Producer] as [Producer], 
[jT_ras_SubStore].[V_Name] as [V_SubStore], 
[jT_ras_Nomenclature].[Cod_Nom] as [V_Cod_Nom], 
[jT_ras_Series].[SertMSG] as [SertMSG], 
[jT_ras_Series].[NUM] as [V_Series], 
[jT_ras_Nomenclature].[Cod_RAS] as [V_Cod_RAS], 
[jT_oms_Tender].[Num] as [V_TenderNum], 
[jT_ras_LSFO].[C_LSProvider] as [V_C_LSFO], 
[jT_ras_Nomenclature].[Name] as [V_Nomenclature], 
[jT_ras_Store].[StoreName] as [V_Store], 
[jT_ras_Series].[Date_E] as [ExpDate], 
[jT_ras_Organisation].[Name] as [V_Owner], 
[jT_ras_Nomenclature].[Name] as [NameLS], 
[hDED].[rf_OrganisationOwnerID] as [rf_OrganisationOwnerID], 
[hDED].[rf_OrganisationOwnerIDHost] as [rf_OrganisationOwnerIDHost], 
[hDED].[rf_OrganisationByDemandID] as [rf_OrganisationByDemandID], 
[hDED].[rf_OrganisationByDemandIDHost] as [rf_OrganisationByDemandIDHost], 
[jT_ras_Organisation1].[Name] as [SILENT_rf_OrganisationByDemandID], 
[hDED].[rf_OrganisationContragentID] as [rf_OrganisationContragentID], 
[hDED].[rf_OrganisationContragentIDHost] as [rf_OrganisationContragentIDHost], 
[jT_ras_Organisation2].[Name] as [SILENT_rf_OrganisationContragentID], 
[hDED].[rf_StoredID] as [rf_StoredID], 
[hDED].[rf_StoredIDHost] as [rf_StoredIDHost], 
[hDED].[rf_NDSID] as [rf_NDSID], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[hDED].[rf_SeriesID] as [rf_SeriesID], 
[hDED].[rf_SeriesIDHost] as [rf_SeriesIDHost], 
[hDED].[rf_LSFOID] as [rf_LSFOID], 
[hDED].[rf_LSFOIDHost] as [rf_LSFOIDHost], 
[hDED].[rf_SubStoreID] as [rf_SubStoreID], 
[hDED].[rf_SubStoreIDHost] as [rf_SubStoreIDHost], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[hDED].[rf_DeliveryCLSDateID] as [rf_DeliveryCLSDateID], 
[hDED].[Price] as [Price], 
[hDED].[Count] as [Count], 
[hDED].[PriceOPT] as [PriceOPT], 
[hDED].[EAN13] as [EAN13], 
[hDED].[PriceBase] as [PriceBase], 
[hDED].[GTD] as [GTD], 
[hDED].[CountALL] as [CountALL], 
[hDED].[SumNDS] as [SumNDS], 
[hDED].[Summa] as [Summa], 
[hDED].[DateOUT] as [DateOUT], 
[hDED].[Note] as [Note], 
[hDED].[CostPrise] as [CostPrise], 
[hDED].[DateReg] as [DateReg], 
[hDED].[SH_Code] as [SH_Code], 
[hDED].[Consigment] as [Consigment], 
[hDED].[Data] as [Data]
FROM [ras_StoredLS] as [hDED]
INNER JOIN [V_ras_Nomenclature] as [jT_ras_Nomenclature] on [jT_ras_Nomenclature].[NomenclatureID] = [hDED].[rf_NomenclatureID] AND  [jT_ras_Nomenclature].[HostNomenclatureID] = [hDED].[rf_NomenclatureIDHost]
INNER JOIN [V_ras_SubStore] as [jT_ras_SubStore] on [jT_ras_SubStore].[SubStoreID] = [hDED].[rf_SubStoreID] AND  [jT_ras_SubStore].[HostSubStoreID] = [hDED].[rf_SubStoreIDHost]
INNER JOIN [ras_Series] as [jT_ras_Series] on [jT_ras_Series].[SeriesID] = [hDED].[rf_SeriesID] AND  [jT_ras_Series].[HostSeriesID] = [hDED].[rf_SeriesIDHost]
INNER JOIN [oms_Tender] as [jT_oms_Tender] on [jT_oms_Tender].[TenderID] = [hDED].[rf_TenderID]
INNER JOIN [ras_LSFO] as [jT_ras_LSFO] on [jT_ras_LSFO].[LSFOID] = [hDED].[rf_LSFOID] AND  [jT_ras_LSFO].[HostLSFOID] = [hDED].[rf_LSFOIDHost]
INNER JOIN [ras_Store] as [jT_ras_Store] on [jT_ras_Store].[StoreID] = [hDED].[rf_StoredID] AND  [jT_ras_Store].[HostStoreID] = [hDED].[rf_StoredIDHost]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationOwnerID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationOwnerIDHost]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation1] on [jT_ras_Organisation1].[OrganisationID] = [hDED].[rf_OrganisationByDemandID] AND  [jT_ras_Organisation1].[HostOrganisationID] = [hDED].[rf_OrganisationByDemandIDHost]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation2] on [jT_ras_Organisation2].[OrganisationID] = [hDED].[rf_OrganisationContragentID] AND  [jT_ras_Organisation2].[HostOrganisationID] = [hDED].[rf_OrganisationContragentIDHost]
go

