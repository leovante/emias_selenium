CREATE VIEW [V_ras_DemandRecipe] AS SELECT 
[hDED].[DemandRecipeID], [hDED].[HostDemandRecipeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DemandID] as [rf_DemandID], 
[hDED].[rf_DemandIDHost] as [rf_DemandIDHost], 
[jT_ras_Demand].[Num] as [SILENT_rf_DemandID], 
[hDED].[rf_DPCPharmacyRecipeID] as [rf_DPCPharmacyRecipeID], 
[jT_oms_DPCPharmacyRecipe].[SeriesNum_Recipe] as [SILENT_rf_DPCPharmacyRecipeID]
FROM [ras_DemandRecipe] as [hDED]
INNER JOIN [ras_Demand] as [jT_ras_Demand] on [jT_ras_Demand].[DemandID] = [hDED].[rf_DemandID] AND  [jT_ras_Demand].[HostDemandID] = [hDED].[rf_DemandIDHost]
INNER JOIN [V_oms_DPCPharmacyRecipe] as [jT_oms_DPCPharmacyRecipe] on [jT_oms_DPCPharmacyRecipe].[DPCPharmacyRecipeID] = [hDED].[rf_DPCPharmacyRecipeID]
go

