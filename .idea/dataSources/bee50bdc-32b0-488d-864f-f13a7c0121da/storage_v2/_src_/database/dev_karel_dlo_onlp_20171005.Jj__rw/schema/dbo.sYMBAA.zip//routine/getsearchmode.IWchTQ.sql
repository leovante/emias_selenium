create function GetSearchMode()
returns int
as
begin
	declare @strtype varchar(20)
	declare @inttype int
	set @inttype = 0

	set @strtype = (select ValueStr from x_UserSettings
	where
		[Property] = 'Поиск номенклатуры' and
		[OwnerGUID] =  '{00000000-0000-0000-0000-000000000000}' and
		[DocTypeDefGUID] = '{00000000-0000-0000-0000-000000000000}' and
		[rf_SettingTypeID] = 7)

	if(@strtype like 'c_lsfo')
		set @inttype = 1

	return @inttype
end
go

