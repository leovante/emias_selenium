
/****** Object:  StoredProcedure [dbo].[ras_AnalisisDBtmp]    Script Date: 11/25/2008 15:44:22 ******/
CREATE Procedure [dbo].[ras_AnalisisDB_orig]
 as 
begin
select * from (--Проверяет нессответствие кодов и огрн в ras_Organisation и oms_SFO
select count(1) as 'Count',
'Найдены ЛС, где владелец товара не соответствует контракту.' as 'message' 
from ras_StoredLS as SLS 
inner join ras_LSFO as LSFO on SLS.rf_LSFOID=LSFO.LSFOID and SLS.rf_LSFOIDHost=LSFO.HostLSFOID 
inner join ras_Nomenclature as RN on RN.NomenclatureID=LSFO.rf_NomenclatureID
       and RN.HostNomenclatureID=LSFO.rf_NomenclatureIDHost
inner join oms_CLS as OCLS on RN.rf_CLS=OCLS.CLSID
inner join oms_Tender as OT on OCLS.rf_TenderID=OT.TenderID
inner join oms_SFO as OSFO on OT.rf_SFOID=OSFO.SFOID 
inner join ras_Organisation Org on SLS.rf_OrganisationOwnerID=org.OrganisationID and 
       SLS.rf_OrganisationOwnerIDHost=org.HostOrganisationID
where 
SLS.StoredLSID>0
and 
(
org.OGRN !=osfo.FO_OGRN or ltrim(rtrim(org.code)) !=ltrim(rtrim(osfo.CFO))
)
 union all --проверка соответствия C_PFS в ras_Nomenclature и oms_CLS
select count(1) as 'Count'
,'Код ЦПФС в номенклатуре не соответствует ссылке' as 'message' 
from (ras_Nomenclature as rn inner join oms_CLS as oc on rn.rf_CLS=oc.CLSID) 
where rn.C_PFS<> oc.C_PFS  union all --проверка уникальности полей LSFOID и C_LSProvider
select isnull(sum(count),0) as Count,
'дублирование строк в таблице ras_LSFO' as 'message' from
(select count(1) as Count from ras_LSFO
where rf_providerID>0
group by LSFOID,C_LSProvider
having count(1)>1) t
 union all --проверяет уникальность полей C_LSProvider,C_PFS в пределах одного поставщика
select isnull(sum(count),0) as Count,
'поля C_LSProvider,C_PFS в пределах одного поставщика не уникальны' as 'message' from
(select distinct count(1) as 'Count'
from ras_LSFO where LSFOID>0
group by rf_providerID,C_LSProvider,C_PFS
having count(1)>1) t union all select count(1) as 'Count',
'Есть ЛС у которых не согласованы код поставщика и номенклатура' as 'message'
from (ras_storedLS as sLS inner join ras_LSFO as LSFO 
on sLS.rf_LSFOID=LSFO.LSFOID) 
where sLS.storedLSID<>0 and LSFO.LSFOID<>0 
and sLS.rf_NomenclatureID<>LSFO.rf_NomenclatureID  union all --определяет наличие неизвестных поставщиков и битых ссылок в таблице ras_LSFO
select count(1) as 'Count',
'В таблице ras_LSFO есть неизвестные поставщики' as 'message' 
from ras_LSFO where (LSFOID>0 and rf_ProviderID=0)
union all 
select count(1) as 'Count',
'Битые ссылки в таблице ras_LSFO' as 'message'
from ras_LSFO where (LSFOID>0 and rf_ProviderID=null) union all --проверка соответствия C_PFS в ras_Nomenclature и ras_LSFO
select count(1) as 'Count'
,'Код ЦПФС в ras_LSFO не соответствует ссылке' as 'message' 
from (ras_Nomenclature as rn inner join ras_LSFO as rl 
on rn.NomenclatureID=rl.rf_NomenclatureID) 
where rn.C_PFS<> rl.C_PFS  union all --Проверяет есть ли в сериях дубли по полям
--rf_nomenclatureID,rf_NomenclatureIDHost,Num
--а также открыта ли дата окончания срока действия 
select isnull(sum(count),0) as Count,
'Дубли в сериях' as message from 
(
select  count(1) as Count from ras_series
where SeriesID>0 and date_E > getdate() 
group by rf_nomenclatureID,rf_NomenclatureIDHost,Num
having count(1)>1
) t 
union all select count(1) as 'Count','Найдены фантомные записи(нарушена целостность ссылок) в журнале 
операций' as 'message' from
(  
 select TransactJournalID , 'Приходная накладная' DocName from ras_TransactJournal tj
	left join ras_PositionBill T on tj.PositionID =T.PositionBillID and tj.PositionIDhost =T.HostPositionBillID
	where tj.TransactJournalID>0 and
		 (tj.rf_docDescriptionID=2 and t.PositionBillID is Null)
		
union all
   select TransactJournalID , 'Электронная расходная накладная' DocName from ras_TransactJournal tj
	left join ras_PositionBillEx_Other T on tj.PositionID =T.PositionBillEx_OtherID and tj.PositionIDhost =T.HostPositionBillEx_OtherID
	where tj.TransactJournalID>0 and
		 (tj.rf_docDescriptionID=3 and t.PositionBillEx_OtherID is Null)
		
union all
   select TransactJournalID , 'Расходная накладная' DocName from ras_TransactJournal tj
	left join ras_PositionBillEx T on tj.PositionID =T.PositionBillExID and tj.PositionIDhost =T.HostPositionBillExID
	where tj.TransactJournalID>0 and
		 (tj.rf_docDescriptionID=4 and t.PositionBillExID is Null)
		
union all
   select TransactJournalID , 'Документ - Перемещение' DocName from ras_TransactJournal tj
	left join ras_PositionBillShift T on tj.PositionID =T.PositionBillShiftID and tj.PositionIDhost =T.HostPositionBillShiftID
	where tj.TransactJournalID>0 and
		 (tj.rf_docDescriptionID=5 and t.PositionBillShiftID is Null)
		
union all
   select TransactJournalID , 'Документ - Списание' DocName from ras_TransactJournal tj
	left join ras_PositionWriteOffArticle T on tj.PositionID =T.PositionWriteOffArticleID and tj.PositionIDhost =T.HostPositionWriteOffArticleID
	where tj.TransactJournalID>0 and
		 (tj.rf_docDescriptionID=6 and t.PositionWriteOffArticleID is Null)
		
union all
   select TransactJournalID , 'Документ - Оприходование' DocName from ras_TransactJournal tj
	left join ras_PositionPosting T on tj.PositionID =T.PositionPostingID and tj.PositionIDhost =T.HostPositionPostingID
	where tj.TransactJournalID>0 and
		 (tj.rf_docDescriptionID=7 and t.PositionPostingID is Null)
		
union all
   select TransactJournalID , 'Документ - Инвентаризация' DocName from ras_TransactJournal tj
	left join ras_PositionInventarisation T on tj.PositionID =T.PositionInventarisationID and tj.PositionIDhost =T.HostPositionInventarisationID
	where tj.TransactJournalID>0 and
		 (tj.rf_docDescriptionID=8 and t.PositionInventarisationID is Null)
		
union all
   select TransactJournalID , 'Отчет комиссионера' DocName from ras_TransactJournal tj
	left join ras_PositionReport T on tj.PositionID =T.PositionReportID and tj.PositionIDhost =T.HostPositionReportID
	where tj.TransactJournalID>0 and
		 (tj.rf_docDescriptionID=9 and t.PositionReportID is Null)
		
union all
   select TransactJournalID , 'Возврат поставщику' DocName from ras_TransactJournal tj
	left join ras_PositionBillReturnPr T on tj.PositionID =T.PositionBillReturnPrID and tj.PositionIDhost =T.HostPositionBillReturnPrID
	where tj.TransactJournalID>0 and
		 (tj.rf_docDescriptionID=10 and t.PositionBillReturnPrID is Null)
		
union all
   select TransactJournalID , 'Возврат от клиента' DocName from ras_TransactJournal tj
	left join ras_PositionBillReturnCl T on tj.PositionID =T.PositionBillReturnClID and tj.PositionIDhost =T.HostPositionBillReturnClID
	where tj.TransactJournalID>0 and
		 (tj.rf_docDescriptionID=11 and t.PositionBillReturnClID is Null)
		
union all
   select TransactJournalID , 'Переоценка товара' DocName from ras_TransactJournal tj
	left join ras_PositionBillRevaluation T on tj.PositionID =T.PositionBillRevaluationID and tj.PositionIDhost =T.HostPositionBillRevaluationID
	where tj.TransactJournalID>0 and
		 (tj.rf_docDescriptionID=12 and t.PositionBillRevaluationID is Null)
		
union all
   select TransactJournalID , 'Отчет комитенту' DocName from ras_TransactJournal tj
	left join ras_PositionRTC T on tj.PositionID =T.PositionRTCID and tj.PositionIDhost =T.HostPositionRTCID
	where tj.TransactJournalID>0 and tj.Count <> 0 and 
		 (tj.rf_docDescriptionID=13 and t.PositionRTCID is Null)
		
		
union all
   select TransactJournalID , 'Заказ клиента' DocName from ras_TransactJournal tj
	left join ras_PositionOrgOrder  T on tj.PositionID =T.PositionOrgOrderID and tj.PositionIDhost =T.HostPositionOrgOrderID
	where tj.TransactJournalID>0 and
		 (tj.rf_docDescriptionID=15 and t.PositionOrgOrderID is Null)
) t) as r
end
go

