CREATE VIEW [V_ras_StateBillRetProv] AS SELECT 
[hDED].[StateBillRetProvID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Action] as [Action], 
[hDED].[Note] as [Note]
FROM [ras_StateBillRetProv] as [hDED]
go

