CREATE VIEW [V_ras_StateExpertPositionReport] AS SELECT 
[hDED].[StateExpertPositionReportID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note]
FROM [ras_StateExpertPositionReport] as [hDED]
go

