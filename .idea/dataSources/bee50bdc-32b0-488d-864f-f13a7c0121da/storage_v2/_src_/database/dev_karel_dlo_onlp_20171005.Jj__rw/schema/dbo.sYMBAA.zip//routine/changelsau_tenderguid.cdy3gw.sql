
CREATE PROCEDURE [dbo].[ChangeLsAu_TenderGuid](@oldNomkLsCode bigint, @newNomkLsCode bigint, @tenderGuid uniqueidentifier)
AS
BEGIN

	declare @oldLsID int; --ID ЛС с положительным кодом
	select @oldLsID = LSID from oms_LS where NOMK_LS = @oldNomkLsCode;
	declare @minusLsID int; --ID ЛС с отрицательным кодом
	select @minusLsID = LSID from oms_LS where NOMK_LS = @newNomkLsCode;

	if (@oldLsID is not null and @minusLsID is not null)
	begin		
		declare @clsId int;

		--перебираем все цены, которые были задеты схлопыванием
		declare _clsCur cursor for
		select distinct CLSID from oms_CLS cls
		join oms_tender on rf_TenderID = TenderID 
		where rf_LSID in (@oldLsID, @minusLsID) and oms_Tender.GUID = @tenderGuid

		open _clsCur
		fetch next from _clsCur into @clsId
		while (@@fetch_status <> -1)
		begin
			exec [dbo].[ChangeLsAu_Cls] @oldLsID, @oldNomkLsCode, @minusLsID , @newNomkLsCode ,  @clsId  

			fetch next from _clsCur into @clsId
		end
		close _clsCur
		deallocate _clsCur


		declare @oldNomenId int;
		declare @newNomenId int;

			--получаем ID новой номенклатуры
		set @oldNomenId = (select top 1 NomenclatureID from ras_Nomenclature where rf_LSID = @oldLsID and Cod_RAS = convert(varchar(max), @oldNomkLsCode));

			--получаем ID старой номенклатуры
		set @newNomenId = (select NomenclatureID from ras_Nomenclature
									where rf_LSID = @minusLsID and COD_RAS = convert(varchar(max), @newNomkLsCode))


		update ras_PositionBillRequest
		set rf_NomenclatureID = @newNomenId
		where PositionBillRequestID > 0 and PositionBillRequestID in
		(
			select isnull(PositionBillRequestID, 0) from Life_ras_PositionBillRequest
			where rf_NomenclatureID in (@oldNomenId, @newNomenId)
			group by PositionBillRequestID, rf_NomenclatureID
			having count(distinct rf_NomenclatureID) = 2
		)

		update ras_ProducedNomenclature
		set rf_NomenclatureID = @newNomenId
		where ProducedNomenclatureID > 0 and ProducedNomenclatureID in
		(
			select isnull(ProducedNomenclatureID, 0) from Life_ras_ProducedNomenclature
			where rf_NomenclatureID in (@oldNomenId, @newNomenId)
			group by ProducedNomenclatureID, rf_NomenclatureID
			having count(distinct rf_NomenclatureID) = 2
		)

		update ras_Nomenclature
		set Date_E = '2200-01-01T00:00:00.000'
		where rf_LSID = @minusLsID
	end
END


go

