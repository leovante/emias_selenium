CREATE VIEW [V_ras_PositionBillReturnCL] AS SELECT 
[hDED].[PositionBillReturnCLID], [hDED].[HostPositionBillReturnCLID], [hDED].[x_Edition], [hDED].[x_Status], 
(ISNULL((SELECT top 1  TenderType_Name 
FROM oms_TenderType 
join ras_StoredLS on rf_TenderTypeID = TenderTypeID and hDed.rf_StoredLSID = ras_StoredLS.StoredLSID 
			  and hDed.rf_StoredLSIDHost = ras_StoredLS.HostStoredLSID),'')) as [V_TenderTypeName], 
(dbo.ras_ConvertToFraction(hDED.Count,(select top 1 Severability1 * Severability2  from ras_Nomenclature nom where jT_ras_StoredLS.rf_NomenclatureID = nom.NomenclatureID and jT_ras_StoredLS.rf_NomenclatureIDHost = nom.HostNomenclatureID))) as [V_FractionCount], 
[jT_ras_StoredLS].[V_TenderNum] as [V_TenderNum], 
[jT_ras_StoredLS].[V_Series] as [V_Series], 
[jT_ras_StoredLS].[V_Owner] as [V_Owner], 
[jT_ras_StoredLS].[V_C_LSFO] as [V_C_LSFO], 
[jT_ras_StoredLS].[V_Nomenclature] as [V_Nomenclature], 
[jT_ras_StoredLS].[V_Nomenclature] as [V_StoredLS], 
[jT_ras_StoredLS].[Consigment] as [V_Consigment], 
[jT_ras_Series].[SertMSG] as [SertMSG], 
[hDED].[rf_NDSID] as [rf_NDSID], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[hDED].[rf_SeriesID] as [rf_SeriesID], 
[hDED].[rf_SeriesIDHost] as [rf_SeriesIDHost], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_LSFOID] as [rf_LSFOID], 
[hDED].[rf_LSFOIDHost] as [rf_LSFOIDHost], 
[hDED].[rf_SubStoreID] as [rf_SubStoreID], 
[hDED].[rf_SubStoreIDHost] as [rf_SubStoreIDHost], 
[hDED].[rf_BillReturnClientID] as [rf_BillReturnClientID], 
[hDED].[rf_BillReturnClientIDHost] as [rf_BillReturnClientIDHost], 
[hDED].[rf_StatePositionBillReturnCLID] as [rf_StatePositionBillReturnCLID], 
[hDED].[rf_PositionStatusID] as [rf_PositionStatusID], 
[hDED].[Producer] as [Producer], 
[hDED].[Consigment] as [Consigment], 
[hDED].[Price] as [Price], 
[hDED].[ExpDate] as [ExpDate], 
[hDED].[Count] as [Count], 
[hDED].[PriceBase] as [PriceBase], 
[hDED].[Summa] as [Summa], 
[hDED].[SumNDS] as [SumNDS], 
[hDED].[PriceOPT] as [PriceOPT], 
[hDED].[isSert] as [isSert], 
[hDED].[DateReg] as [DateReg], 
[hDED].[SH_Code] as [SH_Code], 
[hDED].[EAN13] as [EAN13], 
[hDED].[NameLS] as [NameLS], 
[hDED].[Note] as [Note], 
[hDED].[GTD] as [GTD]
FROM [ras_PositionBillReturnCL] as [hDED]
INNER JOIN [V_ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
INNER JOIN [ras_Series] as [jT_ras_Series] on [jT_ras_Series].[SeriesID] = [hDED].[rf_SeriesID] AND  [jT_ras_Series].[HostSeriesID] = [hDED].[rf_SeriesIDHost]
go

