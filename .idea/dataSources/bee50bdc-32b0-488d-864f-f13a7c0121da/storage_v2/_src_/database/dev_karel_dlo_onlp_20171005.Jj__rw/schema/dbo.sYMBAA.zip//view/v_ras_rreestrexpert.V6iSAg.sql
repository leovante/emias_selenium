CREATE VIEW [V_ras_RReestrExpert] AS SELECT 
[hDED].[RReestrExpertID], [hDED].[x_Edition], [hDED].[x_Status], 
IsNull((select top 1 GeneralLogin from x_User where x_User.UserID=hDED.rf_UserID),'') as [UserLogin], 
[jT_oms_ExpertType].[Name] as [V_NAME], 
[hDED].[rf_ExpertTypeID] as [rf_ExpertTypeID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[rf_RReestrID] as [rf_RReestrID], 
[hDED].[Date] as [Date], 
[hDED].[BadCount] as [BadCount], 
[hDED].[BadSum] as [BadSum], 
[hDED].[rf_UserID] as [rf_UserID]
FROM [ras_RReestrExpert] as [hDED]
INNER JOIN [oms_ExpertType] as [jT_oms_ExpertType] on [jT_oms_ExpertType].[ExpertTypeID] = [hDED].[rf_ExpertTypeID]
go

