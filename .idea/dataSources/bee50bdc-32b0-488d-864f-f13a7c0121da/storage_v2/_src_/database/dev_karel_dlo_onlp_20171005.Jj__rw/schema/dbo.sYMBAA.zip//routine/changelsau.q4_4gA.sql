
CREATE PROCEDURE [dbo].[ChangeLsAu](@oldNomkLsCode bigint, @newNomkLsCode bigint)
AS
BEGIN

	declare @oldLsID int; --ID ЛС с положительным кодом
	select @oldLsID = LSID from oms_LS where NOMK_LS = @oldNomkLsCode;
	declare @newLsID int; --ID ЛС с отрицательным кодом
	select @newLsID = LSID from oms_LS where NOMK_LS = @newNomkLsCode;

	if (@oldLsID is not null and @newLsID is not null)
	begin		
		

		if not exists (select * from oms_CollapseHistory where OldCode = @oldNomkLsCode and NewCode <> @newNomkLsCode)
			begin
			
				
				declare @clsId int;

				--перебираем все цены 
				declare _clsCur cursor for
						select CLSID from oms_CLS cls
						where rf_LSID in (@oldLsID, @newLsID)
						group by CLSID			
			
				open _clsCur
				fetch next from _clsCur into @clsId
				while (@@fetch_status <> -1)
				begin
					print 'oldNomkls= ' + cast(@oldNomkLsCode as varchar(max))+ ' , newNomkLS =  ' + cast(@newNomkLsCode as varchar(max))+ ' , ClsID = ' + cast(@clsId as varchar(max))

					exec [dbo].[ChangeLsAu_Cls] @oldLsID, @oldNomkLsCode, @newLsID , @newNomkLsCode ,  @clsId  

					fetch next from _clsCur into @clsId
				end
				close _clsCur
				deallocate _clsCur


				declare @oldNomenId int;
				declare @newNomenId int;

					--получаем ID старой номенклатуры
				set @oldNomenId = (select top 1 NomenclatureID from ras_Nomenclature where rf_LSID = @oldLsID and Cod_RAS = convert(varchar(max), @oldNomkLsCode));

					--получаем ID новой номенклатуры
				set @newNomenId = (select NomenclatureID from ras_Nomenclature
											where rf_LSID = @newLsID and COD_RAS = convert(varchar(max), @newNomkLsCode))


				update ras_PositionBillRequest
				set rf_NomenclatureID = @newNomenId
				where PositionBillRequestID > 0 and rf_NomenclatureID = @oldNomenId

				update ras_ProducedNomenclature
				set rf_NomenclatureID = @newNomenId
				where ProducedNomenclatureID > 0 and rf_NomenclatureID = @oldNomenId

				update ras_Nomenclature
				set Date_E = '2200-01-01T00:00:00.000'
				where rf_LSID = @newLsID


				if (SELECT COUNT(*) from oms_CollapseHistory where OldCode = @oldNomkLsCode and NewCode = @newNomkLsCode) = 0
					begin
						insert into oms_CollapseHistory(x_Edition, x_Status, OldCode, NewCode, CollapseDate, UGUID, IsSuccessCod, IsSuccessAu)
						values(1, 1, @oldNomkLsCode, @newNomkLsCode, GETDATE(), NEWID(), 0, 1)
					end
					else
					begin
						update oms_CollapseHistory 
						set CollapseDate = GETDATE(), IsSuccessAu = 1
						where OldCode = @oldNomkLsCode and NewCode = @newNomkLsCode
					end

				
			end
		else
			begin
				
				declare @errorMessage varchar(max)
				set @errorMessage = 'В CollapseHistory существует правило со старым кодом: ' + cast(@oldNomkLsCode as varchar(max));
				RAISERROR (@errorMessage, 18, 1);
			end
	end
END


go

