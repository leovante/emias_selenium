CREATE VIEW [V_ras_RecipeSeries] AS SELECT 
[hDED].[RecipeSeriesID], [hDED].[HostRecipeSeriesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_OGRN] as [C_OGRN], 
[hDED].[MCOD] as [MCOD], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E], 
[hDED].[SERIES_B] as [SERIES_B], 
[hDED].[SERIES_E] as [SERIES_E], 
[hDED].[NUM_B] as [NUM_B], 
[hDED].[NUM_E] as [NUM_E]
FROM [ras_RecipeSeries] as [hDED]
go

