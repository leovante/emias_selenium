
CREATE TRIGGER KlAdrChanged
   ON  kla_KlAdr
   AFTER INSERT,UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	update kla_KlAdr
		set rf_parentID=t.kk
	from (select k2.KlAdrID as kk,k1.KlAdrID from inserted k1 
		  inner join kla_KlAdr k2 on SUBSTRING(k1.CODE,1,8)=SUBSTRING(k2.CODE,1,8)
		  where k1.LEVEL>3  and k2.LEVEL<4 and k1.rf_parentid=0)t
	where kla_KlAdr.KlAdrID=t.KlAdrID and kla_KlAdr.rf_parentID=0
	
	
	update kla_KlAdr
		set rf_parentID=t.kk
	from (select k2.KlAdrID as kk,k1.KlAdrID from inserted k1 
		  inner join kla_KlAdr k2 on SUBSTRING(k1.CODE,1,8)=SUBSTRING(k2.CODE,1,8)
		  where k1.LEVEL>2  and k2.LEVEL<3 and k1.rf_parentid=0)t
	where kla_KlAdr.KlAdrID=t.KlAdrID and kla_KlAdr.rf_parentID=0
	
	update kla_KlAdr
		set rf_parentID=t.kk
	from (select k2.KlAdrID as kk,k1.KlAdrID from inserted k1 
		  inner join kla_KlAdr k2 on SUBSTRING(k1.CODE,1,5)=SUBSTRING(k2.CODE,1,5)
		  where k1.LEVEL>2  and k2.LEVEL<3 and k1.rf_parentid=0)t
	where kla_KlAdr.KlAdrID=t.KlAdrID and kla_KlAdr.rf_parentID=0
	
	update kla_KlAdr
		set rf_parentID=t.kk
	from (select k2.KlAdrID as kk,k1.KlAdrID from inserted k1 
		  inner join kla_KlAdr k2 on SUBSTRING(k1.CODE,1,2)=SUBSTRING(k2.CODE,1,2)
		  where k1.LEVEL>1  and k2.LEVEL<2 and k1.rf_parentid=0)t
	where kla_KlAdr.KlAdrID=t.KlAdrID and kla_KlAdr.rf_parentID=0
	
END
go

