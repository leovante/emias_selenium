CREATE VIEW [V_oms_SMReestrDateState] AS SELECT 
[hDED].[SMReestrDateStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrID] as [rf_SMReestrID], 
[jT_oms_SMReestr].[V_SMReestr] as [SILENT_rf_SMReestrID], 
[hDED].[rf_SMReestrStateID] as [rf_SMReestrStateID], 
[jT_oms_SMReestrState].[Name] as [SILENT_rf_SMReestrStateID], 
[hDED].[rf_MTReestrID] as [rf_MTReestrID], 
[hDED].[Date] as [Date], 
[hDED].[Rem] as [Rem]
FROM [oms_SMReestrDateState] as [hDED]
INNER JOIN [V_oms_SMReestr] as [jT_oms_SMReestr] on [jT_oms_SMReestr].[SMReestrID] = [hDED].[rf_SMReestrID]
INNER JOIN [oms_SMReestrState] as [jT_oms_SMReestrState] on [jT_oms_SMReestrState].[SMReestrStateID] = [hDED].[rf_SMReestrStateID]
go

