CREATE VIEW [V_oms_sc_PrescribleLS] AS SELECT 
[hDED].[sc_PrescribleLSID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_MNName].[NAME_MNN] as [V_NAME_MNN], 
[hDED].[rf_MNNameID] as [rf_MNNameID], 
[jT_oms_MNName].[NAME_MNN] as [SILENT_rf_MNNameID], 
[hDED].[rf_LFID] as [rf_LFID], 
[jT_oms_LF].[C_LF] as [SILENT_rf_LFID], 
[hDED].[rf_DLSID] as [rf_DLSID], 
[jT_oms_DLS].[C_DLS] as [SILENT_rf_DLSID], 
[hDED].[rf_FARGID] as [rf_FARGID], 
[jT_oms_FARG].[FNAME_FRG] as [SILENT_rf_FARGID], 
[hDED].[rf_sc_StandartCureID] as [rf_sc_StandartCureID], 
[hDED].[Frequency] as [Frequency], 
[hDED].[ODD] as [ODD], 
[hDED].[EKD] as [EKD], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_sc_PrescribleLS] as [hDED]
INNER JOIN [oms_MNName] as [jT_oms_MNName] on [jT_oms_MNName].[MNNameID] = [hDED].[rf_MNNameID]
INNER JOIN [oms_LF] as [jT_oms_LF] on [jT_oms_LF].[LFID] = [hDED].[rf_LFID]
INNER JOIN [oms_DLS] as [jT_oms_DLS] on [jT_oms_DLS].[DLSID] = [hDED].[rf_DLSID]
INNER JOIN [oms_FARG] as [jT_oms_FARG] on [jT_oms_FARG].[FARGID] = [hDED].[rf_FARGID]
go

