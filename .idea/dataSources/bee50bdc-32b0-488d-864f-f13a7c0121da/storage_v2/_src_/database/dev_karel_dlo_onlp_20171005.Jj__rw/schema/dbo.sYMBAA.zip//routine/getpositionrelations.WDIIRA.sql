

-- ===================================================
-- Author:          <Неизвестен>
-- Create date:		<Неизвестна>
-- Description:     Функция поиска зависимых позиций
-- Last update:		14:17, 30.10.2009, Максименко Ал.
-- ===================================================
CREATE FUNCTION [dbo].[getPositionRelations](@_PositionID int,@_PositionIDHost int,@_DocDescriptionID int, @_StoredLSID int, @_StoredLSIDHost int)
RETURNS @retPositions TABLE
(
 TransactJournalID int NOT NULL,
 PositionID int NOT NULL,
 positionidhost int not null, 
 rf_DocDescriptionID int NOT NULL,
 rf_StoredLSID int NOT NULL,
 rf_storedlsidhost int not null 
)
AS
BEGIN

declare @tjid int
declare @posid int
declare @posidhost int
declare @docdid int
declare @slsid int
declare @slsidhost int
  
insert @retPositions --инсертим первую порцию сторедлсов
select TransactJournalID,PositionID,PositionIDHost,rf_DocDescriptionID,rf_StoredLSID,rf_StoredLSIDHost from PositionRelations(@_PositionID,@_DocDescriptionID, @_StoredLSID,@_Positionidhost,@_Storedlsidhost)where TransactJournalid not in (select TransactJournalID from @retPositions)

 DECLARE curPositionCursor CURSOR DYNAMIC  for 
 select  TransactJournalID,PositionID,PositionIDHost,rf_DocDescriptionID,rf_StoredLSID,rf_StoredLSIDHost from @retPositions
 open curPositionCursor

--проходим по всем сторедлсам которые уже есть и для каждого вызываем поиск зависимых позиций
fetch  next from curPositionCursor into @tjid,@posid,@posidhost,@docdid,@slsid,@slsidhost
 while @@fetch_status = 0
 begin
  insert @retPositions
  select TransactJournalID,PositionID,PositionIDHost,rf_DocDescriptionID,rf_StoredLSID,rf_StoredLSIDHost from PositionRelations(@posid,@docdid, @slsid,@posidhost,@slsidhost)where TransactJournalid not in (select TransactJournalID from @retPositions)
  fetch next from curPositionCursor into @tjid,@posid,@posidhost,@docdid,@slsid,@slsidhost
 end
deallocate curPositionCursor
RETURN
END
go

