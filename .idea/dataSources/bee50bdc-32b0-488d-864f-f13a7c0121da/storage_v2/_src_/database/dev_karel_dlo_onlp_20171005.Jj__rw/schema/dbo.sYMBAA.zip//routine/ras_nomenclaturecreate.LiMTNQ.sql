
CREATE PROCEDURE [dbo].[ras_NomenclatureCreate] AS
BEGIN
if exists(select * from sysobjects where [name] = 'tmp_err') drop table tmp_err

Declare @n_tab varchar(100);
Declare @sql varchar(max),@sql2 varchar(max);

begin try
				----------------------------
				--Добавление номенклатуры по ключевому полю C_PFS	
				SET @n_tab='ras_Nomenclature';		

				INSERT INTO [ras_Nomenclature]
							([Name]
							,[rf_NDSID]
							,[Cod_RAS]
							,[Cod_Nom]			
							,[rf_ProducerID]
							,[rf_NarcLSTypeID]
							,[rf_LFID]
							,[rf_DLSID],
							 rf_LSID, 
							 rf_MLFID, 
							 M_LF,
							 rf_VLFID, 
							 V_LF
							,[MSG_TEXT]
							,[Date_B]
							,[Date_E]
							,[rf_SpecificID]
							,[DOZ_ME]
							,[Severability1]
							,[Severability2]
							,[EAN13])

Select  distinct 
                           case when (select count(NomenID) from rls_nomen where NomenID > 0 ) > 0 then
					
							ltrim(rtrim(oms_LS.NAME_MED)) 
							else LTRIM(rtrim(
												
								Replace(Replace(Replace(Replace(Replace(Replace(Replace(
								ltrim(rtrim(
								case 
								when charindex('№'+cast(N_FV as varchar),Name_Med)>0 and N_FV <>0 then
									case when len(left(Name_Med,charindex('№',Name_Med)))-len(Replace(left(Name_Med,charindex('№',Name_Med)),',',''))>=3
									then
									substring(Name_Med,charindex(',',Name_Med)+1,
										case when charindex(',',Name_Med,charindex('№'+cast(N_FV as varchar),Name_Med))=0 then len(Name_Med) else
											case when charindex('№'+cast(N_FV as varchar),Name_Med) = 0
											then charindex(',',Name_Med,charindex('№'+cast(N_FV as varchar),Name_Med)) 
											else charindex(',',Name_Med,charindex('№'+cast(N_FV as varchar),Name_Med))-1
											end									
										end 
									-charindex(',',Name_Med))
									else
									substring(Name_Med,1,
										case when charindex(',',Name_Med,charindex('№'+cast(N_FV as varchar),Name_Med))=0 then len(Name_Med) else
										charindex(',',Name_Med,charindex('№'+cast(N_FV as varchar),Name_Med))-1 end)
									end
								else 
									case when len(Name_Med)-len(Replace(Name_Med,',','')) > 3
									then
									substring(Name_Med,charindex(',',Name_Med)+1,
										len(Name_Med)-charindex(',',reverse(Name_Med),charindex(reverse(left(Name_FCT,6)),reverse(Name_Med)))-charindex(',',Name_Med))
									else 
									Replace(substring(Name_Med,1,
										Case when charindex(left(Name_FCT,6),Name_Med)=0 or charindex('-'+left(Name_FCT,6),Name_Med)>0 then len(Name_Med) else 
										len(Name_Med)-charindex(',',reverse(Name_Med),charindex(reverse(left(Name_FCT,6)),reverse(Name_Med))) end),Name_MNN+',','')
									end
								end
								)),'приготовления','пригот.'),'раствор','р-р'),'внутри','в/'),'пролонгированного','пролонг.'),
								'таблетки покрытые кишечно','т. п-ые кишечно'),'суспензии','сусп.'),'лекарственных','лек.') 
																							
							))
							end as [Name], 
							4 as rf_NDSID, 
							cast(NOMK_LS as varchar(max)) as Cod_Ras,
							cast(NOMK_LS as varchar(max)) as Cod_Nom, 
			
							isnull((Select top 1 ProducerID from ras_Producer where [Name]=Name_FCT ),0) as rf_ProducerID,
							(Select top 1 NarcLSTypeID from ras_NarcLSType where ras_NarcLSType.Code=oms_NarcType.Code) as rf_NarcLSTypeID
							,oms_LS.rf_LFID,
							oms_LS.rf_DLSID,
							oms_LS.LSID,
							oms_LS.rf_MLFID,
							oms_LS.M_LF,
							oms_LS.rf_VLFID,
							oms_LS.V_LF,
							oms_LS.MSG_text,
							oms_LS.Date_B as Date_B,
							oms_LS.Date_E as Date_E,
							ISNULL(
								(select top 1 SpecificID from ras_Specific where ras_Specific.Code=cast(oms_Spec.Code as varchar)),
								(select top 1 SpecificID from ras_Specific where CODE = '0')) as rf_SpecificID,
							1,
							 isnull( case rls_Nomen.DrugsInpPack when 0 then 1 else rls_Nomen.DrugsInpPack end, case oms_LS.N_FV when 0 then 1 else oms_LS.N_FV end) as [Severability1],
							 isnull( case PPackInUPack when 0 then 1 else PPackInUPack end *  
									 case UPackInSPack when 0 then 1 else UPackInSPack end , 1 ) as [Severability2] 
							,ltrim(rtrim(isnull(rls_Nomen.EanCode, '')))
			
							from oms_LS
							left join rls_Nomen on oms_LS.RlsNomenUid = rls_Nomen.UID and oms_LS.RlsNomenUid <> '00000000-0000-0000-0000-000000000000'
							inner join oms_NarcType on NarcTypeID=rf_NarcTypeID
							inner join oms_Spec on SpecID=rf_SpecID
							inner join oms_TRName on trnameID=rf_trnameID
							inner join oms_LF on LFID=rf_LFID
							inner join oms_DLS on DLSID=rf_DLSID
							inner join oms_MNName on mnnameID=rf_mnnameID
							left outer join ras_nomenclature  on cast(oms_LS.NOMK_LS as varchar(max)) = ras_nomenclature.Cod_RAS
							where nomenclatureID is null 
								and oms_LS.Date_E > getDate()
								and LSID>0.1
								and oms_LS.NOMK_LS  not in (Select NOMK_LS 
				from oms_LS
				left join rls_Nomen on oms_LS.RlsNomenUid = rls_Nomen.UID and oms_LS.RlsNomenUid <> '00000000-0000-0000-0000-000000000000'
				inner join oms_NarcType on NarcTypeID=rf_NarcTypeID
				inner join oms_Spec on SpecID=rf_SpecID
				inner join oms_TRName on trnameID=rf_trnameID
				inner join oms_LF on LFID=rf_LFID
				inner join oms_DLS on DLSID=rf_DLSID
				inner join oms_MNName on mnnameID=rf_mnnameID
				left outer join ras_nomenclature  on cast(oms_LS.NOMK_LS as varchar(max)) = ras_nomenclature.Cod_RAS
				where nomenclatureID is null 
								and oms_LS.Date_E > getDate()
								and LSID>0.1
				group by NOMK_LS , NAME_MED
				having count(NOMK_LS) > 1)
				-----------------------
				--Обновление ссылок в таблице номенклатуры

END TRY
--Если запрос таки упал :(
BEGIN CATCH
		--ошибка в индексах
		if ERROR_NUMBER()=2601 
		begin 

			SET @sql=null;
			SELECT @sql = ISNULL(@sql,'')+ CASE WHEN @sql IS NULL THEN '' ELSE ', ' END +c.name
				FROM sys.index_columns ic
				LEFT JOIN sys.indexes i ON ic.object_id=i.object_id
				LEFT JOIN sys.columns c ON ic.object_id=c.object_id
				WHERE ic.index_id=i.index_id and ic.column_id=c.column_id
				and i.name like '%UNIQUE'and ic.object_id=object_id(@n_tab)
			Select @sql2='Cod_RAS'
		 
			if exists(select * from sysobjects where [name] = 'tmp_err')
				begin 
					insert into tmp_err
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
		
				end
				else
					begin
					SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage,'Ошибка в уникальных индексах для таблицы '+@n_tab+'! Индекс стоит на поля '+@sql+', а протокол проверяет поля '+@sql2 as er
					into tmp_err
					end
				end
		else 
		if exists(select * from sysobjects where [name] = 'tmp_err')
			begin
				insert into tmp_err
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage,'' as er
			end
		else
			begin
				SELECT ERROR_NUMBER() AS ErrorNumber,(ERROR_MESSAGE() +' TABLE ' + @n_tab) AS ErrorMessage,'' as er into tmp_err
			end
END CATCH
END
go

