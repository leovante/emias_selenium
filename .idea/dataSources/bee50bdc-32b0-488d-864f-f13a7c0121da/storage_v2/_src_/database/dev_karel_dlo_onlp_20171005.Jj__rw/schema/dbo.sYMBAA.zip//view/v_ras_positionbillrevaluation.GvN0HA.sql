CREATE VIEW [V_ras_PositionBillRevaluation] AS SELECT 
[hDED].[PositionBillRevaluationID], [hDED].[HostPositionBillRevaluationID], [hDED].[x_Edition], [hDED].[x_Status], 
((ISNULL((SELECT top 1  TenderType_Name 
FROM oms_TenderType 
join ras_StoredLS on rf_TenderTypeID = TenderTypeID and hDed.rf_StoredLSID = ras_StoredLS.StoredLSID 
			  and hDed.rf_StoredLSIDHost = ras_StoredLS.HostStoredLSID),''))) as [V_TenderTypeName], 
(dbo.ras_ConvertToFraction(hDED.Count,(select top 1 Severability1 * Severability2  from ras_Nomenclature nom where jT_ras_StoredLS.rf_NomenclatureID = nom.NomenclatureID and jT_ras_StoredLS.rf_NomenclatureIDHost = nom.HostNomenclatureID))) as [V_FractionCount], 
[jT_ras_StoredLS].[V_Producer] as [V_Producer], 
[jT_ras_StoredLS].[V_Producer] as [V_Produсer], 
[jT_ras_StoredLS].[V_Nomenclature] as [V_Nomenclature], 
[jT_ras_StoredLS].[V_Series] as [V_Series], 
[jT_ras_StoredLS].[V_TenderNum] as [V_TenderNum], 
[jT_ras_StoredLS].[V_Cod_RAS] as [V_COD], 
[jT_ras_StoredLS].[V_Owner] as [V_Owner], 
[jT_ras_StoredLS].[Consigment] as [V_Consigment], 
[jT_ras_StoredLS].[Price] as [V_PriceOld], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_StatePositionBillRevaluationID] as [rf_StatePositionBillRevaluationID], 
[hDED].[rf_BillRevaluationID] as [rf_BillRevaluationID], 
[hDED].[rf_BillRevaluationIDHost] as [rf_BillRevaluationIDHost], 
[hDED].[rf_PositionStatusID] as [rf_PositionStatusID], 
[hDED].[PriceNew] as [PriceNew], 
[hDED].[SummaNew] as [SummaNew], 
[hDED].[SummaOld] as [SummaOld], 
[hDED].[PRICE_OPTNew] as [PRICE_OPTNew], 
[hDED].[PRICE_BASENew] as [PRICE_BASENew], 
[hDED].[Count] as [Count]
FROM [ras_PositionBillRevaluation] as [hDED]
INNER JOIN [V_ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
go

