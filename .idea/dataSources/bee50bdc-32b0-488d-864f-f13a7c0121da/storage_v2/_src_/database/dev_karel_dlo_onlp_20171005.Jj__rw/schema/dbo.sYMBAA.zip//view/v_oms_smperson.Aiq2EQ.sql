CREATE VIEW [V_oms_SMPerson] AS SELECT 
[hDED].[SMPersonID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_Person].[Patronymic] as [V_OT], 
[jT_oms_Person].[FAMILY] as [V_FAMILY], 
[jT_oms_Person].[NAME] as [V_NAME], 
[hDED].[rf_PersonID] as [rf_PersonID], 
[hDED].[rf_DoctorID] as [rf_DoctorID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_MKBOther] as [rf_MKBOther], 
[hDED].[rf_PersonDLOID] as [rf_PersonDLOID], 
[hDED].[rf_Recipe_ReestrID] as [rf_Recipe_ReestrID], 
[hDED].[Date_P] as [Date_P], 
[hDED].[Q_Z] as [Q_Z], 
[hDED].[K_MU] as [K_MU], 
[hDED].[REG_S] as [REG_S], 
[hDED].[S_ALL] as [S_ALL], 
[hDED].[SMPersonGUID] as [SMPersonGUID], 
[hDED].[K_LR] as [K_LR], 
[hDED].[D_TYPE] as [D_TYPE], 
[hDED].[isOperPerson] as [isOperPerson]
FROM [oms_SMPerson] as [hDED]
INNER JOIN [oms_Person] as [jT_oms_Person] on [jT_oms_Person].[PersonID] = [hDED].[rf_PersonID]
go

