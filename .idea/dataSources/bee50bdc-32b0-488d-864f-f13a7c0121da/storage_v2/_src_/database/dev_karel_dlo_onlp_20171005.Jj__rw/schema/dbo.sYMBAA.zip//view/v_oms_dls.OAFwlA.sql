CREATE VIEW [V_oms_DLS] AS SELECT 
[hDED].[DLSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_DLS] as [C_DLS], 
[hDED].[NAME_DLS] as [NAME_DLS], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[GUIDLS] as [GUIDLS]
FROM [oms_DLS] as [hDED]
go

