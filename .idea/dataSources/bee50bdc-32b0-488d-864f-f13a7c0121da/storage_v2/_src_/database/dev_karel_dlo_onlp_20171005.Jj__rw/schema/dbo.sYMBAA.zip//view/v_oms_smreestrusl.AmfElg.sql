CREATE VIEW [V_oms_SMreestrUsl] AS SELECT 
[hDED].[SMreestrUslID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[IDServ] as [IDServ], 
[hDED].[Podr] as [Podr], 
[hDED].[Profil] as [Profil], 
[hDED].[Det] as [Det], 
[hDED].[Date_IN] as [Date_IN], 
[hDED].[Date_OUT] as [Date_OUT], 
[hDED].[DS] as [DS], 
[hDED].[Code_USL] as [Code_USL], 
[hDED].[Kol_USL] as [Kol_USL], 
[hDED].[Tarif_Usl] as [Tarif_Usl], 
[hDED].[Code_MD] as [Code_MD], 
[hDED].[ComentU] as [ComentU], 
[hDED].[SumV_Usl] as [SumV_Usl], 
[hDED].[Usl] as [Usl], 
[hDED].[PRVS] as [PRVS], 
[hDED].[LPU] as [LPU], 
[hDED].[LPU_1] as [LPU_1], 
[hDED].[NOM_USL] as [NOM_USL], 
[hDED].[VID_ME] as [VID_ME], 
[hDED].[VID_VME] as [VID_VME]
FROM [oms_SMreestrUsl] as [hDED]
go

