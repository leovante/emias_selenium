
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[NamelesName] 
(
	-- Add the parameters for the function here
	@lsid int
)
RETURNS varchar(2000)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ResultVar varchar(2000)

	IF NOT EXISTS(SELECT 1 FROM oms_LS WHERE LSID = @lsid) RETURN @ResultVar

	DECLARE @DLS varchar(100)
	DECLARE @MLF varchar(100)
	DECLARE @VLF varchar(100)
	DECLARE @N varchar(100)
	DECLARE @DOZ varchar(100)

	DECLARE @MNN varchar (500)
	DECLARE @LF varchar  (500)

	SET @DLS = ''
	SET @MLF = ''
	SET @VLF = ''
	SET @N = ''
	SET @DOZ = ''


	DECLARE @delta decimal
	SET @delta = 0.001

	DECLARE @lsMnnid int
	DECLARE @lsTrnID int
	--DECLARE @cmnn varchar(20)
	DECLARE @lsNamemed varchar(500)
	DECLARE @lsV_LF decimal(7,3)
	DECLARE @lsrf_VLF int
	DECLARE @lsM_LF decimal(7,3)
	DECLARE @lsrf_MLF int
	DECLARE @lsN_FV int	
	DECLARE @lsN_Doza int
	DECLARE @lsD_LS varchar(100)
	DECLARE @lsrf_DLS varchar(100)

	DECLARE @lsrf_MNN int
	DECLARE @lsrf_LF int

               

	SELECT  @lsMnnid = rf_MNNameID, 	
			@lsNamemed = NAME_MED,
			@lsV_LF = V_LF,
			@lsrf_VLF = rf_VLFID,
			@lsM_LF = M_LF,
			@lsrf_MLF = rf_MLFID,
			@lsN_FV = N_FV,
			@lsN_Doza = N_DOZA,
			@lsD_LS = D_LS,
			@lsrf_DLS = rf_DLSID,
			@lsrf_MNN = rf_MNNameID,
			@lsTrnID = rf_TRNameID,
			@lsrf_LF = rf_LFID
	FROM oms_LS WHERE LSID = @lsid 

		
		
		IF (@lsMnnid <= 0)
		BEGIN
			IF (@lsTrnID <= 0) 
			BEGIN
				SET @ResultVar = @lsNamemed
				RETURN @ResultVar
			END
			ELSE
			BEGIN
				SET @MNN = '~,' + isnull((select top 1 NAME_TRN from oms_TRName where TRNameID = @lsTrnID), '')	
			END
		END
		ELSE IF  ((select charindex('-', c_mnn)  from oms_MNName where MNNameID = @lsMnnid) > 0)
		BEGIN -- Для ИМН (КОД МНН = -1)оставляем только название
			SET @ResultVar = @lsNamemed
			RETURN @ResultVar
		END ELSE
		BEGIN
			SET @MNN = isnull((select top 1 NAME_MNN from oms_MNName where MNNameID = @lsrf_MNN), '')
		END

		IF (len(@lsD_LS) > 0) AND (@lsD_LS != '0')
		BEGIN
			 SET @DLS = @lsD_LS + ' ' + isnull((select top 1 NAME_DLS from oms_DLS where DLSID = @lsrf_DLS), '')
		END

		 IF @lsM_LF > @delta	
		 BEGIN
			SET @MLF = ' /' + REPLACE(cast(@lsM_LF as varchar(10)), '.000', '') + ' ' + isnull((select top 1 NAME_MLF from oms_MLF where MLFID = @lsrf_MLF), '')
		 END   

		 IF @lsV_LF > @delta	
		 BEGIN
			SET @VLF = ' /' + REPLACE(cast(@lsV_LF as varchar(10)), '.000', '') + ' ' + isnull((select top 1 NAME_VLF from oms_VLF where VLFID = @lsrf_VLF), '')
		 END   

		 IF @lsN_Doza > 0	
		 BEGIN
			SET @DOZ = ' /' + cast(@lsN_Doza as varchar(10)) + ' доз'
		 END 

		 IF @lsN_FV > 0	
		 BEGIN
			SET @N = ' №' + cast(@lsN_FV as varchar(10))
		 END 

		 
		 SET @LF = isnull((select top 1 NAME_LF from oms_LF where LFID = @lsrf_LF), '')
		 SET @ResultVar = ltrim(rtrim( @MNN + ', ' + @LF + ', ' + @DLS + @MLF + @VLF + @DOZ + @N))
		     

	-- Return the result of the function
	RETURN @ResultVar

END

go

