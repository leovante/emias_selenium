CREATE VIEW [V_ras_PositionDistrib] AS SELECT 
[hDED].[PositionDistribID], [hDED].[HostPositionDistribID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_ras_StoredLS].[V_Series] as [V_Series], 
[jT_ras_StoredLS].[V_C_LSFO] as [V_C_LSFO], 
[jT_ras_StoredLS].[V_Nomenclature] as [V_Nomenclature], 
[jT_ras_StoredLS].[V_Owner] as [V_Owner], 
[jT_ras_StoredLS].[V_TenderTypeName] as [V_TenderTypeName], 
[jT_ras_StoredLS].[V_TenderNum] as [V_TenderNum], 
[jT_ras_StoredLS].[Price] as [V_Price], 
[jT_ras_StoredLS].[Consigment] as [V_Consigment], 
[hDED].[rf_StoredLSID] as [rf_StoredLSID], 
[hDED].[rf_StoredLSIDHost] as [rf_StoredLSIDHost], 
[hDED].[rf_StatePosDistribID] as [rf_StatePosDistribID], 
[jT_ras_StatePosDistrib].[Name] as [SILENT_rf_StatePosDistribID], 
[hDED].[rf_DistribID] as [rf_DistribID], 
[hDED].[rf_DistribIDHost] as [rf_DistribIDHost], 
[jT_ras_Distrib].[Num] as [SILENT_rf_DistribID], 
[hDED].[Count] as [Count], 
[hDED].[Summa] as [Summa]
FROM [ras_PositionDistrib] as [hDED]
INNER JOIN [V_ras_StoredLS] as [jT_ras_StoredLS] on [jT_ras_StoredLS].[StoredLSID] = [hDED].[rf_StoredLSID] AND  [jT_ras_StoredLS].[HostStoredLSID] = [hDED].[rf_StoredLSIDHost]
INNER JOIN [ras_StatePosDistrib] as [jT_ras_StatePosDistrib] on [jT_ras_StatePosDistrib].[StatePosDistribID] = [hDED].[rf_StatePosDistribID]
INNER JOIN [ras_Distrib] as [jT_ras_Distrib] on [jT_ras_Distrib].[DistribID] = [hDED].[rf_DistribID] AND  [jT_ras_Distrib].[HostDistribID] = [hDED].[rf_DistribIDHost]
go

