CREATE VIEW [V_ras_StatePosBillIShift] AS SELECT 
[hDED].[StatePosBillIShiftID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Cod] as [Cod], 
[hDED].[Name] as [Name]
FROM [ras_StatePosBillIShift] as [hDED]
go

