CREATE VIEW [V_oms_SMError] AS SELECT 
[hDED].[SMErrorID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_SMExpert].[V_SMExpert] as [V_V_SMExpert], 
[hDED].[rf_SMReestrID] as [rf_SMReestrID], 
[hDED].[rf_SMReestrPatientID] as [rf_SMReestrPatientID], 
[hDED].[rf_SMExpertID] as [rf_SMExpertID], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[jT_oms_SMCriterion].[SMCriterionCaption] as [SILENT_rf_SMCriterionID], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[rf_SMreestrUslID] as [rf_SMreestrUslID], 
[hDED].[rf_SMFieldConditionID] as [rf_SMFieldConditionID], 
[hDED].[rf_MTReestrID] as [rf_MTReestrID], 
[hDED].[Rem] as [Rem], 
[hDED].[S_CODE] as [S_CODE], 
[hDED].[S_SUM] as [S_SUM], 
[hDED].[S_TIP] as [S_TIP], 
[hDED].[S_OSN] as [S_OSN], 
[hDED].[S_IST] as [S_IST], 
[hDED].[num_zap] as [num_zap]
FROM [oms_SMError] as [hDED]
INNER JOIN [V_oms_SMExpert] as [jT_oms_SMExpert] on [jT_oms_SMExpert].[SMExpertID] = [hDED].[rf_SMExpertID]
INNER JOIN [oms_SMCriterion] as [jT_oms_SMCriterion] on [jT_oms_SMCriterion].[SMCriterionID] = [hDED].[rf_SMCriterionID]
go

