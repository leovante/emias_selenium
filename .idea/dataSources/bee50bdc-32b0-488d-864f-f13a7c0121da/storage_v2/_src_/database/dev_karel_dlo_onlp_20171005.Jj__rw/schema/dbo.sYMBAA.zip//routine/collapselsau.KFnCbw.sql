
CREATE PROCEDURE [dbo].[CollapseLsAu](@plusCode bigint, @minusCode bigint)
AS
BEGIN
	declare @plusID int; --ID ЛС с положительным кодом
	select @plusID = LSID from oms_LS where NOMK_LS = @plusCode;
	declare @minusID int; --ID ЛС с отрицательным кодом
	select @minusID = LSID from oms_LS where NOMK_LS = @minusCode;


	BEGIN TRY 
	if (@plusID is not null and @minusID is not null)
	begin

		exec dbo.ras_PrepareNomenclature @plusCode
		
		declare @newNomenID int;
		--ПЫТАЕМСЯ НАЙТИ ЭТАЛОННУЮ НОМЕНКЛАТУРУ (ГДЕ КОД РАС РАВЕН КОДУ ЛС)
		SELECT @newNomenID = ISNULL(NomenclatureID, -1) from ras_Nomenclature 
		where rf_LSID = @plusID and COD_RAS = CONVERT(varchar(max), @plusCode)


		declare @minusNomenCount int; --Количество номенклатур ЛС с отрицательным кодом
		select @minusNomenCount = COUNT(1) from ras_Nomenclature where rf_LSID = @minusID;

		
		declare _oldCur cursor for
		select NomenclatureID from ras_Nomenclature where rf_LSID = @minusID
		open _oldCur

		--ЕСТЬ НОМЕНКЛАТУРЫ ДЛЯ СТАРОГО ЛС И НОВОГО ЛС
		if (@minusNomenCount > 0 and @newNomenID <> -1)
		begin			


			declare @ignoreLsfo string_list 

			insert into @ignoreLsfo (string_item) values ('ras_Lsfo')

			declare @ignoreLsfoAndSeries string_list 

			insert into @ignoreLsfoAndSeries (string_item) values ('ras_Lsfo')
			insert into @ignoreLsfoAndSeries (string_item) values ('ras_Series')


			--ПЕРЕБИРАЕМ СТАРЫЕ НОМЕНКЛАТУРЫ И ИСПРАВЛЯЕМ ВСЕ ССЫЛКИ НА НИХ НА НОВУЮ
			declare @oldNomenID int;			
			fetch next from _oldCur into @oldNomenID
			while (@@fetch_status <> -1)
			begin
				declare @codRasMinus varchar(max);
				select top 1 @codRasMinus = Cod_RAS from ras_Nomenclature where NomenclatureID = @oldNomenID;


				declare @oldLSFOID int;
				declare @newLSFOID int;

				begin try
					declare _lsfo cursor for
					select old.LSFOID oldLsfoID, (select LSFOID from ras_LSFO new where old.C_PFS = new.C_PFS and rf_NomenclatureID = @newNomenID ) newLSFOID
					from ras_LSFO  old
					where rf_NomenclatureID = @oldNomenID

					open _lsfo

						fetch next from _lsfo into @oldLSFOID, @newLSFOID 
						while (@@fetch_status <> -1)
						begin


							if (not @newLSFOID is null) 
							begin
								exec ref_update 'RAS', 'rf_LSFOID%', @oldLSFOID, @newLSFOID

								delete from ras_LSFO where LSFOID = @oldLSFOID 
							end
							else
							begin
								update ras_LSFO
								set C_LSProvider = REPLACE(C_LSProvider, @codRasMinus + '_', CONVERT(varchar(max), @plusCode) + '_')
									, rf_NomenclatureID = @newNomenID
								where LSFOID = @oldLSFOID
							end 

							fetch next from _lsfo into @oldLSFOID, @newLSFOID 
						end
					close _lsfo
					deallocate _lsfo
				end try 
				begin catch 
					begin try
						update ras_LSFO
						set C_LSProvider = REPLACE(C_LSProvider, @codRasMinus + '_', CONVERT(varchar(max), @plusCode) + '_')
						, rf_NomenclatureID = @newNomenID
						where rf_NomenclatureID = @oldNomenID	
					end try 
					begin catch 
					end catch 
				end catch
				
				update ras_PositionInventarisation
				set C_LSFO = REPLACE(C_LSFO, @codRasMinus + '_', CONVERT(varchar(max), @plusCode) + '_'),
				Name = (select top 1 Name from ras_Nomenclature where Cod_RAS = @plusCode)
				where C_LSFO like @codRasMinus + '_%'

				update ras_PositionBillEx_Other
				set C_LSFO = REPLACE(C_LSFO, @codRasMinus + '_', CONVERT(varchar(max), @plusCode) + '_')
				where C_LSFO like @codRasMinus + '_%'

				update ras_ExtractedLSfromReestr
				set C_LSFO = CONVERT(varchar(max), @plusCode)
				where C_LSFO = @codRasMinus

				update ras_PositionReport
				set C_LSFO = CONVERT(varchar(max), @plusCode)
				where C_LSFO = @codRasMinus

				--проверяем наличие серий с одинаковыми номерами для положительной и отрицательной номенклатуры
				if (	
					select isnull(SUM(c), 0) from
					(
						select ISNULL((COUNT(distinct NUM)), 0) as c from ras_Series 
						where SeriesID  > 0 and (rf_NomenclatureID = @oldNomenID or rf_NomenclatureID = @newNomenID)
						group by NUM
						having COUNT(*) > 1
					)ttt
				) = 0
				begin
					exec RefUpdateWithIgnore 'RAS', 'rf_NomenclatureID%', @ignoreLsfo, @oldNomenID, @newNomenID
				end
				else
				begin
					-- перебираем все дублирующиеся номера серий для обоих номенклатур
					declare @seriesNum varchar(max);
					declare _serCur cursor for
						select NUM from ras_Series 
						where SeriesID  > 0 and (rf_NomenclatureID = @oldNomenID or rf_NomenclatureID = @newNomenID)
						group by NUM
						having COUNT(*) > 1
					open _serCur

					fetch next from _serCur into @seriesNum
					while (@@fetch_status <> -1)
					begin
						declare @minusSerId int;
						declare @plusSerId int;

						SELECT @minusSerId = SeriesID from ras_Series where NUM = @seriesNum and rf_NomenclatureID = @oldNomenID 
						SELECT @plusSerId = SeriesID from ras_Series where NUM = @seriesNum and rf_NomenclatureID = @newNomenID 

						--перебрасываем все ссылки с отрицательной серии на положительную серию
						exec  Ref_update 'RAS', 'rf_SeriesID%', @minusSerId, @plusSerId

						--перебрасываем ссылки со старой номенклатуры на новую НЕ трогая таблицу серий
						exec RefUpdateWithIgnore 'RAS', 'rf_NomenclatureID%', @ignoreLsfoAndSeries, @oldNomenID,@newNomenID


						fetch next from _serCur into @seriesNum
					end
					close _serCur		
					deallocate _serCur
				end

				update ras_Nomenclature
				set Date_E = GETDATE()
				where NomenclatureID = @oldNomenID

				fetch next from _oldCur into @oldNomenID
			end			
		end

		update oms_LS
		set rf_GroupIMNID = 
			(
				select rf_GroupIMNID from oms_LS where LSID = @minusID
			)
		where LSID = @plusID
		
		update oms_LS
		set FCode = 
			(
				select FCode from oms_LS where LSID = @minusID
			)
		where LSID = @plusID

		--обновляем ссылки на ЛС с отрицательным кодом
		exec  Ref_update 'OMS', 'rf_LSID%', @minusID, @plusID
		--exec  Ref_update 'DEMAND', 'rf_LSID%', @minusID, @plusID		

		update oms_CollapseHistory 
		set IsSuccessAu = 1
		where OldCode = @minusCode and NewCode = @plusCode
	end

	END TRY
	BEGIN CATCH
		SELECT 
			ERROR_NUMBER() AS ErrorNumber,
			ERROR_MESSAGE() AS ErrorMessage;
	END CATCH
	
	close _oldCur		
	deallocate _oldCur
		
END
go

