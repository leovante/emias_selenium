-- =============================================
-- Author:		Юров Сергей анатольевич
-- Create date: 14.04.2008
-- Description:	Функция возвращает текущую организацию
-- =============================================
CREATE FUNCTION  RAS_GetSelfOrganisation
(
	
)
RETURNS int 
AS
BEGIN
	declare @OrgID int
    set @OrgID = -1
	select @OrgID = OrganisationID
	from ras_Organisation
	where OGRN = IsNull((select top 1  ValueStr
						from x_UserSettings
						where [Property]='OGRN' and OwnerGuid = '10000000-0000-0000-0000-000000000000'),'')
	  and CODE = IsNull((select top 1  ValueStr
						from x_UserSettings
						where [Property]='CODE' and OwnerGuid = '10000000-0000-0000-0000-000000000000'),'')
    
	RETURN @OrgID

END
go

