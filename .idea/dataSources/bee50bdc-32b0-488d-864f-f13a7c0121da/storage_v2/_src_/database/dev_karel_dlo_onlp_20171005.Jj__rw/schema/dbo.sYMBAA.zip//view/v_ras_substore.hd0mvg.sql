CREATE VIEW [V_ras_SubStore] AS SELECT 
[hDED].[SubStoreID], [hDED].[HostSubStoreID], [hDED].[x_Edition], [hDED].[x_Status], 
ISNULL ((SELECT  SUM(Count) AS Count FROM    ras_StoredLS AS st WHERE (st.rf_SubStoreID = hDED.SubStoreID)), 0) as [Count_UP], 
ISNULL((SELECT TOP 1 ras_Zone.Name + '-' + convert(varchar,ras_Rack.Name) + '-' + convert(varchar,ras_Shelf.Name) + '-' + convert(varchar,rss.Name) FROM ras_Zone INNER JOIN ras_Rack ON ras_Rack.rf_ZoneID = ras_Zone.ZoneID INNER JOIN ras_Shelf ON ras_Shelf.rf_RackID = ras_Rack.RackID INNER JOIN ras_SubStore rss ON  rss.rf_ShelfID = ras_Shelf.ShelfID WHERE rss.SubStoreID = hDED.SubStoreID),'') as [V_Name], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[hDED].[rf_ShelfID] as [rf_ShelfID], 
[hDED].[rf_ShelfIDHost] as [rf_ShelfIDHost], 
[hDED].[Name] as [Name], 
[hDED].[Count_UP_Max] as [Count_UP_Max], 
[hDED].[Barcode] as [Barcode]
FROM [ras_SubStore] as [hDED]
go

