
CREATE PROCEDURE [dbo].[CollapseLsMis](@newCode bigint, @oldCode bigint)
AS
BEGIN
	;
	exec dbo.ChangeLsMis_NoNameless @oldCode , @newCode 

END
go

