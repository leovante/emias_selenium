
---------------------------
---------------------------

-- =============================================
-- Author:		Ranzou
-- Create date: <Create Date,,>
-- Description:	Чистит хвосты после НСИ загрузки
-- =============================================
CREATE PROCEDURE [dbo].[CleanDBFTails]
AS
BEGIN
Declare @Sql nvarchar(max) 
	if exists(select * from sysobjects where [name] = 'inf_tabl') drop table inf_tabl
	if exists(select * from sysobjects where [name] = 'inf_tabl2') drop table inf_tabl2	
	if exists(select * from sysobjects where [name] = 'tmp_tables') drop table tmp_tables
	
----------------------------------------------------------------------------------------------
DECLARE cur_del_Tab SCROLL CURSOR 
	FOR select 'drop table ['+[name]+']' 
	from sys.all_objects	
	where [name] like 'rd_%' 
					or name like 'err_%' 
					or name like 'Err_%'					
OPEN cur_del_Tab 
FETCH FIRST FROM cur_del_Tab 
INTO @SQL	
WHILE @@FETCH_STATUS = 0 
BEGIN	
	EXECUTE sp_executesql @SQL	
	FETCH NEXT FROM cur_del_Tab 
	INTO @SQL 
END	
DEALLOCATE cur_del_Tab 

END

go

