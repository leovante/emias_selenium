CREATE VIEW [V_hlt_Marker] AS SELECT 
[hDED].[MarkerID], [hDED].[x_Edition], [hDED].[x_Status], 
Convert(varchar, hDED.Date, 104) + ' - ' + jT_hlt_TypeMarker.Name + ' : ' + hDED.Result as [V_Caption], 
[jT_hlt_MKAB].[V_FIO] as [V_PatFIO], 
[jT_hlt_TypeMarker].[Name] as [V_TypeMarkerName], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_TypeMarkerID] as [rf_TypeMarkerID], 
[jT_hlt_TypeMarker].[Name] as [SILENT_rf_TypeMarkerID], 
[hDED].[Date] as [Date], 
[hDED].[Result] as [Result], 
[hDED].[NoteText] as [NoteText], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[GUID] as [GUID]
FROM [hlt_Marker] as [hDED]
INNER JOIN [V_hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_TypeMarker] as [jT_hlt_TypeMarker] on [jT_hlt_TypeMarker].[TypeMarkerID] = [hDED].[rf_TypeMarkerID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
go

