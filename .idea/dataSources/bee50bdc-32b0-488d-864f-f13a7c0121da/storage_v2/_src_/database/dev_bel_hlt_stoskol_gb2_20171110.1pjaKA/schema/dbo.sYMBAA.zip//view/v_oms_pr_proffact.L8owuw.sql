CREATE VIEW [V_oms_pr_ProfFact] AS SELECT 
[hDED].[pr_ProfFactID], [hDED].[x_Edition], [hDED].[x_Status], 
(((isnull((Select top 1 case when Year(oms_pr_ProfPlan.Reject_DATE)>1900 then 'отказ '+convert(varchar,Reject_DATE,104) else oms_pr_ProfPlan.Quarter+' кв. '+cast(oms_pr_ProfPlan.Year as varchar) end
from oms_pr_ProfPlan where pr_ProfPlanID>0 and pr_ProfPlanID=rf_pr_ProfPlanID),'')))) as [V_Plan], 
[jT_oms_pr_Person].[V_Person] as [V_V_Person], 
[hDED].[rf_kl_VisitResultID] as [rf_kl_VisitResultID], 
[hDED].[rf_kl_HealthGroupID] as [rf_kl_HealthGroupID], 
[hDED].[rf_pr_PersonID] as [rf_pr_PersonID], 
[hDED].[rf_pr_ProfPlanID] as [rf_pr_ProfPlanID], 
[hDED].[Date_NPM] as [Date_NPM], 
[hDED].[Date_PPM] as [Date_PPM], 
[hDED].[DISP2_NPM] as [DISP2_NPM], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [oms_pr_ProfFact] as [hDED]
INNER JOIN [V_oms_pr_Person] as [jT_oms_pr_Person] on [jT_oms_pr_Person].[pr_PersonID] = [hDED].[rf_pr_PersonID]
go

