CREATE VIEW [V_hlt_PersonSprType] AS SELECT 
[hDED].[PersonSprTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [hlt_PersonSprType] as [hDED]
go

