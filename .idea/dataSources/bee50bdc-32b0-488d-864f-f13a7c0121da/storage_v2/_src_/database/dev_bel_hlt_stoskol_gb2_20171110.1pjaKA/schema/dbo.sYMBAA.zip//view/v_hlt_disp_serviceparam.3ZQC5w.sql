CREATE VIEW [V_hlt_disp_ServiceParam] AS SELECT 
[hDED].[disp_ServiceParamID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OmsParamGuid] as [rf_OmsParamGuid], 
[jT_oms_Param].[Name] as [SILENT_rf_OmsParamGuid], 
[hDED].[rf_ServiceGuid] as [rf_ServiceGuid], 
[jT_hlt_disp_Service].[Name] as [SILENT_rf_ServiceGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_ServiceParam] as [hDED]
INNER JOIN [oms_Param] as [jT_oms_Param] on [jT_oms_Param].[GUID] = [hDED].[rf_OmsParamGuid]
INNER JOIN [hlt_disp_Service] as [jT_hlt_disp_Service] on [jT_hlt_disp_Service].[Guid] = [hDED].[rf_ServiceGuid]
go

