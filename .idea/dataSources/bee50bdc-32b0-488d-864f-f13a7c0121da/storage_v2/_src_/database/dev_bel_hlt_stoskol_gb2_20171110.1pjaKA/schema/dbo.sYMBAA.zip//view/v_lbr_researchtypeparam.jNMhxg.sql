CREATE VIEW [V_lbr_ResearchTypeParam] AS SELECT 
[hDED].[ResearchTypeParamID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_ResearchParamValueTypeID] as [rf_ResearchParamValueTypeID], 
[jT_lbr_ResearchParamValueType].[Name] as [SILENT_rf_ResearchParamValueTypeID], 
[hDED].[rf_ResearchTypeUGUID] as [rf_ResearchTypeUGUID], 
[hDED].[rf_BioMID] as [rf_BioMID], 
[hDED].[rf_MicrobeID] as [rf_MicrobeID], 
[hDED].[ParamName] as [ParamName], 
[hDED].[ParamUnit] as [ParamUnit], 
[hDED].[MinValue] as [MinValue], 
[hDED].[MaxValue] as [MaxValue], 
[hDED].[MinNormalValue] as [MinNormalValue], 
[hDED].[MaxNormalValue] as [MaxNormalValue], 
[hDED].[GroupName] as [GroupName], 
[hDED].[RequiredParam] as [RequiredParam], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[TemplateParamName] as [TemplateParamName], 
[hDED].[Code] as [Code], 
[hDED].[ShortName] as [ShortName], 
[hDED].[CodeLis] as [CodeLis], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [lbr_ResearchTypeParam] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [lbr_ResearchParamValueType] as [jT_lbr_ResearchParamValueType] on [jT_lbr_ResearchParamValueType].[ResearchParamValueTypeID] = [hDED].[rf_ResearchParamValueTypeID]
go

