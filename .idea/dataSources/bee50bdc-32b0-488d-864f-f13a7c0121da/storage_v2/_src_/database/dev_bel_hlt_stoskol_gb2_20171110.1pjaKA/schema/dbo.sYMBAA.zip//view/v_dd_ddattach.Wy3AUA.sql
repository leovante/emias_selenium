CREATE VIEW [V_dd_DDAttach] AS SELECT 
[hDED].[DDAttachID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDAttach] as [hDED]
go

