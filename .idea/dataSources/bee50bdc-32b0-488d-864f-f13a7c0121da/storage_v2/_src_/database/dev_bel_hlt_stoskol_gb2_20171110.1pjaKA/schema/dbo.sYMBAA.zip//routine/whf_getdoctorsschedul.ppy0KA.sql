
CREATE FUNCTION [dbo].[whf_GetDoctorsSchedul]
(
	@dateA datetime, 
	@dateB datetime	,
	@FlagAccess int
)
RETURNS 
@tmp_tab TABLE
(
	DocPRVDID int,	

	DocID int,
	Fam varchar (50),
	Im varchar (50),
	Ot varchar (50),		

	UchastokID int,
	Uchastok varchar(1024), 	

	SeparationID int,
	SeparationName varchar (255),

	SpecialityID int,
	SpecialityName varchar (255),
	
	DolgID int,
	DolgName varchar (50),

	RoomID int,
	RoomNum varchar (10),	

	[Date] datetime, 
	[OutReason] varchar(20),

	Hour_from int,
	Minute_from int,
	Hour_to int,
	Minute_to int,
	[TicketCount] int,
	[FlagAccess] int,
	InTime	int
)
AS
BEGIN
	
	INSERT INTO @tmp_tab
	(
		DocPRVDID,	

		DocID,
		Fam,
		Im ,
		Ot ,		

		UchastokID,
		Uchastok, 	

		SeparationID,
		SeparationName,

		SpecialityID,
		SpecialityName,
		
		DolgID,
		DolgName,

		RoomID,
		RoomNum,	

		[Date], 
		[OutReason],

		Hour_from ,
		Minute_from ,
		Hour_to ,
		Minute_to ,
		[TicketCount] ,
		[FlagAccess] ,
		InTime	
	)
	SELECT  
		p.DocPRVDID as DocPRVDID,

		doc.LPUDoctorID as DocID,
		CASE WHEN p.rf_ResourceTypeID = 2 THEN	hr.Comment		
			 WHEN doc.LPUDoctorID = 0 THEN ''
			 WHEN (doc.FAM_V is null) OR (LEN(doc.FAM_V)) = 0 THEN ''
			 WHEN (LEN(doc.FAM_V) = 1) THEN Upper(doc.FAM_V)
			 ELSE CAST(Upper(substring(doc.FAM_V,1,1)) + lower(substring(doc.FAM_V,2, 50)) AS VARCHAR(50)) 
			 END AS Fam,
		CASE WHEN p.rf_ResourceTypeID = 2 THEN ''
			 WHEN doc.LPUDoctorID = 0 THEN ''
			 WHEN (doc.IM_V is null) OR (LEN(doc.IM_V)) = 0 THEN ''
			 WHEN (LEN(doc.IM_V) = 1) THEN Upper(doc.IM_V)
			 ELSE CAST(Upper(substring(doc.IM_V,1,1)) + lower(substring(doc.IM_V,2, 25)) AS VARCHAR(25)) 
			 END AS IM,
		CASE WHEN p.rf_ResourceTypeID = 2 THEN ''
			 WHEN doc.LPUDoctorID = 0 THEN ''
			 WHEN (doc.OT_V is null) OR (LEN(doc.OT_V)) = 0 THEN ''
			 WHEN (LEN(doc.OT_V) = 1) THEN Upper(doc.OT_V)
			 ELSE CAST(Upper(substring(doc.OT_V,1,1)) + lower(substring(doc.OT_V,2, 25)) AS VARCHAR(25)) 
			 END AS OT,
		
		null AS UchastokID, 	
		CAST('' AS VARCHAR(1024)) AS Uchastok, 	

		ISNULL(dp.DepartmentID, 0) AS SeparationID ,
		CAST(ISNULL(dp.DepartmentName, '') AS VARCHAR(255)) AS SeparationName, 

		ISNULL(prvs.PRVSid, 0) AS SpecialityID, 
		CAST(ISNULL(prvs.PRVS_NAME, '') AS VARCHAR(255)) AS SpecialityName, 

		ISNULL(prvd.prvdid, 0) AS DolgID, 
		CAST(ISNULL(prvd.name, '') AS VARCHAR(50)) AS DolgName, 

		ISNULL(hr.HealingRoomID, 0) AS RoomID,
		CAST(ISNULL(hr.Num, '') AS VARCHAR(10)) AS RoomNum,
		
		/*DTT_Date*/isnull(iv.Date, @dateA) AS [Date],
--		iv.Date AS [Date], --1
		case when iv.Date is null then 'нет приема' else ISNULL(OutReason, '') end AS [OutReason],
--		ISNULL(OutReason, '')  AS [OutReason], --2
		ISNULL(Hour_from, 0) AS Hour_from,
		ISNULL(Minute_from, 0) AS Minute_from,
		ISNULL(Hour_To, 0) AS Hour_To,
		ISNULL(Minute_to, 0) AS Minute_to,
		0 AS [TicketCount],
		0 AS [FlagAccess],
		p.InTime AS InTime		
	FROM hlt_DocPrvd p
		inner JOIN hlt_LpuDoctor doc on p.rf_LPUDoctorID = doc.LPUDoctorID
		left JOIN oms_Department dp on dp.DepartmentID = p.rf_DepartmentID 
		left JOIN oms_prvs prvs on p.rf_PRVSID  = prvs.prvsid
		left JOIN oms_prvd prvd on prvd.PRVDID = p.rf_PRVDID
		left JOIN hlt_HealingRoom hr on hr.HealingRoomID = p.rf_HealingRoomID

		left JOIN --3 inner join/left.join
		(
			SELECT dtt.Date, 
				dtt.rf_DocPRVDID as DocPRVDID,									
				CASE (ISNULL(MAX(dbt.TypeBusy),0))
					WHEN 0 THEN 
						CASE ISNULL(min(dbt.CODE ), 0)
							WHEN 0 THEN NULL
							WHEN 1 THEN 'Отп.'
							WHEN 2 THEN 'Вых.'
							WHEN 3 THEN 'Бол.'
							ELSE
							  'н/п'
							END					
					ELSE NULL END as [OutReason],
				CASE  
					WHEN min(dtt.Begin_Time) = null THEN NULL
					WHEN DATEPART(hh, (min(dtt.Begin_Time))) = 0 THEN NULL 
					ELSE Convert(VARCHAR(2), DATEPART(hh, (min(dtt.Begin_Time))), 2)					  
					END AS Hour_from,				
				CASE 
					WHEN min(dtt.Begin_Time) = null THEN NULL
					WHEN DATEPART(hh, min(dtt.Begin_Time)) = 0 THEN NULL
					ELSE right('0' + convert(VARCHAR(2), DATEPART(mi, min(dtt.Begin_Time))), 2)
					END AS Minute_from,
				CASE
					WHEN min(dtt.Begin_Time) = null THEN NULL
					WHEN DATEPART(hh, min(dtt.Begin_Time)) = 0 THEN NULL
					ELSE Convert(VARCHAR(2), DATEPART(hh, max(dtt.End_Time)), 2) 
					END AS Hour_to,
				CASE 
					WHEN min(dtt.Begin_Time) = null THEN NULL
					WHEN DATEPART(hh, min(dtt.Begin_Time)) = 0 THEN null
					ELSE right('0' + convert(VARCHAR(2), DATEPART(mi, max(dtt.End_Time))), 2)
					END AS Minute_to
			FROM         
				dbo.hlt_DoctorTimeTable AS dtt 
				INNER JOIN
					dbo.hlt_DocBusyType AS dbt 
					ON dbt.DocBusyTypeID = dtt.rf_DocBusyType AND dbt.DocBusyTypeID <> 0 				
				WHERE   dtt.DoctorTimeTableID <> 0                        
						and dtt.Begin_Time <> '1900-01-01T00:00:00'     
						and dtt.rf_DocPRVDID <> 0 
						and dtt.Date between @dateA and @dateB
						and ((dbt.TypeBusy = 0) OR (DATEPART(hh, dtt.Begin_Time) > 0))	
				group by dtt.Date, dtt.rf_DocPRVDID					
						)	iv
		on iv.DocPRVDID = p.DocPrVdID 


delete from @tmp_tab where intime != 1;

/* Считаем TicketCount */
if @FlagAccess > 0 BEGIN

	UPDATE @tmp_tab
	SET  [TicketCount]  = iv.TicketCount
	FROM @tmp_tab t
		left loop JOIN (
			SELECT 
				dtt.Date, 
				dtt.rf_DocPrVdID,
				sum(dtt.PlanUE - dtt.UsedUE) as TicketCount
			FROM 
				dbo.hlt_DoctorTimeTable AS dtt 
					INNER JOIN 	dbo.hlt_DocBusyType AS dbt 
						ON dbt.DocBusyTypeID = dtt.rf_DocBusyType AND dbt.DocBusyTypeID <> 0 
			WHERE dtt.Date between @dateA and @dateB
				  and dtt.PlanUE > 0
				  and (dbt.TypeBusy = 1) 			  
				  and (dtt.FlagAccess & @FlagAccess) > 0		-- Только для самозаписи	
				  and dtt.DoctorTimeTableID <> 0                        
				  and dtt.Begin_Time <> '1900-01-01T00:00:00' --отсекаем записи вне очереди
				  --and (DATEPART(hh, dtt.Begin_Time) > 0) --это не то же самое?
				  and (dtt.rf_DocPRVDID <> 0)			  
			GROUP BY  dtt.Date, dtt.rf_DocPrVdID
		) iv
		ON iv.rf_DocPrVdID = t.DocPRVDID and iv.Date = t.[Date]
	WHERE iv.rf_DocPrVdID is not null 

	/* Считаем [FlagAccess] */ 
	UPDATE @tmp_tab
	SET  [FlagAccess]  = iv.FA
	FROM @tmp_tab t
		inner loop JOIN (
				SELECT 
				dtt.Date, 
				dtt.rf_DocPrVdID,
					max( DISTINCT(dtt.[FlagAccess] & 1)) +
					max( DISTINCT(dtt.[FlagAccess] & 2)) +
					max( DISTINCT(dtt.[FlagAccess] & 4)) +
					max( DISTINCT(dtt.[FlagAccess] & 8))  AS FA 
				FROM 
				dbo.hlt_DoctorTimeTable AS dtt 
					INNER JOIN 	dbo.hlt_DocBusyType AS dbt 
						ON dbt.DocBusyTypeID = dtt.rf_DocBusyType AND dbt.DocBusyTypeID <> 0 
				WHERE dtt.Date between @dateA and @dateB
					  and dtt.PlanUE > 0
					  and (dbt.TypeBusy = 1) 			  
					  and (dtt.PlanUE > dtt.UsedUE)
					  and dtt.DoctorTimeTableID <> 0                        
					  and dtt.Begin_Time <> '1900-01-01T00:00:00' --отсекаем записи вне очереди					  
					  and (dtt.rf_DocPRVDID <> 0)			  
				GROUP BY  dtt.Date, dtt.rf_DocPrVdID
		) iv
		on iv.rf_DocPrVdID = t.DocPRVDID and iv.Date = t.[Date]
	WHERE iv.rf_DocPrVdID is not null 
END

/*Проставляем участки*/
DECLARE curDocPrvd CURSOR
KEYSET
FOR SELECT DISTINCT DocPRVDID FROM @tmp_tab

DECLARE @prvdid int

OPEN curDocPrvd

FETCH NEXT FROM curDocPrvd INTO @prvdid
WHILE (@@fetch_status = 0)
BEGIN
	DECLARE @uch VARCHAR(1024) 
	SET @uch = null
	SELECT @uch =  ISNULL(@uch + ', ', '') + ltrim(rtrim(UchastoCaption)) FROM hlt_Uchastok-- Code/UchastoCaption - менять тут для отображения кода или названия участка!!!
	WHERE rf_DocPRVDID = @prvdid

	IF LEN(@uch) != 0 
	BEGIN
		UPDATE @tmp_tab SET Uchastok = @uch WHERE DocPRVDID = @prvdid		
	END

	UPDATE @tmp_tab SET Uchastokid = isnull((select top 1 UchastokID from hlt_Uchastok where rf_DocPRVDID = @prvdid), 0)  WHERE DocPRVDID = @prvdid

	FETCH NEXT FROM curDocPrvd INTO @prvdid
END

CLOSE curDocPrvd
DEALLOCATE curDocPrvd


	RETURN 
END
go

