CREATE VIEW [V_oms_pr_LPUGraf] AS SELECT 
[hDED].[pr_LPUGrafID], [hDED].[x_Edition], [hDED].[x_Status], 
(isnull((select top 1 NameShort from oms_pr_weekDay where pr_WeekDayID>0 and pr_WeekDayID=rf_pr_WeekDayID),'ежедневно')+' '+
isnull(((select top 1 name from oms_pr_Hour where pr_HourID>0 and pr_HourID=rf_pr_HourOpenID)+'-'+(select top 1 name from oms_pr_Hour where pr_HourID>0 and pr_HourID=rf_pr_HourCloseID)),'круглосуточно')
) as [V_Graf], 
[jT_oms_pr_LPU].[V_M_NAMES] as [V_V_M_NAMES], 
[hDED].[rf_pr_WeekDayID] as [rf_pr_WeekDayID], 
[hDED].[rf_pr_LPUID] as [rf_pr_LPUID], 
[hDED].[rf_pr_HourCloseID] as [rf_pr_HourCloseID], 
[hDED].[rf_pr_HourOpenID] as [rf_pr_HourOpenID]
FROM [oms_pr_LPUGraf] as [hDED]
INNER JOIN [V_oms_pr_LPU] as [jT_oms_pr_LPU] on [jT_oms_pr_LPU].[pr_LPUID] = [hDED].[rf_pr_LPUID]
go

