
CREATE FUNCTION [dbo].[FullYearAge](@BIRTHDATE datetime,@DATE datetime)
RETURNS int
WITH EXECUTE AS CALLER
AS
BEGIN
	DECLARE @yearsdiff int	
	DECLARE @estimatedate DATETIME
	
	SET @yearsdiff = DATEPART(YEAR, @DATE) - DATEPART(YEAR, @BIRTHDATE)	
	SET @estimatedate = DATEADD(YEAR, @yearsdiff, @BIRTHDATE)
	
	IF(@estimatedate> @DATE)set @yearsdiff = @yearsdiff - 1
	IF(@yearsdiff<0) set @yearsdiff =0
	Return @yearsdiff
END;
go

