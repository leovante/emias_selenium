CREATE VIEW [V_rls_DrugLifeTime] AS SELECT 
[hDED].[DrugLifeTimeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[Text] as [Text], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code], 
[hDED].[LifeTime] as [LifeTime]
FROM [rls_DrugLifeTime] as [hDED]
go

