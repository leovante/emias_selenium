CREATE VIEW [V_hlt_CallDoctor] AS SELECT 
[hDED].[CallDoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_DocInfoFinalizeLPUDoctor], 
[jT_hlt_LPUDoctor1].[V_DocInfo] as [V_DocInfoLPUDoctor], 
[jT_hlt_MKAB].[OT] as [vOt], 
[jT_hlt_MKAB].[N_POL] as [N_POL], 
[jT_hlt_MKAB].[S_POL] as [S_POL], 
[jT_hlt_MKAB].[NAME] as [vName], 
[jT_hlt_MKAB].[rf_UchastokID] as [V_UchastokCODE], 
[jT_hlt_MKAB].[DATE_BD] as [V_DATE_BD], 
[jT_hlt_MKAB].[FAMILY] as [vFamily], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[Rf_FinalizeLPUDoctorID] as [Rf_FinalizeLPUDoctorID], 
[hDED].[rf_CallDoctorStatusID] as [rf_CallDoctorStatusID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_FinalizeDocPRVDID] as [rf_FinalizeDocPRVDID], 
[hDED].[rf_TypeCallDoctorID] as [rf_TypeCallDoctorID], 
[hDED].[rf_AddressID] as [rf_AddressID], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[Address] as [Address], 
[hDED].[Complaint] as [Complaint], 
[hDED].[DateCall] as [DateCall], 
[hDED].[isFinalize] as [isFinalize], 
[hDED].[DateFinalize] as [DateFinalize], 
[hDED].[CodeDomophon] as [CodeDomophon], 
[hDED].[Phone] as [Phone], 
[hDED].[Description] as [Description], 
[hDED].[Entrance] as [Entrance], 
[hDED].[Floor] as [Floor], 
[hDED].[DateVisit] as [DateVisit], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID], 
[hDED].[SourceDvt] as [SourceDvt], 
[hDED].[Family] as [Family], 
[hDED].[Name] as [Name], 
[hDED].[Ot] as [Ot], 
[hDED].[BirthDate] as [BirthDate], 
[hDED].[SeriesPol] as [SeriesPol], 
[hDED].[NumberPol] as [NumberPol], 
[hDED].[DateStatus] as [DateStatus], 
[hDED].[SourceSmp] as [SourceSmp], 
[hDED].[CauseCancel] as [CauseCancel]
FROM [hlt_CallDoctor] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[Rf_FinalizeLPUDoctorID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor1] on [jT_hlt_LPUDoctor1].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
go

