CREATE VIEW [V_hlt_MKABLocation] AS SELECT 
[hDED].[MKABLocationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_MKABLocation] as [hDED]
go

