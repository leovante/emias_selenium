CREATE VIEW [V_lbr_ResearchJournal] AS SELECT 
[hDED].[ResearchJournalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResearchGUID] as [rf_ResearchGUID], 
[hDED].[rf_ResearchStateID] as [rf_ResearchStateID], 
[hDED].[HL7Message] as [HL7Message], 
[hDED].[Comment] as [Comment], 
[hDED].[ActionDate] as [ActionDate]
FROM [lbr_ResearchJournal] as [hDED]
go

