CREATE PROCEDURE dbo.GetKatlPersoninDate    @idPerson int , @Date Datetime   AS

 select oms_Katl.KatlID
   from
   (
      select rf_PersonId, Min(C_KATL) as mi, Max(C_KATL) as ma from 
      oms_LG_Person
      inner join 
      oms_Katl on oms_Katl.KATLID = oms_LG_Person.rf_KatlID
      where  DATE_EL>@Date and rf_PersonId = @idPerson
     group by rf_PersonId 
 
   )t inner join oms_Katl on oms_Katl.C_Katl =  mi
--case when (ma=140 or ma=150) then ma else mi end
go

