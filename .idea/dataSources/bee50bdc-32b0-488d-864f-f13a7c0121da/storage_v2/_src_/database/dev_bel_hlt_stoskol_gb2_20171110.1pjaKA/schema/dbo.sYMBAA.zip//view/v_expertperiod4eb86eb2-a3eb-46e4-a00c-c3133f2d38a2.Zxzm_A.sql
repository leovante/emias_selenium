CREATE view [V_ExpertPeriod4eb86eb2-a3eb-46e4-a00c-c3133f2d38a2] as select * from [tmp_ExpertPeriod4eb86eb2-a3eb-46e4-a00c-c3133f2d38a2]
go

