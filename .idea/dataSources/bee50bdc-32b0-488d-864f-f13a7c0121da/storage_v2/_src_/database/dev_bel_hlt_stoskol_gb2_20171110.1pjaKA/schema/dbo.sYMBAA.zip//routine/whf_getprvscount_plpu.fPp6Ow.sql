
CREATE FUNCTION [dbo].[whf_GetPRVSCount_PLPU]
(	
	@dateA DATETIME, 
	@dateB DATETIME,
	@MCOD varchar(10) = '%',
	@FlagAccess int
	
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT t1.*, isnull(t2.Tickets,0) as Tickets FROM
		(
			SELECT distinct
				prvs.PRVSID,
				prvs.C_PRVS, 
				prvs.PRVS_NAME	
			FROM oms_PRVS prvs WITH (NOLOCK)
				INNER JOIN hlt_DocPRVD docPRVD  WITH(NOLOCK) 
					ON docPRVD.rf_PRVSID = prvs.PRVSID
				INNER JOIN hlt_DoctorTimeTable dtt  WITH(NOLOCK) 
					ON dtt.rf_DocPRVDID = docPRVD.docPRVDID	
				INNER JOIN oms_Department dep  WITH(NOLOCK) 
					ON dep.DepartmentID = 	docPRVD.rf_DepartmentID 
				INNER JOIN oms_LPU lpu  WITH(NOLOCK) 
					ON dep.rf_LPUID = lpu.LPUID and lpu.MCOD like @MCOD
			WHERE prvs.PRVSID > 0
			AND docPRVD.docPRVDID > 0
			AND docPRVD.inTime = 1
			AND dtt.DoctorTimeTableID > 0
			AND dtt.Date BETWEEN @dateA AND @dateB			
		) t1
	LEFT JOIN
		(			
				SELECT 
					docPRVD.rf_PRVSID as PRVSID,	
					sum(dtt.PlanUE - dtt.UsedUE) as Tickets
				FROM hlt_DocPRVD docPRVD  WITH(NOLOCK) 	
					INNER JOIN oms_Department dep  WITH(NOLOCK) 
						ON dep.DepartmentID = 	docPRVD.rf_DepartmentID 
					INNER JOIN oms_LPU lpu  WITH(NOLOCK) 
						ON dep.rf_LPUID = lpu.LPUID and lpu.MCOD like @MCOD	
					INNER JOIN hlt_DoctorTimeTable dtt  WITH(NOLOCK) 
						ON dtt.rf_DocPRVDID = docPRVD.docPRVDID
					INNER JOIN hlt_DocBusyType dbt  WITH(NOLOCK) 
						ON dtt.rf_DocBusyType = dbt.DocBusyTypeID			
					LEFT JOIN hlt_DoctorVisitTable dvt  WITH(NOLOCK) 
						ON dvt.rf_DoctorTimeTableID = dtt.DoctorTimeTableID
				WHERE docPRVD.rf_PRVSID > 0
				AND docPRVD.docPRVDID > 0
				AND docPRVD.inTime = 1
				AND dtt.DoctorTimeTableID > 0
				AND dtt.Date BETWEEN @dateA AND @dateB
				AND dbt.TypeBusy > 0
				AND dtt.FlagAccess & @FlagAccess > 0	
				AND dtt.PlanUE > 0		
				GROUP BY docPRVD.rf_PRVSID
			
		)t2
		ON t1.PRVSID = t2.PRVSID
)
go

