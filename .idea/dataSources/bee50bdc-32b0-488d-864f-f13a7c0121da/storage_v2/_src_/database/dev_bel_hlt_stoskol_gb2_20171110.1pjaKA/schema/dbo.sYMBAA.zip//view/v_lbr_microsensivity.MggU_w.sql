CREATE VIEW [V_lbr_MicroSensivity] AS SELECT 
[hDED].[MicroSensivityID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_AntiFagID] as [rf_AntiFagID], 
[jT_lbr_AntiFag].[Name] as [SILENT_rf_AntiFagID], 
[hDED].[rf_ResearchResultMblUGUID] as [rf_ResearchResultMblUGUID], 
[hDED].[Sens] as [Sens], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [lbr_MicroSensivity] as [hDED]
INNER JOIN [lbr_AntiFag] as [jT_lbr_AntiFag] on [jT_lbr_AntiFag].[AntiFagID] = [hDED].[rf_AntiFagID]
go

