CREATE VIEW [V_oms_pr_InfoNote] AS SELECT 
[hDED].[pr_InfoNoteID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_pr_Person].[V_Person] as [V_V_Person], 
[jT_oms_pr_InfoType].[Name] as [V_InfoType], 
[jT_oms_pr_ProfType].[Name] as [V_PRType], 
[hDED].[rf_pr_ProfTypeID] as [rf_pr_ProfTypeID], 
[hDED].[rf_pr_InfoTypeID] as [rf_pr_InfoTypeID], 
[hDED].[rf_pr_ReestrID] as [rf_pr_ReestrID], 
[hDED].[rf_pr_PersonID] as [rf_pr_PersonID], 
[hDED].[Info_Date] as [Info_Date], 
[hDED].[Info_Type] as [Info_Type], 
[hDED].[ID_PAC] as [ID_PAC], 
[hDED].[isActual] as [isActual], 
[hDED].[Reject_DATE] as [Reject_DATE], 
[hDED].[Question_Date] as [Question_Date], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [oms_pr_InfoNote] as [hDED]
INNER JOIN [V_oms_pr_Person] as [jT_oms_pr_Person] on [jT_oms_pr_Person].[pr_PersonID] = [hDED].[rf_pr_PersonID]
INNER JOIN [oms_pr_InfoType] as [jT_oms_pr_InfoType] on [jT_oms_pr_InfoType].[pr_InfoTypeID] = [hDED].[rf_pr_InfoTypeID]
INNER JOIN [oms_pr_ProfType] as [jT_oms_pr_ProfType] on [jT_oms_pr_ProfType].[pr_ProfTypeID] = [hDED].[rf_pr_ProfTypeID]
go

