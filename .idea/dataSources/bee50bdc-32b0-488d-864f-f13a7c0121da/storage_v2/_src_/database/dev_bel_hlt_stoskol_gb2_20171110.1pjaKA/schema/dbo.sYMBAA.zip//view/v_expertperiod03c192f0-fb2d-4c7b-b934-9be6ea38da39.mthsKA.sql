CREATE view [V_ExpertPeriod03c192f0-fb2d-4c7b-b934-9be6ea38da39] as select * from [tmp_ExpertPeriod03c192f0-fb2d-4c7b-b934-9be6ea38da39]
go

