CREATE VIEW [V_oms_pr_ResourceInfo] AS SELECT 
[hDED].[pr_ResourceInfoID], [hDED].[x_Edition], [hDED].[x_Status], 
((isnull(((select top 1 name from oms_pr_Hour where pr_HourID>0 and pr_HourID=rf_pr_HourBeginID)+'-'+(select top 1 name from oms_pr_Hour where pr_HourID>0 and pr_HourID=rf_pr_HourEndID)),''))) as [V_Info], 
[jT_oms_pr_LPU].[V_M_NAMES] as [V_V_M_NAMES], 
[jT_oms_pr_ProfType].[Name] as [V_Name], 
[jT_oms_pr_WeekDay].[Name] as [V_NameDay], 
[hDED].[rf_pr_ProfTypeID] as [rf_pr_ProfTypeID], 
[hDED].[rf_pr_WeekDayID] as [rf_pr_WeekDayID], 
[hDED].[rf_pr_LPUID] as [rf_pr_LPUID], 
[hDED].[rf_pr_HourBeginID] as [rf_pr_HourBeginID], 
[hDED].[rf_pr_HourEndID] as [rf_pr_HourEndID], 
[hDED].[TypeInfo] as [TypeInfo], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [oms_pr_ResourceInfo] as [hDED]
INNER JOIN [V_oms_pr_LPU] as [jT_oms_pr_LPU] on [jT_oms_pr_LPU].[pr_LPUID] = [hDED].[rf_pr_LPUID]
INNER JOIN [oms_pr_ProfType] as [jT_oms_pr_ProfType] on [jT_oms_pr_ProfType].[pr_ProfTypeID] = [hDED].[rf_pr_ProfTypeID]
INNER JOIN [oms_pr_WeekDay] as [jT_oms_pr_WeekDay] on [jT_oms_pr_WeekDay].[pr_WeekDayID] = [hDED].[rf_pr_WeekDayID]
go

