CREATE VIEW [V_hlt_disp_Type] AS SELECT 
[hDED].[disp_TypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DispTypeGuid] as [rf_DispTypeGuid], 
[jT_hlt_disp_Type].[Name] as [SILENT_rf_DispTypeGuid], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_Type] as [hDED]
INNER JOIN [hlt_disp_Type] as [jT_hlt_disp_Type] on [jT_hlt_disp_Type].[Guid] = [hDED].[rf_DispTypeGuid]
go

