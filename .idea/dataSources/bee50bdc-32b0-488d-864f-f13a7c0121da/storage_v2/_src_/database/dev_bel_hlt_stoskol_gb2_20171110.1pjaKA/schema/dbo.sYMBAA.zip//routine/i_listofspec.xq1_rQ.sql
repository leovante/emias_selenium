


-- =============================================
-- Author:		Сергей Шумаков
-- Create date: 2010/09/06
-- Description:	Инфомат. Возвращает список специальностей.
-- =============================================
CREATE FUNCTION [dbo].[I_ListOfSpec] 
(		
	@date_a datetime, 
	@date_b datetime, 
	@dbt int,
	@mkabid int
)
RETURNS TABLE 
AS
RETURN 
(
	with schedul(prvsid, planUE, NormaUE) AS /*Доступные специальности*/
	(
		select t.DPRVD_PRVSID, sum(t.DTT_PlanUE), sum(t.DVT_NormaUE)
		from 
		(
			select DPRVD_PRVSID, max(DTT_PlanUE) as DTT_PlanUE, isnull(sum(DVT_NormaUE),0) as DVT_NormaUE
				from IV_Schedul 
				where   UchastokID is null /*специалистов (не участковых)*/        
						and datepart(hh, dtt_Begin_Time) <> 0 /* отсекаем записи других типов */ 
						and DPRVD_PRVSID is not null
						and dtt_date between @date_a and @date_b
						and DocBusyTypeID = @dbt /**/		        
						and (dtt_FlagAccess & 4) > 0 /*фильтр по правам доступа	*/
				group by DoctorTimeTableID, DPRVD_PRVSID 
		) t
		group by DPRVD_PRVSID
	)
	select 
		prvs.prvsid, 
		prvs.prvs_name,
		case when (schedul.planUE > schedul.NormaUE) then 1 else 0 end as Active
	from hlt_DocPrVd dprvd	
	inner join oms_PRVS prvs
	on dprvd.rf_PRVSID = prvs.PRVSID and dprvd.InTime=1
	left join schedul on prvs.prvsid = schedul.prvsid
	where prvs.prvsid > 0 
	group by prvs.prvsid, prvs.prvs_name, schedul.prvsid, schedul.planUE, schedul.NormaUE 
)
go

