
CREATE PROCEDURE [dbo].[Oms_omsUpdateRef]
	(
		@Code int				
	)
AS
	SET NOCOUNT ON
-----------------------------------------------------------------------------------------------------
BEGIN TRY 
declare @Field varchar(100)
declare @SQL   varchar(max)
declare @rSQL   varchar(max)
    Declare cursor_ cursor SCROLL Local Read_ONLY FOR
		Select x_DocElemDef.[Name],Replace(Query_Dbf,'"','''')
from x_DocElemDef
				inner join x_DocTypeDef on x_DocElemDef.DocTypeDefID=x_DocTypeDef.DocTypeDefID
                inner join x_DocTypeDef dd on x_DocElemDef.LinkedDocTypeDefId = dd.DocTypeDefID
				inner join tmp_LoadPrepare on tableName =dd.HeadTable
				inner join oms_LoadNsiTable on x_DocTypeDef.headtable=Table_Name
				--inner join inf_tabl on tableName = table_n
				where (LinkedDocTypeDefId>0) 
				and Code =@Code
				and ElemType < '3' 
	OPEN cursor_
	FETCH First FROM cursor_  INTO  @Field,@SQL
    WHILE @@FETCH_STATUS = 0
	Begin

set @rSQL = Reverse(@SQL)

set @rSQL= Substring( @rSql, CharIndex(Reverse(@Field),@rSQL,1),Len(@rSQL)-CharIndex(Reverse(@Field),@rSQL,1)+1)


set @rSQL= Substring( @rSql, 1, CharIndex('llunsi',@rSQL,1)+5)
set @rSQL= 'update rd_'+Convert(varchar,@Code)+' set ['+@Field+']='+Replace(Replace (Replace (Reverse(@rSQL), ' as ',''),@Field,''),'t.','t.dbf_')+' from rd_'+Convert(varchar,@Code) +' t where '+@Field+' =0'

EXECUTE sp_executesql @rSQL

	FETCH NEXT FROM cursor_
		INTO  @Field,@SQL
	END
	Close cursor_;
	DEALLOCATE cursor_;

END TRY 
BEGIN CATCH 

END CATCH;
go

