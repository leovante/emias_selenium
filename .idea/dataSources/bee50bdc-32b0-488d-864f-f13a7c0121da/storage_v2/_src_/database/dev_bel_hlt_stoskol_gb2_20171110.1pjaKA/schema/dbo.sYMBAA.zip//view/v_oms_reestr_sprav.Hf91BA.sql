CREATE VIEW [V_oms_reestr_Sprav] AS SELECT 
[hDED].[reestr_SpravID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Num] as [Num], 
[hDED].[Date_Create] as [Date_Create], 
[hDED].[OGRN] as [OGRN], 
[hDED].[GUID] as [GUID]
FROM [oms_reestr_Sprav] as [hDED]
go

