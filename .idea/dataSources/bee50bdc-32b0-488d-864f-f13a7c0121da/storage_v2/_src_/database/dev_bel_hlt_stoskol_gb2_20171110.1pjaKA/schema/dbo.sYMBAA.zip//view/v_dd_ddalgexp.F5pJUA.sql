CREATE VIEW [V_dd_DDAlgExp] AS SELECT 
[hDED].[DDAlgExpID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[hDED].[rf_DDErrorCodeGUID] as [rf_DDErrorCodeGUID], 
[hDED].[rf_DDStatusAlgID] as [rf_DDStatusAlgID], 
[hDED].[NAME] as [NAME], 
[hDED].[Source] as [Source], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDAlgExp] as [hDED]
go

