CREATE VIEW [V_oms_OKSM] AS SELECT 
[hDED].[OKSMID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[NameSM] as [NameSM], 
[hDED].[NameFullSM] as [NameFullSM], 
[hDED].[KSM] as [KSM], 
[hDED].[ALFA2] as [ALFA2], 
[hDED].[ALFA3] as [ALFA3], 
[hDED].[Rem] as [Rem], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_OKSM] as [hDED]
go

