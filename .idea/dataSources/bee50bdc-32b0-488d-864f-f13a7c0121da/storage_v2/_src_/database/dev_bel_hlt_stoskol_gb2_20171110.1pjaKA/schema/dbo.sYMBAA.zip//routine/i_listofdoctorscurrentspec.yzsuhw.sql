
-- =============================================
-- Author:		Сергей Шумаков
-- Create date: 2010/09/06
-- Description:	Инфомат. Возвращает список врачей.
-- =============================================
CREATE FUNCTION [dbo].[I_ListOfDoctorsCurrentSpec] 
(		
	@date_a datetime, 
	@date_b datetime, 
	@dbt int,
	@mkabid int,
	@prvs int
)
RETURNS TABLE 
AS
RETURN 
(
	/* Получаем врачей по специальности */

	with schedul(DocPRVDID, PlanUE, NormaUE) AS /*Доступные врачи*/
	(
		select  DTT_DocPRVDID, sum(DTT_PlanUE) as DTT_PlanUE, sum(DVT_NormaUE) as DVT_NormaUE
		from 
		(
			select  DTT_DocPRVDID, max(DTT_PlanUE) as DTT_PlanUE, isnull(sum(DVT_NormaUE),0) as DVT_NormaUE
			from IV_Schedul 
			where   UchastokID is null /*специалистов (не участковых)*/        
					and datepart(hh, dtt_Begin_Time) <> 0 /* отсекаем записи других типов */ 
					and DTT_DocPRVDID is not null
					and DTT_DocPRVDID != 0
					and dtt_date between @date_a and @date_b /**/
					and DocBusyTypeID = @dbt /**/	
					and DPRVD_PRVSID = @prvs	/**/        
					and (dtt_FlagAccess & 4) > 0 /*фильтр по правам доступа	*/
			group by DoctorTimeTableID, DTT_DocPRVDID
		)t group by  DTT_DocPRVDID
	)
	select prvd.DocPRVDID, 
			case
		 when (prvd.isSpecial = 1) and 
		 ((select top 1 case valueStr when '' then 0 when '0' then 0 else 1 end from x_userSettings where property like 'Диспансерное наблюдение') = 1) AND
		 NOT EXISTS
				(
					SELECT TOP 1 1 from hlt_RegMedicalCheck			
					WHERE rf_MKABID = @mkabid 
					AND getdate() BETWEEN dateRegistration AND DateOff 
					AND rf_PRVSID = prvd.rf_PRVSID
				)
		then 0
		when (planUE > NormaUE) then 1 else 0 end as Active
	from hlt_DocPrVd prvd	
	left join schedul on prvd.DocPRVDID = schedul.DocPRVDID
	where prvd.DocPRVDID > 0 /*and doc.IsDoctor=1 */ and prvd.InTime = 1
	and prvd.rf_PrVsID = @prvs
	group by prvd.DocPRVDID, prvd.rf_PRVSID, prvd.isSpecial, PlanUE, NormaUE
)
go

