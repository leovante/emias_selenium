
CREATE FUNCTION [dbo].[CheckSSValid]
(
	@SS varchar(15)
)
RETURNS int
AS
BEGIN
	DECLARE @valid int
	set @valid=(select case when
			((((len(@SS)= 14) and ((substring(@SS,1,1)*9+substring(@SS,2,1)*8+ substring(@SS,3,1)*7+ substring(@SS,5,1)*6+substring(@SS,6,1)*5+ substring(@SS,7,1)*4+ substring(@SS,9,1)*3+substring(@SS,10,1)*2+ substring(@SS,11,1))%101%100 = substring(@SS,13,2))) or
			((len(@SS)= 11) and ((substring(@SS,1,1)*9+substring(@SS,2,1)*8+ substring(@SS,3,1)*7+ substring(@SS,4,1)*6+substring(@SS,5,1)*5+ substring(@SS,6,1)*4+ substring(@SS,7,1)*3+substring(@SS,8,1)*2+ substring(@SS,9,1))%101%100 = substring(@SS,10,2))))
			and @SS != '000-000-000 00')		
			then 1 
			else 0 end)	
	RETURN @valid
END
go

