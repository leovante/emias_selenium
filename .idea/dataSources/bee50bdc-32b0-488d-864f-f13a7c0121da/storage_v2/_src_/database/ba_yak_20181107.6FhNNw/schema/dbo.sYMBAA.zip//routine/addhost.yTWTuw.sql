-- =============================================
-- Create date: 18/09/2012
-- Description:	вставка нового хоста
-- =============================================
CREATE PROCEDURE AddHost
	@IDHost int, @GUID uniqueidentifier,@Name varchar(200),@Dec varchar(200)
AS
BEGIN

		--вставка нового хоста
	SET IDENTITY_INSERT x_host ON; 
	insert into x_host (HostID, HostGuid, HostTitle, HostDescription) 
	values (@IDHost,@GUID,@Name,@Dec)
	--values (@IDHost, '<ГУИД хоста>', 
	--'<Заголовок хоста (Сокращенное имя отделения, например, ТО (терапвет. отд))>','<Описание (Полное имя отделения)>'); 
	SET IDENTITY_INSERT  x_host OFF;

	--изменение функции обозначающей свой хост
	declare @sql nvarchar(max)
	set @sql='
		ALTER FUNCTION [dbo].[GetSelfHost]()
										RETURNS int
										AS
										BEGIN
										DECLARE @hostID int
										set @hostID ='+convert(varchar(20),@IDHost)+'
										RETURN (@hostID)
										END
										'
						
	exec (@sql)

	---------------------------------------------------------------------------------------
	-- проставка дефолтов
	declare @useExec bit
	set @useExec = 1

	declare @virtualHost varchar(50)
	set @virtualHost = 999

	declare @dd uniqueidentifier
	declare @ddht varchar(50)
	declare @ddid int
	declare @ddpk varchar(50)

	declare @dedid int
	declare @dedfn varchar(50)
	declare @lddid int
	declare @lddht varchar(50)
	declare @ldd uniqueidentifier 

	declare @tmp varchar(5000)
	declare @defaultName varchar(500)		
	if exists (select * from syscolumns where id = object_id(N'GetSelfHost'))
	begin
		if dbo.GetSelfHost() > 0
		begin
			
			declare @host varchar(50)
			set @host = dbo.GetSelfHost()		
			
			declare cur cursor read_only for
				select d.GUID, d.HeadTable, d.DocTypeDefID, d.PK_Name 
				from x_DocTypeDef d where d.DocTypeDefID > 0 
				
			open cur
			fetch next from cur into @dd, @ddht, @ddid, @ddpk
			while @@fetch_status = 0
			begin
			
				if dbo.IsDO(@DD) >= 1
				begin
					if dbo.IsVirtual(@dd) = 1
					begin
						print '---------------------Виртуальный документ ' + @ddht + '---------------------'
					end
					else
					begin					
						print '---------------------Обычный документ ' + @ddht + '---------------------'
						set @defaultName = dbo.GetDefaultName(@ddht, 'HOST' + @ddpk)
						set @tmp = 'alter table ' + @ddht + ' drop constraint ' + @defaultName
						print '-->'+@tmp
						if @useExec = 1 exec(@tmp)
						set @tmp = 'alter table ' + @ddht + ' add constraint ' + @defaultName  + ' default ' + @host + ' for HOST' + @ddpk
						print '-->'+@tmp
						if @useExec = 1 exec(@tmp)					
						declare cur2 cursor read_only for 
							select e.DocElemDefID, e.FieldName, e.LinkedDocTypeDefID, d.HeadTable, d.GUID	
							from x_DocElemDef e
							inner join x_DocTypeDef d on e.LinkedDocTypeDefID = d.DocTypeDefID
							where e.DocTypeDefID = @ddid and e.ElemType = 2 and e.LinkedDocTypeDefID > 0
						open cur2
								
						fetch next from cur2 into @dedid, @dedfn, @lddid, @lddht, @ldd
						while @@fetch_status = 0
						begin				
							if dbo.IsDO(@ldd) >= 1
							begin
								
								if dbo.IsVirtual(@ldd) = 1
								begin
									print 'ссылка на виртуальный документ из ' + @ddht + ' в ' + @lddht								
									set @defaultName = dbo.GetDefaultName(@ddht, @dedfn + 'Host')
									set @tmp = 'alter table ' + @ddht + ' drop constraint ' + @defaultName
									print '-->'+@tmp
									if @useExec = 1 exec(@tmp)
									set @tmp = 'alter table ' + @ddht + ' add constraint ' + @defaultName  + ' default ' + @virtualHost + ' for ' + @dedfn + 'Host'
									print '-->'+@tmp
									if @useExec = 1 exec(@tmp)
								end							
								else
								begin
									print 'ссылка на обычный документ из ' + @ddht + ' в ' + @lddht
									set @defaultName = dbo.GetDefaultName(@ddht, @dedfn + 'Host')
									set @tmp = 'alter table ' + @ddht + ' drop constraint ' + @defaultName
									print '-->'+@tmp
									if @useExec = 1 exec(@tmp)
									set @tmp = 'alter table ' + @ddht + ' add constraint ' + @defaultName  + ' default ' + @host + ' for ' + @dedfn + 'Host'
									print '-->'+@tmp
									if @useExec = 1 exec(@tmp)
								end
							end
							fetch next from cur2 into @dedid, @dedfn, @lddid, @lddht, @ldd
						end
								
						close cur2			
						deallocate cur2
					end
				end
				else
				begin									
						print '---------------------Обычный документ ' + @ddht + '---------------------'
						set @defaultName = dbo.GetDefaultName(@ddht, 'HOST' + @ddpk)
						set @tmp = 'alter table ' + @ddht + ' drop constraint ' + @defaultName
						print '-->'+@tmp
						if @useExec = 1 exec(@tmp)
						set @tmp = 'alter table ' + @ddht + ' add constraint ' + @defaultName  + ' default ' + @host + ' for HOST' + @ddpk
						print '-->'+@tmp
						if @useExec = 1 exec(@tmp)
						-- переберём все элементы
						declare cur2 cursor read_only for 
							select e.DocElemDefID, e.FieldName, e.LinkedDocTypeDefID, d.HeadTable, d.GUID	
							from x_DocElemDef e
							inner join x_DocTypeDef d on e.LinkedDocTypeDefID = d.DocTypeDefID
							where e.DocTypeDefID = @ddid and e.ElemType = 2 and e.LinkedDocTypeDefID > 0
						open cur2
						fetch next from cur2 into @dedid, @dedfn, @lddid, @lddht, @ldd
						while @@fetch_status = 0
						begin				
							if dbo.IsDO(@ldd) >= 1
							begin							
								if dbo.IsVirtual(@ldd) = 1
								begin
									print 'ссылка на виртуальный документ из ' + @ddht + ' в ' + @lddht
									-- Выставим дефалты	
									set @defaultName = dbo.GetDefaultName(@ddht, @dedfn + 'Host')
									set @tmp = 'alter table ' + @ddht + ' drop constraint ' + @defaultName
									print '-->'+@tmp
									if @useExec = 1 exec(@tmp)
									set @tmp = 'alter table ' + @ddht + ' add constraint ' + @defaultName  + ' default ' + @virtualHost + ' for ' + @dedfn + 'Host'
									print '-->'+@tmp
									if @useExec = 1 exec(@tmp)
								end							
								else
								begin
									print 'ссылка на обычный документ из ' + @ddht + ' в ' + @lddht
									set @defaultName = dbo.GetDefaultName(@ddht, @dedfn + 'Host')
									set @tmp = 'alter table ' + @ddht + ' drop constraint ' + @defaultName
									print '-->'+@tmp
									if @useExec = 1 exec(@tmp)
									set @tmp = 'alter table ' + @ddht + ' add constraint ' + @defaultName  + ' default ' + @host + ' for ' + @dedfn + 'Host'
									print '-->'+@tmp
									if @useExec = 1 exec(@tmp)
								end
							end
							fetch next from cur2 into @dedid, @dedfn, @lddid, @lddht, @ldd
						end							

						close cur2			
						deallocate cur2
							
				end		
				
				
				fetch next from cur into @dd, @ddht, @ddid, @ddpk
			end
			close cur
			deallocate cur
			
		end
		else
			print 'База данных не была инициирована. Выполнение скрипта не возможно.'		
	end
	else
		print 'База данных не была инициирована. Выполнение скрипта не возможно.'


	-- установка индексов для ДО таблиц	
	--declare @virtualHost int 
	set @virtualHost = 0
	set @virtualHost = dbo.GetSelfHost()

	declare @ttt varchar(5000)
	declare @dt uniqueidentifier
	declare @dtFlags int


	declare @tableName varchar(50)
	declare @idname varchar(50)
	--declare @defaultName varchar(50)
	declare @defaultHost varchar(50)
	declare @dtdid int
	declare @ldtid int
	declare @elName varchar(50)

	set @defaultHost = @IDHost

	declare cur cursor read_only for select DocTypeDef, flags from x_stdo where hostid = 0 
	and DocTypeDef <> '00000000-0000-0000-0000-000000000000'

	open cur

	fetch next from cur into @dt, @dtFlags
	while @@fetch_status = 0
	begin
		print '---------------------------------------------'

		
		set @tableName = (select top 1 HeadTable from x_DocTypeDef where GUID = @dt)
		set @dtdid = (select top 1 DocTypeDefID from x_DocTypeDef where GUID = @dt)
		set @idname = (select top 1 PK_Name from x_DocTypeDef where GUID = @dt)
		set @defaultName = (

						select top 1 d.name from sysobjects d
							inner join sysobjects t on t.id = d.parent_obj
							inner join syscolumns c on c.id = t.id and c.cdefault = d.id
							where  d.type = 'D' and t.name = @tableName and c.name = 'HOST' + @idname
							)
		print 'Обрабатывается документ [' + @tableName + ']'
		print 'GUID = {' + cast(@dt as varchar(50)) + '}'
		

		print ('SET IDENTITY_INSERT ' + @tableName+' ON; if not exists(select * from ' + @tableName + ' where '+@idname + '=0 and HOST'+ @idname + ' = '+@defaultHost+') insert into ' + @tableName+' ('+@idname+',HOST'+@idname+')values(0, '+ @defaultHost+'); SET IDENTITY_INSERT ' + @tableName+' OFF;')
		exec ('SET IDENTITY_INSERT ' + @tableName+' ON; if not exists(select * from ' + @tableName + ' where '+@idname + '=0 and HOST'+ @idname + ' = '+@defaultHost+') insert into ' + @tableName+' ('+@idname+',HOST'+@idname+')values(0, '+ @defaultHost+'); SET IDENTITY_INSERT ' + @tableName+' OFF;')
		print ('SET IDENTITY_INSERT ' + @tableName+' ON; if not exists(select * from ' + @tableName + ' where '+@idname + '=0 and HOST'+ @idname + ' = 0) insert into ' + @tableName+' ('+@idname+',HOST'+@idname+')values(0, 0); SET IDENTITY_INSERT ' + @tableName+' OFF;')
		exec ('SET IDENTITY_INSERT ' + @tableName+' ON; if not exists(select * from ' + @tableName + ' where '+@idname + '=0 and HOST'+ @idname + ' = 0) insert into ' + @tableName+' ('+@idname+',HOST'+@idname+')values(0, 0); SET IDENTITY_INSERT ' + @tableName+' OFF;')
		
		fetch next from cur into @dt, @dtFlags
	end

	close cur
	deallocate cur	
	
END
go

