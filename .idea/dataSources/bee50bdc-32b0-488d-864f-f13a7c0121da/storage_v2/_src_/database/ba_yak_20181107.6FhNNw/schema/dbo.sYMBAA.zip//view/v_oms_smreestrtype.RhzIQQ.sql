CREATE VIEW [V_oms_SMReestrType] AS SELECT 
[hDED].[SMReestrTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[SMReestrTypeCode] as [SMReestrTypeCode], 
[hDED].[SMReestrTypeName] as [SMReestrTypeName], 
[hDED].[Flags] as [Flags]
FROM [oms_SMReestrType] as [hDED]
go

