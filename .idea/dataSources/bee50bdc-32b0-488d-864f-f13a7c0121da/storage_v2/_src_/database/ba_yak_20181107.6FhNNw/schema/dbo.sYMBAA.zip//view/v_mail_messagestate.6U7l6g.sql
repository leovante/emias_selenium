CREATE VIEW [V_mail_MessageState] AS SELECT 
[hDED].[MessageStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[FriendlyName] as [FriendlyName]
FROM [mail_MessageState] as [hDED]
go

