CREATE VIEW [V_ras_NarcLSType] AS SELECT 
[hDED].[NarcLSTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [ras_NarcLSType] as [hDED]
go

