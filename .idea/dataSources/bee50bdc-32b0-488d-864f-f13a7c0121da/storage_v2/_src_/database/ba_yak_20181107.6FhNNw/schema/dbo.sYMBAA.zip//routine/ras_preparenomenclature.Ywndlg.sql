
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE ras_PrepareNomenclature 
		@NomkLsCode bigint
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @lsID int; --ID ЛС с положительным кодом
	select @lsID = LSID from oms_LS where NOMK_LS = @NomkLsCode;

	if (@lsID is not null) 
	begin

		declare @plusNomenCount int; --Количство эталонных номенклатур ЛС с положительным кодом
		select @plusNomenCount = COUNT(1) from ras_Nomenclature where rf_LSID = @lsID and COD_RAS = CONVERT(varchar(max), @NomkLsCode);
		
		
		--НЕТ ЭТАЛОННОЙ НОМЕНКЛАТУРЫ ДЛЯ НОВОГО ЛС
		if (@plusNomenCount = 0)
		begin
			--СОЗДАЁМ НОМЕНКЛАТУРУ
			INSERT INTO [ras_Nomenclature]
			([Name], [rf_NDSID],[Cod_RAS],[Cod_Nom],[rf_ProducerID],[rf_NarcLSTypeID],[rf_LFID]
			,[rf_DLSID],rf_LSID,rf_MLFID, M_LF,rf_VLFID, V_LF,[MSG_TEXT],[Date_B],[Date_E],[rf_SpecificID],[DOZ_ME],[Severability1],[Severability2])
			Select  distinct ltrim(rtrim(oms_LS.NAME_MED)) as [Name], 
				4 as rf_NDSID, 
				cast(NOMK_LS as varchar(max)) as Cod_Ras,
				cast(NOMK_LS as varchar(max)) as Cod_Nom, 			
				isnull((Select top 1 ProducerID from ras_Producer where [Name]=Name_FCT ),0) as rf_ProducerID,
				(Select top 1 NarcLSTypeID from ras_NarcLSType where ras_NarcLSType.Code=oms_NarcType.Code) as rf_NarcLSTypeID,
				oms_LS.rf_LFID, oms_LS.rf_DLSID, oms_LS.LSID, oms_LS.rf_MLFID, oms_LS.M_LF, oms_LS.rf_VLFID, oms_LS.V_LF,
				oms_LS.MSG_text, oms_LS.Date_B as Date_B, oms_LS.Date_E as Date_E,
				ISNULL(
					(select top 1 SpecificID from ras_Specific where ras_Specific.Code=cast(oms_Spec.Code as varchar)),
					(select top 1 SpecificID from ras_Specific where CODE = '0')) as rf_SpecificID,
				1,
					isnull( case rls_Nomen.DrugsInpPack when 0 then 1 else rls_Nomen.DrugsInpPack end, case oms_LS.N_FV when 0 then 1 else oms_LS.N_FV end) as [Severability1],
					isnull( case PPackInUPack when 0 then 1 else PPackInUPack end *  
							case UPackInSPack when 0 then 1 else UPackInSPack end , 1 ) as [Severability2] 
			
				from oms_LS
				left join rls_Nomen on oms_LS.RlsNomenUid = rls_Nomen.UID and oms_LS.RlsNomenUid <> '00000000-0000-0000-0000-000000000000'
				inner join oms_NarcType on NarcTypeID=rf_NarcTypeID
				inner join oms_Spec on SpecID=rf_SpecID
				inner join oms_TRName on trnameID=rf_trnameID
				inner join oms_LF on LFID=rf_LFID
				inner join oms_DLS on DLSID=rf_DLSID
				inner join oms_MNName on mnnameID=rf_mnnameID
				left outer join ras_nomenclature  on cast(oms_LS.NOMK_LS as varchar(max)) = ras_nomenclature.Cod_RAS
				where nomenclatureID is null 
					and oms_LS.Date_E > getDate() and oms_LS.LSID = @lsID
		end
		else
		begin
			--ОБНОВЛЯЕМ ЭТАЛОННУЮ НОМЕНКЛАТУРУ
			with NomenInfo
			([Name], [rf_NDSID],[Cod_RAS],[Cod_Nom],[rf_ProducerID],[rf_NarcLSTypeID],[rf_LFID]
			,[rf_DLSID],rf_LSID,rf_MLFID, M_LF,rf_VLFID, V_LF,[MSG_TEXT],[Date_B],[Date_E],[rf_SpecificID],
			[DOZ_ME],[Severability1],[Severability2])
			as
			(								
			Select  distinct 
				ltrim(rtrim(oms_LS.NAME_MED)) as [Name], 
				4 as rf_NDSID, 
				cast(NOMK_LS as varchar(max)) as Cod_Ras,
				cast(NOMK_LS as varchar(max)) as Cod_Nom,			
				isnull((Select top 1 ProducerID from ras_Producer where [Name]=Name_FCT ),0) as rf_ProducerID,
				(Select top 1 NarcLSTypeID from ras_NarcLSType where ras_NarcLSType.Code=oms_NarcType.Code) as rf_NarcLSTypeID,
				oms_LS.rf_LFID,	oms_LS.rf_DLSID, oms_LS.LSID, oms_LS.rf_MLFID, oms_LS.M_LF,	oms_LS.rf_VLFID, oms_LS.V_LF, oms_LS.MSG_text,
				oms_LS.Date_B as Date_B, oms_LS.Date_E as Date_E,
				ISNULL(
					(select top 1 SpecificID from ras_Specific where ras_Specific.Code=cast(oms_Spec.Code as varchar)),
					(select top 1 SpecificID from ras_Specific where CODE = '0')) as rf_SpecificID,
				1,
					isnull( case rls_Nomen.DrugsInpPack when 0 then 1 else rls_Nomen.DrugsInpPack end, case oms_LS.N_FV when 0 then 1 else oms_LS.N_FV end) as [Severability1],
					isnull( case PPackInUPack when 0 then 1 else PPackInUPack end *  
							case UPackInSPack when 0 then 1 else UPackInSPack end , 1 ) as [Severability2] 
			
				from oms_LS
				left join rls_Nomen on oms_LS.RlsNomenUid = rls_Nomen.UID and oms_LS.RlsNomenUid <> '00000000-0000-0000-0000-000000000000'
				inner join oms_NarcType on NarcTypeID=rf_NarcTypeID
				inner join oms_Spec on SpecID=rf_SpecID
				inner join oms_TRName on trnameID=rf_trnameID
				inner join oms_LF on LFID=rf_LFID
				inner join oms_DLS on DLSID=rf_DLSID
				inner join oms_MNName on mnnameID=rf_mnnameID
				where oms_LS.Date_E > getDate() 
			)

			update ras_Nomenclature
			set 
				ras_Nomenclature.Name = NomenInfo.Name,
				ras_Nomenclature.[rf_NDSID] = NomenInfo.[rf_NDSID],
				ras_Nomenclature.[Cod_Nom] = NomenInfo.[Cod_Nom],
				ras_Nomenclature.[rf_ProducerID] = NomenInfo.[rf_ProducerID],
				ras_Nomenclature.[rf_NarcLSTypeID] = NomenInfo.[rf_NarcLSTypeID],
				ras_Nomenclature.[rf_LFID] = NomenInfo.[rf_LFID],
				ras_Nomenclature.[rf_DLSID] = NomenInfo.[rf_DLSID],
				ras_Nomenclature.rf_LSID = NomenInfo.rf_LSID,
				ras_Nomenclature.rf_MLFID = NomenInfo.rf_MLFID,
				ras_Nomenclature.M_LF = NomenInfo.M_LF,
				ras_Nomenclature.rf_VLFID = NomenInfo.rf_VLFID,
				ras_Nomenclature.V_LF = NomenInfo.V_LF,
				ras_Nomenclature.[MSG_TEXT] = NomenInfo.[MSG_TEXT],
				ras_Nomenclature.[Date_B] = NomenInfo.[Date_B],
				ras_Nomenclature.[Date_E] = NomenInfo.[Date_E],
				ras_Nomenclature.[rf_SpecificID] = NomenInfo.[rf_SpecificID],
				ras_Nomenclature.[DOZ_ME] = NomenInfo.[DOZ_ME],
				ras_Nomenclature.[Severability1] = NomenInfo.[Severability1],
				ras_Nomenclature.[Severability2] = NomenInfo.[Severability2]
			from NomenInfo
			where ras_Nomenclature.Cod_RAS = NomenInfo.Cod_RAS and ras_Nomenclature.Cod_RAS = CONVERT(varchar(max), @NomkLsCode);
		end
	end

	set nocount off
END
go

