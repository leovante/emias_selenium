CREATE VIEW [V_ras_StatePosDistrib] AS SELECT 
[hDED].[StatePosDistribID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [ras_StatePosDistrib] as [hDED]
go

