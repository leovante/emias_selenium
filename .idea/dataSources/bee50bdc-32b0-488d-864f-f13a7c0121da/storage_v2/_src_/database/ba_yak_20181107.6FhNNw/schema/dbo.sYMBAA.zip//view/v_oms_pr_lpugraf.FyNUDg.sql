CREATE VIEW [V_oms_pr_LPUGraf] AS SELECT 
[hDED].[pr_LPUGrafID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_pr_LPU].[V_M_NAMES] as [V_V_M_NAMES], 
[hDED].[rf_pr_WeekDayID] as [rf_pr_WeekDayID], 
[hDED].[rf_pr_LPUID] as [rf_pr_LPUID], 
[hDED].[HourOpen] as [HourOpen], 
[hDED].[HourClose] as [HourClose]
FROM [oms_pr_LPUGraf] as [hDED]
INNER JOIN [V_oms_pr_LPU] as [jT_oms_pr_LPU] on [jT_oms_pr_LPU].[pr_LPUID] = [hDED].[rf_pr_LPUID]
go

