CREATE VIEW [V_oms_Department] AS SELECT 
[hDED].[DepartmentID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_LPU].[C_OGRN] as [V_C_OGRN], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_kl_AgeGroupID] as [rf_kl_AgeGroupID], 
[jT_oms_kl_AgeGroup].[Name] as [SILENT_rf_kl_AgeGroupID], 
[hDED].[rf_AddressID] as [rf_AddressID], 
[jT_kla_Address].[CODE] as [SILENT_rf_AddressID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[DepartmentCODE] as [DepartmentCODE], 
[hDED].[DepartmentNAME] as [DepartmentNAME], 
[hDED].[ZAVPCOD] as [ZAVPCOD], 
[hDED].[ZAVFIO] as [ZAVFIO], 
[hDED].[Rem] as [Rem], 
[hDED].[GUIDDepartment] as [GUIDDepartment], 
[hDED].[N_OTD] as [N_OTD], 
[hDED].[Code_Department] as [Code_Department], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[FAX] as [FAX], 
[hDED].[CodeKLADR] as [CodeKLADR], 
[hDED].[Tel] as [Tel]
FROM [oms_Department] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_kl_AgeGroup] as [jT_oms_kl_AgeGroup] on [jT_oms_kl_AgeGroup].[kl_AgeGroupID] = [hDED].[rf_kl_AgeGroupID]
INNER JOIN [kla_Address] as [jT_kla_Address] on [jT_kla_Address].[AddressID] = [hDED].[rf_AddressID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
go

