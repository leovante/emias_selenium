CREATE VIEW [V_ras_Producer] AS SELECT 
[hDED].[ProducerID], [hDED].[HostProducerID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_OrganisationIDHost] as [rf_OrganisationIDHost], 
[hDED].[rf_CountryID] as [rf_CountryID], 
[hDED].[rf_CountryIDHost] as [rf_CountryIDHost], 
[jT_ras_Country].[Code] as [SILENT_rf_CountryID], 
[hDED].[Name] as [Name]
FROM [ras_Producer] as [hDED]
INNER JOIN [ras_Country] as [jT_ras_Country] on [jT_ras_Country].[CountryID] = [hDED].[rf_CountryID] AND  [jT_ras_Country].[HostCountryID] = [hDED].[rf_CountryIDHost]
go

