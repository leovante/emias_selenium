
CREATE PROCEDURE [dbo].[ChangeLsAu_ClsGuid](@oldCode bigint, @newCode bigint,  @clsGuid uniqueidentifier)
AS
BEGIN

	DECLARE @clsId int

	if ( (select count(distinct CLSID) from oms_CLS where GUIDCLS = @clsGuid group by GUIDCLS) = 1)
	begin

		select top 1 @clsId =  CLSID from oms_CLS where GUIDCLS = @clsGuid

		declare @plusID int; --ID ЛС с положительным кодом
		select @plusID = LSID from oms_LS where NOMK_LS = @oldCode;
		declare @minusID int; --ID ЛС с отрицательным кодом
		select @minusID = LSID from oms_LS where NOMK_LS = @newCode;


		exec [dbo].[ChangeLsAu_Cls] @plusID, @oldCode, @minusID , @newCode ,  @clsId
	 
	 end
END
go

