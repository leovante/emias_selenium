
CREATE FUNCTION [dbo].[get_all_ls_null_amount2](@Date datetime)
RETURNS @LS TABLE (StoreID int not NULL,
			HostStoreID int not null,
		   StoredLSID int not NULL, 
			HostStoredLSID int not NULL,	   
		   Amount decimal(18,10) not NULL)
AS
BEGIN
	Declare @RestDateTime datetime 
		
	set @RestDateTime = (select top 1 min(TransactDateTimeOperation)
	 		from ras_transactjournal tj
			inner join ras_period p on p.PeriodID = tj.rf_PeriodID and p.HostPeriodID = tj.rf_PeriodIDHost
			inner join ras_stateperiod sp on sp.StatePeriodID = p.rf_StatePeriodID
	 		where (sp.EnumName = 'open')		
			and (@Date >= p.Date_B) 	
			and (rf_PeriodID <> 0)	
		)
	if (@RestDateTime IS NULL) 
		BEGIN


			set @RestDateTime = (select top 1 min(TransactDateTimeOperation)
	 			from ras_transactjournal tj
				inner join ras_period p on p.PeriodID = tj.rf_PeriodID and p.HostPeriodID = tj.rf_PeriodIDHost 
				inner join ras_stateperiod sp on sp.StatePeriodID = p.rf_StatePeriodID
	 			where (sp.EnumName = 'open')
				and (@Date >= p.Date_B) 	
				and (rf_PeriodID <> 0)	
			)
			if (@RestDateTime IS NULL) BEGIN
				insert @LS
	select  ls.rf_StoredID as StoreID,
					ls.rf_StoredIDHost as HostStoreID,
					ls.StoredLSID as StoredLSID, 
					ls.HostStoredLSID as HostStoredLSID, 
			        isnull(tj.[count],0.00) as Amount
	from 
	ras_StoredLS ls
	left join
	(Select sum(tj.Count) count, tj.rf_StoredLSID, tj.rf_StoredLSIDHost 
	 from ras_transactjournal tj
	 inner join ras_period p on tj.rf_periodID = p.PeriodID and tj.rf_periodIDHost = p.HostPeriodID
	 where  (tj.rf_StoredLSID <> 0) 
	 and (TransactDateTimeOperation  <= @Date)
	 group by tj.rf_StoredLSID, tj.rf_StoredLSIDHost) tj on tj.rf_StoredLSID = ls.StoredLSID and tj.rf_StoredLSIDHost = ls.HostStoredLSID
				RETURN	
			END
	END

	insert @LS
	select  ls.rf_StoredID as StoreID,
					ls.rf_StoredIDHost as HostStoreID,
					ls.StoredLSID as StoredLSID, 
					ls.HostStoredLSID as HostStoredLSID, 
			        isnull(tj.[count],0.00) as Amount
	from 
	ras_StoredLS ls
	left join
	(Select sum(tj.Count) count, tj.rf_StoredLSID, tj.rf_StoredLSIDHost 
	 from ras_transactjournal tj
	 inner join ras_period p on tj.rf_periodID = p.PeriodID and tj.rf_periodIDHost = p.HostPeriodID
	 where  (tj.rf_StoredLSID <> 0) 
	 and (TransactDateTimeOperation BETWEEN @RestDateTime and @Date)
	 group by tj.rf_StoredLSID, tj.rf_StoredLSIDHost) tj on tj.rf_StoredLSID = ls.StoredLSID and tj.rf_StoredLSIDHost = ls.HostStoredLSID
	RETURN 

END
go

