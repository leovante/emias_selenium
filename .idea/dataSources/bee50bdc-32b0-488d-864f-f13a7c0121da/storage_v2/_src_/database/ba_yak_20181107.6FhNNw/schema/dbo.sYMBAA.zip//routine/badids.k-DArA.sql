CREATE PROCEDURE BadIDs
	(
	@table_name nvarchar(50)
	)
AS
	SET NOCOUNT ON
	IF @table_name IS NULL BEGIN
	  PRINT 'Имя таблицы должно быть задано'
      RETURN(-1)
    END
    
   --создание временной таблицы
   create table #tmp
   (
    maintable nvarchar(200) collate database_default 
    ,subtable nvarchar(200) collate database_default 
    ,id_num    int  NOT NULL
    ,count_val int  NOT NULL
   );
   
   --поиск имени столбца с ПК   
    DECLARE @objId int
    SET @objId=object_id(@table_name)
       
    DECLARE @col_name nvarchar(50)
    SELECT @col_name=s.name 
    FROM sys.all_columns s
    WHERE (s.object_id=@objId)AND is_identity =1
   
   --выбор всех таблиц, где есть столбцы с именем rf_+{имя столбика с ПК}
    DECLARE tables CURSOR
    FOR SELECT sysobjects.name
       FROM sysobjects INNER JOIN syscolumns 
       ON syscolumns.id=sysobjects.id
    WHERE syscolumns.name='rf_'+@col_name   
    --FOR READ ONLY
   
    DECLARE @table_rf varchar (100)
    DECLARE @sql nvarchar(max)
    
    OPEN tables
    FETCH tables INTO @table_rf    
       print @@FETCH_STATUS
    WHILE (@@FETCH_STATUS>=0) BEGIN
       -- поиск битых ссылок       
      SET @SQL = 'INSERT INTO #tmp (maintable, subtable,id_num, count_val)'+
                  ' SELECT '''+@table_name+''', '''+@table_rf+''', rf_'+@col_name+', COUNT(*) FROM '+@table_rf+
                  ' LEFT OUTER JOIN '+@table_name+' ON rf_'+@col_name+'='+@col_name+
                  ' WHERE '+@col_name+' IS NULL  GROUP BY rf_'+@col_name
       print @SQL
       EXECUTE sp_executesql @SQL
       FETCH tables INTO @table_rf
       
    END
    CLOSE tables
    DEALLOCATE tables
    
    SELECT * FROM #tmp
    
    RETURN(0)
go

