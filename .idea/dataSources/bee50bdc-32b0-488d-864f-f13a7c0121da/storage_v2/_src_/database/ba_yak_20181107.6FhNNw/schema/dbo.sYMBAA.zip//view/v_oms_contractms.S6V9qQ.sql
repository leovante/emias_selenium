CREATE VIEW [V_oms_ContractMS] AS SELECT 
[hDED].[ContractMSID], [hDED].[x_Edition], [hDED].[x_Status], 
(isnull((select top 1 FIO from x_User where userid = 0), 'н/д')) as [V_UserFIO], 
((('№ ' +ConNumber+ ' '+[jT_oms_SMO].[Q_NAME]))) as [V_Info], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[jT_oms_Finl].[NAME] as [SILENT_rf_FinlID], 
[hDED].[rf_TenderKindID] as [rf_TenderKindID], 
[hDED].[rf_kl_MedCareTypeID] as [rf_kl_MedCareTypeID], 
[jT_oms_kl_MedCareType].[Code] as [SILENT_rf_kl_MedCareTypeID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[rf_InshuredID] as [rf_InshuredID], 
[jT_oms_Inshured].[rf_OrganisationID] as [SILENT_rf_InshuredID], 
[hDED].[rf_SMCollectID] as [rf_SMCollectID], 
[jT_oms_SMCollect].[SMCollectName] as [SILENT_rf_SMCollectID], 
[hDED].[ConNumber] as [ConNumber], 
[hDED].[DateSign] as [DateSign], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[NumEdition] as [NumEdition], 
[hDED].[StatusEdition] as [StatusEdition], 
[hDED].[DateEdition] as [DateEdition], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[State] as [State]
FROM [oms_ContractMS] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_Finl] as [jT_oms_Finl] on [jT_oms_Finl].[FinlID] = [hDED].[rf_FinlID]
INNER JOIN [oms_kl_MedCareType] as [jT_oms_kl_MedCareType] on [jT_oms_kl_MedCareType].[kl_MedCareTypeID] = [hDED].[rf_kl_MedCareTypeID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
INNER JOIN [oms_Inshured] as [jT_oms_Inshured] on [jT_oms_Inshured].[InshuredID] = [hDED].[rf_InshuredID]
INNER JOIN [oms_SMCollect] as [jT_oms_SMCollect] on [jT_oms_SMCollect].[SMCollectID] = [hDED].[rf_SMCollectID]
go

