CREATE VIEW [dbo].[V_x_Logs] AS SELECT 
[hDED].[LogsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Action] as [Action], 
[hDED].[Login] as [Login], 
[hDED].[Host] as [Host], 
[hDED].[UserID] as [UserID], 
[hDED].[x_Seance] as [x_Seance], 
[hDED].[Data] as [Data], 
[hDED].[Dt] as [Dt]
FROM [x_Logs] as [hDED]
go

