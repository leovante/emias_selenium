
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[TriggerDirNumber] 
   ON  [dbo].[oms_hs_Direction]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	update [oms_hs_Direction] set DirNumber = left(ltrim(rtrim(DirLpu)) + '-' + cast(hs_DirectionID as varchar), 20)
	where hs_DirectionID in (select hs_DirectionID from inserted where ltrim(rtrim(DirNumber)) = '')
END

go

