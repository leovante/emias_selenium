CREATE VIEW [V_ras_Order] AS SELECT 
[hDED].[OrderID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_OrganisationIDHost] as [rf_OrganisationIDHost], 
[jT_ras_Organisation].[Name] as [SILENT_rf_OrganisationID], 
[hDED].[rf_ResponsibleID] as [rf_ResponsibleID], 
[hDED].[rf_ResponsibleIDHost] as [rf_ResponsibleIDHost], 
[jT_ras_Responsible].[V_FIO] as [SILENT_rf_ResponsibleID], 
[hDED].[rf_StoreSenderID] as [rf_StoreSenderID], 
[hDED].[rf_StoreSenderIDHost] as [rf_StoreSenderIDHost], 
[jT_ras_Store].[StoreName] as [SILENT_rf_StoreSenderID], 
[hDED].[rf_StateOrderID] as [rf_StateOrderID], 
[jT_ras_StateOrder].[Name] as [SILENT_rf_StateOrderID], 
[hDED].[NUM] as [NUM], 
[hDED].[Date] as [Date], 
[hDED].[DatePerform] as [DatePerform]
FROM [ras_Order] as [hDED]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationIDHost]
INNER JOIN [V_ras_Responsible] as [jT_ras_Responsible] on [jT_ras_Responsible].[ResponsibleID] = [hDED].[rf_ResponsibleID] AND  [jT_ras_Responsible].[HostResponsibleID] = [hDED].[rf_ResponsibleIDHost]
INNER JOIN [ras_Store] as [jT_ras_Store] on [jT_ras_Store].[StoreID] = [hDED].[rf_StoreSenderID] AND  [jT_ras_Store].[HostStoreID] = [hDED].[rf_StoreSenderIDHost]
INNER JOIN [ras_StateOrder] as [jT_ras_StateOrder] on [jT_ras_StateOrder].[StateOrderID] = [hDED].[rf_StateOrderID]
go

