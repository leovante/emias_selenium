
CREATE FUNCTION [dbo].[ras_ConvertToFraction]
(
	@val decimal (18,10),
    @z int 
)
RETURNS varchar(50)
AS
BEGIN
    declare @res varchar (50)
	declare @c int
	declare @i int 
	declare @dgt int
	declare @delit varchar(50)
	declare @drob varchar(50)
	declare @znam int
	declare @zisl int
	declare @promzisl int
	declare @prom decimal (18,10)
	declare @prominus decimal (18,10)
	declare @f int = 0--1:отрицательное, 0:положительное

	set @delit = '1'
	set @i = 1
	--проверка на отрицательность
	if @val<0 set @f = 1

	set @val = case when @val<0 then -@val
				else @val
				end;
	set @val  = @val*@z
	set @prom = @val
    set @c = convert (int, @val)
	set @prominus = round(@val-@c,8)
	set @val = round(@val-@c,8)

    if (@val=0)
       begin
	   set @res = convert(varchar(50),@c) 
       	RETURN case when @f = 1 then '-'+@res
			else @res
			end
	   end
    
    declare @ch int

    --количесвто знаков после запятой
	declare @nulVal varchar(20)

	set @nulVal = ltrim(replace(@val,'0.',' '))--удаляю справа
	set @nulVal = replace(rtrim(replace(@nulVal,'0',' ')),' ', '0')--удаляю слева
	while SUBSTRING(@nulVal,@i,@i) =0
	begin
		set @delit = @delit+'0'
		set @i = @i+1
	end
	set @val = convert(decimal,replace(ltrim(replace(@nulVal,'0',' ')),' ', '0'))
	set @dgt = LEN(rtrim(ltrim(replace(replace(@val,'0.',' '),'0',' '))))-1
	
	if @dgt>5 --откуда начинаем округлять
	begin 
	 set @val = round(@prom-@c,3)
	 set @prom = round(@prom,3)
	set @nulVal = ltrim(replace(@val,'0.',' '))--удаляю справа
	set @nulVal = replace(rtrim(replace(@nulVal,'0',' ')),' ', '0')--удаляю слева
	set @i = 1
	while SUBSTRING(@nulVal,@i,@i) =0
	begin
		set @delit = @delit+'0'
		set @i = @i+1
	end
	set @val = convert(decimal,replace(ltrim(replace(@nulVal,'0',' ')),' ', '0'))
	set @dgt = LEN(rtrim(ltrim(replace(replace(@val,'0.',' '),'0',' '))))-1

	end

	--делимое
	while (@dgt !=0)
	Begin
	set @delit = @delit+'0'
	set @dgt = @dgt-1
	end

	
    if ((@delit%@z = 0 or @delit/@z<=1 or @delit=10) and (@z!=10 and round(@prom,8)-convert(int,@val)!=0))
	begin
	  declare @x int
	  declare @y int 
	  set @x = @val
	  set @y = convert(int,@delit)
	
	   while (1=1)
	   begin
	   if @x>@y 
	   set @x = @x%@y
	   else
	   set @y = @y%@x

	   if (@x=0 or @y =0)
	   break;
	   else
	   continue;
	   end 
	set @x = @x+@y
	set @val = @val/@x
	set @delit = convert(int,@delit)/@x
	set @val = convert(int, @val%convert(int,@delit))
	declare @valstr varchar(50)
	set @valstr = convert(int, @val)
	set @drob = convert(varchar(50),@valstr) + '/' + convert(varchar(50),@delit)
	if @c>0
	begin
	if @delit*@val =1
	 set @res = convert(varchar(50),@c+1)
	else
	 set @res = convert(varchar(50),@c) + ', ' + @drob
	end
	else
	 set @res = @drob
	RETURN case when @f = 1 then '-'+@res
			else @res
			end
	end


	--знаменатель
	set @znam = convert(int,@delit)/@val

	set @promzisl = convert(int,@delit)%@val

	if (@promzisl=0)
		set @promzisl=1

	set @zisl = @promzisl%@znam

    if (@znam = 1 and @zisl=0)
	 begin
	 if (round(@val/@delit,2) != 1)
		begin
		set @znam = @delit
		set @zisl = @val
		end
	 end
    if (@znam=@zisl or @znam = @delit or round(@val/@delit,2) = 1)
	set @drob = 1
	else
	set @drob = convert(varchar(50),@zisl) + '/' + convert(varchar(50),@znam)


    if (@drob!='0')
    begin
      if (@val > 0 and @c>0)
	  begin
	  if @drob = '1' or @zisl = '0'
	     set @res = convert(varchar(50),@c+1)
		 else 
		 set @res = convert(varchar(50),@c) + ', ' + @drob
	  end
       else 
         set @res = @drob
    end 
    else 
       set @res = convert(varchar(50),@c) 
    RETURN case when @f = 1 then '-'+@res
			else @res
			end
END
go

