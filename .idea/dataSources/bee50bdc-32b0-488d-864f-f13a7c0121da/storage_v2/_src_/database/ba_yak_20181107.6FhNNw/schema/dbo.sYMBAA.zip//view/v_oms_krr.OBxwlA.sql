CREATE VIEW [V_oms_KRR] AS SELECT 
[hDED].[KRRID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_Department].[DepartmentNAME] as [V_DepartmentNAME], 
[jT_oms_LPU].[M_NAMES] as [V_M_NAMES], 
[jT_oms_LPU].[MCOD] as [V_MCOD], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode1], 
[jT_oms_kl_Category].[Name] as [V_CategoryNAME], 
[jT_oms_ServiceMedical1].[ServiceMedicalCode] as [V_ServiceMedicalCode2], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_OperServiceMedicalID] as [rf_OperServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_OperServiceMedicalID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[rf_kl_TariffTypeID] as [rf_kl_TariffTypeID], 
[jT_oms_kl_TariffType].[Name] as [SILENT_rf_kl_TariffTypeID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[hDED].[rf_kl_CategoryID] as [rf_kl_CategoryID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[rf_TariffTargetID] as [rf_TariffTargetID], 
[jT_oms_TariffTarget].[TariffTargetCode] as [SILENT_rf_TariffTargetID], 
[hDED].[rf_KRRVidID] as [rf_KRRVidID], 
[jT_oms_KRRVid].[VidK_N_ame] as [SILENT_rf_KRRVidID], 
[hDED].[ValueKRR] as [ValueKRR], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Doc] as [Doc], 
[hDED].[Date_Doc] as [Date_Doc], 
[hDED].[GUIDKRR] as [GUIDKRR]
FROM [oms_KRR] as [hDED]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_kl_Category] as [jT_oms_kl_Category] on [jT_oms_kl_Category].[kl_CategoryID] = [hDED].[rf_kl_CategoryID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical1] on [jT_oms_ServiceMedical1].[ServiceMedicalID] = [hDED].[rf_OperServiceMedicalID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [oms_kl_TariffType] as [jT_oms_kl_TariffType] on [jT_oms_kl_TariffType].[kl_TariffTypeID] = [hDED].[rf_kl_TariffTypeID]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
INNER JOIN [oms_TariffTarget] as [jT_oms_TariffTarget] on [jT_oms_TariffTarget].[TariffTargetID] = [hDED].[rf_TariffTargetID]
INNER JOIN [oms_KRRVid] as [jT_oms_KRRVid] on [jT_oms_KRRVid].[KRRVidID] = [hDED].[rf_KRRVidID]
go

