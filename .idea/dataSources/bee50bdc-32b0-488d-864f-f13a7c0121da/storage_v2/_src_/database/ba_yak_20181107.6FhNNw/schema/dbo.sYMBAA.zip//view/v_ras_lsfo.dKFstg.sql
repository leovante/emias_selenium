CREATE VIEW [V_ras_LSFO] AS SELECT 
[hDED].[LSFOID], [hDED].[HostLSFOID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_ras_Provider].[V_Organisation] as [V_Organisation], 
[jT_ras_Nomenclature].[Name] as [V_NAME], 
[hDED].[rf_CLSID] as [rf_CLSID], 
[hDED].[rf_NomenclatureID] as [rf_NomenclatureID], 
[hDED].[rf_NomenclatureIDHost] as [rf_NomenclatureIDHost], 
[hDED].[rf_ProviderID] as [rf_ProviderID], 
[hDED].[rf_ProviderIDHost] as [rf_ProviderIDHost], 
[hDED].[rf_ProduсerID] as [rf_ProduсerID], 
[hDED].[rf_ProduсerIDHost] as [rf_ProduсerIDHost], 
[hDED].[C_LSProvider] as [C_LSProvider], 
[hDED].[C_PFS] as [C_PFS], 
[hDED].[GroupSyn] as [GroupSyn], 
[hDED].[Packed] as [Packed]
FROM [ras_LSFO] as [hDED]
INNER JOIN [V_ras_Provider] as [jT_ras_Provider] on [jT_ras_Provider].[ProviderID] = [hDED].[rf_ProviderID] AND  [jT_ras_Provider].[HostProviderID] = [hDED].[rf_ProviderIDHost]
INNER JOIN [ras_Nomenclature] as [jT_ras_Nomenclature] on [jT_ras_Nomenclature].[NomenclatureID] = [hDED].[rf_NomenclatureID] AND  [jT_ras_Nomenclature].[HostNomenclatureID] = [hDED].[rf_NomenclatureIDHost]
go

