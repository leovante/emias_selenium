CREATE VIEW [V_oms_ipra_Event] AS SELECT 
[hDED].[ipra_EventID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ipra_IPRAID] as [rf_ipra_IPRAID], 
[jT_oms_ipra_IPRA].[IpraNum] as [SILENT_rf_ipra_IPRAID], 
[hDED].[rf_ipra_EventGroupID] as [rf_ipra_EventGroupID], 
[jT_oms_ipra_EventGroup].[SHName] as [SILENT_rf_ipra_EventGroupID], 
[hDED].[isNeed] as [isNeed], 
[hDED].[PeriodForm] as [PeriodForm], 
[hDED].[PeriodTo] as [PeriodTo], 
[hDED].[IsIndefiniteEndDate] as [IsIndefiniteEndDate], 
[hDED].[IsUntil18] as [IsUntil18], 
[hDED].[IsExecute] as [IsExecute], 
[hDED].[GUID] as [GUID]
FROM [oms_ipra_Event] as [hDED]
INNER JOIN [oms_ipra_IPRA] as [jT_oms_ipra_IPRA] on [jT_oms_ipra_IPRA].[ipra_IPRAID] = [hDED].[rf_ipra_IPRAID]
INNER JOIN [oms_ipra_EventGroup] as [jT_oms_ipra_EventGroup] on [jT_oms_ipra_EventGroup].[ipra_EventGroupID] = [hDED].[rf_ipra_EventGroupID]
go

