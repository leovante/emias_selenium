CREATE VIEW [V_oms_DOCTOR] AS SELECT 
[hDED].[DOCTORID], [hDED].[x_Edition], [hDED].[x_Status], 
FAM_V+' '+IM_V+' '+OT_V as [DOCTOR_FIO], 
([jT_oms_LPU].Mcod +' '+[PCOD]) as [V_DoctorCode], 
[jT_oms_LPU].[C_OGRN] as [V_C_OGRN], 
[jT_oms_LPU].[MCOD] as [V_MCOD], 
[jT_oms_LPU].[M_NAMES] as [V_M_NAMES], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_PRVDID] as [rf_PRVDID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[hDED].[rf_KV_KATID] as [rf_KV_KATID], 
[hDED].[PCOD] as [PCOD], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E], 
[hDED].[FAM_V] as [FAM_V], 
[hDED].[IM_V] as [IM_V], 
[hDED].[OT_V] as [OT_V], 
[hDED].[D_PRIK] as [D_PRIK], 
[hDED].[D_SER] as [D_SER], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[DR] as [DR], 
[hDED].[D_JOB] as [D_JOB], 
[hDED].[DATE_REG_B] as [DATE_REG_B], 
[hDED].[SS] as [SS], 
[hDED].[DATE_REG_E] as [DATE_REG_E]
FROM [oms_DOCTOR] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

