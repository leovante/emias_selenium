CREATE VIEW [dbo].[V_x_ReportLog] AS SELECT 
[hDED].[ReportLogID], [hDED].[x_Edition], [hDED].[x_Status], 
((ISNULL((select top 1 rep.[Caption]  from x_Report rep where  [hDed].[ReportGUID] = rep.[ReportGUID]), '[не найден]'))) as [ReportNameVSV], 
(ISNULL((select top 1 GeneralLogin from x_user u where  [hDed].[rf_UserID] = u.UserID), convert(varchar(50), [hDed].[rf_UserID]))) as [UserNameVSV], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[ReportGUID] as [ReportGUID], 
[hDED].[RunLog] as [RunLog], 
[hDED].[Version] as [Version], 
[hDED].[RunDate] as [RunDate], 
[hDED].[x_Seance] as [x_Seance]
FROM [x_ReportLog] as [hDED]
go

