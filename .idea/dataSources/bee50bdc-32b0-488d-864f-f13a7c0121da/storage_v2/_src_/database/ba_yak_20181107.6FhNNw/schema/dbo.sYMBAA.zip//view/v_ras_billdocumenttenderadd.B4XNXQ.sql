CREATE VIEW [V_ras_BillDocumentTenderAdd] AS SELECT 
[hDED].[BillDocumentTenderAddID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_AddBillDocumentID] as [rf_AddBillDocumentID], 
[hDED].[rf_AddBillDocumentIDHost] as [rf_AddBillDocumentIDHost], 
[hDED].[rf_OriginalBillDocumentID] as [rf_OriginalBillDocumentID], 
[hDED].[rf_OriginalBillDocumentIDHost] as [rf_OriginalBillDocumentIDHost], 
[hDED].[rf_TenderAddID] as [rf_TenderAddID]
FROM [ras_BillDocumentTenderAdd] as [hDED]
go

