
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[RefUpdateWithIgnore](@themeName varchar(100), @fieldLike varchar(100), @ignoredTables string_list READONLY, @old int,@new int)
AS
BEGIN

DECLARE @SQL nvarchar(max)
declare _cursor cursor
	for 
			select 	' update '+d.HeadTable+ ' set ' +e.Name +'= ' +convert(varchar(10),@new) +' where '+e.Name+' = '+convert(varchar(10),@old)  from x_DocElemDef e		
			inner join x_DocTypeDef d on d.DocTypeDefID = e.DocTypeDefID
			inner join x_theme on x_Theme.ThemeId= d.ThemeID 
			where e.Name like @fieldLike and x_Theme.Name = @themeName and d.HeadTable not in (select string_item from @ignoredTables)
			
open _cursor
	fetch next from _cursor into @SQL
	while (@@fetch_status <> -1)
	begin				
		
	
		--print @SQL
		EXECUTE sp_executesql @SQL

		fetch next from _cursor into @SQL
	end
	close _cursor
		
	deallocate _cursor
END
go

