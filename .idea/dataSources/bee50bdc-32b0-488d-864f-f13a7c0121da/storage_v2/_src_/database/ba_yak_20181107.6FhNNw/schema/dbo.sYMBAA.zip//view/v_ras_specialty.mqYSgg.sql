CREATE VIEW [V_ras_Specialty] AS SELECT 
[hDED].[SpecialtyID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [ras_Specialty] as [hDED]
go

