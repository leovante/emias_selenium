CREATE VIEW [V_ras_StorageCertificateBook] AS SELECT 
[hDED].[StorageCertificateBookID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Num] as [Num]
FROM [ras_StorageCertificateBook] as [hDED]
go

