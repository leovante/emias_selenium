CREATE VIEW [V_oms_regs_DocumentData] AS SELECT 
[hDED].[regs_DocumentDataID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LabelID] as [rf_LabelID], 
[hDED].[rf_DocumentID] as [rf_DocumentID], 
[hDED].[Key] as [Key], 
[hDED].[Value] as [Value], 
[hDED].[AttributeString] as [AttributeString]
FROM [oms_regs_DocumentData] as [hDED]
go

