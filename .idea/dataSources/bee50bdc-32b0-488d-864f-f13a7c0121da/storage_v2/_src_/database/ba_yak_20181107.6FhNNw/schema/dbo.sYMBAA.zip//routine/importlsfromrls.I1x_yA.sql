
CREATE PROCEDURE [dbo].[ImportLSFromRLS](@code bigint)
AS
BEGIN
	BEGIN TRY 
		;
		WITH GetInfoFromRls(RlsNomenUid, Code, FCode, NameMed, DLS, rf_DLSID, 
		V_LF, rf_VLFID, M_LF, rf_MLFID, 
		N_FV, NAME_FCT, NAME_CNF, 
		NAME_PCK, NAME_CNP, COMPL, 
		FLAG1, FLAG2, DATE_B, DATE_E, 
		rf_LFID, rf_LsTypeID, rf_FARGID, 
		rf_TRNameID, rf_MNNameID, IsDlo, rf_NarcTypeID, N_DOZA) AS
		(
		select 	
			nom.[UID],
			nom.Code,
			isnull((Select top 1 MAX(RzdDrugID) from rls_RzdMapping where rls_RzdMapping.rf_NomenUID = nom.[UID]), 0) FCODE,
			nom.NameMed,

			CASE WHEN prep.DfConc <> '' 
				THEN 
					CASE WHEN prep.rf_ConcenUnitsUID = '00000000-0000-0000-0000-000000000000'
					THEN ''
					ELSE prep.DfConc + ' ' + con.ShortName + ', '
					END
				ELSE ''
				END +
			CASE WHEN prep.DfSize <> '' 
				THEN 
					CASE WHEN prep.rf_SizeUnitsUID = '00000000-0000-0000-0000-000000000000'
					THEN prep.DfSize + ', '
					ELSE prep.DfSize + ' ' + size.ShortName + ', '
					END
				ELSE ''
				END +
			CASE WHEN prep.DfAct <> '' 
				THEN 
					CASE WHEN prep.rf_ActUnitsUID = '00000000-0000-0000-0000-000000000000'
					THEN ''
					ELSE prep.DfAct + ' ' + act.ShortName + ', '
					END
				ELSE ''
				END as DLS, --???????????? ??? ???????

			0 as rf_DLSID,

			nom.PPackVolume as V_LF,

			ISNULL((select top 1 VLFID from oms_VLF where C_VLF = cub.Code), 0 ) as rf_VLFID,

			CASE WHEN prep.DfMass <> 0 THEN prep.DfMass ELSE nom.PPackMass END as M_LF,

			CASE WHEN prep.DfMass <> 0 
			THEN ISNULL((select top 1 MLFID from oms_MLF where C_MLF = mass.Code), 0 )
			ELSE ISNULL((select top 1 MLFID from oms_MLF where C_MLF = mass2.Code), 0 )	END as rf_MLFID,

			CASE WHEN nom.DrugsInpPack = 0 THEN 1 else nom.DrugsInpPack
			 END * CASE WHEN nom.PPackInUPack = 0 THEN 1 else nom.PPackInUPack END
			  * CASE WHEN nom.UPackInSPack = 0 THEN 1 else nom.UPackInSPack END as N_FV,

			ISNULL(CASE WHEN (prep.rf_FirmsUID <> '00000000-0000-0000-0000-000000000000')
			THEN firmnames.Name END, '') as NAME_FCT,

			ISNULL(CASE WHEN (prep.rf_FirmsUID <> '00000000-0000-0000-0000-000000000000')
			THEN REPLACE(countries.Name, '/', ' ') END, '') as NAME_CNF,

			CASE WHEN nomenFirmNames.FirmNamesID <> 0 
			THEN nomenFirmNames.Name		
			ELSE '' END as NAME_PCK,

			CASE WHEN nomenCountries.CountriesID <> 0 
			THEN REPLACE(nomenCountries.Name , '/', ' ')
			ELSE '' END as NAME_CNP,

			'' as COMPL,

			(case when not(alimp.rf_ActMattersUID is null and limp.rf_TradeNamesUID is NULL) then 1 else 0 end) as FLAG1,

			0 as FLAG2,

			CONVERT(datetime, '01.01.2013', 104) as DATE_B,

			CONVERT(datetime, '01.01.2200', 104) as DATE_E,

			CASE WHEN (cdf.ClsDrugFormsID <> 0)
			THEN ISNULL((select top 1 LFID from oms_LF where C_LF = cdf.Code), 0)
			END as rf_LFID,

			CASE WHEN (ntfr.ClsNtfrID <> 0)
			THEN
				ISNULL((select top 1 LSTypeID from oms_LsType where LsTypeCode = ntfr.Code), 0)
			END as rf_LsTypeID,

			ISNULL((select top 1 FARGID from oms_FARG where C_FARG = 
				(select rls_ClsPharmaGroup.Code from rls_ClsPharmaGroup where UID in (select top 1 rf_ClsPharmaGroupUID from rls_Prep_PharmaGroup where rf_PrepUID = prep.UID)))
				, 0) as rf_FARGID,

			ISNULL((select top 1 TrNameID from oms_TRName where C_TRN = trade.Code), 0) as rf_TRNameID,

			CASE WHEN (ntfr.Code = 1)
			THEN
				CASE WHEN (select COUNT(*) from rls_Prep_ActMatters where rf_PrepUID = prep.UID) > 0
				THEN
					ISNULL((select top 1 MNNameID from oms_MNName where C_MNN = 
					(select Code from rls_ActMatters where UID in (select top 1 rf_ActMattersUID from rls_Prep_ActMatters where rf_PrepUID = prep.UID))), 0)
				ELSE
					ISNULL((select top 1 MNNameID from oms_MNName where C_MNN = -2), 0)
				END
			ELSE
				ISNULL((select top 1 MNNameID from oms_MNName where C_MNN = -2), 0)
			END as rf_MNNameID,

			IsNull ((select top 1 1 from rls_ActMatters_DrugForms actDF where actDF.rf_ActMattersUID = actdlo.[UID]), 0) as IsDlo,

			ISNULL(case	
			when (n.Name != '') then 5--?????????
			when (s.NAME != '' and s.Code <> 2) then 4 --?????????????????
			end, 0) as rf_NarcTypeID,
			prep.DrugDose as N_DOZA
		from rls_Nomen nom --oms_LS ls 
		--join rls_Nomen nom on ls.RlsNomenUid = nom.UID
		join rls_Prep prep on nom.rf_PrepUID = prep.UID
		join rls_ConcenUnits con on prep.rf_ConcenUnitsUID = con.UID
		join rls_SizeUnits size on prep.rf_SizeUnitsUID = size.UID
		join rls_ActUnits act on prep.rf_ActUnitsUID = act.UID
		join rls_CubicUnits cub on nom.rf_CubicUnitsUID = cub.UID
		join rls_MassUnits mass on prep.rf_MassUnitsUID = mass.UID
		join rls_MassUnits mass2 on nom.rf_MassUnitsUID = mass2.UID
		join rls_Firms firms on prep.rf_FirmsUID = firms.UID
		join rls_FirmNames firmnames on firms.rf_FirmNamesUID = firmnames.UID
		join rls_Countries countries on firms.rf_CountriesUID = countries.UID

		inner join rls_REGCERT r on prep.rf_RegCertUID = r.[UID]
		inner join rls_REGCERT_STATUS rs on r.rf_RegCert_StatusUID = rs.[UID]

		left join rls_Firms nomenFirms on nom.rf_FirmsUID = nomenFirms.UID
		left join rls_FirmNames nomenFirmNames on nomenFirms.rf_FirmNamesUID = nomenFirmNames.UID
		left join rls_Countries nomenCountries on nomenFirms.rf_CountriesUID = nomenCountries.UID

		join rls_ClsDrugForms cdf on prep.rf_ClsDrugFormsUID = cdf.UID
		join rls_ClsNtfr ntfr on prep.rf_ClsNtfrUID = ntfr.UID
		join rls_TradeNames trade on prep.rf_TradeNamesUID = trade.UID

		left join rls_tradenames t on t.[UID] = prep.rf_TradeNamesUID
		left join rls_tn_df_limp limp on (limp.rf_TradeNamesUID = prep.rf_TradeNamesUID) and (limp.rf_ClsDrugFormsUID = prep.rf_ClsDrugFormsUID)
		left join rls_prep_actmatters actprep on prep.[UID] = actprep.rf_PrepUID and actprep.code>0
		left join rls_am_df_limp alimp on (alimp.rf_ActMattersUID = actprep.rf_ActMattersUID) and (alimp.rf_ClsDrugFormsUID = prep.rf_ClsDrugFormsUID)
		left join rls_ActMatters actdlo on actdlo.UID = actprep.rf_ActMattersUID
		left join rls_STRONGGROUPS s on s.[UID] = actdlo.rf_StrongGroupsUID
		left join dbo.rls_NARCOGROUPS n on n.[UID] = actdlo.rf_NarcoGroupsUID
		where nom.NomenID > 0 --ls.LSID > 0 and ls.RlsNomenUid <> '00000000-0000-0000-0000-000000000000'
		)

		insert into oms_LS
		(RlsNomenUid, NOMK_LS, Fcode, Name_Med, D_LS, rf_DLSID, 
		V_LF, rf_VLFID, M_LF, rf_MLFID, 
		N_FV, NAME_FCT, NAME_CNF, 
		NAME_PCK, NAME_CNP, COMPL, 
		FLAG1, FLAG2, DATE_B, DATE_E, 
		rf_LFID, rf_LsTypeID, rf_FARGID, 
		rf_TRNameID, rf_MNNameID, IsDlo, rf_NarcTypeID, N_DOZA)
		select 
		GetInfoFromRls.RlsNomenUid, GetInfoFromRls.Code, GetInfoFromRls.FCode, GetInfoFromRls.NameMed, CASE WHEN GetInfoFromRls.DLS <> '' THEN SUBSTRING(GetInfoFromRls.DLS, 1, LEN(GetInfoFromRls.DLS) - 1) ELSE '' END, GetInfoFromRls.rf_DLSID, 
		GetInfoFromRls.V_LF, GetInfoFromRls.rf_VLFID, GetInfoFromRls.M_LF, GetInfoFromRls.rf_MLFID, 
		GetInfoFromRls.N_FV, GetInfoFromRls.NAME_FCT,GetInfoFromRls. NAME_CNF, 
		GetInfoFromRls.NAME_PCK, GetInfoFromRls.NAME_CNP, GetInfoFromRls.COMPL, 
		GetInfoFromRls.FLAG1, GetInfoFromRls.FLAG2, GetInfoFromRls.DATE_B, GetInfoFromRls.DATE_E, 
		GetInfoFromRls.rf_LFID, GetInfoFromRls.rf_LsTypeID, GetInfoFromRls.rf_FARGID, 
		GetInfoFromRls.rf_TRNameID, GetInfoFromRls.rf_MNNameID, GetInfoFromRls.IsDlo, GetInfoFromRls.rf_NarcTypeID, GetInfoFromRls.N_DOZA
		from GetInfoFromRls
		left join oms_LS ls on ls.NOMK_LS = Code
		where ls.LSID is null and GetInfoFromRls.Code = @code

		declare @lsid int;
		set @lsid = (select CAST(SCOPE_IDENTITY() AS INT) where @@ROWCOUNT > 0);

		if (@lsid is not null and @lsid > 0)
			update oms_LS
			set Pattern = ttt.Pattern
			from 
			(
				select lsType.Pattern from oms_LS ls
				join oms_LSType lsType on ls.rf_LsTypeID = lsType.LsTypeID
				where LSID = @lsid
			)ttt
			where oms_LS.LSID = @lsid
	END TRY
	BEGIN CATCH
		SELECT 
			ERROR_NUMBER() AS ErrorNumber,
			ERROR_MESSAGE() AS ErrorMessage;
	END CATCH	
END
go

