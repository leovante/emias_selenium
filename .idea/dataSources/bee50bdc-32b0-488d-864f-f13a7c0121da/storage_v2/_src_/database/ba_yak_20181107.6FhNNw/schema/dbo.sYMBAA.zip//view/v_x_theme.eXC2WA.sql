CREATE view [dbo].[V_x_Theme] as select [ThemeID], [Name], [Mnem], [Prefix], [NumVersion], [GUID], [ParentThemeID], [x_Edition], [x_Status] from x_Theme
go

