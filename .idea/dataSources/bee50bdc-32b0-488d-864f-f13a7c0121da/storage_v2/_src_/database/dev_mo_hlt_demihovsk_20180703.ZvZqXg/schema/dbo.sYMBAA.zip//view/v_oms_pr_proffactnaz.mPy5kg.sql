CREATE VIEW [V_oms_pr_ProfFactNaz] AS SELECT 
[hDED].[pr_ProfFactNazID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[rf_pr_ProfFactID] as [rf_pr_ProfFactID], 
[hDED].[NAZR] as [NAZR], 
[hDED].[NAZ_V] as [NAZ_V], 
[hDED].[NAZ_PR] as [NAZ_PR]
FROM [oms_pr_ProfFactNaz] as [hDED]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
go

