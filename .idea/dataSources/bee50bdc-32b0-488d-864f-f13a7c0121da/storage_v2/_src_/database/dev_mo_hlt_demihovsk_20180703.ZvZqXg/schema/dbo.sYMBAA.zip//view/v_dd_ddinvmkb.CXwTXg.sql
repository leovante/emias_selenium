CREATE VIEW [V_dd_DDInvMKB] AS SELECT 
[hDED].[DDInvMKBID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDInvalidityID] as [rf_DDInvalidityID], 
[jT_dd_DDInvalidity].[V_INVNAME] as [SILENT_rf_DDInvalidityID], 
[hDED].[rf_DDInvalidDiseaseTypeGUID] as [rf_DDInvalidDiseaseTypeGUID], 
[hDED].[Flag] as [Flag]
FROM [dd_DDInvMKB] as [hDED]
INNER JOIN [V_dd_DDInvalidity] as [jT_dd_DDInvalidity] on [jT_dd_DDInvalidity].[DDInvalidityID] = [hDED].[rf_DDInvalidityID]
go

