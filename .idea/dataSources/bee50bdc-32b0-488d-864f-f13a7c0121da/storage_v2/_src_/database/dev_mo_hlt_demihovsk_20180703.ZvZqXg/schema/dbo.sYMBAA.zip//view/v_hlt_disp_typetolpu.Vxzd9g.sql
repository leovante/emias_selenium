CREATE VIEW [V_hlt_disp_TypeToLpu] AS SELECT 
[hDED].[disp_TypeToLpuID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LpuGuid] as [rf_LpuGuid], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LpuGuid], 
[hDED].[rf_dispTypeGuid] as [rf_dispTypeGuid], 
[jT_hlt_disp_Type].[Name] as [SILENT_rf_dispTypeGuid], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_TypeToLpu] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[GUIDLPU] = [hDED].[rf_LpuGuid]
INNER JOIN [hlt_disp_Type] as [jT_hlt_disp_Type] on [jT_hlt_disp_Type].[Guid] = [hDED].[rf_dispTypeGuid]
go

