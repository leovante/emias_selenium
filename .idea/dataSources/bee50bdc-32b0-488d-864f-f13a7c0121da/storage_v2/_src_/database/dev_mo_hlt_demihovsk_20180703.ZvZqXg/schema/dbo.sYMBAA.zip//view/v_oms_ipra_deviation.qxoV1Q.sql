CREATE VIEW [V_oms_ipra_Deviation] AS SELECT 
[hDED].[ipra_DeviationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_ipra_IPRAID] as [rf_ipra_IPRAID], 
[hDED].[Reason] as [Reason], 
[hDED].[DateDeviation] as [DateDeviation]
FROM [oms_ipra_Deviation] as [hDED]
go

