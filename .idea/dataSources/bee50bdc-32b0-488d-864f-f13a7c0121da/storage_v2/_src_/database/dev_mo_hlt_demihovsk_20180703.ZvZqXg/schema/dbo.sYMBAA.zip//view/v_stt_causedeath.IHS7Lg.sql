CREATE VIEW [V_stt_CauseDeath] AS SELECT 
[hDED].[CauseDeathID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Name] as [Name], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_CauseDeath] as [hDED]
go

