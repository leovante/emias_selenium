CREATE VIEW [V_hlt_DUVisit] AS SELECT 
[hDED].[DUVisitID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[jT_hlt_TAP].[v_TAP] as [SILENT_rf_TAPID], 
[hDED].[rf_ReqMedicalCheckID] as [rf_ReqMedicalCheckID], 
[jT_hlt_RegMedicalCheck].[rf_MKABID] as [SILENT_rf_ReqMedicalCheckID], 
[hDED].[AppointedToBeDate] as [AppointedToBeDate], 
[hDED].[ItWasDate] as [ItWasDate], 
[hDED].[isAppearance] as [isAppearance], 
[hDED].[Flag] as [Flag], 
[hDED].[Comment] as [Comment], 
[hDED].[GUID] as [GUID]
FROM [hlt_DUVisit] as [hDED]
INNER JOIN [V_hlt_TAP] as [jT_hlt_TAP] on [jT_hlt_TAP].[TAPID] = [hDED].[rf_TAPID]
INNER JOIN [hlt_RegMedicalCheck] as [jT_hlt_RegMedicalCheck] on [jT_hlt_RegMedicalCheck].[RegMedicalCheckID] = [hDED].[rf_ReqMedicalCheckID]
go

