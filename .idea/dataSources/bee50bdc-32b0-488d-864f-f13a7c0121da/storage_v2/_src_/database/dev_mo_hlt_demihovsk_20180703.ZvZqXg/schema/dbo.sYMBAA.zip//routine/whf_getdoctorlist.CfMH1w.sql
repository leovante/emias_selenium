-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	Перечень врачей ЛПУ, ведущийх прием (РПГУ2-МО)
-- =============================================
CREATE FUNCTION [dbo].[whf_GetDoctorList] ()
RETURNS TABLE
AS
RETURN (
		SELECT docprvdid ID
			,doc.LPUDoctorID DoctorID
			,doc.PCOD
			,doc.SS
			,doc.Fam_V FAM
			,doc.IM_V IM
			,doc.OT_V OT
			,prvd.rf_PRVSID
			,prvd.V_PRVSName PRVSName
			,prvd.V_PRVDName PRVDName
			,prvd.V_DepartmentNAME DepartmentNAME
			,oms_LPU.MCOD
		FROM v_hlt_docprvd prvd WITH (NOLOCK) 
		INNER JOIN hlt_lpudoctor doc  WITH (NOLOCK) ON prvd.rf_LPUDoctorID = doc.LPUDoctorID
		INNER JOIN oms_department  WITH (NOLOCK) ON prvd.rf_DepartmentID = oms_department.DepartmentID
		INNER JOIN oms_LPU  WITH (NOLOCK) ON oms_department.rf_LPUID = oms_LPU.LPUID
		WHERE prvd.intime = 1
			AND prvd.rf_ResourceTypeID = 1
			and prvd.rf_PRVSID > 0
		)
go

