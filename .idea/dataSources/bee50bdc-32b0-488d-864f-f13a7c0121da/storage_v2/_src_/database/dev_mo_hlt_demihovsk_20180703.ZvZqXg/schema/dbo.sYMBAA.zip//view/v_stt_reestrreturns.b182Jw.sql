CREATE VIEW [V_stt_ReestrReturns] AS SELECT 
[hDED].[ReestrReturnsID], [hDED].[x_Edition], [hDED].[x_Status], 
(select [Name] from oms_ExpertType where ExpertTypeID = 
(select  rf_ExpertTypeID from hlt_MHExpert where MHExpertID = hded.rf_MHExpertID)) as [V_ExpertType], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[jT_hlt_ReestrMH].[DateBegin] as [SILENT_rf_ReestrMHID], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[jT_oms_SMCriterion].[SMCriterionCaption] as [SILENT_rf_SMCriterionID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[hDED].[rf_MHExpertID] as [rf_MHExpertID], 
[jT_hlt_MHExpert].[Num] as [SILENT_rf_MHExpertID], 
[hDED].[rf_MedServicePatientID] as [rf_MedServicePatientID], 
[jT_stt_MedServicePatient].[V_ServiceMedicalCode] as [SILENT_rf_MedServicePatientID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_ReestrOccasionID] as [rf_ReestrOccasionID], 
[hDED].[Rem] as [Rem]
FROM [stt_ReestrReturns] as [hDED]
INNER JOIN [hlt_ReestrMH] as [jT_hlt_ReestrMH] on [jT_hlt_ReestrMH].[ReestrMHID] = [hDED].[rf_ReestrMHID]
INNER JOIN [oms_SMCriterion] as [jT_oms_SMCriterion] on [jT_oms_SMCriterion].[SMCriterionID] = [hDED].[rf_SMCriterionID]
INNER JOIN [hlt_MHExpert] as [jT_hlt_MHExpert] on [jT_hlt_MHExpert].[MHExpertID] = [hDED].[rf_MHExpertID]
INNER JOIN [V_stt_MedServicePatient] as [jT_stt_MedServicePatient] on [jT_stt_MedServicePatient].[MedServicePatientID] = [hDED].[rf_MedServicePatientID]
go

