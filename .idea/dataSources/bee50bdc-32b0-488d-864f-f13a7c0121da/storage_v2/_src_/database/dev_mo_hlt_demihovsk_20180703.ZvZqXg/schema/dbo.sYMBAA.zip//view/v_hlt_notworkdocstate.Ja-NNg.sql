CREATE VIEW [V_hlt_NotWorkDocState] AS SELECT 
[hDED].[NotWorkDocStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Description] as [Description], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_NotWorkDocState] as [hDED]
go

