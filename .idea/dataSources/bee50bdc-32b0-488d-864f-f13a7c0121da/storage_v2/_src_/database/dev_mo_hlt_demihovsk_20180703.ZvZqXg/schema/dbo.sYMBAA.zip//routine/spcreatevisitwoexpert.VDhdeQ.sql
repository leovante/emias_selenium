
CREATE PROCEDURE [dbo].[spCreateVisitWOExpert] @dttid INT
	,@mkabid INT
	,@hist XML
	,@recotdtype INT
	,@result INT OUTPUT
AS
BEGIN
	/* Есть ли такая временная запись? */
	IF NOT EXISTS (
			SELECT *
			FROM hlt_DoctorTimeTable
			WHERE DoctorTimeTableID = @dttid
			)
	BEGIN
		SET @result = - 8

		RETURN
	END

	/*Определяем врача*/
	DECLARE @docPRVDID INT

	SET @docPRVDID = isnull((
				SELECT TOP 1 rf_docPRVDID
				FROM hlt_DoctorTimeTable
				WHERE DoctorTimeTableID = @dttid
				), 0)

	/*И его специальность*/
	DECLARE @PRVSID INT
	SET @PRVSID = isnull((
				SELECT TOP 1 rf_PRVSID
				FROM hlt_DocPRVD
				WHERE DocPRVDID = @docPRVDID
				), 0)
	
	/*Уже записаны к врачу такой же специальности*/
	IF EXISTS (
			SELECT 1
			FROM hlt_DoctorTimeTable dtt
			INNER JOIN hlt_DoctorVisitTable dvt ON dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID
			INNER JOIN hlt_DocPRVD ON DocPRVDID = dtt.rf_DocPRVDID
			WHERE dvt.rf_MKABID = @mkabid
				AND hlt_DocPRVD.rf_PRVSID = @PRVSID
				AND (dtt.Begin_Time > GETDATE()	or dtt.Date = (select top 1 dtt2.date from hlt_doctortimetable dtt2 where DoctorTimeTableID=@DTTID))
			)
	BEGIN
		SET @result = - 101

		RETURN
	END

	/*А может уже кого-то записали?*/
	DECLARE @PLAN INT
	DECLARE @NORMA INT

	SET @PLAN = isnull((
				SELECT PLANUE
				FROM hlt_DoctorTimeTable
				WHERE DoctorTimeTableID = @dttid
				), 0)
	SET @NORMA = isnull((
				SELECT sum(NormaUE)
				FROM hlt_DoctorVisitTable
				WHERE rf_DoctorTimeTableID = @dttid
				), 0)

	IF @NORMA >= @PLAN
	BEGIN
		SET @result = - 2

		RETURN
	END


	BEGIN TRAN

	DECLARE @num VARCHAR(200) = ''
	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE NAME = 'spGetDVDStubNum'
				AND type = 'P'
			)
	BEGIN
		DECLARE @RC INT

		EXECUTE @RC = [dbo].[spGetDVDStubNum] @dttid
			,@num OUTPUT
		
	END
	ELSE
	BEGIN
		UPDATE hlt_DoctorTimeTable
		SET LastStubNum = LastStubNum + 1
		WHERE DoctorTimeTableID = @dttid

		SELECT TOP 1 @num =convert(VARCHAR(5), Begin_Time, 108) + '.' + RIGHT('000' + cast(LastStubNum AS VARCHAR(3)), 3)
		FROM hlt_DoctorTimeTable
		WHERE DoctorTimeTableID = @dttid
	END


	DECLARE @dvtID INT

	/* Создаем записи в hlt_DoctorVisitTable */
	INSERT INTO hlt_DoctorVisitTable (
		rf_DoctorTimeTableID
		,rf_MKABID
		,Comment
		,editHistory
		,Flags
		,fromReg
		,fromDoc
		,fromInfomat
		,fromInternet
		,fromTel
		,UGUID
		,NormaUE
		,DateTimeCreate
		,StubNum
		)
	SELECT @dttid
		,@mkabid
		,hlt_MKAB.FAMILY + ' ' + hlt_MKAB.NAME + ' ' + hlt_MKAB.OT + ', ' + cast(datepart(yy, hlt_MKAB.DATE_BD) AS VARCHAR(4)) + ' г.р.'
		,@hist
		,4
		,@recotdtype & 0x01
		,@recotdtype & 0x02
		,@recotdtype & 0x04
		,@recotdtype & 0x08
		,@recotdtype & 0x10
		,newid()
		,1
		,getdate()
		,@num
	FROM hlt_MKAB
	WHERE MKABID = @mkabid

	/* сохраняем ID записи*/
	--SET @dvtid = (
	--		SELECT IDENT_CURRENT('hlt_DoctorVisitTable')
	--		)
	COMMIT TRAN

	SET @result = 0
END

go

