CREATE VIEW [V_rls_Descriptions] AS SELECT 
[hDED].[DescriptionsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FirmsUID] as [rf_FirmsUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[FprepName] as [FprepName], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Descriptions] as [hDED]
go

