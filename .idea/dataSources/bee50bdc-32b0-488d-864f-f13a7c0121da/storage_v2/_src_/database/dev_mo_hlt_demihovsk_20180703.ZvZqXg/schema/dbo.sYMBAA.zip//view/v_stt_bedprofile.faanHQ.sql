CREATE VIEW [V_stt_BedProfile] AS SELECT 
[hDED].[BedProfileID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Flag] as [Flag], 
[hDED].[Date_E] as [Date_E], 
[hDED].[UGUID] as [UGUID]
FROM [stt_BedProfile] as [hDED]
go

