CREATE VIEW [V_dd_DDHealthInstability] AS SELECT 
[hDED].[DDHealthInstabilityID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDChildFormID] as [rf_DDChildFormID], 
[jT_dd_DDChildForm].[v_FIO] as [SILENT_rf_DDChildFormID], 
[hDED].[rf_DDHealthInstabilityTypeGUID] as [rf_DDHealthInstabilityTypeGUID], 
[jT_dd_DDHealthInstabilityType].[Name] as [SILENT_rf_DDHealthInstabilityTypeGUID], 
[hDED].[Flag] as [Flag]
FROM [dd_DDHealthInstability] as [hDED]
INNER JOIN [V_dd_DDChildForm] as [jT_dd_DDChildForm] on [jT_dd_DDChildForm].[DDChildFormID] = [hDED].[rf_DDChildFormID]
INNER JOIN [dd_DDHealthInstabilityType] as [jT_dd_DDHealthInstabilityType] on [jT_dd_DDHealthInstabilityType].[UGUID] = [hDED].[rf_DDHealthInstabilityTypeGUID]
go

