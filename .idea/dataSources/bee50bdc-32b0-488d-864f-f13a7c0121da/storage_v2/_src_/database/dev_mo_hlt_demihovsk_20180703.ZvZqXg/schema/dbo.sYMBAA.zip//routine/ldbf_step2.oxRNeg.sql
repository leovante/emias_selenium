
CREATE PROCEDURE [dbo].[LDBF_Step2]
	@PathDBF nvarchar (max),
	@iReestr int,
	@Priority int
AS
BEGIN
	

/*Инициализация переменных*/
Declare @Res nvarchar(max),@e varchar(200),@GUID varchar(50),@Result varchar(100),@SQL nvarchar(max),
@Katalog varchar(2500),@Katalog2 varchar(2000),@return_value int,@t1 varchar(200),@t2 varchar(200),@t3 varchar(200),
@columns nvarchar(max),@columns1 nvarchar(max),@ForKatalog varchar(max),@UserFIO varchar(200);

select @UserFIO=FIO from x_User where UserID=1

if not exists(select * from sysobjects where [name] = 'inf_tabl') 
Begin
	CREATE TABLE inf_tabl(
	table_n varchar(50),
	hidden varchar(50) ,
	desc_table varchar(100),
	insert_n int
	,update_n int
	,close_n int
	,RealClose int
	)
end

/*----------------курсор по таблицам--------------*/

DECLARE cur_Tab SCROLL CURSOR  FOR
Select Name_DBF,Key_DBF,Query_DBF,Code,Name_DBF
	from oms_LoadNSITable 
		inner join [tmp_LoadPrepare] on tablename=Table_Name and LoadNSITableID = tableID
	where LoadNSITableID>0 and [tmp_LoadPrepare].[Priority]=@Priority
group by Key_DBF,Name_DBF,Query_DBF,Code,[tmp_LoadPrepare].[Priority]
order by [tmp_LoadPrepare].[Priority]

OPEN cur_Tab
DECLARE @N_T varchar(100), @Key varchar(400),@QueryDBF varchar(8000), @Code int,@N_T_0 varchar(100)
	FETCH FIRST FROM cur_Tab
	INTO @N_T,@Key,@QueryDBF,@Code,@N_T_0
WHILE @@FETCH_STATUS = 0
BEGIN
begin try
	

/*Процедура проверки на обновление*/
	set @SQL = ' declare @Result nvarchar(max); exec dbo.Oms_rd_Update '''+Convert(varchar,@Code)+''',''rd_'+ Convert(varchar,@Code)+''', @Result OUTPUT' 
	print @SQL
	EXECUTE sp_executesql @SQL



--Пропишем info_tab2
end try
begin CATCH 
print 'Ошибка__'
end CATCH 
begin try
	if not exists(select * from sysobjects where [name] = 'inf_tabl2')  
		Select * into inf_tabl2 
			from inf_tabl
		else
			Insert into inf_tabl2 Select inf_tabl.*,0,0,0 from inf_tabl
						inner join oms_LoadNSITable on table_n=table_Name and desc_Table=Rem
			where Name_DBF=@N_T

		if not exists(Select * from sys.columns c 	where object_id=object_id('inf_tabl2') and c.name='Kol_DBF') 
						ALTER TABLE inf_tabl2 ADD Kol_DBF int
		if not exists(Select * from sys.columns c where object_id=object_id('inf_tabl2') and c.name='Kol_oms') 
						ALTER TABLE inf_tabl2 ADD Kol_oms int
		if not exists(Select * from sys.columns c where object_id=object_id('inf_tabl2') and c.name='Kol_ERR') 
						ALTER TABLE inf_tabl2 ADD Kol_ERR int

		Set @SQL=''
		Select @SQL=@SQL+'Update inf_tabl2 Set Kol_DBF=isnull( (Select count(*) from ['+@N_T+']),''0''),
							Kol_oms=(Select count(*)-1 from ['+table_n+']) ,
							Kol_Err=0
							where table_n='''+table_n+''''
							from inf_tabl2
								inner join oms_LoadNSITable on table_n=table_Name
							where Name_DBF=@N_T_0
		EXECUTE sp_executesql @SQL

		
		declare @dSQL nvarchar(max);
		set @SQL='';
		set @dSQL = 'if exists (select * from sys.all_objects where [name]=''rd_'+Convert(varchar,@Code)+''') '

		select @SQL = ' update  inf_tabl2 Set  Kol_ERR = isnull( ( select count(*) from rd_'+ Convert(varchar,@Code) +' where Err like ''%!%''  ), ''0'') 
							where table_n='''+table_n+''''
		from inf_tabl2
				inner join oms_LoadNSITable on table_n=table_Name
			where Name_DBF=@N_T_0

if(Len(@SQL)>0) begin
				set @SQL= @dSQL +@SQL
				EXECUTE sp_executesql @SQL
		end
else print '___'

end try
begin CATCH 
	print '__Error'
end Catch

	FETCH NEXT FROM cur_Tab
	INTO @N_T,@Key,@QueryDBF,@Code,@N_T_0
END

DEALLOCATE cur_Tab;
END
go

