CREATE VIEW [V_hlt_atc_Category] AS SELECT 
[hDED].[atc_CategoryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_atc_Category] as [hDED]
go

