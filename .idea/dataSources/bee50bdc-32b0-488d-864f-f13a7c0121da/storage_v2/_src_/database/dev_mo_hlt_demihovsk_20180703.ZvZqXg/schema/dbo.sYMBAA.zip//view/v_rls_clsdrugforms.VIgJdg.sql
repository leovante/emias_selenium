CREATE VIEW [V_rls_ClsDrugForms] AS SELECT 
[hDED].[ClsDrugFormsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsDrugFormsUID] as [rf_ClsDrugFormsUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[Name] as [Name], 
[hDED].[FullName] as [FullName], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_ClsDrugForms] as [hDED]
go

