
CREATE FUNCTION [dbo].[I_ListOfSpec] 
(		
	@date_a datetime, 
	@date_b datetime, 
	@dbt int,
	@mkabid int
)
RETURNS @Result TABLE (
            prvsid int not null
           ,prvs_name varchar(200) not null
		   ,[Active] int not null
		   ,[TicketCount] int not null
)
AS BEGIN	
	-- Settings
	declare @divByLPU int
	SET @divByLPU = (select case when isnull((select top 1 valueSTR from x_UserSettings WITH(NOLOCK) where Property = 'Разделение врачей по ЛПУ' and rf_UserID in ([dbo].[GetCurrentUserID] () , 1) order by rf_UserID desc), '1') = '1' then 1 else 0 end)

	declare @divByUch int
	SET @divByUch = (select case when isnull((select top 1 valueSTR from x_UserSettings WITH(NOLOCK) where Property = 'Разделение врачей по участкам' and rf_UserID in ([dbo].[GetCurrentUserID] () , 1) order by rf_UserID desc), '1') = '1' then 1 else 0 end)
	
	declare @hideButton int
	SET @hideButton = (select case when isnull((select top 1 valueSTR from x_UserSettings WITH(NOLOCK) where Property = 'Инфомат - скрыть неактивные кнопки' and rf_UserID in ([dbo].[GetCurrentUserID] () , 1) order by rf_UserID desc), '1') = '1' then 1 else 0 end)

	declare @lpucode varchar(50)
	SET @lpucode = (select isnull((select top 1 valueSTR from x_UserSettings WITH(NOLOCK) where Property = 'Код поликлиники' and rf_UserID in ([dbo].[GetCurrentUserID] (), 1) order by rf_UserID desc), ''))

	insert  @Result
	select 
		prvs.prvsid, 
		prvs.prvs_name,
		case when (sum(isnull(dtt.planUE,0)) > sum(isnull(dtt.UsedUE,0))) then 1 else 0 end as Active,
		sum(isnull(dtt.planUE,0)) - sum(isnull(dtt.UsedUE,0)) as TicketCount
	from hlt_DocPrVd dprvd WITH(NOLOCK)	 
		INNER JOIN oms_PRVS prvs  WITH(NOLOCK)	on prvs.prvsID = dprvd.rf_PRVSID and prvs.prvsID > 0
		INNER JOIN hlt_DoctorTimeTable dtt  WITH(NOLOCK)	on dtt.rf_DocPrVdID = dprvd.DocPrVdID 
		INNER JOIN dbo.hlt_DocBusyType AS dbt WITH (NOLOCK) ON dbt.DocBusyTypeID = dtt.rf_DocBusyType
			AND dbt.DocBusyTypeID <> 0
		LEFT JOIN oms_Department dp  WITH(NOLOCK)	on dp.DepartmentID = dprvd.rf_DepartmentID 
		LEFT JOIN oms_LPU lpu  WITH(NOLOCK)	ON dp.rf_LPUID = lpu.LPUID  
	where dprvd.InTime = 1
		and dtt.date between @date_a and @date_b
		and	prvs.prvsid > 0
		and (dtt.FlagAccess & 4) > 0 --фильтр по правам доступа--
		AND (dbt.TypeBusy IN (1, 2)	)
		--and dtt.rf_DocBusyType = @dbt		
		and ((@divByLPU = 0) OR (lpu.MCOD = @lpucode)) --a || (^a && b) = a || b 	
		and ((@divByUch = 0) OR (dprvd.DocPRVDID not in (SELECT DISTINCT rf_DOCPRVDID from hlt_Uchastok where UchastokID > 0)))		
		and dprvd.rf_ResourceTypeID = 1
	group by prvs.prvsid, prvs.prvs_name
	having ((@hideButton = 0) OR (sum(isnull(dtt.planUE,0)) > sum(isnull(dtt.UsedUE,0))))


	return
END
go

