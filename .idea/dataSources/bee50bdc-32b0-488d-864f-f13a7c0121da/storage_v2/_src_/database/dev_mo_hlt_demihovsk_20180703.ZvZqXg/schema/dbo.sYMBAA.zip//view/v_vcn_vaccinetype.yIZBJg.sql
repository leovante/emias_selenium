CREATE VIEW [V_vcn_VaccineType] AS SELECT 
[hDED].[VaccineTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
(GUID) as [V_VaccineTypeGUID], 
[jT_vcn_InjectionType].[Code] as [V_InjectionTypeCode], 
[hDED].[rf_InjectionTypeID] as [rf_InjectionTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[GUID] as [GUID], 
[hDED].[ageMinY] as [ageMinY], 
[hDED].[ageMinM] as [ageMinM], 
[hDED].[ageMinD] as [ageMinD], 
[hDED].[ageMaxY] as [ageMaxY], 
[hDED].[ageMaxM] as [ageMaxM], 
[hDED].[ageMaxD] as [ageMaxD]
FROM [vcn_VaccineType] as [hDED]
INNER JOIN [vcn_InjectionType] as [jT_vcn_InjectionType] on [jT_vcn_InjectionType].[InjectionTypeID] = [hDED].[rf_InjectionTypeID]
go

