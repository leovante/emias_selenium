CREATE VIEW [V_hlt_atc_MilkSet] AS SELECT 
[hDED].[atc_MilkSetID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_atc_CategoryID] as [rf_atc_CategoryID], 
[jT_hlt_atc_Category].[Name] as [SILENT_rf_atc_CategoryID], 
[hDED].[Num] as [Num], 
[hDED].[Comment] as [Comment], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[AgeFrom] as [AgeFrom], 
[hDED].[AgeTo] as [AgeTo], 
[hDED].[TuCode] as [TuCode], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_atc_MilkSet] as [hDED]
INNER JOIN [hlt_atc_Category] as [jT_hlt_atc_Category] on [jT_hlt_atc_Category].[atc_CategoryID] = [hDED].[rf_atc_CategoryID]
go

