CREATE VIEW [V_hlt_CHOICES_NotWork] AS SELECT 
[hDED].[CHOICES_NotWorkID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Field] as [Field], 
[hDED].[Caption] as [Caption], 
[hDED].[Rem] as [Rem], 
[hDED].[Field1] as [Field1], 
[hDED].[Field2] as [Field2]
FROM [hlt_CHOICES_NotWork] as [hDED]
go

