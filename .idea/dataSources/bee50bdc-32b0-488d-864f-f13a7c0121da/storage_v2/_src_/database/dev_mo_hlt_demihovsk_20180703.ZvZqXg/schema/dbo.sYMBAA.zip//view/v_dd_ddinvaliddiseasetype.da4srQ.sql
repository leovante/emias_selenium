CREATE VIEW [V_dd_DDInvalidDiseaseType] AS SELECT 
[hDED].[DDInvalidDiseaseTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[TypeName] as [TypeName], 
[hDED].[TypeCode] as [TypeCode]
FROM [dd_DDInvalidDiseaseType] as [hDED]
go

