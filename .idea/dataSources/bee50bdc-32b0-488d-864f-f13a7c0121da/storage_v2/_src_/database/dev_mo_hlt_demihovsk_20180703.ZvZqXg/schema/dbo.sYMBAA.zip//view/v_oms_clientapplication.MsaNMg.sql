CREATE VIEW [V_oms_ClientApplication] AS SELECT 
[hDED].[ClientApplicationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ClientApplicationGuid] as [ClientApplicationGuid], 
[hDED].[FullName] as [FullName], 
[hDED].[Mnem] as [Mnem], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags]
FROM [oms_ClientApplication] as [hDED]
go

