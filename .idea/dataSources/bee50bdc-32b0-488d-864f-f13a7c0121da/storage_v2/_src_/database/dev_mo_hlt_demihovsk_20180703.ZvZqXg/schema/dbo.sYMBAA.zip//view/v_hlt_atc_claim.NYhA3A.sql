CREATE VIEW [V_hlt_atc_Claim] AS SELECT 
[hDED].[atc_ClaimID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PrevMoID] as [rf_PrevMoID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_PodrID] as [rf_PodrID], 
[jT_oms_LPU1].[M_NAMES] as [SILENT_rf_PodrID], 
[hDED].[rf_UchastokID] as [rf_UchastokID], 
[jT_hlt_Uchastok].[CODE] as [SILENT_rf_UchastokID], 
[hDED].[rf_atc_ClaimPersonID] as [rf_atc_ClaimPersonID], 
[hDED].[rf_atc_ClaimTrustedPersonID] as [rf_atc_ClaimTrustedPersonID], 
[hDED].[rf_atc_ClaimKindID] as [rf_atc_ClaimKindID], 
[jT_hlt_atc_ClaimKind].[Name] as [SILENT_rf_atc_ClaimKindID], 
[hDED].[rf_atc_DeclineReasonID] as [rf_atc_DeclineReasonID], 
[jT_hlt_atc_DeclineReason].[Reason] as [SILENT_rf_atc_DeclineReasonID], 
[hDED].[rf_atc_WantedMilkSetID] as [rf_atc_WantedMilkSetID], 
[jT_hlt_atc_MilkSet].[Num] as [SILENT_rf_atc_WantedMilkSetID], 
[hDED].[rf_atc_DeliveryPointID] as [rf_atc_DeliveryPointID], 
[jT_hlt_atc_DeliveryPoint].[Name] as [SILENT_rf_atc_DeliveryPointID], 
[hDED].[IdInSource] as [IdInSource], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[PrevMo] as [PrevMo], 
[hDED].[Comment] as [Comment], 
[hDED].[GUID] as [GUID], 
[hDED].[Num] as [Num], 
[hDED].[DeadlineDate] as [DeadlineDate], 
[hDED].[AutoProlongation] as [AutoProlongation]
FROM [hlt_atc_Claim] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_LPU] as [jT_oms_LPU1] on [jT_oms_LPU1].[LPUID] = [hDED].[rf_PodrID]
INNER JOIN [hlt_Uchastok] as [jT_hlt_Uchastok] on [jT_hlt_Uchastok].[UchastokID] = [hDED].[rf_UchastokID]
INNER JOIN [hlt_atc_ClaimKind] as [jT_hlt_atc_ClaimKind] on [jT_hlt_atc_ClaimKind].[atc_ClaimKindID] = [hDED].[rf_atc_ClaimKindID]
INNER JOIN [hlt_atc_DeclineReason] as [jT_hlt_atc_DeclineReason] on [jT_hlt_atc_DeclineReason].[atc_DeclineReasonID] = [hDED].[rf_atc_DeclineReasonID]
INNER JOIN [hlt_atc_MilkSet] as [jT_hlt_atc_MilkSet] on [jT_hlt_atc_MilkSet].[atc_MilkSetID] = [hDED].[rf_atc_WantedMilkSetID]
INNER JOIN [hlt_atc_DeliveryPoint] as [jT_hlt_atc_DeliveryPoint] on [jT_hlt_atc_DeliveryPoint].[atc_DeliveryPointID] = [hDED].[rf_atc_DeliveryPointID]
go

