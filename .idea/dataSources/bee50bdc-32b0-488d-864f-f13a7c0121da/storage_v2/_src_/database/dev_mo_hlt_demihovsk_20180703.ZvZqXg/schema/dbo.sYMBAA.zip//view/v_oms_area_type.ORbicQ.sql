CREATE VIEW [V_oms_area_type] AS SELECT 
[hDED].[area_typeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CodeTypeArea] as [CodeTypeArea], 
[hDED].[NameTypeArea] as [NameTypeArea]
FROM [oms_area_type] as [hDED]
go

