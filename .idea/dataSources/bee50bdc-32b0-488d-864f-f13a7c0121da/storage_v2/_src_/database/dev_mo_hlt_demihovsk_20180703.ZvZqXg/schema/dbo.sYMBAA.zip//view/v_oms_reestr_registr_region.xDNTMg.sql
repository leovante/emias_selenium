CREATE VIEW [V_oms_Reestr_Registr_Region] AS SELECT 
[hDED].[Reestr_Registr_RegionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Num] as [Num], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[GUID] as [GUID], 
[hDED].[OGRN] as [OGRN]
FROM [oms_Reestr_Registr_Region] as [hDED]
go

