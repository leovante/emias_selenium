

CREATE PROCEDURE [dbo].[sp2dr_CreateHomeVisit2_fromCALL] (
	 @mkabid INT
	,@mcod VARCHAR(20)
	,@date DATETIME
	,@address VARCHAR(200)
	,@complaint VARCHAR(100)
	,@phone VARCHAR(25)
	,@porch INT
	,@floor INT
	,@intercome VARCHAR(20)
	,@result INT OUTPUT
	)
AS
BEGIN

	exec [dbo].[sp2dr_CreateHomeVisit2Params] 
					 @mkabid 
					,@mcod 
					,@date 
					,@address 
					,@complaint 
					,@phone 
					,@porch 
					,@floor 
					,@intercome
					,3 -- source КЦ
					,@result output
	
END

go

