
 --Возвращает список КСГ для набора данных  Московская область
create FUNCTION [dbo].[GetKSG](
--Включает исключения и обработку прерванный случай и возраст до 4
@List_OperDS nvarchar(4000), 
-- Список пар из операций и диагнозов вида разделенных ;Пример :(A16.24.006.001,T95);(A16.24.006.001,T91);(A16.08.029.004,)
---И операция и диагноз не обязательны, но запятая обязательно
@List_DS nvarchar(4000), 
-- список диагнозов разделенных запятыми Пример 'T95,T91,A00,'
@List_DopDS nvarchar(4000), 
-- список сопутствующих диагнозов разделенных запятыми Пример 'T95,T91,A00,'
@Sex varchar(1),
--Код пола
-- 2 Женский
-- 1 Мужской
@Age int, 
--Возраст
@IsAgeDay bit=0, 
-- 1 в случае если возраст в днях
-- 0 возраст в годах
@departmentId int=0,
--ID отделения
@date datetime, 
-- дата окончания лечения
@dlit int=1,
--Длительность лечения
@prerv varchar(20)='',
--Прерванный случай
@ExpertKSGCriterionId int=0
)
RETURNS @result TABLE (
ServicemedicalID int,
[КСГ] [varchar](50),
[Наименование КСГ] [varchar](350),
[Тип] [varchar](700),
[TariffId] [int] NULL, 
[KRRValue] [decimal](38, 6) NULL,
[KSGValue] [decimal](38, 5) NULL, 
[Value] [decimal](38, 2) NULL,
[rf_MKBId] [int] NULL, 
[Диагноз] [varchar](255),
[rf_SopMKBId] [int] NULL, 
[Сопутствующий диагноз] [varchar](255),
[Норма]    [int],
[Info] [varchar](350)
)
AS
begin
/*declare @krr decimal(20,5)
set @krr = isnull(dbo.getDepartmentKRR(@departmentId, @date),1)
*/
declare @depType int
declare @depName    varchar(max)
declare @depProfile int
declare @lpuid      int
select  @depType = rf_kl_DepartmentTypeID, @depName = SILENT_rf_kl_DepartmentTypeID, @depProfile =rf_kl_DepartmentProfileID, @lpuid=rf_LPUID from v_oms_Department
where DepartmentID =@departmentId


begin
INSERT INTO @result
select distinct ServicemedicalID,ServicemedicalCode, Servicemedicalname,Info, tariffID,  

case when V_UnitName like '%КСГ%' then dbo.getKRRValue(@date,@lpuid,@depProfile,@depType,ServicemedicalCode,'',mkbid,case when @IsAgeDay=1 then 1 else @Age end, @dlit) 
else dbo.getKRRValueКпс(@date,@lpuid,@depProfile,@depType,ServicemedicalCode,'',mkbid,case when @IsAgeDay=1 then 1 else @Age end, @dlit)  end  , 
 value1,
case when V_UnitName like '%КСГ%' then isnull(value1*dbo.getKRRValue(@date,@lpuid,@depProfile,@depType,ServicemedicalCode,'',mkbid,case when @IsAgeDay=1 then 1 else @Age end, @dlit),0) 
else isnull(value1*dbo.getKRRValueКпс(@date,@lpuid,@depProfile,@depType,ServicemedicalCode,'',mkbid,case when @IsAgeDay=1 then 1 else @Age end, @dlit),0)  --isnull(value1,0) 
end,

			
MKBID,oms_mkb.name [Диагноз],0,  '',1 as [Норма]  ,

case when V_UnitName like '%КСГ%' then 
dbo.getKRRInfo(@date,@lpuid,@depProfile,@depType,ServicemedicalCode,'',mkbid,case when @IsAgeDay=1 then 1 else @Age end, @dlit)
else 
(
 select '('+convert(varchar(10),vidid)+','+convert(varchar(20),value)/*+','+info*/+')' +';' as 'data()' 
 from [dbo].[GetKRR](@date, @lpuid,@depProfile,@depType,ServicemedicalCode,'',mkbid ,case when @IsAgeDay=1 then 1 else @Age end, @dlit)
left join oms_krrvid on vidid= krrvidid
for xml path(''))
end

from v_oms_tariff
inner join V_oms_ServiceMedical on ServiceMedicalID =  v_oms_tariff.rf_ServiceMedicalID and V_UnitName like '%случай%'
inner join (
select top 1 Item [MKB] from dbo.TableFromString(@List_DS,',') 
) m on 1 =1 
inner join oms_mkb on [MKB]=DS
where  v_oms_tariff.date_E>@date and V_oms_ServiceMedical.rf_kl_DepartmentTypeID=@depType and V_oms_ServiceMedical.rf_kl_DepartmentProfileID=@depProfile
and V_oms_ServiceMedical.rf_kl_DepartmentProfileID>0
and (  ((@Age<18 or @IsAgeDay=1) and v_agename<>'Взрослые' ) 
or  (@Age>=18 and  @IsAgeDay=0  and v_agename<>'Дети' ) )
order by value1
end

--else


INSERT INTO @result
select distinct rf_ServicemedicalID,ServicemedicalCode, Servicemedicalname,Info, tariffID, 
dbo.getKRRValue(@date,@lpuid,@depProfile,@depType,ServicemedicalCode,Oper,rf_MKBID,       case when @IsAgeDay=1 then 1 else @Age end, @dlit),
value1,
value1*dbo.getKRRValue(@date,@lpuid,@depProfile,@depType,ServicemedicalCode,Oper,rf_MKBID,case when @IsAgeDay=1 then 1 else @Age end, @dlit),

rf_MKBID,[Диагноз],rf_SopMKBID,  [Сопутствующий диагноз],1 as [Норма]  ,dbo.getKRRInfo(@date,@lpuid,@depProfile,@depType,ServicemedicalCode,Oper,rf_MKBID,case when @IsAgeDay=1 then 1 else @Age end, @dlit)
from (
select  Qw.Oper,
isnull(ksg.ServicemedicalCode, Qw1.ServicemedicalCode) ServicemedicalCode, 
isnull(ksg.Servicemedicalname, Qw1.Servicemedicalname) Servicemedicalname, 
isnull(( ksg.Info+'('+
case when Qw.Oper is not null and ltrim(rtrim(qw.Oper))<>'' then 'операция: '+Qw.Oper
else '' end+ 
case when Qw.DSQ is not null and oms_mkb.DS<>'' then ' диагноз: '+Qw.DSQ
else '' end+ 
case when Qw.DopDS is not null and Dop.DS<>'' then  ' сопутствующий диагноз: '+QW.DopDS
else '' end+ 
case when @ExpertKSGCriterionID>0 and  oms_ExpertKSG.rf_ExpertKSGCriterionID>0 then ' схема: '+CodeKSGCriterion else '' end+
 ')'), Qw1.Info) as Info, 
isnull( ksg.ServiceMedicalId,Qw1.ServiceMedicalId) as ServiceMedicalId, 
oms_mkb.MKBID rf_MKBID,
oms_mkb.name [Диагноз],
  rf_SopMKBID,
  Dop.name [Сопутствующий диагноз],
 oms_ExpertKSG.Flags
from oms_ExpertKSG
inner join oms_ServiceMedical on oms_ServiceMedical.ServiceMedicalId = rf_OperationServiceMedicalID and oms_ExpertKSG.Date_E>@date
inner join oms_ServiceMedical ksg on ksg.ServiceMedicalId = rf_KSGServiceMedicalID 
and ksg.Date_E >@date and   (oms_ExpertKSG.rf_kl_DepartmentTypeID=@depType or oms_ExpertKSG.rf_kl_DepartmentTypeID=0)
and oms_ExpertKSG.DATE_E>@date
inner join oms_MKB on oms_MKB.MKBID = rf_MKBID
inner join oms_MKB dop on dop.MKBID = rf_SopMKBID
inner join oms_kl_SEX on kl_SExID = oms_ExpertKSG.rf_kl_SEXID
inner join oms_ExpertKSGCriterion on ExpertKSGCriterionId=rf_ExpertKSGCriterionID  
right join (

select Substring (t.Item,charIndex('(',t.Item)+1, charIndex(',',t.Item)-charIndex('(',t.Item)-1) as Oper,
Substring (t.Item,charIndex(',',t.Item)+1,charIndex(')',t.Item)-charIndex(',',t.Item)-1 ) as DsQ, Dop.Item as DopDS
from dbo.TableFromString(@List_OperDS,';') t
left join  dbo.TableFromString(@List_DopDS,',')  dop on 1=1
union
select Substring (t.Item,charIndex('(',t.Item)+1, charIndex(',',t.Item)-charIndex('(',t.Item)-1) as Oper,
Substring (t.Item,charIndex(',',t.Item)+1,charIndex(')',t.Item)-charIndex(',',t.Item)-1 ) as DsQ, '' as DopDS
from dbo.TableFromString(@List_OperDS,';') t
where len(@List_OperDS)>5
union 
select '' ,Item,'' as DopDS from dbo.TableFromString(@List_DS,',') 
union
select '' ,t.Item,Dop.Item as DopDS from dbo.TableFromString(@List_DS,',') t
left join  dbo.TableFromString(@List_DopDS,',')  dop on 1=1

) Qw on ltrim(rtrim(qw.Oper)) =ltrim(rtrim(oms_ServiceMedical.ServiceMedicalCode)) and ( ltrim(rtrim(oms_MKB.DS))= ltrim(rtrim(DSQ)) ) 
and  ( ltrim(rtrim(dop.DS))= ltrim(rtrim(DopDS)) ) 

and 
 (Code=@Sex or kl_SEXID=0 ) 
and ( oms_ExpertKSG.rf_ExpertKSGCriterionID=0 or oms_ExpertKSG.rf_ExpertKSGCriterionID =@ExpertKSGCriterionID) 
and (Year2=0 or (@Age>=Year1 and @Age<Year2 and IsAgeDay=@IsAgeDay )
or (@IsAgeDay=1 and Year1=0 and IsAgeDay=0 )
or (@IsAgeDay=1 and IsAgeDay=1 and @Age>=255 and Year1=28 )
--or( @IsAgeDay=0 and IsAgeDay=1 and @Age>1 and Year1=29 )
 or (@IsAgeDay=1 and IsAgeDay=1 and @Age<=1 and Year2=255 and Year1=91 )
)
left join ( 
select oper.ServicemedicalCode as Oper, ksg.ServicemedicalCode,ksg.Servicemedicalname, ksg.Info+'(операция: '+oper.ServicemedicalCode +')' as Info,ksg.ServicemedicalId, rf_MKBID, oms_MKB.Name as [Диагноз],oms_ExpertKSG.Value 
from oms_ExpertKSG
inner join oms_ServiceMedical oper on oper.ServiceMedicalId = rf_OperationServiceMedicalID and  rf_OperationServiceMedicalID>0 and ExpertKSGId>0 and oper.ServicemedicalCode !=''
inner join oms_ServiceMedical ksg on ksg.ServiceMedicalId = rf_KSGServiceMedicalID and  ksg.Date_E >@date
inner join oms_kl_SEX on kl_SExID = oms_ExpertKSG.rf_kl_SEXID
inner join oms_MKB on MKBID = rf_MKBID
inner join oms_ExpertKSGCriterion on ExpertKSGCriterionId=rf_ExpertKSGCriterionID  
where  (oms_ExpertKSG.rf_kl_DepartmentTypeID=@depType or oms_ExpertKSG.rf_kl_DepartmentTypeID=0)
and oms_ExpertKSG.DATE_E>@date
and rf_MKBID=0 
and (Code=@Sex or kl_SEXID=0) 
and ( oms_ExpertKSG.rf_ExpertKSGCriterionID=0 or oms_ExpertKSG.rf_ExpertKSGCriterionID =@ExpertKSGCriterionID) 
and (Year2=0 or (@Age>=Year1 and @Age<Year2 and IsAgeDay=@IsAgeDay)
or (@IsAgeDay=1 and Year1=0 and IsAgeDay=0 )
or (@IsAgeDay=1 and IsAgeDay=1 and @Age>=255 and Year1=28 )
--or( @IsAgeDay=0 and IsAgeDay=1 and @Age>1 and Year1=29 )
 or (@IsAgeDay=1 and IsAgeDay=1 and @Age<=1 and Year2=255 and Year1=91 )
)
) Qw1 on ExpertKSGID is null and Qw1.Oper = qw.Oper --and Qw.Oper<>'' 

) ksg 
inner join oms_Tariff on ksg.ServicemedicalID=oms_Tariff.rf_ServicemedicalID and oms_Tariff.date_b<=@date and oms_Tariff.date_e>@date
inner join oms_TariffTarget on rf_TariffTargetID = TariffTargetID and (oms_TariffTarget.rf_kl_DepartmentTypeID=@depType or oms_TariffTarget.rf_kl_DepartmentTypeID=0)
where ServicemedicalId>0
order by value1 desc

declare @num int 
set @num=0
select @num=Num from  @result
inner join 
(
select '300DRG0116011' usl1 , '300DRG0116009' Usl2, '1' Num union
select '300DRG0116012',		'300DRG0116009','2' Union 
select '300DRG0116011',		'300DRG0116010','3' Union
select '300DRG0116073',		'300DRG0116018','4' Union
select '300DRG0116074',		'300DRG0116018','5' Union
select '300DRG0116154',		'300DRG0116160','6' Union
select '300DRG0116281',		'300DRG0116280','7' Union
select '300DRG0116281',		'300DRG0116188','8' Union
select '300DRG0116226',		'300DRG0116223','9' Union
select '300DRG0116034',		'300DRG0116223','10' Union
select '300DRG0116237',		'300DRG0116252','11' ) t on [КСГ] = usl1 or [КСГ] =Usl2
group by Num
having count(*)>1
if(@num>0)
 
declare @notUsl varchar(50)
set @notUsl =0
select @notUsl=usl2 from (
select '300DRG0116011' usl1 , '300DRG0116009' Usl2, '1' Num union
select '300DRG0116012',		'300DRG0116009', '2' Union 
select '300DRG0116011',		'300DRG0116010', '3' Union
select '300DRG0116073',		'300DRG0116018', '4' Union
select '300DRG0116074',		'300DRG0116018', '5' Union
select '300DRG0116154',		'300DRG0116160','6' Union
select '300DRG0116281',		'300DRG0116280','7' Union
select '300DRG0116281',		'300DRG0116188','8' Union
select '300DRG0116226',		'300DRG0116223','9' Union
select '300DRG0116034',		'300DRG0116223','10' Union
select '300DRG0116237',		'300DRG0116252','11') t where Num =@num
 
delete from @result where [КСГ]=@notUsl
 declare @k_Anatom int
declare @k_T7     int
declare @k_J      int


set @k_Anatom=0
set @k_T7    =0
set @k_J     =0


select @k_J=count(*) from (
select  Substring (t.Item,charIndex(',',t.Item)+1,charIndex(')',t.Item)-charIndex(',',t.Item)-1 ) as Ds
from dbo.TableFromString(@List_OperDS,';') t
union
select Item from dbo.TableFromString(@List_DS,',') 
union
select Item from dbo.TableFromString(@List_DopDS,',') 
) tJ 
inner join dbo.TableFromString('J94.2, J94.8, J94.9, J93, J93.0, J93.1, J93.8, J93.9, J96.0, N17, T79.4, R57.1, R57.8',',') on rtrim(ltrim( item))=Ds
 
if(@k_J=0) return

select @k_Anatom=count (distinct code) from (
select  Substring (t.Item,charIndex(',',t.Item)+1,charIndex(')',t.Item)-charIndex(',',t.Item)-1 ) as Ds
from dbo.TableFromString(@List_OperDS,';') t
union
select Item from dbo.TableFromString(@List_DS,',') 
union
select Item from dbo.TableFromString(@List_DopDS,',') 

) all_ds inner join (
select 'T1' code,item from  dbo.TableFromString('S02.0, S02.1, S04.0, S05.7, S06.1, S06.2, S06.3, S06.4, S06.5, S06.6, S06.7, S07.0, S07.1, S07.8, S09.0, S11.0, S11.1, S11.2, S11.7, S15.0, S15.1, S15.2, S15.3, S15.7, S15.8, S15.9, S17.0, S17.8, S18',',')  
union
select 'T2',item from  dbo.TableFromString('S12.0, S12.9, S13.0, S13.1, S13.3, S14.0, S14.3, S22.0, S23.0, S23.1, S24.0, S32.0, S32.1, S33.0, S33.1, S33.2, S33.4, S34.0, S34.3, S34.4',',') 
union
select 'T3',item from  dbo.TableFromString('S22.2, S22.4, S22.5, S25.0, S25.1, S25.2, S25.3, S25.4, S25.5, S25.7, S25.8, S25.9, S26.0, S27.0, S27.1, S27.2, S27.4, S27.5, S27.6, S27.8, S28.0, S28.1',',') 
union
select 'T4',item from  dbo.TableFromString('S35.0, S35.1, S35.2, S35.3, S35.4, S35.5, S35.7, S35.8, S35.9, S36.0, S36.1, S36.2, S36.3, S36.4, S36.5, S36.8, S36.9, S37.0, S38.3',',') 
union
select 'T5',item from  dbo.TableFromString('S32.3, S32.4, S32.5, S36.6, S37.1, S37.2, S37.4, S37.5, S37.6, S37.8, S38.0, S38.2',',')
union
select 'T6',item from  dbo.TableFromString('S42.2, S42.3, S42.4, S42.8, S45.0, S45.1, S45.2, S45.7, S45.8, S47 , S48.0, S48.1, S48.9, S52.7, S55.0, S55.1, S55.7, S55.8, S57.0, S57.8, S57.9, S58.0, S58.1, S58.9, S68.4, S71.7, S72.0, S72.1, S72.2, S72.3, S72.4, S72.7, S75.0, S75.1, S75.2, S75.7, S75.8, S77.0, S77.1, S77.2, S78.0, S78.1, S78.9, S79.7, S82.1, S82.2, S82.3, S82.7, S85.0, S85.1, S85.5, S85.7, S87.0, S87.8, S88.0, S88.1, S88.9, S95.7, S95.8, S95.9, S97.0, S97.8, S98.0',',')  
) anatom on rtrim(ltrim( item))=ds

select @k_T7=count(*) from (
select  Substring (t.Item,charIndex(',',t.Item)+1,charIndex(')',t.Item)-charIndex(',',t.Item)-1 ) as Ds
from dbo.TableFromString(@List_OperDS,';') t
union
select Item from dbo.TableFromString(@List_DS,',') 
union
select Item from dbo.TableFromString(@List_DopDS,',') 
) t inner join dbo.TableFromString('S02.7, S12.7, S22.1, S27.7, S29.7, S31.7, S32.7, S36.7, S38.1,S39.6, S39.7, S37.7, S42.7, S49.7, T01.1, T01.8, T01.9, T02.0,T02.1, T02.2, T02.3, T02.4, T02.5, T02.6, T02.7, T02.8, T02.9, T04.0, T04.1, T04.2, T04.3, T04.4, T04.7, T04.8, T04.9, T05.0, T05.1, T05.2, T05.3, T05.4, T05.5, T05.6, T05.8, T05.9, T06.0, T06.1, T06.2, T06.3, T06.4, T06.5, T06.8, T07',',')  t7 on rtrim(ltrim( item))=ds




if ((@k_Anatom>1 or @k_T7>0) and @k_J>0)
begin
INSERT INTO @result
select rf_ServicemedicalID,V_ServicemedicalCode, V_SMname,'Дополнительные критерии отнесения: комбинация диагнозов плюс диагноз, характеризующий тяжесть состояния.', tariffId, 
 
 dbo.getKRRValue(@date,@lpuid,@depProfile,@depType,V_ServicemedicalCode,'',0,case when @IsAgeDay=1 then 1 else @Age end, @dlit),
 value1,
 value1*dbo.getKRRValue(@date,@lpuid,@depProfile,@depType,V_ServicemedicalCode,'',0,case when @IsAgeDay=1 then 1 else @Age end, @dlit), 
 
0,'',0,'',1 as [Норма] ,dbo.getKRRInfo(@date,@lpuid,@depProfile,@depType,V_ServicemedicalCode,'',0,case when @IsAgeDay=1 then 1 else @Age end, @dlit)
 from v_oms_tariff
 
where V_SMname like '%Политравма%' and date_E>@date
 
end
 
RETURN 
END


 go

