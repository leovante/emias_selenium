CREATE VIEW [V_stt_PatientAgent] AS SELECT 
[hDED].[PatientAgentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_TYPEDOCID] as [rf_TYPEDOCID], 
[jT_oms_TYPEDOC].[C_DOC] as [SILENT_rf_TYPEDOCID], 
[hDED].[rf_LiveAddressID] as [rf_LiveAddressID], 
[hDED].[rf_RegAddressID] as [rf_RegAddressID], 
[hDED].[rf_kl_TipOMSID] as [rf_kl_TipOMSID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_GenderTypeID] as [rf_GenderTypeID], 
[jT_stt_GenderType].[Gender] as [SILENT_rf_GenderTypeID], 
[hDED].[rf_FamilyTiesID] as [rf_FamilyTiesID], 
[hDED].[rf_OKSMID] as [rf_OKSMID], 
[hDED].[Name] as [Name], 
[hDED].[Surname] as [Surname], 
[hDED].[Patronymic] as [Patronymic], 
[hDED].[BirthDate] as [BirthDate], 
[hDED].[BirthPlace] as [BirthPlace], 
[hDED].[S_POL] as [S_POL], 
[hDED].[N_POL] as [N_POL], 
[hDED].[LiveAddress] as [LiveAddress], 
[hDED].[RegAddress] as [RegAddress], 
[hDED].[Flag] as [Flag], 
[hDED].[isBase] as [isBase], 
[hDED].[WOPatronymic] as [WOPatronymic], 
[hDED].[UGUID] as [UGUID], 
[hDED].[S_DOC] as [S_DOC], 
[hDED].[N_DOC] as [N_DOC], 
[hDED].[WhoGiveout_DOC] as [WhoGiveout_DOC], 
[hDED].[WhenGiveout_DOC] as [WhenGiveout_DOC]
FROM [stt_PatientAgent] as [hDED]
INNER JOIN [oms_TYPEDOC] as [jT_oms_TYPEDOC] on [jT_oms_TYPEDOC].[TYPEDOCID] = [hDED].[rf_TYPEDOCID]
INNER JOIN [stt_GenderType] as [jT_stt_GenderType] on [jT_stt_GenderType].[GenderTypeID] = [hDED].[rf_GenderTypeID]
go

