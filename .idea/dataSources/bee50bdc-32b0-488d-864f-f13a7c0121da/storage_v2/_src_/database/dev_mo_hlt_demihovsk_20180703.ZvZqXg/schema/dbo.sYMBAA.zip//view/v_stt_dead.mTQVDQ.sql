CREATE VIEW [V_stt_Dead] AS SELECT 
[hDED].[DeadID], [hDED].[x_Edition], [hDED].[x_Status], 
( case when [hDED].rf_MedicalHistoryID=0 then isnull((select top 1 mkb.DS+' - '+mkb.NAME from stt_Diagnos d
inner join oms_MKB mkb on mkb.MKBID=d.rf_MKBID
where DiagnosID=[hDED].rf_DiagnosID),'') else
(isnull((select top 1 mkb.DS+' - '+mkb.NAME from stt_Diagnos d
inner join oms_MKB mkb on mkb.MKBID=d.rf_MKBID
where rf_MedicalHistoryID=[hDED].rf_MedicalHistoryID
and rf_DiagnosTypeID=(select DiagnosTypeID from stt_DiagnosType where Code='10')),''))end) as [V_Diagnos], 
((hDED.Family+' ' +hDED.Name+' ' +hDED.OT)) as [FIO], 
(FAM_Recipient+ ' ' + Nam_Recipient + ' '+ OT_Recipient) as [V_FIORecipient], 
[jT_stt_MedicalHistory].[FIO] as [V_FIO], 
[jT_stt_MedicalHistory].[MedCardNum] as [V_MedCardNum], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_TYPEDOCID] as [rf_TYPEDOCID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_AddressRegID] as [rf_AddressRegID], 
[hDED].[rf_AddressFactID] as [rf_AddressFactID], 
[hDED].[rf_kl_SocStatusID] as [rf_kl_SocStatusID], 
[hDED].[rf_kl_EducationTypeID] as [rf_kl_EducationTypeID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[jT_stt_MedicalHistory].[FIO] as [SILENT_rf_MedicalHistoryID], 
[hDED].[rf_DiagnosID] as [rf_DiagnosID], 
[hDED].[rf_GenderTypeID] as [rf_GenderTypeID], 
[hDED].[rf_PlaceDeathID] as [rf_PlaceDeathID], 
[hDED].[rf_CauseDeathID] as [rf_CauseDeathID], 
[hDED].[rf_TypeDeathCertificateID] as [rf_TypeDeathCertificateID], 
[hDED].[DateIn] as [DateIn], 
[hDED].[DateDeath] as [DateDeath], 
[hDED].[S_DeathCertificate] as [S_DeathCertificate], 
[hDED].[N_DeathCertificate] as [N_DeathCertificate], 
[hDED].[DateOut] as [DateOut], 
[hDED].[FIO_Recipient] as [FIO_Recipient], 
[hDED].[S_DOC] as [S_DOC], 
[hDED].[N_DOC] as [N_DOC], 
[hDED].[Date_DeathCertificate] as [Date_DeathCertificate], 
[hDED].[IssuedOrganisation] as [IssuedOrganisation], 
[hDED].[Date_Doc] as [Date_Doc], 
[hDED].[Family] as [Family], 
[hDED].[Name] as [Name], 
[hDED].[OT] as [OT], 
[hDED].[AddressReg] as [AddressReg], 
[hDED].[AddressFact] as [AddressFact], 
[hDED].[DateBirth] as [DateBirth], 
[hDED].[isSingle] as [isSingle], 
[hDED].[Delivered] as [Delivered], 
[hDED].[isCreateCertificate] as [isCreateCertificate], 
[hDED].[BurialPlace] as [BurialPlace], 
[hDED].[ResponsibleNonIntrusive] as [ResponsibleNonIntrusive], 
[hDED].[FAM_Recipient] as [FAM_Recipient], 
[hDED].[NAM_Recipient] as [NAM_Recipient], 
[hDED].[OT_Recipient] as [OT_Recipient], 
[hDED].[issued] as [issued], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flags] as [flags]
FROM [stt_Dead] as [hDED]
INNER JOIN [V_stt_MedicalHistory] as [jT_stt_MedicalHistory] on [jT_stt_MedicalHistory].[MedicalHistoryID] = [hDED].[rf_MedicalHistoryID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
go

