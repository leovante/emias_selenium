CREATE VIEW [V_hl7_Document] AS SELECT 
[hDED].[DocumentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[UGUID] as [UGUID], 
[hDED].[OID] as [OID], 
[hDED].[Version] as [Version], 
[hDED].[Data] as [Data], 
[hDED].[rf_DTDGuid] as [rf_DTDGuid], 
[hDED].[rf_DocID] as [rf_DocID], 
[hDED].[Flags] as [Flags], 
[hDED].[ResponseCode] as [ResponseCode], 
[hDED].[Response] as [Response], 
[hDED].[CreateDate] as [CreateDate]
FROM [hl7_Document] as [hDED]
go

