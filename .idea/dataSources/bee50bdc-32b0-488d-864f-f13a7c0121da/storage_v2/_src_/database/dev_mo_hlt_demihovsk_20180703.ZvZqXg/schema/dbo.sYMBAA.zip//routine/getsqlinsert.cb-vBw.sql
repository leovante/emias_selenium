
/* 
Функция генерит запрос для изменения/вставки  записи 
перчисленных  доктипов

1861
HeadTable				Description

hlt_TAP					Таблица амбулаторного посещения
hlt_DoctorTimeTable		Таблица режима работы врача
hlt_DoctorVisitTable	Таблица посещения для врача
hlt_Uchastok			Участок
hlt_Separation			Отделение
hlt_LPUDoctor			Медицинский персонал
hlt_HealingRoom			Кабинет
hlt_ServiceMedical		Содержит информацию о медицинских услугах
hlt_SMTAP				Оказанная медицинская помощь
--hlt_NotWorkDoc			Документ временной нетрудоспособности
*/

CREATE FUNCTION [dbo].[GetSQLInsert]
( @name varchar(50), @Id int )
RETURNS varchar(8000) 
AS
BEGIN
	declare @rez varchar(8000)
    set @rez=''
if(@name ='hlt_TAP')
	begin
		select @rez=
			'if (not exists (select * from  hlt_Tap where UGUID =''' +Convert(Varchar(100),hlt_Tap.Uguid)+'''))'
			+' INSERT INTO [hlt_TAP] ' +
			+'([CarePersonSex],[CarePersonAge],[DateTAP],[DateClose],[UGUID],[S_POL],[N_POL],[IsClosed],[isWorker],[CareBegin],[CareEnd],[FAMILY],[Description],[rf_KATLID],[rf_TypeSellID],[rf_TypeVisitID],[rf_GoalVisitID]' 
			+',[rf_ResultVisitID],[rf_MKBID],[rf_MKB2ID],[rf_ILLTypeID],[rf_ILLType2ID],[rf_DUTypeID],[rf_TRTypeID],[rf_DUType2ID] '
			+',[rf_ReasonCareID],[rf_INVID],[rf_NotWorkDocStatusID],[rf_LPUDoctorID],/*[rf_LPUDoctor_SID],*/[rf_SMOID],[rf_OtherSMOID] '
			+',[rf_SpecEventCertID],[rf_SocStatusID],/*[rf_MKABSheetFinalDSID],[rf_DirectionID],*/[rf_OutcomeVisitID] '
			+') select '
			+''''
			+convert(varchar,[CarePersonSex])+''','''
			+convert(varchar,[CarePersonAge])+''','
			+'Convert(datetime,'''+Convert(varchar,[DateTAP],102)+''',102),'
			+'Convert(datetime,'''+Convert(varchar,[DateClose],102)+''',102),'''
			+convert(varchar(100),hlt_Tap.[UGUID])+''','''
			+[S_POL]+''','''
			+[N_POL]+''','''
			+convert(varchar,[IsClosed])+''','''
			+convert(varchar,[isWorker])+''','
			+'Convert(datetime,'''+Convert(varchar,[CareBegin],102)+''',102),'
			+'Convert(datetime,'''+Convert(varchar,[CareEnd],102)+''',102),'''
			+[FAMILY]+''','''
			+[Description]+''','
			+'isnull((select convert(varchar, KatlID) from oms_Katl  where C_Katl = ''' +C_Katl+'''),''0''),'
			+'isnull((select convert(varchar, TypeSellID) from hlt_TypeSell  where COD = ''' +convert(varchar,hlt_TypeSell.COD)+'''),''0''),'
			+'isnull((select convert(varchar, TypeVisitID) from hlt_TypeVisit  where COD = ''' +convert(varchar,hlt_TypeVisit.COD)+'''),''0''),'
			+'isnull((select convert(varchar, GoalVisitId) from hlt_GoalVisit  where COD = ''' +convert(varchar,hlt_GoalVisit.COD)+'''),''0''),'
			+'isnull((select convert(varchar, ResultVisitID) from hlt_ResultVisit  where COD = ''' +convert(varchar,hlt_ResultVisit.COD)+'''),''0''),'
			+'isnull((select convert(varchar, MKBID) from oms_MKB  where DS = ''' +convert(varchar,MKB.DS)+'''),''0''),'
			+'isnull((select convert(varchar, MKBID) from oms_MKB  where DS = ''' +convert(varchar,MKB2.DS)+'''),''0''),'
			+'isnull((select convert(varchar, ILLTypeID) from hlt_ILLType  where COD = ''' +convert(varchar,ILLType.COD)+'''),''0''),'
			+'isnull((select convert(varchar, ILLTypeID) from hlt_ILLType  where COD = ''' +convert(varchar,ILLType2.COD)+'''),''0''),'
			+'isnull((select convert(varchar, DUTypeID) from hlt_DUType  where COD = ''' +convert(varchar,hlt_DUType.COD)+'''),''0''),'
			+'isnull((select convert(varchar, TRTypeID) from hlt_TRType  where COD = ''' +convert(varchar,hlt_TRType.COD)+'''),''0''),'
			+'isnull((select convert(varchar, DUTypeID) from hlt_DUType  where COD = ''' +convert(varchar,hlt_DUType2.COD)+'''),''0''),'
			+'isnull((select convert(varchar, ReasonCareID) from hlt_ReasonCare  where COD = ''' +convert(varchar,hlt_ReasonCare.COD)+'''),''0''),'
			+'isnull((select convert(varchar, InvID) from hlt_INV  where COD = ''' +convert(varchar,hlt_INV.COD)+'''),''0''),'
			+'isnull((select convert(varchar, NotWorkDocStatusID) from hlt_NotWorkDocStatus  where COD = ''' +convert(varchar,hlt_NotWorkDocStatus.COD)+'''),''0''),'
			+'isnull((select convert(varchar, LPUDoctorID) from hlt_LPUDoctor where UGUID = ''' +convert(varchar(100),hlt_LPUDoctor.UGUID)+'''),''0''),'
			+'isnull((select convert(varchar, SMOID) from oms_SMO  where Q_OGRN = ''' +convert(varchar,smo.Q_OGRN)+'''),''0''),'
			+'isnull((select convert(varchar, SMOID) from oms_SMO  where Q_OGRN = ''' +convert(varchar,smo2.Q_OGRN)+'''),''0''),'
			/*[rf_LPUDoctor_SID],*/
			+'isnull((select convert(varchar, SpecEventCertID) from hlt_SpecEventCert  where CODE = ''' +convert(varchar,hlt_SpecEventCert.CODE)+'''),''0''),'
			+'isnull((select convert(varchar, SocStatusID) from hlt_SocStatus  where COD = ''' +convert(varchar,hlt_SocStatus.COD)+'''),''0''),'
			/*[rf_MKABSheetFinalDSID],
			[rf_DirectionID],*/
			+'isnull((select convert(varchar, OutcomeVisitID) from hlt_OutcomeVisit  where CODE = ''' +convert(varchar,hlt_OutcomeVisit.CODE)+'''),''0'')'
			+' else UPDATE [hlt_TAP] set '
			+'[CarePersonSex]='''+convert(varchar,[CarePersonSex])+''''
			+',[CarePersonAge]='''+convert(varchar,[CarePersonAge])+''''
			+',[DateTAP]= Convert(datetime,'''+Convert(varchar,[DateTAP],102)+''',102)'
			+',[DateClose]=Convert(datetime,'''+Convert(varchar,[DateClose],102)+''',102)'
			+',[S_POL]='''+[S_POL]+''''
			+',[N_POL]='''+[N_POL]+''''
			+',[IsClosed]='''+convert(varchar,[IsClosed])+''''
			+',[isWorker]='''+convert(varchar,[IsWorker])+''''
			+',[CareBegin]=Convert(datetime,'''+Convert(varchar,[CareBegin],102)+''',102)'
			+',[CareEnd]=Convert(datetime,'''+Convert(varchar,[CareEnd],102)+''',102)'
			+',[FAMILY]='''+[FAMILY]+''''
			+',[Description]='''+[Description]+''''
			+',[rf_KATLID]=isnull((select convert(varchar, KatlID) from oms_Katl  where C_Katl = ''' +C_Katl+'''),''0'')'
			+',[rf_TypeSellID]=isnull((select convert(varchar, TypeSellID) from hlt_TypeSell  where COD = ''' +convert(varchar,hlt_TypeSell.COD)+'''),''0'')'
			+',[rf_TypeVisitID]=isnull((select convert(varchar, TypeVisitID) from hlt_TypeVisit  where COD = ''' +convert(varchar,hlt_TypeVisit.COD)+'''),''0'')'
			+',[rf_GoalVisitID]=isnull((select convert(varchar, GoalVisitId) from hlt_GoalVisit  where COD = ''' +convert(varchar,hlt_GoalVisit.COD)+'''),''0'')' 
			+',[rf_ResultVisitID]=isnull((select convert(varchar, ResultVisitID) from hlt_ResultVisit  where COD = ''' +convert(varchar,hlt_ResultVisit.COD)+'''),''0'')'
			+',[rf_MKBID]=isnull((select convert(varchar, MKBID) from oms_MKB  where DS = ''' +convert(varchar,MKB.DS)+'''),''0'')'
			+',[rf_MKB2ID]=isnull((select convert(varchar, MKBID) from oms_MKB  where DS = ''' +convert(varchar,MKB2.DS)+'''),''0'')'
			+',[rf_ILLTypeID]=isnull((select convert(varchar, ILLTypeID) from hlt_ILLType  where COD = ''' +convert(varchar,ILLType.COD)+'''),''0'')'
			+',[rf_ILLType2ID]=isnull((select convert(varchar, ILLTypeID) from hlt_ILLType  where COD = ''' +convert(varchar,ILLType2.COD)+'''),''0'')'
			+',[rf_DUTypeID]=isnull((select convert(varchar, DUTypeID) from hlt_DUType  where COD = ''' +convert(varchar,hlt_DUType.COD)+'''),''0'')'
			+',[rf_TRTypeID]=isnull((select convert(varchar, TRTypeID) from hlt_TRType  where COD = ''' +convert(varchar,hlt_TRType.COD)+'''),''0'')' 
			+',[rf_DUType2ID]=isnull((select convert(varchar, DUTypeID) from hlt_DUType  where COD = ''' +convert(varchar,hlt_DUType2.COD)+'''),''0'')'
			+',[rf_ReasonCareID]=isnull((select convert(varchar, ReasonCareID) from hlt_ReasonCare  where COD = ''' +convert(varchar,hlt_ReasonCare.COD)+'''),''0'')'
			+',[rf_INVID]=isnull((select top 1 convert(varchar, InvID) from hlt_INV  where COD = ''' +convert(varchar,hlt_INV.COD)+'''),''0'')'
			+',[rf_NotWorkDocStatusID]=isnull((select convert(varchar, NotWorkDocStatusID) from hlt_NotWorkDocStatus  where COD = ''' +convert(varchar,hlt_NotWorkDocStatus.COD)+'''),''0'')'
			+',[rf_LPUDoctorID]=isnull((select convert(varchar, LPUDoctorID) from hlt_LPUDoctor where UGUID = ''' +convert(varchar(100),hlt_LPUDoctor.UGUID)+'''),''0'')'
			/*[rf_LPUDoctor_SID],*/
			+',[rf_SMOID]=isnull((select convert(varchar, SMOID) from oms_SMO  where Q_OGRN = ''' +convert(varchar,smo.Q_OGRN)+'''),''0'')'
			+',[rf_OtherSMOID]=isnull((select convert(varchar, SMOID) from oms_SMO  where Q_OGRN = ''' +convert(varchar,smo2.Q_OGRN)+'''),''0'')'
			+',[rf_SpecEventCertID]=isnull((select convert(varchar, SpecEventCertID) from hlt_SpecEventCert  where CODE = ''' +convert(varchar,hlt_SpecEventCert.CODE)+'''),''0'')'
			+',[rf_SocStatusID]=isnull((select convert(varchar, SocStatusID) from hlt_SocStatus  where COD = ''' +convert(varchar,hlt_SocStatus.COD)+'''),''0'')'
			/*[rf_MKABSheetFinalDSID],[rf_DirectionID]*/
			+',[rf_OutcomeVisitID]=isnull((select convert(varchar, OutcomeVisitID) from hlt_OutcomeVisit  where CODE = ''' +convert(varchar,hlt_OutcomeVisit.CODE)+'''),''0'')' 
			+ ' where [UGUID]='''+convert(varchar(100),hlt_Tap.[UGUID])+''''
			from hlt_Tap
				inner join oms_Katl               on KatlId        = rf_KatlId
				inner join hlt_TypeSell			  on TypeSellId    = rf_TypeSellId
				inner join hlt_TypeVisit          on TypeVisitId   = rf_TypeVisitId
				inner join hlt_GoalVisit          on GoalVisitId   = rf_GoalVisitId
				inner join hlt_ResultVisit        on ResultVisitId = rf_ResultVisitId
				inner join oms_MKB    MKB         on MKB.MKBId         = rf_MKBId
				inner join oms_MKB    MKB2        on MKB2.MKBId         = rf_MKB2Id
				inner join hlt_ILLType  ILLType   on ILLType.ILLTypeId         = rf_ILLTypeId
				inner join hlt_ILLType  ILLType2  on ILLType2.ILLTypeId         = rf_ILLType2Id
				inner join hlt_DUType             on hlt_DUType.DUTypeId         = rf_DUType2Id
				inner join hlt_TRType             on TRTypeId         = rf_TRTypeId
				inner join hlt_DUType hlt_DUType2 on hlt_DUType2.DUTypeId         = rf_DUTypeId
				inner join hlt_ReasonCare         on ReasonCareId         = rf_ReasonCareId
				inner join hlt_INV                on INVId         = rf_INVId
				inner join hlt_NotWorkDocStatus   on NotWorkDocStatusId         = rf_NotWorkDocStatusId
				inner join hlt_LPUDoctor          on LPUDoctorId         = rf_LPUDoctorID
				/*inner join oms_LPU                on hlt_LPUDoctor.rf_LPUID         = LPUId*/
				inner join oms_SMO    SMO         on SMO.SMOId         = rf_SMOId
				inner join oms_SMO    SMO2        on SMO2.SMOId          = rf_OtherSMOID
				inner join hlt_SpecEventCert      on rf_SpecEventCertID         = SpecEventCertId
				inner join hlt_SocStatus          on rf_SocStatusID         = SocStatusId
				inner join hlt_OutcomeVisit       on rf_OutcomeVisitID         = OutcomeVisitId
				where TapId= @id
end 
if(@name ='hlt_SMTAP')
	begin
		select @rez='if (not exists (select * from  hlt_SMTap where SMTAPGuid =''' +Convert(varchar(100),SMTAPGuid)+'''))'
		+' INSERT INTO [hlt_SMTAP] ' +
		+'([rf_TAPID],[rf_ServiceMedicalID],[REG_S],[SMTAPGuid],[IsFake],[rf_LPUDoctorID],[Count],[DATE_P],[rf_DoctorVisitTableID],[FLAGS],[rf_LPUID],[rf_MKBID],[Description])'
		+' select '
		+'isnull((select convert(varchar, TApID) from hlt_Tap  where Uguid = ''' +Convert(varchar(100),hlt_Tap.Uguid)+'''),''0''),'
		+'isnull((select convert(varchar, ServiceMedicalID) from hlt_ServiceMedical  where Uguid = ''' +convert(varchar(100),hlt_ServiceMedical.[Uguid])+'''),''0''),'''
		+convert(varchar,[REG_S])+''','''
		+convert(varchar(100),SMTAPGuid)+''','''
		+convert(varchar,[IsFake])+''','
		+'isnull((select convert(varchar, LPUDoctorID) from hlt_LPUDoctor where UGUID = ''' +convert(varchar(100),hlt_LPUDoctor.UGUID)+'''),''0''),'''
		+convert(varchar,hlt_SMTap.[Count])+''','
		+'Convert(datetime,'''+Convert(varchar,[Date_P],102)+''',102),'
		+'isnull((select convert(varchar, DoctorVisitTableID) from hlt_DoctorVisitTable  where Uguid = ''' +convert(varchar(100),hlt_DoctorVisitTable.[Uguid])+'''),''0''),'''
		+convert(varchar,hlt_SMTAP.[FLAGS])+''','
		+'isnull((select convert(varchar, LPUID) from oms_LPU  where C_OGRN = ''' +oms_LPU.C_OGRN+''' and MCOD='''+oms_LPU.MCOD+'''),''0''),'
		+'isnull((select convert(varchar, MKBID) from oms_MKB  where DS = ''' +convert(varchar(10),DS)+'''),''0''),'''
		+hlt_SMTap.[Description]+''''
		+'  else UPDATE [hlt_SMTAP] set '
		+' [rf_TAPID]=isnull((select convert(varchar, TApID) from hlt_Tap  where Uguid = ''' +convert(varchar(100),hlt_Tap.[Uguid])+'''),''0'')'
		+',[rf_ServiceMedicalID]=isnull((select convert(varchar, ServiceMedicalID) from hlt_ServiceMedical  where Uguid = ''' +convert(varchar(100),hlt_ServiceMedical.[Uguid])+'''),''0'')'
		+',[REG_S]='''+convert(varchar,[REG_S])+''''
		+',[IsFake]='''+convert(varchar,[IsFake])+''''
		+',[rf_LPUDoctorID]=isnull((select convert(varchar, LPUDoctorID) from hlt_LPUDoctor where UGUID = ''' +convert(varchar(100),hlt_LPUDoctor.UGUID)+'''),''0'')'
		+',[Count]='''+convert(varchar,[Count])+''''
		+',[Date_P]= Convert(datetime,'''+Convert(varchar,[Date_P],102)+''',102)'
		+',[rf_DoctorVisitTableID]=isnull((select convert(varchar, DoctorVisitTableID) from hlt_DoctorVisitTable  where Uguid = ''' +convert(varchar(100),hlt_DoctorVisitTable.[Uguid])+'''),''0'')'
		+',[Flags]='''+convert(varchar,hlt_SMTAP.[Flags])+''''
		+',[rf_LPUID]=isnull((select convert(varchar, LPUID) from oms_LPU  where C_OGRN = ''' +oms_LPU.C_OGRN+''' and MCOD='''+oms_LPU.MCOD+'''),''0'')'
		+',[rf_MKBID]=isnull((select convert(varchar, MKBID) from oms_MKB  where DS = ''' +convert(varchar,DS)+'''),''0'')'
		+',[Description]='''+hlt_SMTap.[Description]+''''
		+ ' where [SMTAPGUID]='''+convert(varchar(100),[SMTAPGUID])+''''

		from hlt_SMTAP
		inner join oms_MKB			      on MKBId           = rf_MKBId
		inner join oms_LPU                on hlt_SMTAP.rf_LPUID    = oms_LPU.LPUId
		inner join hlt_LPUDoctor          on LPUDoctorId         = rf_LPUDoctorID
		inner join oms_LPU lpu            on hlt_LPUDoctor.rf_LPUID    = lpu.LPUId
		inner join hlt_Tap				  on TapId         = rf_TapID
		inner join hlt_ServiceMedical	  on hlt_SMTap.rf_ServiceMedicalID =ServiceMedicalID
		inner join hlt_DoctorVisitTable   on rf_DoctorVisitTableID =DoctorVisitTableID
		where SMTapId= @id
end
if(@name ='hlt_LPUDoctor')
begin
select	@rez='if (not exists (select * from  hlt_LPUDoctor where UGUID =''' +Convert(Varchar(100),hlt_LPUDoctor.Uguid)+'''))'
			+'INSERT INTO [hlt_LPUDoctor] '
			+' ([UGUID],[PCOD],[OT_V],[IM_V],[D_SER],[FAM_V],[MSG_Text],[isDoctor],[inTime],[DR],[IsSpecial],[rf_LPUID],[rf_PRVDID],[rf_PRVSID],[rf_KV_KATID],[rf_SeparationID])  ( select ' 
		    +''''+convert(varchar(100),hlt_LPUDoctor.UGuid)+''','''

		   +[PCOD]+''','''
           +[OT_V]+''','''
           +[IM_V]+''','
         +  'Convert(datetime,'''+Convert(varchar,[D_SER],102)+''',102),'''
       	   +[FAM_V]+''','''
           +hlt_LPUDoctor.MSG_Text+''','''
           +Convert(varchar,[isDoctor])+''','''
           +Convert(varchar,[inTime])+''','
           +'Convert(datetime,'''+Convert(varchar,[DR],102)+''',102),'''
           +Convert(varchar,[IsSpecial])+''','
 	+ 'isnull((select convert(varchar, LPUID) from oms_LPU  where C_OGRN = ''' +oms_LPU.C_OGRN+''' and MCOD='''+oms_LPU.MCOD+'''),''0''),'
	+ 'isnull((select convert(varchar,PRVDID) from oms_PRVD where C_PRVD = ''' +C_PRVD+'''),''0''),'
	+ 'isnull((select convert(varchar,PRVSID) from oms_PRVS where C_PRVS = ''' +C_PRVS+'''),''0''),'
	+ 'isnull((select convert(varchar,KV_KatID) from oms_Kv_Kat where KVKAT = ''' +convert(varchar,KVKAT)+'''),''0''),'
	+ 'isnull((select convert(varchar, SeparationID) from hlt_Separation  where Uguid = ''' +convert(varchar(100),hlt_Separation.[Uguid])+'''),''0'')'
	+') else UPDATE [hlt_LPUDoctor] set '
	+'[PCOD] = '''+PCOD+''''
	+',[OT_V] = '''+OT_V+''''
	+',[IM_V] = '''+IM_V+''''
	+',[D_SER] = Convert(datetime,'''+Convert(varchar,[D_SER],102)+''',102)'
	+',[FAM_V] = '''+FAM_V+''''
	+',[MSG_Text] = '''+hlt_LPUDoctor.MSG_Text+''''
	+',[isDoctor] = '''+Convert(varchar,isDoctor)+''''
	+',[inTime] = '''  +Convert(varchar,inTime)+''''
	+',[DR]= Convert(datetime,'''+Convert(varchar,[DR],102)+''',102)'
	+',[isSpecial] = '''+Convert(varchar,isSpecial)+''''
    +',[rf_LPUID]  = isnull((select convert(varchar, LPUID) from oms_LPU  where C_OGRN = ''' +oms_LPU.C_OGRN+''' and MCOD='''+oms_LPU.MCOD+'''),''0'')'
    +',[rf_PRVDID] = isnull((select convert(varchar,PRVDID) from oms_PRVD where C_PRVD = ''' +C_PRVD+'''),''0'')'
    +',[rf_PRVSID] = isnull((select convert(varchar,PRVSID) from oms_PRVS where C_PRVS = ''' +C_PRVS+'''),''0'')'
    +',[rf_KV_KatID]= isnull((select convert(varchar,KV_KatID) from oms_Kv_Kat where KVKAT = ''' +convert(varchar,KVKAT)+'''),''0'')'
    +',[rf_SeparationID] =isnull((select convert(varchar, SeparationID) from hlt_Separation  where Uguid = ''' +convert(varchar(100),hlt_Separation.[Uguid])+'''),''0'')'
    +' where [UGUID]='''+convert(varchar(100),hlt_LPUDoctor.[UGUID])+''''
from [hlt_LPUDoctor] 
inner join oms_Prvs on PrvsId = rf_PrvsId
inner join oms_Lpu on LpuId = rf_LpuId
inner join oms_Prvd on PrvdId = rf_PrvdId
inner join oms_kv_kat on kv_katId = rf_kv_katId
inner join hlt_Separation on SeparationId = rf_SeparationId
where LPUDoctorID= @id
end
if(@name ='hlt_DoctorTimeTable')
begin
select @rez=
'if (not exists (select * from  hlt_DoctorTimeTable where UGUID =''' +Convert(Varchar(100),hlt_DoctorTimeTable.Uguid)+'''))'
			+'INSERT INTO [hlt_DoctorTimeTable] '
            +'([Begin_Time],[End_Time],[Date],[rf_LPUDoctorID],[rf_DocBusyType],[FlagAccess],[FLAGS],[UGUID])  ( select ' 
            +'Convert(datetime,'''+Convert(varchar,[Begin_Time],127)+''',127),'
            +'Convert(datetime,'''+Convert(varchar,[End_Time],127)+''',127),' 
            +'Convert(datetime,'''+Convert(varchar,[Date],127)+''',127),'
		    +'isnull((select convert(varchar, LPUDoctorID) from hlt_LPUDoctor where Uguid = ''' +convert(varchar(100),hlt_LPUDoctor.UGUID)+'''),''0''),'
	        +'isnull((select convert(varchar, DocBusyTypeID) from hlt_DocBusyType  where CODE = ''' +convert(varchar(100),hlt_DocBusyType.[CODE])+'''),''0''),'''
			+Convert(varchar,[FlagAccess])+''','''
			+Convert(varchar,hlt_DoctorTimeTable.[FLAGS])+''','''
			+Convert(varchar(100),hlt_DoctorTimeTable.[UGUID])+
'''	) else UPDATE [hlt_DoctorTimeTable] set '
			+'[Begin_Time]=	Convert(datetime,'''+Convert(varchar,[Begin_Time],127)+''',127),'
			+'[End_Time]=	Convert(datetime,'''+Convert(varchar,[End_Time],127)+''',127),'
			+'[Date]=	Convert(datetime,'''+Convert(varchar,[Date],127)+''',127),'
		    +'[rf_LPUDoctorID]= isnull((select convert(varchar, LPUDoctorID) from hlt_LPUDoctor where UGUID = ''' +convert(varchar(100),hlt_LPUDoctor.UGUID)+'''),''0''),'
	        +'[rf_DocBusyType]=isnull((select convert(varchar, DocBusyTypeID) from hlt_DocBusyType  where CODE = ''' +convert(varchar(100),hlt_DocBusyType.[CODE])+'''),''0''),'
			+'[FlagAccess]='''+Convert(varchar,[FlagAccess])+''','
			+'[FLAGS]=''' +Convert(varchar,hlt_DoctorTimeTable.[FLAGS])+''''
            +' where [UGUID]='''+convert(varchar(100),hlt_DoctorTimeTable.[UGUID])+''''

from [hlt_DoctorTimeTable] 
		inner join hlt_LPUDoctor      on LPUDoctorId = rf_LPUDoctorID
	    inner join oms_LPU            on hlt_LPUDoctor.rf_LPUID    = LPUId
		inner join hlt_DocBusyType    on hlt_DoctorTimeTable.rf_DocBusyType = DocBusyTypeID
where DoctorTimeTableID= @id
end
if(@name ='hlt_DoctorVisitTable')
begin
		select @rez='if (not exists (select * from  hlt_DoctorVisitTable where UGUID =''' +Convert(Varchar(100),[hlt_DoctorVisitTable].Uguid)+'''))'
		+'INSERT INTO [hlt_DoctorVisitTable]([rf_DoctorTimeTableID],[rf_TAPID],[Comment],[StubPrintCounter],[VisitStatus],[Flags],[DocComments],[Complaints],[Examination],[Conclusion],[UGUID]) ( select '   
		+'isnull((select convert(varchar, DoctorTimeTableID) from hlt_DoctorTimeTable  where Uguid = ''' +Convert(varchar(100),hlt_DoctorTimeTable.Uguid)+'''),''0''),'
		+'isnull((select convert(varchar, TApID) from hlt_Tap  where Uguid = ''' +Convert(varchar(100),hlt_Tap.Uguid)+'''),''0''),'''
		+Comment+''','''
		/*+'isnull((select convert(varchar, MKBID) from oms_MKB  where DS = ''' +convert(varchar,DS)+'''),''0''),'''*/
		+Convert(varchar,StubPrintCounter)+''','''
		+Convert(varchar,VisitStatus)+''','''
		+Convert(varchar,[hlt_DoctorVisitTable].Flags)+''','''
		+Convert(varchar(8000),DocComments)+''','''
		+Convert(varchar(8000),Complaints)+''','''
		+Convert(varchar(8000),Examination)+''','''
		+Convert(varchar(8000),Conclusion)+''','''
		+Convert(varchar(8000),[hlt_DoctorVisitTable].Uguid)+''''
		+') else UPDATE [hlt_DoctorVisitTable] set '
		+'[rf_DoctorTimeTableID]= isnull((select convert(varchar, DoctorTimeTableID) from hlt_DoctorTimeTable  where Uguid = ''' +Convert(varchar(100),hlt_DoctorTimeTable.Uguid)+'''),''0''),'
		+'[rf_TAPID]= isnull((select convert(varchar, TApID) from hlt_Tap  where Uguid = ''' +Convert(varchar(100),hlt_Tap.Uguid)+'''),''0''),'
		+'[Comment]='''+Comment+''','
		+'[StubPrintCounter] ='''+Convert(varchar,StubPrintCounter)+''','
		+'[VisitStatus]='''+Convert(varchar,VisitStatus)+''','
		+'[Flags]='''+Convert(varchar,[hlt_DoctorVisitTable].Flags)+''','
		+'[DocComments] ='''+Convert(varchar(8000),DocComments)+''','
		+'[Complaints] =''' +Convert(varchar(8000),Complaints)+''','
		+'[Examination] ='''+Convert(varchar(8000),Examination)+''','
		+'[Conclusion] =''' +Convert(varchar(8000),Conclusion)+''''
        +' where [UGUID]='''+convert(varchar(100),hlt_DoctorVisitTable.[UGUID])+''''

		from [hlt_DoctorVisitTable]
		inner join hlt_DoctorTimeTable on DoctorTimeTableID=rf_DoctorTimeTableID
		inner join hlt_Tap 			on TapId         = rf_TapID
		/*inner join oms_MKB			on MKBId           = rf_MKBId*/
where DoctorVisitTableID= @id
end
if(@name ='hlt_HealingRoom')
begin
	select @rez = 'if (not exists (select * from  hlt_HealingRoom where UGUID =''' +Convert(Varchar(100),Uguid)+'''))'
		+ ' INSERT INTO [hlt_HealingRoom]([Num],[Comment],[Flat],[UGUID]) (select '''
		+ Num+ ''','''
		+ Comment +''','''
		+ Convert(varchar,Flat)+''','''
		+ Convert(varchar(100),UGUID)+''''
		+ ') else UPDATE [hlt_HealingRoom] set '
		+'[Num]='''+Num+''','
		+'[Comment]='''+Comment+''','
		+'[Flat]='''+Convert(varchar,Flat)+''''
		+' where [UGUID]='''+convert(varchar(100),[UGUID])+''''
		from hlt_HealingRoom
		where HealingRoomID= @id
end
if(@name ='hlt_Separation')
begin
	select @rez = 'if (not exists (select * from  hlt_Separation where UGUID =''' +Convert(Varchar(100),hlt_Separation.Uguid)+'''))'
		+ ' INSERT INTO [hlt_Separation](Code,[Name],[rf_LPUDoctorID],[rf_SeparationTypeID],[rf_ProfileMedHelpID],[UGUID]) (select '''
		+ hlt_Separation.Code+ ''','''
		+hlt_Separation.[Name] +''','
		+'isnull((select convert(varchar, LPUDoctorID) from hlt_LPUDoctor where UGUID = ''' +convert(varchar(100),hlt_LPUDoctor.UGUID)+'''),''0''),'
		+'isnull((select convert(varchar, SeparationTypeID) from hlt_SeparationType  where CODE = ''' +convert(varchar(100),hlt_SeparationType.[CODE])+'''),''0''),'
		+'isnull((select convert(varchar, ProfileMedHelpID) from hlt_ProfileMedHelp  where CODE = ''' +convert(varchar(100),hlt_ProfileMedHelp.[CODE])+'''),''0''),'''
		+Convert(varchar(100),hlt_Separation.UGUID)+''''
		+') else UPDATE [hlt_Separation] set '
		+'[Code]='''+hlt_Separation.Code+''','
		+'[Name]='''+hlt_Separation.[Name]+''','
		+'[rf_LPUDoctorID]= isnull((select convert(varchar, LPUDoctorID) from hlt_LPUDoctor where UGUID = ''' +convert(varchar(100),hlt_LPUDoctor.UGUID)+'''),''0''),'
		+'[rf_SeparationTypeID]= isnull((select convert(varchar, SeparationTypeID) from hlt_SeparationType  where CODE = ''' +convert(varchar(100),hlt_SeparationType.[CODE])+'''),''0''),'
		+'[rf_ProfileMedHelpID] = isnull((select convert(varchar, ProfileMedHelpID) from hlt_ProfileMedHelp  where CODE = ''' +convert(varchar(100),hlt_ProfileMedHelp.[CODE])+'''),''0'')'
		+' where UGUID='''+
		+Convert(varchar(100),hlt_Separation.UGUID)+''''
		from hlt_Separation
		inner join hlt_LPUDoctor on rf_LPUDoctorID = LPUDoctorID
		inner join oms_LPU       on rf_LPUID = LPUID
		inner join hlt_SeparationType on rf_SeparationTypeId = SeparationTypeID
		inner join hlt_ProfileMedHelp on rf_ProfileMedHelpId = ProfileMedHelpID
	where SeparationID= @id
end
if(@name ='hlt_Uchastok')
begin
	select @rez ='if (not exists (select * from  hlt_Uchastok where UGUID =''' +Convert(Varchar(100),hlt_Uchastok.Uguid)+'''))'
		+' INSERT INTO [hlt_Uchastok]([UchastoCaption],[CODE],[rf_LPUDoctorID],[UGUID]) (select '''
		+UchastoCaption+''','''
		+CODE+''','
		+'isnull((select convert(varchar, LPUDoctorID) from hlt_LPUDoctor where UGUID = ''' +convert(varchar(100),hlt_LPUDoctor.UGUID)+'''),''0''),'''
		+Convert(varchar(100),hlt_Uchastok.UGUID)+''''
		+') else UPDATE [hlt_Uchastok] set '
			+'[UchastoCaption]='''+UchastoCaption+''','
			+'[Code]='''+Code+''','
			+'[rf_LPUDoctorID]=isnull((select convert(varchar, LPUDoctorID) from hlt_LPUDoctor where UGUID = ''' +convert(varchar(100),hlt_LPUDoctor.UGUID)+'''),''0'')'
		+' where UGUID='''+Convert(varchar(100),hlt_Uchastok.UGUID)+''''
		from [hlt_Uchastok]
		inner join hlt_LPUDoctor on rf_LPUDoctorID = LPUDoctorID
		where UchastokID= @id
end
if(@name ='hlt_PolyclinicRecipeFederalLG')
begin
	select  @rez ='if (not exists (select * from  hlt_PolyclinicRecipeFederalLG where RecipeGUID =''' +Convert(Varchar(100),RecipeGuid)+''' and NumExport = '''+ Convert(Varchar(100),NumExport)+''' ))'
		+ ' INSERT INTO [hlt_PolyclinicRecipeFederalLG]'+
		+'([DOZ_LS],[KV_ALL],[KEK_State],[rf_MKBID],[Series_Recipe],[Num_Recipe],[rf_FinlID],[rf_PR_LRID],'
		+'[rf_PeriodID],[rf_StatusLPURecipeID],[D_Type],[RecipeGUID],[NumExport],[DateExport],[StatusEdition]'
		+',[PRINT_COUNT],[Description],[FLAGS],[Signa],[rf_DLSID],[rf_KATLID],[C_MNN]'
		+',[NOMK_LS],[rf_SMTAPID],[PersonGUID],[rf_LFID],[DATE_VR],[SS],[PCOD]) ' 
		+'(select '''
		+ DOZ_LS+''','''
		+ convert(varchar(100),KV_ALL)+''','''
		+ convert(varchar(100),KEK_State)+''','
		+ 'isnull((select convert(varchar, MKBID) from  oms_MKB where DS = '''+Convert(varchar(100),oms_MKB.DS) +'''),''0''),'''
		+ Series_Recipe+''','''
		+ convert(varchar(100),Num_Recipe)+''','
		+ 'isnull((select convert(varchar, FinlID) from  oms_Finl where C_Finl = '''+Convert(varchar(100),oms_Finl.C_Finl)+'''),''0''),'
		+ 'isnull((select convert(varchar, PR_LRID) from  oms_PR_LR where PR_LR_VALUE = '''+Convert(varchar(100),oms_PR_LR.PR_LR_VALUE)+'''),''0''),'
		+ 'isnull((select convert(varchar, PeriodID) from  oms_Period where EnumName = '''+Convert(varchar(100),oms_Period.EnumName)+'''),''0''),'
		+ 'isnull((select convert(varchar, StatusLPURecipeID) from  oms_StatusLPURecipe where EnumName = '''+Convert(varchar(100),oms_StatusLPURecipe.EnumName)+'''),''0''),'''
		+ D_Type+''','''
		+ convert(varchar(100),RecipeGUID)+''','''
		+ convert(varchar(100),NumExport)+''','
		+ 'Convert(datetime,'''+Convert(varchar,DateExport,127)+''',127),'''
		+ convert(varchar(100),StatusEdition)+''','''
		+ convert(varchar(100),PRINT_COUNT)+''','''
		+ hlt_PolyclinicRecipeFederalLG.Description+''','''
		+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.FLAGS)+''','''
		+ Signa+''','
		+ 'isnull((select convert(varchar, DLSID) from  oms_DLS where C_DLS = '''+Convert(varchar(100),oms_DLS.C_DLS)+'''),''0''),'
		+ 'isnull((select convert(varchar, KATLID) from  oms_KATL where C_KATL = '''+Convert(varchar(100),oms_KATL.C_KATL)+'''),''0''),'''
		+ convert(varchar(100),C_MNN)+''','''
		+ convert(varchar(100),NOMK_LS)+''','
		+ 'isnull((select convert(varchar, SMTAPID) from  hlt_SMTAP where SMTAPGuid = '''+Convert(varchar(100),hlt_SMTAP.SMTAPGuid)+'''),''0''),'''
		+ convert(varchar(100),PersonGUID)+''','
		+ 'isnull((select convert(varchar, LFID) from  oms_LF where C_LF = '''+Convert(varchar(100),oms_LF.C_LF)+'''),''0''),'
		+ 'Convert(datetime,'''+Convert(varchar,DATE_VR,127)+''',127),'''
		+ SS+''','''
		+ PCOD+''') else UPDATE [hlt_PolyclinicRecipeFederalLG] set '
			+' [DOZ_LS]='''+hlt_PolyclinicRecipeFederalLG.DOZ_LS+''''
			+',[KV_ALL]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.KV_ALL)+''''
			+',[KEK_State]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.KEK_State)+''''
			+',[rf_MKBID]=isnull((select convert(varchar, MKBID) from  oms_MKB where DS = '''+Convert(varchar(100),oms_MKB.DS) +'''),''0'')'
			+',[Series_Recipe]='''+hlt_PolyclinicRecipeFederalLG.Series_Recipe+''''
			+',[Num_Recipe]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.Num_Recipe)+''''
			+',[rf_FinlID]=isnull((select convert(varchar, FinlID) from  oms_Finl where C_Finl = '''+Convert(varchar(100),oms_Finl.C_Finl) +'''),''0'')'
			+',[rf_PR_LRID]=isnull((select convert(varchar, PR_LRID) from  oms_PR_LR where  PR_LR_VALUE = '''+Convert(varchar(100),oms_PR_LR.PR_LR_VALUE) +'''),''0'')'
			+',[rf_PeriodID]=isnull((select convert(varchar, PeriodID) from  oms_Period where EnumName = '''+Convert(varchar(100),oms_Period.EnumName) +'''),''0'')'
			+',[rf_StatusLPURecipeID]=isnull((select convert(varchar, StatusLPURecipeID) from  oms_StatusLPURecipe where EnumName = '''+Convert(varchar(100),oms_StatusLPURecipe.EnumName) +'''),''0'')'
			+',[D_Type]='''+hlt_PolyclinicRecipeFederalLG.D_Type+''''
			+',[RecipeGUID]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.RecipeGUID)+''''
			+',[NumExport]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.NumExport)+''''
			+',[DateExport]=Convert(datetime,'''+Convert(varchar,hlt_PolyclinicRecipeFederalLG.DateExport,127)+''',127)'
			+',[StatusEdition]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.StatusEdition)+''''
			+',[PRINT_COUNT]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.PRINT_COUNT)+''''
			+',[Description]='''+hlt_PolyclinicRecipeFederalLG.Description+''''
			+',[FLAGS]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.FLAGS)+''''
			+',[rf_UserID]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.rf_UserID)+''''
			+',[Signa]='''+hlt_PolyclinicRecipeFederalLG.Signa+''''
			+',[rf_DLSID]=isnull((select convert(varchar, DLSID) from  oms_DLS where C_DLS = '''+Convert(varchar(100),oms_DLS.C_DLS) +'''),''0'')'
			+',[rf_KATLID]=isnull((select convert(varchar, KATLID) from  oms_KATL where C_Katl = '''+Convert(varchar(100),oms_KATL.C_Katl) +'''),''0'')'
			+',[C_MNN]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.C_MNN)+''''
			+',[NOMK_LS]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.NOMK_LS)+''''
			+',[rf_SMTAPID]=isnull((select convert(varchar, SMTAPID) from  hlt_SMTAP where SMTAPGuid = '''+Convert(varchar(100),hlt_SMTAP.SMTAPGUID) +'''),''0'')'
			+',[PersonGUID]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.PersonGUID)+''''
			+',[rf_LFID]=isnull((select convert(varchar, LFID) from  oms_LF where C_LF = '''+Convert(varchar(100),oms_LF.C_LF) +'''),''0'')'
			+',[DATE_VR]=Convert(datetime,'''+Convert(varchar,hlt_PolyclinicRecipeFederalLG.DATE_VR,127)+''',127)'
			+',[SS]='''+hlt_PolyclinicRecipeFederalLG.SS+''''
			+',[PCOD]='''+hlt_PolyclinicRecipeFederalLG.PCOD+''''
+' where [RecipeGUID]='''+ convert(varchar(100),hlt_PolyclinicRecipeFederalLG.RecipeGUID)+''' and NumExport ='''+convert(varchar(100),hlt_PolyclinicRecipeFederalLG.NumExport)+''''
		from hlt_PolyclinicRecipeFederalLG
		inner join oms_MKB				on MKBID   = rf_MKBID
		inner join oms_Finl				on FinlID  = rf_FinlID
        inner join oms_PR_LR			on PR_LRID = rf_PR_LRID
		inner join oms_Period			on PeriodId= rf_PeriodId
		inner join oms_StatusLPURecipe  on StatusLPURecipeId=rf_StatusLPURecipeID
		inner join oms_DLS              on DLSID = rf_DlsID
		inner join oms_KATL             on KatlId = rf_KatLId
		inner join hlt_SMTAP			on SMTAPID = rf_SMTAPID
		inner join oms_LF				on LFID = rf_LFID
	where PolyclinicRecipeFederalLGID= @id
end
if(@name ='hlt_ServiceMedical')
begin
select  @rez='if (not exists (select * from  hlt_ServiceMedical where UGUID =''' +Convert(Varchar(100),hlt_ServiceMedical.UGuid)+'''))'
		+ ' INSERT INTO [hlt_ServiceMedical]'+
		+'([MSG_TEXT],[CODE],[Name],[CODE_LPU],[rf_TypeMedHelpID],'
		+'[rf_ProfileMedHelpID],[rf_UnitMedHelpID],[rf_PRVSID],[rf_PRVDID],[TimeNorm],'
		+'[rf_ServiceMedicalID],[CountEquivUnits],[FullName],[TimeNorm_Var],[IsComplex],'
		+'[Is_Stand],[Not_Oms],[UGUID])' 
		+'(select '''
			+ hlt_ServiceMedical.MSG_TEXT+''','''
			+ hlt_ServiceMedical.CODE+''','''
			+ hlt_ServiceMedical.Name+''','''
			+ hlt_ServiceMedical.CODE_LPU+''','
			+ 'isnull((select convert(varchar, TypeMedHelpID) from  hlt_TypeMedHelp where CODE = '''+Convert(varchar(100),hlt_TypeMedHelp.CODE) +'''),''0''),'
			+ 'isnull((select convert(varchar, ProfileMedHelpID) from  hlt_ProfileMedHelp where CODE = '''+Convert(varchar(100),hlt_ProfileMedHelp.CODE) +'''),''0''),'
			+ 'isnull((select convert(varchar, UnitMedHelpID) from  hlt_UnitMedHelp where CODE = '''+Convert(varchar(100),hlt_UnitMedHelp.CODE) +'''),''0''),'
			+ 'isnull((select convert(varchar, PRVSID) from  oms_PRVS where C_PRVS = '''+Convert(varchar(100),oms_PRVS.C_PRVS) +'''),''0''),'
			+ 'isnull((select convert(varchar, PRVDID) from  oms_PRVD where C_PRVD = '''+Convert(varchar(100),oms_PRVD.C_PRVD) +'''),''0''),'''
			+ convert(varchar(100),hlt_ServiceMedical.TimeNorm)+''','
			+ 'isnull((select convert(varchar, ServiceMedicalID) from  hlt_ServiceMedical where UGUID = '''+Convert(varchar(100),h.UGUID) +'''),''0''),'''
			+ convert(varchar(100),hlt_ServiceMedical.CountEquivUnits)+''','''
			+ hlt_ServiceMedical.FullName+''','''
			+ convert(varchar(100),hlt_ServiceMedical.TimeNorm_Var)+''','''
			+ convert(varchar(100),hlt_ServiceMedical.IsComplex)+''','''
			+ convert(varchar(100),hlt_ServiceMedical.Is_Stand)+''','''
			+ convert(varchar(100),hlt_ServiceMedical.Not_Oms)+''','''
			+ convert(varchar(100),hlt_ServiceMedical.UGUID)+''')'
			+' else UPDATE hlt_ServiceMedical set '
				+' [MSG_TEXT]='''+hlt_ServiceMedical.MSG_TEXT+''''
				+',[CODE]='''+hlt_ServiceMedical.CODE+''''
				+',[Name]='''+hlt_ServiceMedical.Name+''''
				+',[CODE_LPU]='''+hlt_ServiceMedical.CODE_LPU+''''
				+',[rf_TypeMedHelpID]=isnull((select convert(varchar, TypeMedHelpID) from  hlt_TypeMedHelp where CODE = '''+Convert(varchar(100),hlt_TypeMedHelp.Code) +'''),''0'')'
				+',[rf_ProfileMedHelpID]=isnull((select convert(varchar, ProfileMedHelpID) from  hlt_ProfileMedHelp where CODE = '''+Convert(varchar(100),hlt_ProfileMedHelp.Code) +'''),''0'')'
				+',[rf_UnitMedHelpID]=isnull((select convert(varchar, UnitMedHelpID) from  hlt_UnitMedHelp where Code = '''+Convert(varchar(100),hlt_UnitMedHelp.CODE) +'''),''0'')'
				+',[rf_PRVSID]=isnull((select convert(varchar, PRVSID) from  oms_PRVS where C_Prvs = '''+Convert(varchar(100),oms_PRVS.C_PRVS) +'''),''0'')'
				+',[rf_PRVDID]=isnull((select convert(varchar, PRVDID) from  oms_PRVD where C_PRVD = '''+Convert(varchar(100),oms_PRVD.C_PRVD) +'''),''0'')'
				+',[TimeNorm]='''+ convert(varchar(100),hlt_ServiceMedical.TimeNorm)+''''
				+',[rf_ServiceMedicalID]=isnull((select convert(varchar, ServiceMedicalID) from  hlt_ServiceMedical where Uguid = '''+Convert(varchar(100),hlt_ServiceMedical.Uguid) +'''),''0'')'
				+',[CountEquivUnits]='''+ convert(varchar(100),hlt_ServiceMedical.CountEquivUnits)+''''
				+',[FullName]='''+hlt_ServiceMedical.FullName+''''
				+',[TimeNorm_Var]='''+ convert(varchar(100),hlt_ServiceMedical.TimeNorm_Var)+''''
				+',[IsComplex]='''+ convert(varchar(100),hlt_ServiceMedical.IsComplex)+''''
				+',[Is_Stand]='''+ convert(varchar(100),hlt_ServiceMedical.Is_Stand)+''''
				+',[Not_Oms]='''+ convert(varchar(100),hlt_ServiceMedical.Not_Oms)+''''
				+' where hlt_ServiceMedical.[UGUID]='''+ convert(varchar(100),hlt_ServiceMedical.UGUID)+''''
		from hlt_ServiceMedical
		inner join hlt_TypeMedHelp on TypeMedHelpID = rf_TypeMedHelpID
		inner join hlt_ProfileMedHelp on ProfileMedHelpID = rf_ProfileMedHelpID
		inner join hlt_UnitMedHelp on UnitMedHelpID = rf_UnitMedHelpID
		inner join oms_PRVS on PRVSID = rf_PRVSID
		inner join oms_PRVD on PRVDID = rf_PRVDID
        inner join hlt_ServiceMedical h on h.ServiceMedicalID = hlt_ServiceMedical.rf_ServiceMedicalID
        where hlt_ServiceMedical.ServiceMedicalID= @id
end
/*if(@name ='hlt_NotWorkDoc')
begin
	select @rez='if (not exists (select * from  hlt_NotWorkDoc where UGUID =''' +Convert(Varchar(100),hlt_NotWorkDoc.Uguid)+'''))'
					+' INSERT INTO [hlt_NotWorkDoc] ' +
					+'([S_NWDS],[N_NWDS],[DateOpen],[DateClose],[IsCare],[CarePersonAge],[CarePersonSex],[Flag],[rf_NotWorkDocStatusID],[rf_ReasonCareID],[rf_MKABID],[rf_TAPID],[rf_NotWorkDocID],[PlaceEmployment],[DisabledPersonFIO],[DisabledPersonAge],[DisabledPersonSex],[DisabledPersonAddress],[S_NWDS_MAIN_PE],[N_NWDS_MAIN_PE],[IsMainPE],[DateContinueWork],[ResultComment],[rf_CureModeID],[DateDirectMSE],[rf_DocCloseNWDSID],[DocCloseNWDS_FIO],[DocCloseNWDS_PCOD],'
					+'[rf_PR_VS_DocCloseID],[UGUID],[CarePersonFIO],[EstimateDateDelivery],[rf_MKBID]'
					+') ( select '+
					+''''
					+ hlt_NotWorkDoc.S_NWDS+''','''
					+ hlt_NotWorkDoc.N_NWDS+''','
					+ 'Convert(datetime,'''+Convert(varchar,hlt_NotWorkDoc.DateOpen,127)+''',127),'
					+ 'Convert(datetime,'''+Convert(varchar,hlt_NotWorkDoc.DateClose,127)+''',127),'''
					+ convert(varchar(100),hlt_NotWorkDoc.IsCare)+''','''
					+ convert(varchar(5),hlt_NotWorkDoc.CarePersonAge)+''','''
					+ convert(varchar(2),hlt_NotWorkDoc.CarePersonSex)+''','''
					+ convert(varchar(100),hlt_NotWorkDoc.Flag)+''','
					+ 'isnull((select convert(varchar, NotWorkDocStatusID) from  hlt_NotWorkDocStatus where Cod = '''+Convert(varchar(100),hlt_NotWorkDocStatus.COD) +'''),''0''),'
					+ 'isnull((select convert(varchar, ReasonCareID) from  hlt_ReasonCare where COD = '''+Convert(varchar(100),hlt_ReasonCare.Cod) +'''),''0''),'
					+ 'isnull((select convert(varchar, MKABID) from  hlt_MKAB where Uguid = '''+Convert(varchar(100),hlt_MKAB.Uguid) +'''),''0''),'
					+ 'isnull((select convert(varchar, TAPID) from  hlt_TAP where Uguid = '''+Convert(varchar(100),hlt_TAP.Uguid) +'''),''0''),'
					+ 'isnull((select convert(varchar, NotWorkDocID) from  hlt_NotWorkDoc where UGUID = '''+Convert(varchar(100),hlt_NotWorkDoc2.UGUID) +'''),''0''),'''
					+ hlt_NotWorkDoc.PlaceEmployment+''','''
					+ hlt_NotWorkDoc.DisabledPersonFIO+''','''
					+ convert(varchar(100),hlt_NotWorkDoc.DisabledPersonAge)+''','''
					+ convert(varchar(100),hlt_NotWorkDoc.DisabledPersonSex)+''','''
					+ hlt_NotWorkDoc.DisabledPersonAddress+''','''
					+ hlt_NotWorkDoc.S_NWDS_MAIN_PE+''','''
					+ hlt_NotWorkDoc.N_NWDS_MAIN_PE+''','''
					+ convert(varchar(100),hlt_NotWorkDoc.IsMainPE)+''','
					+ 'Convert(datetime,'''+Convert(varchar,hlt_NotWorkDoc.DateContinueWork,127)+''',127),'''
					+ hlt_NotWorkDoc.ResultComment+''','
					+ 'isnull((select convert(varchar, CureModeID) from  hlt_CureMode where Code = '''+Convert(varchar(100),hlt_CureMode.Code) +'''),''0''),'
					+ 'Convert(datetime,'''+Convert(varchar,hlt_NotWorkDoc.DateDirectMSE,127)+''',127),'
					+ 'isnull((select convert(varchar, LPUDoctorID) from  hlt_LPUDoctor where Uguid = '''+Convert(varchar(100),hlt_LPUDoctor.Uguid) +'''),''0''),'''
					+ hlt_NotWorkDoc.DocCloseNWDS_FIO+''','''
					+ hlt_NotWorkDoc.DocCloseNWDS_PCOD+''','
					+ 'isnull((select convert(varchar, PRVSID) from  oms_PRVS where C_PRVS = '''+Convert(varchar(100),oms_PRVS.C_PRVS) +'''),''0''),'''
					+ convert(varchar(100),hlt_NotWorkDoc.UGUID)+''','''
					+ hlt_NotWorkDoc.CarePersonFIO+''','
					+ 'Convert(datetime,'''+Convert(varchar,hlt_NotWorkDoc.EstimateDateDelivery,127)+''',127),'
					+ 'isnull((select convert(varchar, MKBID) from  oms_MKB where DS = '''+Convert(varchar(100),oms_MKB.DS) +'''),''0'')'
					+' ) else UPDATE [hlt_NotWorkDoc] set '
					+' [S_NWDS]='''+hlt_NotWorkDoc.S_NWDS+''''
					+',[N_NWDS]='''+hlt_NotWorkDoc.N_NWDS+''''
					+',[DateOpen] = Convert(datetime,'''+Convert(varchar,hlt_NotWorkDoc.DateOpen,127)+''',127)'
					+',[DateClose]= Convert(datetime,'''+Convert(varchar,hlt_NotWorkDoc.DateClose,127)+''',127)'
					+',[IsCare]='''+ convert(varchar(100),hlt_NotWorkDoc.IsCare)+''''
					+',[CarePersonAge]=''' + convert(varchar(100),hlt_NotWorkDoc.CarePersonAge)+''''
					+',[CarePersonSex]=''' + convert(varchar(100),hlt_NotWorkDoc.CarePersonSex)+''''
					+',[Flag]='''+ convert(varchar(100),hlt_NotWorkDoc.Flag)+''''
					+',[rf_NotWorkDocStatusID]=isnull((select convert(varchar, NotWorkDocStatusID) from  hlt_NotWorkDocStatus where COD = '''+Convert(varchar(100),hlt_NotWorkDocStatus.Cod) +'''),''0'')'
					+',[rf_ReasonCareID]=isnull((select convert(varchar, ReasonCareID) from  hlt_ReasonCare where COD = '''+Convert(varchar(100),hlt_ReasonCare.Cod) +'''),''0'')'
					+',[rf_MKABID]=isnull((select convert(varchar, MKABID) from  hlt_MKAB where UGUID = '''+Convert(varchar(100),hlt_MKAB.UGUID) +'''),''0'')'
					+',[rf_TAPID]=isnull((select convert(varchar, TAPID) from  hlt_TAP where UGUID = '''+Convert(varchar(100),hlt_TAP.UGUID) +'''),''0'')'
					+',[rf_NotWorkDocID]=isnull((select convert(varchar, NotWorkDocID) from  hlt_NotWorkDoc where Uguid = '''+Convert(varchar(100),hlt_NotWorkDoc2.Uguid) +'''),''0'')'
					+',[PlaceEmployment]='''  +hlt_NotWorkDoc.PlaceEmployment+''''
					+',[DisabledPersonFIO]='''+hlt_NotWorkDoc.DisabledPersonFIO+''''
					+',[DisabledPersonAge]='''+ convert(varchar(100),hlt_NotWorkDoc.DisabledPersonAge)+''''
					+',[DisabledPersonSex]='''+ convert(varchar(100),hlt_NotWorkDoc.DisabledPersonSex)+''''
					+',[DisabledPersonAddress]='''+hlt_NotWorkDoc.DisabledPersonAddress+''''
					+',[S_NWDS_MAIN_PE]='''+hlt_NotWorkDoc.S_NWDS_MAIN_PE+''''
					+',[N_NWDS_MAIN_PE]='''+hlt_NotWorkDoc.N_NWDS_MAIN_PE+''''
					+',[IsMainPE]='''+ convert(varchar(100),hlt_NotWorkDoc.IsMainPE)+''''
					+',[DateContinueWork]=Convert(datetime,'''+Convert(varchar,hlt_NotWorkDoc.DateContinueWork,127)+''',127)'
					+',[ResultComment]='''+hlt_NotWorkDoc.ResultComment+''''
					+',[rf_CureModeID]=isnull((select convert(varchar, CureModeID) from  hlt_CureMode where Code = '''+Convert(varchar(100),hlt_CureMode.Code) +'''),''0'')'
					+',[DateDirectMSE]=Convert(datetime,'''+Convert(varchar,hlt_NotWorkDoc.DateDirectMSE,127)+''',127)'
					+',[rf_DocCloseNWDSID]=isnull((select convert(varchar, LPUDoctorID) from  hlt_LPUDoctor where Uguid = '''+Convert(varchar(100),hlt_LPUDoctor.Uguid) +'''),''0'')'
					+',[DocCloseNWDS_FIO]='''+hlt_NotWorkDoc.DocCloseNWDS_FIO+''''
					+',[DocCloseNWDS_PCOD]='''+hlt_NotWorkDoc.DocCloseNWDS_PCOD+''''
					+',[rf_PR_VS_DocCloseID]=isnull((select convert(varchar, PRVSID) from  oms_PRVS where C_pRVS = '''+Convert(varchar(100),oms_PRVS.C_PRVS) +'''),''0'')'
					+',[UGUID]='''+ convert(varchar(100),hlt_NotWorkDoc.UGUID)+''''
					+',[CarePersonFIO]='''+hlt_NotWorkDoc.CarePersonFIO+''''
					+',[EstimateDateDelivery]=Convert(datetime,'''+Convert(varchar,hlt_NotWorkDoc.EstimateDateDelivery,127)+''',127)'
					+',[rf_MKBID]=isnull((select convert(varchar, MKBID) from  oms_MKB where DS = '''+Convert(varchar(100),oms_MKB.DS) +'''),''0'')
					+''''
				where hlt_NotWorkDoc.Uguid='''+ convert(varchar(100),hlt_NotWorkDoc.Uguid)+''''
		from hlt_NotWorkDoc
				inner join hlt_NotWorkDocStatus on NotWorkDocStatusID = rf_NotWorkDocStatusID
				inner join hlt_ReasonCare on ReasonCareID = rf_ReasonCareID
				inner join hlt_MKAB on MKABID = rf_MKABID
				inner join hlt_TAP on TAPID = rf_TAPID
				inner join hlt_NotWorkDoc hlt_NotWorkDoc2 on hlt_NotWorkDoc2.NotWorkDocID = hlt_NotWorkDoc.rf_NotWorkDocID
				inner join hlt_CureMode on CureModeID = hlt_NotWorkDoc.rf_CureModeID
				inner join hlt_LPUDoctor on LPUDoctorID = rf_LPUDoctorID
				inner join oms_PRVS on PRVSID = rf_PRVSID
				inner join oms_MKB on MKBID = hlt_NotWorkDoc.rf_MKBID
		where hlt_NotWorkDoc.NotWorkDocid= @id
	end*/
RETURN @rez

END
go

