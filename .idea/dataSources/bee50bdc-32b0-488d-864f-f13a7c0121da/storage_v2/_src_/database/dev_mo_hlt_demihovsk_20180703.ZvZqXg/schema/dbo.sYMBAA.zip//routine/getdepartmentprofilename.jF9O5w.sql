
 create FUNCTION [dbo].[GetDepartmentProfileName] (@Field varchar(50))  
RETURNS varchar(150)   AS  
BEGIN 
return (select top 1  Name from  oms_kl_DepartmentProfile where Code=@Field)
END
 go

