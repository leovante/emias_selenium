
CREATE FUNCTION [dbo].[f2dr_GetHomeVisits2] (
	@mkabid INT
	,@mcod VARCHAR(20)
	,@dateFrom DATETIME
	,@dateTo DATETIME
	)
RETURNS @T TABLE (
	id INT
	,state INT
	,date DATETIME
	,timeFrom DATETIME
	,timeTo DATETIME
	,DoctorName VARCHAR(250)
	,DocPrvdName varchar(100)
	)
AS
BEGIN
	DECLARE @CallDocDTDID INT = isnull((
				SELECT DocTypeDefID
				FROM x_DocTypeDef
				WHERE GUID = '743F4CC3-29A1-4F24-882B-33CC9D0ED8FE'
				), 0)

/*-- Коржов С.А.*/
DECLARE @errCode int
DECLARE @DocPRVDID int
DECLARE @LPUDoctorID int
SET @errCode = (SELECT top 1 ErrorCode FROM [dbo].[f2dr_CheckHomeVisit2] (@mkabid ,@mcod))

SELECT @DocPRVDID = cd.rf_DocPRVDID, @LPUDoctorID = cd.rf_LPUDoctorID FROM [hlt_CallDoctor] cd WITH (NOLOCK)
	INNER JOIN v_hlt_DocPRVD docPRVD WITH (NOLOCK) ON docPRVD.DocPRVDID = 	cd.rf_DocPRVDID
	LEFT JOIN hlt_CallDoctorStatus cds WITH (NOLOCK) ON cd.rf_CallDoctorStatusID = cds.CallDoctorStatusID
		AND cds.CallDoctorStatusID > 0
	WHERE cd.rf_MKABID = @mkabid 
		AND cd.DateCall BETWEEN @dateFrom
			AND @dateTo
if @DocPRVDID <= 0 OR  @LPUDoctorID <= 0 
--if @errCode = -201 OR @errCode = -202 OR @errCode = -203 OR @errCode = -204
/*--*/
	INSERT INTO @T (
		id
		,STATE
		,DATE
		,timeFrom
		,timeTo
		,DoctorName 
		,DocPRVDName
		)

	SELECT cd.CallDoctorID id
		,isnull(cds.Code, 0) AS [state]
		,cd.DateCall AS DATE
		,' ' AS timeFrom
		,' ' AS timeTo
		,'Не назначен' as V_FIO
		,'Не назначено' as V_PRVDName
	FROM [hlt_CallDoctor] cd WITH (NOLOCK)
	INNER JOIN v_hlt_DocPRVD docPRVD WITH (NOLOCK) ON docPRVD.DocPRVDID = 	cd.rf_DocPRVDID
	LEFT JOIN hlt_CallDoctorStatus cds WITH (NOLOCK) ON cd.rf_CallDoctorStatusID = cds.CallDoctorStatusID
		AND cds.CallDoctorStatusID > 0
	WHERE cd.rf_MKABID = @mkabid 
		AND cd.DateCall BETWEEN @dateFrom
			AND @dateTo
else
INSERT INTO @T (
		id
		,STATE
		,DATE
		,timeFrom
		,timeTo
		,DoctorName 
		,DocPRVDName
		)
	SELECT cd.CallDoctorID id
		,isnull(cds.Code, 0) AS [state]
		,cd.DateCall AS DATE
		,isnull(dtt.Begin_Time, cd.DateCall) AS timeFrom -- //
		,isnull(dtt.End_Time, '1900-01-01T19:00:00') AS timeTo -- //
		,docPRVD.V_FIO 
		,docPRVD.V_PRVDName
	FROM [hlt_CallDoctor] cd WITH (NOLOCK)
	INNER JOIN v_hlt_DocPRVD docPRVD WITH (NOLOCK) ON docPRVD.DocPRVDID = 	cd.rf_DocPRVDID
	LEFT JOIN hlt_CallDoctorStatus cds WITH (NOLOCK) ON cd.rf_CallDoctorStatusID = cds.CallDoctorStatusID
		AND cds.CallDoctorStatusID > 0
	LEFT JOIN [hlt_ActionSchedule] acsh WITH (NOLOCK) ON cd.CallDoctorID = acsh.[rf_DocTypeID]
		AND acsh.[DocTypeDefID] = @CallDocDTDID
	LEFT JOIN hlt_DoctorVisitTable dvt WITH (NOLOCK) ON dvt.DoctorVisitTableID = acsh.[rf_DoctorVisitTableID]
	LEFT JOIN hlt_DoctorTimeTable dtt WITH (NOLOCK) ON dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID
	WHERE cd.rf_MKABID = @mkabid 
		AND cd.DateCall BETWEEN @dateFrom
			AND @dateTo
		AND cd.rf_DocPRVDID IN (
			SELECT docprvdid
			FROM hlt_Docprvd WITH (NOLOCK) 
			WHERE rf_Departmentid IN (
					SELECT departmentid
					FROM oms_Department WITH (NOLOCK) 
					WHERE rf_lpuid IN (
							SELECT lpuid 
							FROM oms_LPU WITH (NOLOCK) 
							WHERE mcod = @mcod
							)
					)
			)

	RETURN
END
go

