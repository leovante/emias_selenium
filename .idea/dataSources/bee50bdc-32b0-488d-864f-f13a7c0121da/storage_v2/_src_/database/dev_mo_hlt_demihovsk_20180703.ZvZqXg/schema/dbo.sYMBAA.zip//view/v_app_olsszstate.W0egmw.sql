CREATE VIEW [V_App_OLSSZState] AS SELECT 
[hDED].[OLSSZStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Cod] as [Cod], 
[hDED].[State] as [State], 
[hDED].[Description] as [Description]
FROM [App_OLSSZState] as [hDED]
go

