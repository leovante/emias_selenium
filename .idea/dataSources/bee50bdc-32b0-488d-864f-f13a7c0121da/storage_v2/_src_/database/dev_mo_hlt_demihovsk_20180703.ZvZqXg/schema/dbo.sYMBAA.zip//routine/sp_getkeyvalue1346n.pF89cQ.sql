
--'3E9506CC-BA15-45D1-80B7-691658A4CA60'
CREATE procedure [dbo].[sp_GetKeyValue1346n]
	@guid uniqueidentifier
as
begin
declare @descguid uniqueidentifier
	select top 1 @descguid = hlt_MedRecord.descguid from hlt_MedRecord where hlt_MedRecord.[GUID] = @guid

	select '<!--(@@W@@)-->' as 'key', 
			isnull((SELECT cast(W as varchar(10)) FROM DD_DDForm where ddformguid = @descguid ), '') as 'value'
	union all
    select '<!--(@@ageYParam@@)-->',
			isnull((SELECT cast(DATEDIFF ( yy , hlt_MKAB.DATE_BD , DD_DDForm.SendedToDD ) as varchar(100))
                        FROM DD_DDForm 
                                inner join hlt_MKAB on DD_DDForm.MKABGUID = hlt_MKAB.UGUID                                 
                        where ddformguid = @descguid ), '')
	union all
    select '<!--(@@ageMParam@@)-->',
			isnull((SELECT cast(DATEDIFF ( mm , hlt_MKAB.DATE_BD , DD_DDForm.SendedToDD ) as varchar(100))
                        FROM DD_DDForm 
                                inner join hlt_MKAB on DD_DDForm.MKABGUID = hlt_MKAB.UGUID                                 
                        where ddformguid = @descguid ), '')
	union all
	select '<!--(@@DR@@)-->',
			isnull((SELECT convert(varchar,DR,104) FROM DD_DDForm where ddformguid = @descguid ), '')
	union all
    select '<!--(@@DateStart@@)-->',
			isnull((select top 1 convert(varchar,[SendedToDD],104)  from dd_DDForm d where ddformguid = @descguid), '')
	union all
    select '<!--(@@GrZd@@)-->',
			isnull((SELECT dd_ResultTypeValue.Name FROM dd_ResultTypeValue JOIN dd_ResultValue ON dd_ResultValue.rf_ResultTypeValueGUID = dd_ResultTypeValue.UGUID JOIN dd_ResultType  ON dd_ResultType.UGUID = dd_ResultValue.rf_ResultTypeGUID JOIN DD_DDForm ON dd_ResultValue.rf_DDFormGUID = DD_DDForm.DDFormGUID where ddformguid = @descguid AND dd_ResultType.Name = 'Группа здоровья' ), '')
	union all
    select '<!--(@@FizGr@@)-->',
			isnull((SELECT dd_ResultTypeValue.Name FROM dd_ResultTypeValue JOIN dd_ResultValue ON dd_ResultValue.rf_ResultTypeValueGUID = dd_ResultTypeValue.UGUID JOIN dd_ResultType  ON dd_ResultType.UGUID = dd_ResultValue.rf_ResultTypeGUID JOIN DD_DDForm ON dd_ResultValue.rf_DDFormGUID = DD_DDForm.DDFormGUID where ddformguid = @descguid AND dd_ResultType.Name = 'Физкультурная группа' ), '')
	union all
    select '<!--(@@Family@@)-->', 
			isnull((SELECT Family FROM DD_DDForm where ddformguid = @descguid ), '')
	union all
    select '<!--(@@Name@@)-->', 
			isnull((SELECT Name FROM DD_DDForm where ddformguid = @descguid ), '')
	union all
    select '<!--(@@Patronymic@@)-->',
			isnull((SELECT Patronymic FROM DD_DDForm where ddformguid = @descguid ), '')
	union all
    select '<!--(@@S_POL@@)-->',
			isnull((SELECT S_POL FROM DD_DDForm where ddformguid = @descguid ), '')
	union all
    select '<!--(@@N_POL@@)-->',
			isnull((SELECT N_POL FROM DD_DDForm where ddformguid = @descguid ), '')
	union all
	select '<!--(@@PersonalDocument@@)-->', 
		isnull((SELECT oms_typedoc.Name + (case when (len(oms_typedoc.Name) > 0) then ': ' else '' end) + ' ' + hlt_mkab.S_DOC + ' ' + hlt_MKAB.N_DOC FROM DD_DDForm inner join hlt_mkab on dd_ddform.mkabguid = hlt_mkab.uguid inner join oms_typedoc on hlt_mkab.rf_typedocid = oms_typedoc.TYPEDOCID where ddformguid = @descguid ), '')
	union all
    select '<!--(@@SMONAME@@)-->',
			isnull((SELECT oms_SMO.Q_NAME FROM oms_SMO JOIN DD_DDForm ON DD_DDForm.rf_SMOID=oms_SMO.SMOID where ddformguid = @descguid ), '')
	union all
    select '<!--(@@SS@@)-->', 
			isnull((SELECT SS FROM DD_DDForm where ddformguid = @descguid ), '')
	union all
	select '<!--(@@ADDRESS@@)-->', 
			isnull((SELECT ADDRESS FROM DD_DDForm where ddformguid = @descguid ), '')
	union all
	select '<!--(@@NALPU@@)-->',
			isnull((SELECT 
							NALPU =
								CASE
									WHEN (oms_LPU.ADRES = '' ) THEN oms_LPU.M_NAMEF
									ELSE (oms_LPU.M_NAMEF + ',' +  oms_LPU.ADRES )
								END
										FROM oms_LPU 
									JOIN dd_DDForm ON dd_DDForm.rf_LPUID = oms_LPU.LPUID
										 where ddformguid = @descguid ), '')
	
	
	
	union all
	select '<!--(@@LPUNAMEBYMKAB@@)-->',
			isnull((SELECT 
					oms_LPU.M_NAMEF
					FROM oms_LPU 
						join hlt_MKAB on hlt_MKAB.rf_LPUID = oms_LPU.LPUID
						join dd_DDForm ON dd_DDForm.MKABGUID = hlt_MKAB.UGUID									
					where ddformguid = @descguid ), '')	
	union all
	select '<!--(@@LPUADDRESSBYMKAB@@)-->',
			isnull((SELECT 
					oms_LPU.ADRES
					FROM oms_LPU 
						join hlt_MKAB on hlt_MKAB.rf_LPUID = oms_LPU.LPUID
						join dd_DDForm ON dd_DDForm.MKABGUID = hlt_MKAB.UGUID									
						where ddformguid = @descguid ), '')		
	
	union all
    select '<!--(@@VesValue@@)-->',
			isnull((SELECT Value FROM DD_HealthIndicators  
									JOIN DD_HealthIndex ON DD_HealthIndex.UGUID=DD_HealthIndicators.rf_HealthIndexUGUID
									JOIN DD_DDForm ON DD_DDForm.DDFormGUID=DD_HealthIndicators.rf_DDFormGUID
								where ddformguid = @descguid AND DD_HealthIndex.HealthIndexName = 'Вес' ), '')
	union all
	select '<!--(@@RostValue@@)-->', isnull((SELECT Value FROM DD_HealthIndicators  
									JOIN DD_HealthIndex ON DD_HealthIndex.UGUID=DD_HealthIndicators.rf_HealthIndexUGUID
									JOIN DD_DDForm ON DD_DDForm.DDFormGUID=DD_HealthIndicators.rf_DDFormGUID 									
								where ddformguid = @descguid AND DD_HealthIndex.HealthIndexName = 'Рост' ), '')
	union all
    select '<!--(@@OkrGolovy@@)-->',
			isnull((SELECT Value FROM DD_HealthIndicators  
									JOIN DD_HealthIndex ON DD_HealthIndex.UGUID=DD_HealthIndicators.rf_HealthIndexUGUID
									JOIN DD_DDForm ON DD_DDForm.DDFormGUID=DD_HealthIndicators.rf_DDFormGUID
								 where ddformguid = @descguid AND DD_HealthIndex.HealthIndexName = 'Окружность головы' ), '')
	union all
    select '<!--(@@ExamsList@@)-->',
		   isnull((
                    select stuff((SELECT ', &nbsp; ' + CONVERT(VARCHAR,dd_DDExam.DateExam,104) + ' : ' + dd_DDService.DDServiceName
						FROM dd_DDExam
						JOIN dd_DDService ON dd_DDService.UGUID = dd_DDExam.rf_DDServiceGUID
						JOIN dd_DDForm ON dd_DDForm.DDFormGUID = dd_DDExam.rf_DDFormGUID 
						--inner join hlt_MedRecord on DD_DDForm.DDFormGUID = hlt_MedRecord.DescGuid 
						where --hlt_MedRecord.[GUID] = @guid 
						ddformguid = @descguid AND dd_DDService.DDServiceID<>0
						 for xml path(''),type).value('.','varchar(max)'),1,9,'')), '')
	union all
	select '<!--(@@ResearchLFList@@)-->', 
			isnull((
                    select stuff(( SELECT ', &nbsp; '+  CONVERT(VARCHAR,dd_DDResearchLF.DateBegin,104) + ' : ' + dd_DDService.DDServiceName 
						FROM dd_DDResearchLF 
								JOIN dd_DDService ON dd_DDService.UGUID = dd_DDResearchLF.rf_DDServiceGUID 
								JOIN dd_DDForm ON dd_DDForm.DDFormGUID = dd_DDResearchLF.rf_DDFormGUID 
						 --inner join hlt_MedRecord on DD_DDForm.DDFormGUID = hlt_MedRecord.DescGuid 
						 where --hlt_MedRecord.[GUID] =  @guid	
						 ddformguid = @descguid
						 for xml path(''),type).value('.','varchar(max)'),1,9,'')), '')
	union all
	select '<!--(@@FioDoctor@@)-->', 
			isnull((SELECT (hlt_LPUDoctor.FAM_V + ' ' + substring(hlt_LPUDoctor.IM_V, 1, 1) + '.' +
												substring(hlt_LPUDoctor.OT_V, 1, 1) + '.')
										FROM hlt_LPUDoctor 
											JOIN dd_DDForm ON dd_DDForm.rf_LPUDoctorGUID = hlt_LPUDoctor.UGUID
										 --inner join hlt_MedRecord on DD_DDForm.DDFormGUID = hlt_MedRecord.DescGuid 
										 where --hlt_MedRecord.[GUID] = @guid 
										 ddformguid = @descguid
										 AND hlt_LPUDoctor.LPUDoctorID <> 0 ), '')
	union all
	Select '<!--(@@EduAddress@@)-->',
		isnull((select [address] from dd_Organization 
		join 
			(
				select 
				  c.value('@instanceid', 'int') as instanceid
				from 
				 (
				select *, cast(convert(nvarchar(max),data) as xml) as [xmldata] 
				 from [hlt_MedRecord] 
				 where (data != '') and (data != '</ns0:root>') and [guid] = @guid
				 ) t1
				 cross apply 
				 xmldata.nodes('declare namespace ns0="http://xml.softrust.ru/schema/AddoHtm";/ns0:root/ns0:element') as T(c)
				 where  c.value('@id', 'varchar(50)') = 'EduNameIDInput'
			)ttt on dd_Organization.OrganizationID = ttt.instanceid
			), '')
end
go

