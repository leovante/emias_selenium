
CREATE FUNCTION [dbo].[GetGestatioAge](@pergGuid uniqueidentifier, @DateOpen datetime, @FirstGestationalAge int, @gestBirth int)
RETURNS int
AS
BEGIN
	-- если исход беременности еще НЕ установлен
	if (@pergGuid = '00000000-0000-0000-0000-000000000000')
	begin
		--если дата первичного осмотра НЕ установлена (равно 1900) тогда вернем 0 - Чтобы заполнили!!!
		IF (CONVERT(VARCHAR, @DateOpen, 104) = '01.01.1900')
		begin
			return 0;
		end
		else -- если же дата первичного осмотра установлена, тогда, считаем ТЕКУЩУЮ неделю
		begin
			-- разница в неделях между текущей датой и датой первичного осмотра.
			declare @diffWeeks int, @countWeeks int;
			set @diffWeeks = DATEDIFF("ww",@DateOpen,GETDATE());
			-- и прибавим количество недель на момент первичного гинекологического осмотра.
			set @countWeeks = @FirstGestationalAge + @diffWeeks;
			return @countWeeks;
		end
	end
	--Исход беременности установлен
	-- Если указан исход беременности, тогда выводим значение gestbirth
	return @gestBirth	
END;
go

