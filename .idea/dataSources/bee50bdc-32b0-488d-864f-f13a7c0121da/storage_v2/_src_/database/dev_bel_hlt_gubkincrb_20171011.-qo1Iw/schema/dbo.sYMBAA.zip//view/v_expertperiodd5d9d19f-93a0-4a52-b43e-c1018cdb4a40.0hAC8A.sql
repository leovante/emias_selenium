CREATE view [V_ExpertPeriodd5d9d19f-93a0-4a52-b43e-c1018cdb4a40] as select * from [tmp_ExpertPeriodd5d9d19f-93a0-4a52-b43e-c1018cdb4a40]
go

