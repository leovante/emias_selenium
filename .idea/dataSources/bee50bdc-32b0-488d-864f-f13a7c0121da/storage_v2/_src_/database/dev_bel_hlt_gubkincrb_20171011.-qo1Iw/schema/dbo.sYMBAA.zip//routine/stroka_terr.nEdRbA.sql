CREATE FUNCTION stroka_Terr (@MKB_CODES as nvarchar(4000), @pol int, @DateBegin datetime, @DateEnd datetime)
RETURNS TABLE
AS
RETURN (
Select sum(vsego) as vsego,sum(vzr) as vzr,sum(det) as det from(
SELECT 
count(*) as vsego,
isnull(sum(case when (MH.V_AGE >= 18) then 1 else 0 end),0) as vzr,
isnull(sum(case when (MH.V_AGE < 18) then 1 else 0 end),0) as det
from oms_MKB MKB WITH (NOLOCK)
inner join selectByMKB(@MKB_CODES) FU on MKB.MKBID=FU.MKBID
inner join stt_Diagnos DiS WITH (NOLOCK) on (MKB.MKBID=DiS.rf_MKBID) and (DiS.rf_DiagnosTypeID in (select DiagnosTypeID from stt_DiagnosType DiST where Code = '07' OR Code = '10'))
inner join v_stt_MedicalHistory MH WITH (NOLOCK) on (MH.MedicalHistoryID=Dis.rf_MedicalHistoryID) and MH.Sex = @pol
inner join tmp_report_OKATO on OKATOID=MH.rf_OKATOID
inner join v_currentmigrationpatient cmp WITH (NOLOCK) on cmp.rf_medicalHistoryid=medicalhistoryid 
 and (cmp.DateIngoing between @DateBegin and @DateEnd)
inner join stt_migrationpatient mig WITH (NOLOCK) on mig.rf_medicalHistoryid=medicalhistoryid and mig.rf_StationarBranchID>0
inner join stt_StationarBranch WITH (NOLOCK) on StationarBranchID=mig.rf_StationarBranchID 
inner join tmp_report_Dep on tmp_report_Dep.DepartmentID=stt_StationarBranch.rf_DepartmentID 
inner join stt_Injury TRT WITH (NOLOCK) on (TRT.InjuryID = MH.rf_InjuryID)
where TRT.CODE='3'
and mig.migrationPatientID not in (Select top 1 migrationPatientID from stt_migrationPatient
	where rf_medicalHistoryID=medicalHistoryID and rf_StationarBranchID>0
	order by dateIngoing)--не приемное отделение
UNION ALL
Select count(*) as vsego,
isnull(sum(case when (dbo.FullYearAge(hlt_MKAB.DATE_BD,hlt_TAP.DateClose) > 17) then 1 else 0 end),0) as vzr,
isnull(sum(case when (dbo.FullYearAge(hlt_MKAB.DATE_BD,hlt_TAP.DateClose) < 18) then 1 else 0 end),0) as det
from oms_MKB MKB WITH (NOLOCK)
inner join selectByMKB(@MKB_CODES) FU on MKB.MKBID=FU.MKBID
inner join hlt_TAP WITH (NOLOCK) on MKB.MKBID=rf_MKBID and 
(hlt_TAP.DateClose between @DateBegin and @DateEnd)
inner join hlt_MKAB WITH (NOLOCK) ON MKABID=rf_MKABID and (hlt_MKAB.w = @pol)
inner join tmp_report_OKATO on OKATOID=hlt_MKAB.rf_OKATOID
inner join tmp_report_Dep on tmp_report_Dep.DepartmentID=hlt_TAP.rf_DepartmentID
inner join oms_kl_TraumaType TRT WITH (NOLOCK) on kl_TraumaTypeID=rf_kl_TraumaTypeID
inner join (
Select min(TAPID) as mTAPID from hlt_TAP WITH (NOLOCK)
where (hlt_TAP.DateClose between @DateBegin and @DateEnd)
group by rf_MKABID,rf_MKBID
)min_T on TAPID=mTAPID
where TRT.CODE='13'
)t
	)
go

