CREATE FUNCTION dbo.GenSequen (@pred varchar(10))
RETURNS varchar(8)  AS
BEGIN RETURN 
CASE 4-len(convert(varchar(10),@pred)) 
WHEN 0 THEN convert(varchar(10),@pred)
WHEN 1 THEN '0'+convert(varchar(10),@pred)
WHEN 2 THEN '00'+convert(varchar(10),@pred)
WHEN 3 THEN '000'+convert(varchar(10),@pred)
end
END


go

