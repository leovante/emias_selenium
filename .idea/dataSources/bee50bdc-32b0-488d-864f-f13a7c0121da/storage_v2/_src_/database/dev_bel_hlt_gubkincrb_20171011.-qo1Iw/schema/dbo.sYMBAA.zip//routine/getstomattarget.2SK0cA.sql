
create FUNCTION GetStomatTarget
()
 
RETURNS @result TABLE (
   rf_LPUID               int,
   rf_tariffTargetID      int,
   rf_kl_DepartmentTypeId int 
 )
 
AS
 
begin
INSERT INTO @result
select rf_LPUID,  V_oms_LPUTarget.rf_tarifftargetId ,V_oms_LPUTarget.rf_kl_DepartmentTypeId from V_oms_LPUTarget
inner join oms_LPU on lpuid=rf_LPUID
inner join oms_tarifftarget on tarifftargetId = V_oms_LPUTarget.rf_tarifftargetId
where SILENT_rf_kl_DepartmentTypeID='Поликлиника' and TarifftargetCode ='1 уровень.Стомат.' and
C_OGRN in 
(select ValueStr from x_UserSettings where Property like 'ОГРН поликлиники')
 
 
if (not exists (select * from @result))
INSERT INTO @result
select  LPUID as rf_LPUID, 
isnull((select TariffTargetId from oms_tarifftarget where TarifftargetCode ='2 уровень.Стомат.'),0) rf_TariffTargetId,
(select kl_DepartmentTypeid from oms_kl_DepartmentType where code='3') rf_kl_DepartmentTypeid
 from oms_LPU
where C_OGRN in 
(select ValueStr from x_UserSettings where Property like 'ОГРН поликлиники')
union 
 
select  LPUID as rf_LPUID, 
0 rf_TariffTargetId,
(select kl_DepartmentTypeid from oms_kl_DepartmentType where code='3') rf_kl_DepartmentTypeid
 from oms_LPU
where C_OGRN in 
(select ValueStr from x_UserSettings where Property like 'ОГРН поликлиники')
 
Return
 
end
go

