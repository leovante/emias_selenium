CREATE VIEW [V_hlt_LPUDoctor] AS SELECT 
[hDED].[LPUDoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
((('[' + ltrim(rtrim(PCOD)) + '] '+ Upper(substring(ltrim(FAM_V), 1, 1))+ CASE WHEN LEN(FAM_V) > 0  THEN LOWER(SUBSTRING(LTRIM(RTRIM(FAM_V)), 2, LEN(LTRIM(RTRIM(FAM_V))) - 1))  ELSE '' END + ' '  + Upper(substring(ltrim(IM_V), 1, 1)) + '. ' + Upper(substring(ltrim(OT_V), 1, 1)) + '.'))) as [V_DocInfo], 
((([jT_oms_LPU].C_OGRN+' '+PCOD ))) as [V_PCOD], 
[jT_oms_Department].[DepartmentNAME] as [V_DepartmentName], 
[jT_oms_LPU].[C_OGRN] as [V_C_OGRN], 
[jT_oms_PRVS].[PRVS_NAME] as [V_PRVSName], 
[jT_oms_PRVD].[NAME] as [V_PRVDName], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_PRVDID] as [rf_PRVDID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[hDED].[rf_KV_KATID] as [rf_KV_KATID], 
[hDED].[rf_HealingRoomID] as [rf_HealingRoomID], 
[jT_hlt_HealingRoom].[Num] as [SILENT_rf_HealingRoomID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[PCOD] as [PCOD], 
[hDED].[FAM_V] as [FAM_V], 
[hDED].[IM_V] as [IM_V], 
[hDED].[OT_V] as [OT_V], 
[hDED].[DR] as [DR], 
[hDED].[IsSpecial] as [IsSpecial], 
[hDED].[D_SER] as [D_SER], 
[hDED].[isDoctor] as [isDoctor], 
[hDED].[inTime] as [inTime], 
[hDED].[MSG_Text] as [MSG_Text], 
[hDED].[DE_SER] as [DE_SER], 
[hDED].[UGUID] as [UGUID], 
[hDED].[SS] as [SS]
FROM [hlt_LPUDoctor] as [hDED]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
INNER JOIN [oms_PRVD] as [jT_oms_PRVD] on [jT_oms_PRVD].[PRVDID] = [hDED].[rf_PRVDID]
INNER JOIN [hlt_HealingRoom] as [jT_hlt_HealingRoom] on [jT_hlt_HealingRoom].[HealingRoomID] = [hDED].[rf_HealingRoomID]
go

