
CREATE function [dbo].[CheckENPBirthDate] (@ENP nvarchar(17),@BD datetime)
	 returns int
AS
BEGIN
--if (dbo.[CheckENP] (@ENP))=0
--		return 0
if (LEN(@ENP)=16)
	begin
		declare @y int
		set @y = 0;
		set @y = 9999-REVERSE(SUBSTRING(@ENP,5,4))
		declare @m int
		set @m = 99 - SUBSTRING(@ENP,3,2)
		if (@y<1951)
		 set @m=@m-20
		else if @y<2001
			set @m=@m-40
		declare @d int
		set @d=99-SUBSTRING(@ENP,9,2)
		if (@d>50)
			set @d = @d-50
		declare @ret varchar(50)
		declare @ret2 varchar(50)
		set @ret=cast(@y as varchar(4))+'-'+cast(@m /10 as varchar(2))+cast(@m  % 10 as varchar(2))+'-'+cast(@d /10  as varchar(2))+cast(@d %10  as varchar(2))
		set @ret2=cast(@y as varchar(4))+'-'+cast(@d /10 as varchar(2))+cast(@d  % 10 as varchar(2))+'-'+cast(@m /10  as varchar(2))+cast(@m %10  as varchar(2))
		if (@ret=substring(convert(varchar,@BD,121),1,10))or(@ret2=substring(convert(varchar,@BD,121),1,10))
			return 1
		else return 0
    end
     return 0
END


go

