-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [spwlConfirmTicket] 
	-- Add the parameters for the stored procedure here
	@dvtID int,
	@mkabid int,
	@result int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	/* Есть ли такая временная запись? */
	IF NOT EXISTS
	(
		SELECT 1 FROM hlt_DoctorVisitTable WHERE DoctorVisitTableID = @dvtid AND (FLAGS & 16) > 0
	)
	BEGIN
		SET @result = -8	
		RETURN
	END

	/*Снимаем признак брони*/
	UPDATE hlt_DoctorVisitTable
	SET FLAGS = 4
	WHERE DoctorVisitTableID = @dvtid

	
	DECLARE @wlid int
	SET @wlid = isnull((select top 1 WaitingListID from hlt_WaitingList where rf_DoctorVisitTableID = @dvtid),0)

	DELETE FROM  hlt_WaitingList
		WHERE WaitingListID = @wlid	
	
	SET @result = 0
END

go

