-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION CountBadDaysByMigration
(
	-- Add the parameters for the function here
	@MedicalHistoryID int
)
RETURNS Int
AS
BEGIN
	
	DECLARE @Result int	

	select   
	@Result = DateDiff(day,
		dateadd(hh,8,convert(datetime,(convert(varchar,max(dateIngoing),104)),104)),
		case --Ищем день на 8.00
			when 
				(datepart(hh,min(dateIngoing))<=8 and datepart(hh,min(dateIngoing))>=0)
	  		 then dateadd(hh,8,convert(datetime,(convert(varchar,min(dateIngoing),104)),104))
			 else dateadd(hh,32,convert(datetime,(convert(varchar,min(dateIngoing),104)),104))
		end )		 
	from 
	stt_MigrationPatient where rf_medicalHistoryID =@MedicalHistoryID
	and dateIngoing>(
						select min(dateIngoing) 
						from stt_MigrationPatient 
						where rf_medicalHistoryID 
						=@MedicalHistoryID
					 )

	select @Result = case when @Result<0 then 1 else @Result end
	
	RETURN @Result

END
go

