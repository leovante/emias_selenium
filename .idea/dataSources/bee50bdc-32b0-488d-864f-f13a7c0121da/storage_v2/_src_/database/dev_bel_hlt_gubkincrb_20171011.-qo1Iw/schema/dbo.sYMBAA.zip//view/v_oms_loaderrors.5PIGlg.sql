CREATE VIEW [V_oms_LoadErrors] AS SELECT 
[hDED].[LoadErrorsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Value] as [Value], 
[hDED].[description] as [description]
FROM [oms_LoadErrors] as [hDED]
go

