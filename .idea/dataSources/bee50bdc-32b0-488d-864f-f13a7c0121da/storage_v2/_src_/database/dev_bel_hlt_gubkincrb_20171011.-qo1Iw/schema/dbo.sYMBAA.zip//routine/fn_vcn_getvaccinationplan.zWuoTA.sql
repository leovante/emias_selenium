
CREATE FUNCTION dbo.fn_vcn_GetVaccinationPlan 
	(
	@ic int,
	@date_bd datetime,
	@mkabId int,
	@vg int,
	@DateBegin datetime,
	@reasonId int
	)  
RETURNS @resTable TABLE
		(rf_InoculationCardID int,
		rf_VaccinationGroupID int,
		rf_VaccinationTypeID int,
		[Date] datetime,
		rf_VaccineTypeID int,
		rf_SchemaID int,
		rf_SchemaStage int,
		PrevInoculationDate datetime,
		rf_ReasonID int)
AS
BEGIN
		declare @PrevVaccinationType int = 0 
		declare @PrevInoculationDate datetime = @date_bd
		declare @dateNext datetime

		select top 1
			@PrevVaccinationType = isnull(inoc.rf_VaccinationTypeID, 0), 
			@PrevInoculationDate = isnull(inoc.[DateExecute], @date_bd) 
		from vcn_Inoculation inoc
		join vcn_InoculationCard ic on inoc.rf_InoculationCardID = ic.InoculationCardID
		join vcn_Vaccine vac on inoc.rf_ExecuteVaccineID = vac.VaccineID
		join vcn_VaccineType vt on vac.rf_VaccineTypeID = vt.VaccineTypeID
		join vcn_VaccineToVaccinationGroup v2vg on v2vg.rf_VaccineTypeID = vt.VaccineTypeID
		join vcn_VaccinationGroup vg on v2vg.rf_VaccinationGroupID = vg.VaccinationGroupID
		join vcn_Status st on inoc.rf_StatusID = st.StatusID
		join vcn_VaccinationType vct on inoc.rf_VaccinationTypeID = vct.VaccinationTypeID
		where 
		ic.rf_MKABID = @mkabId -- заданный пациент
		and vg.VaccinationGroupID = @vg -- заданная болезнь
		and isExecuted = 1 -- выполненные прививки
		and st.Code != '5'
		order by vct.Code desc, inoc.DateExecute desc, inoc.InoculationID desc

		--print @PrevVaccinationType
		--print @PrevInoculationDate

		-- Определение схемы
		declare @contingent int = 0
		declare @w int = (select rf_kl_SexID from hlt_MKAB where MKABID = @mkabId)

		declare @schema int = 0
		declare @schemaStage int = 0
		declare @ageMin varchar(9) = '000.00.00'

		set @contingent = isnull((select top 1 c2c.rf_ContingentID from vcn_InoculationCard ic
		join vcn_ContingentToCard c2c on c2c.rf_InoculationCardID = ic.InoculationCardID
		where ic.rf_MKABID = @mkabId and c2c.rf_VaccinationGroupID = @vg), 0)

		--print @contingent
		--print @w

		select top 1 
			@schemaStage = ss.SchemaStageID,
			@schema = ss.rf_SchemaID,
			@dateNext = dbo.ymd_AddToDate(@PrevInoculationDate, ss.intervalMinY, ss.intervalMinM, ss.intervalMinD),
			@ageMin = RIGHT('000' + cast(ss.ageMinY as varchar), 3) + '.' + RIGHT('00' + cast(ss.ageMinM as varchar), 2) + '.' + RIGHT('00' + cast(ss.ageMinD as varchar), 2)
		from vcn_SchemaStage ss
		where ss.rf_SchemaID in (
			-- Определение подходящих схем в первом приближении
			select SchemaID 
			from vcn_Schema sch
			where sch.rf_VaccinationGroupID = @vg -- заданная болезнь
			and sch.rf_ReasonID = @reasonId -- заданный календарь
			and isActive = 1 -- активные схемы
			and dbo.ymd_GetDiff(@date_bd, @dateBegin) < RIGHT('000' + cast(sch.ageMaxY as varchar), 3) + '.' + RIGHT('00' + cast(sch.ageMaxM as varchar), 2) + '.' + RIGHT('00' + cast(sch.ageMaxD as varchar), 2) -- учёт максимального возраста
			and sch.rf_ContingentID = @contingent -- учёт группы риска
			and (sch.rf_kl_SexID = 0 or sch.rf_kl_SexID = @w) -- учёт пола
			)
		and ss.rf_PrevVaccinationTypeID = @PrevVaccinationType -- учёт предыдущего шага
		--and (ss.rf_PrevVaccinationTypeID > 0 OR dbo.ymd_GetDiff(@date_bd, @dateBegin) <= RIGHT('000' + cast(ss.ageMinY as varchar), 3) + RIGHT('00' + cast(ss.ageMinM as varchar), 2) + RIGHT('00' + cast(ss.ageMinD as varchar), 2)) -- учёт минимального возраста
		--and RIGHT('000' + cast(ss.ageMinY as varchar), 3) + RIGHT('00' + cast(ss.ageMinM as varchar), 2) + RIGHT('00' + cast(ss.ageMinD as varchar), 2) <= dbo.ymd_GetDiff(@date_bd, @dateEnd) -- учёт минимального возраста
		--and dbo.ymd_AddToDate(@PrevInoculationDate, ss.intervalMinY, ss.intervalMinM, ss.intervalMinD) <= @DateEnd -- учёт минимального интервала между шагами
		order by dbo.ymd_AddToDate(dbo.ymd_AddToDate(@PrevInoculationDate, ss.intervalMinY, ss.intervalMinM, ss.intervalMinD), ss.ageMinY, ss.ageMinM, ss.ageMinD) asc -- поиск шага с минимальной плановой датой следующего шага

		--print @schema
		--print @dateNext
		--print @schemaStage

		-- определение параметров плановой прививки
		if (@DateBegin > @dateNext) SET @dateNext = @DateBegin

		if (@ageMin > dbo.ymd_GetDiff(@date_bd, @dateNext)) SET @dateNext = (select dbo.ymd_AddToDate(@date_bd, ss.ageMinY, ss.ageMinM, ss.ageMinD) from vcn_SchemaStage ss where ss.SchemaStageID = @schemaStage)

		if (select rf_SeasonID from vcn_Schema where SchemaID = @schema) > 0 -- учёт сезона
		begin
			if @dateNext < (select s.DateBegin from vcn_Schema sch join vcn_Season s on sch.rf_SeasonID = s.SeasonID where sch.SchemaID = @schema)
				Set @dateNext = (select s.DateBegin from vcn_Schema sch join vcn_Season s on sch.rf_SeasonID = s.SeasonID where sch.SchemaID = @schema)
			else if @dateNext > (select s.DateEnd from vcn_Schema sch join vcn_Season s on sch.rf_SeasonID = s.SeasonID where sch.SchemaID = @schema)
				Set @schemaStage = 0
		end

		if (@schemaStage > 0)
		begin
			insert into @resTable
			([rf_InoculationCardID],
			[rf_VaccinationGroupID],
			[rf_VaccinationTypeID],
			[Date],
			[rf_VaccineTypeID],
			[rf_SchemaID],
			[rf_SchemaStage],
			[PrevInoculationDate],
			[rf_ReasonID])
			select 
				@ic,
				@vg,
				ss.rf_NextVaccinationTypeID,
				@dateNext,
				vt.VaccineTypeID,
				ss.rf_SchemaID,
				@schemaStage,
				@PrevInoculationDate,
				@reasonId
			from vcn_SchemaStage ss
			join vcn_VaccinationType vnt on ss.rf_NextVaccinationTypeID = vnt.VaccinationTypeID
			join vcn_VaccineType vt on ss.rf_VaccineTypeID = vt.VaccineTypeID
			where ss.SchemaStageID = @schemaStage
		end

		return
END
go

