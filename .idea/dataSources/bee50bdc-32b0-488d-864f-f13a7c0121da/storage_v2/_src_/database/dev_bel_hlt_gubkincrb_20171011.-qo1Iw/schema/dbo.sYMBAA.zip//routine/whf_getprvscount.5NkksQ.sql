-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [whf_GetPRVSCount]
(	
	@dateA DATETIME, 
	@dateB DATETIME,
	@FlagAccess int
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT t1.*, isnull(t2.Tickets,0) as Tickets FROM
		(
			SELECT distinct
				prvs.PRVSID,
				prvs.C_PRVS, 
				prvs.PRVS_NAME	
			FROM oms_PRVS prvs
				INNER JOIN hlt_DocPRVD docPRVD
					ON docPRVD.rf_PRVSID = prvs.PRVSID
				INNER JOIN hlt_DoctorTimeTable dtt
					ON dtt.rf_DocPRVDID = docPRVD.docPRVDID				
			WHERE prvs.PRVSID > 0
			AND docPRVD.docPRVDID > 0
			AND docPRVD.inTime = 1
			AND dtt.DoctorTimeTableID > 0
			AND dtt.Date BETWEEN @dateA AND @dateB			
		) t1
	LEFT JOIN
		(			
				SELECT 
					docPRVD.rf_PRVSID as PRVSID,	
					sum(dtt.PlanUE - dtt.UsedUE) as Tickets
				FROM hlt_DocPRVD docPRVD		
					INNER JOIN hlt_DoctorTimeTable dtt
						ON dtt.rf_DocPRVDID = docPRVD.docPRVDID
					INNER JOIN hlt_DocBusyType dbt
						ON dtt.rf_DocBusyType = dbt.DocBusyTypeID			
					LEFT JOIN hlt_DoctorVisitTable dvt
						ON dvt.rf_DoctorTimeTableID = dtt.DoctorTimeTableID
				WHERE docPRVD.rf_PRVSID > 0
				AND docPRVD.docPRVDID > 0
				AND docPRVD.inTime = 1
				AND dtt.DoctorTimeTableID > 0
				AND dtt.Date BETWEEN @dateA AND @dateB
				AND dbt.TypeBusy = 1
				AND dtt.FlagAccess & @FlagAccess > 0	
				AND dtt.PlanUE > 0		
				GROUP BY docPRVD.rf_PRVSID
			
		)t2
		ON t1.PRVSID = t2.PRVSID
)
go

