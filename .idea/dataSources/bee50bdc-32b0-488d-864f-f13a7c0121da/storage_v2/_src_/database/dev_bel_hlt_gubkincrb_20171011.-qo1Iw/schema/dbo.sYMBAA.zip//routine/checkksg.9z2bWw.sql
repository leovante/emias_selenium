
create function [dbo].[CheckKSG](
@KSG nvarchar(50), 
@List_OperDS nvarchar(4000), -- Список пар из операций и диагнозов вида разделенных ;Пример :(A16.24.006.001,T95);(A16.24.006.001,T91);(A16.08.029.004,) 
                             -- И операция и диагноз не обязательны, но запятая обязательно
@List_DS nvarchar(4000),     -- список диагнозов разделенных запятыми Пример 'T95,T91,A00,'
@Dop_DS nvarchar(4000),     -- список доп.диагнозов разделенных запятыми Пример 'T95,T91,A00,'
@Sex varchar(1),             -- Код пола   2-Женский  ;  1-Мужской
@Ag int,                     -- Возраст на дату поступления
@IsAgeDay bit,
@date datetime,
@dlit int,
@departmentID int
) 
 
returns int
AS
BEGIN
return (
select Sum(case when КСГ=@ksg then T else 0 end) as D
 from (
 select Row_number()over(order by Value desc)as T,КСГ, value  from dbo.getKSG(@List_OperDS,@List_DS,@Dop_DS,@Sex,@Ag,@IsAgeDay,@departmentId,@date,@dlit,' ')
 group by КСГ,Value
 ) tab
)
END
go

