CREATE VIEW [V_stt_DisabilityList] AS SELECT 
[hDED].[DisabilityListID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_NotWorkDocID] as [rf_NotWorkDocID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[UGUID] as [UGUID]
FROM [stt_DisabilityList] as [hDED]
go

