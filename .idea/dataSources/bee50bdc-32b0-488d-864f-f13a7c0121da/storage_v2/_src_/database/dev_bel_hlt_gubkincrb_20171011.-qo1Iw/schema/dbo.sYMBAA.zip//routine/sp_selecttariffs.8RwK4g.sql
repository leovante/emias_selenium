
	CREATE procedure [dbo].[sp_selectTariffs]
			@dateSm datetime,
			@docPrvdId int,
			@departmentId int,		
			@reasonTypeId int,		
			@mkabId int,
			@serviceMedicalId int,
			@result varchar(254) output--выходной параметр в случае ошибки или доп.инфо
	as
	begin
		set @result = ''--информационное сообщение, в случае ошибки или доп.инфо.

		--дополнительные параметры, получаем из входных
		declare @depProfileId int,
				@depTypeId int,
				@lpuId int;
		declare @prvdId int,
				@prvsId int;
		select @depTypeId = ISNULL(rf_kl_DepartmentTypeID, 0), @depProfileId = ISNULL(rf_kl_DepartmentProfileID, 0), @lpuId = ISNULL(rf_LPUID, 0) from oms_Department where DepartmentID = @departmentId;
		select @prvdId = ISNULL(rf_PRVDID, 0), @prvsId = ISNULL(rf_PRVSID, 0) from hlt_DocPRVD where DocPRVDID = @docPrvdId;
		--доп параметры из мкаба
		--select isnull(1, 0) from hlt_MKAB where MKABID = @mkabId;
	
		SELECT top 100
			tariff.TariffID as [Id],
			tariff.GUIDTariff as [UGuid],
			tariff.Value1 as [Value1],
			tariff.Value2 as [Value2],
			tariff.Value3 as [Value3],
			tariff.Value4 as [Value4],
			tariff.Date_B as [Begin],
			tariff.Date_E as [End],
			tariff.rf_LPUID as [LpuId],
			tariff.rf_kl_ReasonTypeID as [ReasonTypeId],
			tariff.rf_ServiceMedicalID as [ServiceMedicalId]	
		from [dbo].[oms_Tariff] tariff
			inner join [dbo].[oms_ServiceMedical] as sm on tariff.rf_ServiceMedicalID = sm.ServiceMedicalID
			inner join [dbo].[oms_LPU] lpu on tariff.rf_LPUID = lpu.LPUID
			inner join [dbo].[oms_kl_ReasonType] rt on tariff.rf_kl_ReasonTypeID = rt.kl_ReasonTypeID
		where tariff.TariffID > 0 
			AND sm.ServiceMedicalID = @serviceMedicalId
			AND lpu.LPUID in (0, @lpuId)
			AND rt.kl_ReasonTypeID in (0, @reasonTypeId)
			AND ((tariff.[Date_B] <= @dateSm) AND (@dateSm <= tariff.[Date_E]))
	end
/*
DECLARE	@result1 varchar(2000)
exec [sp_selectTariffs] @dateSm = '2016-05-20 00:00:00', @docPrvdId = 672, @departmentId = 2332, @reasonTypeId = 4, @mkabId = 2574406, @serviceMedicalId = 14601, @result = @result1 OUTPUT
print @result1
*/
  go

