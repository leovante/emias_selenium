

-- =============================================
-- Author:		Сергей Шумаков
-- Create date: 2010/09/06
-- Description:	Инфомат. Возвращает список отделений.
-- =============================================
CREATE FUNCTION [dbo].[I_ListOfDepartment] 
(		
	@date_a datetime, 
	@date_b datetime, 
	@dbt int,
	@mkabid int
)
RETURNS TABLE 
AS
RETURN 
(
	with schedul(depid, planUE, NormaUE) AS /*Доступные специальности*/
	(
		select hr_departmentid, sum(DTT_PlanUE) as DTT_PlanUE, isnull(sum(DVT_NormaUE),0) as DVT_NormaUE
		from 
		(
				select hr_departmentid, max(DTT_PlanUE) as DTT_PlanUE, isnull(sum(DVT_NormaUE),0) as DVT_NormaUE
				from IV_Schedul 
				where   datepart(hh, dtt_Begin_Time) <> 0 /* отсекаем записи других типов */ 
						and hr_departmentid is not null /*Отделения кабинетов*/
						and dtt_date between @date_a and @date_b
						and DocBusyTypeID = @dbt /**/		        
						and (dtt_FlagAccess & 4) > 0 /*фильтр по правам доступа	*/
				group by DoctorTimeTableID, hr_departmentid
		)t group by  hr_departmentid
	)
	select dp.DepartmentID, dp.DepartmentName,
		 case when (schedul.planUE > schedul.NormaUE) then 1 else 0 end as Active
	from hlt_HealingRoom hr	
	inner join oms_Department dp
	on hr.rf_DepartmentID = dp.DepartmentID and hr.InTime = 1
	left join schedul on dp.DepartmentID = schedul.depid
	where (dp.DepartmentID > 0)
	group by dp.DepartmentID, dp.DepartmentName, schedul.depid, schedul.planUE, schedul.NormaUE 
)
go

