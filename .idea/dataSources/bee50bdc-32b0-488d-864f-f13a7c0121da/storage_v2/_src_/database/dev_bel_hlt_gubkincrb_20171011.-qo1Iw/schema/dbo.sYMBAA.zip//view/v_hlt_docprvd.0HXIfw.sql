CREATE VIEW [V_hlt_DocPRVD] AS SELECT 
[hDED].[DocPRVDID], [hDED].[x_Edition], [hDED].[x_Status], 
(Upper(substring(ltrim(FAM_V), 1, 1))+ CASE WHEN LEN(FAM_V) > 0  THEN LOWER(SUBSTRING(LTRIM(RTRIM(FAM_V)), 2, LEN(LTRIM(RTRIM(FAM_V))) - 1))  ELSE '' END + ' '  + Upper(substring(ltrim(IM_V), 1, 1)) + '. ' + Upper(substring(ltrim(OT_V), 1, 1)) + '.'
) as [V_FIO], 
[jT_oms_Department].[DepartmentNAME] as [V_DepartmentNAME], 
[jT_oms_PRVD].[NAME] as [V_PRVDName], 
[jT_oms_PRVS].[PRVS_NAME] as [V_PRVSName], 
[jT_hlt_LPUDoctor].[PCOD] as [V_Cod], 
[hDED].[rf_PRVDID] as [rf_PRVDID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[hDED].[rf_KV_KATID] as [rf_KV_KATID], 
[jT_oms_KV_KAT].[KVKAT] as [SILENT_rf_KV_KATID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_HealingRoomID] as [rf_HealingRoomID], 
[jT_hlt_HealingRoom].[Num] as [SILENT_rf_HealingRoomID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_EquipmentID] as [rf_EquipmentID], 
[jT_hlt_Equipment].[Name] as [SILENT_rf_EquipmentID], 
[hDED].[rf_ResourceTypeID] as [rf_ResourceTypeID], 
[jT_hlt_ResourceType].[Name] as [SILENT_rf_ResourceTypeID], 
[hDED].[D_PRIK] as [D_PRIK], 
[hDED].[S_ST] as [S_ST], 
[hDED].[D_END] as [D_END], 
[hDED].[MainWorkPlace] as [MainWorkPlace], 
[hDED].[InTime] as [InTime], 
[hDED].[GUID] as [GUID], 
[hDED].[Name] as [Name], 
[hDED].[ShownInSchedule] as [ShownInSchedule], 
[hDED].[ERName] as [ERName], 
[hDED].[ERID] as [ERID], 
[hDED].[NomServiceCode] as [NomServiceCode], 
[hDED].[isSpecial] as [isSpecial], 
[hDED].[isDismissal] as [isDismissal], 
[hDED].[Interval] as [Interval], 
[hDED].[isUseInterval] as [isUseInterval], 
[hDED].[PCOD] as [PCOD]
FROM [hlt_DocPRVD] as [hDED]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [oms_PRVD] as [jT_oms_PRVD] on [jT_oms_PRVD].[PRVDID] = [hDED].[rf_PRVDID]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
INNER JOIN [hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [oms_KV_KAT] as [jT_oms_KV_KAT] on [jT_oms_KV_KAT].[KV_KATID] = [hDED].[rf_KV_KATID]
INNER JOIN [hlt_HealingRoom] as [jT_hlt_HealingRoom] on [jT_hlt_HealingRoom].[HealingRoomID] = [hDED].[rf_HealingRoomID]
INNER JOIN [hlt_Equipment] as [jT_hlt_Equipment] on [jT_hlt_Equipment].[EquipmentID] = [hDED].[rf_EquipmentID]
INNER JOIN [hlt_ResourceType] as [jT_hlt_ResourceType] on [jT_hlt_ResourceType].[ResourceTypeID] = [hDED].[rf_ResourceTypeID]
go

