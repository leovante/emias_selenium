CREATE VIEW [V_dd_DDSexualDevelopment] AS SELECT 
[hDED].[DDSexualDevelopmentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDChildFormID] as [rf_DDChildFormID], 
[jT_dd_DDChildForm].[v_FIO] as [SILENT_rf_DDChildFormID], 
[hDED].[gmPValue] as [gmPValue], 
[hDED].[gmAxValue] as [gmAxValue], 
[hDED].[mFaValue] as [mFaValue], 
[hDED].[gMaValue] as [gMaValue], 
[hDED].[gMeValue] as [gMeValue], 
[hDED].[gMenarheYears] as [gMenarheYears], 
[hDED].[gMenarheMonths] as [gMenarheMonths], 
[hDED].[Flag] as [Flag]
FROM [dd_DDSexualDevelopment] as [hDED]
INNER JOIN [V_dd_DDChildForm] as [jT_dd_DDChildForm] on [jT_dd_DDChildForm].[DDChildFormID] = [hDED].[rf_DDChildFormID]
go

