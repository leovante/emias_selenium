CREATE FUNCTION stroka_Vzroslie (@MKB_CODES as nvarchar(4000),@pol int, @DateBegin datetime, @DateEnd datetime)
RETURNS TABLE
AS
RETURN (
Select sum(pr_prom) as pr_prom,sum(pr_sh) as pr_sh,sum(pr_tr_sum) as pr_tr_sum,sum(pr_tr_avto) as pr_tr_avto,
sum(pr_proch) as pr_proch,sum(npr_byt) as npr_byt,sum(npr_street) as npr_street,sum(npr_tr_sum) as npr_tr_sum,
sum(npr_tr_avto) as npr_tr_avto,sum(npr_sport) as npr_sport,sum(npr_proch) as npr_proch,sum(itogo) as itogo from(
SELECT 
isnull(sum(case when TRT.Code ='1.1' then 1 else 0 end),0) as pr_prom,
isnull(sum(case when TRT.CODE ='1.3' then 1 else 0 end),0) as pr_sh,
isnull(sum(case when TRT.CODE in('1.2','1.2.1') then 1 else 0 end),0) as pr_tr_sum,
isnull(sum(case when TRT.CODE='1.2.1' then 1 else 0 end),0) as pr_tr_avto,
isnull(sum(case when TRT.CODE in('1' ,'1.4') then 1 else 0 end),0) as pr_proch,
isnull(sum(case when TRT.CODE= '2.1' then 1 else 0 end),0) as npr_byt,
isnull(sum(case when TRT.CODE= '2.2' then 1 else 0 end),0) as npr_street,
isnull(sum(case when TRT.CODE in('2.3','2.3.1') then 1 else 0 end),0) as npr_tr_sum,
isnull(sum(case when TRT.CODE= '2.3.1' then 1 else 0  end),0) as npr_tr_avto,
isnull(sum(case when TRT.CODE= '2.5' then 1 else 0 end),0) as npr_sport,
isnull(sum(case when TRT.CODE in ('2','2.4','2.6') then 1 else 0 end),0) as npr_proch,
isnull(sum(case when TRT.CODE not in ('0','3') then 1 else 0 end),0) as itogo
 from oms_MKB MKB WITH (NOLOCK)
inner join selectByMKB(@MKB_CODES) FU on MKB.MKBID=FU.MKBID
inner join stt_Diagnos DiS WITH (NOLOCK) on (MKB.MKBID=DiS.rf_MKBID) and (DiS.rf_DiagnosTypeID in 
(select DiagnosTypeID from stt_DiagnosType DiST WITH (NOLOCK) where Code = '07' OR Code = '10'))
inner join stt_MedicalHistory MH WITH (NOLOCK) on (MH.Sex = @pol) and 
 (MH.MedicalHistoryID=Dis.rf_MedicalHistoryID) and medicalhistoryid>0
inner join tmp_report_OKATO WITH (NOLOCK) on OKATOID=MH.rf_OKATOID
inner join v_currentmigrationpatient cmp WITH (NOLOCK) on cmp.rf_medicalHistoryid=medicalhistoryid and rf_StationarBranchID=0--выписка 
 and (cmp.DateIngoing between @DateBegin and @DateEnd)
inner join stt_migrationpatient mig WITH (NOLOCK) on mig.rf_medicalHistoryid=medicalhistoryid and mig.rf_StationarBranchID>0
inner join stt_StationarBranch WITH (NOLOCK) on StationarBranchID=mig.rf_StationarBranchID 
inner join tmp_report_Dep on tmp_report_Dep.DepartmentID=stt_StationarBranch.rf_DepartmentID 
inner join stt_Injury TRT WITH (NOLOCK) on (TRT.InjuryID = MH.rf_InjuryID)
where (dbo.FullYearAge(MH.BD,cmp.DateIngoing)>= 18) and mig.migrationPatientID not in (Select top 1 migrationPatientID from stt_migrationPatient
	where rf_medicalHistoryID=medicalHistoryID and rf_StationarBranchID>0
	order by dateIngoing)--не приемное отделение
UNION ALL
Select isnull(sum(case when TRT.Code ='1' then 1 else 0 end),0) as pr_prom,
isnull(sum(case when TRT.CODE ='4' then 1 else 0 end),0) as pr_sh,
isnull(sum(case when TRT.CODE in('2','3') then 1 else 0 end),0) as pr_tr_sum,
isnull(sum(case when TRT.CODE='3' then 1 else 0 end),0) as pr_tr_avto,
isnull(sum(case when TRT.CODE='5' then 1 else 0 end),0) as pr_proch,
isnull(sum(case when TRT.CODE= '6' then 1 else 0 end),0) as npr_byt,
isnull(sum(case when TRT.CODE= '7' then 1 else 0 end),0) as npr_street,
isnull(sum(case when TRT.CODE in('8','9') then 1 else 0 end),0) as npr_tr_sum,
isnull(sum(case when TRT.CODE= '9' then 1 else 0  end),0) as npr_tr_avto,
isnull(sum(case when TRT.CODE= '11' then 1 else 0 end),0) as npr_sport,
isnull(sum(case when TRT.CODE in ('10','12') then 1 else 0 end),0) as npr_proch,
isnull(sum(case when TRT.CODE not in ('0','13') then 1 else 0 end),0) as itogo from oms_MKB MKB WITH (NOLOCK)
inner join selectByMKB(@MKB_CODES) FU on MKB.MKBID=FU.MKBID
inner join hlt_TAP WITH (NOLOCK) on MKB.MKBID=rf_MKBID
 and (hlt_TAP.DateClose between @DateBegin and @DateEnd)
inner join hlt_MKAB WITH (NOLOCK) ON (hlt_MKAB.w = @pol) and MKABID=rf_MKABID
inner join tmp_report_OKATO on OKATOID=hlt_MKAB.rf_OKATOID
inner join tmp_report_Dep on tmp_report_Dep.DepartmentID=hlt_TAP.rf_DepartmentID 
inner join oms_kl_TraumaType TRT WITH (NOLOCK) on kl_TraumaTypeID=rf_kl_TraumaTypeID
inner join (
Select min(TAPID) as mTAPID from hlt_TAP WITH (NOLOCK)
where (hlt_TAP.DateClose between @DateBegin and @DateEnd)
group by rf_MKABID,rf_MKBID
)min_T on TAPID=mTAPID
where 
dbo.FullYearAge(hlt_MKAB.DATE_BD,hlt_TAP.DateClose) >= 18
)t
)
go

