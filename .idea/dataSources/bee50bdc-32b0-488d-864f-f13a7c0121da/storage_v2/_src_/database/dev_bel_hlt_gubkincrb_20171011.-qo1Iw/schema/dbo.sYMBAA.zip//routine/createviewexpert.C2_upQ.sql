


CREATE PROCEDURE [dbo].[createViewExpert]  @id int AS 
begin

IF not EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_ViewExpert]') AND type in (N'U'))
CREATE TABLE [dbo].[tmp_ViewExpert](
	[rf_ReportPeriodId] [int] NULL,
	[dep_name] [varchar](8000) NULL,
	[Код] [varchar](10) NOT NULL,
	[Замечание] [varchar](8000) NULL,
	[Амбулатория пациенты] [int] NULL,
	[Амбулатория случаи] [int] NULL,
	[Амбулатория услуги] [int] NULL,
	[Амбулатория Сумма] [decimal](38, 2) NULL,
	[Стационар пациенты] [int] NULL,
	[Стационар случаи] [int] NULL,
	[Стационар услуги] [int] NULL,
	[Стационар сумма] [decimal](38, 2) NULL,
	[Днев.стационар пациенты] [int] NULL,
	[Днев.стационар случаи] [int] NULL,
	[Днев.стационар услуги] [int] NULL,
	[Днев.стационар сумма] [decimal](38, 2) NULL,
	[ID] [int] NOT NULL,
	[Rem] [varchar](8000) NULL,
	[smoid] [int] NULL,
	[main] [int] NOT NULL
) ON [PRIMARY]





IF  EXISTS (SELECT * FROM [tmp_ViewExpert] where rf_ReportperiodId = @id) delete from [tmp_ViewExpert] where rf_ReportperiodId = @id
 

INSERT INTO [tmp_ViewExpert]
           ([rf_ReportPeriodId]
           ,[dep_name]
           ,[Код]
           ,[Замечание]
           ,[Амбулатория пациенты]
           ,[Амбулатория случаи]
           ,[Амбулатория услуги]
           ,[Амбулатория Сумма]
           ,[Стационар пациенты]
           ,[Стационар случаи]
           ,[Стационар услуги]
           ,[Стационар сумма]
           ,[Днев.стационар пациенты]
           ,[Днев.стационар случаи]
           ,[Днев.стационар услуги]
           ,[Днев.стационар сумма]
           ,[ID]
           ,[Rem]
           ,[smoid]
           ,[main])
    
-- Ошибки подробно по СМО 
select @id as rf_ReportPeriodId,* 
from 
(
select '' as dep_name,
        SMCriterionCode as [Код],
	   ' в т. числе '+isnull(isnull(a.Rem,s.Rem),ds.Rem)  as [Замечание],
	   isnull(Sum([Амбулатория пациенты]),0) as [Амбулатория пациенты],
       isnull(Sum([Амбулатория случаи]),0)   as [Амбулатория случаи],  
       isnull(Sum([Амбулатория услуги]),0)   as [Амбулатория услуги], 
       isnull(Sum([Амбулатория Сумма]),0)	 as   [Амбулатория Сумма],
	   isnull(Sum([Стационар пациенты]),0)   as [Стационар пациенты], 
	   isnull(Sum([Стационар случаи]),0)     as [Стационар случаи],
       isnull(Sum([Стационар услуги]),0)     as [Стационар услуги],
       isnull(Sum(s.[Стационар сумма]),0)    as   [Стационар сумма],
       isnull(Sum([Днев.стационар пациенты]),0)   as [Днев.стационар пациенты], 
	   isnull(Sum([Днев.стационар случаи]),0)     as [Днев.стационар случаи],
	   isnull(Sum([Днев.стационар услуги]),0)     as [Днев.стационар услуги],
       isnull(Sum([Днев.стационар сумма]),0)    as   [Днев.стационар сумма],      
       SMCriterionID as [ID], 
	   isnull(isnull(a.Rem,s.Rem), ds.Rem) as [Rem],
	   dep.smoid,
	   SMCriterionID as main
  
from (select  rf_SMOID as smoid from tmp_ExpertPeriod 
group by  rf_SMOID) dep
left join
(
select rf_SMCriterionID as ID,
  count(distinct r.rf_MKABID)  as [Амбулатория пациенты],
   count(distinct v.ReestrMHSMTAPId) as[Амбулатория услуги],
  count(distinct V.rf_TapId) as[Амбулатория случаи],
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Амбулатория Сумма],
  Rem , dep_name , rf_SMOID
  from [hlt_ReestrTAPMHReturns] R    
  inner join tmp_ExpertPeriod v  on   v.ReestrMHSMTAPId= r.rf_ReestrMHSMTAPid and v.rf_MKABId = r.rf_MKABId    
  where v.rf_reportPeriodID =@id and v.rf_MKABId>0 and Rem <>'' 
  group by rf_SMCriterionID, Rem, dep_name, rf_SMOID
) a on  a.rf_Smoid = dep.SMOID
full join  

(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Стационар Сумма],r.Rem, dep_name , rf_SMOID  
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  r.rf_MedicalHistoryID= SK and  r.rf_ReestrOccasionID = SU     
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and r.Rem <>''  and ( Sluch_USL_OK =1 or Sluch_USL_OK =3)
  group by rf_SMCriterionID, r.Rem, dep_name, rf_SMOID
) s on s.ID = a.ID and a.Rem = s.Rem  and s.rf_Smoid = dep.SMOID
full join  

(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Днев.стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Днев.стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Днев.стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Днев.стационар Сумма],r.Rem, dep_name, rf_SMOID   
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  r.rf_MedicalHistoryID= SK and  r.rf_ReestrOccasionID = SU     
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and r.Rem <>''  and Sluch_USL_OK =2 
  group by rf_SMCriterionID, r.Rem, dep_name, rf_SMOID
) ds on ds.ID = a.ID and a.Rem = ds.Rem and ds.rf_Smoid = dep.SMOID
inner join oms_SMCriterion on isnull(ISNULL(a.Id,s.ID), ds.ID) = SMCriterionID 
where not (s.ID is null) or not(a.ID is null) or not (ds.ID is null) 
group by SMCriterionID,SMCriterionCode,isnull(a.Rem,s.Rem),ds.Rem, SMCriterionDescription, dep.smoid
union

-- Ошибки подробно по СМО и отделениям
select dep.dep_name,
        SMCriterionCode as [Код],
	   ' в т. числе '+isnull(isnull(a.Rem,s.Rem),ds.Rem)  as [Замечание],
	   isnull(Sum([Амбулатория пациенты]),0) as [Амбулатория пациенты],
       isnull(Sum([Амбулатория случаи]),0)   as [Амбулатория случаи],  
       isnull(Sum([Амбулатория услуги]),0)   as [Амбулатория услуги], 
       isnull(Sum([Амбулатория Сумма]),0)	 as   [Амбулатория Сумма],
	   isnull(Sum([Стационар пациенты]),0)   as [Стационар пациенты], 
	   isnull(Sum([Стационар случаи]),0)     as [Стационар случаи],
       isnull(Sum([Стационар услуги]),0)     as [Стационар услуги],
       isnull(Sum(s.[Стационар сумма]),0)    as   [Стационар сумма],
       isnull(Sum([Днев.стационар пациенты]),0)   as [Днев.стационар пациенты], 
	   isnull(Sum([Днев.стационар случаи]),0)     as [Днев.стационар случаи],
	   isnull(Sum([Днев.стационар услуги]),0)     as [Днев.стационар услуги],
       isnull(Sum([Днев.стационар сумма]),0)    as   [Днев.стационар сумма],      
       SMCriterionID as [ID], 
	   isnull(isnull(a.Rem,s.Rem), ds.Rem) as [Rem],
	   dep.smoid,SMCriterionID as main
from (select dep_name, rf_SMOID as smoid from tmp_ExpertPeriod 
group by dep_name, rf_SMOID) dep
left join
(
select rf_SMCriterionID as ID,
  count(distinct r.rf_MKABID)  as [Амбулатория пациенты],
   count(distinct v.ReestrMHSMTAPId) as[Амбулатория услуги],
  count(distinct V.rf_TapId) as[Амбулатория случаи],
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Амбулатория Сумма],
  Rem , dep_name , rf_SMOID
  from [hlt_ReestrTAPMHReturns] R    
  inner join tmp_ExpertPeriod v  on   v.ReestrMHSMTAPId= r.rf_ReestrMHSMTAPid and v.rf_MKABId = r.rf_MKABId    
  where v.rf_reportPeriodID =@id and v.rf_MKABId>0 and Rem <>'' 
  group by rf_SMCriterionID, Rem, dep_name, rf_SMOID
) a on a.dep_name =dep.dep_name and a.rf_Smoid = dep.SMOID
full join  

(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Стационар Сумма],r.Rem, dep_name , rf_SMOID  
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  r.rf_MedicalHistoryID= SK and  r.rf_ReestrOccasionID = SU     
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and r.Rem <>''  and ( Sluch_USL_OK =1 or Sluch_USL_OK =3)
  group by rf_SMCriterionID, r.Rem, dep_name, rf_SMOID
) s on s.ID = a.ID and a.Rem = s.Rem and dep.dep_name = s.dep_name and s.rf_Smoid = dep.SMOID
full join  

(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Днев.стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Днев.стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Днев.стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Днев.стационар Сумма],r.Rem, dep_name, rf_SMOID   
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  r.rf_MedicalHistoryID= SK and  r.rf_ReestrOccasionID = SU     
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and r.Rem <>''  and Sluch_USL_OK =2 
  group by rf_SMCriterionID, r.Rem, dep_name, rf_SMOID
) ds on ds.ID = a.ID and a.Rem = ds.Rem and ds.rf_Smoid = dep.SMOID
inner join oms_SMCriterion on isnull(ISNULL(a.Id,s.ID), ds.ID) = SMCriterionID 
where not (s.ID is null) or not(a.ID is null) or not (ds.ID is null) and  dep.dep_name = ds.dep_name
group by SMCriterionID,SMCriterionCode,isnull(a.Rem,s.Rem),ds.Rem, SMCriterionDescription, dep.dep_name, dep.smoid
union

-- Ошибки подробно по отделениям
select dep.dep_name,
        SMCriterionCode as [Код],
	   ' в т. числе '+isnull(isnull(a.Rem,s.Rem),ds.Rem)  as [Замечание],
	   isnull(Sum([Амбулатория пациенты]),0) as [Амбулатория пациенты],
       isnull(Sum([Амбулатория случаи]),0)   as [Амбулатория случаи],  
       isnull(Sum([Амбулатория услуги]),0)   as [Амбулатория услуги], 
       isnull(Sum([Амбулатория Сумма]),0)	 as   [Амбулатория Сумма],
	   isnull(Sum([Стационар пациенты]),0)   as [Стационар пациенты], 
	   isnull(Sum([Стационар случаи]),0)     as [Стационар случаи],
       isnull(Sum([Стационар услуги]),0)     as [Стационар услуги],
       isnull(Sum(s.[Стационар сумма]),0)    as   [Стационар сумма],
       isnull(Sum([Днев.стационар пациенты]),0)   as [Днев.стационар пациенты], 
	   isnull(Sum([Днев.стационар случаи]),0)     as [Днев.стационар случаи],
	   isnull(Sum([Днев.стационар услуги]),0)     as [Днев.стационар услуги],
       isnull(Sum([Днев.стационар сумма]),0)    as   [Днев.стационар сумма],      
       SMCriterionID as [ID], 
	   isnull(isnull(a.Rem,s.Rem), ds.Rem) as [Rem],-1,SMCriterionID as main
from
(
select dep_name  from tmp_ExpertPeriod 
group by dep_name) dep
left join
(
select rf_SMCriterionID as ID,
  count(distinct r.rf_MKABID)  as [Амбулатория пациенты],
   count(distinct v.ReestrMHSMTAPId) as[Амбулатория услуги],
  count(distinct V.rf_TapId) as[Амбулатория случаи],
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Амбулатория Сумма],
  Rem , dep_name 
  from [hlt_ReestrTAPMHReturns] R    
  inner join tmp_ExpertPeriod v  on   v.ReestrMHSMTAPId= r.rf_ReestrMHSMTAPid and v.rf_MKABId = r.rf_MKABId    
  where v.rf_reportPeriodID =@id and v.rf_MKABId>0 and Rem <>'' 
  group by rf_SMCriterionID, Rem, dep_name
) a on a.dep_name =dep.dep_name
full join  

(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Стационар Сумма],r.Rem, dep_name   
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  r.rf_MedicalHistoryID= SK and  r.rf_ReestrOccasionID = SU     
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and r.Rem <>''  and ( Sluch_USL_OK =1 or Sluch_USL_OK =3)
  group by rf_SMCriterionID, r.Rem, dep_name
) s on s.ID = a.ID and a.Rem = s.Rem and dep.dep_name = s.dep_name
full join  

(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Днев.стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Днев.стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Днев.стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Днев.стационар Сумма],r.Rem, dep_name   
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  r.rf_MedicalHistoryID= SK and  r.rf_ReestrOccasionID = SU     
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and r.Rem <>''  and Sluch_USL_OK =2 
  group by rf_SMCriterionID, r.Rem, dep_name
) ds on ds.ID = a.ID and a.Rem = ds.Rem
inner join oms_SMCriterion on isnull(ISNULL(a.Id,s.ID), ds.ID) = SMCriterionID 
where not (s.ID is null) or not(a.ID is null) or not (ds.ID is null) and  dep.dep_name = ds.dep_name
group by SMCriterionID,SMCriterionCode,isnull(a.Rem,s.Rem),ds.Rem, SMCriterionDescription, dep.dep_name
union

-- Ошибки подробно
select '',
        SMCriterionCode as [Код],
	   ' в т. числе '+isnull(isnull(a.Rem,s.Rem),ds.Rem)  as [Замечание],
	   isnull(Sum([Амбулатория пациенты]),0) as [Амбулатория пациенты],
       isnull(Sum([Амбулатория случаи]),0)   as [Амбулатория случаи],  
       isnull(Sum([Амбулатория услуги]),0)   as [Амбулатория услуги], 
       isnull(Sum([Амбулатория Сумма]),0)	 as   [Амбулатория Сумма],
	   isnull(Sum([Стационар пациенты]),0)   as [Стационар пациенты], 
	   isnull(Sum([Стационар случаи]),0)     as [Стационар случаи],
       isnull(Sum([Стационар услуги]),0)     as [Стационар услуги],
       isnull(Sum(s.[Стационар сумма]),0)    as   [Стационар сумма],
       isnull(Sum([Днев.стационар пациенты]),0)   as [Днев.стационар пациенты], 
	   isnull(Sum([Днев.стационар случаи]),0)     as [Днев.стационар случаи],
	   isnull(Sum([Днев.стационар услуги]),0)     as [Днев.стационар услуги],
       isnull(Sum([Днев.стационар сумма]),0)    as   [Днев.стационар сумма],
      
       SMCriterionID as [ID], 
	   isnull(isnull(a.Rem,s.Rem), ds.Rem) as [Rem],-1,SMCriterionID as main
from
(
select rf_SMCriterionID as ID,
  count(distinct r.rf_MKABID)  as [Амбулатория пациенты],
   count(distinct v.ReestrMHSMTAPId) as[Амбулатория услуги],
  count(distinct V.rf_TapId) as[Амбулатория случаи],
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Амбулатория Сумма],
  Rem  
  from [hlt_ReestrTAPMHReturns] R    
  inner join tmp_ExpertPeriod v  on   v.ReestrMHSMTAPId= r.rf_ReestrMHSMTAPid and v.rf_MKABId = r.rf_MKABId    
  where v.rf_reportPeriodID =@id and v.rf_MKABId>0 and Rem <>'' 
  group by rf_SMCriterionID, Rem
) a full join  

(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Стационар Сумма],r.Rem   
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  r.rf_MedicalHistoryID= SK and  r.rf_ReestrOccasionID = SU     
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and r.Rem <>''  and ( Sluch_USL_OK =1 or Sluch_USL_OK =3) 
  group by rf_SMCriterionID, r.Rem
) s on s.ID = a.ID and a.Rem = s.Rem
full join  

(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Днев.стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Днев.стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Днев.стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Днев.стационар Сумма],r.Rem   
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  r.rf_MedicalHistoryID= SK and  r.rf_ReestrOccasionID = SU     
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and r.Rem <>''  and Sluch_USL_OK =2 
  group by rf_SMCriterionID, r.Rem
) ds on ds.ID = a.ID and a.Rem = ds.Rem
inner join oms_SMCriterion on isnull(ISNULL(a.Id,s.ID), ds.ID) = SMCriterionID 
where not (s.ID is null) or not(a.ID is null) or not (ds.ID is null) 
group by SMCriterionID,SMCriterionCode,isnull(a.Rem,s.Rem),ds.Rem, SMCriterionDescription

union
-- Ошибки без подробностей по смо
select 
'',
       SMCriterionCode as [Код],
	   SMCriterionCaption  as [Замечание],
	   isnull(Sum([Амбулатория пациенты]),0) as [Амбулатория пациенты],
       isnull(Sum([Амбулатория случаи]),0)   as [Амбулатория случаи],   
       isnull(Sum([Амбулатория услуги]),0)   as [Амбулатория услуги],   
       isnull(Sum([Амбулатория Сумма]),0)	 as   [Амбулатория Сумма], 
	   isnull(Sum([Стационар пациенты]),0)   as [Стационар пациенты], 
	   isnull(Sum([Стационар случаи]),0)     as [Стационар случаи],
	   isnull(Sum([Стационар услуги]),0)     as [Стационар услуги],
       isnull(Sum(s.[Стационар сумма]),0)    as   [Стационар сумма],
       isnull(Sum([Днев.стационар пациенты]),0) as [Днев.стационар пациенты], 
	   isnull(Sum([Днев.стационар случаи]),0)   as [Днев.стационар случаи],
	   isnull(Sum([Днев.стационар услуги]),0)   as [Днев.стационар услуги],
       isnull(Sum([Днев.стационар сумма]),0)    as   [Днев.стационар сумма],      
       SMCriterionID as [ID], SMCriterionDescription as [Rem],smoid,0
from oms_SMcriterion 
inner join 
 (select  rf_SMOID  as smoid  from tmp_ExpertPeriod 
  group by  rf_SMOID) dep on 1=1
left outer join (
select rf_SMCriterionID as ID, 
  count(distinct r.rf_MKABID)  as [Амбулатория пациенты],
  count(distinct v.ReestrMHSMTAPId) as[Амбулатория услуги],
  count(distinct V.rf_TapId) as[Амбулатория случаи],
  Sum(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Амбулатория Сумма] 
  , rf_SMOID   
  from [hlt_ReestrTAPMHReturns] R    
  inner join tmp_ExpertPeriod v  on   v.ReestrMHSMTAPId= r.rf_ReestrMHSMTAPid and v.rf_MKABId = r.rf_MKABId    
  where rf_reportPeriodID =@id and v.rf_MKABId>0 
  group by rf_SMCriterionID, rf_SMOID
) a on a.ID = SMCriterionID and smoid= a.rf_SMOID
left join 
(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Стационар Сумма]  
   , rf_SMOID   
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and ( Sluch_USL_OK =1 or Sluch_USL_OK =3)
  group by rf_SMCriterionID , rf_SMOID  
) s on s.ID = SMCriterionID and smoid= s.rf_SMOID
left join 
(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Днев.стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Днев.стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Днев.стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Днев.стационар Сумма]   
  , rf_SMOID
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and Sluch_USL_OK =2 
  group by rf_SMCriterionID, rf_SMOID
) ds on ds.ID = SMCriterionID and smoid= ds.rf_SMOID
where not (s.ID is null) or not(a.ID is null) or not (ds.ID is null)
group by SMCriterionID,SMCriterionCode,SMCriterionCaption, SMCriterionDescription, dep.smoid


union
-- Ошибки без подробностей по смо и отделениям
select 
dep.dep_name,
       SMCriterionCode as [Код],
	   SMCriterionCaption  as [Замечание],
	   isnull(Sum([Амбулатория пациенты]),0) as [Амбулатория пациенты],
       isnull(Sum([Амбулатория случаи]),0)   as [Амбулатория случаи],   
       isnull(Sum([Амбулатория услуги]),0)   as [Амбулатория услуги],   
       isnull(Sum([Амбулатория Сумма]),0)	 as   [Амбулатория Сумма], 
	   isnull(Sum([Стационар пациенты]),0)   as [Стационар пациенты], 
	   isnull(Sum([Стационар случаи]),0)     as [Стационар случаи],
	   isnull(Sum([Стационар услуги]),0)     as [Стационар услуги],
       isnull(Sum(s.[Стационар сумма]),0)    as   [Стационар сумма],
       isnull(Sum([Днев.стационар пациенты]),0) as [Днев.стационар пациенты], 
	   isnull(Sum([Днев.стационар случаи]),0)   as [Днев.стационар случаи],
	   isnull(Sum([Днев.стационар услуги]),0)   as [Днев.стационар услуги],
       isnull(Sum([Днев.стационар сумма]),0)    as   [Днев.стационар сумма],      
       SMCriterionID as [ID], SMCriterionDescription as [Rem],smoid,0
from oms_SMcriterion 
inner join 
 (select  rf_SMOID  as smoid ,dep_name from tmp_ExpertPeriod 
  group by  rf_SMOID, dep_name) dep on 1=1
left outer join (
select rf_SMCriterionID as ID, 
  count(distinct r.rf_MKABID)  as [Амбулатория пациенты],
  count(distinct v.ReestrMHSMTAPId) as[Амбулатория услуги],
  count(distinct V.rf_TapId) as[Амбулатория случаи],
  Sum(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Амбулатория Сумма] 
  , rf_SMOID   
  , dep_name
  from [hlt_ReestrTAPMHReturns] R    
  inner join tmp_ExpertPeriod v  on   v.ReestrMHSMTAPId= r.rf_ReestrMHSMTAPid and v.rf_MKABId = r.rf_MKABId    
  where rf_reportPeriodID =@id and v.rf_MKABId>0 
  group by rf_SMCriterionID, rf_SMOID, dep_name
) a on a.ID = SMCriterionID and smoid= a.rf_SMOID and a.Dep_name= dep.dep_name
left join 
(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Стационар Сумма]  
   , rf_SMOID   
   , dep_name
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and  ( Sluch_USL_OK =1 or Sluch_USL_OK =3)
  group by rf_SMCriterionID , rf_SMOID  ,dep_name
) s on s.ID = SMCriterionID and smoid= s.rf_SMOID and s.Dep_name= dep.dep_name
left join 
(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Днев.стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Днев.стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Днев.стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Днев.стационар Сумма]   
  , rf_SMOID
  , dep_name
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and Sluch_USL_OK =2 
  group by rf_SMCriterionID, rf_SMOID ,dep_name
) ds on ds.ID = SMCriterionID and smoid= ds.rf_SMOID and ds.Dep_name= dep.dep_name
where not (s.ID is null) or not(a.ID is null) or not (ds.ID is null)
group by SMCriterionID,SMCriterionCode,SMCriterionCaption, SMCriterionDescription, dep.smoid, dep.dep_name


union
-- Ошибки без подробностей по отделениям
select 
dep.dep_name,
       SMCriterionCode as [Код],
	   SMCriterionCaption  as [Замечание],
	   isnull(Sum([Амбулатория пациенты]),0) as [Амбулатория пациенты],
       isnull(Sum([Амбулатория случаи]),0)   as [Амбулатория случаи],   
       isnull(Sum([Амбулатория услуги]),0)   as [Амбулатория услуги],   
       isnull(Sum([Амбулатория Сумма]),0)	 as   [Амбулатория Сумма], 
	   isnull(Sum([Стационар пациенты]),0)   as [Стационар пациенты], 
	   isnull(Sum([Стационар случаи]),0)     as [Стационар случаи],
	   isnull(Sum([Стационар услуги]),0)     as [Стационар услуги],
       isnull(Sum(s.[Стационар сумма]),0)    as   [Стационар сумма],
       isnull(Sum([Днев.стационар пациенты]),0) as [Днев.стационар пациенты], 
	   isnull(Sum([Днев.стационар случаи]),0)   as [Днев.стационар случаи],
	   isnull(Sum([Днев.стационар услуги]),0)   as [Днев.стационар услуги],
       isnull(Sum([Днев.стационар сумма]),0)    as   [Днев.стационар сумма],      
       SMCriterionID as [ID], SMCriterionDescription as [Rem],-1,0
from oms_SMcriterion 
inner join 
 (select  dep_name from tmp_ExpertPeriod 
  group by   dep_name) dep on 1=1
left outer join (
select rf_SMCriterionID as ID, 
  count(distinct r.rf_MKABID)  as [Амбулатория пациенты],
  count(distinct v.ReestrMHSMTAPId) as[Амбулатория услуги],
  count(distinct V.rf_TapId) as[Амбулатория случаи],
  Sum(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Амбулатория Сумма]    
  , dep_name
  from [hlt_ReestrTAPMHReturns] R    
  inner join tmp_ExpertPeriod v  on   v.ReestrMHSMTAPId= r.rf_ReestrMHSMTAPid and v.rf_MKABId = r.rf_MKABId    
  where rf_reportPeriodID =@id and v.rf_MKABId>0 
  group by rf_SMCriterionID, rf_SMOID, dep_name
) a on a.ID = SMCriterionID and a.Dep_name= dep.dep_name
left join 
(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Стационар Сумма]      
   , dep_name
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and ( Sluch_USL_OK =1 or Sluch_USL_OK =3)
  group by rf_SMCriterionID ,dep_name
) s on s.ID = SMCriterionID and  s.Dep_name= dep.dep_name
left join 
(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Днев.стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Днев.стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Днев.стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Днев.стационар Сумма]   
  , dep_name
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and Sluch_USL_OK =2 
  group by rf_SMCriterionID, dep_name
) ds on ds.ID = SMCriterionID and  ds.Dep_name= dep.dep_name
where not (s.ID is null) or not(a.ID is null) or not (ds.ID is null)
group by SMCriterionID,SMCriterionCode,SMCriterionCaption, SMCriterionDescription, dep.dep_name



union
-- Ошибки без подробностей
select 
'',
       SMCriterionCode as [Код],
	   SMCriterionCaption  as [Замечание],
	   isnull(Sum([Амбулатория пациенты]),0) as [Амбулатория пациенты],
       isnull(Sum([Амбулатория случаи]),0)   as [Амбулатория случаи],   
       isnull(Sum([Амбулатория услуги]),0)   as [Амбулатория услуги],   
       isnull(Sum([Амбулатория Сумма]),0)	 as   [Амбулатория Сумма], 
	   isnull(Sum([Стационар пациенты]),0)   as [Стационар пациенты], 
	   isnull(Sum([Стационар случаи]),0)     as [Стационар случаи],
	   isnull(Sum([Стационар услуги]),0)     as [Стационар услуги],
       isnull(Sum(s.[Стационар сумма]),0)    as   [Стационар сумма],
       isnull(Sum([Днев.стационар пациенты]),0) as [Днев.стационар пациенты], 
	   isnull(Sum([Днев.стационар случаи]),0)   as [Днев.стационар случаи],
	   isnull(Sum([Днев.стационар услуги]),0)   as [Днев.стационар услуги],
       isnull(Sum([Днев.стационар сумма]),0)    as   [Днев.стационар сумма],      
       SMCriterionID as [ID], SMCriterionDescription as [Rem],-1,0
from oms_SMCriterion
left outer join (
select rf_SMCriterionID as ID, 
  count(distinct r.rf_MKABID)  as [Амбулатория пациенты],
  count(distinct v.ReestrMHSMTAPId) as[Амбулатория услуги],
  count(distinct V.rf_TapId) as[Амбулатория случаи],
  Sum(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Амбулатория Сумма]    
  from [hlt_ReestrTAPMHReturns] R    
  inner join tmp_ExpertPeriod v  on   v.ReestrMHSMTAPId= r.rf_ReestrMHSMTAPid and v.rf_MKABId = r.rf_MKABId    
  where rf_reportPeriodID =@id and v.rf_MKABId>0 
  group by rf_SMCriterionID
) a on a.ID = SMCriterionID
left join 
(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Стационар Сумма]   
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and ( Sluch_USL_OK =1 or Sluch_USL_OK =3)
  group by rf_SMCriterionID
) s on s.ID = SMCriterionID
left join 
(
select rf_SMCriterionID as ID,
  count(distinct  Usl_IDSERV) as [Днев.стационар услуги] ,
  count(distinct Sluch_SLUCHID) as [Днев.стационар случаи] ,
  count(distinct Patient_ID_PAC) as [Днев.стационар пациенты], 
  sum(convert(decimal(18,2),ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0'))) as [Днев.стационар Сумма]   
  from stt_ReestrReturns r

  inner join tmp_ExpertPeriod v on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID
  where  r.rf_reportPeriodID =@id and rf_MedicalHistoryId >0 and SK>0 and Sluch_USL_OK =2 
  group by rf_SMCriterionID
) ds on ds.ID = SMCriterionID
where not (s.ID is null) or not(a.ID is null) or not (ds.ID is null)
group by SMCriterionID,SMCriterionCode,SMCriterionCaption, SMCriterionDescription
union

--Всего ошибок
select '','  ','Всего ошибок ',
	   [Амбулатория пациенты],
       [Амбулатория случаи],
        [Амбулатория услуги],
        [Амбулатория Сумма],
	   [Стационар пациенты], 
	   [Стационар случаи],
	    [Стационар услуги],
       [Стационар сумма],
       [Днев.стационар пациенты], 
	   [Днев.стационар случаи],
	   [Днев.стационар услуги],
       [Днев.стационар сумма],
       '-1', 'Все ошибочные записи, вошедшие в счет',
      -1,0
from (
  select 
  count(distinct ReestrMHSMTAPId) as [Амбулатория услуги],   
  count(distinct rf_TAPId)        as [Амбулатория случаи], 
  count(distinct r.rf_MKABID)     as [Амбулатория пациенты], 
  Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2))   as [Амбулатория Сумма]   
from ( 
	select rf_ReestrMHSMTAPId ,rf_MKABID
	from hlt_ReestrTAPMHReturns WITH(NOLOCK) 
    inner join hlt_MHExpert WITH(NOLOCK)  on MHExpertId = rf_MHExpertID
	where rf_MKABID>0 and rf_ReportPeriodID=@id
	group by rf_ReestrMHSMTAPId,rf_MKABID ) r
inner join tmp_ExpertPeriod v WITH(NOLOCK)  on  v.ReestrMHSMTAPId= r.rf_ReestrMHSMTAPId and v.rf_MKABId = r.rf_MKABId
where  rf_reportPeriodID =@id  and Sluch_USL_OK=3     
) a,
 (select count(distinct Sluch_SLUCHID) as  [Стационар случаи],
          count(distinct Usl_IDSERV) as  [Стационар услуги],
          count(distinct Patient_ID_PAC) as [Стационар пациенты], 
          Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2)) as [Стационар Сумма]   
    from (select rf_MedicalHistoryID, rf_MedServicePatientID
    from stt_ReestrReturns WITH(NOLOCK) 
    inner join hlt_MHExpert WITH(NOLOCK) on MHExpertId = rf_MHExpertID
	where stt_ReestrReturns.rf_reportPeriodID =@id and rf_MedicalHistoryId>0
	group by rf_MedicalHistoryID, rf_MedServicePatientID ) r
    inner join  tmp_ExpertPeriod v WITH(NOLOCK) on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID    
    where  rf_reportPeriodID =@id  and ( Sluch_USL_OK=1 or  Sluch_USL_OK=3) 
 )s,
 (
 select  count(distinct Sluch_SLUCHID) as  [Днев.стационар случаи],
         count(distinct  Usl_IDSERV) as  [Днев.стационар услуги],
         count(distinct Patient_ID_PAC) as [Днев.стационар пациенты], 
         Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2)) as [Днев.стационар Сумма]   
    from (select rf_MedicalHistoryID, rf_MedServicePatientID
	from stt_ReestrReturns WITH(NOLOCK) 
  inner join hlt_MHExpert WITH(NOLOCK) on MHExpertId = rf_MHExpertID
	where stt_ReestrReturns.rf_reportPeriodID =@id and rf_MedicalHistoryId>0
	group by rf_MedicalHistoryID, rf_MedServicePatientID ) r
  inner join  tmp_ExpertPeriod v WITH(NOLOCK) on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID    
  where  rf_reportPeriodID =@id and   Sluch_USL_OK=2 
 )ds
union 
--Всего ошибок с разбивкой по СМО
select '','  ','Всего ошибок для СМО : '+case when Q_name ='' then 'Без указания' else Q_name end,
	   [Амбулатория пациенты],
       [Амбулатория случаи],
        [Амбулатория услуги],
        [Амбулатория Сумма],
	   [Стационар пациенты], 
	   [Стационар случаи],
	    [Стационар услуги],
       [Стационар сумма],
       [Днев.стационар пациенты], 
	   [Днев.стационар случаи],
	   [Днев.стационар услуги],
       [Днев.стационар сумма],
       '-1', 'Все ошибочные записи, вошедшие в счет',
       smoid,0
from (
select rf_SMOID smoid, Q_name from tmp_ExpertPeriod 
inner join Oms_SMO on SMOID = rf_SMOID
group by rf_SMOID, Q_name) oms_SMO
left join
(
  select 
  count(distinct ReestrMHSMTAPId) as [Амбулатория услуги],   
  count(distinct rf_TAPId)        as [Амбулатория случаи], 
  count(distinct r.rf_MKABID)     as [Амбулатория пациенты], 
  Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2))   as [Амбулатория Сумма], rf_SMOID   
from ( 
	select rf_ReestrMHSMTAPId ,rf_MKABID
	from hlt_ReestrTAPMHReturns WITH(NOLOCK) 
    inner join hlt_MHExpert WITH(NOLOCK)  on MHExpertId = rf_MHExpertID
	where rf_MKABID>0 and rf_ReportPeriodID=@id
	group by rf_ReestrMHSMTAPId,rf_MKABID ) r
inner join tmp_ExpertPeriod v WITH(NOLOCK)  on  v.ReestrMHSMTAPId= r.rf_ReestrMHSMTAPId and v.rf_MKABId = r.rf_MKABId
where  rf_reportPeriodID =@id  and Sluch_USL_OK=3  
   group by rf_SMOID
) a on a.rf_SMOID = SmoID
left join
 (select count(distinct Sluch_SLUCHID) as  [Стационар случаи],
          count(distinct Usl_IDSERV) as  [Стационар услуги],
          count(distinct Patient_ID_PAC) as [Стационар пациенты], 
          Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2)) as [Стационар Сумма]  
          , rf_SMOID 
    from (select rf_MedicalHistoryID, rf_MedServicePatientID
    from stt_ReestrReturns WITH(NOLOCK) 
    inner join hlt_MHExpert WITH(NOLOCK) on MHExpertId = rf_MHExpertID
	where stt_ReestrReturns.rf_reportPeriodID =@id and rf_MedicalHistoryId>0
	group by rf_MedicalHistoryID, rf_MedServicePatientID ) r
    inner join  tmp_ExpertPeriod v WITH(NOLOCK) on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID    
    where  rf_reportPeriodID =@id  and ( Sluch_USL_OK=1 or  Sluch_USL_OK=3) 
    group by rf_SMOID
 )s  on s.rf_SMOID = SmoID
 left join 
 (
 select  count(distinct Sluch_SLUCHID) as  [Днев.стационар случаи],
         count(distinct  Usl_IDSERV) as  [Днев.стационар услуги],
         count(distinct Patient_ID_PAC) as [Днев.стационар пациенты], 
         Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2)) as [Днев.стационар Сумма],
         rf_SMOID   
    from (select rf_MedicalHistoryID, rf_MedServicePatientID
	from stt_ReestrReturns WITH(NOLOCK) 
  inner join hlt_MHExpert WITH(NOLOCK) on MHExpertId = rf_MHExpertID
	where stt_ReestrReturns.rf_reportPeriodID =@id and rf_MedicalHistoryId>0
	group by rf_MedicalHistoryID, rf_MedServicePatientID ) r
  inner join  tmp_ExpertPeriod v WITH(NOLOCK) on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID    
  where  rf_reportPeriodID =@id and   Sluch_USL_OK=2 
  group by rf_SMOID
 )ds on ds.rf_SMOID = SmoID


union 
--Всего ошибок с разбивкой по отделениям
select dep.dep_name,'  ','Всего ошибок Отделение :'+dep.dep_name,
	   [Амбулатория пациенты],
       [Амбулатория случаи],
        [Амбулатория услуги],
        [Амбулатория Сумма],
	   [Стационар пациенты], 
	   [Стационар случаи],
	    [Стационар услуги],
       [Стационар сумма],
       [Днев.стационар пациенты], 
	   [Днев.стационар случаи],
	   [Днев.стационар услуги],
       [Днев.стационар сумма],
       '-1', 'Все ошибочные записи, вошедшие в счет',
       -1,0
from (
select dep_name from tmp_ExpertPeriod 
group by dep_name) dep
left join
(
  select 
  count(distinct ReestrMHSMTAPId) as [Амбулатория услуги],   
  count(distinct rf_TAPId)        as [Амбулатория случаи], 
  count(distinct r.rf_MKABID)     as [Амбулатория пациенты], 
  Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2))   as [Амбулатория Сумма], dep_name  
from ( 
	select rf_ReestrMHSMTAPId ,rf_MKABID
	from hlt_ReestrTAPMHReturns WITH(NOLOCK) 
    inner join hlt_MHExpert WITH(NOLOCK)  on MHExpertId = rf_MHExpertID
	where rf_MKABID>0 and rf_ReportPeriodID=@id
	group by rf_ReestrMHSMTAPId,rf_MKABID ) r
inner join tmp_ExpertPeriod v WITH(NOLOCK)  on  v.ReestrMHSMTAPId= r.rf_ReestrMHSMTAPId and v.rf_MKABId = r.rf_MKABId
where  rf_reportPeriodID =@id  and Sluch_USL_OK=3  
   group by dep_name
) a on a.dep_name = dep.dep_name
left join
 (select count(distinct Sluch_SLUCHID) as  [Стационар случаи],
          count(distinct Usl_IDSERV) as  [Стационар услуги],
          count(distinct Patient_ID_PAC) as [Стационар пациенты], 
          Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2)) as [Стационар Сумма]  
          , dep_name
    from (select rf_MedicalHistoryID, rf_MedServicePatientID
    from stt_ReestrReturns WITH(NOLOCK) 
    inner join hlt_MHExpert WITH(NOLOCK) on MHExpertId = rf_MHExpertID
	where stt_ReestrReturns.rf_reportPeriodID =@id and rf_MedicalHistoryId>0
	group by rf_MedicalHistoryID, rf_MedServicePatientID ) r
    inner join  tmp_ExpertPeriod v WITH(NOLOCK) on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID    
    where  rf_reportPeriodID =@id  and ( Sluch_USL_OK=1 or  Sluch_USL_OK=3) 
    group by dep_name
 )s  on s.dep_name = dep.dep_name
 left join 
 (
 select  count(distinct Sluch_SLUCHID) as  [Днев.стационар случаи],
         count(distinct  Usl_IDSERV) as  [Днев.стационар услуги],
         count(distinct Patient_ID_PAC) as [Днев.стационар пациенты], 
         Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2)) as [Днев.стационар Сумма],
         dep_name  
    from (select rf_MedicalHistoryID, rf_MedServicePatientID
	from stt_ReestrReturns WITH(NOLOCK) 
  inner join hlt_MHExpert WITH(NOLOCK) on MHExpertId = rf_MHExpertID
	where stt_ReestrReturns.rf_reportPeriodID =@id and rf_MedicalHistoryId>0
	group by rf_MedicalHistoryID, rf_MedServicePatientID ) r
  inner join  tmp_ExpertPeriod v WITH(NOLOCK) on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID    
  where  rf_reportPeriodID =@id and   Sluch_USL_OK=2 
  group by dep_name
 )ds on ds.dep_name = dep.dep_name
union

--Всего ошибок с разбивкой по отделениям СМО
select dep.dep_name,'  ','Всего ошибок для СМО : '+case when Q_name ='' then 'Без указания' else Q_name end+' Отделение :'+dep.dep_name,
	   [Амбулатория пациенты],
       [Амбулатория случаи],
        [Амбулатория услуги],
        [Амбулатория Сумма],
	   [Стационар пациенты], 
	   [Стационар случаи],
	    [Стационар услуги],
       [Стационар сумма],
       [Днев.стационар пациенты], 
	   [Днев.стационар случаи],
	   [Днев.стационар услуги],
       [Днев.стационар сумма],
       '-1', 'Все ошибочные записи, вошедшие в счет',
      smoid,0
from (
select dep_name, SMOID, Q_name from tmp_ExpertPeriod 
inner join Oms_SMO on SMOID = rf_smoid
group by dep_name, Smoid,Q_name ) dep
left join
(
  select 
  count(distinct ReestrMHSMTAPId) as [Амбулатория услуги],   
  count(distinct rf_TAPId)        as [Амбулатория случаи], 
  count(distinct r.rf_MKABID)     as [Амбулатория пациенты], 
  Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2))   as [Амбулатория Сумма], dep_name, rf_SMOID  
  
from ( 
	select rf_ReestrMHSMTAPId ,rf_MKABID
	from hlt_ReestrTAPMHReturns WITH(NOLOCK) 
    inner join hlt_MHExpert WITH(NOLOCK)  on MHExpertId = rf_MHExpertID
	where rf_MKABID>0 and rf_ReportPeriodID=@id
	group by rf_ReestrMHSMTAPId,rf_MKABID ) r
inner join tmp_ExpertPeriod v WITH(NOLOCK)  on  v.ReestrMHSMTAPId= r.rf_ReestrMHSMTAPId and v.rf_MKABId = r.rf_MKABId
where  rf_reportPeriodID =@id  and Sluch_USL_OK=3  
   group by dep_name, rf_SMOID
) a on a.dep_name = dep.dep_name and dep.SMOID = a.rf_Smoid
left join
 (select count(distinct Sluch_SLUCHID) as  [Стационар случаи],
          count(distinct Usl_IDSERV) as  [Стационар услуги],
          count(distinct Patient_ID_PAC) as [Стационар пациенты], 
          Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2)) as [Стационар Сумма]  
          , dep_name, rf_SMOID
    from (select rf_MedicalHistoryID, rf_MedServicePatientID
    from stt_ReestrReturns WITH(NOLOCK) 
    inner join hlt_MHExpert WITH(NOLOCK) on MHExpertId = rf_MHExpertID
	where stt_ReestrReturns.rf_reportPeriodID =@id and rf_MedicalHistoryId>0
	group by rf_MedicalHistoryID, rf_MedServicePatientID ) r
    inner join  tmp_ExpertPeriod v WITH(NOLOCK) on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID    
    where  rf_reportPeriodID =@id  and ( Sluch_USL_OK=1 or  Sluch_USL_OK=3) 
    group by dep_name, rf_SMOID
 )s  on s.dep_name = dep.dep_name and dep.SMOID = s.rf_Smoid
 left join 
 (
 select  count(distinct Sluch_SLUCHID) as  [Днев.стационар случаи],
         count(distinct  Usl_IDSERV) as  [Днев.стационар услуги],
         count(distinct Patient_ID_PAC) as [Днев.стационар пациенты], 
         Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2)) as [Днев.стационар Сумма],
         dep_name, rf_SMOID  
    from (select rf_MedicalHistoryID, rf_MedServicePatientID
	from stt_ReestrReturns WITH(NOLOCK) 
  inner join hlt_MHExpert WITH(NOLOCK) on MHExpertId = rf_MHExpertID
	where stt_ReestrReturns.rf_reportPeriodID =@id and rf_MedicalHistoryId>0
	group by rf_MedicalHistoryID, rf_MedServicePatientID ) r
  inner join  tmp_ExpertPeriod v WITH(NOLOCK) on  rf_MedicalHistoryID= SK and  r.rf_MedServicePatientID = v.rf_MedServicePatientID    
  where  rf_reportPeriodID =@id and   Sluch_USL_OK=2 
  group by dep_name, rf_MKABID, rf_SMOID
 )ds on ds.dep_name = dep.dep_name and  dep.SMOID = a.rf_Smoid


union
-- Всего по счету с разбивкой по отделениям
select dep.dep_name as dep_name,
'  ','Всего по счету '+isnull(a.dep_name, isnull(s.dep_name,ds.dep_name)),
	   [Амбулатория пациенты],
       [Амбулатория случаи],   
        [Амбулатория услуги],  
        [Амбулатория Сумма],    
	   [Стационар пациенты], 
	   [Стационар случаи],
	   [Стационар услуги],
       [Стационар сумма],
        [Днев.стационар пациенты], 
	   [Днев.стационар случаи],
	   [Днев.стационар услуги],
       [Днев.стационар сумма],
	    '-3','Все записи, вошедшие в счет '+dep.dep_name,
	   -1 as smoid,0
from (select dep_name from tmp_ExpertPeriod group by dep_name) dep 
left join
(
 select  count(distinct Patient_ID_PAC)         as [Амбулатория пациенты], 
         count(distinct Usl_IDSERV)    as [Амбулатория услуги],   
         count(distinct Sluch_SLUCHID)    as [Амбулатория случаи],   
         Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2))    as [Амбулатория сумма],
         dep_name           
  from tmp_ExpertPeriod r  WITH(NOLOCK) 
  where rf_MKABID>0 and Sluch_USL_OK=3
  group by dep_name
) a on dep.dep_name = a.dep_name
left join (
 select count(distinct Patient_ID_PAC) as  [Стационар пациенты], 
        count(distinct Sluch_SLUCHID) as  [Стационар случаи],
        count(distinct Usl_IDSERV) as  [Стационар услуги],
        Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2))  as [Стационар сумма],
        dep_name   
  from tmp_ExpertPeriod R   WITH(NOLOCK) 
  where SU>0  and ( Sluch_USL_OK=1 or  Sluch_USL_OK=3) 
   group by dep_name
) s on s.dep_name = dep.dep_name
left join (
 select count(distinct Patient_ID_PAC)as  [Днев.стационар пациенты], 
        count(distinct Sluch_SLUCHID) as  [Днев.стационар случаи],
        count(distinct Usl_IDSERV)    as  [Днев.стационар услуги],
        Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2)) as [Днев.стационар сумма],
        dep_name   
  from tmp_ExpertPeriod R WITH(NOLOCK) 
  where SU>0 and Sluch_USL_OK=2 
   group by dep_name
) ds on ds.dep_name = dep.dep_name
union 
-- Всего по счету Итого
select '',
'  ','Всего по счету ',
	   [Амбулатория пациенты],
       [Амбулатория случаи],   
        [Амбулатория услуги],  
        [Амбулатория Сумма],    
	   [Стационар пациенты], 
	   [Стационар случаи],
	   [Стационар услуги],
       [Стационар сумма],
        [Днев.стационар пациенты], 
	   [Днев.стационар случаи],
	   [Днев.стационар услуги],
       [Днев.стационар сумма],
	    '-3','Все записи, вошедшие в счет ',
	    -1,0
	    
from (
 select  count(distinct r.rf_MKABID)         as [Амбулатория пациенты], 
         count(distinct ReestrMHSMTAPId)    as [Амбулатория услуги],   
         count(distinct rf_TAPId)    as [Амбулатория случаи],   
         Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,0))), '0'),'0')),2))    as [Амбулатория сумма]
        
            
  from tmp_ExpertPeriod r  WITH(NOLOCK) 
  where rf_MKABID>0 
) a inner join 


(
 select count(distinct Patient_ID_PAC) as  [Стационар пациенты], 
        count(distinct Sluch_SLUCHID) as  [Стационар случаи],
        count(distinct  Usl_IDSERV) as  [Стационар услуги],
        Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2))  as [Стационар сумма]
         
  from tmp_ExpertPeriod R   WITH(NOLOCK) 
  where SU>0  and ( Sluch_USL_OK=1 or  Sluch_USL_OK=3)
) s on 1=1
inner join
(
 select count(distinct Patient_ID_PAC) as  [Днев.стационар пациенты], 
        count(distinct Sluch_SLUCHID) as  [Днев.стационар случаи],
        count(distinct  Usl_IDSERV) as  [Днев.стационар услуги],
        Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2)) as [Днев.стационар сумма]
           
  from tmp_ExpertPeriod R WITH(NOLOCK) 
  where SU>0 and Sluch_USL_OK=2  
  
) ds on 1=1
union 
-- Всего по счету с разбивкой по отделениям и СМО
select dep.dep_name as dep_name,
'  ','Всего по счету для СМО : '+case when Q_name ='' then 'Без указания' else Q_name end+case when dep.dep_name <>'' then ' Отделение: ' + dep.dep_name end,
	   [Амбулатория пациенты],
       [Амбулатория случаи],   
        [Амбулатория услуги],  
        [Амбулатория Сумма],    
	   [Стационар пациенты], 
	   [Стационар случаи],
	   [Стационар услуги],
       [Стационар сумма],
        [Днев.стационар пациенты], 
	   [Днев.стационар случаи],
	   [Днев.стационар услуги],
       [Днев.стационар сумма],
	    '-3','Все записи, вошедшие в счет '+dep.dep_name,
	    oms_SMO.smoid,0
from (select dep_name, rf_SMOID as smoid from tmp_ExpertPeriod group by dep_name, rf_SMOID) dep 
inner join oms_SMO on oms_SMO.Smoid = dep.SmoId
left join
(
 select  count(distinct Patient_ID_PAC)         as [Амбулатория пациенты], 
         count(distinct Usl_IDSERV)    as [Амбулатория услуги],   
         count(distinct Sluch_SLUCHID)    as [Амбулатория случаи],   
         Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2))    as [Амбулатория сумма],
         dep_name , rf_SMOID          
  from tmp_ExpertPeriod r  WITH(NOLOCK) 
  where rf_MKABID>0 and Sluch_USL_OK=3
  group by dep_name, rf_SMOID
) a on dep.dep_name = a.dep_name and a.rf_SMOID=dep.smoid
left join (
 select count(distinct Patient_ID_PAC) as  [Стационар пациенты], 
        count(distinct Sluch_SLUCHID) as  [Стационар случаи],
        count(distinct Usl_IDSERV) as  [Стационар услуги],
        Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2))  as [Стационар сумма],
        dep_name, rf_SMOID   
  from tmp_ExpertPeriod R   WITH(NOLOCK) 
  where SU>0  and ( Sluch_USL_OK=1 or  Sluch_USL_OK=3) 
group by dep_name, rf_SMOID
) s on s.dep_name = dep.dep_name and s.rf_SMOID=dep.smoid
left join (
 select count(distinct Patient_ID_PAC)as  [Днев.стационар пациенты], 
        count(distinct Sluch_SLUCHID) as  [Днев.стационар случаи],
        count(distinct Usl_IDSERV)    as  [Днев.стационар услуги],
        Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2)) as [Днев.стационар сумма],
        dep_name , rf_SMOID  
  from tmp_ExpertPeriod R WITH(NOLOCK) 
  where SU>0 and Sluch_USL_OK=2 
   group by dep_name, rf_SMOID
) ds on ds.dep_name = dep.dep_name and  ds.rf_SMOID=oms_SMO.smoid
union 
-- Всего по счету с разбивкой по  СМО
select '' as dep_name,
'  ','Всего по счету для СМО : '+case when Q_name ='' then 'Без указания' else Q_name end,
	   [Амбулатория пациенты],
       [Амбулатория случаи],   
        [Амбулатория услуги],  
        [Амбулатория Сумма],    
	   [Стационар пациенты], 
	   [Стационар случаи],
	   [Стационар услуги],
       [Стационар сумма],
        [Днев.стационар пациенты], 
	   [Днев.стационар случаи],
	   [Днев.стационар услуги],
       [Днев.стационар сумма],
	    '-3','Все записи, вошедшие в счет ',
	    oms_SMO.smoid,0
from  (select rf_SMOID smoid, Q_name from tmp_ExpertPeriod 
inner join Oms_SMO on SMOID = rf_SMOID
group by rf_SMOID, Q_name) oms_SMO 
left join
(
 select  count(distinct Patient_ID_PAC)         as [Амбулатория пациенты], 
         count(distinct Usl_IDSERV)    as [Амбулатория услуги],   
         count(distinct Sluch_SLUCHID)    as [Амбулатория случаи],   
         Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2))    as [Амбулатория сумма],
         rf_SMOID          
  from tmp_ExpertPeriod r  WITH(NOLOCK) 
  where rf_MKABID>0 and Sluch_USL_OK=3
  group by  rf_SMOID
) a on SMOID= a.rf_SMOID
left join (
 select count(distinct Patient_ID_PAC) as  [Стационар пациенты], 
        count(distinct Sluch_SLUCHID) as  [Стационар случаи],
        count(distinct Usl_IDSERV) as  [Стационар услуги],
        Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2))  as [Стационар сумма],
        rf_SMOID   
  from tmp_ExpertPeriod R   WITH(NOLOCK) 
  where SU>0  and ( Sluch_USL_OK=1 or  Sluch_USL_OK=3) 
group by  rf_SMOID
) s on s.rf_SMOID=smoid
left join (
 select count(distinct Patient_ID_PAC)as  [Днев.стационар пациенты], 
        count(distinct Sluch_SLUCHID) as  [Днев.стационар случаи],
        count(distinct Usl_IDSERV)    as  [Днев.стационар услуги],
        Sum(round(convert(decimal(18,2), ISNULL(NULLIF(LTRIM(RTRIM(isnull(usl_sumV_USL,'0'))), '0'),'0')),2)) as [Днев.стационар сумма],
        rf_SMOID  
  from tmp_ExpertPeriod R WITH(NOLOCK) 
  where SU>0 and Sluch_USL_OK=2 
   group by  rf_SMOID
) ds on  ds.rf_SMOID=oms_SMO.smoid

) allRec



end
go

