CREATE FUNCTION  [dbo].[GetDoctorbyPCOD] (   @PCOD varchar(50) ) 
Returns int  AS
Begin

declare @Id int;
set @Id=-1
declare @Pcod1 varchar(50)
declare @Pcod2 varchar(50)
select @Pcod1= cast((CASE CHARINDEX(' ',RTRIM(LTRIM(@PCOD))) WHEN 0 THEN '' ELSE LTRIM(RTRIM(SUBSTRING(@PCOD,CHARINDEX(' ',RTRIM(LTRIM(@PCOD)))+1,LEN(@PCOD)-CHARINDEX(' ',RTRIM(LTRIM(@PCOD)))))) END) as Varchar(10)),  
@PCod2 =case CHARINDEX(' ',RTRIM(LTRIM(@PCOD))) when 0 then Ltrim(Rtrim(@Pcod)) else
Ltrim(Rtrim(substring(@Pcod,1, CHARINDEX(' ',RTRIM(LTRIM(@PCOD)))))) end 

select @Id= DoctorId from v_oms_Doctor
where V_c_Ogrn = @Pcod2 and Pcod= @Pcod1

return @ID
END
go

