CREATE VIEW [V_rls_PharmaGroup_Okdp] AS SELECT 
[hDED].[PharmaGroup_OkdpID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsPharmaGroupUID] as [rf_ClsPharmaGroupUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[OKDP] as [OKDP], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_PharmaGroup_Okdp] as [hDED]
go

