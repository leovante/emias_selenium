

CREATE VIEW [IV_Schedul]
AS
SELECT     
dtt.DoctorTimeTableID,
dtt.Begin_Time AS DTT_Begin_Time, 
dtt.End_Time AS DTT_End_Time, 
dtt.Date AS DTT_Date, 
dtt.FlagAccess AS DTT_FlagAccess, 
dtt.PlanUE as DTT_PlanUE,
dtt.rf_DocPRVDID as DTT_DocPrVdID,
dbt.DocBusyTypeID, 
dbt.CODE AS DBT_Code, 
/*dbt.Name AS DBT_Name, */
dbt.TypeBusy AS DBT_TypeBusy, 

hr.HealingRoomID as DTT_HealingRoomID,
hr.rf_DepartmentID as HR_DepartmentID,

dprvd.rf_LPUDoctorID as DPRVD_LPUDoctorID, 
dprvd.rf_PRVSID as DPRVD_PRVSID, 
dprvd.rf_HealingRoomID as DPRVD_HealingRoomID, 

uch.UchastokID, 
uch.CODE as Uch_CODE,

uch.UchastoCaption,            
dvt.DoctorVisitTableID, 
dvt.rf_MKABID as DVT_rf_MKABID,
dvt.NormaUE as DVT_NormaUE,
dvt.StubNum as DVT_StubNum
FROM         
dbo.hlt_DoctorTimeTable AS dtt 
INNER JOIN
	dbo.hlt_DocBusyType AS dbt 
	ON dbt.DocBusyTypeID = dtt.rf_DocBusyType AND dbt.DocBusyTypeID <> 0 
LEFT OUTER JOIN 
	dbo.hlt_DocPRVD as dprvd
	ON dtt.rf_DocPRVDID = dprvd.DocPRVDID and dprvd.InTime = 1
LEFT OUTER JOIN 
	dbo.hlt_HealingRoom as hr
	ON dtt.rf_HealingRoomID = hr.HealingRoomID and hr.InTime = 1
LEFT OUTER JOIN 
	dbo.hlt_Uchastok AS uch 
	ON uch.rf_DocPrVdID = dprvd.DocPrVdID 
LEFT OUTER JOIN
    dbo.hlt_DoctorVisitTable AS dvt 
	ON dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID AND dvt.rf_DoctorTimeTableID <> 0
WHERE   dtt.DoctorTimeTableID <> 0                        
		and dtt.PlanUE > 0
        and dtt.Begin_Time <> '1900-01-01T00:00:00' /*отсекаем записи вне очереди*/        
		and (dtt.rf_DocPRVDID <> 0 or dtt.rf_HealingRoomID <> 0)
		and (not (dprvd.DocPrVdID is null) or not (hr.HealingRoomID is null))

go

