CREATE view [V_ExpertPeriod028efa5a-a288-4c2a-a4e2-7a263449c9b8] as select * from [tmp_ExpertPeriod028efa5a-a288-4c2a-a4e2-7a263449c9b8]
go

