CREATE VIEW [V_rls_FirmNames] AS SELECT 
[hDED].[FirmNamesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[Name] as [Name], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_FirmNames] as [hDED]
go

