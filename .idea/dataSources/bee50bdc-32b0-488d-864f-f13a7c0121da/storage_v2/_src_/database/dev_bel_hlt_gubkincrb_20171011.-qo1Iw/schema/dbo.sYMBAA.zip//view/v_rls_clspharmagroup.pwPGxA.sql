CREATE VIEW [V_rls_ClsPharmaGroup] AS SELECT 
[hDED].[ClsPharmaGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsPharmaGroupUID] as [rf_ClsPharmaGroupUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code], 
[hDED].[INFO] as [INFO]
FROM [rls_ClsPharmaGroup] as [hDED]
go

