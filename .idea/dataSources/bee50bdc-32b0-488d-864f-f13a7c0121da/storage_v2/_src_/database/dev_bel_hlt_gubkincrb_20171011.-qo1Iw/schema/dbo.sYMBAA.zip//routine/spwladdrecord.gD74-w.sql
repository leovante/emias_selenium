-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [spwlAddRecord] 
	@mkabid int,
	@docprvd int,
	@spec varchar(100),	
	@dateFrom datetime,
	@dateTo datetime,
	@hourFrom int,
	@hourTo int,
	@result int output
AS
BEGIN
	
/*специальность*/
DECLARE @PRVSID	int
SET @PRVSID = isnull((SELECT top 1 prvsid FROM oms_prvs where PRVS_NAME = @spec), 0)

/*Проверим диспансерных пациентов*/
	IF (@PRVSID != 0) AND ( 
		(select top 1 case valueStr when '' then 0 when '0' then 0 else 1 end 
		 from x_userSettings where property like 'Диспансерное наблюдение') = 1
	)  
	BEGIN

		IF @PRVSID in
				(
					SELECT PRVSID FROM oms_PRVS
					WHERE C_PRVS IN  (   '40127'	/*Эндокринология*/
										,'4020102'	/*Детская эндокринология*/
										,'4012205'	/*Кардиология*/
										,'4020103'	/*Детская кардиология*/
										,'4012209'	/*Ревматология*/
										,'40109'	/*Неврология*/
										,'4012201'	/*Гастроэнтерология*/
										,'4012202'	/*Гематология*/
										,'4012207'	/*Нефрология*/)
				)
		BEGIN
			/*Самозапись к этим специалистам разрешена только для диспансерных пациентов*/
			IF NOT EXISTS
				(
					SELECT TOP 1 1 from hlt_RegMedicalCheck			
					WHERE rf_MKABID = @mkabid 
					AND @dateFrom BETWEEN dateRegistration AND DateOff 
					AND rf_PRVSID = @PRVSID
				)
			BEGIN				
				SET @result = -13
				RETURN
			END
		END
	END 

BEGIN TRAN

declare @recID int

INSERT INTO [hlt_WaitingList]
           ([DateCreate]
           ,[DateFrom]
           ,[DateTo]
           ,[Flags]
           ,[FromDoc]
           ,[FromInfomat]
           ,[FromInternet]
           ,[FromReg]
           ,[FromTel]
           ,[GUID]
           ,[rf_DoctorVisitTableID]
           ,[rf_HealingRoomID]
           ,[rf_MKABID]
           ,[rf_PRVSID]
           ,[TicketConfirmed]
           ,[TicketCount]
           ,[TicketCreateTime]
           ,[TicketLiveTime]
           ,[HourFrom]
           ,[HourTo]
           ,[x_Edition]
           ,[x_Status]
           ,[rf_DocPRVDID])
     SELECT 
			GetDate() as [DateCreate]
           ,@dateFrom as [DateFrom]
           ,@dateTo as [DateTo]
           ,0 as [Flags]
           ,0 as [FromDoc]
           ,0 as[FromInfomat]
           ,1 as [FromInternet]
           ,0 as[FromReg]
           ,0 as[FromTel]
           ,newid() as [GUID]
           ,0 as[rf_DoctorVisitTableID]
           ,0 as [rf_HealingRoomID]
           ,@mkabid as [rf_MKABID]
           ,@PRVSID as [rf_PRVSID]
           ,0 as [TicketConfirmed]
           ,0 as [TicketCount]
           ,'1900-01-01T00:00:00' as [TicketCreateTime]
           ,'1900-01-01T00:00:00' as [TicketLiveTime]
           ,@hourFrom as [HourFrom]
           ,@hourTo as [HourTo]
           ,1 as [x_Edition]
           ,1 as [x_Status]
           ,@docprvd as [rf_DocPRVDID]

/* сохраняем ID записи*/
SET @recID = (SELECT IDENT_CURRENT('[hlt_WaitingList]'))

	EXEC [dbo].[spwlProcessRecord] @wlid = @recID
COMMIT TRAN
SET @result = 0
END
go

