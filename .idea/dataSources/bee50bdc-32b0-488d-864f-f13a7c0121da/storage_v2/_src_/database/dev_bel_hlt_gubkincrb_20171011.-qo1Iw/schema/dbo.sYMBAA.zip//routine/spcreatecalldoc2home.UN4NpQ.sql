
-- =============================================
-- Author:		Сергей Шумаков
-- Create date: 25 августа 2008
-- Description:	
-- =============================================
CREATE PROCEDURE [spCreateCallDoc2Home]
	@MKABID int,
	@ADDRESS varchar(200),
	@Complaint varchar(100),
	@Phone varchar(25)
AS
BEGIN
begin tran

declare @DocID int
-- Участок
set @DocID =  isnull((select top 1 rf_UchastokID from hlt_MKAB where MKABID = @MKABID), 0)
-- Врач
set @DocID =  isnull((select top 1 rf_LPUDoctorID from hlt_Uchastok where UchastokID = @DocID), 0)



INSERT INTO [hlt_CallDoctor]
           ([rf_LPUDoctorID]
           ,[rf_MKABID]
           ,[Address]
           ,[Complaint]
           ,[DateCall]
           ,[rf_CallDoctorStatusID]
           ,[isFinalize]
           ,[DateFinalize]
           ,[rf_TAPID]
           ,[CodeDomophon]
           ,[Phone]
           ,[Rf_FinalizeLPUDoctorID]
           ,[Description]
           ,[rf_TypeCallDoctorID]
           ,[Entrance]
           ,[Floor])
     select
           @DocID
           ,@MKABID
           ,@ADDRESS
           ,@Complaint
           ,GetDate()
           , (select isnull ( (select top 1 CallDoctorStatusID from hlt_CallDoctorStatus where CODE = '1'), 0))
           ,0
           ,'2222-01-01T00:00:00'
           ,0
           ,''
           ,@Phone
           ,0
           ,''
           ,(select isnull ( (select top 1 TypeCallDoctorID from hlt_TypeCallDoctor where CODE = '1'), 0))
           ,0
           ,0
commit tran

END

go

