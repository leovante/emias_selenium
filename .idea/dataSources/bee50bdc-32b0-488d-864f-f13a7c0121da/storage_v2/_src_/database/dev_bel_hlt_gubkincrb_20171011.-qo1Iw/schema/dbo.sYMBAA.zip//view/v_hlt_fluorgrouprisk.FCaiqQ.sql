CREATE VIEW [V_hlt_FluorGroupRisk] AS SELECT 
[hDED].[FluorGroupRiskID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FluorTypeGroupRiskID] as [rf_FluorTypeGroupRiskID], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Description] as [Description]
FROM [hlt_FluorGroupRisk] as [hDED]
go

