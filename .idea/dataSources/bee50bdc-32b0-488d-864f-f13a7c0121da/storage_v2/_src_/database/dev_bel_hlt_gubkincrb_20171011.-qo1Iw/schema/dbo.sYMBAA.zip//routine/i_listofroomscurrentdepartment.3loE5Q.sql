

-- =============================================
-- Author:		Сергей Шумаков
-- Create date: 2010/09/06
-- Description:	Инфомат. 
-- =============================================
CREATE FUNCTION [dbo].[I_ListOfRoomsCurrentDepartment] 
(		
	@date_a datetime, 
	@date_b datetime, 
	@dbt int,
	@mkabid int,
	@dep int
)
RETURNS TABLE 
AS
RETURN 
(
	with schedul(HealingRoomID, PlanUE, NormaUE) AS /*Доступные кабинеты*/
	(
		select  DTT_HealingRoomID, sum(t.DTT_PlanUE), sum(t.DVT_NormaUE)
		from 
		(
			select  DTT_HealingRoomID, max(DTT_PlanUE) as DTT_PlanUE, isnull(sum(DVT_NormaUE),0) as DVT_NormaUE
			from IV_Schedul 
			where   datepart(hh, dtt_Begin_Time) <> 0 /* отсекаем записи других типов */ 
					and DTT_HealingRoomID  != 0
					and dtt_date between @date_a and @date_b /**/
					and DocBusyTypeID = @dbt /**/	
					and HR_DepartmentID = @dep	/**/        
					and (dtt_FlagAccess & 4) > 0 /*фильтр по правам доступа	*/
			group by DoctorTimeTableID, DTT_HealingRoomID
		)t group by  DTT_HealingRoomID
	)
	select hr.HealingRoomID, hr.Num + ' ' + hr.Comment as RoomName, case when PlanUE > NormaUE then 1 else 0 end  as Active
	from hlt_HealingRoom hr	
	left join schedul on hr.HealingRoomID = schedul.HealingRoomID
	where (hr.HealingRoomID > 0) and (hr.rf_DepartmentID = @dep)
	group by hr.HealingRoomID, hr.Num, hr.Comment, schedul.HealingRoomID, schedul.planUE, schedul.NormaUE 
)
go

