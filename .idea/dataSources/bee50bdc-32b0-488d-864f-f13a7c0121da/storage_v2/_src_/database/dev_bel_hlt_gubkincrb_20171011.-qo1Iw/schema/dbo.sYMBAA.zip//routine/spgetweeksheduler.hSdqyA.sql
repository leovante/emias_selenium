



-- =============================================
-- Author:		Шумаков Сергей
-- Create date: 28.08.2008
-- Description:	Процедура возвращает недельное расписание врачей поликлиники 
-- =============================================
CREATE PROCEDURE [spGetWeekSheduler] 	
	@result xml output
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @dateA DATETIME
	DECLARE @dateB DATETIME

	SET @dateA = CAST(floor(CAST(getdate() AS FLOAT)) AS DATETIME)  /*Убрали время*/

	SET @dateB = DateAdd(d, 13, @dateA)

	SELECT 
		CAST('' AS VARCHAR(100)) AS Uchastok, 	
		CAST(ISNULL(prvs.prvs_name, '') AS VARCHAR(255)) AS SpecName, 
		CAST(ISNULL(dp.DepartmentName, '') AS VARCHAR(255)) AS SeparationName, 
		CAST(ISNULL(prvd.name, '') AS VARCHAR(50)) AS DolgName, 
		CAST(ISNULL(hr.Num, '') AS VARCHAR(10)) AS RoomNum,
		CASE WHEN (doc.FAM_V is null) OR (LEN(doc.FAM_V)) = 0 THEN ''
			 WHEN (LEN(doc.FAM_V) = 1) THEN Upper(doc.FAM_V)
			 ELSE CAST(Upper(substring(doc.FAM_V,1,1)) + lower(substring(doc.FAM_V,2, 50)) AS VARCHAR(50)) 
			 END AS Fam,
		CASE WHEN (doc.IM_V is null) OR (LEN(doc.IM_V)) = 0 THEN ''
			 WHEN (LEN(doc.IM_V) = 1) THEN Upper(doc.IM_V)
			 ELSE CAST(Upper(substring(doc.IM_V,1,1)) + lower(substring(doc.IM_V,2, 25)) AS VARCHAR(25)) 
			 END AS IM,
		CASE WHEN (doc.OT_V is null) OR (LEN(doc.OT_V)) = 0 THEN ''
			 WHEN (LEN(doc.OT_V) = 1) THEN Upper(doc.OT_V)
			 ELSE CAST(Upper(substring(doc.OT_V,1,1)) + lower(substring(doc.OT_V,2, 25)) AS VARCHAR(25)) 
			 END AS OT,
		CAST(ISNULL(p.DocPRVDID,0) AS int) AS PCOD,	
		convert(VARCHAR(19), iv.DTT_Date, 126) AS FullDate,
		iv.DTT_Date AS [Date],
		ISNULL(Hour_from, '') AS Hour_from,
		ISNULL(Minute_from, '') AS Minute_from,
		ISNULL(Hour_To, '') AS Hour_To,
		ISNULL(Minute_to, '') AS Minute_to,
		0 AS [TicketCount],
		0 AS [FlagAccess],
		p.InTime AS InTime
		into #tmp_tab
	FROM hlt_DocPrvd p
		inner JOIN hlt_LpuDoctor doc
			on p.rf_LPUDoctorID = doc.LPUDoctorID
				and doc.InTime = 1 /*and p.InTime = 1 - такие записи удаляются позже отдельно. На порядок быстрее работает*/
		left JOIN oms_Department dp on dp.DepartmentID = p.rf_DepartmentID 
		left JOIN oms_prvd prvd on prvd.PRVDID = p.rf_PRVDID
		left JOIN oms_prvs prvs on prvs.PRVSID = p.rf_PRVSID
		left JOIN hlt_HealingRoom hr on hr.HealingRoomID = p.rf_HealingRoomID
		inner JOIN 
		(
			select 
				s.DTT_Date, 
				s.DTT_DocPrVdID,			
				CASE ISNULL(min(s.DBT_Code), 0)
					WHEN 0 THEN NULL
					WHEN 1 THEN 'Отп.'
					WHEN 2 THEN 'Вых.'
					WHEN 3 THEN 'Бол.'
					ELSE
					  CASE 
						WHEN min(s.DTT_Begin_Time) = null THEN NULL
						WHEN DATEPART(hh, (min(s.DTT_Begin_Time))) = 0 THEN NULL 
						ELSE Convert(VARCHAR(2), DATEPART(hh, (min(s.DTT_Begin_Time))), 2)
					  end
					end
					as Hour_from,				
				CASE 
					WHEN min(s.DTT_Begin_Time) = null THEN NULL
					WHEN DATEPART(hh, min(s.DTT_Begin_Time)) = 0 THEN NULL
					ELSE right('0' + convert(VARCHAR(2), DATEPART(mi, min(s.DTT_Begin_Time))), 2)
					END AS Minute_from,
				CASE
					WHEN min(s.DTT_Begin_Time) = null THEN NULL
					WHEN DATEPART(hh, min(s.DTT_Begin_Time)) = 0 THEN NULL
					ELSE Convert(VARCHAR(2), DATEPART(hh, max(s.DTT_End_Time)), 2) 
					END AS Hour_to,
				CASE 
					WHEN min(s.DTT_Begin_Time) = null THEN NULL
					WHEN DATEPART(hh, min(s.DTT_Begin_Time)) = 0 THEN null
					ELSE right('0' + convert(VARCHAR(2), DATEPART(mi, max(s.DTT_End_Time))), 2)
					END AS Minute_to
			from iv_schedul s
			where s.DTT_Date between @dateA and @dateB
				  and ((DBT_TypeBusy = 0) OR (DATEPART(hh, s.DTT_Begin_Time) > 0))
			group by s.DTT_Date, s.DTT_DocPrVdID
		) iv
		
		on iv.DTT_DocPrVdID = p.DocPrVdID 

delete from #tmp_tab where intime != 1

/*Проставляем участки*/
DECLARE curDocPrvd CURSOR
KEYSET
FOR SELECT DISTINCT PCOD FROM #tmp_tab

DECLARE @prvdid int

OPEN curDocPrvd

FETCH NEXT FROM curDocPrvd INTO @prvdid
WHILE (@@fetch_status = 0)
BEGIN
	DECLARE @uch VARCHAR(1024) 
	SET @uch = null
	SELECT @uch =  ISNULL(@uch + ', ', '') + Code FROM hlt_Uchastok
	WHERE rf_DocPRVDID = @prvdid

	IF LEN(@uch) != 0 
	BEGIN
		UPDATE #tmp_tab SET Uchastok = @uch WHERE PCOD = @prvdid
	END

	FETCH NEXT FROM curDocPrvd INTO @prvdid
END

CLOSE curDocPrvd
DEALLOCATE curDocPrvd


/* Считаем TicketCount */
UPDATE #tmp_tab
SET  [TicketCount]  = iv.TC
FROM #tmp_tab t
	left JOIN (
		SELECT 
			s.DTT_Date, 
			s.DTT_DocPrVdID,
			sum(ISNULL(DTT_PlanUE, 0)) - sum(ISNULL(DVT_NormaUE,0)) AS TC
		FROM iv_schedul s
		WHERE s.DTT_Date between @dateA and @dateB
			  and DTT_PlanUE > 0
			  and (DBT_TypeBusy = 1) 
			  and (DATEPART(hh, s.DTT_Begin_Time) > 0)
			  and (DTT_FlagAccess & 4) > 0		-- Только для самозаписи	
		GROUP BY  s.DTT_Date, s.DTT_DocPrVdID
	) iv
	ON iv.DTT_DocPrVdID = t.PCOD and iv.DTT_Date = t.[Date]
WHERE iv.DTT_DocPrVdID is not null 

/* Считаем [FlagAccess] */ 
UPDATE #tmp_tab
SET  [FlagAccess]  = iv.FA
FROM #tmp_tab t
	left JOIN (
			SELECT 
				s.DTT_Date, 
				s.DTT_DocPrVdID,
				/*Можно просчитать точный флаг, но нас интересует только x<4 и x>=4, поэтому обойдемся максимальным значением */
				max( DISTINCT(s.DTT_FlagAccess)) AS FA 
			FROM iv_schedul s
			WHERE s.DTT_Date between @dateA and @dateB
				  and DTT_PlanUE > 0
				  and DTT_PlanUE > isnull((select sum(NormaUE) from hlt_DoctorVisitTable where rf_DoctorTimeTableID = DoctorTimeTableID),0)
				  and (DBT_TypeBusy = 1) 
				  and (DATEPART(hh, s.DTT_Begin_Time) > 0) 				  
			GROUP BY s.DTT_Date, s.DTT_DocPrVdID
			HAVING sum(ISNULL(DTT_PlanUE, 0)) > sum(ISNULL(DVT_NormaUE,0))	
	) iv
	on iv.DTT_DocPrVdID = t.PCOD and iv.DTT_Date = t.[Date]
WHERE iv.DTT_DocPrVdID is not null 	

SET @result =  
	(
		select tt.* from 
			(
				-- Уровень 1 - тэг LPUShedulerTableResult
				SELECT 
					   1    AS Tag,
					   NULL AS Parent,
					   NULL AS [LPUShedulerTableResult!1],	   
					   'true' AS [LPUShedulerTableResult!1!Result],
					   0 AS [LPUShedulerTableResult!1!Code],
					   NULL AS [Specialization!2!SpecName!ELEMENT],
					   NULL AS [Dolgnost!3!DolgName!ELEMENT],
					   NULL AS [Doctor!4!Fam!ELEMENT],
					   NULL AS [Doctor!4!Im!ELEMENT],
					   NULL AS [Doctor!4!Ot!ELEMENT],
					   NULL AS [Doctor!4!PCOD!ELEMENT],
					   NULL AS [Doctor!4!Uchastok!ELEMENT],
					   NULL AS [Doctor!4!RoomNum!ELEMENT],
					   NULL AS [Doctor!4!SeparationName!ELEMENT],
					   NULL AS [DocShedul!5],
					   NULL AS [RowShedul!6!FullDate!ELEMENT],
					   NULL AS [RowShedul!6!Hour_from!ELEMENT],
					   NULL AS [RowShedul!6!Minute_from!ELEMENT],
					   NULL AS [RowShedul!6!Hour_to!ELEMENT],
					   NULL AS [RowShedul!6!Minute_to!ELEMENT],   	
					   NULL AS [RowShedul!6!TicketCount!ELEMENT],								
					   NULL AS [RowShedul!6!FlagAccess!ELEMENT]								
				UNION ALL
				-- Уровень 2 - тэг - Specialization
				SELECT distinct
					   2 AS Tag,
					   1 AS Parent,
					   NULL AS [LPUShedulerTableResult!1],
					   NULL AS [LPUShedulerTableResult!1!Result],
					   NULL AS [LPUShedulerTableResult!1!Code],
					   SpecName AS [Specialization!2!SpecName!ELEMENT],         
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL
				from #tmp_tab
				union all
				-- уровень 3 - тэг Dolgnost
				SELECT distinct
					   3 AS Tag,
					   2 AS Parent,
					   NULL AS [LPUShedulerTableResult!1],
					   NULL AS [LPUShedulerTableResult!1!Result],
					   NULL AS [LPUShedulerTableResult!1!Code],
					   SpecName AS [Specialization!2!SpecName!ELEMENT],
					   DolgName AS [Dolgnost!3!DolgName!ELEMENT],
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL
				from #tmp_tab
				union all
				--уровень 4 - тэг Doctor
				SELECT distinct
					   4 AS Tag,
					   3 AS Parent,
					   NULL AS [LPUShedulerTableResult!1],
					   NULL AS [LPUShedulerTableResult!1!Result],
					   NULL AS [LPUShedulerTableResult!1!Code],
					   SpecName AS [Specialization!2!SpecName!ELEMENT],
					   DolgName AS [Dolgnost!3!DolgName!ELEMENT],
					   Fam AS [Doctor!4!Fam!ELEMENT],
					   Im AS [Doctor!4!Im!ELEMENT],
					   Ot AS [Doctor!4!Ot!ELEMENT],
					   PCOD AS [Doctor!4!PCOD!ELEMENT],
					   Uchastok AS [Doctor!4!Uchastok!ELEMENT],
					   RoomNum AS [Doctor!4!RoomNum!ELEMENT],
					   SeparationName AS [Doctor!4!SeparationName!ELEMENT],
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL
				from #tmp_tab
				union all
				-- уровень 5 - тэг DocShedul
				SELECT distinct
					   5		AS Tag,
					   4		AS Parent,
					   NULL		AS [LPUShedulerTableResult!1],
					   NULL		AS [LPUShedulerTableResult!1!Result],
					   NULL		AS [LPUShedulerTableResult!1!Code],
					   SpecName AS [Specialization!2!SpecName!ELEMENT],
					   DolgName AS [Dolgnost!3!DolgName!ELEMENT],
					   Fam		AS [Doctor!4!Fam!ELEMENT],
					   Im		AS [Doctor!4!Im!ELEMENT],
					   Ot		AS [Doctor!4!Ot!ELEMENT],
					   PCOD		AS [Doctor!4!PCOD!ELEMENT],
					   Uchastok AS [Doctor!4!Uchastok!ELEMENT],
					   RoomNum	AS [Doctor!4!RoomNum!ELEMENT],
					   SeparationName AS [Doctor!4!SeparationName!ELEMENT],
					   NULL		AS [DocShedul!5],
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL,
					   NULL
				from #tmp_tab t2
				union all
				-- уровень 6 - тэг RowShedul
				SELECT distinct 
					   6		AS Tag,
					   5		AS Parent,
					   NULL		AS [LPUShedulerTableResult!1],
					   NULL		AS [LPUShedulerTableResult!1!Result],
					   NULL		AS [LPUShedulerTableResult!1!Code],
					   SpecName AS [Specialization!2!SpecName!ELEMENT],
					   DolgName AS [Dolgnost!3!DolgName!ELEMENT],
					   Fam		AS [Doctor!4!Fam!ELEMENT],
					   Im		AS [Doctor!4!Im!ELEMENT],
					   Ot		AS [Doctor!4!Ot!ELEMENT],
					   PCOD		AS [Doctor!4!PCOD!ELEMENT],
					   Uchastok AS [Doctor!4!Uchastok!ELEMENT],
					   RoomNum	AS [Doctor!4!RoomNum!ELEMENT],
					   SeparationName AS [Doctor!4!SeparationName!ELEMENT],
					   NULL		AS [DocShedul!5!RowShedul],
					   FullDate		AS [RowShedul!6!FullDate!ELEMENT],
					   Hour_from	AS [RowShedul!6!Hour_from!ELEMENT],
					   Minute_from	AS [RowShedul!6!Minute_from!ELEMENT],
					   Hour_to		AS [RowShedul!6!Hour_to!ELEMENT],
					   Minute_to	AS [RowShedul!6!Minute_to!ELEMENT],							   
					   TicketCount  AS [RowShedul!6!TicketCount!ELEMENT],								
					   FlagAccess   AS [RowShedul!6!FlagAccess!ELEMENT]
				from #tmp_tab
			) tt
	 order by [Specialization!2!SpecName!ELEMENT],
	 [Dolgnost!3!DolgName!ELEMENT],
	 [Doctor!4!Fam!ELEMENT],
	 [Doctor!4!Im!ELEMENT],
	 [Doctor!4!Ot!ELEMENT],
	 [Doctor!4!PCOD!ELEMENT]

	FOR XML EXPLICIT, TYPE
	)

DROP TABLE #tmp_tab

END

go

