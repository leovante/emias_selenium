
/*считаем койко-дни*/
create function [dbo].[stt_BedDay4Migration](@MedicalHistoryID int,@MigrationPatientID int)
returns int
begin


declare @DateOut datetime
declare @bedSum int


	
	SELECT @DateOut=[dbo].[stt_dateOutMigration] (@MedicalHistoryID,@MigrationPatientID)
	select @bedSum=DateDiff(d,DateIngoing,@DateOut)from stt_MigrationPatient where rf_MedicalHistoryID = @MedicalHistoryID and MigrationPatientID =@MigrationPatientID


	if(@bedSum=0)
	begin
		set @bedSum=1
	end 
	if(select dp1.Code from stt_migrationpatient mp1
		inner join stt_stationarBranch sb1 on mp1.rf_stationarBranchID=sb1.stationarBranchID
		inner join oms_department d1 on sb1.rf_departmentID=departmentID
		inner join oms_kl_departmentType dp1 on d1.rf_kl_departmentTypeID=kl_departmentTypeID
		where migrationPatientID=@MigrationPatientID
		) = 2
	begin
		set @bedSum=@bedSum+1
	end


	return @bedSum
end
go

