CREATE VIEW [V_oms_SMReestrVNOV_M] AS SELECT 
[hDED].[SMReestrVNOV_MID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[jT_oms_SMReestrSluch].[IDCase] as [SILENT_rf_SMReestrSluchID], 
[hDED].[VNOV_M] as [VNOV_M]
FROM [oms_SMReestrVNOV_M] as [hDED]
INNER JOIN [oms_SMReestrSluch] as [jT_oms_SMReestrSluch] on [jT_oms_SMReestrSluch].[SMReestrSluchID] = [hDED].[rf_SMReestrSluchID]
go

