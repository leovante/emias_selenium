CREATE VIEW [V_oms_DPCPolyclinicRecipeReestr] AS SELECT 
[hDED].[DPCPolyclinicRecipeReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Num] as [Num], 
[hDED].[Date_Create] as [Date_Create], 
[hDED].[GUID] as [GUID], 
[hDED].[OGRN] as [OGRN]
FROM [oms_DPCPolyclinicRecipeReestr] as [hDED]
go

