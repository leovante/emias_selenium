CREATE VIEW [V_hlt_Uchastok] AS SELECT 
[hDED].[UchastokID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_kl_TypeUID] as [rf_kl_TypeUID], 
[jT_oms_kl_TypeU].[Type_U] as [SILENT_rf_kl_TypeUID], 
[hDED].[CODE] as [CODE], 
[hDED].[UchastoCaption] as [UchastoCaption], 
[hDED].[UGUID] as [UGUID], 
[hDED].[isClosed] as [isClosed], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_Uchastok] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [oms_kl_TypeU] as [jT_oms_kl_TypeU] on [jT_oms_kl_TypeU].[kl_TypeUID] = [hDED].[rf_kl_TypeUID]
go

