

CREATE function [CheckENPGender] (@ENP nvarchar(17), @Gender bit)
returns int
AS
BEGIN
if (dbo.[CheckENP] (@ENP))=0 		return 0
	else 
	begin 
	declare @d int
	set @d=99-SUBSTRING(@ENP,9,2)
	if ((@d>50)and(@gender=1)) or ((@d<50)and(@gender=0))
		return 1
		else return 0
	end
   return 0
END


go

