-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [spwlRemoveRecord]
	@wlRecord int,
	@mkabid int,
	@result int output
AS
BEGIN

BEGIN TRAN

-- Есть ли такая запись?
IF NOT EXISTS
(
	SELECT 1 FROM hlt_WaitingList
	WHERE WaitingListID = @wlRecord
		AND rf_MKABID = @mkabid
)
BEGIN
	ROLLBACK TRAN
	SET @result = -21	
	RETURN
END

/* Если была бронь - удалить */
DECLARE @dvtid int
SET @dvtid = isnull((SELECT top 1 [rf_DoctorVisitTableID] FROM hlt_WaitingList where WaitingListID = @wlRecord),0)
IF @dvtid > 0
BEGIN
	
		EXEC	[dbo].[spCancelVisit]
		@dvtid = @dvtid,
		@mkabid = @mkabid,
		@result = @result OUTPUT
END

/* Удаляем запись */
DELETE FROM hlt_WaitingList WHERE WaitingListID = @wlRecord

COMMIT  TRAN
SET @result = 0

END
go

