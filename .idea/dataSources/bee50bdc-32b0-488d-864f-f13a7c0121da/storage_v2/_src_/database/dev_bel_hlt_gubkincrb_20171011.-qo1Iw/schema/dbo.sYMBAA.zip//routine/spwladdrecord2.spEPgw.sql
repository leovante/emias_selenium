
CREATE PROCEDURE [dbo].[spwlAddRecord2] @mkabid INT
	,@mcod VARCHAR(10)
	,@docprvdid INT
	,@prvsid VARCHAR(100)
	,@phone VARCHAR(50)
	,@complaints VARCHAR(100)
	,@dateFrom DATETIME
	,@dateTo DATETIME
	,@hourFrom INT
	,@hourTo INT
	,@result INT OUTPUT
AS
BEGIN
	DECLARE @recID INT

	IF @prvsid = 0
		AND @docprvdid != 0
	BEGIN
		SELECT TOP 1 @prvsid = rf_PRVSID
		FROM hlt_DocPRVD
		WHERE DocPRVDID = @docprvdid
	END

	INSERT INTO [dbo].[hlt_WaitingList] (
		[DateCreate]
		,[DateFrom]
		,[DateTo]
		,[Flags]
		,[FromDoc]
		,[FromInfomat]
		,[FromInternet]
		,[FromReg]
		,[FromTel]
		,[GUID]
		,[HourFrom]
		,[HourTo]
		,[rf_DocPRVDID]
		,[rf_DoctorVisitTableID]
		,[rf_HealingRoomID]
		,[rf_MKABID]
		,[rf_PRVSID]
		,[TicketConfirmed]
		,[TicketCount]
		,[TicketCreateTime]
		,[TicketLiveTime]
		,[x_Edition]
		,[x_Status]
		,[Complaints]
		,[DateComplete]
		,[DateLastVisitSpeciality]
		,[Description]
		,[Phone]
		,[rf_LPUID]
		,[rf_WaitingListStateID]
		)
	SELECT getdate() [DateCreate]
		,@dateFrom [DateFrom]
		,@dateTo [DateTo]
		,0 [Flags]
		,0 [FromDoc]
		,0 [FromInfomat]
		,1 [FromInternet]
		,0 [FromReg]
		,0 [FromTel]
		,newid() [GUID]
		,@hourFrom [HourFrom]
		,@hourTo [HourTo]
		,@docprvdid [rf_DocPRVDID]
		,0 [rf_DoctorVisitTableID]
		,0 [rf_HealingRoomID]
		,@mkabid [rf_MKABID]
		,@prvsid [rf_PRVSID]
		,0 [TicketConfirmed]
		,0 [TicketCount]
		,'1900-01-01T00:00:00' [TicketCreateTime]
		,'1900-01-01T00:00:00' [TicketLiveTime]
		,1 [x_Edition]
		,1 [x_Status]
		,@complaints [Complaints]
		,'1900-01-01T00:00:00' [DateComplete]
		,'1900-01-01T00:00:00' [DateLastVisitSpecialit]
		,'' [Description]
		,@phone [Phone]
		,isnull((
				SELECT TOP 1 lpuid
				FROM oms_LPU
				WHERE mcod = @mcod
				), 0) [rf_LPUID]
		,isnull((
				SELECT TOP 1 WaitingListStateID
				FROM hlt_WaitingListState
				WHERE CODE = '1'
				), 0) [rf_WaitingListStateID]

	UPDATE hlt_mkab
	SET contactmphone = @phone
	WHERE mkabid = @mkabid and contactmphone = ''

	/* сохраняем ID записи*/
	--  SET @recID = (SELECT IDENT_CURRENT('[hlt_WaitingList]'))
	--	EXEC [dbo].[spwlProcessRecord] @wlid = @recID
	SET @result = 0
END
go

