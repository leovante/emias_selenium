
CREATE procedure [dbo].[sp_vcn_GetVaccinationPlan]
	@icard int,
	@npol varchar(20),
	@spol varchar(20),
	@date_bd datetime,
	@doInsert bit
AS
BEGIN
	declare @resTable table
	(
		rf_InoculationCardID int,
		rf_VaccinationGroupID int,
		rf_VaccinationTypeID int,
		[Date] datetime,
		rf_VaccineTypeID int,
		rf_SchemaID int,
		rf_ReasonID int
	)

	declare @result varchar(254) = ''
	declare @dateBegin datetime = GETDATE()

	declare @mkabid int = 0
	declare @ic int

	if (@icard = 0)
	begin
		set @mkabid = (select top 1 MKABID from hlt_MKAB where n_pol = @npol and s_pol = @spol and date_bd = @date_bd)
		set @ic = (select top 1 InoculationCardID from vcn_InoculationCard where rf_MKABID = @mkabId)
	end
	else
	begin
		set @ic = @icard
		set @mkabid = (select rf_MKABID from vcn_InoculationCard where InoculationCardID = @ic)
	end

	declare @vg int
	declare @reasonId int

	if (@ic > 0) delete from vcn_PlannedInoculation where rf_InoculationCardID = @ic

	DECLARE c CURSOR FOR
		select s.rf_VaccinationGroupID, r.ReasonID
		from vcn_Schema s
        join vcn_Reason r on s.rf_ReasonID = r.ReasonID
        where r.PlanFlag = 1
		group by s.rf_VaccinationGroupID, r.ReasonID
	OPEN c

	FETCH NEXT FROM c
	INTO @vg, @reasonId

	WHILE @@FETCH_STATUS = 0
	BEGIN

		insert into @resTable
		([rf_InoculationCardID],
		[rf_VaccinationGroupID],
		[rf_VaccinationTypeID],
		[Date],
		[rf_VaccineTypeID],
		[rf_SchemaID],
		[rf_ReasonID])
		select 
			[rf_InoculationCardID],
			[rf_VaccinationGroupID],
			[rf_VaccinationTypeID],
			[Date],
			[rf_VaccineTypeID],
			[rf_SchemaID],
			[rf_ReasonID]
		from dbo.fn_vcn_GetVaccinationPlan(@ic, @date_bd, @mkabid, @vg, @dateBegin, @reasonId)

		FETCH NEXT FROM c
		INTO @vg, @reasonId
	END

	CLOSE c
	DEALLOCATE c

	if (@doInsert = 1)
	begin
		insert into vcn_PlannedInoculation 
			([rf_InoculationCardID],
			[rf_VaccinationGroupID],
			[rf_VaccinationTypeID],
			[Date],
			[rf_VaccineTypeID],
			[rf_SchemaID],
			[rf_ReasonID])
		select 
			[rf_InoculationCardID],
			[rf_VaccinationGroupID],
			[rf_VaccinationTypeID],
			[Date],
			[rf_VaccineTypeID],
			[rf_SchemaID],
			[rf_ReasonID]
		from @resTable
	end

	select
		[Date] as InocDate,
		vg.Name as vgName,
		vnt.ShortName as vntName
	from @resTable rt
	join vcn_VaccinationGroup vg on rt.rf_VaccinationGroupID = vg.VaccinationGroupID
	join vcn_VaccinationType vnt on rt.rf_VaccinationTypeID = vnt.VaccinationTypeID
	join vcn_VaccineType vt on rt.rf_VaccineTypeID = vt.VaccineTypeID

END
go

