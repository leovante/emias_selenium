
create FUNCTION [dbo].[GetNormTariff](@date_ date, @ogrn  varchar(20) )
RETURNS @TabNorm TABLE (
           [rf_ServiceMedicalID] int not null
           ,[rf_TariffTargetID] int not null
           ,[rf_DepartmentID]  int not null
           ,[Value1]   decimal(18,2) not null
           ,[Date_B]   datetime not null
           ,[Value2]   decimal(18,2) not null
           ,[Date_E]   datetime null
           ,[rf_LPUID]  int not null
        ,[Doc]       varchar(150) not null
  ,rf_TariffNormId int
)
 
AS
Begin
  insert  @TabNorm
 select  n.[rf_ServiceMedicalID]
        ,n.[rf_TariffTargetID] 
        ,d.rf_DepartmentID 
        ,[Value1]
           ,n.[Date_B]
           ,[Value2]
           ,n.[Date_E]
           ,d.[rf_LPUID]
           
           ,n.[Doc]
   ,TariffNormID
         
 from (select * from GetStomatTarget()) l
inner join oms_lpu on l.rf_lpuid = lpuid and C_OGRN =@ogrn
 inner join (
 select oms_Department.rf_kl_ageGroupId, 
        oms_Department.rf_lpuid, 
        isnull(dep.DepartmentId,lic.rf_DepartmentID) as rf_DepartmentID, 
        lic.rf_kl_DepartmentProfileId,lic.rf_kl_DepartmentTypeId,
  lic.rf_servicemedicalID, lic.Flags
 
    from oms_LicenceReestrSM lic
            inner join oms_LicenceReestr on LicenceReestrId = rf_LicenceReestrID
            inner join oms_Department on rf_DepartmentId = oms_Department.DepartmentID --and oms_Department.rf_LPUID = oms_LicenceReestr.rf_LPUID 
            left join oms_Department dep on rf_DepartmentId = dep.DepartmentID         --and oms_Department.rf_LPUID = oms_LicenceReestr.rf_LPUID 
 and 
                     ( lic.rf_kl_DepartmentProfileID<>oms_Department.rf_kl_DepartmentProfileID
                        or lic.rf_kl_DepartmentTypeID<>oms_Department.rf_kl_DepartmentTypeID ) 
            inner join oms_lpu on oms_LicenceReestr.rf_lpuid = lpuid and C_OGRN =@ogrn
    group by oms_Department.rf_kl_ageGroupId, 
          oms_Department.rf_lpuid, 
  isnull(dep.DepartmentId,lic.rf_DepartmentID), 
          lic.rf_kl_DepartmentProfileId,
  lic.rf_kl_DepartmentTypeId,
  lic.rf_servicemedicalID,
  lic.Flags    
  ) d on l.rf_lpuid = lpuid and  d.rf_lpuid = lpuid and l.rf_kl_departmentTypeId = d.rf_kl_departmentTypeId 
 
 
 
 inner join oms_tariffnorm n on n.rf_tarifftargetid = l.rf_tarifftargetid and (n.rf_lpuid=0 or n.rf_Lpuid in ( select lpuid from oms_lpu where C_ogrn =@ogrn )) and n.date_E>getdate()
 
 inner join V_oms_servicemedical on n.rf_servicemedicalid = servicemedicalid and
 
 ((d.rf_servicemedicalid = V_oms_servicemedical.servicemedicalid and d.rf_servicemedicalid>0 and d.Flags=1) or
 
 ((d.rf_servicemedicalid = 0 or (d.rf_servicemedicalid > 0 and d.Flags=0))
 
 and l.rf_kl_departmentTypeId = V_oms_servicemedical.rf_kl_departmentTypeId
 
 and (V_oms_servicemedical.rf_kl_departmentProfileId = d.rf_kl_departmentProfileId or V_oms_servicemedical.rf_kl_departmentProfileId=0) ))
 
 
 
 inner join oms_kl_agegroup ag on d.rf_kl_agegroupid= ag.kl_agegroupid
 
 inner join oms_kl_agegroup ag1 on n.rf_kl_AgeGroupID= ag1.kl_AgeGroupID
 
 and ( (ag.name = 'Смешанные') or ag.kl_AgeGroupID=ag1.kl_AgeGroupID)
 
 and d.rf_kl_departmenttypeid = V_oms_servicemedical.rf_kl_departmenttypeid
 
 and (d.rf_kl_departmentprofileid = V_oms_servicemedical.rf_kl_departmentprofileid or V_oms_servicemedical.rf_kl_departmentProfileId=0)
 
 
group by  n.[rf_ServiceMedicalID]
        ,n.[rf_TariffTargetID] 
      ,d.rf_DepartmentID 
         ,[Value1]
         ,n.[Date_B]
         ,[Value2]
         ,n.[Date_E]
         ,d.[rf_LPUID]
         ,n.[Doc]
 ,TariffNormID
 
return
end
go

