CREATE VIEW [V_stt_FHBrigade] AS SELECT 
[hDED].[FHBrigadeID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_stt_FHBrigadeProfile].[Name] as [V_ProfileName], 
[hDED].[rf_FHBrigadeProfileID] as [rf_FHBrigadeProfileID], 
[hDED].[Number] as [Number]
FROM [stt_FHBrigade] as [hDED]
INNER JOIN [stt_FHBrigadeProfile] as [jT_stt_FHBrigadeProfile] on [jT_stt_FHBrigadeProfile].[FHBrigadeProfileID] = [hDED].[rf_FHBrigadeProfileID]
go

