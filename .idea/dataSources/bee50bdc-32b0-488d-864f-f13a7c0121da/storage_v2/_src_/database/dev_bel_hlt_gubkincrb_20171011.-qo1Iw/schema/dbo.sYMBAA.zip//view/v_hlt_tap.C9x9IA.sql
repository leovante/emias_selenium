CREATE VIEW [V_hlt_TAP] AS SELECT 
[hDED].[TAPID], [hDED].[x_Edition], [hDED].[x_Status], 
((TAPID)) as [v_TAP], 
(select convert (datetime,'2222-01-01')) as [V_DateIncReestr], 
((case  [hDED].DisabilityStatus WHEN 0 THEN 'Не указано' WHEN 1 THEN 'Впервые' WHEN 2 THEN 'Повторно' WHEN 3 THEN 'Отказано' ELSE '' END)) as [V_DisabilityStatus], 
(isnull((select '[' + ltrim(rtrim(PCOD)) + '] '+ 
Upper(substring(ltrim(FAM_V), 1, 1))+ CASE WHEN 
LEN(FAM_V) > 0  THEN 
LOWER(SUBSTRING(LTRIM(RTRIM(FAM_V)), 2, 
LEN(LTRIM(RTRIM(FAM_V))) - 1))  ELSE '' END + ' '  + 
Upper(substring(ltrim(IM_V), 1, 1)) + '. ' + 
Upper(substring(ltrim(OT_V), 1, 1)) + '.' from hlt_LPUDoctor where LPUDoctorID = [hDED].rf_LPUDoctorID), '')) as [V_DocInfo], 
(isnull((select ltrim(rtrim(S_POL + ' ' + N_POL)) from hlt_PolisMKAB where PolisMKABID = [hDED].rf_PolisMKABID), '')) as [V_SN_POL], 
((select jT_hlt_MKAB.Family+ ' '+ jT_hlt_MKAB.Name+' '+ jT_hlt_MKAB.OT)) as [v_fio], 
[jT_hlt_MKAB].[NAME] as [v_NAME], 
[jT_hlt_MKAB].[NUM] as [v_NUM], 
[jT_hlt_MKAB].[DATE_BD] as [v_DATE_BD], 
[jT_hlt_MKAB].[OT] as [v_OT], 
[jT_hlt_MKAB].[SS] as [v_SS], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_MKB2ID] as [rf_MKB2ID], 
[jT_oms_MKB1].[DS] as [SILENT_rf_MKB2ID], 
[hDED].[rf_MKBExternalID] as [rf_MKBExternalID], 
[jT_oms_MKB2].[DS] as [SILENT_rf_MKBExternalID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_INVID] as [rf_INVID], 
[hDED].[rf_ReasonCareID] as [rf_ReasonCareID], 
[hDED].[rf_NotWorkDocStatusID] as [rf_NotWorkDocStatusID], 
[hDED].[rf_DirectionID] as [rf_DirectionID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_LPUDoctor_SID] as [rf_LPUDoctor_SID], 
[hDED].[rf_OtherSMOID] as [rf_OtherSMOID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_SpecEventCertID] as [rf_SpecEventCertID], 
[hDED].[rf_MKABSheetFinalDSID] as [rf_MKABSheetFinalDSID], 
[hDED].[rf_OutcomeVisitID] as [rf_OutcomeVisitID], 
[jT_hlt_OutcomeVisit].[Code] as [SILENT_rf_OutcomeVisitID], 
[hDED].[rf_kl_MedCareTypeID] as [rf_kl_MedCareTypeID], 
[jT_oms_kl_MedCareType].[Code] as [SILENT_rf_kl_MedCareTypeID], 
[hDED].[rf_kl_SocStatusID] as [rf_kl_SocStatusID], 
[hDED].[rf_kl_DiseaseType2ID] as [rf_kl_DiseaseType2ID], 
[hDED].[rf_kl_DiseaseTypeID] as [rf_kl_DiseaseTypeID], 
[jT_oms_kl_DiseaseType].[Name] as [SILENT_rf_kl_DiseaseTypeID], 
[hDED].[rf_kl_TraumaTypeID] as [rf_kl_TraumaTypeID], 
[hDED].[rf_kl_ReasonTypeID] as [rf_kl_ReasonTypeID], 
[jT_oms_kl_ReasonType].[Name] as [SILENT_rf_kl_ReasonTypeID], 
[hDED].[rf_kl_VisitResultID] as [rf_kl_VisitResultID], 
[jT_oms_kl_VisitResult].[Name] as [SILENT_rf_kl_VisitResultID], 
[hDED].[rf_kl_HealthGroupID] as [rf_kl_HealthGroupID], 
[hDED].[rf_kl_DispRegStateID] as [rf_kl_DispRegStateID], 
[hDED].[rf_kl_DispRegState2ID] as [rf_kl_DispRegState2ID], 
[hDED].[rf_kl_RegistrationEndReasonID] as [rf_kl_RegistrationEndReasonID], 
[hDED].[rf_kl_RegistrationEndReason2ID] as [rf_kl_RegistrationEndReason2ID], 
[hDED].[rf_kl_StatCureResultID] as [rf_kl_StatCureResultID], 
[jT_oms_kl_StatCureResult].[Name] as [SILENT_rf_kl_StatCureResultID], 
[hDED].[rf_kl_SickListReasonID] as [rf_kl_SickListReasonID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[hDED].[rf_kl_VisitPlaceID] as [rf_kl_VisitPlaceID], 
[jT_oms_kl_VisitPlace].[Name] as [SILENT_rf_kl_VisitPlaceID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_kl_PatientStatusID] as [rf_kl_PatientStatusID], 
[hDED].[rf_TypeTAPID] as [rf_TypeTAPID], 
[jT_hlt_TypeTAP].[Code] as [SILENT_rf_TypeTAPID], 
[hDED].[rf_PolisMKABID] as [rf_PolisMKABID], 
[hDED].[rf_RegistrPatientID] as [rf_RegistrPatientID], 
[jT_hlt_RegistrPatient].[Num] as [SILENT_rf_RegistrPatientID], 
[hDED].[rf_mkp_CardGUID] as [rf_mkp_CardGUID], 
[hDED].[rf_kl_ReasonInvID] as [rf_kl_ReasonInvID], 
[jT_oms_kl_ReasonInv].[Name] as [SILENT_rf_kl_ReasonInvID], 
[hDED].[rf_kl_SanitationID] as [rf_kl_SanitationID], 
[jT_oms_kl_Sanitation].[Name] as [SILENT_rf_kl_SanitationID], 
[hDED].[FAMILY] as [FAMILY], 
[hDED].[IsClosed] as [IsClosed], 
[hDED].[CarePersonSex] as [CarePersonSex], 
[hDED].[CarePersonAge] as [CarePersonAge], 
[hDED].[DateTAP] as [DateTAP], 
[hDED].[FlagStatist] as [FlagStatist], 
[hDED].[DateClose] as [DateClose], 
[hDED].[DateCreateTAP] as [DateCreateTAP], 
[hDED].[NumInOtherSystem] as [NumInOtherSystem], 
[hDED].[Flags] as [Flags], 
[hDED].[isDVNClosed] as [isDVNClosed], 
[hDED].[UGUID] as [UGUID], 
[hDED].[S_POL] as [S_POL], 
[hDED].[DisabilityStatus] as [DisabilityStatus], 
[hDED].[N_POL] as [N_POL], 
[hDED].[isWorker] as [isWorker], 
[hDED].[CareBegin] as [CareBegin], 
[hDED].[CareEnd] as [CareEnd], 
[hDED].[Description] as [Description], 
[hDED].[FlagBill] as [FlagBill], 
[hDED].[rf_CreateUserID] as [rf_CreateUserID], 
[hDED].[rf_EditUserID] as [rf_EditUserID], 
[hDED].[CreateUserName] as [CreateUserName], 
[hDED].[EditUserName] as [EditUserName]
FROM [hlt_TAP] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_MKB] as [jT_oms_MKB1] on [jT_oms_MKB1].[MKBID] = [hDED].[rf_MKB2ID]
INNER JOIN [oms_MKB] as [jT_oms_MKB2] on [jT_oms_MKB2].[MKBID] = [hDED].[rf_MKBExternalID]
INNER JOIN [hlt_OutcomeVisit] as [jT_hlt_OutcomeVisit] on [jT_hlt_OutcomeVisit].[OutcomeVisitID] = [hDED].[rf_OutcomeVisitID]
INNER JOIN [oms_kl_MedCareType] as [jT_oms_kl_MedCareType] on [jT_oms_kl_MedCareType].[kl_MedCareTypeID] = [hDED].[rf_kl_MedCareTypeID]
INNER JOIN [oms_kl_DiseaseType] as [jT_oms_kl_DiseaseType] on [jT_oms_kl_DiseaseType].[kl_DiseaseTypeID] = [hDED].[rf_kl_DiseaseTypeID]
INNER JOIN [oms_kl_ReasonType] as [jT_oms_kl_ReasonType] on [jT_oms_kl_ReasonType].[kl_ReasonTypeID] = [hDED].[rf_kl_ReasonTypeID]
INNER JOIN [oms_kl_VisitResult] as [jT_oms_kl_VisitResult] on [jT_oms_kl_VisitResult].[kl_VisitResultID] = [hDED].[rf_kl_VisitResultID]
INNER JOIN [oms_kl_StatCureResult] as [jT_oms_kl_StatCureResult] on [jT_oms_kl_StatCureResult].[kl_StatCureResultID] = [hDED].[rf_kl_StatCureResultID]
INNER JOIN [oms_kl_VisitPlace] as [jT_oms_kl_VisitPlace] on [jT_oms_kl_VisitPlace].[kl_VisitPlaceID] = [hDED].[rf_kl_VisitPlaceID]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [hlt_TypeTAP] as [jT_hlt_TypeTAP] on [jT_hlt_TypeTAP].[TypeTAPID] = [hDED].[rf_TypeTAPID]
INNER JOIN [hlt_RegistrPatient] as [jT_hlt_RegistrPatient] on [jT_hlt_RegistrPatient].[RegistrPatientID] = [hDED].[rf_RegistrPatientID]
INNER JOIN [oms_kl_ReasonInv] as [jT_oms_kl_ReasonInv] on [jT_oms_kl_ReasonInv].[kl_ReasonInvID] = [hDED].[rf_kl_ReasonInvID]
INNER JOIN [oms_kl_Sanitation] as [jT_oms_kl_Sanitation] on [jT_oms_kl_Sanitation].[kl_SanitationID] = [hDED].[rf_kl_SanitationID]
go

