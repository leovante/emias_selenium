
CREATE PROCEDURE [dbo].[ChangeLsCod_ClsGuid](@oldCode bigint, @newCode bigint, @clsGuid uniqueidentifier)
AS
BEGIN

	begin try 
		if (select COUNT(1) from sys.triggers where name like '%insert_Nameless_LS%') = 1
				DISABLE TRIGGER insert_Nameless_LS ON oms_LS;	
	end try
	begin catch
	end catch

	declare @oldLsID int; --ID ЛС с положительным кодом
	select @oldLsID = LSID from oms_LS where NOMK_LS = @oldCode;
	declare @newLsID int; --ID ЛС с отрицательным кодом
	select @newLsID = LSID from oms_LS where NOMK_LS = @newCode;

	if (@newLsID is null)
	begin
		-- добавляем положительный ЛС из РЛС
		exec dbo.ImportLSFromRLS @newCode
		select @newLsID = LSID from oms_LS where NOMK_LS = @newCode;
	end

	if (@oldLsID is not null and @newLsID is not null)
	begin		
		declare @clsId int;
		
		select @clsid = ClsiD from oms_CLS where GuidCls = @clsGuid
	
		update oms_CLS
		set rf_LSID = @newLsID
		where CLSID = @clsId

		update oms_PharmacyRecipe
		set rf_LSID = @newLsID
		where rf_CLSID = @clsId

		update oms_DPCPharmacyRecipe
		set rf_LSID = @newLsID
		where rf_CLSID = @clsId

		update oms_Recipe
		set rf_LSID = @newLsID
		where rf_CLSID = @clsId					
					
		update oms_LS
		set Date_E = '2200-01-01T00:00:00.000'
		where LSID = @newLsID


		update oms_LS
		set rf_GroupIMNID = 
				(
					select top 1 rf_GroupIMNID from oms_LS where LSID = @oldLsID
				)
		where LSID = @newLsID and rf_GRoupImnID = 0

		update oms_LS
		set FCode = 
			(
				select top 1 FCode from oms_LS where LSID = @oldLsID
			)
		where LSID = @newLsID and FCode = 0
	end

	begin try
		if (select COUNT(1) from sys.triggers where name like '%insert_Nameless_LS%') = 1
			ENABLE TRIGGER insert_Nameless_LS ON oms_LS;	
	end try
	begin catch 
	end catch

END
go

