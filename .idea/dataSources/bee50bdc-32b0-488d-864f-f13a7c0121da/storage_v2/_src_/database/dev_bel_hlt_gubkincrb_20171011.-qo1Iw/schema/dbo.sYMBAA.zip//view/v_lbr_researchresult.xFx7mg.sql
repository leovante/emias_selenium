CREATE VIEW [V_lbr_ResearchResult] AS SELECT 
[hDED].[ResearchResultID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResearchParamValueTypeID] as [rf_ResearchParamValueTypeID], 
[jT_lbr_ResearchParamValueType].[Name] as [SILENT_rf_ResearchParamValueTypeID], 
[hDED].[rf_ResearchGUID] as [rf_ResearchGUID], 
[hDED].[rf_ResearchTypeParamUGUID] as [rf_ResearchTypeParamUGUID], 
[hDED].[Caption] as [Caption], 
[hDED].[Value] as [Value], 
[hDED].[Unit] as [Unit], 
[hDED].[rBoolean] as [rBoolean], 
[hDED].[rInteger] as [rInteger], 
[hDED].[rDecimal] as [rDecimal], 
[hDED].[rString] as [rString], 
[hDED].[rDateTime] as [rDateTime], 
[hDED].[UGUID] as [UGUID], 
[hDED].[RequiredParam] as [RequiredParam], 
[hDED].[LRef] as [LRef], 
[hDED].[HRef] as [HRef], 
[hDED].[DateComplete] as [DateComplete], 
[hDED].[TestNote] as [TestNote], 
[hDED].[ExtLink] as [ExtLink]
FROM [lbr_ResearchResult] as [hDED]
INNER JOIN [lbr_ResearchParamValueType] as [jT_lbr_ResearchParamValueType] on [jT_lbr_ResearchParamValueType].[ResearchParamValueTypeID] = [hDED].[rf_ResearchParamValueTypeID]
go

