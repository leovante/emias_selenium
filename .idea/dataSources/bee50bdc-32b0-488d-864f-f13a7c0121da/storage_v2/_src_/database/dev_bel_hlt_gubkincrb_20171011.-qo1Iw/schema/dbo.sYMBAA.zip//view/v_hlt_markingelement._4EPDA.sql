CREATE VIEW [V_hlt_MarkingElement] AS SELECT 
[hDED].[MarkingElementID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_BlankTemplateID] as [rf_BlankTemplateID], 
[jT_hlt_BlankTemplate].[Caption] as [SILENT_rf_BlankTemplateID], 
[hDED].[rf_MarkingID] as [rf_MarkingID], 
[jT_hlt_Marking].[Name] as [SILENT_rf_MarkingID], 
[hDED].[IdElement] as [IdElement], 
[hDED].[Flags] as [Flags]
FROM [hlt_MarkingElement] as [hDED]
INNER JOIN [hlt_BlankTemplate] as [jT_hlt_BlankTemplate] on [jT_hlt_BlankTemplate].[BlankTemplateID] = [hDED].[rf_BlankTemplateID]
INNER JOIN [hlt_Marking] as [jT_hlt_Marking] on [jT_hlt_Marking].[MarkingID] = [hDED].[rf_MarkingID]
go

