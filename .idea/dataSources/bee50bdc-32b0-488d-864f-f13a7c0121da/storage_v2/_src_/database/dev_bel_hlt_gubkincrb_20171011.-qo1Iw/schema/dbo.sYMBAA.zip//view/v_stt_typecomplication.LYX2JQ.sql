CREATE VIEW [V_stt_TypeComplication] AS SELECT 
[hDED].[TypeComplicationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_TypeComplication] as [hDED]
go

