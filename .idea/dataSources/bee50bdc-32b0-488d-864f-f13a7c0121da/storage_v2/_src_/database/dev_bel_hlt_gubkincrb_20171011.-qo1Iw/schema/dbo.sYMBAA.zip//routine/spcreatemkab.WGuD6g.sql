-- =============================================
-- Author:		Шумаков Сергей
-- Create date: '2008-11-26'
-- Description:	Создаем медицинскую карту пациента
-- =============================================

CREATE PROCEDURE [spCreateMKAB]
	@input xml,
	@result int output
AS
BEGIN
     -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SET ARITHABORT ON;

	declare @cnt int;
	declare @PATID varchar(25);
    DECLARE @LPUID int;

	select @cnt = count(MKABID) from hlt_MKAB mk
	where mk.Family = @input.query('/hlt_MKAB/FAMILY').value('.', 'varchar(40)')
		and mk.S_POL = @input.query('/hlt_MKAB/S_POL').value('.', 'varchar(10)')
		and mk.N_POL = @input.query('/hlt_MKAB/N_POL').value('.', 'varchar(50)')

	-- Мед. карта уже существует...
	if (@cnt != 0)
	begin
		set @result = -1;
		return;
	end
    
    -- Получим поликлинику
   set @lpuid = 
    (
      SELECT top 1 ISNULL(lp.LPUID, 0) FROM oms_LPU lp
      WHERE lp.C_OGRN =
      (
          SELECT top 1 isnull(us.ValueStr, '') from x_UserSettings us
          where us.Property = 'ОГРН поликлиники'
      )
      and lp.MCOD = 
      (
          SELECT top 1 isnull(us.ValueStr, '') from x_UserSettings us
          where us.Property = 'Код поликлиники'
      )
      and lp.DATE_E > GETDATE()
    )

    
    -- Проверим, есть ли такой человек среди застрахованных...
    select @cnt = count(pt.PatientID), @PATID = isnull(min(pt.PatientID), 0) from hlt_Patient pt
	where pt.Family = @input.query('/hlt_MKAB/FAMILY').value('.', 'varchar(40)')
		and pt.S_POL = @input.query('/hlt_MKAB/S_POL').value('.', 'varchar(10)')
		and pt.N_POL = @input.query('/hlt_MKAB/N_POL').value('.', 'varchar(50)')
        
	if (@cnt != 0)
	begin
    	-- Создаем мед. карту по регистру застрахованных
        
         INSERT INTO hlt_MKAB 
         (
            Adres,
            DATE_BD,
            DatePolBegin,
            DatePolEnd,
            Dependent,
            FAMILY,
            IsWorker,
            KindCod,
            MilitaryCOD,
            N_DOC,
            N_POL,
            [Name],
            OT,
            PhoneHome,
            PhoneWork,
            Post,
            Profession,
            rf_CitizenID,
            rf_EnterpriseID,
            rf_INVID,
            rf_OKATOID,
            rf_SMOID,
            rf_kl_SocStatusID,
            rf_TYPEDOCID,
            S_DOC,
            S_POL,
            SS,
            w,
            [WORK],
			rf_LPUID       
         )
		 (   
        	select 
                    Adres,
                    Birthday,
                    DatePolBegin,
                    DatePolEnd,
                    Dependent,
                    FAMILY,
                    IsWorker,
                    KindCod,
                    MilitaryCOD,
                    N_DOC,
                    N_POL,
                    [Name],
                    OT,
                    PhoneHome,
                    PhoneWork,
                    Post,
                    Profession,
                    rf_CitizenID,
                    rf_EnterpriseID,
                    rf_INVID,
                    rf_OKATOID,
                    rf_SMOID,
                    rf_kl_SocStatusID,
                    rf_TYPEDOCID,
                    S_DOC,
                    Substring(S_POL,0,10),
                    SS,
                    w,
                    PlaceEmployment,
					@lpuid           
           from hlt_Patient 
           where PatientID = @PATID
         )


		set @result = 1;
		return;
	end
    

	begin try

	insert into hlt_MKAB 
    (
    	FAMILY,
        [NAME],
        OT,
        W,
        DATE_BD,
        DatePolBegin,
        DatePolEnd,
        S_POL,
        N_POL,
        S_DOC,
        N_DOC,
        rf_SMOID,
        
        SS,
        ADRES,
        PhoneWork,
        PhoneHome,
        [Work],
        Profession,
        Post,
        Dependent,
        AdresFact,
        IsWorker,
		rf_LPUID
    )
    (
	    SELECT
        @input.query('/hlt_MKAB/FAMILY').value('.', 'varchar(40)'),
        @input.query('/hlt_MKAB/NAME').value('.', 'varchar(40)'),
        @input.query('/hlt_MKAB/OT').value('.', 'varchar(40)'),
        @input.query('/hlt_MKAB/W').value('.', 'int'),
        @input.query('/hlt_MKAB/DATE_BD').value('.', 'datetime'),
        @input.query('/hlt_MKAB/DatePolBegin').value('.', 'datetime'),
        @input.query('/hlt_MKAB/DatePolEnd').value('.', 'datetime'),
        @input.query('/hlt_MKAB/S_POL').value('.', 'varchar(10)'),
        @input.query('/hlt_MKAB/N_POL').value('.', 'varchar(50)'),
        @input.query('/hlt_MKAB/S_DOC').value('.', 'varchar(10)'),
        @input.query('/hlt_MKAB/N_DOC').value('.', 'varchar(15)'),

		(
			select top 1 isnull (SMOID, 0) from oms_SMO 
			where Q_NAME = @input.query('/PatientInfo/SMO_Q_NAME').value('.', 'varchar(150)')
		),
        
        
        @input.query('/hlt_MKAB/SS').value('.', 'varchar(14)'),
        @input.query('/hlt_MKAB/ADRES').value('.', 'varchar(200)'),
        @input.query('/hlt_MKAB/PhoneWork').value('.', 'varchar(20)'),
        @input.query('/hlt_MKAB/PhoneHome').value('.', 'varchar(20)'),
        @input.query('/hlt_MKAB/Work').value('.', 'varchar(50)'),
        @input.query('/hlt_MKAB/Profession').value('.', 'varchar(50)'),
        @input.query('/hlt_MKAB/Post').value('.', 'varchar(50)'),
        @input.query('/hlt_MKAB/Dependent').value('.', 'bit'),
        @input.query('/hlt_MKAB/AdresFact').value('.', 'varchar(200)'),
        @input.query('/hlt_MKAB/IsWorker').value('.', 'bit'),
		@lpuid        
    )
   
	end try
	begin catch
		set @result = -2;
		return;
	end catch
  	-- Создаем мед. карту по переданной xml-ке
	set @result = 2;
	return;
END

go

