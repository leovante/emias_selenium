CREATE VIEW [V_oms_STF] AS SELECT 
[hDED].[STFID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_Organisation].[BIK_Bank] as [V_BIK_Bank], 
[jT_oms_Organisation].[C_Account] as [V_C_Account], 
[jT_oms_Organisation].[INN] as [V_INN], 
[jT_oms_Organisation].[R_Account] as [V_R_Account], 
[jT_oms_Organisation].[Bank] as [V_Bank], 
[hDED].[rf_OKATO] as [rf_OKATO], 
[jT_oms_OKATO].[C_OKATO] as [SILENT_rf_OKATO], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[TF_NAME] as [TF_NAME], 
[hDED].[FAMD_RUK] as [FAMD_RUK], 
[hDED].[IMD_RUK] as [IMD_RUK], 
[hDED].[OTD_RUK] as [OTD_RUK], 
[hDED].[FAMD_R] as [FAMD_R], 
[hDED].[FAM_BUX] as [FAM_BUX], 
[hDED].[IM_BUX] as [IM_BUX], 
[hDED].[OT_BUX] as [OT_BUX], 
[hDED].[FAM_RBYX] as [FAM_RBYX], 
[hDED].[TEL] as [TEL], 
[hDED].[FAX] as [FAX], 
[hDED].[E_MAIL] as [E_MAIL], 
[hDED].[ADRES] as [ADRES], 
[hDED].[POST_IDP] as [POST_IDP], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[F_OGRN] as [F_OGRN], 
[hDED].[OKPO] as [OKPO], 
[hDED].[Code_STF] as [Code_STF]
FROM [oms_STF] as [hDED]
INNER JOIN [oms_Organisation] as [jT_oms_Organisation] on [jT_oms_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID]
INNER JOIN [oms_OKATO] as [jT_oms_OKATO] on [jT_oms_OKATO].[OKATOID] = [hDED].[rf_OKATO]
go

