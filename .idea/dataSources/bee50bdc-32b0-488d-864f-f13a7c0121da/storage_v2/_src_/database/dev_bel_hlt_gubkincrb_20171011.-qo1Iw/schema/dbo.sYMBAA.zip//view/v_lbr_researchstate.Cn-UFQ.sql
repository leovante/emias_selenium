CREATE VIEW [V_lbr_ResearchState] AS SELECT 
[hDED].[ResearchStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Description] as [Description]
FROM [lbr_ResearchState] as [hDED]
go

