CREATE FUNCTION stroka_Deti (@MKB_CODES as nvarchar(4000), @pol int, @DateBegin datetime, @DateEnd datetime)
RETURNS TABLE
AS
RETURN (
Select sum(byt) as byt,sum(street) as street,sum(transport_sum) as transport_sum,sum(transport_avto) as transport_avto,
sum(scool) as scool,sum(sport) as sport,sum(itogo-byt-street-transport_sum-scool-sport) as proch,sum(itogo) as itogo
  from(
SELECT 
isnull(sum(case when TRT.CODE='2.1' then 1 else 0 end),0) as byt,
isnull(sum(case when TRT.CODE='2.2' then 1 else 0 end),0) as street,
isnull(sum(case when TRT.CODE in ('2.3','2.3.1') then 1 else 0 end),0) as transport_sum,
isnull(sum(case when TRT.CODE='2.3.1' then 1 else 0 end),0) as transport_avto,
isnull(sum(case when TRT.CODE='2.4' then 1 else 0 end),0) as scool,
isnull(sum(case when TRT.CODE='2.5' then 1 else 0 end),0) as sport,
0 as proch,
isnull(sum(case when TRT.CODE not in ('0','3') then 1 else 0 end),0) as itogo
from oms_MKB MKB WITH (NOLOCK)
inner join selectByMKB(@MKB_CODES) FU on MKB.MKBID=FU.MKBID
inner join stt_Diagnos DiS WITH (NOLOCK) on (MKB.MKBID=DiS.rf_MKBID) and (DiS.rf_DiagnosTypeID in (select DiagnosTypeID from stt_DiagnosType DiST where Code = '07' OR Code = '10'))
inner join stt_MedicalHistory MH WITH (NOLOCK) on MH.Sex = @pol and (MH.MedicalHistoryID=Dis.rf_MedicalHistoryID)
inner join tmp_report_OKATO WITH (NOLOCK) on OKATOID=MH.rf_OKATOID
inner join v_currentmigrationpatient cmp WITH (NOLOCK) on cmp.rf_medicalHistoryid=medicalhistoryid 
and (cmp.DateIngoing between @DateBegin and @DateEnd)
inner join stt_migrationpatient mig WITH (NOLOCK) on mig.rf_medicalHistoryid=medicalhistoryid and mig.rf_StationarBranchID>0
inner join stt_StationarBranch WITH (NOLOCK) on StationarBranchID=mig.rf_StationarBranchID 
inner join tmp_report_Dep on tmp_report_Dep.DepartmentID=stt_StationarBranch.rf_DepartmentID
inner join stt_Injury TRT WITH (NOLOCK) on (TRT.InjuryID = MH.rf_InjuryID) and TRT.CODE<>'3'
where (dbo.FullYearAge(MH.BD,cmp.DateIngoing)< 18)
and mig.migrationPatientID not in (Select top 1 migrationPatientID from stt_migrationPatient WITH (NOLOCK)
	where rf_medicalHistoryID=medicalHistoryID and rf_StationarBranchID>0
	order by dateIngoing)--не приемное отделение
UNION ALL
Select isnull(sum(case when TRT.CODE='6' then 1 else 0 end),0) as byt,
isnull(sum(case when TRT.CODE='7' then 1 else 0 end),0) as street,
isnull(sum(case when TRT.CODE in ('8','9') then 1 else 0 end),0) as transport_sum,
isnull(sum(case when TRT.CODE='9' then 1 else 0 end),0) as transport_avto,
isnull(sum(case when TRT.CODE='10' then 1 else 0 end),0) as scool,
isnull(sum(case when TRT.CODE='11' then 1 else 0 end),0) as sport,
0 as proch,
isnull(sum(case when TRT.CODE not in ('0','13') then 1 else 0 end),'') as itogo
from oms_MKB MKB WITH (NOLOCK)
inner join selectByMKB(@MKB_CODES) FU on MKB.MKBID=FU.MKBID
inner join hlt_TAP WITH (NOLOCK) on MKB.MKBID=rf_MKBID and 
(hlt_TAP.DateClose between @DateBegin and @DateEnd)
inner join hlt_MKAB WITH (NOLOCK) ON (hlt_MKAB.w = @pol) and MKABID=rf_MKABID
inner join tmp_report_OKATO on OKATOID=hlt_MKAB.rf_OKATOID
inner join tmp_report_Dep on tmp_report_Dep.DepartmentID=hlt_TAP.rf_DepartmentID 
inner join oms_kl_TraumaType TRT WITH (NOLOCK) on kl_TraumaTypeID=rf_kl_TraumaTypeID and TRT.CODE<>'13'
inner join (
Select min(TAPID) as mTAPID from hlt_TAP WITH (NOLOCK)
where (hlt_TAP.DateClose between @DateBegin and @DateEnd)
group by rf_MKABID,rf_MKBID
)min_T on TAPID=mTAPID
where (dbo.FullYearAge(hlt_MKAB.DATE_BD,hlt_TAP.DateClose) < 18) 
)t
)
go

