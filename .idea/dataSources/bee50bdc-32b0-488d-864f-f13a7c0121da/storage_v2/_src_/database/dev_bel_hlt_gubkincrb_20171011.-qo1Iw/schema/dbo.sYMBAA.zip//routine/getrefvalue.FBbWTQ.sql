
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetRefValue]
	@txt varchar(250),
	@dtdid int,
	@id	varchar(50),
	@Result varchar(max) output	
	,@linkedDEDID int = 0
AS
BEGIN
	
	IF (Left(@txt, 1) != '#' or Right(@txt, 1) != '#' or len(@txt) <= 2) RETURN ''
	/* Результат */
	DECLARE @ResultVar varchar(max)
	
	/* Имя таблицы, ПК */
	DECLARE @tbName varchar(50), @fldName varchar(50), @fldNameNumber bit	
	SELECT @tbName  = [headTable], @fldName=PK_Name, @fldNameNumber = 1 from x_docTypeDef where docTypeDefID = @dtdid
	if @linkedDEDID > 0 
	BEGIN
		SET @fldName = isnull(( SELECT name from x_docElemDef where docElemDefID = @linkedDEDID), '')
		SET @fldNameNumber = 0
	END

	/* Позиция разделителя */
	DECLARE  @divInd int 
	SET @divInd = charindex('.', @txt)
	
	/* Выбираемый элемент */
	DECLARE @selElem varchar(250)
	DECLARE @dtFormat varchar(10)
	SET @dtFormat = ''

	IF (@divInd != 0) 
		BEGIN
			/* Просто поле */		
			SET @selElem = substring(@txt, 2, @divInd - 2)		
		END
	ELSE
		BEGIN		
			/* Ссылочное поле */
			SET @selElem =  replace(@txt, '#', '')
		END	
	
	declare @number bit
	set @number = 0;
	/*если у нас используются числовые значения, то берём просто число */
	if ((select count(1)--top 1 v.Name 
		from x_docElemDef e 
			inner join x_valueType v on e.ValueType = v.ValueTypeID 
		WHERE DocTypeDefID = @dtdid AND FieldName = @selElem
		and v.Name in ('tinyint', 'smallint', 'int', 'bit', 'bigint')) > 0)
	begin
		set @number = 1
	end

	/*Используем формат даты*/
	--было: if (isnull((select top 1 ValueType from x_docElemDef WHERE DocTypeDefID = @dtdid AND FieldName = @selElem), 0) = 5)
	--было: SET @dtFormat = ', 104'
	if ((select count(1)--top 1 v.Name 
		from x_docElemDef e 
			inner join x_valueType v on e.ValueType = v.ValueTypeID 
		WHERE DocTypeDefID = @dtdid AND FieldName = @selElem
		and v.Name in ('datetime')) > 0)
	begin
		SET @dtFormat = ', 104'
	END

	/* Команда выбора данных */
	DECLARE @cmd nvarchar(4000)	
	/*SET @cmd = 'select @res1=convert(varchar(max), ' + @selElem + @dtFormat + ')  from ' + @tbName + 
				' where cast(' +  @fldName + ' as varchar(10))  = ''' + @id + ''''*/

	if (@number = 1)
	begin
		SET @cmd = 'select @res1=' + @selElem + ' from ' + @tbName 
	end else
	begin
		SET @cmd = 'select @res1=convert(varchar(max), ' + @selElem + @dtFormat + ')  from ' + @tbName 
	end

	/*IF (@tbName = 'hlt_TAP' and @fldName = 'TAPID')
	BEGIN
		SET @cmd =  @cmd + ' where ' +  @fldName + '  = ' + @id 
	END
	ELSE IF (@tbName = 'hlt_MKAB' and @fldName = 'MKABID')
	BEGIN
		SET @cmd =  @cmd + ' where ' +  @fldName + '  = ' + @id 
	END 
	ELSE IF (@tbName = 'hlt_MedRecord' and @fldName = 'MedRecordID')
	BEGIN
		SET @cmd =  @cmd + ' where ' +  @fldName + '  = ' + @id 
	END 
	ELSE IF (@tbName = 'hlt_VisitHistory' and @fldName = 'VisitHistoryID')
	BEGIN
		SET @cmd =  @cmd + ' where ' +  @fldName + '  = ' + @id 
	END
	ELSE IF (@tbName = 'hlt_LPUDoctor' and @fldName = 'LPUDoctorID')
	BEGIN
		SET @cmd =  @cmd + ' where ' +  @fldName + '  = ' + @id 
	END 
	ELSE
	BEGIN
		SET @cmd =  @cmd + ' where cast(' +  @fldName + ' as varchar(50))  = ''' + @id + ''''		
	END
	*/

	if (@fldNameNumber = 1)
	begin
		SET @cmd =  @cmd + ' where ' +  @fldName + ' = ' + @id
	end else
	begin
		SET @cmd =  @cmd + ' where cast(' +  @fldName + ' as varchar(50))  = ''' + @id + ''''	
	end

--print @cmd

	EXEC sp_executesql @cmd, N'@res1 varchar(255) out', @res1 = @ResultVar out 	
	--print @cmd
	/*Выбирали конечный элемент - выходим */
	IF (@divInd = 0) 
	BEGIN
		SET @Result = @ResultVar
		RETURN 0
	END

	/* Выбирали ссылочный документ. Определяем новый доктип */
	DECLARE @newDTDID int, @newDEDID int
	SELECT @newDTDID = linkedDocTypeDefID, @newDEDID = LinkedDocElemDefID FROM x_docElemDef 
		WHERE DocTypeDefID = @dtdid AND FieldName = @selElem

	/* Новый запрос */
	SET @selElem = '#' +  right(@txt, len(@txt) - @divInd )	

	DECLARE	@return_value int
	DECLARE	@refResult varchar(max)

	EXEC	@return_value = [dbo].[GetRefValue]
			@txt = @selElem,
			@dtdid = @newDTDID,
			@id = @ResultVar,
			@Result = @refResult OUTPUT
			,@linkedDEDID = @newDEDID
	
	SET @Result = @refResult
	RETURN @return_value
END
go

