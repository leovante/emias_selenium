-- =============================================
-- Author:		Кульбабов Василий
-- Create date: 28.11.2013
-- Description:	Получение даты выбытия по движению
-- =============================================
create function [dbo].[stt_DateOutMigration_v2](@MigrationPatientID int)
returns datetime
begin

return (select top 1 DateIngoing from stt_MigrationPatient
		where MigrationPatientID =[dbo].[stt_NextMigration_v2](@MigrationPatientID))	 
		
end
go

