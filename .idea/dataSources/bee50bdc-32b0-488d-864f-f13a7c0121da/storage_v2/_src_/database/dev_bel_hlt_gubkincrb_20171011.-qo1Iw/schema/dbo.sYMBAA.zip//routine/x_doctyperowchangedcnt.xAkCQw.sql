-- =============================================
-- Author:		Сергей Шумаков
-- Create date: 2009-02-17
-- Description:	Количество изменившихся записей по доктипу
-- =============================================
CREATE FUNCTION x_DocTypeRowChangedCnt
(
	
	@DocTypeID int,
	@Date datetime
)
RETURNS int
AS
BEGIN
	DECLARE @Result int

	select @Result = count(distinct ObjID) from x_ObjLife
	where EditionDt > '2009-02-02T00:00:00'
	and DocTypeDefID = 217

	RETURN @Result
END
go

