-- =============================================
-- Author:		Кульбабов Василий
-- Create date: 28.11.2013
-- Description:	Возвращает ID следующего движения пациента, за переданным
-- =============================================
create function [dbo].[stt_NextMigration_v2](@MigrationPatientID int)
returns int
begin

declare @NexMigrationPatientID int ,@MigrationDateTime datetime,@MedicalHistoryID int
set @NexMigrationPatientID = null

select @MedicalHistoryID =rf_MedicalHistoryID,@MigrationDateTime = DateIngoing 
from stt_MigrationPatient where MigrationPatientID = @MigrationPatientID	  

if(@MigrationPatientID <=0 or @MedicalHistoryID <=0) return 0

select top 1 @NexMigrationPatientID=MigrationPatientID from stt_MigrationPatient
where rf_MedicalHistoryID = @MedicalHistoryID and DateIngoing >@MigrationDateTime
order by DateIngoing 

return @NexMigrationPatientID	

end
go

