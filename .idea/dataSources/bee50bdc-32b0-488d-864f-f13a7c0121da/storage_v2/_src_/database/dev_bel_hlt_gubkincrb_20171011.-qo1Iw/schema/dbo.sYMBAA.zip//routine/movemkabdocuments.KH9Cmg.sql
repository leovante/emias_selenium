
-- =============================================
-- Author:		Пищулин Игорь
-- Create date: 
-- Description:	
-- =============================================
CREATE PROCEDURE MoveMkabDocuments 
	-- Add the parameters for the stored procedure here
	@mkabFrom int = 0, 
	@mkabTo int = 0
AS
BEGIN
	SET NOCOUNT ON;
	
	--получаем гуиды мкабов
	declare @mkabguidfrom uniqueidentifier
	declare @mkabguidto uniqueidentifier
	select @mkabguidfrom = case mkabid when @mkabFrom then uguid else @mkabguidfrom end,@mkabguidto = case mkabid when @mkabTo then uguid else @mkabguidto end from hlt_MKAB where mkabid in(@mkabFrom,@mkabTo)
	-- в переменных теперь гуиды

	--получаем идентификатор документа МКАБ
	declare @mkabdtid int
	select @mkabdtid = DocTypeDefID from x_DocTypeDef where HeadTable = 'hlt_mkab'
	--

	--строим запросы по ссылающимся полям
	declare @sql varchar(max)
	select @sql = STUFF(
                        (select 'update ' + dt.HeadTable +' set '+ de.FieldName + '=' + 
	 case when de.SqlDataType = 'uniqueidentifier' then ''''+convert(varchar(40), @mkabguidto)+'''' else convert(varchar(15), @mkabTo) end +
	' where ' + de.FieldName + '=' + 
	 case when de.SqlDataType = 'uniqueidentifier' then ''''+convert(varchar(40), @mkabguidfrom)+'''' else convert(varchar(15), @mkabfrom) end + ';' from x_DocElemDef de
	join x_DocElemDef linkde on de.LinkedDocElemDefID = linkde.DocElemDefID
	join x_DocTypeDef dt on de.DocTypeDefID = dt.DocTypeDefID
	where de.LinkedDocTypeDefID = @mkabdtid and de.ElemType = 2 --srv
	for xml path(''))
                        , 1
                        , 0
                        , '')

	exec(@sql)
	--
END
go

