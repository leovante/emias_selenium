-- =============================================
-- Author:		Kulbabov Vasiliy
-- Create date: 25.01.2016
-- Description:	Генерирует номер мед карты.
-- =============================================
CREATE PROCEDURE [dbo].[GetNewMedCardNum] 
	-- Add the parameters for the stored procedure here
	@num varchar(100) output, 
	@userID int,
	@StationarBranchID int,
	@date datetime	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	-- SET NOCOUNT ON;
set transaction isolation level SERIALIZABLE 
begin transaction  GetMedCardNum

UPDATE [dbo].[x_UserSettings] 
set [ValueInt]=[ValueInt]+1
where Property ='LastMedcardNum'
and OwnerGUID ='4DF516BE-7A1D-416c-BD93-1CBB2159B26D'
and rf_UserID = 1

	if(@@rowcount=0)
	begin
		INSERT INTO [dbo].[x_UserSettings]
			   ([rf_UserID]
			   ,[OwnerGUID]
			   ,[DocTypeDefGUID]
			   ,[rf_SettingTypeID]
			   ,[Property]
			   ,[ValueInt]
			  )
		 VALUES
			   (1
			   ,'4DF516BE-7A1D-416c-BD93-1CBB2159B26D'           
			   ,'00000000-0000-0000-0000-000000000000'           
			   ,(select SettingTypeID from x_SettingType where MnemCode='Целая настройка')
			   ,'LastMedcardNum1'
			   ,1)
	end

	select @num= cast([ValueInt] as varchar) from x_userSettings  
	where Property ='LastMedcardNum'
	and OwnerGUID ='4DF516BE-7A1D-416c-BD93-1CBB2159B26D'
	and rf_UserID = 1

	declare @MedCardTemplate  varchar(100)

	select top 1 @MedCardTemplate =ValueStr from x_UserSettings   
	where Property ='MedCardNumTemplate'
	and OwnerGUID ='4DF516BE-7A1D-416c-BD93-1CBB2159B26D'
	and rf_UserID = @userID

	if(@@rowcount=0)
	begin 
	
		select top 1 @MedCardTemplate =ValueStr from x_UserSettings   
		where Property ='MedCardNumTemplate'
		and OwnerGUID ='4DF516BE-7A1D-416c-BD93-1CBB2159B26D'
		and rf_UserID = 1

		if(@@rowcount=0)
		begin
				INSERT INTO [dbo].[x_UserSettings]
						([rf_UserID]
						,[OwnerGUID]
						,[DocTypeDefGUID]
						,[rf_SettingTypeID]
						,[Property]
						,[ValueStr]
						)
					VALUES
						(1
						,'4DF516BE-7A1D-416c-BD93-1CBB2159B26D'           
						,'00000000-0000-0000-0000-000000000000'           
						,(select SettingTypeID from x_SettingType where MnemCode='Строковая')
						,'MedCardNumTemplate'
						,'%NUM%')

				set @MedCardTemplate ='%NUM%'
		end
	end

set @num = replace(upper(ltrim(rtrim(@MedCardTemplate))),'%NUM%', @num)
set @num = replace(@num,'%YYYY%',DATEPART(year,@date))
set @num = replace(@num,'%MM%', substring(Convert(varchar,@date,101),1,2))
if(CHARINDEX('%BRANCHCODE%',@num)>0)
begin
	set @num = replace(@num,'%BRANCHCODE%',
		isNull((select V_Code from v_stt_stationarBranch where StationarBranchID = @StationarBranchID),''))
end


commit transaction  GetMedCardNum

set transaction isolation level READ COMMITTED  

Return
END
go

