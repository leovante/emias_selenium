
CREATE PROC [dbo].[ras_GetDocCRC]
	-- id документа
	@DocID int, 

	-- хост документа
	@DocHostID int, 

	-- ссылка на описание документа в ras_DocDescription
	@DocDescriptionID int,
	-- контрольная сумма от cуммы
	-- тут подумать над типом! 
	@CRCDocSumm decimal(18,3) output,
	-- контрольная сумма от количества
	-- тут подумать над типом! 
	@CRCDocCount decimal(18,3) output,
	-- cамая крутая контрольная сумма
	-- тут подумать над типом! 
	@CRC decimal(22,3) output,

	
	@CRCDocSummProvod decimal(18,3) output,
	@CRCDocCountProvod decimal(18,3) output,
	@CRCProvod decimal(22,3) output
as
begin
/* 
	-------------------------------------------------------
	Процедура подсчета контрольной суммы для документов РАСа
	Не завершена, ибо много вопросов и для полноценного использования требует реструктуризации.
	ЧИТАЙТЕ КОД И ПРАВЬТЕ!
	Для использования проверьте содержимое ras_DocDescription 
	-------------------------------------------------------
	Контрольные суммы считаются:
	1) сума документа = сумма позиций документа (не учитывать удаленные)
	2) количество упаковок = сумма количеств позиций(не учитывать удаленные)
	3) контрольная сумма1 = сумма (хеш (код рас) * количество) (не учитывать удаленные) это старая 
	   контрольная сумма1 = сумма (хеш (код рас) ^ хеш(количество)) (не учитывать удаленные) это новая
	-------------------------------------------------------
	Тут никак не получается сделать хранимую ф-цию
	т.к. динамически формируются sql-запросы, 
	которые не удается выполнить из ф-ции =E
	-------------------------------------------------------
	Процедура _специально_ не возвращает строку
	т.к. в этом случае все используют ридер,
	а гораздо безопаснее выходные параметры
	-------------------------------------------------------
	(с) Spirit
*/

	-- переменные для работы 
	DECLARE 

		-- имя обрабатываемой таблицы 
		@DocName varchar(200),

		-- имя ID-шного столбца в документе
		@DocIDName varchar(200),

		-- rf на него
		@rf_DocIDName varchar(200),

		-- имя хостового столбца в документе
		@DocHostIDName varchar(200),

		-- rf на него
		@rf_DocHostIDName varchar(200),

		-- имя таблицы с позициями
		@PositionName varchar(200),

		-- имя таблицы с позициями
		@PositionNamePrice varchar(200),

		-- имя цены у позиции
		@PositionPrice varchar(200),

		-- имя таблицы с позициями
		@PositionRfStatus varchar(200),

		-- ID статуса "удален"
		@PositionDelID int,

		-- ID статуса "проведен"
		@PositionProvodID int,

		-- имя столбца в позициях, по которому считаем сумму
		@PositionSumColumn varchar(200),

		-- имя столбца в позициях, по которому считаем кол-во
		@PositionCountColumn varchar(200),

		-- имя таблицы, которая ссылается на номенклатуру
		@TabRfNomenclature varchar(200),

		-- признак того, что номенклатуру и серию доставать через StoredLS
		@flag_use_storedLS int,

		@DateDoc varchar(150),
		
		-- сюда засовываем команды
		@cmd varchar(8000),
		@cmdProvod varchar(8000),
		@qwery varchar(max),
		@cmd2  nvarchar(4000);


	-- нужна реструктуризация чтобы в ras_DocDescription хранить имя столбца для суммы
	-- ВОПРОС! Какая сумма, c НДС или нет? Сейчас без НДС, т.к. сумма с НДС есть не везде 
	SET @PositionSumColumn = 'Summa';

	-- табличная переменная для списка статусов 
	-- ее тут быть не должно, эти данные нужно поднимать из ras_DocDescription
	DECLARE @tab_status  table 
	(
		-- имя таблицы документа
		tab_name      varchar (200),

		-- ссылка из позиции на таблицу статуса
		rf_tab_status    varchar (200), 

		--поле даты проведения документа
		dateDoc varchar(50),

		-- id статуса позиции "удален"
		id_del_row 	  int,	

		-- id статуса позиции "проведен"
		id_provod_row 	  int,	

		-- признак того, что добираться до номенклатуры через StoredLS
		use_rf_StoredLS  int
		)

	-- здесь в табличную переменную пишем то, чего нам не хватает в ras_DocDescription
	-- исправить после реструктуризации всю эту гадость!

	-- все ok
	insert into @tab_status values ('ras_BillDocument', 'rf_StateID', 'Date_fact', 5, 3, 0)

	-- у этих позиций нет статуса "Удален"
	insert into @tab_status values ('ras_BillEx_Other', 'rf_StateExPosBill_OtherID', 'Date_fact', -1, 3, 0)--2

	-- добираться до номенклатуры через StoredLS
	insert into @tab_status values ('ras_BillExtracted', 'rf_StateExPosBillID', 'Date', 30, 15, 1)

	-- добираться до номенклатуры через StoredLS
	insert into @tab_status values ('ras_BillShift', 'rf_StatePosBillIShiftID', 'Date', 30, 15, 1)	

	-- добираться до номенклатуры через StoredLS
	insert into @tab_status values ('ras_WriteOffArticle', 'rf_StatePositionWriteOffArcticleID', 'Date', 20, 5, 1)

		-- добираться до номенклатуры через StoredLS
	insert into @tab_status values ('ras_WriteOffPurposeList', 'rf_StatePositionWPLID', 'Date', 4, 2, 1)

	-- все ok
	insert into @tab_status values ('ras_Posting', 'rf_StatePositionPostingID', 'Date_fact',  4, 2, 0)

	-- у этих позиций нет статуса "Удален"
	insert into @tab_status values ('ras_Inventarisation', 'rf_StatePosInvID', 'Date', -1, 15, 0)

	-- добираться до номенклатуры через StoredLS
	insert into @tab_status values ('ras_Report', 'rf_StatePositionReportID', 'Date', 30, 15, 1)

	-- добираться до номенклатуры через StoredLS
	insert into @tab_status values ('ras_BillReturnProvider', 'rf_StatePosBillReturnPrID', 'Date', 20, 5, 1)

	-- все ok
	insert into @tab_status values ('ras_BillReturnClient', 'rf_StatePositionBillReturnCLID', 'Date', 20, 5, 1)

	-- добираться до номенклатуры через StoredLS
	insert into @tab_status values ('ras_BillRevaluation', 'rf_StatePositionBillRevaluationID', 'Date', 5, 3, 1)--большой ворос нужны ли они вообше

	-- все ok
	insert into @tab_status values ('ras_ReportToComitent', 'rf_StatePositionReportID', 'Date', 30, 15, 0)--большой ворос нужны ли они вообше

	-- добираться до номенклатуры через StoredLS
	insert into @tab_status values ('ras_Distrib', 'rf_StatePosDistribID', 'Date', 4, 3, 1)

-----------------------------------------------------------------------------------------------

	-- выбираем инфу из DocDescription 
	-- в базе очепятка "NameFileldCount", логичней "PositionNameFieldCount"
	SELECT @DocName = NameTable,  @PositionName = NamePosition, @PositionNamePrice= NamePosition, @PositionCountColumn = NameFileldCount
	from ras_DocDescription where DocDescriptionID = @DocDescriptionID;

	-- вот так некрасиво лепим метаданные, а что делать =(
	SET @DocIDName = @DocName + 'ID'
	SET @DocHostIDName = 'Host' + @DocIDName;
	SET @rf_DocIDName = 'rf_' + @DocIDName
	SET @rf_DocHostIDName = 'rf_' + @DocIDName + 'Host'

	-- ГАДОСТЬ! ссылка из ras_PositionBillEx_Other не подчиняется общим правилам
	-- и не имеет окончания ID, именно поэтому тут этот if
	if (lower(@DocName) = lower('BillEx_Other'))
	begin
		SET @rf_DocIDName = 'rf_BillEx_Other';
		SET @rf_DocHostIDName = 'rf_BillEx_OtherHost';
		SET @PositionPrice = 'PriceBase';
	end
	else
	begin
	SET @PositionPrice = 'Price';
	end



	-- приклеваем префиксы тематики чтобы проще скрипт лепить
	SET	@DocName = 'ras_' + @DocName;
	SET @PositionName = 'ras_' + @PositionName;

	--еще ода заливная рыба
	if (lower(@DocName) = lower('ras_WriteOffPurposeList'))
	begin
		SET @PositionName = 'ras_positionWPL'
	end

	;print 'Table: '+@DocName + ' DocID: ' + convert(varchar, @DocID)

	--еще ода заливная рыба
	if (lower(@DocName) = lower('ras_WriteOffArticle') or lower(@DocName) = lower('ras_WriteOffPurposeList'))
	begin
		SET @PositionSumColumn = '[count]*ras_StoredLS.[Price]'
		set @PositionNamePrice = 'ras_StoredLS'
	end

	-- выясняем, а что у нас соотвествует статусу "Удален"
	SELECT @PositionRfStatus = rf_tab_status, @PositionDelID = id_del_row, @flag_use_storedLS = use_rf_StoredLS, 
	@PositionProvodID = id_provod_row,
	@DateDoc = dateDoc
	from @tab_status
	where lower(tab_name) = lower(@DocName)
	

	-- создаем наш запрос для подсчета

	SET @cmd2 = 'declare @CRCForALLPosition decimal(18,3)' + char(13) + 'set @CRCForALLPosition = '

	SET @cmd = 'Select convert(bigint,sum(convert(bigint,CHECKSUM(*)))) from ' + @PositionName 
		-- условие выборки нашего документа 
	SET @cmd = @cmd + ' where ' + @PositionName + '.' +  @rf_DocIDName + ' = ' + Convert(varchar(20), @DocID) + ' and ' + char(13)
	SET @cmd = @cmd + @PositionName + '.' +  @rf_DocHostIDName + ' = ' + Convert(varchar(20), @DocHostID) + ' and ' + char(13)

	SET @cmdProvod = @cmdProvod + 'where ' + @PositionName + '.' +  @rf_DocIDName + ' = ' + Convert(varchar(20), @DocID) + ' and ' + char(13)
	SET @cmdProvod = @cmdProvod + @PositionName + '.' +  @rf_DocHostIDName + ' = ' + Convert(varchar(20), @DocHostID) + ' and ' + char(13)

	-- условие фильтрования удаленных и проведенных позиций
	SET @cmd = @cmd + @PositionName  + '.' + @PositionRfStatus + ' <> ' + Convert(varchar(20), @PositionDelID) 	

	SET @cmd2 = @cmd2 + '(' + @cmd + ')' + char(13)


	-- тут скалярные ф-ции, которые вычисляют контрольные суммы
	SET @cmd = 'Select Sum(' + @PositionName + '.' + @PositionSumColumn + ') as CRCSumm, 0 as CRCSummProvod, Sum(' + @PositionName + '.' +@PositionCountColumn + ') as CRCCount, 0 as CRCCountProvod,' + char(13)
	SET @cmd = @cmd + 'Sum( distinct convert(bigint, checksum (RTRIM(LTRIM(ras_Nomenclature.Cod_Nom))))) ^ Sum( distinct convert(bigint,checksum (RTRIM(LTRIM(ser.NUM))))) 
	^ convert(bigint, checksum( sum(' + @PositionName + '.' + @PositionCountColumn + '))) ^ convert(bigint, checksum(min('+@DocName  +'.'+ @DateDoc+')))^ convert(bigint, checksum(min('+@DocName  +'.NUM' + '))) 
	^ sum(convert(bigint, checksum(oms_TenderType.GUIDType))) ^ sum(convert(bigint, checksum(ras_TypeDelivery.Code))) ^ sum(convert(bigint, checksum(oms_DeliveryCLSDate.GUIDDel)))
	 ^ convert(bigint,checksum(sum(isnull(' + 'ras_' +  @PositionNamePrice + '.' + @PositionPrice + ',0) )))  ^ convert(bigint,@CRCForALLPosition)  as CRC, 0 as CRCProvod' + char(13)

	SET @cmdProvod = 'Select 0 as CRCSumm, Sum(isnull(' + @PositionName + '.' + @PositionSumColumn + ',0)) as CRCSummProvod, 0 as CRCCount, Sum(isnull(' + @PositionName + '.' +@PositionCountColumn + ',0)) as CRCCountProvod,' + char(13)
	SET @cmdProvod = @cmdProvod + '0 as CRC, Sum( distinct convert(bigint,checksum (RTRIM(LTRIM(ras_Nomenclature.Cod_Nom))))) ^ Sum( distinct convert(bigint, checksum (RTRIM(LTRIM(ser.NUM))))) 
	^ convert(bigint,checksum(sum(isnull(' + @PositionName + '.' + @PositionCountColumn + ',0) ))) ^ convert(bigint, checksum(min('+@DocName  +'.'+ @DateDoc+'))) 
	^ convert(bigint, checksum(min('+@DocName  +'.NUM'+'))) ^ sum(convert(bigint, checksum(oms_TenderType.GUIDType))) ^ sum(convert(bigint, checksum(ras_TypeDelivery.Code))) 
	^ sum(convert(bigint, checksum(oms_DeliveryCLSDate.GUIDDel))) ^ convert(bigint,checksum(sum(isnull(' + 'ras_' +  @PositionNamePrice + '.' +@PositionPrice+ ',0) )))  as CRCProvod' + char(13)


	-- 3 числа пихаем во временную таблицу ##ret_table
	SET @cmd = @cmd + 'from ' + @PositionName + char(13)

	SET @cmdProvod = @cmdProvod + 'from ' + @PositionName + char(13)

		-- 3 числа пихаем во временную таблицу ##ret_table
	SET @cmd = @cmd + 'inner join ' + @DocName  +' on '+ @rf_DocIDName + ' = ' + @DocIDName + char(13)
	SET @cmdProvod = @cmdProvod + 'inner join ' + @DocName  +' on '+ @rf_DocIDName + ' = ' + @DocIDName + char(13)

	-- по умолчанию на номенклатуру ссылаются позиции
	SET @TabRfNomenclature = @PositionName

	-- через гланды лезем за номенклатурой
	-- ссылки на склад прописал жестко 
	if (@flag_use_storedLS = 1)
	begin
		-- не угадали, ссылается склад
		SET @TabRfNomenclature = 'ras_StoredLS';

		SET @cmd = @cmd + 'inner join ras_StoredLS ON ' + @PositionName + '.rf_StoredLSID =  ras_StoredLS.StoredLSID and ' + char(13)
		SET @cmd = @cmd + @PositionName + '.rf_StoredLSIDHost = ras_StoredLS.HostStoredLSID'+ char(13)

		SET @cmdProvod = @cmdProvod + 'inner join ras_StoredLS ON ' + @PositionName + '.rf_StoredLSID =  ras_StoredLS.StoredLSID and ' + char(13)
		SET @cmdProvod = @cmdProvod + @PositionName + '.rf_StoredLSIDHost = ras_StoredLS.HostStoredLSID'+ char(13)
	end

	-- связываем позиции с номенклатурой (ras_Nomenclature), ссылки на номенклатуру прописал жестко 
	-- хорошо бы в DocDescrition запихать эту инфу, но как-то дофига получается
	SET @cmd = @cmd + 'inner join ras_Nomenclature ON ' + @TabRfNomenclature + '.rf_NomenclatureID = ras_Nomenclature.NomenclatureID and '  + char(13)
	SET @cmd = @cmd + @TabRfNomenclature + '.rf_NomenclatureIDHost = ras_Nomenclature.HostNomenclatureID' + char(13)

	SET @cmdProvod  = @cmdProvod + 'inner join ras_Nomenclature ON ' + @TabRfNomenclature + '.rf_NomenclatureID = ras_Nomenclature.NomenclatureID and '  + char(13)
	SET @cmdProvod  = @cmdProvod + @TabRfNomenclature + '.rf_NomenclatureIDHost = ras_Nomenclature.HostNomenclatureID' + char(13)
	
	if (lower(@DocName) = lower('ras_BillEx_Other'))
	begin
		SET @cmd = @cmd + 'inner join ras_Series ser ON ' + @TabRfNomenclature + '.Series = ser.NUM'  + char(13)
					+ 'and ser.rf_NomenclatureID = ras_Nomenclature.NomenclatureID'  + char(13)

		SET @cmdProvod  = @cmdProvod + 'inner join ras_Series ser ON ' + @TabRfNomenclature + '.Series = ser.NUM'  + char(13)
					+ 'and ser.rf_NomenclatureID = ras_Nomenclature.NomenclatureID'  + char(13)
	end
	else
	begin
		SET @cmd = @cmd + 'inner join ras_Series ser ON ' + @TabRfNomenclature + '.rf_SeriesID = ser.SeriesID and '  + char(13)
		SET @cmd = @cmd + @TabRfNomenclature + '.rf_SeriesIDHost = ser.HostSeriesID' + char(13)

		SET @cmdProvod  = @cmdProvod + 'inner join ras_Series ser ON ' + @TabRfNomenclature + '.rf_SeriesID = ser.SeriesID and '  + char(13)
		SET @cmdProvod  = @cmdProvod + @TabRfNomenclature + '.rf_SeriesIDHost = ser.HostSeriesID' + char(13)
	end

	SET @cmd = @cmd + 'inner join oms_TenderType on rf_TenderTypeID = TenderTypeID ' + char(13)
	SET @cmdProvod  = @cmdProvod + 'inner join oms_TenderType on rf_TenderTypeID = TenderTypeID ' + char(13)

		-- через гланды лезем за номенклатурой
	-- ссылки на склад прописал жестко 
	if (@flag_use_storedLS = 1)
	begin
		SET @cmd = @cmd + 'inner join oms_DeliveryCLSDate on ras_StoredLS.rf_DeliveryCLSDateID = DeliveryCLSDateID ' + char(13)
		SET @cmdProvod  = @cmdProvod + 'inner join oms_DeliveryCLSDate on ras_StoredLS.rf_DeliveryCLSDateID = DeliveryCLSDateID ' + char(13)
	end
	else
	begin
		SET @cmd = @cmd + 'inner join oms_DeliveryCLSDate on ' + @PositionName + '.rf_DeliveryCLSDateID = DeliveryCLSDateID ' + char(13)
		SET @cmdProvod  = @cmdProvod + 'inner join oms_DeliveryCLSDate on ' + @PositionName + '.rf_DeliveryCLSDateID = DeliveryCLSDateID ' + char(13)
	end

	if (lower(@DocName) = lower('ras_WriteOffPurposeList'))
	begin
		SET @cmd = @cmd + 'inner join ras_Store on ' + @DocName + '.rf_StoreId = StoreId ' + char(13)
		SET @cmd = @cmd + 'inner join ras_TypeDelivery on rf_TypeDeliveryID = TypeDeliveryID ' + char(13)

		SET @cmdProvod  = @cmdProvod + 'inner join ras_Store on ' + @DocName + '.rf_StoreId = StoreId ' + char(13)
		SET @cmdProvod  = @cmdProvod + 'inner join ras_TypeDelivery on rf_TypeDeliveryID = TypeDeliveryID ' + char(13)
	end
	else
	begin
		SET @cmd = @cmd + 'inner join ras_TypeDelivery on rf_TypeDeliveryID = TypeDeliveryID ' + char(13)
		SET @cmdProvod  = @cmdProvod + 'inner join ras_TypeDelivery on rf_TypeDeliveryID = TypeDeliveryID ' + char(13)
	end



	-- условие выборки нашего документа 
	SET @cmd = @cmd + 'where ' + @PositionName + '.' +  @rf_DocIDName + ' = ' + Convert(varchar(20), @DocID) + ' and ' + char(13)
	SET @cmd = @cmd + @PositionName + '.' +  @rf_DocHostIDName + ' = ' + Convert(varchar(20), @DocHostID) + ' and ' + char(13)

	SET @cmdProvod = @cmdProvod + 'where ' + @PositionName + '.' +  @rf_DocIDName + ' = ' + Convert(varchar(20), @DocID) + ' and ' + char(13)
	SET @cmdProvod = @cmdProvod + @PositionName + '.' +  @rf_DocHostIDName + ' = ' + Convert(varchar(20), @DocHostID) + ' and ' + char(13)


	-- условие фильтрования удаленных и проведенных позиций
	SET @cmd = @cmd + @PositionName  + '.' + @PositionRfStatus + ' <> ' + Convert(varchar(20), @PositionDelID) + char(13) 

	-- условие фильтрования удаленных и проведенных позиций
	SET @cmdProvod = @cmdProvod  + @PositionName  + '.' + @PositionRfStatus + ' <> ' + Convert(varchar(20), @PositionDelID) + char(13) + 'and ' +
					  @PositionName  + '.' + @PositionRfStatus + ' >= ' +  Convert(varchar(20), @PositionProvodID) + char(13)

	-- посмотреть для дебага
	--print @cmd
	set @qwery = 'Select Sum(CRCSumm) as CRCSumm, Sum(CRCSummProvod) as CRCSummProvod, Sum(CRCCount) as CRCCount, Sum(CRCCountProvod) as CRCCountProvod,' + char(13)
	SET @qwery = @qwery + 'Sum(CRC) as CRC, Sum(CRCProvod) as CRCProvod' + char(13)+ ' into ##ret_table from '
	SET @qwery = @qwery +'('+ @cmd +' union '+@cmdProvod+')c'
	SET @qwery = @cmd2 + @qwery
	exec (@qwery)

	-- достаем данные с "того света" в выходные параметры
	SELECT @CRCDocSumm = CRCSumm, @CRCDocCount = CRCCount, @CRC = CRC, 
	@CRCDocSummProvod = CRCSummProvod,
	@CRCDocCountProvod = CRCCountProvod,
	@CRCProvod = CRCProvod
	from ##ret_table

	SET @CRCDocSumm = IsNull(@CRCDocSumm, 0)
	SET @CRCDocCount = IsNull(@CRCDocCount, 0)
	SET @CRC = IsNull(@CRC, 0)
	SET @CRCDocSummProvod = IsNull(@CRCDocSummProvod, 0)
	SET @CRCDocCountProvod  = IsNull(@CRCDocCountProvod, 0)
	SET @CRCProvod= IsNull(@CRCProvod, 0)

	-- грохаем "тот свет"
	SET @cmd = 'if exists (select * from tempdb..sysobjects where id = object_id(N''tempdb..##ret_table'') and xtype = ''U'') drop table  ##ret_table'
	
	exec (@cmd)
end


go

