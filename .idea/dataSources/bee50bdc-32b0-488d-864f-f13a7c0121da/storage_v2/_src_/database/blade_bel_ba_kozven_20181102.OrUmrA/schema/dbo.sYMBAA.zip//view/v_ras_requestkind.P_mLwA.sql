CREATE VIEW [V_ras_RequestKind] AS SELECT 
[hDED].[RequestKindID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name]
FROM [ras_RequestKind] as [hDED]
go

