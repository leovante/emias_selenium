CREATE VIEW [V_oms_pr_ProfFactDS] AS SELECT 
[hDED].[pr_ProfFactDSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_kl_DiseaseTypeID] as [rf_kl_DiseaseTypeID], 
[jT_oms_kl_DiseaseType].[Name] as [SILENT_rf_kl_DiseaseTypeID], 
[hDED].[rf_pr_ProfFactID] as [rf_pr_ProfFactID], 
[hDED].[isMainDS] as [isMainDS], 
[hDED].[Rem] as [Rem]
FROM [oms_pr_ProfFactDS] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_kl_DiseaseType] as [jT_oms_kl_DiseaseType] on [jT_oms_kl_DiseaseType].[kl_DiseaseTypeID] = [hDED].[rf_kl_DiseaseTypeID]
go

