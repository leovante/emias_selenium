CREATE VIEW [V_ras_Provider] AS SELECT 
[hDED].[ProviderID], [hDED].[HostProviderID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_ras_Organisation].[Name] as [V_Organisation], 
[hDED].[rf_SFOID] as [rf_SFOID], 
[jT_oms_SFO].[FO_OGRN] as [SILENT_rf_SFOID], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_OrganisationIDHost] as [rf_OrganisationIDHost], 
[hDED].[Name] as [Name]
FROM [ras_Provider] as [hDED]
INNER JOIN [ras_Organisation] as [jT_ras_Organisation] on [jT_ras_Organisation].[OrganisationID] = [hDED].[rf_OrganisationID] AND  [jT_ras_Organisation].[HostOrganisationID] = [hDED].[rf_OrganisationIDHost]
INNER JOIN [oms_SFO] as [jT_oms_SFO] on [jT_oms_SFO].[SFOID] = [hDED].[rf_SFOID]
go

