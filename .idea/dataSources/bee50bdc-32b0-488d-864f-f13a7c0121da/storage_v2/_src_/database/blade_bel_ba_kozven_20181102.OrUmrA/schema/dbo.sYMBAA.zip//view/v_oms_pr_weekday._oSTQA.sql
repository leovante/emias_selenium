CREATE VIEW [V_oms_pr_WeekDay] AS SELECT 
[hDED].[pr_WeekDayID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[NameShort] as [NameShort]
FROM [oms_pr_WeekDay] as [hDED]
go

