-------------------------------------------------------------------------------------------------------------------------------
---Возвращает список КСГ для набора данных
CREATE FUNCTION [dbo].[GetKSG](
@List_OperDS nvarchar(4000), 
-- Список пар из операций и диагнозов вида разделенных ;Пример :(A16.24.006.001,T95);(A16.24.006.001,T91);(A16.08.029.004,) 
---И операция и диагноз не обязательны, но запятая обязательно
@List_DS nvarchar(4000), 
-- список диагнозов разделенных запятыми Пример 'T95,T91,A00,'
@Sex varchar(1),
--Код пола
-- 2	Женский
-- 1	Мужской
@Age int, 
--Возраст 
@IsAgeDay bit=0, 
-- 1 в случае если возраст в днях
-- 0 возраст в годах
@departmentId int=0,
--ID отделения
@date datetime 
-- дата окончания лечения
)

RETURNS @result TABLE (
    ServicemedicalID int,
	[КСГ] [varchar](50),
	[Наименование КСГ] [varchar](300),
	[Тип] [varchar](100),

	[TariffId] [int] NULL,    
	[KSGValue]   [decimal](38, 2) NULL,  
	[KRRValue] [decimal](38, 2) NULL,
	[Value] [decimal](38, 2) NULL,
	[rf_MKBId] [int] NULL,    
	[Диагноз] [varchar](255)
)
AS
begin
declare @krr decimal(18,2)
set @krr = isnull(dbo.getDepartmentKRR(@departmentId, @date),1)
INSERT INTO @result
select distinct rf_ServicemedicalID,ServicemedicalCode, Servicemedicalname,Info, tariffID, isnull(value1,1),@krr ,isnull(value1,1)*@krr, 
rf_MKBID,[Диагноз]
from (
select    isnull(ksg.ServicemedicalCode, Qw1.ServicemedicalCode)ServicemedicalCode, 
isnull(ksg.Servicemedicalname,Qw1.Servicemedicalname) Servicemedicalname, 
isnull(( ksg.Info+'('+
         case when Qw.Oper is not null and qw.Oper<>'' then 'операция: '+Qw.Oper
               else '' end+   case when Qw.DSQ is not null then ' диагноз: '+Qw.DSQ
               else '' end+ ')'), Qw1.Info) as Info, isnull( ksg.ServiceMedicalId,Qw1.ServiceMedicalId) as ServiceMedicalId, 
              MKBID rf_MKBID,
oms_mkb.name [Диагноз]
         from oms_ExpertKSG
			inner join oms_ServiceMedical on oms_ServiceMedical.ServiceMedicalId = rf_OperationServiceMedicalID
			inner join oms_ServiceMedical ksg on ksg.ServiceMedicalId = rf_KSGServiceMedicalID
			inner join oms_MKB on MKBID = rf_MKBID
			inner join oms_kl_SEX on kl_SExID = oms_ExpertKSG.rf_kl_SEXID
			right join (
					select  Substring (Item,charIndex('(',Item)+1, charIndex(',',Item)-charIndex('(',Item)-1) as Oper,
						Substring (Item,charIndex(',',Item)+1,charIndex(')',Item)-charIndex(',',Item)-1 ) as DsQ
						from dbo.TableFromString(@List_OperDS,';')
					union 
					select '' ,Item  from dbo.TableFromString(@List_DS,',')	
            ) Qw on ltrim(rtrim(qw.Oper)) =ltrim(rtrim(oms_ServiceMedical.ServiceMedicalCode)) and  ( ltrim(rtrim(DS))= ltrim(rtrim(DSQ)) )             
            and   (Code=@Sex or kl_SEXID=0)  
            and  (Year2=0  or (@Age>=Year1 and @Age<=Year2 and IsAgeDay=@IsAgeDay)
                           or (@IsAgeDay=1 and Year1=0 and   IsAgeDay=0 )
                           or (@IsAgeDay=1 and IsAgeDay=1 and @Age>=255 and Year1=28)
                  )
                           
            left  join (           
			  select  oper.ServicemedicalCode as Oper, ksg.ServicemedicalCode,ksg.Servicemedicalname, ksg.Info+'(операция: '+oper.ServicemedicalCode +')' as Info,ksg.ServicemedicalId, rf_MKBID, oms_MKB.Name as [Диагноз] from oms_ExpertKSG
			  	inner join oms_ServiceMedical oper on oper.ServiceMedicalId = rf_OperationServiceMedicalID
			  	inner join oms_ServiceMedical ksg on ksg.ServiceMedicalId = rf_KSGServiceMedicalID
			  	inner join oms_kl_SEX on kl_SExID = oms_ExpertKSG.rf_kl_SEXID
			  		inner join oms_MKB on MKBID = rf_MKBID
				 where rf_MKBID=0 and rf_OperationServiceMedicalID>0 and ExpertKSGId>0			
				   and   (Code=@Sex or kl_SEXID=0)  
            and  (Year2=0  or (@Age>=Year1 and @Age<=Year2 and IsAgeDay=@IsAgeDay)
                           or (@IsAgeDay=1 and Year1=0 and   IsAgeDay=0 )
                           or (@IsAgeDay=1 and IsAgeDay=1 and @Age>=255 and Year1=28))
          ) Qw1  on ExpertKSGID is null and Qw1.Oper = qw.Oper and Qw.Oper<>''                                                           

 ) ksg 
  
 left join oms_Tariff on ksg.ServicemedicalID=oms_Tariff.rf_ServicemedicalID and oms_Tariff.date_b<=@date and oms_Tariff.date_e>@date
where ServicemedicalId>0
/*if(select count(distinct [КСГ]) from @result where [КСГ] in ('15','3') )=2 delete from @result where [КСГ]='15'
if(select count(distinct [КСГ]) from @result where [КСГ] in ('15','4') )=2 delete from @result where [КСГ]='15'    
if(select count(distinct [КСГ]) from @result where [КСГ] in ('11','12'))=2 delete from @result where [КСГ]='12'    
if(select count(distinct [КСГ]) from @result where [КСГ] in ('12','4') )=2 delete from @result where [КСГ]='12'    
if(select count(distinct [КСГ]) from @result where [КСГ] in ('12','3') )=2 delete from @result where [КСГ]='12'    
*/
RETURN 
END
go

