CREATE VIEW [V_oms_pr_InfoNote] AS SELECT 
[hDED].[pr_InfoNoteID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_pr_ProfTypeID] as [rf_pr_ProfTypeID], 
[hDED].[rf_pr_InfoTypeID] as [rf_pr_InfoTypeID], 
[hDED].[rf_pr_ReestrID] as [rf_pr_ReestrID], 
[hDED].[rf_pr_PersonID] as [rf_pr_PersonID], 
[hDED].[rf_pr_ProfPlanID] as [rf_pr_ProfPlanID], 
[jT_oms_pr_ProfPlan].[ID_PAC] as [SILENT_rf_pr_ProfPlanID], 
[hDED].[Info_Date] as [Info_Date], 
[hDED].[ID_PAC] as [ID_PAC], 
[hDED].[isActual] as [isActual], 
[hDED].[Reject_DATE] as [Reject_DATE], 
[hDED].[Question_Date] as [Question_Date], 
[hDED].[Info_Type] as [Info_Type], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [oms_pr_InfoNote] as [hDED]
INNER JOIN [oms_pr_ProfPlan] as [jT_oms_pr_ProfPlan] on [jT_oms_pr_ProfPlan].[pr_ProfPlanID] = [hDED].[rf_pr_ProfPlanID]
go

