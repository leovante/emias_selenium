CREATE VIEW [V_rls_Okpd_Prep_v1] AS SELECT 
[hDED].[Okpd_Prep_v1ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PrepUID] as [rf_PrepUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[rf_Okpd_v1UID] as [rf_Okpd_v1UID], 
[hDED].[rf_Okpd_Link_v1UID] as [rf_Okpd_Link_v1UID], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Okpd_Prep_v1] as [hDED]
go

