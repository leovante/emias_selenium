CREATE VIEW [V_ras_SeriesCertificateType] AS SELECT 
[hDED].[SeriesCertificateTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [ras_SeriesCertificateType] as [hDED]
go

