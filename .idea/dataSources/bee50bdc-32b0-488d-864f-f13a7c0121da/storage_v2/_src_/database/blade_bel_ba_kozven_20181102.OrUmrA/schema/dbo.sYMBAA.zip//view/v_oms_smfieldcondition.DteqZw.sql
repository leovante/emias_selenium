CREATE VIEW [V_oms_SMFieldCondition] AS SELECT 
[hDED].[SMFieldConditionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[hDED].[MainTable] as [MainTable], 
[hDED].[MainField] as [MainField], 
[hDED].[RefTable] as [RefTable], 
[hDED].[RefField] as [RefField], 
[hDED].[Query] as [Query], 
[hDED].[Mask] as [Mask], 
[hDED].[IsExist] as [IsExist], 
[hDED].[IsActual] as [IsActual], 
[hDED].[FieldActual] as [FieldActual], 
[hDED].[Rem] as [Rem], 
[hDED].[Code] as [Code], 
[hDED].[GuidSMFieldCondition] as [GuidSMFieldCondition]
FROM [oms_SMFieldCondition] as [hDED]
go

