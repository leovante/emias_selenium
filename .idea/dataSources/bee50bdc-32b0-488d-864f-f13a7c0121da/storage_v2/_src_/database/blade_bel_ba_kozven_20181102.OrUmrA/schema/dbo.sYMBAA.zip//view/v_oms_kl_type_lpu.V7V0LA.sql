CREATE VIEW [V_oms_kl_Type_LPU] AS SELECT 
[hDED].[kl_Type_LPUID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Type_LPU] as [Type_LPU], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_Type_LPU] as [hDED]
go

