CREATE VIEW [V_oms_pr_ProcRes] AS SELECT 
[hDED].[pr_ProcResID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [oms_pr_ProcRes] as [hDED]
go

