CREATE VIEW [V_ras_SubStore] AS SELECT 
[hDED].[SubStoreID], [hDED].[HostSubStoreID], [hDED].[x_Edition], [hDED].[x_Status], 
(ISNULL((SELECT
   TOP 1
   ras_Zone.Name + '-' +
   CASE WHEN ras_Rack.Name < 10 THEN '0'+convert(varchar,ras_Rack.Name) ELSE convert(varchar,ras_Rack.Name) END  + '-' +
   CASE WHEN ras_Shelf.Name < 10 THEN '0'+convert(varchar,ras_Shelf.Name) ELSE convert(varchar,ras_Shelf.Name) END  + '-' +
   CASE WHEN rss.Name < 10 THEN '0'+convert(varchar,rss.Name) ELSE convert(varchar,rss.Name) END
  FROM
   ras_Zone INNER JOIN ras_Rack ON ras_Rack.rf_ZoneID = ras_Zone.ZoneID INNER JOIN ras_Shelf ON ras_Shelf.rf_RackID = ras_Rack.RackID INNER JOIN ras_SubStore rss ON  rss.rf_ShelfID = ras_Shelf.ShelfID  WHERE rss.SubStoreID = hDED.SubStoreID
 ),'') 
) as [V_Name], 
ISNULL ((SELECT  SUM(Count) AS Count FROM    ras_StoredLS AS st WHERE (st.rf_SubStoreID = hDED.SubStoreID)), 0) as [Count_UP], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_StoreIDHost] as [rf_StoreIDHost], 
[hDED].[rf_ShelfID] as [rf_ShelfID], 
[hDED].[rf_ShelfIDHost] as [rf_ShelfIDHost], 
[hDED].[Name] as [Name], 
[hDED].[Count_UP_Max] as [Count_UP_Max], 
[hDED].[Barcode] as [Barcode]
FROM [ras_SubStore] as [hDED]
go

