CREATE VIEW [V_rls_OKPD2] AS SELECT 
[hDED].[OKPD2ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[CodeRls] as [CodeRls]
FROM [rls_OKPD2] as [hDED]
go

