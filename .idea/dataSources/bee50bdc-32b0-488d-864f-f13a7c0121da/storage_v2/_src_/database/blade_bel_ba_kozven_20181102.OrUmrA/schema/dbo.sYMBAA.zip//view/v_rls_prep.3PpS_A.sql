CREATE VIEW [V_rls_Prep] AS SELECT 
[hDED].[PrepID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ActUnitsUID] as [rf_ActUnitsUID], 
[hDED].[rf_ClsDrugFormsUID] as [rf_ClsDrugFormsUID], 
[hDED].[rf_ClsNtfrUID] as [rf_ClsNtfrUID], 
[hDED].[rf_ConcenUnitsUID] as [rf_ConcenUnitsUID], 
[hDED].[rf_DrugFormCharsUID] as [rf_DrugFormCharsUID], 
[hDED].[rf_LatinNamesUID] as [rf_LatinNamesUID], 
[hDED].[rf_SizeUnitsUID] as [rf_SizeUnitsUID], 
[hDED].[rf_MassUnitsUID] as [rf_MassUnitsUID], 
[hDED].[rf_TradeNamesUID] as [rf_TradeNamesUID], 
[hDED].[rf_FirmsUID] as [rf_FirmsUID], 
[hDED].[rf_RegCertUID] as [rf_RegCertUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[DfSize] as [DfSize], 
[hDED].[DrugDose] as [DrugDose], 
[hDED].[NoRecipe] as [NoRecipe], 
[hDED].[ListType] as [ListType], 
[hDED].[RegEnd] as [RegEnd], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code], 
[hDED].[DfAct] as [DfAct], 
[hDED].[DFMass] as [DFMass], 
[hDED].[DfConc] as [DfConc]
FROM [rls_Prep] as [hDED]
go

