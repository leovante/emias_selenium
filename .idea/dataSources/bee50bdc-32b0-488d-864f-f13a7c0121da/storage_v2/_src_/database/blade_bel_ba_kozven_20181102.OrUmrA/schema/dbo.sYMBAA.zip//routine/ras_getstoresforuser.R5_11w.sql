
CREATE FUNCTION [dbo].[RAS_GetStoresForUser](@userID int, @checkEnableWriteOff bit)
returns table
as 
return
(
	select StoreID from ras_store
	where exists 
	(
		SELECT TOP 1 '�����������' from ras_UserStoreVisible 
			WHERE rf_StoreID = ras_store.StoreID  AND
			rf_UserID = @userID and ((IsEnabledSelectInWriteOff = 1 and @checkEnableWriteOff = 1) or @checkEnableWriteOff = 0) 
		union all 
		SELECT TOP 1 '�����'
		where @userID = 1 or 
		(
			select COUNT(*) from x_UserRole where UserID = @userID and RoleID = 
				(select RoleID from x_Role where [GUID] = '11111111-1111-1111-1111-111111111111')
		) = 1
	)
	and StoreID > 0
)
go

