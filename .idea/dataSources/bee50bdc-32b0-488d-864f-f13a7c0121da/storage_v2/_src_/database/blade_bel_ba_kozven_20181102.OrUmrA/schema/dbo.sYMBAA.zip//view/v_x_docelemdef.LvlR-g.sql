CREATE view [dbo].[V_x_DocElemDef] as
select [DocElemDefID], [x_Edition], [x_Status], [DocTypeDefID], [Name], [Caption], [Description], [ElemType], [ValueType], [ValueSize]
,[ValueScale], [FieldName], [LinkedDocTypeDefID], [LinkedDocElemDefID],[SRVDocElemDefID], [GUID], [Pos], [OutputFormat], [Flags], [CategoryName],
[TagName],[MnemCode],
[SqlDataType] as [ElementSqlTypeNameVSV],
[SqlDataType] as [SqlDataType],
(select Code from [x_ElemType] where ElemTypeID = ElemType) as [ElemTypeVSV]
from [x_DocElemDef]
go

