CREATE VIEW [V_oms_SMReestrState] AS SELECT 
[hDED].[SMReestrStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [oms_SMReestrState] as [hDED]
go

