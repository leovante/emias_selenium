
CREATE PROC [dbo].[ras_SetDocumentJournalProtocol]
        @DocID int,
        @DocHostID int,
        @docGuid varchar(150),
        @DocDescriptionID int,
		@num varchar(150),
        @organisation int,
        @state varchar(150),
        @dateDoc datetime,
        @typPost varchar(150)
as
DECLARE --вычисление контр. сумм
		@RC int,
        @CRCDocSumm decimal(24,6),
        @CRCDocCount decimal(24,6),
        @CRC decimal(24,6),
        @CRCDocSummProvod decimal(24,6),
        @CRCDocCountProvod decimal(24,6),
        @CRCProvod decimal(24,6)
        
EXECUTE @RC = [dbo].[ras_GetDocCRC] 
              @DocID
              ,@DocHostID
              ,@DocDescriptionID
              ,@CRCDocSumm OUTPUT
              ,@CRCDocCount OUTPUT
              ,@CRC OUTPUT
              ,@CRCDocSummProvod OUTPUT
              ,@CRCDocCountProvod OUTPUT
              ,@CRCProvod OUTPUT

EXECUTE ras_RegisterDocumentJournal @docGuid,
            @DocDescriptionID,
            @docID,
            @num,
            @organisation,
            @CRCDocCount,
            @CRCDocSumm,
            @state,
            @CRC,
            @dateDoc,
            @typPost

go

