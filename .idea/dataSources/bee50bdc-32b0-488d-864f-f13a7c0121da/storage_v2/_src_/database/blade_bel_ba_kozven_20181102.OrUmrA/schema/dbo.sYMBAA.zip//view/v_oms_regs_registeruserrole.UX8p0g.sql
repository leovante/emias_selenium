CREATE VIEW [V_oms_regs_RegisterUserRole] AS SELECT 
[hDED].[regs_RegisterUserRoleID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RegisterTypeID] as [rf_RegisterTypeID], 
[hDED].[rf_UserDoctorID] as [rf_UserDoctorID], 
[hDED].[rf_RoleGuid] as [rf_RoleGuid]
FROM [oms_regs_RegisterUserRole] as [hDED]
go

