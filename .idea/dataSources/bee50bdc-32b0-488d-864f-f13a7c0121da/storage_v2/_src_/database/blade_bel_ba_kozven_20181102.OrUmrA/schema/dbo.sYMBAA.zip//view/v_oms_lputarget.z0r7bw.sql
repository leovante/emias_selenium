CREATE VIEW [V_oms_LPUTarget] AS SELECT 
[hDED].[LPUTargetID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_Department].[DepartmentNAME] as [V_DepartmentNAME], 
[jT_oms_LPU].[MCOD] as [V_MCOD], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_TariffTargetID] as [rf_TariffTargetID], 
[jT_oms_TariffTarget].[TariffTargetCode] as [SILENT_rf_TariffTargetID], 
[hDED].[Rem] as [Rem], 
[hDED].[GUID] as [GUID], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_LPUTarget] as [hDED]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [oms_TariffTarget] as [jT_oms_TariffTarget] on [jT_oms_TariffTarget].[TariffTargetID] = [hDED].[rf_TariffTargetID]
go

