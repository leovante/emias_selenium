CREATE VIEW [V_oms_ErrorRecipe] AS SELECT 
[hDED].[ErrorRecipeID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_ReestrExpert].[V_NAME] as [V_ExpName], 
[jT_oms_Error].[Name] as [V_NAME], 
[jT_oms_Error].[KOD] as [V_KOD], 
[jT_oms_Recipe].[Series_Recipe] as [V_Series_Recipe], 
[jT_oms_Recipe].[Num_Recipe] as [V_Num_Recipe], 
[hDED].[rf_ErrorID] as [rf_ErrorID], 
[hDED].[rf_RecipeID] as [rf_RecipeID], 
[hDED].[rf_ReestrExpertID] as [rf_ReestrExpertID], 
[hDED].[Rem] as [Rem]
FROM [oms_ErrorRecipe] as [hDED]
INNER JOIN [V_oms_ReestrExpert] as [jT_oms_ReestrExpert] on [jT_oms_ReestrExpert].[ReestrExpertID] = [hDED].[rf_ReestrExpertID]
INNER JOIN [oms_Error] as [jT_oms_Error] on [jT_oms_Error].[ErrorID] = [hDED].[rf_ErrorID]
INNER JOIN [oms_Recipe] as [jT_oms_Recipe] on [jT_oms_Recipe].[RecipeID] = [hDED].[rf_RecipeID]
go

