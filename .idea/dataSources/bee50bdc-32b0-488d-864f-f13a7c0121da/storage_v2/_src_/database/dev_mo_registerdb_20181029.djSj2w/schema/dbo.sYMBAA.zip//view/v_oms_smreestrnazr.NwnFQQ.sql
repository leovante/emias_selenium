CREATE VIEW [V_oms_SMReestrNAZR] AS SELECT 
[hDED].[SMReestrNAZRID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[NAZR] as [NAZR]
FROM [oms_SMReestrNAZR] as [hDED]
go

