CREATE VIEW [V_regs_FormLabel] AS SELECT 
[hDED].[FormLabelID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FormID] as [rf_FormID], 
[hDED].[rf_LabelID] as [rf_LabelID], 
[hDED].[ElementId] as [ElementId]
FROM [regs_FormLabel] as [hDED]
go

