CREATE FUNCTION [GetSelfHost]()
RETURNS int AS
BEGIN
	DECLARE @hostID int set @hostID =-1 RETURN (@hostID)
END
go

