CREATE VIEW [V_oms_in_ReestrState] AS SELECT 
[hDED].[in_ReestrStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_in_LSID] as [rf_in_LSID], 
[jT_oms_in_LS].[NAME_MED] as [SILENT_rf_in_LSID], 
[hDED].[rf_in_StateID] as [rf_in_StateID], 
[jT_oms_in_State].[Name] as [SILENT_rf_in_StateID], 
[hDED].[Ver] as [Ver], 
[hDED].[Rem] as [Rem], 
[hDED].[Date] as [Date]
FROM [oms_in_ReestrState] as [hDED]
INNER JOIN [oms_in_LS] as [jT_oms_in_LS] on [jT_oms_in_LS].[in_LSID] = [hDED].[rf_in_LSID]
INNER JOIN [oms_in_State] as [jT_oms_in_State] on [jT_oms_in_State].[in_StateID] = [hDED].[rf_in_StateID]
go

