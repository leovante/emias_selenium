CREATE VIEW [V_regs_Form] AS SELECT 
[hDED].[FormID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RegisterID] as [rf_RegisterID], 
[hDED].[Name] as [Name], 
[hDED].[Version] as [Version], 
[hDED].[UGuid] as [UGuid], 
[hDED].[IsSingle] as [IsSingle]
FROM [regs_Form] as [hDED]
go

