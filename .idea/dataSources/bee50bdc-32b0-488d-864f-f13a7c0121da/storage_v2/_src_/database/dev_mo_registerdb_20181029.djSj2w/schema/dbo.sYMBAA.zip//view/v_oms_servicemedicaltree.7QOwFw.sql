CREATE VIEW [V_oms_ServiceMedicalTree] AS SELECT 
[hDED].[ServiceMedicalTreeID], [hDED].[x_Edition], [hDED].[x_Status], 
(SELECT ServiceMedicalCode FROM oms_ServiceMedical WHERE ServiceMedicalID = [hded].rf_ChildServiceMedicalID) as [V_ChildServiceMedicalCode], 
(SELECT ServiceMedicalCode FROM oms_ServiceMedical WHERE ServiceMedicalID = [hded].rf_RootServiceMedicalID) as [V_RootServiceMedicalCode], 
[hDED].[rf_ChildServiceMedicalID] as [rf_ChildServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ChildServiceMedicalID], 
[hDED].[rf_RootServiceMedicalID] as [rf_RootServiceMedicalID], 
[jT_oms_ServiceMedical1].[ServiceMedicalName] as [SILENT_rf_RootServiceMedicalID], 
[hDED].[GUIDTree] as [GUIDTree], 
[hDED].[Flags] as [Flags]
FROM [oms_ServiceMedicalTree] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ChildServiceMedicalID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical1] on [jT_oms_ServiceMedical1].[ServiceMedicalID] = [hDED].[rf_RootServiceMedicalID]
go

