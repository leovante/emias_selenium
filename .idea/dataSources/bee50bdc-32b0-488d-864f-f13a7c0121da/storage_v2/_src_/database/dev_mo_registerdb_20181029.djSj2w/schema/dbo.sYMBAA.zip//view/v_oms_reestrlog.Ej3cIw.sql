CREATE VIEW [V_oms_ReestrLog] AS SELECT 
[hDED].[ReestrLogID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_LoadErrorsID] as [rf_LoadErrorsID], 
[hDED].[FileName] as [FileName], 
[hDED].[CorrectRecNum] as [CorrectRecNum], 
[hDED].[UnCorrectRecNum] as [UnCorrectRecNum], 
[hDED].[AllRecNum] as [AllRecNum], 
[hDED].[SendGUID] as [SendGUID], 
[hDED].[HostGUID] as [HostGUID], 
[hDED].[PrevSendGuid] as [PrevSendGuid]
FROM [oms_ReestrLog] as [hDED]
go

