CREATE VIEW [V_regs_RegisterUserRole] AS SELECT 
[hDED].[RegisterUserRoleID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RegisterTypeID] as [rf_RegisterTypeID], 
[hDED].[rf_UserDoctorID] as [rf_UserDoctorID], 
[hDED].[rf_RoleGuid] as [rf_RoleGuid]
FROM [regs_RegisterUserRole] as [hDED]
go

