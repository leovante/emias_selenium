CREATE VIEW [V_rls_Ident_Wind_Str] AS SELECT 
[hDED].[Ident_Wind_StrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_NomenUID] as [rf_NomenUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[IWid] as [IWid], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Ident_Wind_Str] as [hDED]
go

