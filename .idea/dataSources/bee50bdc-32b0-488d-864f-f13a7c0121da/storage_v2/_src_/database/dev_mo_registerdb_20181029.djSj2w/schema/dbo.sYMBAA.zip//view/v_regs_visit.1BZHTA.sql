CREATE VIEW [V_regs_Visit] AS SELECT 
[hDED].[VisitID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_UserDoctorID] as [rf_UserDoctorID], 
[hDED].[rf_RegisterMemberID] as [rf_RegisterMemberID], 
[hDED].[rf_RegisterSpecificID] as [rf_RegisterSpecificID], 
[hDED].[Date] as [Date], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Data] as [Data]
FROM [regs_Visit] as [hDED]
go

