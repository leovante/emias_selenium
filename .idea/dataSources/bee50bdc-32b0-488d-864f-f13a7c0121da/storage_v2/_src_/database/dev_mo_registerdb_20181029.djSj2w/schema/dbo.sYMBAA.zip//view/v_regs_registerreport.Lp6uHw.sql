CREATE VIEW [V_regs_RegisterReport] AS SELECT 
[hDED].[RegisterReportID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RegisterID] as [rf_RegisterID], 
[hDED].[rf_ReportGuid] as [rf_ReportGuid]
FROM [regs_RegisterReport] as [hDED]
go

