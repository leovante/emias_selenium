CREATE VIEW [V_oms_SM_PRVD] AS SELECT 
[hDED].[SM_PRVDID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_PRVD].[NAME] as [V_PRVD], 
[hDED].[rf_PRVDID] as [rf_PRVDID], 
[hDED].[Note] as [Note]
FROM [oms_SM_PRVD] as [hDED]
INNER JOIN [oms_PRVD] as [jT_oms_PRVD] on [jT_oms_PRVD].[PRVDID] = [hDED].[rf_PRVDID]
go

