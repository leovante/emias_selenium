CREATE VIEW [V_oms_SMCollectList] AS SELECT 
[hDED].[SMCollectListID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[hDED].[rf_SMCollectID] as [rf_SMCollectID], 
[hDED].[SMCollectListRem] as [SMCollectListRem]
FROM [oms_SMCollectList] as [hDED]
go

