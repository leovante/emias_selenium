CREATE VIEW [V_regs_Medication] AS SELECT 
[hDED].[MedicationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MNNameID] as [rf_MNNameID], 
[hDED].[rf_LFID] as [rf_LFID], 
[hDED].[rf_DLSID] as [rf_DLSID], 
[hDED].[rf_LSID] as [rf_LSID], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[hDED].[rf_RegisterMemberID] as [rf_RegisterMemberID], 
[hDED].[BeginDate] as [BeginDate], 
[hDED].[EndDate] as [EndDate], 
[hDED].[MedicalExpertBoard] as [MedicalExpertBoard], 
[hDED].[OneTimeAmount] as [OneTimeAmount], 
[hDED].[Amount] as [Amount], 
[hDED].[Route] as [Route]
FROM [regs_Medication] as [hDED]
go

