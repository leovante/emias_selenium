CREATE VIEW [V_oms_hs_DepartmentBed] AS SELECT 
[hDED].[hs_DepartmentBedID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_hs_LpuDepartmentID] as [rf_hs_LpuDepartmentID], 
[jT_oms_hs_LpuDepartment].[Name] as [SILENT_rf_hs_LpuDepartmentID], 
[hDED].[rf_ProfileID] as [rf_ProfileID], 
[hDED].[Count] as [Count], 
[hDED].[ProfilBed] as [ProfilBed], 
[hDED].[Active] as [Active], 
[hDED].[Flag] as [Flag], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[PlaneCount] as [PlaneCount], 
[hDED].[LastUserID] as [LastUserID]
FROM [oms_hs_DepartmentBed] as [hDED]
INNER JOIN [oms_hs_LpuDepartment] as [jT_oms_hs_LpuDepartment] on [jT_oms_hs_LpuDepartment].[hs_LpuDepartmentID] = [hDED].[rf_hs_LpuDepartmentID]
go

