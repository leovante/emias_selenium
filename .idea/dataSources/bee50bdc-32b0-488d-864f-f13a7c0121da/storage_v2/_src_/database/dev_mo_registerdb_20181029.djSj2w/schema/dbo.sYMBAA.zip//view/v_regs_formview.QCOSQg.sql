CREATE VIEW [V_regs_FormView] AS SELECT 
[hDED].[FormViewID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FormID] as [rf_FormID], 
[hDED].[Content] as [Content], 
[hDED].[Type] as [Type]
FROM [regs_FormView] as [hDED]
go

