CREATE VIEW [V_regs_Plans] AS SELECT 
[hDED].[PlansID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_RegisterID] as [rf_RegisterID], 
[hDED].[Targets] as [Targets]
FROM [regs_Plans] as [hDED]
go

