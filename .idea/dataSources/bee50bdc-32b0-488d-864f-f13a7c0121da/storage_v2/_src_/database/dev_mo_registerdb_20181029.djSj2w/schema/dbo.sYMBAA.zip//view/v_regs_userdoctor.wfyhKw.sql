CREATE VIEW [V_regs_UserDoctor] AS SELECT 
[hDED].[UserDoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DOCTORID] as [rf_DOCTORID], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_UserGUID] as [rf_UserGUID]
FROM [regs_UserDoctor] as [hDED]
go

