CREATE VIEW [V_oms_GroupIMN] AS SELECT 
[hDED].[GroupIMNID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_GroupIMN].[GuidGroupIMN] as [V_GuidGroupIMN], 
[jT_oms_GroupIMN].[Name] as [V_Name], 
[hDED].[rf_MainGroupIMNID] as [rf_MainGroupIMNID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[GuidGroupIMN] as [GuidGroupIMN]
FROM [oms_GroupIMN] as [hDED]
INNER JOIN [oms_GroupIMN] as [jT_oms_GroupIMN] on [jT_oms_GroupIMN].[GroupIMNID] = [hDED].[rf_MainGroupIMNID]
go

