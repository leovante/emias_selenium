CREATE VIEW [V_oms_pr_ResourcePlan] AS SELECT 
[hDED].[pr_ResourcePlanID], [hDED].[x_Edition], [hDED].[x_Status], 
(case when DateBegin=DateEnd then convert(varchar,DateBegin,104)
when Year(DateBegin)=Year(DateEnd) and datepart(day,DateBegin)=1 and datepart(day,dateadd(day,1,DateEnd))=1 then 
	case when Month(DateBegin)=Month(DateEnd) then right(convert(varchar,DateBegin,104),7)
	when Month(DateBegin)=1 and Month(DateEnd)=3 then 'I кв.'+convert(varchar,Year(DateBegin))
	when Month(DateBegin)=4 and Month(DateEnd)=6 then 'II кв.'+convert(varchar,Year(DateBegin))
	when Month(DateBegin)=7 and Month(DateEnd)=9 then 'III кв.'+convert(varchar,Year(DateBegin))
	when Month(DateBegin)=10 and Month(DateEnd)=12 then 'IV кв.'+convert(varchar,Year(DateBegin))
	when Month(DateBegin)=1 and Month(DateEnd)=6 then '1 полугодие '+convert(varchar,Year(DateBegin))
	when Month(DateBegin)=7 and Month(DateEnd)=12 then '2 полугодие '+convert(varchar,Year(DateBegin))
	when Month(DateBegin)=1 and Month(DateEnd)=12 then convert(varchar,Year(DateBegin))+' год'
	else convert(varchar,DateBegin,104)+'-'+convert(varchar,DateEnd,104) end
	else convert(varchar,DateBegin,104)+'-'+convert(varchar,DateEnd,104) end) as [V_Period], 
[jT_oms_pr_LPU].[V_M_NAMES] as [V_V_M_NAMES], 
[jT_oms_pr_ProfType].[Name] as [V_NameType], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_pr_ProfTypeID] as [rf_pr_ProfTypeID], 
[hDED].[rf_pr_LPUID] as [rf_pr_LPUID], 
[hDED].[Count] as [Count], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [oms_pr_ResourcePlan] as [hDED]
INNER JOIN [V_oms_pr_LPU] as [jT_oms_pr_LPU] on [jT_oms_pr_LPU].[pr_LPUID] = [hDED].[rf_pr_LPUID]
INNER JOIN [oms_pr_ProfType] as [jT_oms_pr_ProfType] on [jT_oms_pr_ProfType].[pr_ProfTypeID] = [hDED].[rf_pr_ProfTypeID]
go

