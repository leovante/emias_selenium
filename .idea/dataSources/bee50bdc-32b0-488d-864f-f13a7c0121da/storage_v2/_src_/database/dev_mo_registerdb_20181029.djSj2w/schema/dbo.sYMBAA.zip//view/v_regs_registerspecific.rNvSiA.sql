CREATE VIEW [V_regs_RegisterSpecific] AS SELECT 
[hDED].[RegisterSpecificID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RegisterID] as [rf_RegisterID], 
[hDED].[SetDataView] as [SetDataView], 
[hDED].[DislpayDataView] as [DislpayDataView], 
[hDED].[Uguid] as [Uguid]
FROM [regs_RegisterSpecific] as [hDED]
go

