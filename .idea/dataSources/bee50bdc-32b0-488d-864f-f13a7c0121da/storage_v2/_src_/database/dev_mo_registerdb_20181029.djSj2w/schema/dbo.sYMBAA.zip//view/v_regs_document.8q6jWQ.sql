CREATE VIEW [V_regs_Document] AS SELECT 
[hDED].[DocumentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_CreatorID] as [rf_CreatorID], 
[hDED].[rf_AuthorID] as [rf_AuthorID], 
[hDED].[rf_RegisterMemberID] as [rf_RegisterMemberID], 
[hDED].[rf_FormID] as [rf_FormID], 
[hDED].[Created] as [Created], 
[hDED].[Updated] as [Updated], 
[hDED].[Data] as [Data]
FROM [regs_Document] as [hDED]
go

