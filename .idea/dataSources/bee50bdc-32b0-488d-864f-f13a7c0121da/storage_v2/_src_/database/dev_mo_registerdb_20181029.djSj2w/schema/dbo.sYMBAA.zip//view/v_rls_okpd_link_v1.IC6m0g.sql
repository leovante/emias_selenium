CREATE VIEW [V_rls_Okpd_Link_v1] AS SELECT 
[hDED].[Okpd_Link_v1ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [rls_Okpd_Link_v1] as [hDED]
go

