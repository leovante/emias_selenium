CREATE VIEW [V_oms_ProtokolDelivery] AS SELECT 
[hDED].[ProtokolDeliveryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_APUID] as [rf_APUID], 
[jT_oms_APU].[P_NAMES] as [SILENT_rf_APUID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID], 
[hDED].[rf_ProtokolPosID] as [rf_ProtokolPosID], 
[jT_oms_ProtokolPos].[rf_LSID] as [SILENT_rf_ProtokolPosID], 
[hDED].[rf_PurchaseRequisitionID] as [rf_PurchaseRequisitionID], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Count] as [Count], 
[hDED].[UnitGuid] as [UnitGuid], 
[hDED].[GuidProtokolD] as [GuidProtokolD]
FROM [oms_ProtokolDelivery] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_APU] as [jT_oms_APU] on [jT_oms_APU].[APUID] = [hDED].[rf_APUID]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
INNER JOIN [oms_ProtokolPos] as [jT_oms_ProtokolPos] on [jT_oms_ProtokolPos].[ProtokolPosID] = [hDED].[rf_ProtokolPosID]
go

