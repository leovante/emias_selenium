CREATE VIEW [V_rls_Currency] AS SELECT 
[hDED].[CurrencyID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[Name] as [Name], 
[hDED].[UID] as [UID], 
[hDED].[Symbols] as [Symbols], 
[hDED].[Code] as [Code]
FROM [rls_Currency] as [hDED]
go

