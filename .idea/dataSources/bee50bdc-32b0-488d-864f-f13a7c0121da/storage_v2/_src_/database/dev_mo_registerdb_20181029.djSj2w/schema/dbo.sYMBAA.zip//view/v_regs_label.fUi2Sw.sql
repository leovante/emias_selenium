CREATE VIEW [V_regs_Label] AS SELECT 
[hDED].[LabelID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[InnerCode] as [InnerCode]
FROM [regs_Label] as [hDED]
go

