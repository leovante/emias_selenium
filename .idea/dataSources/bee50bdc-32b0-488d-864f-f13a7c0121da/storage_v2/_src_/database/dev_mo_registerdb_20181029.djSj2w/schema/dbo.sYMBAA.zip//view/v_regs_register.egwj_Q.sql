CREATE VIEW [V_regs_Register] AS SELECT 
[hDED].[RegisterID], [hDED].[x_Edition], [hDED].[x_Status], [hDED].[EnumName]
, 
[hDED].[TypeName] as [TypeName]
FROM [regs_Register] as [hDED]
go

