CREATE VIEW [V_rls_Cls_Mz_PhGroup] AS SELECT 
[hDED].[Cls_Mz_PhGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_Cls_Mz_PhGroupUID] as [rf_Cls_Mz_PhGroupUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[Name] as [Name], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Cls_Mz_PhGroup] as [hDED]
go

