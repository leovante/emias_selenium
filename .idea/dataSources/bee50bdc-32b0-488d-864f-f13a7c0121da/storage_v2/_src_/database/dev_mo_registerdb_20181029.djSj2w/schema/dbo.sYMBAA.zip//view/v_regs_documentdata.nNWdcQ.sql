CREATE VIEW [V_regs_DocumentData] AS SELECT 
[hDED].[DocumentDataID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LabelID] as [rf_LabelID], 
[hDED].[rf_DocumentID] as [rf_DocumentID], 
[hDED].[Key] as [Key], 
[hDED].[Value] as [Value], 
[hDED].[AttributeString] as [AttributeString]
FROM [regs_DocumentData] as [hDED]
go

