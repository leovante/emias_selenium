CREATE VIEW [V_stt_Indication] AS SELECT 
[hDED].[IndicationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [stt_Indication] as [hDED]
go

