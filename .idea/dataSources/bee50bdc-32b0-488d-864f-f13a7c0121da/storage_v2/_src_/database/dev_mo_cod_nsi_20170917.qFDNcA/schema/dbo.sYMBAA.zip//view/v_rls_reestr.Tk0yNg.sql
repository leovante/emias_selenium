CREATE VIEW [V_rls_Reestr] AS SELECT 
[hDED].[ReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[DateReestr] as [DateReestr]
FROM [rls_Reestr] as [hDED]
go

