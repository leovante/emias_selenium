CREATE VIEW [V_hlt_WriteExamination] AS SELECT 
[hDED].[WriteExaminationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Description] as [Description], 
[hDED].[ErrorMsg] as [ErrorMsg], 
[hDED].[CriticalLevel] as [CriticalLevel], 
[hDED].[Active] as [Active], 
[hDED].[Rule] as [Rule], 
[hDED].[RuleRegistry] as [RuleRegistry], 
[hDED].[RuleDoctor] as [RuleDoctor], 
[hDED].[RuleInfomat] as [RuleInfomat], 
[hDED].[RuleInternet] as [RuleInternet], 
[hDED].[RulePhone] as [RulePhone], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_WriteExamination] as [hDED]
go

