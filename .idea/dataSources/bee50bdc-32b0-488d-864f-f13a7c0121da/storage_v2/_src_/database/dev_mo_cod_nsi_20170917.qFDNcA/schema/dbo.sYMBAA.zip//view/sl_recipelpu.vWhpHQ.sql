CREATE VIEW [dbo].[sl_RecipeLpu] AS
SELECT  
		--DPCPolyclinicRecipeID,
		--count (DPCPolyclinicRecipeID)
		DPCPolyclinicRecipeID													as idRecipe				
		,0																		as ids
		,0																		as id_rec
		,0																		as placename
		,statusEdition															as rec_status
		,SUBSTRING(SN_POL,1,abs(LEN(SN_POL)-(CHARINDEX(' ',REVERSE (SN_POL)))))	as p_pser
		,SUBSTRING (SN_POL, 
		LEN(SN_POL)+1-(CHARINDEX(' ', REVERSE (SN_POL))),
		CHARINDEX(' ', REVERSE (SN_POL)))										as P_PNOM
		,oms_Person.ss															as p_snils
		,oms_Person.FAMILY														as p_fam
		,oms_Person.NAME														as p_im
		,oms_Person.Patronymic													as p_ot
		,oms_Person.W 															as P_pol
		,oms_Person.dr															as p_dr
		,0																		as p_in
		,C_DOC																	as p_cdocum
		,SUBSTRING (SN_doc,1 , LEN(SN_DOC)-(CHARINDEX(' ',REVERSE (SN_DOC))))	as p_serdoc
		,SUBSTRING(SN_DOC,LEN(SN_DOC)+1-(CHARINDEX(' ',REVERSE (SN_DOC))),
		CHARINDEX(' ',REVERSE (SN_DOC)))										as p_numdoc
		,0																		as p_doclg
		,0																		as p_recvdoc
		,DocumDate																as p_ddoc
		,lgota.DATE_BL															as p_bdlgot
		,lgota.DATE_EL															as p_edlgot
		,C_OKATO																as p_okato
		,oms_Person.ADRES														as p_gorod
		,C_KATL																	as p_kodl
		,ltrim(rtrim(C_OGRN))													as code_lpu
		,ltrim(rtrim(	MCOD))													as mcode_lpu
		,0																		as s_rform
		,Series_Recipe															as s_rser
		,Num_Recipe																as s_rnom
		,rf_PeriodID															as s_srok
		,oms_MKB.DS																as s_mkb
		,oms_ls.nomk_ls															as s_prep
		,'?'																		as s_typels
		,KV_ALL																	as s_kolvo
		,0																		as s_coded
		,0																		as s_ds
		,0																		as s_codfls
		,oms_doctor.PCOD														as s_doctor
		,oms_doctor.FAM_V														as s_fam
		,oms_doctor.IM_V														as s_im
		,oms_doctor.OT_V														as s_ot
		,KEK_State																as s_kek
		,DATE_VR																as s_datenap
		,0																		as s_sposob
		,0																		as change
		,DATE_VR																as dt_create
		,0																		as isvalid
		,0																		as curvers
		,0																		as actual
		,0																		as k_sum
		,0																		as owner
		,0																		as idOrg
		,rf_statusLPUrecipe														as s_status
		,0																		as p_tiplg
		,0																		as lot
		,0																		as idotper
		,0																		as p_pnom_rq
		,0																		as p_oplat
		,0																		as fedreg 
		  FROM oms_DPCPolyclinicRecipe
		inner join  oms_person on personID=rf_personID
		inner join (
		select oms_LG_Person.*
		from oms_LG_Person inner join
		(select rf_PersonID, Min(LG_PersonID) as ID from oms_LG_Person
		where Getdate()> Date_BL  and GetDate()< Date_EL
		group by rf_PersonID
		) p on p.ID = LG_PersonID
		) lgota on lgota.rf_PersonID = personID
		inner join oms_katl on katlID=oms_DPCPolyclinicRecipe.rf_katlID
		inner join oms_okato on okatoID=oms_person.rf_OKATO_OMS_ID
		inner join oms_TYPEDOC on TYPEDOCID=rf_TYPEDOCID
		inner join oms_lpu on lpuID=rf_lpuID
		inner join oms_doctor  on doctorID=rf_doctorID
		inner join oms_Ls on LSID=oms_DPCPolyclinicRecipe.rf_LSID
		--inner join oms_cls on lsID=oms_cls.rf_lsID
		--inner join oms_tender on tenderID=rf_tenderID
		--inner join oms_sfo on sfoID=rf_sfoID
		inner join oms_DLS on oms_Ls.rf_DLSID = DLSId
		inner join oms_VLF on rf_VLFID = VLFID
		inner join oms_MLF on rf_MLFID = MLFID
		inner join oms_mkb on mkbID=rf_mkbID
		inner join oms_MNName on MNNameID=oms_ls.rf_MNNameID
		inner join oms_LF on LFID=oms_ls.rf_lfid


		where statusedition=0 and DPCPolyclinicRecipeid<>0
go

