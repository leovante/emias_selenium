CREATE VIEW [V_stt_SODoctorTeamComposition] AS SELECT 
[hDED].[SODoctorTeamCompositionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DoctorPositionID] as [rf_DoctorPositionID], 
[hDED].[rf_SODoctorTeamsID] as [rf_SODoctorTeamsID]
FROM [stt_SODoctorTeamComposition] as [hDED]
go

