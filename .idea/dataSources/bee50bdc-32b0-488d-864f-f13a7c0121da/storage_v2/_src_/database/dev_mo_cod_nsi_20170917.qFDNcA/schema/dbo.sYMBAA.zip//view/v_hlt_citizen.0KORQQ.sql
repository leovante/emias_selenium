CREATE VIEW [V_hlt_Citizen] AS SELECT 
[hDED].[CitizenID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[COD] as [COD], 
[hDED].[NAME] as [NAME], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateEDIT] as [DateEDIT]
FROM [hlt_Citizen] as [hDED]
go

