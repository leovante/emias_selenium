CREATE VIEW [V_hlt_RepresentativeMKAB] AS SELECT 
[hDED].[RepresentativeMKABID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[rf_AddressRegID] as [rf_AddressRegID], 
[jT_kla_Address].[CODE] as [SILENT_rf_AddressRegID], 
[hDED].[rf_AddressLiveID] as [rf_AddressLiveID], 
[jT_kla_Address1].[CODE] as [SILENT_rf_AddressLiveID], 
[hDED].[rf_kl_TipOMSID] as [rf_kl_TipOMSID], 
[jT_oms_kl_TipOMS].[IDDOC] as [SILENT_rf_kl_TipOMSID], 
[hDED].[rf_PatientMKABID] as [rf_PatientMKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_PatientMKABID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB1].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_NotWorkDocCareID] as [rf_NotWorkDocCareID], 
[jT_hlt_NotWorkDocCare].[NAME] as [SILENT_rf_NotWorkDocCareID], 
[hDED].[FAMILY] as [FAMILY], 
[hDED].[NAME] as [NAME], 
[hDED].[OT] as [OT], 
[hDED].[isNoOT] as [isNoOT], 
[hDED].[BD] as [BD], 
[hDED].[Birthplace] as [Birthplace], 
[hDED].[Work] as [Work], 
[hDED].[Post] as [Post], 
[hDED].[Phone] as [Phone], 
[hDED].[OtherContactInf] as [OtherContactInf], 
[hDED].[S_POL] as [S_POL], 
[hDED].[N_POL] as [N_POL], 
[hDED].[AddressReg] as [AddressReg], 
[hDED].[AddressLive] as [AddressLive], 
[hDED].[isMain] as [isMain], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID], 
[hDED].[SS] as [SS]
FROM [hlt_RepresentativeMKAB] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
INNER JOIN [kla_Address] as [jT_kla_Address] on [jT_kla_Address].[AddressID] = [hDED].[rf_AddressRegID]
INNER JOIN [kla_Address] as [jT_kla_Address1] on [jT_kla_Address1].[AddressID] = [hDED].[rf_AddressLiveID]
INNER JOIN [oms_kl_TipOMS] as [jT_oms_kl_TipOMS] on [jT_oms_kl_TipOMS].[kl_TipOMSID] = [hDED].[rf_kl_TipOMSID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_PatientMKABID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB1] on [jT_hlt_MKAB1].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_NotWorkDocCare] as [jT_hlt_NotWorkDocCare] on [jT_hlt_NotWorkDocCare].[NotWorkDocCareID] = [hDED].[rf_NotWorkDocCareID]
go

