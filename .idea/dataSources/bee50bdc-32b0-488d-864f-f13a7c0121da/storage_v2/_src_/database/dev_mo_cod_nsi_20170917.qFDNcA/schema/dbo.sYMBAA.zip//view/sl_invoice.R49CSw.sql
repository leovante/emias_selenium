CREATE VIEW [dbo].[sl_Invoice] AS 

SELECT  CAST(p.PostingID AS INT)                                  AS idinvoice
       ,CAST(substring(p.NUM,0,30) AS CHAR(30))                   AS dNumber
       ,sfoID													  AS org_from
	   ,sfoID													  AS owner	
       ,APUID													  AS org_to   
       ,1                                            AS docType
       ,1                                            AS actual
       ,p.Date              AS ddate
       ,p.Date              AS FlowDate
       ,p.DateCreate        AS dt_load
       ,p.DateOP        AS dt_acc
	   ,1											 AS src	
       ,p.[Sum]                                      AS sl_all   
	   ,p.[Sum]                                      AS sl_acc   	
	   ,1											 AS TipLg
	   ,GETDATE()									AS  Dt
	   ,GETDATE()									 AS dt_change		
FROM ras_Posting p
inner join ras_organisation owner on  owner.OrganisationID=rf_OrganisationOwnerID  and owner.HostOrganisationID=rf_OrganisationOwnerIDHost
inner join oms_SFO on CFO=owner.Code	and 	FO_OGRN=owner.OGRN
inner join ras_organisation org_to  on  org_to.OrganisationID=rf_OrganisationID  and org_to.HostOrganisationID=rf_OrganisationIDHost
inner join oms_APU on a_cod=org_to.Code	and 	P_OGRN=org_to.OGRN


WHERE p.PostingID <>0
AND   rf_StatePostingID <>5
AND   rf_TypePostingID <>1
go

