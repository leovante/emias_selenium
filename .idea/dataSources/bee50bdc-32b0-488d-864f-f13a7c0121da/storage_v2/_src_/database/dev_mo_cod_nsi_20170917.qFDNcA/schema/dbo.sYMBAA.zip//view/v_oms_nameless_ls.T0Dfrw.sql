CREATE VIEW [V_oms_Nameless_LS] AS SELECT 
[hDED].[Nameless_LSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LSID] as [rf_LSID], 
[jT_oms_LS].[NAME_MED] as [SILENT_rf_LSID], 
[hDED].[rf_NamelessID] as [rf_NamelessID], 
[jT_oms_Nameless].[Name] as [SILENT_rf_NamelessID], 
[hDED].[Flags] as [Flags]
FROM [oms_Nameless_LS] as [hDED]
INNER JOIN [oms_LS] as [jT_oms_LS] on [jT_oms_LS].[LSID] = [hDED].[rf_LSID]
INNER JOIN [oms_Nameless] as [jT_oms_Nameless] on [jT_oms_Nameless].[NamelessID] = [hDED].[rf_NamelessID]
go

