CREATE VIEW [V_rls_ConcenUnits] AS SELECT 
[hDED].[ConcenUnitsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[FullName] as [FullName], 
[hDED].[UID] as [UID], 
[hDED].[ShortName] as [ShortName], 
[hDED].[Code] as [Code]
FROM [rls_ConcenUnits] as [hDED]
go

