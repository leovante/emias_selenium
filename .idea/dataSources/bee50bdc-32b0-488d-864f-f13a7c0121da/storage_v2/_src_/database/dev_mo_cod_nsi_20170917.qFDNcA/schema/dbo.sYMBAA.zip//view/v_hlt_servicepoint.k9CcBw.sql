CREATE VIEW [V_hlt_ServicePoint] AS SELECT 
[hDED].[ServicePointID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_HealingRoomID] as [rf_HealingRoomID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateB] as [DateB], 
[hDED].[DateE] as [DateE], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_ServicePoint] as [hDED]
go

