CREATE VIEW [V_oms_kl_DispRegState] AS SELECT 
[hDED].[kl_DispRegStateID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_DispRegStateCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_DispRegState] as [hDED]
go

