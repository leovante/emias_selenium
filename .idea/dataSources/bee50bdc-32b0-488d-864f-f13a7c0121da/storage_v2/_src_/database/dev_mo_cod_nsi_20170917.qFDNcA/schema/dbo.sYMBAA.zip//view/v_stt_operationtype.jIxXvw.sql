CREATE VIEW [V_stt_OperationType] AS SELECT 
[hDED].[OperationTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [stt_OperationType] as [hDED]
go

