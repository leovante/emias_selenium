CREATE VIEW [V_stt_HospDegree] AS SELECT 
[hDED].[HospDegreeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[flag] as [flag]
FROM [stt_HospDegree] as [hDED]
go

