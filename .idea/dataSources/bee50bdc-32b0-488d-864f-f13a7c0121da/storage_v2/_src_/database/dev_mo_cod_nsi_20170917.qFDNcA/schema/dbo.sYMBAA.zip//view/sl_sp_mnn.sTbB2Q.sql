CREATE VIEW [dbo].[sl_Sp_Mnn] AS 

SELECT [C_Mnn] AS C_Mnn
     -- ,[x_Edition]
     -- ,[x_Status]
     -- ,[C_MNN]
      ,[NAME_MNN] name_mnn_r
      ,[Latin_Name]name_mnn_l 
	  ,[MSG_TEXT]	
  FROM [dbo].[oms_MNName]


--c_mnn, name_mnn_r, name_mnn_l                                                                                                                                                                                               msg_text
go

