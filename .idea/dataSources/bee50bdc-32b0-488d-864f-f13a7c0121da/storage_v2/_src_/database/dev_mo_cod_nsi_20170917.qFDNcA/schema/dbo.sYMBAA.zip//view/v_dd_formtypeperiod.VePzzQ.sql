CREATE VIEW [V_dd_FormTypePeriod] AS SELECT 
[hDED].[FormTypePeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
((case when IsReady=1 then 'Да' else 'Нет' end)) as [V_IsReady], 
[jT_dd_DDForm].[v_FIO] as [V_v_FIO], 
[jT_dd_DDType].[Name] as [V_DDTypeName], 
[hDED].[rf_DDFormGUID] as [rf_DDFormGUID], 
[hDED].[rf_DDTypeUGUID] as [rf_DDTypeUGUID], 
[hDED].[Uguid] as [Uguid], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[IsReady] as [IsReady]
FROM [dd_FormTypePeriod] as [hDED]
INNER JOIN [V_dd_DDForm] as [jT_dd_DDForm] on [jT_dd_DDForm].[DDFormGUID] = [hDED].[rf_DDFormGUID]
INNER JOIN [dd_DDType] as [jT_dd_DDType] on [jT_dd_DDType].[UGUID] = [hDED].[rf_DDTypeUGUID]
go

