CREATE VIEW [dbo].[sl_sp_org] AS 

select 
		SFOID as idorg,
		FO_NAMES as orgname,    
		ADRES as adres,    
		FO_NAMES as ulname,    
		RIGHT(FO_OGRN+CFO,10 ) as a_cod,    
		1 as orgtip,    
		FO_OGRN as ogrn    , 
		FO_NAMEF as  shortname, 
		E_MAIL as     email,    
		CASE WHEN C_OKATO <> 'нет' THEN C_OKATO ELSE NULL  END  as region,    
		DATE_B as DATE_B, 
		DATE_E as    DATE_E
	from oms_Sfo
	inner join OMS_OKATO on rf_OKATOID=OKATOID
	where SfoId>0

union all

select 
		apuid as idorg,
		P_NAMES as orgname,    
		ADRES as adres,    
		P_NAMES as ulname,    
		RIGHT(P_OGRN +A_COD,10) as a_cod,    -- '_'
		case A_COD when '220400' then 2 else 4 end as orgtip,    
		P_OGRN as ogrn    , 
		P_NAMEF as  shortname, 
		E_MAIL as     email,    
		C_OKATO as region,    
		DATE_B as DATE_B, 
		DATE_E as    DATE_E
	from Oms_APU 
	inner join OMS_OKATO on rf_OKATOID=OKATOID
	where  APUID>0
go

