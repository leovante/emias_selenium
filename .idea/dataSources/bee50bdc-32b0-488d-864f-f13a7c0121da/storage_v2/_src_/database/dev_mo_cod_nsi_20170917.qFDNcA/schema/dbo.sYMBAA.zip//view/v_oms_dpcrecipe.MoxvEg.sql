
CREATE VIEW [dbo].[V_oms_DPCRecipe]
AS
SELECT        
R.s_rser AS Series,
R.s_rnom AS Number, 
R.s_datenap AS Date_Wr, 
dbo.[sp_lpu].[Name_short] AS LPUName_Wr,
R.s_ot AS DocPatronymic_Wr, 
R.s_im AS DocName_Wr, 
R.s_fam AS DocFamily_Wr, 
'' AS DocPRVSName_Wr, 
LS.NAME_MED AS NameLS_Wr, 
R.ko_all AS Quantity_Wr, 
'' AS Doz_Wr, 
isnull(O.k_dateotp, '2222-01-01') AS DATE_OTP, 
'' AS APUName_Otp, 
isnull(LS_OTP.NAME_MED, '') AS NameLS_Otp, 
isnull(O.ko_all, 0) AS Quantity_Otp, 
'' AS Doz_Otp, 
                         CASE R.tipreg 
							WHEN 1 THEN 'Федеральный'
							WHEN 2 THEN 'Региональный'
							WHEN 3 THEN '7ВЗН' 
							WHEN 5 THEN 'РОЗ'
							ELSE ''
						 END AS Financing, 
CASE R.p_oplat 
							WHEN 1 THEN '100%'
							WHEN 2 THEN '50%'
							ELSE ''
						 END AS PayPercent, 
0 AS KATLID, 
CAST(R.c_katl AS varchar(3)) AS PrivilegeCategory, 
dbo.oms_KATL.NAME AS PrivilegeName, 
dbo.oms_MKB.DS AS MKBCode, 
dbo.oms_MKB.NAME AS MKBName, 
CASE 
							WHEN k_ann > 0 THEN 'Аннулирован'
							when O.k_dateotp is not null then 'Отпущен'
							ELSE 'Выписан' 
						 END AS [Status],
                         rf_MKABID AS MKABID
FROM            dbo.SP_REC_LPU AS R LEFT JOIN
						 dbo.SP_REC_OTP AS O ON R.s_rser = O.s_rser AND R.s_rnom = O.s_rnom
                         left JOIN  dbo.[sp_lpu] ON R.mcod = dbo.[sp_lpu].MCOD 
                         left JOIN dbo.oms_LS AS LS ON R.nomk_ls = LS.NOMK_LS 
						 left JOIN dbo.oms_LS AS LS_OTP ON O.nomk_ls = LS_OTP.NOMK_LS 
                         left JOIN dbo.oms_KATL ON cast(R.c_katl as varchar(3)) = cast(oms_KATL.C_KATL  as varchar(3))
                         left JOIN dbo.oms_MKB ON R.s_mkb = dbo.oms_MKB.DS


go

