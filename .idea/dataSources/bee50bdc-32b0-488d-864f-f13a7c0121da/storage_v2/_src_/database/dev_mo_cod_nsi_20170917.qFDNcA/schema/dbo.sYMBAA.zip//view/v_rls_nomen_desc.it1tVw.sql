CREATE VIEW [V_rls_Nomen_Desc] AS SELECT 
[hDED].[Nomen_DescID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_NomenUID] as [rf_NomenUID], 
[hDED].[rf_DescriptionsUID] as [rf_DescriptionsUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Number] as [Number], 
[hDED].[Code] as [Code]
FROM [rls_Nomen_Desc] as [hDED]
go

