CREATE VIEW [V_oms_Kl_SPOS] AS SELECT 
[hDED].[Kl_SPOSID], [hDED].[x_Edition], [hDED].[x_Status], 
(((Code))) as [V_kl_SPOSCode], 
[hDED].[Kod] as [Kod], 
[hDED].[Opis] as [Opis], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Code] as [Code]
FROM [oms_Kl_SPOS] as [hDED]
go

