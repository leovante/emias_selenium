CREATE VIEW [V_ras_StatePositionReport] AS SELECT 
[hDED].[StatePositionReportID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note]
FROM [ras_StatePositionReport] as [hDED]
go

