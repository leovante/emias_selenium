CREATE VIEW [V_dd_PersonOrg] AS SELECT 
[hDED].[PersonOrgID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_DDFormGUID] as [rf_DDFormGUID], 
[hDED].[rf_OrganizationUGUID] as [rf_OrganizationUGUID], 
[hDED].[MkabGuid] as [MkabGuid], 
[hDED].[Surname] as [Surname], 
[hDED].[Name] as [Name], 
[hDED].[Patronymic] as [Patronymic], 
[hDED].[BirthDate] as [BirthDate], 
[hDED].[Address] as [Address], 
[hDED].[N_POL] as [N_POL], 
[hDED].[S_Pol] as [S_Pol], 
[hDED].[SN_DOC] as [SN_DOC], 
[hDED].[SS] as [SS], 
[hDED].[UGUID] as [UGUID]
FROM [dd_PersonOrg] as [hDED]
go

