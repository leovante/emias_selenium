CREATE VIEW [V_hlt_UchastokVracha] AS SELECT 
[hDED].[UchastokVrachaID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_UchastokID] as [rf_UchastokID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [hlt_UchastokVracha] as [hDED]
go

