CREATE VIEW [V_hlt_TypeDirection] AS SELECT 
[hDED].[TypeDirectionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[COD] as [COD], 
[hDED].[Name] as [Name]
FROM [hlt_TypeDirection] as [hDED]
go

