CREATE VIEW [V_hlt_Manipulation] AS SELECT 
[hDED].[ManipulationID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_DirectionManipulation].[V_FIOPat] as [V_FIOPat], 
[jT_hlt_DirectionManipulation].[V_MKABNum] as [V_MKABNum], 
[jT_hlt_DirectionManipulation].[V_TypeDate] as [V_Type], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[PCOD] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_DirectionManipulationID] as [rf_DirectionManipulationID], 
[jT_hlt_DirectionManipulation].[Num] as [SILENT_rf_DirectionManipulationID], 
[hDED].[DatePrescription] as [DatePrescription], 
[hDED].[isComplete] as [isComplete], 
[hDED].[DateComplete] as [DateComplete], 
[hDED].[Comment] as [Comment], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags]
FROM [hlt_Manipulation] as [hDED]
INNER JOIN [V_hlt_DirectionManipulation] as [jT_hlt_DirectionManipulation] on [jT_hlt_DirectionManipulation].[DirectionManipulationID] = [hDED].[rf_DirectionManipulationID]
INNER JOIN [hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
go

