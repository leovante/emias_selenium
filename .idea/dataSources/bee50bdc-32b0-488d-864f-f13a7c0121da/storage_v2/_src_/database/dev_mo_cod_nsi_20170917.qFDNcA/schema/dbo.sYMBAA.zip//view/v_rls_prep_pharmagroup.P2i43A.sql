CREATE VIEW [V_rls_Prep_PharmaGroup] AS SELECT 
[hDED].[Prep_PharmaGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsPharmaGroupUID] as [rf_ClsPharmaGroupUID], 
[hDED].[rf_PrepUID] as [rf_PrepUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Prep_PharmaGroup] as [hDED]
go

