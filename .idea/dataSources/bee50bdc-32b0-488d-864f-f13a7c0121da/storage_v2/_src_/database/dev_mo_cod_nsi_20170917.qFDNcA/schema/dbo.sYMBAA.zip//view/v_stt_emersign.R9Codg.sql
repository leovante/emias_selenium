CREATE VIEW [V_stt_EmerSign] AS SELECT 
[hDED].[EmerSignID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[flag] as [flag]
FROM [stt_EmerSign] as [hDED]
go

