CREATE VIEW [V_hlt_BillService] AS SELECT 
[hDED].[BillServiceID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_TariffID] as [rf_TariffID], 
[jT_oms_Tariff].[Value1] as [SILENT_rf_TariffID], 
[hDED].[rf_InvoiceID] as [rf_InvoiceID], 
[jT_hlt_Invoice].[Num] as [SILENT_rf_InvoiceID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[ValueTariff] as [ValueTariff], 
[hDED].[Count] as [Count], 
[hDED].[CountComplete] as [CountComplete], 
[hDED].[Flags] as [Flags]
FROM [hlt_BillService] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_Tariff] as [jT_oms_Tariff] on [jT_oms_Tariff].[TariffID] = [hDED].[rf_TariffID]
INNER JOIN [hlt_Invoice] as [jT_hlt_Invoice] on [jT_hlt_Invoice].[InvoiceID] = [hDED].[rf_InvoiceID]
go

