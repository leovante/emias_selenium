CREATE VIEW [V_stt_AttendingDoctor] AS SELECT 
[hDED].[AttendingDoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_stt_MedicalHistory].[FIO] as [V_FIO], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_СonstitutiveInfo], 
[jT_hlt_LPUDoctor1].[V_DocInfo] as [V_AttendingDocInfo], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_СonstitutiveID] as [rf_СonstitutiveID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[date] as [date], 
[hDED].[flag] as [flag], 
[hDED].[UGUID] as [UGUID]
FROM [stt_AttendingDoctor] as [hDED]
INNER JOIN [V_stt_MedicalHistory] as [jT_stt_MedicalHistory] on [jT_stt_MedicalHistory].[MedicalHistoryID] = [hDED].[rf_MedicalHistoryID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_СonstitutiveID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor1] on [jT_hlt_LPUDoctor1].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
go

