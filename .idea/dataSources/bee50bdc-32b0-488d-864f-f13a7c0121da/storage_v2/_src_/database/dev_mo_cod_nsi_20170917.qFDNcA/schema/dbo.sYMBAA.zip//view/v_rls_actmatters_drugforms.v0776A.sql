CREATE VIEW [V_rls_ActMatters_DrugForms] AS SELECT 
[hDED].[ActMatters_DrugFormsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsDrugFormsUID] as [rf_ClsDrugFormsUID], 
[hDED].[rf_ActMattersUID] as [rf_ActMattersUID], 
[hDED].[rf_Cls_Mz_PhGroupUID] as [rf_Cls_Mz_PhGroupUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_ActMatters_DrugForms] as [hDED]
go

