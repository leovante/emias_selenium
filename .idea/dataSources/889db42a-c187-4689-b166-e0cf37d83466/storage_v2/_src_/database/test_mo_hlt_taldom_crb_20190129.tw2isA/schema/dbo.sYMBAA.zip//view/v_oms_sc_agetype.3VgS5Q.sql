CREATE VIEW [V_oms_sc_AgeType] AS SELECT 
[hDED].[sc_AgeTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name]
FROM [oms_sc_AgeType] as [hDED]
go

