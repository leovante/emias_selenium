CREATE VIEW [V_oms_onco_N004] AS SELECT 
[hDED].[onco_N004ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[ID_N] as [ID_N], 
[hDED].[DS_N] as [DS_N], 
[hDED].[KOD_N] as [KOD_N], 
[hDED].[N_NAME] as [N_NAME], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN004] as [GUIDN004]
FROM [oms_onco_N004] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
go

