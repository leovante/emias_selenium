CREATE VIEW [V_lbr_ResearchTypeKindEquipmentType] AS SELECT 
[hDED].[ResearchTypeKindEquipmentTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResearchTypeKindID] as [rf_ResearchTypeKindID], 
[hDED].[rf_EquipmentTypeID] as [rf_EquipmentTypeID], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [lbr_ResearchTypeKindEquipmentType] as [hDED]
go

