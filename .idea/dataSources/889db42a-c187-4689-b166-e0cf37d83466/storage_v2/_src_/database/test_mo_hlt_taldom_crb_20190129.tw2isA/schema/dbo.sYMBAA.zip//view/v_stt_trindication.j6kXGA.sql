CREATE VIEW [V_stt_TrIndication] AS SELECT 
[hDED].[TrIndicationID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_stt_Indication].[Name] as [V_Name], 
[hDED].[rf_IndicationID] as [rf_IndicationID], 
[jT_stt_Indication].[Name] as [SILENT_rf_IndicationID], 
[hDED].[rf_TransfusionID] as [rf_TransfusionID], 
[jT_stt_Transfusion].[rf_MedicalHistoryID] as [SILENT_rf_TransfusionID], 
[hDED].[Description] as [Description], 
[hDED].[Date] as [Date], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flags] as [flags]
FROM [stt_TrIndication] as [hDED]
INNER JOIN [stt_Indication] as [jT_stt_Indication] on [jT_stt_Indication].[IndicationID] = [hDED].[rf_IndicationID]
INNER JOIN [stt_Transfusion] as [jT_stt_Transfusion] on [jT_stt_Transfusion].[TransfusionID] = [hDED].[rf_TransfusionID]
go

