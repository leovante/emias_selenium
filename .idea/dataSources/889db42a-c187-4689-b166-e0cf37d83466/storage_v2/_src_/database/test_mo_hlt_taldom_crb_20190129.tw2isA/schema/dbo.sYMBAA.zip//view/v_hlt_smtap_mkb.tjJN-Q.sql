CREATE VIEW [V_hlt_SMTAP_MKB] AS SELECT 
[hDED].[SMTAP_MKBID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_SMTAPID] as [rf_SMTAPID], 
[hDED].[IsMainDS] as [IsMainDS], 
[hDED].[Q_Z] as [Q_Z]
FROM [hlt_SMTAP_MKB] as [hDED]
go

