CREATE VIEW [V_oms_pr_ResourceGraf] AS SELECT 
[hDED].[pr_ResourceGrafID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_pr_LPU].[V_M_NAMES] as [V_V_M_NAMES], 
[jT_oms_pr_ProfType].[Name] as [V_NameType], 
[hDED].[rf_pr_ProfTypeID] as [rf_pr_ProfTypeID], 
[hDED].[rf_pr_LPUID] as [rf_pr_LPUID], 
[hDED].[DatePlan] as [DatePlan], 
[hDED].[Region] as [Region], 
[hDED].[Rem] as [Rem], 
[hDED].[HourBegin] as [HourBegin], 
[hDED].[Flags] as [Flags], 
[hDED].[HourEnd] as [HourEnd]
FROM [oms_pr_ResourceGraf] as [hDED]
INNER JOIN [V_oms_pr_LPU] as [jT_oms_pr_LPU] on [jT_oms_pr_LPU].[pr_LPUID] = [hDED].[rf_pr_LPUID]
INNER JOIN [oms_pr_ProfType] as [jT_oms_pr_ProfType] on [jT_oms_pr_ProfType].[pr_ProfTypeID] = [hDED].[rf_pr_ProfTypeID]
go

