CREATE VIEW [V_stt_ReestrMPMH] AS SELECT 
[hDED].[ReestrMPMHID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[jT_hlt_ReestrMH].[DateBegin] as [SILENT_rf_ReestrMHID], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[jT_stt_MigrationPatient].[rf_StationarBranchID] as [SILENT_rf_MigrationPatientID], 
[hDED].[Num] as [Num], 
[hDED].[Flag] as [Flag]
FROM [stt_ReestrMPMH] as [hDED]
INNER JOIN [hlt_ReestrMH] as [jT_hlt_ReestrMH] on [jT_hlt_ReestrMH].[ReestrMHID] = [hDED].[rf_ReestrMHID]
INNER JOIN [stt_MigrationPatient] as [jT_stt_MigrationPatient] on [jT_stt_MigrationPatient].[MigrationPatientID] = [hDED].[rf_MigrationPatientID]
go

