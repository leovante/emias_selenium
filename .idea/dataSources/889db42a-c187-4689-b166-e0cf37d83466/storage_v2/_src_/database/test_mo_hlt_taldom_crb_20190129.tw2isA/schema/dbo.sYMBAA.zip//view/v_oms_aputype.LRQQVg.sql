CREATE VIEW [V_oms_ApuType] AS SELECT 
[hDED].[ApuTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ApuTypeCode] as [ApuTypeCode], 
[hDED].[ApuTypeName] as [ApuTypeName], 
[hDED].[ApuTypeNote] as [ApuTypeNote], 
[hDED].[ApuTypeFlags] as [ApuTypeFlags]
FROM [oms_ApuType] as [hDED]
go

