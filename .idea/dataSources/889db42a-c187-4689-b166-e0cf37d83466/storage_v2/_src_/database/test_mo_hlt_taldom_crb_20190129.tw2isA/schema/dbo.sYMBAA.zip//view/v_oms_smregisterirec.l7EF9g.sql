CREATE VIEW [V_oms_SMRegisterIRec] AS SELECT 
[hDED].[SMRegisterIRecID], [hDED].[x_Edition], [hDED].[x_Status], 
((((((select FIO from x_User where UserId = hDED.LastUserID)))))) as [V_UserFIO], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[jT_oms_SMReestrSluch].[IDCase] as [SILENT_rf_SMReestrSluchID], 
[hDED].[rf_SMReestrSluchViewID] as [rf_SMReestrSluchViewID], 
[jT_oms_SMReestrSluchView].[inf_Family] as [SILENT_rf_SMReestrSluchViewID], 
[hDED].[rf_SMExpVidID] as [rf_SMExpVidID], 
[jT_oms_SMExpVid].[NameExpVid] as [SILENT_rf_SMExpVidID], 
[hDED].[rf_SMExpTargetID] as [rf_SMExpTargetID], 
[jT_oms_SMExpTarget].[NameExpTarget] as [SILENT_rf_SMExpTargetID], 
[hDED].[rf_SMRegisterTarifID] as [rf_SMRegisterTarifID], 
[jT_oms_SMRegisterTarif].[Tarif] as [SILENT_rf_SMRegisterTarifID], 
[hDED].[rf_SMRegisterInstructionID] as [rf_SMRegisterInstructionID], 
[jT_oms_SMRegisterInstruction].[Num] as [SILENT_rf_SMRegisterInstructionID], 
[hDED].[Flags] as [Flags], 
[hDED].[Num] as [Num], 
[hDED].[Date_Akt] as [Date_Akt], 
[hDED].[LastUserID] as [LastUserID]
FROM [oms_SMRegisterIRec] as [hDED]
INNER JOIN [oms_SMReestrSluch] as [jT_oms_SMReestrSluch] on [jT_oms_SMReestrSluch].[SMReestrSluchID] = [hDED].[rf_SMReestrSluchID]
INNER JOIN [oms_SMReestrSluchView] as [jT_oms_SMReestrSluchView] on [jT_oms_SMReestrSluchView].[SMReestrSluchViewID] = [hDED].[rf_SMReestrSluchViewID]
INNER JOIN [oms_SMExpVid] as [jT_oms_SMExpVid] on [jT_oms_SMExpVid].[SMExpVidID] = [hDED].[rf_SMExpVidID]
INNER JOIN [oms_SMExpTarget] as [jT_oms_SMExpTarget] on [jT_oms_SMExpTarget].[SMExpTargetID] = [hDED].[rf_SMExpTargetID]
INNER JOIN [oms_SMRegisterTarif] as [jT_oms_SMRegisterTarif] on [jT_oms_SMRegisterTarif].[SMRegisterTarifID] = [hDED].[rf_SMRegisterTarifID]
INNER JOIN [oms_SMRegisterInstruction] as [jT_oms_SMRegisterInstruction] on [jT_oms_SMRegisterInstruction].[SMRegisterInstructionID] = [hDED].[rf_SMRegisterInstructionID]
go

