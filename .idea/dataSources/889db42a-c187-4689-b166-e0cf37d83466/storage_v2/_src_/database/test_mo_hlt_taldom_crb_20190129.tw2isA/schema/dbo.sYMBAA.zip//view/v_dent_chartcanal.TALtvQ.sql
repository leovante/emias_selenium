CREATE VIEW [V_dent_ChartCanal] AS SELECT 
[hDED].[ChartCanalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_dent_RootCanalID] as [rf_dent_RootCanalID], 
[jT_oms_dent_RootCanal].[Name] as [SILENT_rf_dent_RootCanalID], 
[hDED].[rf_dent_CanalConditionID] as [rf_dent_CanalConditionID], 
[jT_oms_dent_CanalCondition].[Name] as [SILENT_rf_dent_CanalConditionID], 
[hDED].[rf_ChartRootID] as [rf_ChartRootID], 
[jT_dent_ChartRoot].[Date] as [SILENT_rf_ChartRootID], 
[hDED].[Date] as [Date], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Note] as [Note]
FROM [dent_ChartCanal] as [hDED]
INNER JOIN [oms_dent_RootCanal] as [jT_oms_dent_RootCanal] on [jT_oms_dent_RootCanal].[dent_RootCanalID] = [hDED].[rf_dent_RootCanalID]
INNER JOIN [oms_dent_CanalCondition] as [jT_oms_dent_CanalCondition] on [jT_oms_dent_CanalCondition].[dent_CanalConditionID] = [hDED].[rf_dent_CanalConditionID]
INNER JOIN [dent_ChartRoot] as [jT_dent_ChartRoot] on [jT_dent_ChartRoot].[ChartRootID] = [hDED].[rf_ChartRootID]
go

