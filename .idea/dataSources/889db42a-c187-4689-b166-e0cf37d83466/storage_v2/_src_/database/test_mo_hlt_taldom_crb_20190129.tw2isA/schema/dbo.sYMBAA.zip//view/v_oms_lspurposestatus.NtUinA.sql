CREATE VIEW [V_oms_LSPurposeStatus] AS SELECT 
[hDED].[LSPurposeStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CodeLSP] as [CodeLSP], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUIDLSP] as [UGUIDLSP], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Caption] as [Caption]
FROM [oms_LSPurposeStatus] as [hDED]
go

