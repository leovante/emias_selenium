CREATE VIEW [V_dd_ResultValue] AS SELECT 
[hDED].[ResultValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_dd_ResultType].[V_Name] as [V_V_Name], 
[jT_dd_ResultType].[Name] as [V_Name], 
[jT_dd_ResultTypeValue].[Name] as [V_NameValue], 
[hDED].[rf_DDFormGUID] as [rf_DDFormGUID], 
[hDED].[rf_DDExamGUID] as [rf_DDExamGUID], 
[hDED].[rf_DDResearchLFGUID] as [rf_DDResearchLFGUID], 
[hDED].[rf_ResultTypeGUID] as [rf_ResultTypeGUID], 
[hDED].[rf_ResultTypeValueGUID] as [rf_ResultTypeValueGUID], 
[hDED].[UGUID] as [UGUID]
FROM [dd_ResultValue] as [hDED]
INNER JOIN [V_dd_ResultType] as [jT_dd_ResultType] on [jT_dd_ResultType].[UGUID] = [hDED].[rf_ResultTypeGUID]
INNER JOIN [dd_ResultTypeValue] as [jT_dd_ResultTypeValue] on [jT_dd_ResultTypeValue].[UGUID] = [hDED].[rf_ResultTypeValueGUID]
go

