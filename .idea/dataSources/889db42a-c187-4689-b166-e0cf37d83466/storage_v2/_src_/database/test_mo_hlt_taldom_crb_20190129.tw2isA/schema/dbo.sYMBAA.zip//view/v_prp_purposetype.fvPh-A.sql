CREATE VIEW [V_prp_PurposeType] AS SELECT 
[hDED].[PurposeTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [prp_PurposeType] as [hDED]
go

