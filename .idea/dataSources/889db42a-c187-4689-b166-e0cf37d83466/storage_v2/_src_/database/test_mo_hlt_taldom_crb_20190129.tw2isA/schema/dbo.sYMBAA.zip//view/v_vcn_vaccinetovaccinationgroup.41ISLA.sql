CREATE VIEW [V_vcn_VaccineToVaccinationGroup] AS SELECT 
[hDED].[VaccineToVaccinationGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_vcn_VaccineType].[GUID] as [V_VaccineTypeGuid], 
[jT_vcn_VaccinationGroup].[Code] as [V_VaccinationGroupCode], 
[hDED].[rf_VaccinationGroupID] as [rf_VaccinationGroupID], 
[jT_vcn_VaccinationGroup].[Name] as [SILENT_rf_VaccinationGroupID], 
[hDED].[rf_VaccineTypeID] as [rf_VaccineTypeID], 
[jT_vcn_VaccineType].[Name] as [SILENT_rf_VaccineTypeID], 
[hDED].[Remark] as [Remark], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [vcn_VaccineToVaccinationGroup] as [hDED]
INNER JOIN [vcn_VaccineType] as [jT_vcn_VaccineType] on [jT_vcn_VaccineType].[VaccineTypeID] = [hDED].[rf_VaccineTypeID]
INNER JOIN [vcn_VaccinationGroup] as [jT_vcn_VaccinationGroup] on [jT_vcn_VaccinationGroup].[VaccinationGroupID] = [hDED].[rf_VaccinationGroupID]
go

