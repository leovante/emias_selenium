CREATE VIEW [V_oms_ReestrPay] AS SELECT 
[hDED].[ReestrPayID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[Date_Pay] as [Date_Pay], 
[hDED].[Pay] as [Pay]
FROM [oms_ReestrPay] as [hDED]
go

