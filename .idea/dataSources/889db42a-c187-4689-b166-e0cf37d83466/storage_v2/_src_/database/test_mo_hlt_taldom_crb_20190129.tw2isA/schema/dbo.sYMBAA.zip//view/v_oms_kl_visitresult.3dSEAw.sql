CREATE VIEW [V_oms_kl_VisitResult] AS SELECT 
[hDED].[kl_VisitResultID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_VisitResultCode], 
[hDED].[rf_kl_DDServiceID] as [rf_kl_DDServiceID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[CODE_Region] as [CODE_Region], 
[hDED].[CODE_DD] as [CODE_DD], 
[hDED].[VisitResultGUID] as [VisitResultGUID], 
[hDED].[CODE_Federal] as [CODE_Federal]
FROM [oms_kl_VisitResult] as [hDED]
go

