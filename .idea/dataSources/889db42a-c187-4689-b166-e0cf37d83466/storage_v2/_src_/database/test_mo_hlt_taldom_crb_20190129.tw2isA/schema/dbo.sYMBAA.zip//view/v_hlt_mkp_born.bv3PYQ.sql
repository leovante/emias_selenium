CREATE VIEW [V_hlt_mkp_Born] AS SELECT 
[hDED].[mkp_BornID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[rf_mkp_CardGUID] as [rf_mkp_CardGUID], 
[jT_hlt_mkp_Card].[NUM] as [SILENT_rf_mkp_CardGUID], 
[hDED].[rf_mkp_DeathMotherGUID] as [rf_mkp_DeathMotherGUID], 
[hDED].[NUM] as [NUM], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateBirthChild] as [DateBirthChild], 
[hDED].[Weight] as [Weight], 
[hDED].[Length] as [Length], 
[hDED].[DevelopmentalDisorders] as [DevelopmentalDisorders], 
[hDED].[RatingApgar1] as [RatingApgar1], 
[hDED].[RatingApgar5] as [RatingApgar5], 
[hDED].[Flags] as [Flags], 
[hDED].[WeightExtract] as [WeightExtract], 
[hDED].[Pronatis] as [Pronatis], 
[hDED].[StateExtract] as [StateExtract], 
[hDED].[StatusBorn] as [StatusBorn], 
[hDED].[StateRoddom] as [StateRoddom], 
[hDED].[Stillbirth] as [Stillbirth], 
[hDED].[Treatment] as [Treatment], 
[hDED].[Alive] as [Alive], 
[hDED].[CancelChild] as [CancelChild], 
[hDED].[ReasonStillbirth] as [ReasonStillbirth], 
[hDED].[StateBirth] as [StateBirth]
FROM [hlt_mkp_Born] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
INNER JOIN [hlt_mkp_Card] as [jT_hlt_mkp_Card] on [jT_hlt_mkp_Card].[UGUID] = [hDED].[rf_mkp_CardGUID]
go

