CREATE VIEW [V_lbr_LaboratoryResearchType] AS SELECT 
[hDED].[LaboratoryResearchTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LaboratoryID] as [rf_LaboratoryID], 
[jT_lbr_Laboratory].[LaboratoryName] as [SILENT_rf_LaboratoryID], 
[hDED].[rf_ResearchTypeUGUID] as [rf_ResearchTypeUGUID], 
[jT_lbr_ResearchType].[ResearchName] as [SILENT_rf_ResearchTypeUGUID], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [lbr_LaboratoryResearchType] as [hDED]
INNER JOIN [lbr_Laboratory] as [jT_lbr_Laboratory] on [jT_lbr_Laboratory].[LaboratoryID] = [hDED].[rf_LaboratoryID]
INNER JOIN [lbr_ResearchType] as [jT_lbr_ResearchType] on [jT_lbr_ResearchType].[UGUID] = [hDED].[rf_ResearchTypeUGUID]
go

