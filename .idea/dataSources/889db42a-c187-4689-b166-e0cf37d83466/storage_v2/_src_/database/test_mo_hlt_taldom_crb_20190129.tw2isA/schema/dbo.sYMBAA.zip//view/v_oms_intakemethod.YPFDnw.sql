CREATE VIEW [V_oms_IntakeMethod] AS SELECT 
[hDED].[IntakeMethodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[C_IM] as [C_IM], 
[hDED].[GUID_IM] as [GUID_IM], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [oms_IntakeMethod] as [hDED]
go

