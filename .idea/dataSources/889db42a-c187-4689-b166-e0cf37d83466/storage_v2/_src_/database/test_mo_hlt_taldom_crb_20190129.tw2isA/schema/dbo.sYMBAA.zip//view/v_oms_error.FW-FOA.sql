CREATE VIEW [V_oms_Error] AS SELECT 
[hDED].[ErrorID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_ExpertAlgorithm].[AlgType] as [AlgType], 
[jT_oms_ExpertAlgorithm].[Caption] as [AlgCaption], 
[hDED].[rf_ExpertAlgorithmID] as [rf_ExpertAlgorithmID], 
[hDED].[KOD] as [KOD], 
[hDED].[Name] as [Name], 
[hDED].[Prior] as [Prior], 
[hDED].[SetOn] as [SetOn], 
[hDED].[Rem] as [Rem]
FROM [oms_Error] as [hDED]
INNER JOIN [oms_ExpertAlgorithm] as [jT_oms_ExpertAlgorithm] on [jT_oms_ExpertAlgorithm].[ExpertAlgorithmID] = [hDED].[rf_ExpertAlgorithmID]
go

