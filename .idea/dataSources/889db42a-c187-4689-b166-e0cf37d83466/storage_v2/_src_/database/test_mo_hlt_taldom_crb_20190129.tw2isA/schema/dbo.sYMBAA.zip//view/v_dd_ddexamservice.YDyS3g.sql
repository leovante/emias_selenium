CREATE VIEW [V_dd_DDExamService] AS SELECT 
[hDED].[DDExamServiceID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDExamID] as [rf_DDExamID]
FROM [dd_DDExamService] as [hDED]
go

