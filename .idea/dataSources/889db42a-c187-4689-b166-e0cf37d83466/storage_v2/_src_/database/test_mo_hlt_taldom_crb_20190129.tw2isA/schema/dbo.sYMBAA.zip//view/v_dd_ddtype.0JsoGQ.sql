CREATE VIEW [V_dd_DDType] AS SELECT 
[hDED].[DDTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[hDED].[rf_DDTypeID] as [rf_DDTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag]
FROM [dd_DDType] as [hDED]
go

