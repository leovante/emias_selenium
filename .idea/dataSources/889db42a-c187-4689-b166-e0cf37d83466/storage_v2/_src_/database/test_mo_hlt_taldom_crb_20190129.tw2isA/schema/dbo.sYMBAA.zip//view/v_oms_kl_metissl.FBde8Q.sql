CREATE VIEW [V_oms_kl_MetIssl] AS SELECT 
[hDED].[kl_MetIsslID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidMetIssl], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [oms_kl_MetIssl] as [hDED]
go

