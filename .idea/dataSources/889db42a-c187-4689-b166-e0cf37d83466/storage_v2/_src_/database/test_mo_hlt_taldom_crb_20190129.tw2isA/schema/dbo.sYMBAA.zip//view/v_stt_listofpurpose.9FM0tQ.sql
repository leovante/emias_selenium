CREATE VIEW [V_stt_ListOfPurpose] AS SELECT 
[hDED].[ListOfPurposeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_CancelDoctorID] as [rf_CancelDoctorID], 
[jT_hlt_LPUDoctor1].[V_DocInfo] as [SILENT_rf_CancelDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_CancelDocPRVDID] as [rf_CancelDocPRVDID], 
[jT_hlt_DocPRVD1].[Name] as [SILENT_rf_CancelDocPRVDID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_ListOfPurposeID] as [rf_ListOfPurposeID], 
[jT_stt_ListOfPurpose].[rf_PurposeLSID] as [SILENT_rf_ListOfPurposeID], 
[hDED].[rf_PurposeLSID] as [rf_PurposeLSID], 
[jT_stt_PurposeLS].[Name] as [SILENT_rf_PurposeLSID], 
[hDED].[rf_MedStageID] as [rf_MedStageID], 
[hDED].[rf_IntakeMethodID] as [rf_IntakeMethodID], 
[hDED].[rf_IntakeWayID] as [rf_IntakeWayID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag], 
[hDED].[Dose] as [Dose], 
[hDED].[TimesInDay] as [TimesInDay], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[SpecificDose] as [SpecificDose], 
[hDED].[RationalDose] as [RationalDose], 
[hDED].[UnitDose] as [UnitDose], 
[hDED].[Signature] as [Signature], 
[hDED].[CancelDate] as [CancelDate], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[hDED].[StoreInfo] as [StoreInfo], 
[hDED].[TenderTypeInfo] as [TenderTypeInfo], 
[hDED].[IsWriteCoreDose] as [IsWriteCoreDose], 
[hDED].[LFCountPerCourse] as [LFCountPerCourse], 
[hDED].[isKEK] as [isKEK], 
[hDED].[isBaseDoseOverride] as [isBaseDoseOverride], 
[hDED].[isSpecialPurpose] as [isSpecialPurpose]
FROM [stt_ListOfPurpose] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor1] on [jT_hlt_LPUDoctor1].[LPUDoctorID] = [hDED].[rf_CancelDoctorID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD1] on [jT_hlt_DocPRVD1].[DocPRVDID] = [hDED].[rf_CancelDocPRVDID]
INNER JOIN [stt_ListOfPurpose] as [jT_stt_ListOfPurpose] on [jT_stt_ListOfPurpose].[ListOfPurposeID] = [hDED].[rf_ListOfPurposeID]
INNER JOIN [stt_PurposeLS] as [jT_stt_PurposeLS] on [jT_stt_PurposeLS].[PurposeLSID] = [hDED].[rf_PurposeLSID]
go

