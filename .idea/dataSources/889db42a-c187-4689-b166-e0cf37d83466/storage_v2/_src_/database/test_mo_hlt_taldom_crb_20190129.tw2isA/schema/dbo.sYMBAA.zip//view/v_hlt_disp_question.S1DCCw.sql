CREATE VIEW [V_hlt_disp_Question] AS SELECT 
[hDED].[disp_QuestionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ParamGuid] as [rf_ParamGuid], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Guid] as [Guid], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [hlt_disp_Question] as [hDED]
go

