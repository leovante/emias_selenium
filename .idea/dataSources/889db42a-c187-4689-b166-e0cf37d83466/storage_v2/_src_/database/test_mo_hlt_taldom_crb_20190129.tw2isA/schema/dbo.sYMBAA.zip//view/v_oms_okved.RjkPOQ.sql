CREATE VIEW [V_oms_OKVED] AS SELECT 
[hDED].[OKVEDID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[NAME] as [NAME], 
[hDED].[OKVED_CODE] as [OKVED_CODE], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID]
FROM [oms_OKVED] as [hDED]
go

