CREATE VIEW [V_hlt_Discount] AS SELECT 
[hDED].[DiscountID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DOGOVORID] as [rf_DOGOVORID], 
[jT_oms_DOGOVOR].[V_Info] as [SILENT_rf_DOGOVORID], 
[hDED].[rf_DiscountReasonTypeID] as [rf_DiscountReasonTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DiscountValue] as [DiscountValue], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_Discount] as [hDED]
INNER JOIN [V_oms_DOGOVOR] as [jT_oms_DOGOVOR] on [jT_oms_DOGOVOR].[DOGOVORID] = [hDED].[rf_DOGOVORID]
go

