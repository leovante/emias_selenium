CREATE VIEW [V_ehr_Journal] AS SELECT 
[hDED].[JournalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_JournalStateID] as [rf_JournalStateID], 
[hDED].[Guid] as [Guid], 
[hDED].[EventDateTime] as [EventDateTime], 
[hDED].[MedicalRecordGuid] as [MedicalRecordGuid]
FROM [ehr_Journal] as [hDED]
go

