CREATE VIEW [V_mail_Message2Computer] AS SELECT 
[hDED].[Message2ComputerID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MessageID] as [rf_MessageID], 
[hDED].[MAC] as [MAC], 
[hDED].[ReadDate] as [ReadDate]
FROM [mail_Message2Computer] as [hDED]
go

