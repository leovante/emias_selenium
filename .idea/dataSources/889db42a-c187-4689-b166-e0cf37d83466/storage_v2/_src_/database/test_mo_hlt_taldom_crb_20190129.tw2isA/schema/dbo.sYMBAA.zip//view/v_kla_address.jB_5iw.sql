CREATE VIEW [V_kla_Address] AS SELECT 
[hDED].[AddressID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_HouseID] as [rf_HouseID], 
[hDED].[rf_CountryID] as [rf_CountryID], 
[hDED].[CODE] as [CODE], 
[hDED].[AddressString] as [AddressString], 
[hDED].[Appartment] as [Appartment], 
[hDED].[DopData] as [DopData], 
[hDED].[Area] as [Area], 
[hDED].[Region] as [Region], 
[hDED].[City] as [City], 
[hDED].[Flags] as [Flags], 
[hDED].[Street] as [Street], 
[hDED].[Locality] as [Locality]
FROM [kla_Address] as [hDED]
go

