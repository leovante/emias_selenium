CREATE VIEW [V_App_Time_SSZ] AS SELECT 
[hDED].[Time_SSZID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Date_Begin] as [Date_Begin], 
[hDED].[Date_End] as [Date_End], 
[hDED].[Description] as [Description]
FROM [App_Time_SSZ] as [hDED]
go

