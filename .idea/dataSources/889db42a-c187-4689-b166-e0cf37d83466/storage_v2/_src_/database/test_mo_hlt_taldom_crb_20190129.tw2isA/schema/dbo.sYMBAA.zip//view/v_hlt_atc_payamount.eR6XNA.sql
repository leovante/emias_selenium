CREATE VIEW [V_hlt_atc_PayAmount] AS SELECT 
[hDED].[atc_PayAmountID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_atc_PayCategoryID] as [rf_atc_PayCategoryID], 
[jT_hlt_atc_PayCategory].[Name] as [SILENT_rf_atc_PayCategoryID], 
[hDED].[Amount] as [Amount], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_atc_PayAmount] as [hDED]
INNER JOIN [hlt_atc_PayCategory] as [jT_hlt_atc_PayCategory] on [jT_hlt_atc_PayCategory].[atc_PayCategoryID] = [hDED].[rf_atc_PayCategoryID]
go

