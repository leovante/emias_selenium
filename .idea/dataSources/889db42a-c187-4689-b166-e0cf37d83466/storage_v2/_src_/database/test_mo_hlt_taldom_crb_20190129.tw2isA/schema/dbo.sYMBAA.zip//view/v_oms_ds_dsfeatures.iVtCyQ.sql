CREATE VIEW [V_oms_ds_DSFeatures] AS SELECT 
[hDED].[ds_DSFeaturesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DocTypeDefGUID] as [rf_DocTypeDefGUID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[isDel] as [isDel], 
[hDED].[Flags] as [Flags], 
[hDED].[DSFeaturesGUID] as [DSFeaturesGUID]
FROM [oms_ds_DSFeatures] as [hDED]
go

