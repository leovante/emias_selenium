CREATE VIEW [V_oms_dent_ConditionType] AS SELECT 
[hDED].[dent_ConditionTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidConditionType], 
[hDED].[rf_dent_ToolbarTypeID] as [rf_dent_ToolbarTypeID], 
[jT_oms_dent_ToolbarType].[Name] as [SILENT_rf_dent_ToolbarTypeID], 
[hDED].[rf_dent_ConditionGroupID] as [rf_dent_ConditionGroupID], 
[jT_oms_dent_ConditionGroup].[Name] as [SILENT_rf_dent_ConditionGroupID], 
[hDED].[Name] as [Name], 
[hDED].[Value] as [Value], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [oms_dent_ConditionType] as [hDED]
INNER JOIN [oms_dent_ToolbarType] as [jT_oms_dent_ToolbarType] on [jT_oms_dent_ToolbarType].[dent_ToolbarTypeID] = [hDED].[rf_dent_ToolbarTypeID]
INNER JOIN [oms_dent_ConditionGroup] as [jT_oms_dent_ConditionGroup] on [jT_oms_dent_ConditionGroup].[dent_ConditionGroupID] = [hDED].[rf_dent_ConditionGroupID]
go

