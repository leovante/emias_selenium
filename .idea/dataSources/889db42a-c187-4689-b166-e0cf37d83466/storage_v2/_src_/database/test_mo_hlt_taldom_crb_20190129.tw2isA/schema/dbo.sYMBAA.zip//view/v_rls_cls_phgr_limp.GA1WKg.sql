CREATE VIEW [V_rls_Cls_PhGr_Limp] AS SELECT 
[hDED].[Cls_PhGr_LimpID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_Cls_PhGr_LimpUID] as [rf_Cls_PhGr_LimpUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[Name] as [Name], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Cls_PhGr_Limp] as [hDED]
go

