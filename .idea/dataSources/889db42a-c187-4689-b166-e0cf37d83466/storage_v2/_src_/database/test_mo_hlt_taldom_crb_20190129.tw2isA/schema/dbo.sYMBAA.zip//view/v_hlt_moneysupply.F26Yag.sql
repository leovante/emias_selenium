CREATE VIEW [V_hlt_MoneySupply] AS SELECT 
[hDED].[MoneySupplyID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMTAPID] as [rf_SMTAPID], 
[jT_hlt_SMTAP].[REG_S] as [SILENT_rf_SMTAPID], 
[hDED].[rf_InvoiceID] as [rf_InvoiceID], 
[jT_hlt_Invoice].[Num] as [SILENT_rf_InvoiceID], 
[hDED].[rf_DogovorPayingID] as [rf_DogovorPayingID], 
[jT_hlt_DogovorPaying].[Num] as [SILENT_rf_DogovorPayingID], 
[hDED].[rf_BillServiceID] as [rf_BillServiceID], 
[jT_hlt_BillService].[rf_ServiceMedicalID] as [SILENT_rf_BillServiceID], 
[hDED].[Date] as [Date], 
[hDED].[SummInc] as [SummInc], 
[hDED].[SummDec] as [SummDec], 
[hDED].[Balance] as [Balance], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_MoneySupply] as [hDED]
INNER JOIN [hlt_SMTAP] as [jT_hlt_SMTAP] on [jT_hlt_SMTAP].[SMTAPID] = [hDED].[rf_SMTAPID]
INNER JOIN [hlt_Invoice] as [jT_hlt_Invoice] on [jT_hlt_Invoice].[InvoiceID] = [hDED].[rf_InvoiceID]
INNER JOIN [hlt_DogovorPaying] as [jT_hlt_DogovorPaying] on [jT_hlt_DogovorPaying].[DogovorPayingID] = [hDED].[rf_DogovorPayingID]
INNER JOIN [hlt_BillService] as [jT_hlt_BillService] on [jT_hlt_BillService].[BillServiceID] = [hDED].[rf_BillServiceID]
go

