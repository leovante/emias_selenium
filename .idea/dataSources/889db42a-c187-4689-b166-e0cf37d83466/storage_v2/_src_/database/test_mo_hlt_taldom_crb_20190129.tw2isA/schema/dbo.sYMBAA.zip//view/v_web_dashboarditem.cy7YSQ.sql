CREATE VIEW [V_web_DashboardItem] AS SELECT 
[hDED].[DashboardItemID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DashboardGroupGuid] as [rf_DashboardGroupGuid], 
[hDED].[Name] as [Name], 
[hDED].[ControllerName] as [ControllerName], 
[hDED].[ActionName] as [ActionName], 
[hDED].[IconURL] as [IconURL], 
[hDED].[Priority] as [Priority], 
[hDED].[Guid] as [Guid], 
[hDED].[Description] as [Description]
FROM [web_DashboardItem] as [hDED]
go

