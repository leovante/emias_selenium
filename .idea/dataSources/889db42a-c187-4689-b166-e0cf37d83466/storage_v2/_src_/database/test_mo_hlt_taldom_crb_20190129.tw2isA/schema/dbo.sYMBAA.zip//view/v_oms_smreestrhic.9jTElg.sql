CREATE VIEW [V_oms_SMReestrHIC] AS SELECT 
[hDED].[SMReestrHICID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[HIC_CODE] as [HIC_CODE]
FROM [oms_SMReestrHIC] as [hDED]
go

