CREATE VIEW [V_dmg_vs_GroupStudent] AS SELECT 
[hDED].[vs_GroupStudentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_vs_GroupID] as [rf_vs_GroupID], 
[hDED].[rf_vs_StudentID] as [rf_vs_StudentID], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Code] as [Code], 
[hDED].[Level] as [Level]
FROM [dmg_vs_GroupStudent] as [hDED]
go

