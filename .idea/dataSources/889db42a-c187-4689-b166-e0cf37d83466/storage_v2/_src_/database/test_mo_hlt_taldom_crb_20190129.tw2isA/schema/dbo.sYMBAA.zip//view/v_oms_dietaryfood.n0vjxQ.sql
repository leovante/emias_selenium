CREATE VIEW [V_oms_DietaryFood] AS SELECT 
[hDED].[DietaryFoodID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_DietaryFoodCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[flags] as [flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_DietaryFood] as [hDED]
go

