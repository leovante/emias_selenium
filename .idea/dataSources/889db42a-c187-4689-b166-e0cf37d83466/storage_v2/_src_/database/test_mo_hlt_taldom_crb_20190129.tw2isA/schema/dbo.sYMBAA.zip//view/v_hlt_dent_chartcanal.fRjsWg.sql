CREATE VIEW [V_hlt_dent_ChartCanal] AS SELECT 
[hDED].[dent_ChartCanalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_dent_RootCanalID] as [rf_dent_RootCanalID], 
[jT_oms_dent_RootCanal].[Name] as [SILENT_rf_dent_RootCanalID], 
[hDED].[rf_dent_CanalConditionID] as [rf_dent_CanalConditionID], 
[jT_oms_dent_CanalCondition].[Name] as [SILENT_rf_dent_CanalConditionID], 
[hDED].[rf_dent_ChartRootID] as [rf_dent_ChartRootID], 
[jT_hlt_dent_ChartRoot].[Date] as [SILENT_rf_dent_ChartRootID], 
[hDED].[Date] as [Date], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_dent_ChartCanal] as [hDED]
INNER JOIN [oms_dent_RootCanal] as [jT_oms_dent_RootCanal] on [jT_oms_dent_RootCanal].[dent_RootCanalID] = [hDED].[rf_dent_RootCanalID]
INNER JOIN [oms_dent_CanalCondition] as [jT_oms_dent_CanalCondition] on [jT_oms_dent_CanalCondition].[dent_CanalConditionID] = [hDED].[rf_dent_CanalConditionID]
INNER JOIN [hlt_dent_ChartRoot] as [jT_hlt_dent_ChartRoot] on [jT_hlt_dent_ChartRoot].[dent_ChartRootID] = [hDED].[rf_dent_ChartRootID]
go

