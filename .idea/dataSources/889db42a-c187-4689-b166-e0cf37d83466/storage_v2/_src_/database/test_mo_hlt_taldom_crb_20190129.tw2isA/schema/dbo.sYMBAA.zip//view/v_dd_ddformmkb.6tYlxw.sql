CREATE VIEW [V_dd_DDFormMKB] AS SELECT 
[hDED].[DDFormMKBID], [hDED].[x_Edition], [hDED].[x_Status], 
(((Select Name from dd_DDStageDisease where dd_DDStageDisease.UGUID=rf_DDStageDiseaseGUID)  )) as [V_StageD], 
(((Select Name from dd_DDTypeDisease where dd_DDTypeDisease.UGUID=rf_DDTypeDiseaseGUID))) as [V_TypeD], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_DDFormID] as [rf_DDFormID], 
[hDED].[rf_DDTypeDiseaseGUID] as [rf_DDTypeDiseaseGUID], 
[hDED].[rf_DDDiscoveryDiseaseGUID] as [rf_DDDiscoveryDiseaseGUID], 
[hDED].[rf_DDStageDiseaseGUID] as [rf_DDStageDiseaseGUID], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDFormMKB] as [hDED]
go

