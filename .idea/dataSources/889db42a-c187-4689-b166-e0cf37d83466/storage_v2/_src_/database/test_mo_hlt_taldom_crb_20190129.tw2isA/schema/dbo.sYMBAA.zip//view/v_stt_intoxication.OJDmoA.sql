CREATE VIEW [V_stt_Intoxication] AS SELECT 
[hDED].[IntoxicationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Cod] as [Cod], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_Intoxication] as [hDED]
go

