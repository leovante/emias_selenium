CREATE VIEW [V_hlt_UchastokMkabReestr] AS SELECT 
[hDED].[UchastokMkabReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
(((case  [hDED].Status WHEN 0 THEN 'Сформирован' WHEN 1 THEN 'Выгружен' WHEN 2 THEN 'Загружен ФЛК' WHEN 3 THEN 'Загружен ответ' WHEN 4 THEN 'Переформирован' ELSE '' END))) as [V_Status], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_CommonReestrTypeID] as [rf_CommonReestrTypeID], 
[jT_hlt_CommonReestrType].[Name] as [SILENT_rf_CommonReestrTypeID], 
[hDED].[rf_CreateUserID] as [rf_CreateUserID], 
[hDED].[CreateUserName] as [CreateUserName], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[DateAnswer] as [DateAnswer], 
[hDED].[Status] as [Status], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags], 
[hDED].[FileName] as [FileName], 
[hDED].[Num] as [Num], 
[hDED].[Month_Ot] as [Month_Ot], 
[hDED].[Year_OT] as [Year_OT], 
[hDED].[NoticeCount] as [NoticeCount], 
[hDED].[ConfirmCount] as [ConfirmCount], 
[hDED].[RefusalCount] as [RefusalCount], 
[hDED].[FlkCount] as [FlkCount], 
[hDED].[DateUnload] as [DateUnload]
FROM [hlt_UchastokMkabReestr] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [hlt_CommonReestrType] as [jT_hlt_CommonReestrType] on [jT_hlt_CommonReestrType].[CommonReestrTypeID] = [hDED].[rf_CommonReestrTypeID]
go

