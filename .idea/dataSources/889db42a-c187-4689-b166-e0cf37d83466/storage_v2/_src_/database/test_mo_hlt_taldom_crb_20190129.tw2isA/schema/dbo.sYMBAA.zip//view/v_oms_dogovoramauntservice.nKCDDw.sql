CREATE VIEW [V_oms_DogovorAmauntService] AS SELECT 
[hDED].[DogovorAmauntServiceID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_DogovorAmauntTypeID] as [rf_DogovorAmauntTypeID], 
[jT_oms_DogovorAmauntType].[Name] as [SILENT_rf_DogovorAmauntTypeID], 
[hDED].[GUIDDogService] as [GUIDDogService]
FROM [oms_DogovorAmauntService] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_DogovorAmauntType] as [jT_oms_DogovorAmauntType] on [jT_oms_DogovorAmauntType].[DogovorAmauntTypeID] = [hDED].[rf_DogovorAmauntTypeID]
go

