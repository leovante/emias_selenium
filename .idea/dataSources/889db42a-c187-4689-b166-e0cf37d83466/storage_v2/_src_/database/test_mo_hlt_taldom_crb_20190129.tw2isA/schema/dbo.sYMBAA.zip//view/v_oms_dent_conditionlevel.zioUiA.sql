CREATE VIEW [V_oms_dent_ConditionLevel] AS SELECT 
[hDED].[dent_ConditionLevelID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidConditionLevel], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [oms_dent_ConditionLevel] as [hDED]
go

