CREATE VIEW [V_hlt_TypeAttachment] AS SELECT 
[hDED].[TypeAttachmentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_TypeAttachment] as [hDED]
go

