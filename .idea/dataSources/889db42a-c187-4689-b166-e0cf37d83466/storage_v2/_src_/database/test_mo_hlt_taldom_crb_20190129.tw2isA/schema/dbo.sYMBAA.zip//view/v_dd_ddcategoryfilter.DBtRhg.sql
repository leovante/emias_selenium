CREATE VIEW [V_dd_DDCategoryFilter] AS SELECT 
[hDED].[DDCategoryFilterID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[CategoryCode] as [CategoryCode], 
[hDED].[CategoryFilter] as [CategoryFilter], 
[hDED].[CategoryName] as [CategoryName]
FROM [dd_DDCategoryFilter] as [hDED]
go

