CREATE VIEW [V_ehr_Specialities] AS SELECT 
[hDED].[SpecialitiesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SpecialityId] as [rf_SpecialityId], 
[hDED].[rf_TemplateID] as [rf_TemplateID], 
[hDED].[Guid] as [Guid]
FROM [ehr_Specialities] as [hDED]
go

