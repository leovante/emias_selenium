CREATE TRIGGER [LifeTrigger_hlt_MKAB] ON [hlt_MKAB] FOR DELETE,INSERT,UPDATE
AS 

SET NOCOUNT ON;

DECLARE @userId INT
DECLARE @seanceId INT 

DECLARE @docTypeId INT 
DECLARE @CURDATE DATETIME


declare @app varchar(50)
declare @index1 int
declare @index2 int


/* @userId, @seanceId */

SET @userId = 0
SET @seanceId = 0

EXEC [GetMalibuContext] @seanceId = @seanceId OUTPUT, @userId = @userId OUTPUT

/* @docTypeId */

SET @CURDATE = getdate()

SET @docTypeId = 0

SELECT TOP 1 @docTypeId = [DocTypeDefID], @seanceId=case WHEN [x_STDO].[HostID] IS NULL THEN @seanceId ELSE 0 END
FROM [x_DocTypeDef] left join [x_STDO] on [x_DocTypeDef].[GUID] = [x_STDO].[DocTypeDef] 
WHERE [HeadTable] = 'hlt_MKAB'

/* action type */

DECLARE @DEL BIT
DECLARE @INS BIT 

DECLARE @action CHAR(1)


SET @DEL = 0
SET @INS = 0


IF EXISTS (SELECT TOP 1 1 FROM DELETED) SET @DEL=1
IF EXISTS (SELECT TOP 1 1 FROM INSERTED) SET @INS = 1 

IF @INS = 1 AND @DEL = 1 SET @ACTION = 'u'
IF @INS = 1 AND @DEL = 0 SET @ACTION = 'i'
IF @INS = 0 AND @DEL = 1 SET @ACTION = 'd'


IF @ACTION = 'd'
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [MKABID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM deleted;

	INSERT INTO Life_hlt_MKAB([MKABID],[AdresFact],[Birthplace],[BlackLabel],[BlackLabelComment],[COD_Person],[ConfirmAgree],[ConfirmDate],[ConfirmUserFIO],[contactConfirm],[contactEmail],[contactMPhone],[CreateUserName],[D_TYPE],[DATE_BD],[DateClose],[DateDoc],[DateMKAB],[DatePolBegin],[DatePolEnd],[Dependent],[DocIssuedBy],[EditUserName],[FAMILY],[FLAGS],[Group],[Hash0],[Hash1],[Hash2],[Hash3],[Hash4],[IdentificationDate],[INN],[isAuto],[isClosed],[isEncrypted],[isExistIPRA],[isLSHome],[IsNoEmail],[IsNoPhone],[IsWorker],[KindCod],[mainContact],[MainMKABGuid],[MedIntervention],[MessageFLAG],[MilitaryCOD],[ADRES],[MKABInfo],[N_DOC],[N_POL],[NAME],[NUM],[OT],[PhoneHome],[PhoneWork],[Post],[Profession],[Qualification],[rf_AddressLiveID],[rf_AddressRegID],[rf_AddressWorkID],[rf_CitizenID],[rf_ConfirmUserID],[rf_CreateUserID],[rf_EditUserID],[rf_EnterpriseID],[rf_GroupOfBloodID],[rf_IdentificationStatusID],[rf_INVID],[rf_kl_EducationTypeID],[rf_kl_HealthGroupID],[rf_kl_MaterialStatusID],[rf_kl_PrivilegeCategoryID],[rf_kl_SexID],[rf_kl_SocStatusID],[rf_kl_TipOMSID],[rf_LPUID],[rf_MilitaryDutyID],[rf_MKABLocationID],[rf_OKATOID],[rf_OKSMID],[rf_omsOKVEDID],[rf_OtherSMOID],[rf_ReasonCloseMKABID],[rf_SMOID],[rf_SpecEventCertID],[rf_TYPEDOCID],[rf_UchastokID],[RH],[Rhesus],[RIDN],[S_DOC],[S_POL],[SS],[UGUID],[W],[Work],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [MKABID],[AdresFact],[Birthplace],[BlackLabel],[BlackLabelComment],[COD_Person],[ConfirmAgree],[ConfirmDate],[ConfirmUserFIO],[contactConfirm],[contactEmail],[contactMPhone],[CreateUserName],[D_TYPE],[DATE_BD],[DateClose],[DateDoc],[DateMKAB],[DatePolBegin],[DatePolEnd],[Dependent],[DocIssuedBy],[EditUserName],[FAMILY],[FLAGS],[Group],[Hash0],[Hash1],[Hash2],[Hash3],[Hash4],[IdentificationDate],[INN],[isAuto],[isClosed],[isEncrypted],[isExistIPRA],[isLSHome],[IsNoEmail],[IsNoPhone],[IsWorker],[KindCod],[mainContact],[MainMKABGuid],[MedIntervention],[MessageFLAG],[MilitaryCOD],[ADRES],[MKABInfo],[N_DOC],[N_POL],[NAME],[NUM],[OT],[PhoneHome],[PhoneWork],[Post],[Profession],[Qualification],[rf_AddressLiveID],[rf_AddressRegID],[rf_AddressWorkID],[rf_CitizenID],[rf_ConfirmUserID],[rf_CreateUserID],[rf_EditUserID],[rf_EnterpriseID],[rf_GroupOfBloodID],[rf_IdentificationStatusID],[rf_INVID],[rf_kl_EducationTypeID],[rf_kl_HealthGroupID],[rf_kl_MaterialStatusID],[rf_kl_PrivilegeCategoryID],[rf_kl_SexID],[rf_kl_SocStatusID],[rf_kl_TipOMSID],[rf_LPUID],[rf_MilitaryDutyID],[rf_MKABLocationID],[rf_OKATOID],[rf_OKSMID],[rf_omsOKVEDID],[rf_OtherSMOID],[rf_ReasonCloseMKABID],[rf_SMOID],[rf_SpecEventCertID],[rf_TYPEDOCID],[rf_UchastokID],[RH],[Rhesus],[RIDN],[S_DOC],[S_POL],[SS],[UGUID],[W],[Work],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM deleted;
END;
ELSE
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [MKABID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM inserted;

	INSERT INTO Life_hlt_MKAB([MKABID],[AdresFact],[Birthplace],[BlackLabel],[BlackLabelComment],[COD_Person],[ConfirmAgree],[ConfirmDate],[ConfirmUserFIO],[contactConfirm],[contactEmail],[contactMPhone],[CreateUserName],[D_TYPE],[DATE_BD],[DateClose],[DateDoc],[DateMKAB],[DatePolBegin],[DatePolEnd],[Dependent],[DocIssuedBy],[EditUserName],[FAMILY],[FLAGS],[Group],[Hash0],[Hash1],[Hash2],[Hash3],[Hash4],[IdentificationDate],[INN],[isAuto],[isClosed],[isEncrypted],[isExistIPRA],[isLSHome],[IsNoEmail],[IsNoPhone],[IsWorker],[KindCod],[mainContact],[MainMKABGuid],[MedIntervention],[MessageFLAG],[MilitaryCOD],[ADRES],[MKABInfo],[N_DOC],[N_POL],[NAME],[NUM],[OT],[PhoneHome],[PhoneWork],[Post],[Profession],[Qualification],[rf_AddressLiveID],[rf_AddressRegID],[rf_AddressWorkID],[rf_CitizenID],[rf_ConfirmUserID],[rf_CreateUserID],[rf_EditUserID],[rf_EnterpriseID],[rf_GroupOfBloodID],[rf_IdentificationStatusID],[rf_INVID],[rf_kl_EducationTypeID],[rf_kl_HealthGroupID],[rf_kl_MaterialStatusID],[rf_kl_PrivilegeCategoryID],[rf_kl_SexID],[rf_kl_SocStatusID],[rf_kl_TipOMSID],[rf_LPUID],[rf_MilitaryDutyID],[rf_MKABLocationID],[rf_OKATOID],[rf_OKSMID],[rf_omsOKVEDID],[rf_OtherSMOID],[rf_ReasonCloseMKABID],[rf_SMOID],[rf_SpecEventCertID],[rf_TYPEDOCID],[rf_UchastokID],[RH],[Rhesus],[RIDN],[S_DOC],[S_POL],[SS],[UGUID],[W],[Work],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [MKABID],[AdresFact],[Birthplace],[BlackLabel],[BlackLabelComment],[COD_Person],[ConfirmAgree],[ConfirmDate],[ConfirmUserFIO],[contactConfirm],[contactEmail],[contactMPhone],[CreateUserName],[D_TYPE],[DATE_BD],[DateClose],[DateDoc],[DateMKAB],[DatePolBegin],[DatePolEnd],[Dependent],[DocIssuedBy],[EditUserName],[FAMILY],[FLAGS],[Group],[Hash0],[Hash1],[Hash2],[Hash3],[Hash4],[IdentificationDate],[INN],[isAuto],[isClosed],[isEncrypted],[isExistIPRA],[isLSHome],[IsNoEmail],[IsNoPhone],[IsWorker],[KindCod],[mainContact],[MainMKABGuid],[MedIntervention],[MessageFLAG],[MilitaryCOD],[ADRES],[MKABInfo],[N_DOC],[N_POL],[NAME],[NUM],[OT],[PhoneHome],[PhoneWork],[Post],[Profession],[Qualification],[rf_AddressLiveID],[rf_AddressRegID],[rf_AddressWorkID],[rf_CitizenID],[rf_ConfirmUserID],[rf_CreateUserID],[rf_EditUserID],[rf_EnterpriseID],[rf_GroupOfBloodID],[rf_IdentificationStatusID],[rf_INVID],[rf_kl_EducationTypeID],[rf_kl_HealthGroupID],[rf_kl_MaterialStatusID],[rf_kl_PrivilegeCategoryID],[rf_kl_SexID],[rf_kl_SocStatusID],[rf_kl_TipOMSID],[rf_LPUID],[rf_MilitaryDutyID],[rf_MKABLocationID],[rf_OKATOID],[rf_OKSMID],[rf_omsOKVEDID],[rf_OtherSMOID],[rf_ReasonCloseMKABID],[rf_SMOID],[rf_SpecEventCertID],[rf_TYPEDOCID],[rf_UchastokID],[RH],[Rhesus],[RIDN],[S_DOC],[S_POL],[SS],[UGUID],[W],[Work],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM inserted;
END; 

SET NOCOUNT OFF;


go

