CREATE VIEW [V_lbr_Container] AS SELECT 
[hDED].[ContainerID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Type] as [Type], 
[hDED].[TextID] as [TextID], 
[hDED].[Description] as [Description], 
[hDED].[TransportType] as [TransportType], 
[hDED].[Preanalytic] as [Preanalytic], 
[hDED].[BiomaterialName] as [BiomaterialName], 
[hDED].[TransportTemperature] as [TransportTemperature], 
[hDED].[PrimaryType] as [PrimaryType]
FROM [lbr_Container] as [hDED]
go

