CREATE VIEW [V_oms_ExpertKSGCritMNN] AS SELECT 
[hDED].[ExpertKSGCritMNNID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MNNameID] as [rf_MNNameID], 
[jT_oms_MNName].[NAME_MNN] as [SILENT_rf_MNNameID], 
[hDED].[rf_ExpertKSGCriterionID] as [rf_ExpertKSGCriterionID], 
[hDED].[rf_onco_N021ID] as [rf_onco_N021ID], 
[jT_oms_onco_N021].[ID_ZAP] as [SILENT_rf_onco_N021ID], 
[hDED].[rf_onco_N020ID] as [rf_onco_N020ID], 
[jT_oms_onco_N020].[MNN] as [SILENT_rf_onco_N020ID], 
[hDED].[Flags] as [Flags], 
[hDED].[ExpertKSGCritMNNGUID] as [ExpertKSGCritMNNGUID]
FROM [oms_ExpertKSGCritMNN] as [hDED]
INNER JOIN [oms_MNName] as [jT_oms_MNName] on [jT_oms_MNName].[MNNameID] = [hDED].[rf_MNNameID]
INNER JOIN [oms_onco_N021] as [jT_oms_onco_N021] on [jT_oms_onco_N021].[onco_N021ID] = [hDED].[rf_onco_N021ID]
INNER JOIN [oms_onco_N020] as [jT_oms_onco_N020] on [jT_oms_onco_N020].[onco_N020ID] = [hDED].[rf_onco_N020ID]
go

