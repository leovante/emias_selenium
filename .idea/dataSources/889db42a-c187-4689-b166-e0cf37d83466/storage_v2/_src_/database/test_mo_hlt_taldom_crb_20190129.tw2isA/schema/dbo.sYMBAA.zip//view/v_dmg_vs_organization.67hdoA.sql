CREATE VIEW [V_dmg_vs_Organization] AS SELECT 
[hDED].[vs_OrganizationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Inn] as [Inn], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dmg_vs_Organization] as [hDED]
go

