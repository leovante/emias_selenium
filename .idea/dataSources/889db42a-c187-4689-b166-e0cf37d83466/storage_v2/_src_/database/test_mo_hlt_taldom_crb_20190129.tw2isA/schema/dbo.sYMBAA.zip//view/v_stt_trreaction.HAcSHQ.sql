CREATE VIEW [V_stt_TrReaction] AS SELECT 
[hDED].[TrReactionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReactionTypeID] as [rf_ReactionTypeID], 
[jT_stt_ReactionType].[Name] as [SILENT_rf_ReactionTypeID], 
[hDED].[rf_TransfusionID] as [rf_TransfusionID], 
[jT_stt_Transfusion].[rf_MedicalHistoryID] as [SILENT_rf_TransfusionID], 
[hDED].[RDate] as [RDate], 
[hDED].[Description] as [Description], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flags] as [flags]
FROM [stt_TrReaction] as [hDED]
INNER JOIN [stt_ReactionType] as [jT_stt_ReactionType] on [jT_stt_ReactionType].[ReactionTypeID] = [hDED].[rf_ReactionTypeID]
INNER JOIN [stt_Transfusion] as [jT_stt_Transfusion] on [jT_stt_Transfusion].[TransfusionID] = [hDED].[rf_TransfusionID]
go

