CREATE VIEW [V_oms_onco_N008] AS SELECT 
[hDED].[onco_N008ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_onco_N007ID] as [rf_onco_N007ID], 
[jT_oms_onco_N007].[Mrf_NAME] as [SILENT_rf_onco_N007ID], 
[hDED].[ID_R_M] as [ID_R_M], 
[hDED].[R_M_NAME] as [R_M_NAME], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN008] as [GUIDN008]
FROM [oms_onco_N008] as [hDED]
INNER JOIN [oms_onco_N007] as [jT_oms_onco_N007] on [jT_oms_onco_N007].[onco_N007ID] = [hDED].[rf_onco_N007ID]
go

