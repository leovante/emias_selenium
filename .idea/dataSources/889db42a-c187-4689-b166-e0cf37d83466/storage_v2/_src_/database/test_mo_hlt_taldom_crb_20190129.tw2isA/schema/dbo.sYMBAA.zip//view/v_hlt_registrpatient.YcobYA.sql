CREATE VIEW [V_hlt_RegistrPatient] AS SELECT 
[hDED].[RegistrPatientID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_MKAB].[NAME] as [V_NAME], 
[jT_hlt_MKAB].[OT] as [V_OT], 
[jT_hlt_MKAB].[DATE_BD] as [V_Birthday], 
[jT_hlt_MKAB].[FAMILY] as [V_FAMILY], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_ReasonCloseMKABID] as [rf_ReasonCloseMKABID], 
[jT_hlt_ReasonCloseMKAB].[Reason] as [SILENT_rf_ReasonCloseMKABID], 
[hDED].[rf_RegistrTypeID] as [rf_RegistrTypeID], 
[jT_hlt_RegistrType].[Name] as [SILENT_rf_RegistrTypeID], 
[hDED].[Num] as [Num], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[DateClose] as [DateClose], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_RegistrPatient] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_ReasonCloseMKAB] as [jT_hlt_ReasonCloseMKAB] on [jT_hlt_ReasonCloseMKAB].[ReasonCloseMKABID] = [hDED].[rf_ReasonCloseMKABID]
INNER JOIN [hlt_RegistrType] as [jT_hlt_RegistrType] on [jT_hlt_RegistrType].[RegistrTypeID] = [hDED].[rf_RegistrTypeID]
go

