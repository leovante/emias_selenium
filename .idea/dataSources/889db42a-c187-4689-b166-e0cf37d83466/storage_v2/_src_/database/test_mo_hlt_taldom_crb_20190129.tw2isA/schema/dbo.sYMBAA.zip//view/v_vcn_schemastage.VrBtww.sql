CREATE VIEW [V_vcn_SchemaStage] AS SELECT 
[hDED].[SchemaStageID], [hDED].[x_Edition], [hDED].[x_Status], 
(('лет: ' + cast([hDED].[intervalMinY] as varchar) + ', мес.: ' + cast([hDED].[intervalMinM] as varchar) + ', дн.: ' + cast([hDED].[intervalMinD] as varchar))) as [V_IntervalMin], 
('лет: ' + cast([hDED].[ageMinY] as varchar) + ', мес.: ' + cast([hDED].[ageMinM] as varchar) + ', дн.: ' + cast([hDED].[ageMinD] as varchar)) as [V_AgeMin], 
[jT_vcn_VaccineType].[GUID] as [V_VaccineTypeGuid], 
[jT_vcn_Schema].[GUID] as [V_SchemaGuid], 
[jT_vcn_VaccinationType].[Code] as [V_PrevVaccinationTypeCode], 
[jT_vcn_VaccinationType1].[Code] as [V_NextVaccinationTypeCode], 
[hDED].[rf_PrevVaccinationTypeID] as [rf_PrevVaccinationTypeID], 
[jT_vcn_VaccinationType].[ShortName] as [SILENT_rf_PrevVaccinationTypeID], 
[hDED].[rf_NextVaccinationTypeID] as [rf_NextVaccinationTypeID], 
[jT_vcn_VaccinationType].[ShortName] as [SILENT_rf_NextVaccinationTypeID], 
[hDED].[rf_VaccineTypeID] as [rf_VaccineTypeID], 
[jT_vcn_VaccineType].[Name] as [SILENT_rf_VaccineTypeID], 
[hDED].[rf_SchemaID] as [rf_SchemaID], 
[hDED].[GUID] as [GUID], 
[hDED].[intervalMinY] as [intervalMinY], 
[hDED].[intervalMinM] as [intervalMinM], 
[hDED].[intervalMinD] as [intervalMinD], 
[hDED].[ageMinY] as [ageMinY], 
[hDED].[ageMinM] as [ageMinM], 
[hDED].[ageMinD] as [ageMinD]
FROM [vcn_SchemaStage] as [hDED]
INNER JOIN [vcn_VaccineType] as [jT_vcn_VaccineType] on [jT_vcn_VaccineType].[VaccineTypeID] = [hDED].[rf_VaccineTypeID]
INNER JOIN [vcn_Schema] as [jT_vcn_Schema] on [jT_vcn_Schema].[SchemaID] = [hDED].[rf_SchemaID]
INNER JOIN [vcn_VaccinationType] as [jT_vcn_VaccinationType] on [jT_vcn_VaccinationType].[VaccinationTypeID] = [hDED].[rf_PrevVaccinationTypeID]
INNER JOIN [vcn_VaccinationType] as [jT_vcn_VaccinationType1] on [jT_vcn_VaccinationType1].[VaccinationTypeID] = [hDED].[rf_NextVaccinationTypeID]
go

