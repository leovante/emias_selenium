CREATE VIEW [V_oms_Egisz_Nfv] AS SELECT 
[hDED].[Egisz_NfvID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[id] as [id], 
[hDED].[Code] as [Code], 
[hDED].[Value] as [Value]
FROM [oms_Egisz_Nfv] as [hDED]
go

