CREATE VIEW [V_onco_Talon] AS SELECT 
[hDED].[TalonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[jT_stt_MigrationPatient].[rf_StationarBranchID] as [SILENT_rf_MigrationPatientID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_onco_N002ID] as [rf_onco_N002ID], 
[hDED].[rf_onco_N003ID] as [rf_onco_N003ID], 
[hDED].[rf_onco_N004ID] as [rf_onco_N004ID], 
[hDED].[rf_onco_N005ID] as [rf_onco_N005ID], 
[hDED].[rf_onco_N018ID] as [rf_onco_N018ID], 
[jT_oms_onco_N018].[Reas_Name] as [SILENT_rf_onco_N018ID], 
[hDED].[Mtstz] as [Mtstz], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[VisitReason] as [VisitReason], 
[hDED].[Revealed] as [Revealed]
FROM [onco_Talon] as [hDED]
INNER JOIN [stt_MigrationPatient] as [jT_stt_MigrationPatient] on [jT_stt_MigrationPatient].[MigrationPatientID] = [hDED].[rf_MigrationPatientID]
INNER JOIN [oms_onco_N018] as [jT_oms_onco_N018] on [jT_oms_onco_N018].[onco_N018ID] = [hDED].[rf_onco_N018ID]
go

