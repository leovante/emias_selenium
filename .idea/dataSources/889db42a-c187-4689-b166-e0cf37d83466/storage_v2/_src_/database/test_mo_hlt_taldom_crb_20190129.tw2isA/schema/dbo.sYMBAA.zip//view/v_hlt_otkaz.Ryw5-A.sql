CREATE VIEW [V_hlt_OTKAZ] AS SELECT 
[hDED].[OTKAZID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[GRUP_MIST] as [GRUP_MIST], 
[hDED].[CODE_MIST] as [CODE_MIST], 
[hDED].[STAT_MIST] as [STAT_MIST], 
[hDED].[NAME_MIST] as [NAME_MIST], 
[hDED].[CODE_LOCAL] as [CODE_LOCAL], 
[hDED].[MSG_TEXT] as [MSG_TEXT]
FROM [hlt_OTKAZ] as [hDED]
go

