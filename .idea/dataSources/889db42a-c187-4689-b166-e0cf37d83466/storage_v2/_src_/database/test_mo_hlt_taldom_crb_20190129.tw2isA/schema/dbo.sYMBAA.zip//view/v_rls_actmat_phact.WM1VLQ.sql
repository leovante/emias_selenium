CREATE VIEW [V_rls_ActMat_PhAct] AS SELECT 
[hDED].[ActMat_PhActID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PharmaActionsUID] as [rf_PharmaActionsUID], 
[hDED].[rf_ActMattersUID] as [rf_ActMattersUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[Number] as [Number], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_ActMat_PhAct] as [hDED]
go

