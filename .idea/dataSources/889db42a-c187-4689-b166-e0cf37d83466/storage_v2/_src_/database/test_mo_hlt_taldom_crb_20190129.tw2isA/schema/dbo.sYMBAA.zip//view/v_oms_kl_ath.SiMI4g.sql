CREATE VIEW [V_oms_kl_ATH] AS SELECT 
[hDED].[kl_ATHID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_ATHID] as [rf_kl_ATHID], 
[hDED].[rf_GuidATH] as [rf_GuidATH], 
[hDED].[C_ATH] as [C_ATH], 
[hDED].[Name_ATH] as [Name_ATH], 
[hDED].[Name_ATH_L] as [Name_ATH_L], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[GuidATH] as [GuidATH]
FROM [oms_kl_ATH] as [hDED]
go

