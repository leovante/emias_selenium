CREATE VIEW [V_oms_SMReestrExecute] AS SELECT 
[hDED].[SMReestrExecuteID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[GUID] as [GUID], 
[hDED].[Type] as [Type], 
[hDED].[FuncName] as [FuncName], 
[hDED].[isActive] as [isActive], 
[hDED].[Rem] as [Rem], 
[hDED].[LoadFilePath] as [LoadFilePath], 
[hDED].[UnLoadFilePath] as [UnLoadFilePath]
FROM [oms_SMReestrExecute] as [hDED]
go

