CREATE VIEW [V_oms_sc_StandartCure] AS SELECT 
[hDED].[sc_StandartCureID], [hDED].[x_Edition], [hDED].[x_Status], 
(StandartCode) as [V_sc_StandartCure], 
(case ComplicationType when 1 then 'Любое' when 2 then 'Вне зависимости от осложнений' when 3 then 'Указанные осложнения' else 'Без осложнений' end) as [V_ComplicationType], 
[hDED].[rf_kl_AgeGroupID] as [rf_kl_AgeGroupID], 
[jT_oms_kl_AgeGroup].[Name] as [SILENT_rf_kl_AgeGroupID], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[rf_kl_MHConditionID] as [rf_kl_MHConditionID], 
[jT_oms_kl_MHCondition].[Name] as [SILENT_rf_kl_MHConditionID], 
[hDED].[rf_sc_ServiceTypeID] as [rf_sc_ServiceTypeID], 
[jT_oms_sc_ServiceType].[Name] as [SILENT_rf_sc_ServiceTypeID], 
[hDED].[StandartName] as [StandartName], 
[hDED].[StandartCode] as [StandartCode], 
[hDED].[Duration] as [Duration], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Description] as [Description], 
[hDED].[Unit] as [Unit], 
[hDED].[ComplicationType] as [ComplicationType], 
[hDED].[Date_B] as [Date_B], 
[hDED].[StandartSource] as [StandartSource], 
[hDED].[StandartSourceInfo] as [StandartSourceInfo], 
[hDED].[Date_E] as [Date_E], 
[hDED].[FCod_ST] as [FCod_ST]
FROM [oms_sc_StandartCure] as [hDED]
INNER JOIN [oms_kl_AgeGroup] as [jT_oms_kl_AgeGroup] on [jT_oms_kl_AgeGroup].[kl_AgeGroupID] = [hDED].[rf_kl_AgeGroupID]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
INNER JOIN [oms_kl_MHCondition] as [jT_oms_kl_MHCondition] on [jT_oms_kl_MHCondition].[kl_MHConditionID] = [hDED].[rf_kl_MHConditionID]
INNER JOIN [oms_sc_ServiceType] as [jT_oms_sc_ServiceType] on [jT_oms_sc_ServiceType].[sc_ServiceTypeID] = [hDED].[rf_sc_ServiceTypeID]
go

