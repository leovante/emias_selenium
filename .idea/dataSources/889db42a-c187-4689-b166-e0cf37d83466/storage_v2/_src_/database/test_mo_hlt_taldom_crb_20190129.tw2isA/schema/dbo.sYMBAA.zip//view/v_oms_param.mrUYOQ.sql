CREATE VIEW [V_oms_Param] AS SELECT 
[hDED].[ParamID], [hDED].[x_Edition], [hDED].[x_Status], 
((hDED.Code)) as [V_ParamCode], 
[hDED].[rf_UnitID] as [rf_UnitID], 
[jT_oms_Unit].[Name] as [SILENT_rf_UnitID], 
[hDED].[rf_ParamTypeID] as [rf_ParamTypeID], 
[jT_oms_ParamType].[Name] as [SILENT_rf_ParamTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[MinValue] as [MinValue], 
[hDED].[MaxValue] as [MaxValue], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags], 
[hDED].[Mask] as [Mask], 
[hDED].[IsComplex] as [IsComplex], 
[hDED].[IsReferal] as [IsReferal], 
[hDED].[rf_ContextGUID] as [rf_ContextGUID]
FROM [oms_Param] as [hDED]
INNER JOIN [oms_Unit] as [jT_oms_Unit] on [jT_oms_Unit].[UnitID] = [hDED].[rf_UnitID]
INNER JOIN [oms_ParamType] as [jT_oms_ParamType] on [jT_oms_ParamType].[ParamTypeID] = [hDED].[rf_ParamTypeID]
go

