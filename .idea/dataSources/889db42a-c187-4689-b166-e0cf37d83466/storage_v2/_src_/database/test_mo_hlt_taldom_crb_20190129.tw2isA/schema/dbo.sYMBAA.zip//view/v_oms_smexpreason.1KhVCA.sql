CREATE VIEW [V_oms_SMExpReason] AS SELECT 
[hDED].[SMExpReasonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[NameExpReason] as [NameExpReason]
FROM [oms_SMExpReason] as [hDED]
go

