CREATE VIEW [V_oms_TenderAdd] AS SELECT 
[hDED].[TenderAddID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[hDED].[Sum] as [Sum], 
[hDED].[Num] as [Num], 
[hDED].[Dt] as [Dt], 
[hDED].[Info] as [Info], 
[hDED].[Rem] as [Rem], 
[hDED].[Xml_Price] as [Xml_Price], 
[hDED].[XML_Post] as [XML_Post]
FROM [oms_TenderAdd] as [hDED]
go

