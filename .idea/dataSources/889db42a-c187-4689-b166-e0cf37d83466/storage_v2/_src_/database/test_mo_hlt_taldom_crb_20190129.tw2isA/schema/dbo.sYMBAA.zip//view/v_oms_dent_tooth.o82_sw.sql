CREATE VIEW [V_oms_dent_Tooth] AS SELECT 
[hDED].[dent_ToothID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidTooth], 
[hDED].[rf_dent_ToothTypeID] as [rf_dent_ToothTypeID], 
[jT_oms_dent_ToothType].[Name] as [SILENT_rf_dent_ToothTypeID], 
[hDED].[rf_dent_SectorID] as [rf_dent_SectorID], 
[jT_oms_dent_Sector].[Name] as [SILENT_rf_dent_SectorID], 
[hDED].[Number] as [Number], 
[hDED].[Root_max] as [Root_max], 
[hDED].[Canal_max] as [Canal_max], 
[hDED].[IsChild] as [IsChild], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [oms_dent_Tooth] as [hDED]
INNER JOIN [oms_dent_ToothType] as [jT_oms_dent_ToothType] on [jT_oms_dent_ToothType].[dent_ToothTypeID] = [hDED].[rf_dent_ToothTypeID]
INNER JOIN [oms_dent_Sector] as [jT_oms_dent_Sector] on [jT_oms_dent_Sector].[dent_SectorID] = [hDED].[rf_dent_SectorID]
go

