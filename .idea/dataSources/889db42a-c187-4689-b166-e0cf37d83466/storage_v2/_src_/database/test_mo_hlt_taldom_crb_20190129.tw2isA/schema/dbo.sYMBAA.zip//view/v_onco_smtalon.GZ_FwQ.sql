CREATE VIEW [V_onco_SmTalon] AS SELECT 
[hDED].[SmTalonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_SMTAPID] as [rf_SMTAPID], 
[hDED].[rf_MedServicePatientID] as [rf_MedServicePatientID], 
[hDED].[rf_onco_N013ID] as [rf_onco_N013ID], 
[hDED].[rf_onco_N014ID] as [rf_onco_N014ID], 
[hDED].[rf_onco_N015ID] as [rf_onco_N015ID], 
[hDED].[rf_onco_N016ID] as [rf_onco_N016ID], 
[hDED].[rf_onco_N017ID] as [rf_onco_N017ID], 
[hDED].[rf_TalonID] as [rf_TalonID], 
[jT_onco_Talon].[rf_TAPID] as [SILENT_rf_TalonID], 
[hDED].[PrCons] as [PrCons], 
[hDED].[Sod] as [Sod], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[K_FR] as [K_FR], 
[hDED].[WEI] as [WEI], 
[hDED].[HEI] as [HEI], 
[hDED].[BSA] as [BSA], 
[hDED].[PPTR] as [PPTR]
FROM [onco_SmTalon] as [hDED]
INNER JOIN [onco_Talon] as [jT_onco_Talon] on [jT_onco_Talon].[TalonID] = [hDED].[rf_TalonID]
go

