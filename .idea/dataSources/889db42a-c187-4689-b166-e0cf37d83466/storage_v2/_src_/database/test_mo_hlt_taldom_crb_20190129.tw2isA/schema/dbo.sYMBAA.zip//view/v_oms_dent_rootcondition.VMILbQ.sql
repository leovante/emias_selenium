CREATE VIEW [V_oms_dent_RootCondition] AS SELECT 
[hDED].[dent_RootConditionID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidRootCondition], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [oms_dent_RootCondition] as [hDED]
go

