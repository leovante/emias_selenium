CREATE VIEW [V_oms_LG_Def] AS SELECT 
[hDED].[LG_DefID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_KATL].[NAME] as [V_NAMEKatl], 
[jT_oms_Finl].[NAME] as [V_NAMEFinl], 
[jT_oms_Account].[PAID] as [V_PAID], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[hDED].[rf_PR_LRID] as [rf_PR_LRID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID]
FROM [oms_LG_Def] as [hDED]
INNER JOIN [oms_KATL] as [jT_oms_KATL] on [jT_oms_KATL].[KATLID] = [hDED].[rf_KATLID]
INNER JOIN [oms_Finl] as [jT_oms_Finl] on [jT_oms_Finl].[FinlID] = [hDED].[rf_FinlID]
INNER JOIN [oms_Account] as [jT_oms_Account] on [jT_oms_Account].[AccountID] = [hDED].[rf_PR_LRID]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
go

