CREATE VIEW [V_oms_SMReestrNAZ] AS SELECT 
[hDED].[SMReestrNAZID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[NAZ_R] as [NAZ_R], 
[hDED].[NAZ_SP] as [NAZ_SP], 
[hDED].[NAZ_V] as [NAZ_V], 
[hDED].[NAZ_N] as [NAZ_N], 
[hDED].[NAZ_PMP] as [NAZ_PMP], 
[hDED].[NAZ_PK] as [NAZ_PK]
FROM [oms_SMReestrNAZ] as [hDED]
go

