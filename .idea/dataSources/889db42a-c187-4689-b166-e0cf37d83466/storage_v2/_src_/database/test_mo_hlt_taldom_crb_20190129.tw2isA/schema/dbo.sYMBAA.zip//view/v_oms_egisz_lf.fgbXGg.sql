CREATE VIEW [V_oms_Egisz_Lf] AS SELECT 
[hDED].[Egisz_LfID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Uid] as [Uid]
FROM [oms_Egisz_Lf] as [hDED]
go

