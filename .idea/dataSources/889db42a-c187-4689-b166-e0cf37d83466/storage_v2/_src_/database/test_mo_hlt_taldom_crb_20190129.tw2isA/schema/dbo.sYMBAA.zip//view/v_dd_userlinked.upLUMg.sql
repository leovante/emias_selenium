CREATE VIEW [V_dd_UserLinked] AS SELECT 
[hDED].[UserLinkedID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrganizationUGUID] as [rf_OrganizationUGUID], 
[hDED].[rf_PersonOrgUGUID] as [rf_PersonOrgUGUID], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[TypeLinked] as [TypeLinked], 
[hDED].[rf_MalibuUserID] as [rf_MalibuUserID]
FROM [dd_UserLinked] as [hDED]
go

