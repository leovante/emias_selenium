CREATE VIEW [V_dmg_vs_Vacation] AS SELECT 
[hDED].[vs_VacationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_vs_VacationTypeID] as [rf_vs_VacationTypeID], 
[hDED].[rf_vs_MedicalCertificateID] as [rf_vs_MedicalCertificateID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dmg_vs_Vacation] as [hDED]
go

