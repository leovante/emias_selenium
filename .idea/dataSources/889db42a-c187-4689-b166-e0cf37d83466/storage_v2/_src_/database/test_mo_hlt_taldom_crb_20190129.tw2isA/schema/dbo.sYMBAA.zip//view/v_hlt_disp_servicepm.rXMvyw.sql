CREATE VIEW [V_hlt_disp_ServicePM] AS SELECT 
[hDED].[disp_ServicePMID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_DDServiceID] as [rf_kl_DDServiceID], 
[hDED].[rf_PatientModelGuid] as [rf_PatientModelGuid], 
[jT_hlt_disp_PatientModel].[Code] as [SILENT_rf_PatientModelGuid], 
[hDED].[rf_ServiceGuid] as [rf_ServiceGuid], 
[jT_hlt_disp_Service].[Name] as [SILENT_rf_ServiceGuid], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Level] as [Level], 
[hDED].[IsTap] as [IsTap], 
[hDED].[IsRequiredSM] as [IsRequiredSM], 
[hDED].[IsConclusion] as [IsConclusion]
FROM [hlt_disp_ServicePM] as [hDED]
INNER JOIN [hlt_disp_PatientModel] as [jT_hlt_disp_PatientModel] on [jT_hlt_disp_PatientModel].[Guid] = [hDED].[rf_PatientModelGuid]
INNER JOIN [hlt_disp_Service] as [jT_hlt_disp_Service] on [jT_hlt_disp_Service].[Guid] = [hDED].[rf_ServiceGuid]
go

