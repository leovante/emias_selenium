CREATE VIEW [V_hlt_mkp_ImpDiagnos] AS SELECT 
[hDED].[mkp_ImpDiagnosID], [hDED].[x_Edition], [hDED].[x_Status], 
([hded].Code + ' - ' + [hded].Name) as [V_Descr], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Name] as [Name], 
[hDED].[Color] as [Color], 
[hDED].[Flags] as [Flags], 
[hDED].[Code] as [Code]
FROM [hlt_mkp_ImpDiagnos] as [hDED]
go

