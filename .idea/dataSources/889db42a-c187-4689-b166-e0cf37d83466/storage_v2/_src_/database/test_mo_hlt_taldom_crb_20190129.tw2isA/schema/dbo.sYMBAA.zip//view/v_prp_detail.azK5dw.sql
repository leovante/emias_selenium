CREATE VIEW [V_prp_Detail] AS SELECT 
[hDED].[DetailID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PurposeID] as [rf_PurposeID], 
[hDED].[rf_PositionID] as [rf_PositionID], 
[jT_prp_Position].[DateComplete] as [SILENT_rf_PositionID], 
[hDED].[Description] as [Description], 
[hDED].[Flag] as [Flag], 
[hDED].[rf_DocRecordID] as [rf_DocRecordID], 
[hDED].[rf_DocTypeDefID] as [rf_DocTypeDefID]
FROM [prp_Detail] as [hDED]
INNER JOIN [prp_Position] as [jT_prp_Position] on [jT_prp_Position].[PositionID] = [hDED].[rf_PositionID]
go

