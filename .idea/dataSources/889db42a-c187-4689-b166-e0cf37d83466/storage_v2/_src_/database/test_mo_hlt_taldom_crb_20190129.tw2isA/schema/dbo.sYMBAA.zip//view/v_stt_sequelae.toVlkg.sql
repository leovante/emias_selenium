CREATE VIEW [V_stt_Sequelae] AS SELECT 
[hDED].[SequelaeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SequelaeTypeID] as [rf_SequelaeTypeID], 
[jT_stt_SequelaeType].[Name] as [SILENT_rf_SequelaeTypeID], 
[hDED].[rf_SequelaePeriodID] as [rf_SequelaePeriodID], 
[jT_stt_SequelaePeriod].[Name] as [SILENT_rf_SequelaePeriodID], 
[hDED].[rf_TransfusionID] as [rf_TransfusionID], 
[jT_stt_Transfusion].[rf_MedicalHistoryID] as [SILENT_rf_TransfusionID], 
[hDED].[Date] as [Date], 
[hDED].[Reason] as [Reason], 
[hDED].[Description] as [Description], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flags] as [flags]
FROM [stt_Sequelae] as [hDED]
INNER JOIN [stt_SequelaeType] as [jT_stt_SequelaeType] on [jT_stt_SequelaeType].[SequelaeTypeID] = [hDED].[rf_SequelaeTypeID]
INNER JOIN [stt_SequelaePeriod] as [jT_stt_SequelaePeriod] on [jT_stt_SequelaePeriod].[SequelaePeriodID] = [hDED].[rf_SequelaePeriodID]
INNER JOIN [stt_Transfusion] as [jT_stt_Transfusion] on [jT_stt_Transfusion].[TransfusionID] = [hDED].[rf_TransfusionID]
go

