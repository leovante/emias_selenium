CREATE VIEW [V_oms_pr_ReestrFLK] AS SELECT 
[hDED].[pr_ReestrFLKID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_pr_ReestrID] as [rf_pr_ReestrID], 
[hDED].[rf_pr_ProfPlanID] as [rf_pr_ProfPlanID], 
[hDED].[rf_pr_ProfFactID] as [rf_pr_ProfFactID], 
[hDED].[rf_pr_InfoNoteID] as [rf_pr_InfoNoteID], 
[hDED].[ID_PAC] as [ID_PAC], 
[hDED].[Code_FLK] as [Code_FLK], 
[hDED].[Name_FLK] as [Name_FLK], 
[hDED].[Rem_FLK] as [Rem_FLK]
FROM [oms_pr_ReestrFLK] as [hDED]
go

