CREATE VIEW [V_emd_MedDocument] AS SELECT 
[hDED].[MedDocumentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[jT_stt_MedicalHistory].[FIO] as [SILENT_rf_MedicalHistoryID], 
[hDED].[rf_MedDocumentTypeID] as [rf_MedDocumentTypeID], 
[jT_emd_MedDocumentType].[Name] as [SILENT_rf_MedDocumentTypeID], 
[hDED].[rf_MainEmdID] as [rf_MainEmdID], 
[jT_emd_MedDocument].[RegNum] as [SILENT_rf_MainEmdID], 
[hDED].[rf_StatusID] as [rf_StatusID], 
[jT_emd_Status].[Name] as [SILENT_rf_StatusID], 
[hDED].[MedDocumentGuid] as [MedDocumentGuid], 
[hDED].[RegNum] as [RegNum], 
[hDED].[rf_DocTypeID] as [rf_DocTypeID], 
[hDED].[DocumentHash] as [DocumentHash], 
[hDED].[Comment] as [Comment], 
[hDED].[Flags] as [Flags], 
[hDED].[VersionNum] as [VersionNum], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[Content] as [Content], 
[hDED].[rf_DocTypeDefID] as [rf_DocTypeDefID], 
[hDED].[rf_EmdTypeGuid] as [rf_EmdTypeGuid]
FROM [emd_MedDocument] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [V_stt_MedicalHistory] as [jT_stt_MedicalHistory] on [jT_stt_MedicalHistory].[MedicalHistoryID] = [hDED].[rf_MedicalHistoryID]
INNER JOIN [emd_MedDocumentType] as [jT_emd_MedDocumentType] on [jT_emd_MedDocumentType].[MedDocumentTypeID] = [hDED].[rf_MedDocumentTypeID]
INNER JOIN [emd_MedDocument] as [jT_emd_MedDocument] on [jT_emd_MedDocument].[MedDocumentID] = [hDED].[rf_MainEmdID]
INNER JOIN [emd_Status] as [jT_emd_Status] on [jT_emd_Status].[StatusID] = [hDED].[rf_StatusID]
go

