CREATE VIEW [V_stt_HealthStatus] AS SELECT 
[hDED].[HealthStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
((cast(ADSistolic as varchar)+'/'+cast(ADDistolic as varchar))) as [V_AD], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[Tempherature] as [Tempherature], 
[hDED].[Date] as [Date], 
[hDED].[ADSistolic] as [ADSistolic], 
[hDED].[ADDistolic] as [ADDistolic], 
[hDED].[Weight] as [Weight], 
[hDED].[Breath] as [Breath], 
[hDED].[Liquid] as [Liquid], 
[hDED].[Stul] as [Stul], 
[hDED].[Bath] as [Bath], 
[hDED].[DayUrine] as [DayUrine], 
[hDED].[Pulse] as [Pulse], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flags] as [flags]
FROM [stt_HealthStatus] as [hDED]
go

