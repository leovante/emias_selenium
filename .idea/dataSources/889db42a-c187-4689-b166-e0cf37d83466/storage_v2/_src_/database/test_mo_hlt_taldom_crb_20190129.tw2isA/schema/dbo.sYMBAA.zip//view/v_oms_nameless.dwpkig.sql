CREATE VIEW [V_oms_Nameless] AS SELECT 
[hDED].[NamelessID], [hDED].[x_Edition], [hDED].[x_Status], 
(((select FIO from x_User where UserId = LastUserID))) as [V_FIOUser], 
[jT_oms_LsType].[LsTypeName] as [V_LsTypeName], 
[hDED].[rf_MNNameID] as [rf_MNNameID], 
[jT_oms_MNName].[NAME_MNN] as [SILENT_rf_MNNameID], 
[hDED].[rf_FARGID] as [rf_FARGID], 
[jT_oms_FARG].[FNAME_FRG] as [SILENT_rf_FARGID], 
[hDED].[rf_kl_ATHID] as [rf_kl_ATHID], 
[jT_oms_kl_ATH].[C_ATH] as [SILENT_rf_kl_ATHID], 
[hDED].[rf_LsTypeID] as [rf_LsTypeID], 
[hDED].[rf_ClassUnitID] as [rf_ClassUnitID], 
[hDED].[Name] as [Name], 
[hDED].[Spec] as [Spec], 
[hDED].[Flags] as [Flags], 
[hDED].[Rem] as [Rem], 
[hDED].[NumReg] as [NumReg], 
[hDED].[Apparatus] as [Apparatus], 
[hDED].[No_mnn] as [No_mnn], 
[hDED].[No_LF] as [No_LF], 
[hDED].[No_D_LS] as [No_D_LS], 
[hDED].[No_TRN] as [No_TRN], 
[hDED].[LastUserID] as [LastUserID], 
[hDED].[ProductCount] as [ProductCount], 
[hDED].[Code] as [Code]
FROM [oms_Nameless] as [hDED]
INNER JOIN [oms_LsType] as [jT_oms_LsType] on [jT_oms_LsType].[LsTypeID] = [hDED].[rf_LsTypeID]
INNER JOIN [oms_MNName] as [jT_oms_MNName] on [jT_oms_MNName].[MNNameID] = [hDED].[rf_MNNameID]
INNER JOIN [oms_FARG] as [jT_oms_FARG] on [jT_oms_FARG].[FARGID] = [hDED].[rf_FARGID]
INNER JOIN [oms_kl_ATH] as [jT_oms_kl_ATH] on [jT_oms_kl_ATH].[kl_ATHID] = [hDED].[rf_kl_ATHID]
go

