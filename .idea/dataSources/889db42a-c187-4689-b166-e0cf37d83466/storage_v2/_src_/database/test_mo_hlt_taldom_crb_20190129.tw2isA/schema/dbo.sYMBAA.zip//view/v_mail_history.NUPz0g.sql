CREATE VIEW [V_mail_History] AS SELECT 
[hDED].[HistoryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MessageID] as [rf_MessageID], 
[hDED].[rf_MessageStateID] as [rf_MessageStateID], 
[hDED].[ActionDate] as [ActionDate]
FROM [mail_History] as [hDED]
go

