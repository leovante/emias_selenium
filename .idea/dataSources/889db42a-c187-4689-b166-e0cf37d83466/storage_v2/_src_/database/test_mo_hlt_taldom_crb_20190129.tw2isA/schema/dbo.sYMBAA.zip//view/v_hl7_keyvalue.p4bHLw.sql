CREATE VIEW [V_hl7_KeyValue] AS SELECT 
[hDED].[KeyValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[KeyName] as [KeyName], 
[hDED].[Value] as [Value], 
[hDED].[CDAType] as [CDAType]
FROM [hl7_KeyValue] as [hDED]
go

