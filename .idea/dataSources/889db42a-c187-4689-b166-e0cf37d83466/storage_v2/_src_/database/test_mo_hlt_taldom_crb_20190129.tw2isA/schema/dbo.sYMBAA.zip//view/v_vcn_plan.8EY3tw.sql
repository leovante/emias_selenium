CREATE VIEW [V_vcn_Plan] AS SELECT 
[hDED].[PlanID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Author] as [Author], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[PlanFlag] as [PlanFlag], 
[hDED].[GUID] as [GUID]
FROM [vcn_Plan] as [hDED]
go

