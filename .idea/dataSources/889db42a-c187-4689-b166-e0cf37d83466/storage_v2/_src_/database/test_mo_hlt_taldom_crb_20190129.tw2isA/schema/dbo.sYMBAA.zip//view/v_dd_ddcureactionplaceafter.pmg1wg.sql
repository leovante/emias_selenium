CREATE VIEW [V_dd_DDCureActionPlaceAfter] AS SELECT 
[hDED].[DDCureActionplaceAfterID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDCureActionPlaceTypeGUID] as [rf_DDCureActionPlaceTypeGUID], 
[jT_dd_DDCureActionPlace].[Name] as [SILENT_rf_DDCureActionPlaceTypeGUID], 
[hDED].[rf_DDStateOfHealthAfterID] as [rf_DDStateOfHealthAfterID], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDCureActionPlaceAfter] as [hDED]
INNER JOIN [dd_DDCureActionPlace] as [jT_dd_DDCureActionPlace] on [jT_dd_DDCureActionPlace].[UGUID] = [hDED].[rf_DDCureActionPlaceTypeGUID]
go

