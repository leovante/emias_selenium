CREATE VIEW [V_stt_HospResult] AS SELECT 
[hDED].[HospResultID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[COD] as [COD], 
[hDED].[Name] as [Name], 
[hDED].[Flag] as [Flag]
FROM [stt_HospResult] as [hDED]
go

