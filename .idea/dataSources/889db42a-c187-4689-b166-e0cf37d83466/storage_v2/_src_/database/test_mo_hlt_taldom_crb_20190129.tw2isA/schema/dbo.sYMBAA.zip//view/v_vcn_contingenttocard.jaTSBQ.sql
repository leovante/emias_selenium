CREATE VIEW [V_vcn_ContingentToCard] AS SELECT 
[hDED].[ContingentToCardID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_InoculationCardID] as [rf_InoculationCardID], 
[hDED].[rf_ContingentID] as [rf_ContingentID], 
[jT_vcn_Contingent].[Name] as [SILENT_rf_ContingentID], 
[hDED].[rf_VaccinationGroupID] as [rf_VaccinationGroupID], 
[jT_vcn_VaccinationGroup].[Name] as [SILENT_rf_VaccinationGroupID], 
[hDED].[GUID] as [GUID]
FROM [vcn_ContingentToCard] as [hDED]
INNER JOIN [vcn_Contingent] as [jT_vcn_Contingent] on [jT_vcn_Contingent].[ContingentID] = [hDED].[rf_ContingentID]
INNER JOIN [vcn_VaccinationGroup] as [jT_vcn_VaccinationGroup] on [jT_vcn_VaccinationGroup].[VaccinationGroupID] = [hDED].[rf_VaccinationGroupID]
go

