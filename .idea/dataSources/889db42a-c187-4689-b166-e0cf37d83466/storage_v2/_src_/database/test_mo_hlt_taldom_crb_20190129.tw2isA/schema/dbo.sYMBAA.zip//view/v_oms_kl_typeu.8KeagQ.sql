CREATE VIEW [V_oms_kl_TypeU] AS SELECT 
[hDED].[kl_TypeUID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Type_U] as [Type_U], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[isPFin] as [isPFin], 
[hDED].[AllowAdult] as [AllowAdult], 
[hDED].[AllowChildren] as [AllowChildren], 
[hDED].[AllowMen] as [AllowMen], 
[hDED].[AllowWomen] as [AllowWomen], 
[hDED].[MinCount] as [MinCount], 
[hDED].[MaxCount] as [MaxCount], 
[hDED].[IsMain] as [IsMain], 
[hDED].[GroupCode] as [GroupCode]
FROM [oms_kl_TypeU] as [hDED]
go

