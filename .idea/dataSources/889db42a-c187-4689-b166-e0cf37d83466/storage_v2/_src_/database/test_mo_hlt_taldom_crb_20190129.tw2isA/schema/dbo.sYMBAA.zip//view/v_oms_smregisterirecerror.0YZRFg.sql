CREATE VIEW [V_oms_SMRegisterIRecError] AS SELECT 
[hDED].[SMRegisterIRecErrorID], [hDED].[x_Edition], [hDED].[x_Status], 
((((((((select FIO from x_User where UserId = hDED.LastUserID)))))))) as [V_UserFIO], 
[hDED].[rf_SMErrorID] as [rf_SMErrorID], 
[jT_oms_SMError].[rf_SMCriterionID] as [SILENT_rf_SMErrorID], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[jT_oms_SMCriterion].[SMCriterionCaption] as [SILENT_rf_SMCriterionID], 
[hDED].[rf_SMRegisterIRecID] as [rf_SMRegisterIRecID], 
[jT_oms_SMRegisterIRec].[rf_SMRegisterInstructionID] as [SILENT_rf_SMRegisterIRecID], 
[hDED].[Agree] as [Agree], 
[hDED].[Sum] as [Sum], 
[hDED].[Rem] as [Rem], 
[hDED].[LastUserID] as [LastUserID]
FROM [oms_SMRegisterIRecError] as [hDED]
INNER JOIN [oms_SMError] as [jT_oms_SMError] on [jT_oms_SMError].[SMErrorID] = [hDED].[rf_SMErrorID]
INNER JOIN [oms_SMCriterion] as [jT_oms_SMCriterion] on [jT_oms_SMCriterion].[SMCriterionID] = [hDED].[rf_SMCriterionID]
INNER JOIN [oms_SMRegisterIRec] as [jT_oms_SMRegisterIRec] on [jT_oms_SMRegisterIRec].[SMRegisterIRecID] = [hDED].[rf_SMRegisterIRecID]
go

