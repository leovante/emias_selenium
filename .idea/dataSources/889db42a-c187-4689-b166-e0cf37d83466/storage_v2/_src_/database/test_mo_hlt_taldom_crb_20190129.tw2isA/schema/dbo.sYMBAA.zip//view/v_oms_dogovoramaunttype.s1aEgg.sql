CREATE VIEW [V_oms_DogovorAmauntType] AS SELECT 
[hDED].[DogovorAmauntTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_ReasonTypeID] as [rf_kl_ReasonTypeID], 
[jT_oms_kl_ReasonType].[Name] as [SILENT_rf_kl_ReasonTypeID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Caption] as [Caption], 
[hDED].[isVMP] as [isVMP], 
[hDED].[isChild] as [isChild], 
[hDED].[Flag] as [Flag], 
[hDED].[GUIDDogAmauntType] as [GUIDDogAmauntType], 
[hDED].[Criterion] as [Criterion]
FROM [oms_DogovorAmauntType] as [hDED]
INNER JOIN [oms_kl_ReasonType] as [jT_oms_kl_ReasonType] on [jT_oms_kl_ReasonType].[kl_ReasonTypeID] = [hDED].[rf_kl_ReasonTypeID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
go

