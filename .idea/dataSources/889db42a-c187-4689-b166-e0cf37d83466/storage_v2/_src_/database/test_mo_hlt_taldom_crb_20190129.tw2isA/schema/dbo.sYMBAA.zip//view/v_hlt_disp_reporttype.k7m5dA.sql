CREATE VIEW [V_hlt_disp_ReportType] AS SELECT 
[hDED].[disp_ReportTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DispTypeGuid] as [rf_DispTypeGuid], 
[jT_hlt_disp_Type].[Name] as [SILENT_rf_DispTypeGuid], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[TypeName] as [TypeName], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_ReportType] as [hDED]
INNER JOIN [hlt_disp_Type] as [jT_hlt_disp_Type] on [jT_hlt_disp_Type].[Guid] = [hDED].[rf_DispTypeGuid]
go

