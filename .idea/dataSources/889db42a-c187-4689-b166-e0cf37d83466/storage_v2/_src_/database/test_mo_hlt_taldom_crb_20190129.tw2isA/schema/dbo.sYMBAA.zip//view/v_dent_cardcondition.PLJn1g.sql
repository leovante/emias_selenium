CREATE VIEW [V_dent_CardCondition] AS SELECT 
[hDED].[CardConditionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_dent_ZoneID] as [rf_dent_ZoneID], 
[jT_oms_dent_Zone].[Name] as [SILENT_rf_dent_ZoneID], 
[hDED].[rf_dent_SurfaceID] as [rf_dent_SurfaceID], 
[jT_oms_dent_Surface].[Name] as [SILENT_rf_dent_SurfaceID], 
[hDED].[rf_dent_ConditionTypeID] as [rf_dent_ConditionTypeID], 
[jT_oms_dent_ConditionType].[Name] as [SILENT_rf_dent_ConditionTypeID], 
[hDED].[rf_dent_ConditionLevelID] as [rf_dent_ConditionLevelID], 
[jT_oms_dent_ConditionLevel].[Name] as [SILENT_rf_dent_ConditionLevelID], 
[hDED].[rf_CardID] as [rf_CardID], 
[jT_dent_Card].[IsActive] as [SILENT_rf_CardID], 
[hDED].[rf_CardToothID] as [rf_CardToothID], 
[jT_dent_CardTooth].[Date] as [SILENT_rf_CardToothID], 
[hDED].[rf_dent_ConstructionPositionID] as [rf_dent_ConstructionPositionID], 
[jT_oms_dent_ConstructionPosition].[Code] as [SILENT_rf_dent_ConstructionPositionID], 
[hDED].[Date] as [Date], 
[hDED].[IsDeleted] as [IsDeleted], 
[hDED].[Note] as [Note], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dent_CardCondition] as [hDED]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [oms_dent_Zone] as [jT_oms_dent_Zone] on [jT_oms_dent_Zone].[dent_ZoneID] = [hDED].[rf_dent_ZoneID]
INNER JOIN [oms_dent_Surface] as [jT_oms_dent_Surface] on [jT_oms_dent_Surface].[dent_SurfaceID] = [hDED].[rf_dent_SurfaceID]
INNER JOIN [oms_dent_ConditionType] as [jT_oms_dent_ConditionType] on [jT_oms_dent_ConditionType].[dent_ConditionTypeID] = [hDED].[rf_dent_ConditionTypeID]
INNER JOIN [oms_dent_ConditionLevel] as [jT_oms_dent_ConditionLevel] on [jT_oms_dent_ConditionLevel].[dent_ConditionLevelID] = [hDED].[rf_dent_ConditionLevelID]
INNER JOIN [dent_Card] as [jT_dent_Card] on [jT_dent_Card].[CardID] = [hDED].[rf_CardID]
INNER JOIN [dent_CardTooth] as [jT_dent_CardTooth] on [jT_dent_CardTooth].[CardToothID] = [hDED].[rf_CardToothID]
INNER JOIN [oms_dent_ConstructionPosition] as [jT_oms_dent_ConstructionPosition] on [jT_oms_dent_ConstructionPosition].[dent_ConstructionPositionID] = [hDED].[rf_dent_ConstructionPositionID]
go

