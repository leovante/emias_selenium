CREATE VIEW [V_hlt_OutcomeVisit] AS SELECT 
[hDED].[OutcomeVisitID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Comment] as [Comment]
FROM [hlt_OutcomeVisit] as [hDED]
go

