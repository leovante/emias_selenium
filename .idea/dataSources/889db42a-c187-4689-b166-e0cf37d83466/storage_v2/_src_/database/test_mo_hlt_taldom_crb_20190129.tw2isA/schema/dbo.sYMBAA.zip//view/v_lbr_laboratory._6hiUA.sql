CREATE VIEW [V_lbr_Laboratory] AS SELECT 
[hDED].[LaboratoryID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_Department].[DepartmentCODE] as [V_DepartmentCODE], 
[jT_oms_Department].[DepartmentNAME] as [V_DepartmentNAME], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[hDED].[rf_LaboratoryTypeID] as [rf_LaboratoryTypeID], 
[jT_lbr_LaboratoryType].[Name] as [SILENT_rf_LaboratoryTypeID], 
[hDED].[rf_LaboratoryKindID] as [rf_LaboratoryKindID], 
[jT_lbr_LaboratoryKind].[Name] as [SILENT_rf_LaboratoryKindID], 
[hDED].[LaboratoryURL] as [LaboratoryURL], 
[hDED].[LaboratoryName] as [LaboratoryName]
FROM [lbr_Laboratory] as [hDED]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [lbr_LaboratoryType] as [jT_lbr_LaboratoryType] on [jT_lbr_LaboratoryType].[LaboratoryTypeID] = [hDED].[rf_LaboratoryTypeID]
INNER JOIN [lbr_LaboratoryKind] as [jT_lbr_LaboratoryKind] on [jT_lbr_LaboratoryKind].[LaboratoryKindID] = [hDED].[rf_LaboratoryKindID]
go

