CREATE VIEW [V_dd_DDStatusAlg] AS SELECT 
[hDED].[DDStatusAlgID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME]
FROM [dd_DDStatusAlg] as [hDED]
go

