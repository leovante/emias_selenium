CREATE VIEW [V_hlt_mkp_Abort] AS SELECT 
[hDED].[mkp_AbortID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_MKB].[DS] as [V_DS], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_AbortDeathTypeUguid] as [rf_AbortDeathTypeUguid], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateDeathAbort] as [DateDeathAbort], 
[hDED].[DateAbort] as [DateAbort], 
[hDED].[Flags] as [Flags], 
[hDED].[IsAbort] as [IsAbort], 
[hDED].[IsDeath] as [IsDeath]
FROM [hlt_mkp_Abort] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
go

