CREATE VIEW [V_rls_Prep_Atc] AS SELECT 
[hDED].[Prep_AtcID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ClsAtcUID] as [rf_ClsAtcUID], 
[hDED].[rf_PrepUID] as [rf_PrepUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Prep_Atc] as [hDED]
go

