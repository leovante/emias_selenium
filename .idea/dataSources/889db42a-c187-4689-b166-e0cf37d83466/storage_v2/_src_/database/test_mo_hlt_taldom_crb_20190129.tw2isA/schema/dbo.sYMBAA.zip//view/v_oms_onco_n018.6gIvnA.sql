CREATE VIEW [V_oms_onco_N018] AS SELECT 
[hDED].[onco_N018ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ID_Reas] as [ID_Reas], 
[hDED].[Reas_Name] as [Reas_Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[GUIDN018] as [GUIDN018]
FROM [oms_onco_N018] as [hDED]
go

