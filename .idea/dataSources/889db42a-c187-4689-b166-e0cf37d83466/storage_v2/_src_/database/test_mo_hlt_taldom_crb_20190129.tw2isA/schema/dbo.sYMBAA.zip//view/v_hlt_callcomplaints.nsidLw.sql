CREATE VIEW [V_hlt_CallComplaints] AS SELECT 
[hDED].[CallComplaintsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ComplaintID] as [rf_ComplaintID], 
[hDED].[rf_CallDoctorID] as [rf_CallDoctorID], 
[hDED].[Note] as [Note]
FROM [hlt_CallComplaints] as [hDED]
go

