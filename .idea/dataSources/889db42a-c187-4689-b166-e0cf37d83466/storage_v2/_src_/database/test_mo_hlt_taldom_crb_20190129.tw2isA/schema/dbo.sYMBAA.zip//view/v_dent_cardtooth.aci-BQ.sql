CREATE VIEW [V_dent_CardTooth] AS SELECT 
[hDED].[CardToothID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_dent_ToothID] as [rf_dent_ToothID], 
[jT_oms_dent_Tooth].[Number] as [SILENT_rf_dent_ToothID], 
[hDED].[rf_CardID] as [rf_CardID], 
[jT_dent_Card].[IsActive] as [SILENT_rf_CardID], 
[hDED].[Date] as [Date], 
[hDED].[IsDeleted] as [IsDeleted], 
[hDED].[IsSupernumerary] as [IsSupernumerary], 
[hDED].[Iropz] as [Iropz], 
[hDED].[Note] as [Note], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[IsChild] as [IsChild]
FROM [dent_CardTooth] as [hDED]
INNER JOIN [oms_dent_Tooth] as [jT_oms_dent_Tooth] on [jT_oms_dent_Tooth].[dent_ToothID] = [hDED].[rf_dent_ToothID]
INNER JOIN [dent_Card] as [jT_dent_Card] on [jT_dent_Card].[CardID] = [hDED].[rf_CardID]
go

