CREATE VIEW [V_stt_CalculateMethod] AS SELECT 
[hDED].[CalculateMethodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Function] as [Function], 
[hDED].[Description] as [Description]
FROM [stt_CalculateMethod] as [hDED]
go

