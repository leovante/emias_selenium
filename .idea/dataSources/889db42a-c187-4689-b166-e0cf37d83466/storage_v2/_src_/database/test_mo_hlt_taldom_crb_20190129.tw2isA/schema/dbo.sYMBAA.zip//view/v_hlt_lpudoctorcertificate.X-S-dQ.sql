CREATE VIEW [V_hlt_LPUDoctorCertificate] AS SELECT 
[hDED].[LPUDoctorCertificateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_PRVSID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[DateExam] as [DateExam], 
[hDED].[Education] as [Education], 
[hDED].[Seria] as [Seria], 
[hDED].[Num] as [Num], 
[hDED].[DateCert] as [DateCert], 
[hDED].[DateEndCert] as [DateEndCert]
FROM [hlt_LPUDoctorCertificate] as [hDED]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
go

