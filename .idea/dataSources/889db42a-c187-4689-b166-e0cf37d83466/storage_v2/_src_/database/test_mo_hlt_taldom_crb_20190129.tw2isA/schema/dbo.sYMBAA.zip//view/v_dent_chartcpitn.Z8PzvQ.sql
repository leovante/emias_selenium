CREATE VIEW [V_dent_ChartCPITN] AS SELECT 
[hDED].[ChartCPITNID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_disp_ExamID] as [rf_disp_ExamID], 
[jT_hlt_disp_Exam].[rf_ServiceGuid] as [SILENT_rf_disp_ExamID], 
[hDED].[rf_ChartID] as [rf_ChartID], 
[jT_dent_Chart].[IsActive] as [SILENT_rf_ChartID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Number] as [Number], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dent_ChartCPITN] as [hDED]
INNER JOIN [hlt_disp_Exam] as [jT_hlt_disp_Exam] on [jT_hlt_disp_Exam].[disp_ExamID] = [hDED].[rf_disp_ExamID]
INNER JOIN [dent_Chart] as [jT_dent_Chart] on [jT_dent_Chart].[ChartID] = [hDED].[rf_ChartID]
go

