CREATE VIEW [V_vcn_Season] AS SELECT 
[hDED].[SeasonID], [hDED].[x_Edition], [hDED].[x_Status], 
((Code)) as [V_SeasonCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [vcn_Season] as [hDED]
go

