CREATE VIEW [V_hlt_LSPurpose] AS SELECT 
[hDED].[LSPurposeID], [hDED].[x_Edition], [hDED].[x_Status], 
(((select Convert(varchar,hded.DatePurpose,104) + ' - ' + (case when hded.rf_LSID <> 0 then jt_oms_LS.Name_Med else jt_oms_MNName.NAME_MNN end)))) as [V_LSDate], 
(select jt_hlt_MKAB.FAMILY + ' ' + jt_hlt_MKAB.NAME + ' ' + jt_hlt_MKAB.OT) as [V_FIOPat], 
((isnull((select rtrim(ltrim(PRVS_NAME)) from oms_PRVS where PRVSID = [jT_hlt_LPUDoctor].rf_PRVSID), ''))) as [V_PRVSName], 
[hDED].[rf_TRNameID] as [rf_TRNameID], 
[jT_oms_TRName].[NAME_TRN] as [SILENT_rf_TRNameID], 
[hDED].[rf_MNNameID] as [rf_MNNameID], 
[jT_oms_MNName].[NAME_MNN] as [SILENT_rf_MNNameID], 
[hDED].[rf_LFID] as [rf_LFID], 
[jT_oms_LF].[C_LF] as [SILENT_rf_LFID], 
[hDED].[rf_LSID] as [rf_LSID], 
[jT_oms_LS].[NAME_MED] as [SILENT_rf_LSID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[jT_hlt_TAP].[v_TAP] as [SILENT_rf_TAPID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_CancelDocPRVDID] as [rf_CancelDocPRVDID], 
[jT_hlt_DocPRVD1].[Name] as [SILENT_rf_CancelDocPRVDID], 
[hDED].[rf_LSPurposeStatusID] as [rf_LSPurposeStatusID], 
[jT_oms_LSPurposeStatus].[Name] as [SILENT_rf_LSPurposeStatusID], 
[hDED].[rf_rx_GenericDrugID] as [rf_rx_GenericDrugID], 
[jT_oms_rx_GenericDrug].[Name_GD] as [SILENT_rf_rx_GenericDrugID], 
[hDED].[rf_rx_DispensableDrugID] as [rf_rx_DispensableDrugID], 
[jT_oms_rx_DispensableDrug].[Name_DD] as [SILENT_rf_rx_DispensableDrugID], 
[hDED].[rf_IntakeMethodID] as [rf_IntakeMethodID], 
[jT_oms_IntakeMethod].[Name] as [SILENT_rf_IntakeMethodID], 
[hDED].[rf_IntakeWayID] as [rf_IntakeWayID], 
[jT_oms_IntakeWay].[Name] as [SILENT_rf_IntakeWayID], 
[hDED].[DatePurpose] as [DatePurpose], 
[hDED].[Signa] as [Signa], 
[hDED].[DOZ] as [DOZ], 
[hDED].[DayCount] as [DayCount], 
[hDED].[Comment] as [Comment], 
[hDED].[isComplete] as [isComplete], 
[hDED].[KV_ALL] as [KV_ALL], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[isBaseDoseOverride] as [isBaseDoseOverride], 
[hDED].[isSpecialPurpose] as [isSpecialPurpose], 
[hDED].[isKEK] as [isKEK], 
[hDED].[CancelDate] as [CancelDate], 
[hDED].[UnitDose] as [UnitDose], 
[hDED].[TimesInDay] as [TimesInDay], 
[hDED].[SingleDose] as [SingleDose], 
[hDED].[isChronicDisease] as [isChronicDisease], 
[hDED].[isTRN] as [isTRN]
FROM [hlt_LSPurpose] as [hDED]
INNER JOIN [oms_TRName] as [jT_oms_TRName] on [jT_oms_TRName].[TRNameID] = [hDED].[rf_TRNameID]
INNER JOIN [oms_MNName] as [jT_oms_MNName] on [jT_oms_MNName].[MNNameID] = [hDED].[rf_MNNameID]
INNER JOIN [oms_LF] as [jT_oms_LF] on [jT_oms_LF].[LFID] = [hDED].[rf_LFID]
INNER JOIN [oms_LS] as [jT_oms_LS] on [jT_oms_LS].[LSID] = [hDED].[rf_LSID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [V_hlt_TAP] as [jT_hlt_TAP] on [jT_hlt_TAP].[TAPID] = [hDED].[rf_TAPID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD1] on [jT_hlt_DocPRVD1].[DocPRVDID] = [hDED].[rf_CancelDocPRVDID]
INNER JOIN [oms_LSPurposeStatus] as [jT_oms_LSPurposeStatus] on [jT_oms_LSPurposeStatus].[LSPurposeStatusID] = [hDED].[rf_LSPurposeStatusID]
INNER JOIN [oms_rx_GenericDrug] as [jT_oms_rx_GenericDrug] on [jT_oms_rx_GenericDrug].[rx_GenericDrugID] = [hDED].[rf_rx_GenericDrugID]
INNER JOIN [oms_rx_DispensableDrug] as [jT_oms_rx_DispensableDrug] on [jT_oms_rx_DispensableDrug].[rx_DispensableDrugID] = [hDED].[rf_rx_DispensableDrugID]
INNER JOIN [oms_IntakeMethod] as [jT_oms_IntakeMethod] on [jT_oms_IntakeMethod].[IntakeMethodID] = [hDED].[rf_IntakeMethodID]
INNER JOIN [oms_IntakeWay] as [jT_oms_IntakeWay] on [jT_oms_IntakeWay].[IntakeWayID] = [hDED].[rf_IntakeWayID]
go

