CREATE VIEW [V_vcn_GlobalReaction] AS SELECT 
[hDED].[GlobalReactionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [vcn_GlobalReaction] as [hDED]
go

