CREATE VIEW [V_stt_ProcedureLS] AS SELECT 
[hDED].[ProcedureLSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PurposeLSID] as [rf_PurposeLSID], 
[jT_stt_PurposeLS].[Name] as [SILENT_rf_PurposeLSID], 
[hDED].[rf_ProcedureDescriptionID] as [rf_ProcedureDescriptionID], 
[jT_stt_ProcedureDescription].[Code] as [SILENT_rf_ProcedureDescriptionID]
FROM [stt_ProcedureLS] as [hDED]
INNER JOIN [stt_PurposeLS] as [jT_stt_PurposeLS] on [jT_stt_PurposeLS].[PurposeLSID] = [hDED].[rf_PurposeLSID]
INNER JOIN [stt_ProcedureDescription] as [jT_stt_ProcedureDescription] on [jT_stt_ProcedureDescription].[ProcedureDescriptionID] = [hDED].[rf_ProcedureDescriptionID]
go

