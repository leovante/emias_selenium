CREATE VIEW [V_hlt_mkp_BornImmun] AS SELECT 
[hDED].[mkp_BornImmunID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_mkp_BornGUID] as [rf_mkp_BornGUID], 
[jT_hlt_mkp_Born].[NUM] as [SILENT_rf_mkp_BornGUID], 
[hDED].[rf_mkp_ImmunizationsGUID] as [rf_mkp_ImmunizationsGUID], 
[jT_hlt_mkp_Immunizations].[V_Descr] as [SILENT_rf_mkp_ImmunizationsGUID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateImm] as [DateImm], 
[hDED].[DateMed] as [DateMed], 
[hDED].[Flags] as [Flags], 
[hDED].[Conducted] as [Conducted], 
[hDED].[Comment] as [Comment]
FROM [hlt_mkp_BornImmun] as [hDED]
INNER JOIN [hlt_mkp_Born] as [jT_hlt_mkp_Born] on [jT_hlt_mkp_Born].[UGUID] = [hDED].[rf_mkp_BornGUID]
INNER JOIN [V_hlt_mkp_Immunizations] as [jT_hlt_mkp_Immunizations] on [jT_hlt_mkp_Immunizations].[UGUID] = [hDED].[rf_mkp_ImmunizationsGUID]
go

