CREATE VIEW [V_stt_LSOutlay] AS SELECT 
[hDED].[LSOutlayID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_ListOfPurposeID] as [rf_ListOfPurposeID], 
[hDED].[rf_PLPositionID] as [rf_PLPositionID], 
[hDED].[rf_TypePackingID] as [rf_TypePackingID], 
[hDED].[CodeRAS] as [CodeRAS], 
[hDED].[Name] as [Name], 
[hDED].[RealCount] as [RealCount], 
[hDED].[Date] as [Date], 
[hDED].[Writed] as [Writed], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Dose] as [Dose], 
[hDED].[UnitDose] as [UnitDose], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID]
FROM [stt_LSOutlay] as [hDED]
go

