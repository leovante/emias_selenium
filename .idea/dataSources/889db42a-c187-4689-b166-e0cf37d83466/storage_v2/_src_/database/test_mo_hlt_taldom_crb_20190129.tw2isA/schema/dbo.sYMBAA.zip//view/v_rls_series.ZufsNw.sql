CREATE VIEW [V_rls_Series] AS SELECT 
[hDED].[SeriesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_NomenUID] as [rf_NomenUID], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[SerNum] as [SerNum], 
[hDED].[Ean] as [Ean], 
[hDED].[EndDate] as [EndDate], 
[hDED].[LetterNum] as [LetterNum], 
[hDED].[LetterDate] as [LetterDate], 
[hDED].[SerStatusID] as [SerStatusID], 
[hDED].[SerStatus] as [SerStatus], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_Series] as [hDED]
go

