CREATE VIEW [V_prp_PLPosition] AS SELECT 
[hDED].[PLPositionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ListOfPurposeID] as [rf_ListOfPurposeID], 
[hDED].[rf_PurposeLSID] as [rf_PurposeLSID], 
[hDED].[rf_LSOutlayID] as [rf_LSOutlayID], 
[hDED].[Flag] as [Flag], 
[hDED].[PurposeCount] as [PurposeCount]
FROM [prp_PLPosition] as [hDED]
go

