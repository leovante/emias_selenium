CREATE VIEW [V_oms_Store] AS SELECT 
[hDED].[StoreID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_APUID] as [rf_APUID], 
[jT_oms_APU].[P_NAMES] as [SILENT_rf_APUID], 
[hDED].[STORE_NAME] as [STORE_NAME], 
[hDED].[Flags] as [Flags], 
[hDED].[Note] as [Note]
FROM [oms_Store] as [hDED]
INNER JOIN [oms_APU] as [jT_oms_APU] on [jT_oms_APU].[APUID] = [hDED].[rf_APUID]
go

