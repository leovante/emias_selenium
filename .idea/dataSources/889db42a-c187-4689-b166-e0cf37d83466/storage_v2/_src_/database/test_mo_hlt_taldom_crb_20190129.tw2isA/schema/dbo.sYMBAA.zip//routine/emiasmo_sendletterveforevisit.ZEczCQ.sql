
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[EMIASMO_SENDLETTERВeforeVISIT] (@uguid UNIQUEIDENTIFIER, @d DATE)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	IF EXISTS (select 1 from rpt_remindMessage rem WITH(NOLOCK) where rem.dvtuguid = @uguid and datediff(day,rem.senddate,rem.visitDate) = datediff(day,getdate(),@d))
	RETURN

	declare  @obr varchar(200)
			,@io varchar(200)
			,@res varchar(200)
			,@KabNum varchar(200)
			,@Speciality varchar(200)
			,@DocFio varchar(200)
			,@dttdate varchar(100)
			,@Begin_Time varchar(100)
			,@lpu varchar(500)
			,@ADRES varchar(500)
			,@talon varchar(30)
			,@email varchar(200)
			,@email2 varchar(200)
			,@mkabid int = 0
			,@dvtid int = 0
			,@mcod varchar(20)
			,@date datetime
			,@uguidLpu UNIQUEIDENTIFIER;

	select @dvtid =		dvt.DoctorVisitTableID
		,@obr =			case when mkab.W = 1 then 'Уважаемый' else 'Уважаемая' end
		,@io=			rtrim(ltrim(dbo.InitCapFirst(mkab.NAME) + ' ' + dbo.InitCapFirst(mkab.OT)))
		,@res =			case when res.EnumName = 'Equipment' then 'Исследование' else 'Врач' end	
		,@Speciality =  case when prvs.PRVSID > 0 then prvs.PRVS_NAME else '' end
		,@KabNum =		case when room.HealingRoomID > 0 and (room.Comment!='' or room.Num!='') 
							then case when room.Num != '' then room.Num else room.Comment end
							else '' end
		,@DocFio = 		case when res.EnumName = 'Equipment' 
							then isnull(research.researchName,'')
							else case when lpudoc.LPUDoctorID > 0 then ltrim(rtrim(lpudoc.FAM_V + ' ' + lpudoc.IM_V + ' ' + lpudoc.OT_V )) 
								else '-' end
							end
		,@dttdate =		convert(varchar(30),dtt.Date,104) 
		,@Begin_Time =	case when datepart(hour,dtt.Begin_Time) = 0 then 'вне расписания' else left(convert(varchar(30),dtt.Begin_Time,108),5) end
		,@lpu =			lpu._2dr_name
		,@ADRES =		lpu.ADRES
		,@talon =		dvt.StubNum
		,@email =		mkab.contactEmail
		,@mkabid =		mkab.MKABID
		,@mcod =		lpu.Mcod
		,@date =		dateadd(minute, datepart(n, dtt.Begin_Time), dateadd(hour, datepart(hh, dtt.Begin_Time), dtt.Date)) 
		,@uguidLpu = lpu.GUIDLPU
	from hlt_DoctorVisitTable dvt WITH(NOLOCK)
		inner join hlt_MKAB mkab WITH(NOLOCK) on mkab.MKABID = dvt.rf_MKABID 
			and mkab.FAMILY != ''
			and replace(mkab.FAMILY,substring(mkab.FAMILY,1,1),'') != '' 
			and len(replace(replace(ltrim(rtrim(mkab.FAMILY))+ltrim(rtrim(mkab.NAME))+ltrim(rtrim(mkab.OT)),'-',''),'.','')) > 3			
			and dvt.UGUID = @uguid 
		inner join hlt_DoctorTimeTable dtt WITH(NOLOCK) on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID
			and dtt.Date > getdate()
			and datepart(hh, dtt.Begin_Time) > 0 
		inner join hlt_DocPRVD dprvd WITH(NOLOCK) on dprvd.DocPRVDID = dtt.rf_DocPRVDID
		inner join hlt_ResourceType res WITH(NOLOCK) on res.ResourceTypeID = dprvd.rf_ResourceTypeID 
		inner join hlt_LPUDoctor lpudoc WITH(NOLOCK) on lpudoc.LPUDoctorID = dprvd.rf_LPUDoctorID
				and case when res.EnumName = 'Doctor' then replace(lpudoc.FAM_V,'не известно','') else 'f' end != ''
		inner join hlt_HealingRoom room WITH(NOLOCK) on room.HealingRoomID = dprvd.rf_HealingRoomID
		--inner join oms_PRVD prvd WITH(NOLOCK) on prvd.PRVDID = dprvd.rf_PRVDID
		inner join Oms_PRVS prvs WITH(NOLOCK) on prvs.PRVSID = dprvd.rf_PRVSID
		inner join oms_Department dep WITH(NOLOCK) on dep.DepartmentID = dprvd.rf_DepartmentID
		inner join rpt_LpuInfo lpu WITH(NOLOCK) on lpu.LPUID = dep.rf_LPUID	
		--inner join hlt_Equipment eq WITH(NOLOCK) on eq.EquipmentID = dprvd.rf_EquipmentID
		--inner join hlt_EquipmentType eqt WITH(NOLOCK) on eqt.EquipmentTypeID = eq.rf_EquipmentTypeID
		outer apply (
			select top 1 isnull(rt.ResearchName,'') researchName 
			from hlt_ActionSchedule ash WITH(NOLOCK)
				inner join lbr_LaboratoryResearch lr WITH(NOLOCK) on lr.LaboratoryResearchID = ash.rf_DocTypeID
					and res.EnumName = 'Equipment'
					and ash.DocTypeDefID = (select top 1 DocTypeDefID from x_DocTypeDef WITH(NOLOCK) where HeadTable = 'lbr_LaboratoryResearch')
					and ash.rf_DoctorVisitTableID = dvt.DoctorVisitTableID
				inner join lbr_Research r WITH(NOLOCK) on r.rf_LaboratoryResearchGUID = lr.GUID  
				inner join lbr_ResearchType rt WITH(NOLOCK) on rt.UGUID = r.rf_ResearchTypeUGUID
					and rt.ResearchTypeID > 0
		)research
	order by dvt.DoctorVisitTableID desc
	
	IF isnull(@mkabid,0) = 0
	RETURN;

	IF patindex('%_@_%_.__%', @email) <= 0 or (select count(1) from contactEMail_ISKL WITH(NOLOCK) where email = @email) > 0
	BEGIN
		set @email = (
			select top 1 emailp.email 
			from rpt_EmiasPatientEMail emailp WITH(NOLOCK)
				inner join hlt_MKAB mkab WITH(NOLOCK) on mkab.MKABID = @mkabid 
					and emailp.s_pol = mkab.S_POL
					and emailp.n_pol = mkab.N_POL
					and emailp.active = 1
					and emailp.date_bd = mkab.DATE_BD 
					and emailp.email != 'example@mail.ru' 
					and patindex('%_@_%_.__%',emailp.email) > 0
		)

		IF patindex('%_@_%_.__%', isnull(@email,'')) <= 0 
		RETURN 
	END

	--if @res = 'Исследование'	 
	--begin
	--select top 1 @DocFio= isnull(rt.ResearchName,'') from hlt_ActionSchedule ash  with(nolock) 
	--	inner join lbr_LaboratoryResearch lr  with(nolock) on lr.LaboratoryResearchID = ash.rf_DocTypeID 
	--			and ash.DocTypeDefID = (select top 1 DocTypeDefid from x_DocTypeDef where HeadTable = 'lbr_LaboratoryResearch')
	--			and rf_DoctorVisitTableID=@dvtid
	--	inner join lbr_Research r  with(nolock) on r.rf_LaboratoryResearchGUID = lr.guid  
	--	inner join lbr_ResearchType rt with(nolock) on r.rf_ResearchTypeUGUID = rt.uguid and rt.ResearchTypeid>0
	--end


	IF @DocFio = '' or replace(@DocFio,'не известно','') = '' or @DocFio = 'не известно'
	RETURN 

	IF not exists(select * from sys.tables where name = 'contactEMail_ISKL') select convert(varchar(1000),'') as email into contactEMail_ISKL
	
	IF (select count(1) from contactEMail_ISKL where email = @email) > 0
	RETURN
	
	--ПРОСТАВИТЬ АДРЕС!!!!!!!!!
	--SET @email  ='nchernova@softrust.ru'
	--SET @email  ='hmeal95@gmail.com'
	--SET @email  ='ninasvoy@inbox.ru'
	--SET @email  ='emprres@gmail.com'
	--SET @email  ='dim@softrust.ru'
	--SET @email  ='dkhvorostov@gmail.com'
	--SET @email  ='muraleksandrovna@yandex.ru'
	--SET @email  ='rulshin@softrust.ru'

	--if (@email not like '%@softrust.ru%') return

	declare @templateid int =(select top 1 templateMessageId from rpt_templatemessage where isActual =1 and templateCod = 't_remind')
	declare @template varchar(max) = (select templateText from rpt_templatemessage where isActual =1 and templateMessageId = @templateid) --(select dbo.[EMIASMO_PrepareLetterBeforeVisit]())

	SET @template = REPLACE(@template, '__obr', @obr)
	SET @template = REPLACE(@template, '__PatIO', @io)
	SET @template = REPLACE(@template, '__VisitDate', @dttdate)
	SET @template = REPLACE(@template, '__VisitTime', @Begin_Time)
	SET @template = REPLACE(@template, '__Speciality', @Speciality)
	SET @template = REPLACE(@template, '__DocFio', @DocFio)
	SET @template = REPLACE(@template, '__LPUName', @lpu)
	SET @template = REPLACE(@template, '__ADRES', @ADRES)
	SET @template = REPLACE(@template, '__Talon', @talon)
	SET @template = REPLACE(@template, '__Resource', @res)
	SET @template = REPLACE(@template, '__KabNum', @KabNum)
	SET @template = REPLACE(@template, '__dvtGUID', cast(@uguid as varchar(50)))
	SET @template = REPLACE(@template, '__lpuGUID', cast(@uguidLpu as varchar(50)))

	IF len(@template) < 100
		RETURN
				
	--Добавляем запись
	INSERT INTO [dbo].rpt_remindMessage (
		[dvtuguid]
		,[mcod]
		,[docFIO]
		,[rf_MKABID]
		,[visitDate]
		,[email]
		,[senddate]
		,[isSend]		
		)
	SELECT @uguid
		,@mcod
		,@docFIO +' ('+@Speciality+')'
		,@mkabid
		,@date
		,@email
		,getdate()
		,1

	--Отправляем письмо
	EXEC msdb.dbo.sp_send_dbmail @profile_name = 'test'
		,@recipients = @email
		,@subject = 'Вы записаны на приём в поликлинике. Ждём вас!'
		,@body_format = 'HTML'
		,@body = @template

	--Добавляем xml
	INSERT INTO dbo.rpt_remindMessage_xml([uguid],[message],rf_rpt_templatemessageid)
	SELECT @uguid,
	'__obr'+'='+ @obr+';'+
	'__PatIO'+'='+ @io+';'+
	'__VisitDate'+'='+ @dttdate+';'+
	'__VisitTime'+'='+ @Begin_Time+';'+
	'__Speciality'+'='+ @Speciality+';'+
	'__DocFio'+'='+ @DocFio+';'+
	'__LPUName'+'='+ @lpu+';'+
	'__ADRES'+'='+ @ADRES+';'+
	'__Talon'+'='+ @talon+';'+
	'__Resource'+'='+ @res+';'+
	'__KabNum'+'='+ @KabNum+';'+
	'__dvtGUID'+'='+ cast(@uguid as varchar(50))+
	'__lpuGUID'+'='+ cast(@uguidLpu as varchar(50))
	,@templateid
END

go

