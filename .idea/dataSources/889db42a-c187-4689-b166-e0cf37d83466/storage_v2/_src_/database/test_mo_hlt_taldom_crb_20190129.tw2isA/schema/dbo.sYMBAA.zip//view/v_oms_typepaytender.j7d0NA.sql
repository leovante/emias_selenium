CREATE VIEW [V_oms_TypePayTender] AS SELECT 
[hDED].[TypePayTenderID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Note] as [Note]
FROM [oms_TypePayTender] as [hDED]
go

