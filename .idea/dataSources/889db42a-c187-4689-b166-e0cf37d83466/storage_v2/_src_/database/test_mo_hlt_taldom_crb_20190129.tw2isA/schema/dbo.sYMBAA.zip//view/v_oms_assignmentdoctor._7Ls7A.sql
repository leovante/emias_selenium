CREATE VIEW [V_oms_AssignmentDoctor] AS SELECT 
[hDED].[AssignmentDoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidAssignmentDoctor], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Code] as [Code]
FROM [oms_AssignmentDoctor] as [hDED]
go

