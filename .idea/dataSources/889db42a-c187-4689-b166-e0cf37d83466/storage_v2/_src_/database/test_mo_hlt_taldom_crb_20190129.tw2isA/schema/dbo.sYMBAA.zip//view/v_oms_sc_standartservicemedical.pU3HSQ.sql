CREATE VIEW [V_oms_sc_StandartServiceMedical] AS SELECT 
[hDED].[sc_StandartServiceMedicalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PRVDID] as [rf_PRVDID], 
[jT_oms_PRVD].[NAME] as [SILENT_rf_PRVDID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_PRVSID], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[rf_sc_AgeRangeID] as [rf_sc_AgeRangeID], 
[jT_oms_sc_AgeRange].[V_Range] as [SILENT_rf_sc_AgeRangeID], 
[hDED].[ServiceMedicalCode] as [ServiceMedicalCode], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_sc_StandartServiceMedical] as [hDED]
INNER JOIN [oms_PRVD] as [jT_oms_PRVD] on [jT_oms_PRVD].[PRVDID] = [hDED].[rf_PRVDID]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
INNER JOIN [V_oms_sc_AgeRange] as [jT_oms_sc_AgeRange] on [jT_oms_sc_AgeRange].[sc_AgeRangeID] = [hDED].[rf_sc_AgeRangeID]
go

