CREATE VIEW [V_hlt_atc_MilkRecipe] AS SELECT 
[hDED].[atc_MilkRecipeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_atc_ClaimID] as [rf_atc_ClaimID], 
[jT_hlt_atc_Claim].[Num] as [SILENT_rf_atc_ClaimID], 
[hDED].[rf_atc_MilkSetID] as [rf_atc_MilkSetID], 
[jT_hlt_atc_MilkSet].[Num] as [SILENT_rf_atc_MilkSetID], 
[hDED].[Num] as [Num], 
[hDED].[DateRecipe] as [DateRecipe], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_atc_MilkRecipe] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_atc_Claim] as [jT_hlt_atc_Claim] on [jT_hlt_atc_Claim].[atc_ClaimID] = [hDED].[rf_atc_ClaimID]
INNER JOIN [hlt_atc_MilkSet] as [jT_hlt_atc_MilkSet] on [jT_hlt_atc_MilkSet].[atc_MilkSetID] = [hDED].[rf_atc_MilkSetID]
go

