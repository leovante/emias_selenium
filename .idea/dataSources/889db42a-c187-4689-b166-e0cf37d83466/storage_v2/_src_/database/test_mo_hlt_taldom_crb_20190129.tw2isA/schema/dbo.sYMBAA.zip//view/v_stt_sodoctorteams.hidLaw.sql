CREATE VIEW [V_stt_SODoctorTeams] AS SELECT 
[hDED].[SODoctorTeamsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flag] as [Flag], 
[hDED].[GUID] as [GUID]
FROM [stt_SODoctorTeams] as [hDED]
go

