CREATE VIEW [V_hlt_disp_Card] AS SELECT 
[hDED].[disp_CardID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DOGOVORID] as [rf_DOGOVORID], 
[jT_oms_DOGOVOR].[V_Info] as [SILENT_rf_DOGOVORID], 
[hDED].[rf_LpuGuid] as [rf_LpuGuid], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LpuGuid], 
[hDED].[rf_MKBMainID] as [rf_MKBMainID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBMainID], 
[hDED].[rf_MKBAdditionalID] as [rf_MKBAdditionalID], 
[jT_oms_MKB1].[DS] as [SILENT_rf_MKBAdditionalID], 
[hDED].[rf_MKBFinalID] as [rf_MKBFinalID], 
[jT_oms_MKB2].[DS] as [SILENT_rf_MKBFinalID], 
[hDED].[rf_MkabGuid] as [rf_MkabGuid], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MkabGuid], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[rf_PatientModelGuid] as [rf_PatientModelGuid], 
[hDED].[rf_DispTypeGuid] as [rf_DispTypeGuid], 
[jT_hlt_disp_Type].[Name] as [SILENT_rf_DispTypeGuid], 
[hDED].[rf_MainCardGuid] as [rf_MainCardGuid], 
[jT_hlt_disp_Card].[rf_MkabGuid] as [SILENT_rf_MainCardGuid], 
[hDED].[rf_dent_PlanStatusID] as [rf_dent_PlanStatusID], 
[jT_oms_dent_PlanStatus].[Name] as [SILENT_rf_dent_PlanStatusID], 
[hDED].[DateOpen] as [DateOpen], 
[hDED].[DateClose] as [DateClose], 
[hDED].[IsClosed] as [IsClosed], 
[hDED].[IsOtkaz] as [IsOtkaz], 
[hDED].[DateAccept] as [DateAccept], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Number] as [Number], 
[hDED].[DopPriznak] as [DopPriznak], 
[hDED].[Uin] as [Uin], 
[hDED].[UinState] as [UinState], 
[hDED].[IsPay] as [IsPay], 
[hDED].[DateStatus] as [DateStatus], 
[hDED].[rf_disp_ReasonCloseGuid] as [rf_disp_ReasonCloseGuid], 
[hDED].[ReasonCloseDescription] as [ReasonCloseDescription], 
[hDED].[FulfilmentRatio] as [FulfilmentRatio], 
[hDED].[CostTreatment] as [CostTreatment]
FROM [hlt_disp_Card] as [hDED]
INNER JOIN [V_oms_DOGOVOR] as [jT_oms_DOGOVOR] on [jT_oms_DOGOVOR].[DOGOVORID] = [hDED].[rf_DOGOVORID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[GUIDLPU] = [hDED].[rf_LpuGuid]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBMainID]
INNER JOIN [oms_MKB] as [jT_oms_MKB1] on [jT_oms_MKB1].[MKBID] = [hDED].[rf_MKBAdditionalID]
INNER JOIN [oms_MKB] as [jT_oms_MKB2] on [jT_oms_MKB2].[MKBID] = [hDED].[rf_MKBFinalID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[UGUID] = [hDED].[rf_MkabGuid]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
INNER JOIN [hlt_disp_Type] as [jT_hlt_disp_Type] on [jT_hlt_disp_Type].[Guid] = [hDED].[rf_DispTypeGuid]
INNER JOIN [hlt_disp_Card] as [jT_hlt_disp_Card] on [jT_hlt_disp_Card].[Guid] = [hDED].[rf_MainCardGuid]
INNER JOIN [oms_dent_PlanStatus] as [jT_oms_dent_PlanStatus] on [jT_oms_dent_PlanStatus].[dent_PlanStatusID] = [hDED].[rf_dent_PlanStatusID]
go

