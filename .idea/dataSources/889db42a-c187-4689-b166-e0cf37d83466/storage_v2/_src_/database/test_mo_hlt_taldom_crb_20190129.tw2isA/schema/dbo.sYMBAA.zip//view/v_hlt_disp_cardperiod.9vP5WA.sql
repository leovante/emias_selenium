CREATE VIEW [V_hlt_disp_CardPeriod] AS SELECT 
[hDED].[disp_CardPeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DispTypeGuid] as [rf_DispTypeGuid], 
[jT_hlt_disp_Type].[Name] as [SILENT_rf_DispTypeGuid], 
[hDED].[rf_CardGuid] as [rf_CardGuid], 
[jT_hlt_disp_Card].[rf_MkabGuid] as [SILENT_rf_CardGuid], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_CardPeriod] as [hDED]
INNER JOIN [hlt_disp_Type] as [jT_hlt_disp_Type] on [jT_hlt_disp_Type].[Guid] = [hDED].[rf_DispTypeGuid]
INNER JOIN [hlt_disp_Card] as [jT_hlt_disp_Card] on [jT_hlt_disp_Card].[Guid] = [hDED].[rf_CardGuid]
go

