CREATE VIEW [V_oms_ChoicesRegRecipe] AS SELECT 
[hDED].[ChoicesRegRecipeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[field] as [field], 
[hDED].[Caption] as [Caption], 
[hDED].[REM] as [REM], 
[hDED].[Field1] as [Field1], 
[hDED].[Field2] as [Field2]
FROM [oms_ChoicesRegRecipe] as [hDED]
go

