CREATE TRIGGER [LifeTrigger_hlt_NotWorkDoc] ON [hlt_NotWorkDoc] FOR DELETE,INSERT,UPDATE
AS 

SET NOCOUNT ON;

DECLARE @userId INT
DECLARE @seanceId INT 

DECLARE @docTypeId INT 
DECLARE @CURDATE DATETIME


declare @app varchar(50)
declare @index1 int
declare @index2 int


/* @userId, @seanceId */

SET @userId = 0
SET @seanceId = 0

EXEC [GetMalibuContext] @seanceId = @seanceId OUTPUT, @userId = @userId OUTPUT

/* @docTypeId */

SET @CURDATE = getdate()

SET @docTypeId = 0

SELECT TOP 1 @docTypeId = [DocTypeDefID], @seanceId=case WHEN [x_STDO].[HostID] IS NULL THEN @seanceId ELSE 0 END
FROM [x_DocTypeDef] left join [x_STDO] on [x_DocTypeDef].[GUID] = [x_STDO].[DocTypeDef] 
WHERE [HeadTable] = 'hlt_NotWorkDoc'

/* action type */

DECLARE @DEL BIT
DECLARE @INS BIT 

DECLARE @action CHAR(1)


SET @DEL = 0
SET @INS = 0


IF EXISTS (SELECT TOP 1 1 FROM DELETED) SET @DEL=1
IF EXISTS (SELECT TOP 1 1 FROM INSERTED) SET @INS = 1 

IF @INS = 1 AND @DEL = 1 SET @ACTION = 'u'
IF @INS = 1 AND @DEL = 0 SET @ACTION = 'i'
IF @INS = 0 AND @DEL = 1 SET @ACTION = 'd'


IF @ACTION = 'd'
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [NotWorkDocID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM deleted;

	INSERT INTO Life_hlt_NotWorkDoc([NotWorkDocID],[CarePersonAge],[CarePersonAge2],[CarePersonFIO],[CarePersonFIO2],[CarePersonMonth1],[CarePersonMonth2],[CarePersonSex],[CarePersonSex2],[CarePersonYear1],[CarePersonYear2],[Date1],[Date2],[DateBegin],[DateBeginSTT],[DateBreakMode],[DateCertMSE],[DateClose],[DateContinueWork],[DateDirectMSE],[DateEnd],[DateEndSTT],[DateOpen],[DateOther],[DateRegMSE],[DisabledPersonAddress],[DisabledPersonAge],[DisabledPersonFIO],[DisabledPersonSex],[DocCloseNWDS_FIO],[DocCloseNWDS_PCOD],[EstimateDateDelivery],[Fam],[Flag],[GroupInv],[Im],[IsCare],[isClose],[IsComeFromOtherLPU],[isDuplicate],[isGiveAgreement],[isLoadFromCOD],[IsMainPE],[IsNeedToSend],[isNextSoftCopy],[IsNotCloseEvent],[IsOutToOtherLPU],[isRegGovEmpService],[isRegOnEarlyChildbearing],[isSendedToOtherLpu],[isSigned],[isSignedBreak],[isSignedResult],[isSoftCopy],[LnXml],[LpuAddress],[LpuName],[LpuOgrn],[MainDateOpen],[MedCardNum],[Mkb_Code],[N_DUPLICATE_MAIN],[N_NWDS],[N_NWDS_MAIN_PE],[BD],[NotWorkDocMainSN],[NotWorkDocNextSN],[NumEdition],[OGRNSanHosp],[Ot],[PlaceEmployment],[ResultComment],[rf_CareMKAB1ID],[rf_CareMKAB2ID],[rf_CureModeID],[rf_DocCloseNWDSID],[rf_DocPRVDID],[rf_EnterpriseID],[rf_kl_CareSex1ID],[rf_kl_CareSex2ID],[rf_kl_SexID],[rf_kl_SickListReasonChID],[rf_kl_SickListReasonID],[rf_LPUID],[rf_MKABID],[rf_MKBID],[rf_NotWorkDocAddReasonID],[rf_NotWorkDocBreakModeID],[rf_NotWorkDocCare2ID],[rf_NotWorkDocCareID],[rf_NotWorkDocCloseReasonID],[rf_NotWorkDocDisableStateID],[rf_NotWorkDocID],[rf_NotWorkDocReestrID],[rf_NotWorkDocStateID],[rf_NotWorkDocStatusID],[rf_OKATOID],[rf_PR_VS_DocCloseID],[rf_ReasonCareID],[rf_RepresentativeMKABID],[rf_TAPID],[S_NWDS],[S_NWDS_MAIN_PE],[SS],[TravelNum],[UGUID],[x_Edition],[x_Status],[XmlData],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [NotWorkDocID],[CarePersonAge],[CarePersonAge2],[CarePersonFIO],[CarePersonFIO2],[CarePersonMonth1],[CarePersonMonth2],[CarePersonSex],[CarePersonSex2],[CarePersonYear1],[CarePersonYear2],[Date1],[Date2],[DateBegin],[DateBeginSTT],[DateBreakMode],[DateCertMSE],[DateClose],[DateContinueWork],[DateDirectMSE],[DateEnd],[DateEndSTT],[DateOpen],[DateOther],[DateRegMSE],[DisabledPersonAddress],[DisabledPersonAge],[DisabledPersonFIO],[DisabledPersonSex],[DocCloseNWDS_FIO],[DocCloseNWDS_PCOD],[EstimateDateDelivery],[Fam],[Flag],[GroupInv],[Im],[IsCare],[isClose],[IsComeFromOtherLPU],[isDuplicate],[isGiveAgreement],[isLoadFromCOD],[IsMainPE],[IsNeedToSend],[isNextSoftCopy],[IsNotCloseEvent],[IsOutToOtherLPU],[isRegGovEmpService],[isRegOnEarlyChildbearing],[isSendedToOtherLpu],[isSigned],[isSignedBreak],[isSignedResult],[isSoftCopy],[LnXml],[LpuAddress],[LpuName],[LpuOgrn],[MainDateOpen],[MedCardNum],[Mkb_Code],[N_DUPLICATE_MAIN],[N_NWDS],[N_NWDS_MAIN_PE],[BD],[NotWorkDocMainSN],[NotWorkDocNextSN],[NumEdition],[OGRNSanHosp],[Ot],[PlaceEmployment],[ResultComment],[rf_CareMKAB1ID],[rf_CareMKAB2ID],[rf_CureModeID],[rf_DocCloseNWDSID],[rf_DocPRVDID],[rf_EnterpriseID],[rf_kl_CareSex1ID],[rf_kl_CareSex2ID],[rf_kl_SexID],[rf_kl_SickListReasonChID],[rf_kl_SickListReasonID],[rf_LPUID],[rf_MKABID],[rf_MKBID],[rf_NotWorkDocAddReasonID],[rf_NotWorkDocBreakModeID],[rf_NotWorkDocCare2ID],[rf_NotWorkDocCareID],[rf_NotWorkDocCloseReasonID],[rf_NotWorkDocDisableStateID],[rf_NotWorkDocID],[rf_NotWorkDocReestrID],[rf_NotWorkDocStateID],[rf_NotWorkDocStatusID],[rf_OKATOID],[rf_PR_VS_DocCloseID],[rf_ReasonCareID],[rf_RepresentativeMKABID],[rf_TAPID],[S_NWDS],[S_NWDS_MAIN_PE],[SS],[TravelNum],[UGUID],[x_Edition],[x_Status],[XmlData],@action,@CURDATE,@userId,@seanceId FROM deleted;
END;
ELSE
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [NotWorkDocID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM inserted;

	INSERT INTO Life_hlt_NotWorkDoc([NotWorkDocID],[CarePersonAge],[CarePersonAge2],[CarePersonFIO],[CarePersonFIO2],[CarePersonMonth1],[CarePersonMonth2],[CarePersonSex],[CarePersonSex2],[CarePersonYear1],[CarePersonYear2],[Date1],[Date2],[DateBegin],[DateBeginSTT],[DateBreakMode],[DateCertMSE],[DateClose],[DateContinueWork],[DateDirectMSE],[DateEnd],[DateEndSTT],[DateOpen],[DateOther],[DateRegMSE],[DisabledPersonAddress],[DisabledPersonAge],[DisabledPersonFIO],[DisabledPersonSex],[DocCloseNWDS_FIO],[DocCloseNWDS_PCOD],[EstimateDateDelivery],[Fam],[Flag],[GroupInv],[Im],[IsCare],[isClose],[IsComeFromOtherLPU],[isDuplicate],[isGiveAgreement],[isLoadFromCOD],[IsMainPE],[IsNeedToSend],[isNextSoftCopy],[IsNotCloseEvent],[IsOutToOtherLPU],[isRegGovEmpService],[isRegOnEarlyChildbearing],[isSendedToOtherLpu],[isSigned],[isSignedBreak],[isSignedResult],[isSoftCopy],[LnXml],[LpuAddress],[LpuName],[LpuOgrn],[MainDateOpen],[MedCardNum],[Mkb_Code],[N_DUPLICATE_MAIN],[N_NWDS],[N_NWDS_MAIN_PE],[BD],[NotWorkDocMainSN],[NotWorkDocNextSN],[NumEdition],[OGRNSanHosp],[Ot],[PlaceEmployment],[ResultComment],[rf_CareMKAB1ID],[rf_CareMKAB2ID],[rf_CureModeID],[rf_DocCloseNWDSID],[rf_DocPRVDID],[rf_EnterpriseID],[rf_kl_CareSex1ID],[rf_kl_CareSex2ID],[rf_kl_SexID],[rf_kl_SickListReasonChID],[rf_kl_SickListReasonID],[rf_LPUID],[rf_MKABID],[rf_MKBID],[rf_NotWorkDocAddReasonID],[rf_NotWorkDocBreakModeID],[rf_NotWorkDocCare2ID],[rf_NotWorkDocCareID],[rf_NotWorkDocCloseReasonID],[rf_NotWorkDocDisableStateID],[rf_NotWorkDocID],[rf_NotWorkDocReestrID],[rf_NotWorkDocStateID],[rf_NotWorkDocStatusID],[rf_OKATOID],[rf_PR_VS_DocCloseID],[rf_ReasonCareID],[rf_RepresentativeMKABID],[rf_TAPID],[S_NWDS],[S_NWDS_MAIN_PE],[SS],[TravelNum],[UGUID],[x_Edition],[x_Status],[XmlData],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [NotWorkDocID],[CarePersonAge],[CarePersonAge2],[CarePersonFIO],[CarePersonFIO2],[CarePersonMonth1],[CarePersonMonth2],[CarePersonSex],[CarePersonSex2],[CarePersonYear1],[CarePersonYear2],[Date1],[Date2],[DateBegin],[DateBeginSTT],[DateBreakMode],[DateCertMSE],[DateClose],[DateContinueWork],[DateDirectMSE],[DateEnd],[DateEndSTT],[DateOpen],[DateOther],[DateRegMSE],[DisabledPersonAddress],[DisabledPersonAge],[DisabledPersonFIO],[DisabledPersonSex],[DocCloseNWDS_FIO],[DocCloseNWDS_PCOD],[EstimateDateDelivery],[Fam],[Flag],[GroupInv],[Im],[IsCare],[isClose],[IsComeFromOtherLPU],[isDuplicate],[isGiveAgreement],[isLoadFromCOD],[IsMainPE],[IsNeedToSend],[isNextSoftCopy],[IsNotCloseEvent],[IsOutToOtherLPU],[isRegGovEmpService],[isRegOnEarlyChildbearing],[isSendedToOtherLpu],[isSigned],[isSignedBreak],[isSignedResult],[isSoftCopy],[LnXml],[LpuAddress],[LpuName],[LpuOgrn],[MainDateOpen],[MedCardNum],[Mkb_Code],[N_DUPLICATE_MAIN],[N_NWDS],[N_NWDS_MAIN_PE],[BD],[NotWorkDocMainSN],[NotWorkDocNextSN],[NumEdition],[OGRNSanHosp],[Ot],[PlaceEmployment],[ResultComment],[rf_CareMKAB1ID],[rf_CareMKAB2ID],[rf_CureModeID],[rf_DocCloseNWDSID],[rf_DocPRVDID],[rf_EnterpriseID],[rf_kl_CareSex1ID],[rf_kl_CareSex2ID],[rf_kl_SexID],[rf_kl_SickListReasonChID],[rf_kl_SickListReasonID],[rf_LPUID],[rf_MKABID],[rf_MKBID],[rf_NotWorkDocAddReasonID],[rf_NotWorkDocBreakModeID],[rf_NotWorkDocCare2ID],[rf_NotWorkDocCareID],[rf_NotWorkDocCloseReasonID],[rf_NotWorkDocDisableStateID],[rf_NotWorkDocID],[rf_NotWorkDocReestrID],[rf_NotWorkDocStateID],[rf_NotWorkDocStatusID],[rf_OKATOID],[rf_PR_VS_DocCloseID],[rf_ReasonCareID],[rf_RepresentativeMKABID],[rf_TAPID],[S_NWDS],[S_NWDS_MAIN_PE],[SS],[TravelNum],[UGUID],[x_Edition],[x_Status],[XmlData],@action,@CURDATE,@userId,@seanceId FROM inserted;
END; 

SET NOCOUNT OFF;


go

