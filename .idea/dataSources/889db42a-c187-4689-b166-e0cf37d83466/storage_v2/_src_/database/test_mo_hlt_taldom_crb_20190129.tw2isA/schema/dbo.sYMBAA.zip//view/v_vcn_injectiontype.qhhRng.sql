CREATE VIEW [V_vcn_InjectionType] AS SELECT 
[hDED].[InjectionTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
(((Code))) as [V_InjectionTypeCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [vcn_InjectionType] as [hDED]
go

