CREATE VIEW [V_oms_LicenceReestrSM] AS SELECT 
[hDED].[LicenceReestrSMID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_LicenceReestr].[V_M_NAMES] as [V_V_M_NAMES], 
[jT_oms_LicenceReestr].[V_MCOD] as [V_MCOD], 
[jT_oms_Department].[DepartmentNAME] as [V_DepartmentNAME], 
[jT_oms_LicenceReestr].[DateE] as [V_DateE], 
[jT_oms_Department].[GUIDDepartment] as [V_GUIDDepartment], 
[jT_oms_LicenceReestr].[DateB] as [V_DateB], 
[jT_oms_LicenceReestr].[GUIDLicenceReestr] as [V_GUIDLicenceReestr], 
[jT_oms_kl_MedCareType].[Name] as [V_Name], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_PRVSID], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_kl_MedCareTypeID] as [rf_kl_MedCareTypeID], 
[jT_oms_kl_MedCareType].[Code] as [SILENT_rf_kl_MedCareTypeID], 
[hDED].[rf_kl_MedCareLicenceID] as [rf_kl_MedCareLicenceID], 
[jT_oms_kl_MedCareLicence].[Code] as [SILENT_rf_kl_MedCareLicenceID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[rf_LicenceReestrID] as [rf_LicenceReestrID], 
[jT_oms_LicenceReestr].[NumLic] as [SILENT_rf_LicenceReestrID], 
[hDED].[Flags] as [Flags], 
[hDED].[Rem] as [Rem], 
[hDED].[GUIDLicReestr] as [GUIDLicReestr]
FROM [oms_LicenceReestrSM] as [hDED]
INNER JOIN [V_oms_LicenceReestr] as [jT_oms_LicenceReestr] on [jT_oms_LicenceReestr].[LicenceReestrID] = [hDED].[rf_LicenceReestrID]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [oms_kl_MedCareType] as [jT_oms_kl_MedCareType] on [jT_oms_kl_MedCareType].[kl_MedCareTypeID] = [hDED].[rf_kl_MedCareTypeID]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_kl_MedCareLicence] as [jT_oms_kl_MedCareLicence] on [jT_oms_kl_MedCareLicence].[kl_MedCareLicenceID] = [hDED].[rf_kl_MedCareLicenceID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
go

