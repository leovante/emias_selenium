CREATE VIEW [V_dent_Chart] AS SELECT 
[hDED].[ChartID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[IsActive] as [IsActive], 
[hDED].[IsChild] as [IsChild], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dent_Chart] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
go

