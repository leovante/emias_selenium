CREATE VIEW [V_lbr_ResearchSample] AS SELECT 
[hDED].[ResearchSampleID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResearchID] as [rf_ResearchID], 
[hDED].[rf_BioMID] as [rf_BioMID], 
[hDED].[BarCode] as [BarCode], 
[hDED].[Count] as [Count], 
[hDED].[Date] as [Date]
FROM [lbr_ResearchSample] as [hDED]
go

