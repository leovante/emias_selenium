CREATE VIEW [V_hlt_FluorTypeGroupRisk] AS SELECT 
[hDED].[FluorTypeGroupRiskID], [hDED].[x_Edition], [hDED].[x_Status], 
((Code)) as [V_FluorTypeGroupRiskCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_FluorTypeGroupRisk] as [hDED]
go

