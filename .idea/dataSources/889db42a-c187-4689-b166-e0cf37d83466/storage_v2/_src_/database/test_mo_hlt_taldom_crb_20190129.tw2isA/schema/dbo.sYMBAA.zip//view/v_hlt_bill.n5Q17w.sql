CREATE VIEW [V_hlt_Bill] AS SELECT 
[hDED].[BillID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_InvoiceID] as [rf_InvoiceID], 
[hDED].[rf_MoneySupplyID] as [rf_MoneySupplyID], 
[jT_hlt_MoneySupply].[rf_DogovorPayingID] as [SILENT_rf_MoneySupplyID], 
[hDED].[rf_MoneySupplyReturnID] as [rf_MoneySupplyReturnID], 
[jT_hlt_MoneySupply1].[rf_DogovorPayingID] as [SILENT_rf_MoneySupplyReturnID], 
[hDED].[Summ] as [Summ], 
[hDED].[Date] as [Date], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_Bill] as [hDED]
INNER JOIN [hlt_MoneySupply] as [jT_hlt_MoneySupply] on [jT_hlt_MoneySupply].[MoneySupplyID] = [hDED].[rf_MoneySupplyID]
INNER JOIN [hlt_MoneySupply] as [jT_hlt_MoneySupply1] on [jT_hlt_MoneySupply1].[MoneySupplyID] = [hDED].[rf_MoneySupplyReturnID]
go

