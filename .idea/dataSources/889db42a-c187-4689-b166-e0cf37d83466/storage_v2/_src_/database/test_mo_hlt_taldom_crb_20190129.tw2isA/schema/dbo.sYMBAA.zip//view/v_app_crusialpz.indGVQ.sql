CREATE VIEW [V_App_CrusialPZ] AS SELECT 
[hDED].[CrusialPZID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OLSPZID] as [rf_OLSPZID], 
[hDED].[_LPUDoctorID] as [_LPUDoctorID], 
[hDED].[_UchastokID] as [_UchastokID], 
[hDED].[FCompl] as [FCompl], 
[hDED].[LPUDoctorFIO] as [LPUDoctorFIO], 
[hDED].[Uchastok] as [Uchastok]
FROM [App_CrusialPZ] as [hDED]
go

