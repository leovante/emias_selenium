CREATE VIEW [V_hlt_UchastokMkabReturns] AS SELECT 
[hDED].[UchastokMkabReturnsID], [hDED].[x_Edition], [hDED].[x_Status], 
((isnull((select rtrim(ltrim(family + ' ' + name + ' ' + ot))
 from hlt_MKAB 
 join hlt_UchastokMKAB on rf_MKABID = MKABID
 where UchastokMKABID = [hDed].rf_UchastokMKABID ), ''))) as [V_FIO], 
[jT_oms_SMCriterion].[SMCriterionCode] as [V_SMCriterionCode], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[jT_oms_SMCriterion].[SMCriterionCaption] as [SILENT_rf_SMCriterionID], 
[hDED].[rf_UchastokMKABID] as [rf_UchastokMKABID], 
[hDED].[rf_UchastokMkabPositionID] as [rf_UchastokMkabPositionID], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags], 
[hDED].[Rem] as [Rem], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[Fields] as [Fields]
FROM [hlt_UchastokMkabReturns] as [hDED]
INNER JOIN [oms_SMCriterion] as [jT_oms_SMCriterion] on [jT_oms_SMCriterion].[SMCriterionID] = [hDED].[rf_SMCriterionID]
go

