CREATE VIEW [V_hlt_HealingRoom] AS SELECT 
[hDED].[HealingRoomID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_Department].[DepartmentNAME] as [V_DepartmentNAME], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[Num] as [Num], 
[hDED].[Comment] as [Comment], 
[hDED].[Flat] as [Flat], 
[hDED].[UGUID] as [UGUID], 
[hDED].[InTime] as [InTime]
FROM [hlt_HealingRoom] as [hDED]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
go

