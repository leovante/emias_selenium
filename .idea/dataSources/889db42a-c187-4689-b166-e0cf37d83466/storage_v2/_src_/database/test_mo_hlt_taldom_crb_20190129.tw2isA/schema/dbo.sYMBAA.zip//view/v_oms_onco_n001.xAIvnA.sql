CREATE VIEW [V_oms_onco_N001] AS SELECT 
[hDED].[onco_N001ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ID_PrOt] as [ID_PrOt], 
[hDED].[PrOt_NAME] as [PrOt_NAME], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN001] as [GUIDN001]
FROM [oms_onco_N001] as [hDED]
go

