CREATE VIEW [V_oms_mn_GipHistory] AS SELECT 
[hDED].[mn_GipHistoryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_mn_PersonID] as [rf_mn_PersonID], 
[jT_oms_mn_Person].[V_FIO] as [SILENT_rf_mn_PersonID], 
[hDED].[ChangeDate] as [ChangeDate], 
[hDED].[NewId] as [NewId], 
[hDED].[NewGUID] as [NewGUID], 
[hDED].[OldId] as [OldId], 
[hDED].[OldGuid] as [OldGuid], 
[hDED].[IsMerge] as [IsMerge], 
[hDED].[CurrentGuid] as [CurrentGuid]
FROM [oms_mn_GipHistory] as [hDED]
INNER JOIN [V_oms_mn_Person] as [jT_oms_mn_Person] on [jT_oms_mn_Person].[mn_PersonID] = [hDED].[rf_mn_PersonID]
go

