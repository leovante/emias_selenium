CREATE VIEW [V_hlt_RegistrMKB] AS SELECT 
[hDED].[RegistrMKBID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_RegistrTypeID] as [rf_RegistrTypeID], 
[jT_hlt_RegistrType].[Name] as [SILENT_rf_RegistrTypeID], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_RegistrMKB] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [hlt_RegistrType] as [jT_hlt_RegistrType] on [jT_hlt_RegistrType].[RegistrTypeID] = [hDED].[rf_RegistrTypeID]
go

