CREATE VIEW [V_vcn_Schema] AS SELECT 
[hDED].[SchemaID], [hDED].[x_Edition], [hDED].[x_Status], 
('лет: ' + cast([hDED].[ageMaxY] as varchar) + ', мес.: ' + cast([hDED].[ageMaxM] as varchar) + ', дн.: ' + cast([hDED].[ageMaxD] as varchar)) as [V_ageMax], 
(hded.GUID) as [V_SchemaGUID], 
[jT_vcn_Contingent].[Code] as [V_ContingentCode], 
[jT_oms_kl_Sex].[Code] as [V_SexCode], 
[jT_vcn_Reason].[GUID] as [V_ReasonGuid], 
[jT_vcn_Season].[Code] as [V_SeasonCode], 
[jT_vcn_VaccinationGroup].[Code] as [V_VaccinationGroupCode], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[rf_ContingentID] as [rf_ContingentID], 
[jT_vcn_Contingent].[Name] as [SILENT_rf_ContingentID], 
[hDED].[rf_ReasonID] as [rf_ReasonID], 
[hDED].[rf_VaccinationGroupID] as [rf_VaccinationGroupID], 
[jT_vcn_VaccinationGroup].[Name] as [SILENT_rf_VaccinationGroupID], 
[hDED].[rf_SeasonID] as [rf_SeasonID], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[isActive] as [isActive], 
[hDED].[GUID] as [GUID], 
[hDED].[ageMaxY] as [ageMaxY], 
[hDED].[ageMaxM] as [ageMaxM], 
[hDED].[ageMaxD] as [ageMaxD]
FROM [vcn_Schema] as [hDED]
INNER JOIN [vcn_Contingent] as [jT_vcn_Contingent] on [jT_vcn_Contingent].[ContingentID] = [hDED].[rf_ContingentID]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
INNER JOIN [vcn_Reason] as [jT_vcn_Reason] on [jT_vcn_Reason].[ReasonID] = [hDED].[rf_ReasonID]
INNER JOIN [vcn_Season] as [jT_vcn_Season] on [jT_vcn_Season].[SeasonID] = [hDED].[rf_SeasonID]
INNER JOIN [vcn_VaccinationGroup] as [jT_vcn_VaccinationGroup] on [jT_vcn_VaccinationGroup].[VaccinationGroupID] = [hDED].[rf_VaccinationGroupID]
go

