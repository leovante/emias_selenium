CREATE VIEW [V_stt_Operation] AS SELECT 
[hDED].[OperationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_ServiceMedicalID] as [rf_kl_ServiceMedicalID], 
[hDED].[rf_OperationTypeID] as [rf_OperationTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[ShortName] as [ShortName], 
[hDED].[Description] as [Description], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_Operation] as [hDED]
go

