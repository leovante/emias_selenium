CREATE VIEW [V_hlt_atc_PayCategory] AS SELECT 
[hDED].[atc_PayCategoryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_atc_CategoryID] as [rf_atc_CategoryID], 
[jT_hlt_atc_Category].[Name] as [SILENT_rf_atc_CategoryID], 
[hDED].[AgeFrom] as [AgeFrom], 
[hDED].[AgeTo] as [AgeTo], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_atc_PayCategory] as [hDED]
INNER JOIN [hlt_atc_Category] as [jT_hlt_atc_Category] on [jT_hlt_atc_Category].[atc_CategoryID] = [hDED].[rf_atc_CategoryID]
go

