CREATE VIEW [V_lbr_ResearchResultMbl] AS SELECT 
[hDED].[ResearchResultMblID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResearchResultUGUID] as [rf_ResearchResultUGUID], 
[hDED].[rf_MicrobeID] as [rf_MicrobeID], 
[jT_lbr_Microbe].[Name] as [SILENT_rf_MicrobeID], 
[hDED].[Result] as [Result], 
[hDED].[Conc] as [Conc], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [lbr_ResearchResultMbl] as [hDED]
INNER JOIN [lbr_Microbe] as [jT_lbr_Microbe] on [jT_lbr_Microbe].[MicrobeID] = [hDED].[rf_MicrobeID]
go

