CREATE VIEW [V_hlt_NotWorkDocNumRange] AS SELECT 
[hDED].[NotWorkDocNumRangeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Num] as [Num], 
[hDED].[DateRecieve] as [DateRecieve], 
[hDED].[isUsed] as [isUsed], 
[hDED].[Flags] as [Flags]
FROM [hlt_NotWorkDocNumRange] as [hDED]
go

