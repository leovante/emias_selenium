CREATE VIEW [V_oms_dent_PlanStatus] AS SELECT 
[hDED].[dent_PlanStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
(hDed.Guid) as [V_GuidPlanType], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [oms_dent_PlanStatus] as [hDED]
go

