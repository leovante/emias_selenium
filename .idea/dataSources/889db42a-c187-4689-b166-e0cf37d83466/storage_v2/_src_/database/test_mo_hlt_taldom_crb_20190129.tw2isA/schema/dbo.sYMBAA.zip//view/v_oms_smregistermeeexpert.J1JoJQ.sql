CREATE VIEW [V_oms_SMRegisterMEEExpert] AS SELECT 
[hDED].[SMRegisterMEEExpertID], [hDED].[x_Edition], [hDED].[x_Status], 
(FAMILY+' '+Im+' '+Ot) as [V_FIO], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[hDED].[rf_KV_KATID] as [rf_KV_KATID], 
[jT_oms_KV_KAT].[KV_KAT_NAME] as [SILENT_rf_KV_KATID], 
[hDED].[Family] as [Family], 
[hDED].[Im] as [Im], 
[hDED].[Ot] as [Ot], 
[hDED].[Num] as [Num], 
[hDED].[DateDog] as [DateDog], 
[hDED].[Rem] as [Rem], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Post] as [Post]
FROM [oms_SMRegisterMEEExpert] as [hDED]
INNER JOIN [oms_KV_KAT] as [jT_oms_KV_KAT] on [jT_oms_KV_KAT].[KV_KATID] = [hDED].[rf_KV_KATID]
go

