CREATE VIEW [V_oms_TypeDelivery] AS SELECT 
[hDED].[TypeDeliveryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Note] as [Note], 
[hDED].[Code] as [Code]
FROM [oms_TypeDelivery] as [hDED]
go

