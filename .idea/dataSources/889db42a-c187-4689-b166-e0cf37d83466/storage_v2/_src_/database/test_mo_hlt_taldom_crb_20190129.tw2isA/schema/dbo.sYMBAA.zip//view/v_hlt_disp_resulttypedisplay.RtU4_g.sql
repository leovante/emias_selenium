CREATE VIEW [V_hlt_disp_ResultTypeDisplay] AS SELECT 
[hDED].[disp_ResultTypeDisplayID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName]
FROM [hlt_disp_ResultTypeDisplay] as [hDED]
go

