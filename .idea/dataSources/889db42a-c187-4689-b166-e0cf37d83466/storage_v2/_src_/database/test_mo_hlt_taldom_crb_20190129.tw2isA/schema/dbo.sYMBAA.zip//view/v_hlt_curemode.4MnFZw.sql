CREATE VIEW [V_hlt_CureMode] AS SELECT 
[hDED].[CureModeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description]
FROM [hlt_CureMode] as [hDED]
go

