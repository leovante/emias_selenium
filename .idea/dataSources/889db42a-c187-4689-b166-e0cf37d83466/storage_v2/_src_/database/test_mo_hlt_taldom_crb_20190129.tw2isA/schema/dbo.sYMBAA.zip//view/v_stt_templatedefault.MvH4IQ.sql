CREATE VIEW [V_stt_TemplateDefault] AS SELECT 
[hDED].[TemplateDefaultID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_TemplateTypeID] as [rf_TemplateTypeID], 
[hDED].[rf_TemplateDefaultID] as [rf_TemplateDefaultID], 
[hDED].[TemplateTag] as [TemplateTag]
FROM [stt_TemplateDefault] as [hDED]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
go

