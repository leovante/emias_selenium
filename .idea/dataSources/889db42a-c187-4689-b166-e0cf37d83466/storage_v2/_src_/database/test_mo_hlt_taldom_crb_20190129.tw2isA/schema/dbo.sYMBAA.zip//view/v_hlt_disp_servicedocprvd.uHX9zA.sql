CREATE VIEW [V_hlt_disp_ServiceDocPrvd] AS SELECT 
[hDED].[disp_ServiceDocPrvdID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DocPrvdGuid] as [rf_DocPrvdGuid], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPrvdGuid], 
[hDED].[rf_ServiceGuid] as [rf_ServiceGuid], 
[jT_hlt_disp_Service].[Name] as [SILENT_rf_ServiceGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_ServiceDocPrvd] as [hDED]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[GUID] = [hDED].[rf_DocPrvdGuid]
INNER JOIN [hlt_disp_Service] as [jT_hlt_disp_Service] on [jT_hlt_disp_Service].[Guid] = [hDED].[rf_ServiceGuid]
go

