CREATE VIEW [V_oms_kl_VidHMP] AS SELECT 
[hDED].[kl_VidHMPID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CodeVid] as [CodeVid], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[GUIDVidHMP] as [GUIDVidHMP]
FROM [oms_kl_VidHMP] as [hDED]
go

