CREATE VIEW [V_oms_TYPEDOG] AS SELECT 
[hDED].[TYPEDOGID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[NAME] as [NAME]
FROM [oms_TYPEDOG] as [hDED]
go

