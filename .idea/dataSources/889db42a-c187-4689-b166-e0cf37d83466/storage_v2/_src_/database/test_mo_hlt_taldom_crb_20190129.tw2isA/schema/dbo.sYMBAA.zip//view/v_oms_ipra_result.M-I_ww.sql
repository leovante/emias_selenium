CREATE VIEW [V_oms_ipra_Result] AS SELECT 
[hDED].[ipra_ResultID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[SHName] as [SHName], 
[hDED].[Code] as [Code], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [oms_ipra_Result] as [hDED]
go

