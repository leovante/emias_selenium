CREATE VIEW [V_dd_DDTypeDisease] AS SELECT 
[hDED].[DDTypeDiseaseID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDTypeDisease] as [hDED]
go

