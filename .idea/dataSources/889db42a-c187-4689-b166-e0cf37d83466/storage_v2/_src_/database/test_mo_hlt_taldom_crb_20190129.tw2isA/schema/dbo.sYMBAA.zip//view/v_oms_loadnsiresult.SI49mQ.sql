CREATE VIEW [V_oms_LoadNSIResult] AS SELECT 
[hDED].[LoadNSIResultID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LoadNSIReestrID] as [rf_LoadNSIReestrID], 
[hDED].[rf_LoadNSITableID] as [rf_LoadNSITableID], 
[hDED].[ErrorName] as [ErrorName], 
[hDED].[Name_LT] as [Name_LT], 
[hDED].[Desc_LT] as [Desc_LT], 
[hDED].[Name_Field] as [Name_Field], 
[hDED].[Desc_Field] as [Desc_Field], 
[hDED].[Value_Field] as [Value_Field], 
[hDED].[Kol] as [Kol], 
[hDED].[Rem] as [Rem]
FROM [oms_LoadNSIResult] as [hDED]
go

