CREATE VIEW [V_kla_Street] AS SELECT 
[hDED].[StreetID], [hDED].[x_Edition], [hDED].[x_Status], 
(((hDed.[Name] + ' ' + hDed.[SOCR] ))) as [V_FullName], 
[hDED].[rf_KlAdrID] as [rf_KlAdrID], 
[hDED].[SOCR] as [SOCR], 
[hDED].[CODE] as [CODE], 
[hDED].[UNO] as [UNO], 
[hDED].[OCATD] as [OCATD], 
[hDED].[Flags] as [Flags], 
[hDED].[Source] as [Source], 
[hDED].[AltCode] as [AltCode], 
[hDED].[Name] as [Name], 
[hDED].[AddressString] as [AddressString], 
[hDED].[GNINMB] as [GNINMB], 
[hDED].[PostIndex] as [PostIndex]
FROM [kla_Street] as [hDED]
go

