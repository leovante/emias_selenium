CREATE VIEW [V_oms_SMExpTarget] AS SELECT 
[hDED].[SMExpTargetID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[NameExpTarget] as [NameExpTarget], 
[hDED].[INV] as [INV]
FROM [oms_SMExpTarget] as [hDED]
go

