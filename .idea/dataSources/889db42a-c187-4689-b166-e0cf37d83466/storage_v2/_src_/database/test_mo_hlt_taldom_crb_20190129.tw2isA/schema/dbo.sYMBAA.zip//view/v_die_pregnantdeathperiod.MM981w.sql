CREATE VIEW [V_die_PregnantDeathPeriod] AS SELECT 
[hDED].[PregnantDeathPeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [die_PregnantDeathPeriod] as [hDED]
go

