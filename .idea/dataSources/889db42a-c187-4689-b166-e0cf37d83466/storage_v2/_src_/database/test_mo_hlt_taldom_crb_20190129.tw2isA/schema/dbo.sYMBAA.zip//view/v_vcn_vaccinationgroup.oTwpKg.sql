CREATE VIEW [V_vcn_VaccinationGroup] AS SELECT 
[hDED].[VaccinationGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_VaccinationGroupCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [vcn_VaccinationGroup] as [hDED]
go

