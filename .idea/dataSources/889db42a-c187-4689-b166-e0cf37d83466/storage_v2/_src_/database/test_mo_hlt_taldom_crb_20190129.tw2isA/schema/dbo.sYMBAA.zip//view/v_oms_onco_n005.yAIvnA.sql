CREATE VIEW [V_oms_onco_N005] AS SELECT 
[hDED].[onco_N005ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[ID_M] as [ID_M], 
[hDED].[DS_M] as [DS_M], 
[hDED].[KOD_M] as [KOD_M], 
[hDED].[M_NAME] as [M_NAME], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN005] as [GUIDN005]
FROM [oms_onco_N005] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
go

