CREATE VIEW [V_stt_BranchProfile] AS SELECT 
[hDED].[BranchProfileID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[jT_stt_StationarBranch].[V_BranchInfo] as [SILENT_rf_StationarBranchID], 
[hDED].[rf_BedProfileID] as [rf_BedProfileID], 
[jT_stt_BedProfile].[Name] as [SILENT_rf_BedProfileID], 
[hDED].[BedsCount] as [BedsCount], 
[hDED].[Reason] as [Reason], 
[hDED].[Date] as [Date], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[isActive] as [isActive], 
[hDED].[SystemDate] as [SystemDate], 
[hDED].[flags] as [flags], 
[hDED].[UGUID] as [UGUID]
FROM [stt_BranchProfile] as [hDED]
INNER JOIN [V_stt_StationarBranch] as [jT_stt_StationarBranch] on [jT_stt_StationarBranch].[StationarBranchID] = [hDED].[rf_StationarBranchID]
INNER JOIN [stt_BedProfile] as [jT_stt_BedProfile] on [jT_stt_BedProfile].[BedProfileID] = [hDED].[rf_BedProfileID]
go

