CREATE VIEW [V_oms_BadRecipes] AS SELECT 
[hDED].[BadRecipesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PersonID] as [rf_PersonID], 
[hDED].[rf_DoctorID] as [rf_DoctorID], 
[hDED].[rf_ReesrLogID] as [rf_ReesrLogID], 
[hDED].[rf_LoadErrorsID] as [rf_LoadErrorsID], 
[hDED].[S_LR] as [S_LR], 
[hDED].[N_LR] as [N_LR]
FROM [oms_BadRecipes] as [hDED]
go

