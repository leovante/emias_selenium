CREATE VIEW [V_oms_PRVS] AS SELECT 
[hDED].[PRVSID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_PRVS].[C_PRVS] as [V_Main_C_PRVS], 
[hDED].[rf_PRVDID] as [rf_PRVDID], 
[jT_oms_PRVD].[NAME] as [SILENT_rf_PRVDID], 
[hDED].[rf_MainPRVSID] as [rf_MainPRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_MainPRVSID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[I_PRVS] as [I_PRVS], 
[hDED].[C_PRVS] as [C_PRVS], 
[hDED].[PRVS_NAME] as [PRVS_NAME], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[Date_Beg] as [Date_Beg], 
[hDED].[Date_End] as [Date_End], 
[hDED].[PostName] as [PostName], 
[hDED].[IDPost_MZ] as [IDPost_MZ]
FROM [oms_PRVS] as [hDED]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_MainPRVSID]
INNER JOIN [oms_PRVD] as [jT_oms_PRVD] on [jT_oms_PRVD].[PRVDID] = [hDED].[rf_PRVDID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
go

