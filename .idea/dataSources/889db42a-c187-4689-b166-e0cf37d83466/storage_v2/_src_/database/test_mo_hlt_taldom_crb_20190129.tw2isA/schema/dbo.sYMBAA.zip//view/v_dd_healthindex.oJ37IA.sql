CREATE VIEW [V_dd_HealthIndex] AS SELECT 
[hDED].[HealthIndexID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDHealthIndexDataTypeGUID] as [rf_DDHealthIndexDataTypeGUID], 
[hDED].[rf_HealthIndexUnitUGUID] as [rf_HealthIndexUnitUGUID], 
[hDED].[HealthIndexName] as [HealthIndexName], 
[hDED].[HealthIndexCode] as [HealthIndexCode], 
[hDED].[Flag] as [Flag], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[MinValue] as [MinValue], 
[hDED].[MaxValue] as [MaxValue], 
[hDED].[SortNum] as [SortNum], 
[hDED].[IsMain] as [IsMain]
FROM [dd_HealthIndex] as [hDED]
go

