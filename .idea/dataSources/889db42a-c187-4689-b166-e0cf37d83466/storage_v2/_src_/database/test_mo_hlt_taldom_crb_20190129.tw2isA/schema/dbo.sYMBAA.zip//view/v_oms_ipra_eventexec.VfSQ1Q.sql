CREATE VIEW [V_oms_ipra_EventExec] AS SELECT 
[hDED].[ipra_EventExecID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_ipra_EventID] as [rf_ipra_EventID], 
[jT_oms_ipra_Event].[rf_ipra_EventGroupID] as [SILENT_rf_ipra_EventID], 
[hDED].[rf_ipra_TypeEventID] as [rf_ipra_TypeEventID], 
[jT_oms_ipra_TypeEvent].[SHName] as [SILENT_rf_ipra_TypeEventID], 
[hDED].[rf_ipra_ResultID] as [rf_ipra_ResultID], 
[jT_oms_ipra_Result].[SHName] as [SILENT_rf_ipra_ResultID], 
[hDED].[Result] as [Result], 
[hDED].[Name] as [Name], 
[hDED].[GUID] as [GUID], 
[hDED].[ExecDate] as [ExecDate], 
[hDED].[Description] as [Description], 
[hDED].[IsExport] as [IsExport], 
[hDED].[ExportDate] as [ExportDate], 
[hDED].[NameLpu] as [NameLpu]
FROM [oms_ipra_EventExec] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_ipra_Event] as [jT_oms_ipra_Event] on [jT_oms_ipra_Event].[ipra_EventID] = [hDED].[rf_ipra_EventID]
INNER JOIN [oms_ipra_TypeEvent] as [jT_oms_ipra_TypeEvent] on [jT_oms_ipra_TypeEvent].[ipra_TypeEventID] = [hDED].[rf_ipra_TypeEventID]
INNER JOIN [oms_ipra_Result] as [jT_oms_ipra_Result] on [jT_oms_ipra_Result].[ipra_ResultID] = [hDED].[rf_ipra_ResultID]
go

