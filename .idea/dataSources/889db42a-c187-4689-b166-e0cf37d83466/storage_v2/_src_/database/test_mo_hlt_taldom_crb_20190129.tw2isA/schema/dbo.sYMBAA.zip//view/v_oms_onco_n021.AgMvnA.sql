CREATE VIEW [V_oms_onco_N021] AS SELECT 
[hDED].[onco_N021ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ExpertKSGCriterionID] as [rf_ExpertKSGCriterionID], 
[jT_oms_ExpertKSGCriterion].[CodeKSGCriterion] as [SILENT_rf_ExpertKSGCriterionID], 
[hDED].[rf_onco_N020ID] as [rf_onco_N020ID], 
[jT_oms_onco_N020].[MNN] as [SILENT_rf_onco_N020ID], 
[hDED].[ID_ZAP] as [ID_ZAP], 
[hDED].[CODE_SH] as [CODE_SH], 
[hDED].[ID_LEKP] as [ID_LEKP], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN021] as [GUIDN021]
FROM [oms_onco_N021] as [hDED]
INNER JOIN [oms_ExpertKSGCriterion] as [jT_oms_ExpertKSGCriterion] on [jT_oms_ExpertKSGCriterion].[ExpertKSGCriterionID] = [hDED].[rf_ExpertKSGCriterionID]
INNER JOIN [oms_onco_N020] as [jT_oms_onco_N020] on [jT_oms_onco_N020].[onco_N020ID] = [hDED].[rf_onco_N020ID]
go

