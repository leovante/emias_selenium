CREATE VIEW [V_oms_dent_CanalCondition] AS SELECT 
[hDED].[dent_CanalConditionID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidCanalCondition], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [oms_dent_CanalCondition] as [hDED]
go

