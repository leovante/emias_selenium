CREATE VIEW [V_oms_SMRegisterQuery] AS SELECT 
[hDED].[SMRegisterQueryID], [hDED].[x_Edition], [hDED].[x_Status], 
(((((select FIO from x_User where UserId = LastUserID))))) as [V_FIOUser], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_SMExpReasonID] as [rf_SMExpReasonID], 
[jT_oms_SMExpReason].[NameExpReason] as [SILENT_rf_SMExpReasonID], 
[hDED].[rf_SMRegisterQueryID] as [rf_SMRegisterQueryID], 
[hDED].[DateRecord] as [DateRecord], 
[hDED].[LastUserID] as [LastUserID], 
[hDED].[Num] as [Num], 
[hDED].[DateSend] as [DateSend], 
[hDED].[DateExec] as [DateExec], 
[hDED].[DateClose] as [DateClose], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [oms_SMRegisterQuery] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_SMExpReason] as [jT_oms_SMExpReason] on [jT_oms_SMExpReason].[SMExpReasonID] = [hDED].[rf_SMExpReasonID]
go

