CREATE VIEW [V_oms_DocTemplaty] AS SELECT 
[hDED].[DocTemplatyID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Rem] as [Rem], 
[hDED].[Tabl] as [Tabl]
FROM [oms_DocTemplaty] as [hDED]
go

