CREATE VIEW [V_oms_PositionBill] AS SELECT 
[hDED].[PositionBillID], [hDED].[x_Edition], [hDED].[x_Status], 
(hDED.Count*hDED.Price) as [V_Sum], 
(hDED.Count*hDED.Price*hDED.NDS/100/(1+hDED.NDS/100)) as [V_SumNDS], 
[hDED].[rf_SFOID] as [rf_SFOID], 
[hDED].[rf_CLSID] as [rf_CLSID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[jT_oms_Tender].[Num] as [SILENT_rf_TenderID], 
[hDED].[rf_BillTenderID] as [rf_BillTenderID], 
[hDED].[Count] as [Count], 
[hDED].[Price] as [Price], 
[hDED].[NDS] as [NDS], 
[hDED].[Series] as [Series], 
[hDED].[EAN13] as [EAN13], 
[hDED].[Note] as [Note], 
[hDED].[ExpDate] as [ExpDate], 
[hDED].[RegNum] as [RegNum], 
[hDED].[CountFact] as [CountFact], 
[hDED].[C_LSFO] as [C_LSFO], 
[hDED].[Product] as [Product], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[Partia] as [Partia], 
[hDED].[Producer] as [Producer], 
[hDED].[Producer_land] as [Producer_land]
FROM [oms_PositionBill] as [hDED]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
INNER JOIN [oms_Tender] as [jT_oms_Tender] on [jT_oms_Tender].[TenderID] = [hDED].[rf_TenderID]
go

