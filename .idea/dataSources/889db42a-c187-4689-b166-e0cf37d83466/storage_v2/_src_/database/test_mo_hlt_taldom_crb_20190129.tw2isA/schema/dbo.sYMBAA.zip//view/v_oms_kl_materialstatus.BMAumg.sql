CREATE VIEW [V_oms_kl_MaterialStatus] AS SELECT 
[hDED].[kl_MaterialStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[GuidMaterialStatus] as [GuidMaterialStatus]
FROM [oms_kl_MaterialStatus] as [hDED]
go

