CREATE VIEW [V_dent_CardRoot] AS SELECT 
[hDED].[CardRootID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_dent_RootCanalID] as [rf_dent_RootCanalID], 
[jT_oms_dent_RootCanal].[Name] as [SILENT_rf_dent_RootCanalID], 
[hDED].[rf_dent_RootConditionID] as [rf_dent_RootConditionID], 
[jT_oms_dent_RootCondition].[Name] as [SILENT_rf_dent_RootConditionID], 
[hDED].[rf_CardToothID] as [rf_CardToothID], 
[jT_dent_CardTooth].[Date] as [SILENT_rf_CardToothID], 
[hDED].[Date] as [Date], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Note] as [Note]
FROM [dent_CardRoot] as [hDED]
INNER JOIN [oms_dent_RootCanal] as [jT_oms_dent_RootCanal] on [jT_oms_dent_RootCanal].[dent_RootCanalID] = [hDED].[rf_dent_RootCanalID]
INNER JOIN [oms_dent_RootCondition] as [jT_oms_dent_RootCondition] on [jT_oms_dent_RootCondition].[dent_RootConditionID] = [hDED].[rf_dent_RootConditionID]
INNER JOIN [dent_CardTooth] as [jT_dent_CardTooth] on [jT_dent_CardTooth].[CardToothID] = [hDED].[rf_CardToothID]
go

