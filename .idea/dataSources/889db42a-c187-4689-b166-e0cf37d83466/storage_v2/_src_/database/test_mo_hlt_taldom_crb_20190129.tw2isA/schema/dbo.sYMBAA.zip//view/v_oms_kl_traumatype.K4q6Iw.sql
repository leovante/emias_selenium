CREATE VIEW [V_oms_kl_TraumaType] AS SELECT 
[hDED].[kl_TraumaTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_TraumaTypeCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_TraumaType] as [hDED]
go

