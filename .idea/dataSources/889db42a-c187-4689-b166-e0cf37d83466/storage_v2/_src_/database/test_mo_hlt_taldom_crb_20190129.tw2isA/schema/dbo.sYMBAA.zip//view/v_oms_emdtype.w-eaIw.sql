CREATE VIEW [V_oms_EmdType] AS SELECT 
[hDED].[EmdTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[GUID] as [GUID]
FROM [oms_EmdType] as [hDED]
go

