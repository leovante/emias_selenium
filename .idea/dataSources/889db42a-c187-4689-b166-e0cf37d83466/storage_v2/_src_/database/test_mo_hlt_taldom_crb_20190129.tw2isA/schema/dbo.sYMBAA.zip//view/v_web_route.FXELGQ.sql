CREATE VIEW [V_web_Route] AS SELECT 
[hDED].[RouteID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ControllerName] as [ControllerName], 
[hDED].[ActionName] as [ActionName], 
[hDED].[Guid] as [Guid]
FROM [web_Route] as [hDED]
go

