CREATE VIEW [V_hlt_disp_Variant] AS SELECT 
[hDED].[disp_VariantID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Guid] as [Guid], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [hlt_disp_Variant] as [hDED]
go

