CREATE VIEW [V_mail_Message] AS SELECT 
[hDED].[MessageID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_mail_MessageState].[FriendlyName] as [V_MessageState], 
[hDED].[rf_MessageTypeID] as [rf_MessageTypeID], 
[hDED].[rf_MessageStateID] as [rf_MessageStateID], 
[hDED].[rf_WarningLvlID] as [rf_WarningLvlID], 
[hDED].[Header] as [Header], 
[hDED].[Body] as [Body], 
[hDED].[IsBroadcast] as [IsBroadcast], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[IncomeDate] as [IncomeDate], 
[hDED].[Sender] as [Sender], 
[hDED].[UniqueID] as [UniqueID]
FROM [mail_Message] as [hDED]
INNER JOIN [mail_MessageState] as [jT_mail_MessageState] on [jT_mail_MessageState].[MessageStateID] = [hDED].[rf_MessageStateID]
go

