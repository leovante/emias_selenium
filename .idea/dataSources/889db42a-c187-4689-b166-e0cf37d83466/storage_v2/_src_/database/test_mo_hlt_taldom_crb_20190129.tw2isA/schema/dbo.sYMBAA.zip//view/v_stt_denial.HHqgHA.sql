CREATE VIEW [V_stt_Denial] AS SELECT 
[hDED].[DenialID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_StationarTypeID] as [rf_StationarTypeID], 
[jT_stt_StationarType].[Name] as [SILENT_rf_StationarTypeID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_DenialCauseID] as [rf_DenialCauseID], 
[hDED].[FAM] as [FAM], 
[hDED].[Name] as [Name], 
[hDED].[OT] as [OT], 
[hDED].[SS] as [SS], 
[hDED].[DenialReason] as [DenialReason], 
[hDED].[DateTime] as [DateTime], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [stt_Denial] as [hDED]
INNER JOIN [stt_StationarType] as [jT_stt_StationarType] on [jT_stt_StationarType].[StationarTypeID] = [hDED].[rf_StationarTypeID]
go

