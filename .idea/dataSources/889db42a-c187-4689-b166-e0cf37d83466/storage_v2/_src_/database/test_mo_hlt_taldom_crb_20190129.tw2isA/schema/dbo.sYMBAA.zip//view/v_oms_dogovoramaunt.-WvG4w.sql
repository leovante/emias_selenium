CREATE VIEW [V_oms_DogovorAmaunt] AS SELECT 
[hDED].[DogovorAmauntID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DOGOVORID] as [rf_DOGOVORID], 
[jT_oms_DOGOVOR].[V_Info] as [SILENT_rf_DOGOVORID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[rf_DoctorTerritoryID] as [rf_DoctorTerritoryID], 
[hDED].[rf_DogovorAmauntTypeID] as [rf_DogovorAmauntTypeID], 
[jT_oms_DogovorAmauntType].[Name] as [SILENT_rf_DogovorAmauntTypeID], 
[hDED].[DateB] as [DateB], 
[hDED].[DateE] as [DateE], 
[hDED].[Amount] as [Amount], 
[hDED].[Delta] as [Delta], 
[hDED].[Price] as [Price], 
[hDED].[Amount_ED] as [Amount_ED], 
[hDED].[Price_POD] as [Price_POD], 
[hDED].[GUIDDogAmaunt] as [GUIDDogAmaunt], 
[hDED].[Flag] as [Flag], 
[hDED].[Rem] as [Rem]
FROM [oms_DogovorAmaunt] as [hDED]
INNER JOIN [V_oms_DOGOVOR] as [jT_oms_DOGOVOR] on [jT_oms_DOGOVOR].[DOGOVORID] = [hDED].[rf_DOGOVORID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
INNER JOIN [oms_DogovorAmauntType] as [jT_oms_DogovorAmauntType] on [jT_oms_DogovorAmauntType].[DogovorAmauntTypeID] = [hDED].[rf_DogovorAmauntTypeID]
go

