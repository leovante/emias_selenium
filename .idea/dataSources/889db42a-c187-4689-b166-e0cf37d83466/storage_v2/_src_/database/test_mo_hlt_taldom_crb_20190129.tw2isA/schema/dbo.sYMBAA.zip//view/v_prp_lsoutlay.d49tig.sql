CREATE VIEW [V_prp_LSOutlay] AS SELECT 
[hDED].[LSOutlayID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ListOfPurposeID] as [rf_ListOfPurposeID], 
[jT_prp_ListOfPurpose].[Signature] as [SILENT_rf_ListOfPurposeID], 
[hDED].[rf_PLPositionID] as [rf_PLPositionID], 
[jT_prp_PLPosition].[Flag] as [SILENT_rf_PLPositionID], 
[hDED].[CodeRAS] as [CodeRAS], 
[hDED].[Date] as [Date], 
[hDED].[Dose] as [Dose], 
[hDED].[Flag] as [Flag], 
[hDED].[Name] as [Name], 
[hDED].[RealCount] as [RealCount], 
[hDED].[UGUID] as [UGUID], 
[hDED].[UnitDose] as [UnitDose], 
[hDED].[Writed] as [Writed], 
[hDED].[rf_StoreID] as [rf_StoreID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID]
FROM [prp_LSOutlay] as [hDED]
INNER JOIN [prp_ListOfPurpose] as [jT_prp_ListOfPurpose] on [jT_prp_ListOfPurpose].[ListOfPurposeID] = [hDED].[rf_ListOfPurposeID]
INNER JOIN [prp_PLPosition] as [jT_prp_PLPosition] on [jT_prp_PLPosition].[PLPositionID] = [hDED].[rf_PLPositionID]
go

