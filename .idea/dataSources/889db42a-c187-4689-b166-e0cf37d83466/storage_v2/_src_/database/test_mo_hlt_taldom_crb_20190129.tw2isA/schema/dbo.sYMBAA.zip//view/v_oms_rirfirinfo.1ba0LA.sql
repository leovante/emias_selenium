CREATE VIEW [V_oms_RIRFIRInfo] AS SELECT 
[hDED].[RIRFIRInfoID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[jT_oms_Reestr].[rf_STFIID] as [SILENT_rf_ReestrID], 
[hDED].[TFOMS_Ogrn] as [TFOMS_Ogrn], 
[hDED].[TFOMS_Name] as [TFOMS_Name], 
[hDED].[TFOMS_Okato] as [TFOMS_Okato], 
[hDED].[LPU_OGRN] as [LPU_OGRN], 
[hDED].[LPU_name] as [LPU_name], 
[hDED].[Doctor_Code] as [Doctor_Code], 
[hDED].[Doctor_Name] as [Doctor_Name], 
[hDED].[C_KAT] as [C_KAT], 
[hDED].[YM] as [YM], 
[hDED].[DS] as [DS], 
[hDED].[NOMKLS] as [NOMKLS], 
[hDED].[Y] as [Y], 
[hDED].[W] as [W], 
[hDED].[R] as [R], 
[hDED].[N] as [N], 
[hDED].[S] as [S], 
[hDED].[SP] as [SP], 
[hDED].[RD] as [RD], 
[hDED].[RDD] as [RDD], 
[hDED].[RV] as [RV]
FROM [oms_RIRFIRInfo] as [hDED]
INNER JOIN [oms_Reestr] as [jT_oms_Reestr] on [jT_oms_Reestr].[ReestrID] = [hDED].[rf_ReestrID]
go

