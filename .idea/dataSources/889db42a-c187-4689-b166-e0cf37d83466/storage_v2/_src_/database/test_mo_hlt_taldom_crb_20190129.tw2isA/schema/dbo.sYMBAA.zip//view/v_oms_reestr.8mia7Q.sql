CREATE VIEW [V_oms_Reestr] AS SELECT 
[hDED].[ReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_STFIID] as [rf_STFIID], 
[jT_oms_STF].[TF_NAME] as [SILENT_rf_STFIID], 
[hDED].[rf_SFOID] as [rf_SFOID], 
[jT_oms_SFO].[FO_OGRN] as [SILENT_rf_SFOID], 
[hDED].[rf_AccountID] as [rf_AccountID], 
[hDED].[rf_ReestrTypeID] as [rf_ReestrTypeID], 
[hDED].[rf_TenderID] as [rf_TenderID], 
[hDED].[Number] as [Number], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Rem] as [Rem], 
[hDED].[Recipe_Count] as [Recipe_Count], 
[hDED].[Sum] as [Sum], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[DateIn] as [DateIn], 
[hDED].[N_SCHET] as [N_SCHET], 
[hDED].[DATE_SCHET] as [DATE_SCHET], 
[hDED].[TYPE_SCHET] as [TYPE_SCHET], 
[hDED].[FileName] as [FileName], 
[hDED].[Year] as [Year], 
[hDED].[Month] as [Month], 
[hDED].[CFO] as [CFO]
FROM [oms_Reestr] as [hDED]
INNER JOIN [oms_STF] as [jT_oms_STF] on [jT_oms_STF].[STFID] = [hDED].[rf_STFIID]
INNER JOIN [oms_SFO] as [jT_oms_SFO] on [jT_oms_SFO].[SFOID] = [hDED].[rf_SFOID]
go

