CREATE VIEW [V_lbr_Option] AS SELECT 
[hDED].[OptionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[GUID] as [GUID], 
[hDED].[Name] as [Name], 
[hDED].[IsRequired] as [IsRequired], 
[hDED].[Min] as [Min], 
[hDED].[Max] as [Max], 
[hDED].[Unit] as [Unit]
FROM [lbr_Option] as [hDED]
go

