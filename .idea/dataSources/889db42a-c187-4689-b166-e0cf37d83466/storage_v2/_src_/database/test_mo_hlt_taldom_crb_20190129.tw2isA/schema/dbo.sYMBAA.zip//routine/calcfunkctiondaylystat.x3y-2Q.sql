
CREATE FUNCTION [dbo].[CalcFunkctionDaylyStat]
(	
	@beginHosp datetime, @endHosp datetime, @StartHospitalTime datetime
)
RETURNS int 
AS
BEGIN

declare @MCOD varchar(20);
Select @MCOD = isnull((Select rf_LPUID from  oms_tehatrvalue 
inner join oms_tehatr t2 on t2.tehatrID=oms_tehatrvalue.rf_tehatrID and t2.Code='0024'
inner join oms_LPU on LPUID=rf_LPUID
where tehatrvalueID in (
Select max(tehatrvalueID) from oms_tehatrvalue
where oms_tehatrvalue.date_E>getdate() 
group by rf_LPUID,rf_tehatrID
) and MCOD=(select top 1 ValueStr from x_UserSettings where [Property] = 'Код поликлиники' and rf_UserID = 1)),
(select top 1 ltrim(rtrim(LPUID)) from oms_LPU where 
    MCOD = ((select top 1 ValueStr from x_UserSettings where [Property] = 'Код поликлиники' and rf_UserID = 1))  
    and stLPU = '1')) 
/* ссылка на ЛПУ */	


set @beginHosp=convert(datetime,replace(convert(varchar(50),@beginHosp,121),CONVERT(VARCHAR(8),@beginHosp,108),'00:00:01'),121) /* начало дня */
declare @t int
declare @dt int

set @t = (select sum (convert(int , isnull(c2.iswork, c1.isWork)) )
	from oms_kl_Calendar c1
		left join oms_kl_Calendar  c2 on c1.Date = c2.Date and c2.rf_LPUID = @MCOD  /* дни ЛПУ */
	 where  c1.Date between @beginHosp and @endHosp)

 set @dt =  DateDiff(d, @beginHosp, @endHosp)  + 1 - @t 

	RETURN @dt

END

go

