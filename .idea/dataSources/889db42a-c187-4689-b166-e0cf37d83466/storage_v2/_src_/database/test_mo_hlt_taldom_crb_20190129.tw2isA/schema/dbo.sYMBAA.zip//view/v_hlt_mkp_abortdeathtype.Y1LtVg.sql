CREATE VIEW [V_hlt_mkp_AbortDeathType] AS SELECT 
[hDED].[mkp_AbortDeathTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Name] as [Name]
FROM [hlt_mkp_AbortDeathType] as [hDED]
go

