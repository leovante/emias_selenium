CREATE VIEW [V_oms_MilitaryDuty] AS SELECT 
[hDED].[MilitaryDutyID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_MilitaryDuty] as [hDED]
go

