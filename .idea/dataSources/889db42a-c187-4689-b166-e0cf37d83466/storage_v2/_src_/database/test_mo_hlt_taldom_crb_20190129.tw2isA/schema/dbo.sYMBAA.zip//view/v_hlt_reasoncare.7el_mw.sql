CREATE VIEW [V_hlt_ReasonCare] AS SELECT 
[hDED].[ReasonCareID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[COD] as [COD], 
[hDED].[NAME] as [NAME], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_ReasonCare] as [hDED]
go

