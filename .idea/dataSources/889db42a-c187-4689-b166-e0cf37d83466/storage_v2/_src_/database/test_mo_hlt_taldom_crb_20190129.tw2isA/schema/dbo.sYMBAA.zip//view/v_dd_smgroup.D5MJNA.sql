CREATE VIEW [V_dd_SMGroup] AS SELECT 
[hDED].[SMGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [dd_SMGroup] as [hDED]
go

