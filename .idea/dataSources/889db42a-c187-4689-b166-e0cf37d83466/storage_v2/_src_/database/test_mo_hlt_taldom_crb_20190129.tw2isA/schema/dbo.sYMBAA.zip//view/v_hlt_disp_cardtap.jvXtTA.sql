CREATE VIEW [V_hlt_disp_CardTap] AS SELECT 
[hDED].[disp_CardTapID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TAPGuid] as [rf_TAPGuid], 
[jT_hlt_TAP].[v_TAP] as [SILENT_rf_TAPGuid], 
[hDED].[rf_CardGuid] as [rf_CardGuid], 
[jT_hlt_disp_Card].[rf_MkabGuid] as [SILENT_rf_CardGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Summa] as [Summa], 
[hDED].[PercentTap] as [PercentTap]
FROM [hlt_disp_CardTap] as [hDED]
INNER JOIN [V_hlt_TAP] as [jT_hlt_TAP] on [jT_hlt_TAP].[UGUID] = [hDED].[rf_TAPGuid]
INNER JOIN [hlt_disp_Card] as [jT_hlt_disp_Card] on [jT_hlt_disp_Card].[Guid] = [hDED].[rf_CardGuid]
go

