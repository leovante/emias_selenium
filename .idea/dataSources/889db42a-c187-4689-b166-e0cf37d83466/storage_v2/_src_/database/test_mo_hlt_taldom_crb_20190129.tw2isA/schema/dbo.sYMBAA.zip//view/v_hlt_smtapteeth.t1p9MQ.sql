CREATE VIEW [V_hlt_SmTapTeeth] AS SELECT 
[hDED].[SmTapTeethID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMTAPID] as [rf_SMTAPID], 
[hDED].[rf_kl_TeethID] as [rf_kl_TeethID], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_SmTapTeeth] as [hDED]
go

