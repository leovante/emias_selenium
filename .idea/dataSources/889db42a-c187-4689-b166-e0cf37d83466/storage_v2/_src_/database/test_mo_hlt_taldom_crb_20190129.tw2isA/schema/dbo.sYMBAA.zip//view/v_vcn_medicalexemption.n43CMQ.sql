CREATE VIEW [V_vcn_MedicalExemption] AS SELECT 
[hDED].[MedicalExemptionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_InoculationCardID] as [rf_InoculationCardID], 
[hDED].[rf_MEReasonID] as [rf_MEReasonID], 
[hDED].[rf_VaccineTypeID] as [rf_VaccineTypeID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[regNum] as [regNum], 
[hDED].[MedicalExemptionGuid] as [MedicalExemptionGuid]
FROM [vcn_MedicalExemption] as [hDED]
go

