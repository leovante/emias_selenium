CREATE VIEW [V_oms_rx_DispensableDrug] AS SELECT 
[hDED].[rx_DispensableDrugID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TRNameID] as [rf_TRNameID], 
[jT_oms_TRName].[NAME_TRN] as [SILENT_rf_TRNameID], 
[hDED].[rf_rx_GenericDrugID] as [rf_rx_GenericDrugID], 
[jT_oms_rx_GenericDrug].[Name_GD] as [SILENT_rf_rx_GenericDrugID], 
[hDED].[Name_DD] as [Name_DD], 
[hDED].[Dosage] as [Dosage], 
[hDED].[GUID_DD] as [GUID_DD], 
[hDED].[Flags] as [Flags]
FROM [oms_rx_DispensableDrug] as [hDED]
INNER JOIN [oms_TRName] as [jT_oms_TRName] on [jT_oms_TRName].[TRNameID] = [hDED].[rf_TRNameID]
INNER JOIN [oms_rx_GenericDrug] as [jT_oms_rx_GenericDrug] on [jT_oms_rx_GenericDrug].[rx_GenericDrugID] = [hDED].[rf_rx_GenericDrugID]
go

