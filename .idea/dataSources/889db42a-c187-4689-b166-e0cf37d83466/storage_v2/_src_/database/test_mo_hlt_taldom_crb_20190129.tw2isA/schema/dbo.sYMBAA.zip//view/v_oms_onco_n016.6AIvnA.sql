CREATE VIEW [V_oms_onco_N016] AS SELECT 
[hDED].[onco_N016ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ID_TLek_V] as [ID_TLek_V], 
[hDED].[TLek_NAME_V] as [TLek_NAME_V], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN016] as [GUIDN016]
FROM [oms_onco_N016] as [hDED]
go

