CREATE VIEW [V_hlt_disp_Exam] AS SELECT 
[hDED].[disp_ExamID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TapGuid] as [rf_TapGuid], 
[hDED].[rf_DvtGuid] as [rf_DvtGuid], 
[jT_hlt_DoctorVisitTable].[Comment] as [SILENT_rf_DvtGuid], 
[hDED].[rf_DocPrvdGuid] as [rf_DocPrvdGuid], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPrvdGuid], 
[hDED].[rf_ServiceGuid] as [rf_ServiceGuid], 
[jT_hlt_disp_Service].[Name] as [SILENT_rf_ServiceGuid], 
[hDED].[rf_ServicePMGuid] as [rf_ServicePMGuid], 
[hDED].[rf_CardGuid] as [rf_CardGuid], 
[jT_hlt_disp_Card].[rf_MkabGuid] as [SILENT_rf_CardGuid], 
[hDED].[DateExam] as [DateExam], 
[hDED].[IsOtkaz] as [IsOtkaz], 
[hDED].[DateOtkaz] as [DateOtkaz], 
[hDED].[IsDeviation] as [IsDeviation], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[DopPriznak] as [DopPriznak], 
[hDED].[IsSigned] as [IsSigned], 
[hDED].[IsBefore] as [IsBefore]
FROM [hlt_disp_Exam] as [hDED]
INNER JOIN [hlt_DoctorVisitTable] as [jT_hlt_DoctorVisitTable] on [jT_hlt_DoctorVisitTable].[UGUID] = [hDED].[rf_DvtGuid]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[GUID] = [hDED].[rf_DocPrvdGuid]
INNER JOIN [hlt_disp_Service] as [jT_hlt_disp_Service] on [jT_hlt_disp_Service].[Guid] = [hDED].[rf_ServiceGuid]
INNER JOIN [hlt_disp_Card] as [jT_hlt_disp_Card] on [jT_hlt_disp_Card].[Guid] = [hDED].[rf_CardGuid]
go

