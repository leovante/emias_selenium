CREATE VIEW [V_oms_CHOICES_SMMU] AS SELECT 
[hDED].[CHOICES_SMMUID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Rem] as [Rem], 
[hDED].[Name] as [Name], 
[hDED].[Field] as [Field], 
[hDED].[Field1] as [Field1], 
[hDED].[Field2] as [Field2], 
[hDED].[Caption] as [Caption]
FROM [oms_CHOICES_SMMU] as [hDED]
go

