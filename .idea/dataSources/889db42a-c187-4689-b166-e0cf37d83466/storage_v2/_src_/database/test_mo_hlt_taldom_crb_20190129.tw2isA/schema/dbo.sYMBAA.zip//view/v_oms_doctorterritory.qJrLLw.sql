CREATE VIEW [V_oms_DoctorTerritory] AS SELECT 
[hDED].[DoctorTerritoryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_DOCTORID] as [rf_DOCTORID], 
[jT_oms_DOCTOR].[DOCTOR_FIO] as [SILENT_rf_DOCTORID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[rf_kl_TypeUID] as [rf_kl_TypeUID], 
[jT_oms_kl_TypeU].[Type_U] as [SILENT_rf_kl_TypeUID], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_DoctorTerritory] as [hDED]
INNER JOIN [V_oms_DOCTOR] as [jT_oms_DOCTOR] on [jT_oms_DOCTOR].[DOCTORID] = [hDED].[rf_DOCTORID]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
INNER JOIN [oms_kl_TypeU] as [jT_oms_kl_TypeU] on [jT_oms_kl_TypeU].[kl_TypeUID] = [hDED].[rf_kl_TypeUID]
go

