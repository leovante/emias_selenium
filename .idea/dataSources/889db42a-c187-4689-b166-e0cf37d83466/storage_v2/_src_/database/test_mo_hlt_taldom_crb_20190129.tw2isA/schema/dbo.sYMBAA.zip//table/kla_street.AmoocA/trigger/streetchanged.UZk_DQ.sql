CREATE TRIGGER [dbo].[StreetChanged] ON [dbo].[kla_Street] 
	FOR INSERT, UPDATE 
AS 
BEGIN   
   update kla_Street
		set rf_KlAdrID=t.KlAdrID
   from (select a.KlAdrID,s.StreetID from inserted s
		 inner join  kla_KlAdr a on  SUBSTRING(a.CODE,1,11)= SUBSTRING(s.CODE,1,11) and a.FLAGS = s.FLAGS)t
   where kla_Street.StreetID=t.StreetID              
END
go

