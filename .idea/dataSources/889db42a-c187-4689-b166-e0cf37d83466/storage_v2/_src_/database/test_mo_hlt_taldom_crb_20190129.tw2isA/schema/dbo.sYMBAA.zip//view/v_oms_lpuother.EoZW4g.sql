CREATE VIEW [V_oms_LPUOther] AS SELECT 
[hDED].[LPUOtherID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[jT_oms_OKATO].[C_OKATO] as [SILENT_rf_OKATOID], 
[hDED].[ShortName] as [ShortName], 
[hDED].[FullName] as [FullName], 
[hDED].[MCode] as [MCode], 
[hDED].[OGRN] as [OGRN], 
[hDED].[Adress] as [Adress], 
[hDED].[Fio_GV] as [Fio_GV], 
[hDED].[Phone] as [Phone], 
[hDED].[Email] as [Email], 
[hDED].[INN] as [INN], 
[hDED].[KPP] as [KPP], 
[hDED].[Code_MO] as [Code_MO], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[OID] as [OID], 
[hDED].[GuidLPUOther] as [GuidLPUOther]
FROM [oms_LPUOther] as [hDED]
INNER JOIN [oms_OKATO] as [jT_oms_OKATO] on [jT_oms_OKATO].[OKATOID] = [hDED].[rf_OKATOID]
go

