CREATE VIEW [V_hlt_FluorControlResearch] AS SELECT 
[hDED].[FluorControlResearchID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [hlt_FluorControlResearch] as [hDED]
go

