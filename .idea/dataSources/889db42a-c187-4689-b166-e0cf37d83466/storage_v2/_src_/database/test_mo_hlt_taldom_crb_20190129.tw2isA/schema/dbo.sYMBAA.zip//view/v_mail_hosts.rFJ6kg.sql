CREATE VIEW [V_mail_Hosts] AS SELECT 
[hDED].[HostsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[HostName] as [HostName], 
[hDED].[HostDescription] as [HostDescription]
FROM [mail_Hosts] as [hDED]
go

