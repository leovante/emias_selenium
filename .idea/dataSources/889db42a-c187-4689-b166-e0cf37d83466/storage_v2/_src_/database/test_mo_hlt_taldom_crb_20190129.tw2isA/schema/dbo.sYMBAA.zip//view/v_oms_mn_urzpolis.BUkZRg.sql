CREATE VIEW [V_oms_mn_UrzPolis] AS SELECT 
[hDED].[mn_UrzPolisID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_mn_PersonID] as [rf_mn_PersonID], 
[jT_oms_mn_Person].[V_FIO] as [SILENT_rf_mn_PersonID], 
[hDED].[rf_mn_PolisID] as [rf_mn_PolisID], 
[jT_oms_mn_Polis].[rf_SMOID] as [SILENT_rf_mn_PolisID], 
[hDED].[rf_mn_UrzPeriodID] as [rf_mn_UrzPeriodID]
FROM [oms_mn_UrzPolis] as [hDED]
INNER JOIN [V_oms_mn_Person] as [jT_oms_mn_Person] on [jT_oms_mn_Person].[mn_PersonID] = [hDED].[rf_mn_PersonID]
INNER JOIN [oms_mn_Polis] as [jT_oms_mn_Polis] on [jT_oms_mn_Polis].[mn_PolisID] = [hDED].[rf_mn_PolisID]
go

