CREATE VIEW [V_oms_KATL] AS SELECT 
[hDED].[KATLID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[jT_oms_Finl].[NAME] as [SILENT_rf_FinlID], 
[hDED].[rf_PR_LRID] as [rf_PR_LRID], 
[jT_oms_PR_LR].[PR_LR_VALUE] as [SILENT_rf_PR_LRID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID], 
[hDED].[rf_TenderKindID] as [rf_TenderKindID], 
[jT_oms_TenderKind].[TKind_Name] as [SILENT_rf_TenderKindID], 
[hDED].[C_KATL] as [C_KATL], 
[hDED].[NAME] as [NAME], 
[hDED].[C_KAT] as [C_KAT], 
[hDED].[MSG_TEXT] as [MSG_TEXT]
FROM [oms_KATL] as [hDED]
INNER JOIN [oms_Finl] as [jT_oms_Finl] on [jT_oms_Finl].[FinlID] = [hDED].[rf_FinlID]
INNER JOIN [oms_PR_LR] as [jT_oms_PR_LR] on [jT_oms_PR_LR].[PR_LRID] = [hDED].[rf_PR_LRID]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
INNER JOIN [oms_TenderKind] as [jT_oms_TenderKind] on [jT_oms_TenderKind].[TenderKindID] = [hDED].[rf_TenderKindID]
go

