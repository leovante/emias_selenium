CREATE VIEW [V_dent_ChartRoot] AS SELECT 
[hDED].[ChartRootID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_dent_RootCanalID] as [rf_dent_RootCanalID], 
[jT_oms_dent_RootCanal].[Name] as [SILENT_rf_dent_RootCanalID], 
[hDED].[rf_dent_RootConditionID] as [rf_dent_RootConditionID], 
[jT_oms_dent_RootCondition].[Name] as [SILENT_rf_dent_RootConditionID], 
[hDED].[rf_ChartToothID] as [rf_ChartToothID], 
[jT_dent_ChartTooth].[Date] as [SILENT_rf_ChartToothID], 
[hDED].[Date] as [Date], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Note] as [Note]
FROM [dent_ChartRoot] as [hDED]
INNER JOIN [oms_dent_RootCanal] as [jT_oms_dent_RootCanal] on [jT_oms_dent_RootCanal].[dent_RootCanalID] = [hDED].[rf_dent_RootCanalID]
INNER JOIN [oms_dent_RootCondition] as [jT_oms_dent_RootCondition] on [jT_oms_dent_RootCondition].[dent_RootConditionID] = [hDED].[rf_dent_RootConditionID]
INNER JOIN [dent_ChartTooth] as [jT_dent_ChartTooth] on [jT_dent_ChartTooth].[ChartToothID] = [hDED].[rf_ChartToothID]
go

