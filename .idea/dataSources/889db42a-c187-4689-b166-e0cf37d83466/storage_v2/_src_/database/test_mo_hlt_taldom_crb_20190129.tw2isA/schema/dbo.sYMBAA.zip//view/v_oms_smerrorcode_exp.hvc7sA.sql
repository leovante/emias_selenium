CREATE VIEW [V_oms_SMErrorCODE_EXP] AS SELECT 
[hDED].[SMErrorCODE_EXPID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMErrorID] as [rf_SMErrorID], 
[hDED].[rf_SMReestrZ_SLID] as [rf_SMReestrZ_SLID], 
[hDED].[CODE_EXP] as [CODE_EXP], 
[hDED].[SANK_ID] as [SANK_ID]
FROM [oms_SMErrorCODE_EXP] as [hDED]
go

