CREATE VIEW [V_App_OLS_POSID] AS SELECT 
[hDED].[OLS_POSIDID], [hDED].[x_Edition], [hDED].[x_Status], 
(SELECT top 1 ISNULL(PR_REG, 0.00) AS Expr1 FROM dbo.oms_CLS AS jT18 WHERE (rf_LSID = hDED.rf_LSID) order by date_bp desc) as [V_Price], 
[jT_oms_LS].[NOMK_LS] as [NOMK_LS], 
[jT_oms_LS].[NAME_MED] as [NAME_MED], 
[hDED].[rf_LSID] as [rf_LSID], 
[jT_oms_LS].[NAME_MED] as [SILENT_rf_LSID], 
[hDED].[rf_FINLID] as [rf_FINLID], 
[hDED].[rf_OrderLSID] as [rf_OrderLSID], 
[jT_App_OrderLS].[Description] as [SILENT_rf_OrderLSID], 
[hDED].[SS] as [SS], 
[hDED].[OrdCnt] as [OrdCnt], 
[hDED].[ConfCnt] as [ConfCnt], 
[hDED].[AccCnt] as [AccCnt], 
[hDED].[BK] as [BK], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [App_OLS_POSID] as [hDED]
INNER JOIN [oms_LS] as [jT_oms_LS] on [jT_oms_LS].[LSID] = [hDED].[rf_LSID]
INNER JOIN [App_OrderLS] as [jT_App_OrderLS] on [jT_App_OrderLS].[OrderLSID] = [hDED].[rf_OrderLSID]
go

