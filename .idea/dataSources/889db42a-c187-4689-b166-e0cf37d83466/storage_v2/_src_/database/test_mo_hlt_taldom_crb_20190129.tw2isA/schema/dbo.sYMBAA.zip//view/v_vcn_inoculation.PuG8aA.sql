CREATE VIEW [V_vcn_Inoculation] AS SELECT 
[hDED].[InoculationID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_DocPRVD].[V_FIO] as [V_ExecuteDocPRVD], 
[jT_hlt_DocPRVD1].[V_FIO] as [V_PurposeDocPRVD], 
[jT_hlt_DocPRVD2].[V_FIO] as [V_ResultDocPRVD], 
[hDED].[rf_ExecuteDLSID] as [rf_ExecuteDLSID], 
[jT_oms_DLS].[C_DLS] as [SILENT_rf_ExecuteDLSID], 
[hDED].[rf_PurposeDLSID] as [rf_PurposeDLSID], 
[hDED].[rf_ExecuteLPUID] as [rf_ExecuteLPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_ExecuteLPUID], 
[hDED].[rf_PurposeLPUID] as [rf_PurposeLPUID], 
[jT_oms_LPU1].[M_NAMES] as [SILENT_rf_PurposeLPUID], 
[hDED].[rf_ResultLPUID] as [rf_ResultLPUID], 
[jT_oms_LPU2].[M_NAMES] as [SILENT_rf_ResultLPUID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[jT_hlt_TAP].[v_TAP] as [SILENT_rf_TAPID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_ExecuteDocPRVDID] as [rf_ExecuteDocPRVDID], 
[hDED].[rf_PurposeDocPRVDID] as [rf_PurposeDocPRVDID], 
[hDED].[rf_ResultDocPRVDID] as [rf_ResultDocPRVDID], 
[hDED].[rf_ExecuteVaccineID] as [rf_ExecuteVaccineID], 
[jT_vcn_Vaccine].[Name] as [SILENT_rf_ExecuteVaccineID], 
[hDED].[rf_PurposeVaccineID] as [rf_PurposeVaccineID], 
[jT_vcn_Vaccine1].[Name] as [SILENT_rf_PurposeVaccineID], 
[hDED].[rf_InoculationCardID] as [rf_InoculationCardID], 
[hDED].[rf_VaccinationTypeID] as [rf_VaccinationTypeID], 
[jT_vcn_VaccinationType].[ShortName] as [SILENT_rf_VaccinationTypeID], 
[hDED].[rf_LocalReactionID] as [rf_LocalReactionID], 
[jT_vcn_LocalReaction].[Name] as [SILENT_rf_LocalReactionID], 
[hDED].[rf_GlobalReactionID] as [rf_GlobalReactionID], 
[jT_vcn_GlobalReaction].[Name] as [SILENT_rf_GlobalReactionID], 
[hDED].[rf_MedicalExemptionID] as [rf_MedicalExemptionID], 
[jT_vcn_MedicalExemption].[regNum] as [SILENT_rf_MedicalExemptionID], 
[hDED].[rf_MEReasonID] as [rf_MEReasonID], 
[jT_vcn_MEReason].[Code] as [SILENT_rf_MEReasonID], 
[hDED].[rf_StatusID] as [rf_StatusID], 
[jT_vcn_Status].[Name] as [SILENT_rf_StatusID], 
[hDED].[rf_ExecuteInjectionTypeID] as [rf_ExecuteInjectionTypeID], 
[jT_vcn_InjectionType].[Name] as [SILENT_rf_ExecuteInjectionTypeID], 
[hDED].[rf_PurposeInjectionTypeID] as [rf_PurposeInjectionTypeID], 
[jT_vcn_InjectionType1].[Name] as [SILENT_rf_PurposeInjectionTypeID], 
[hDED].[rf_ReasonID] as [rf_ReasonID], 
[jT_vcn_Reason].[Name] as [SILENT_rf_ReasonID], 
[hDED].[rf_VaccinationGroupID] as [rf_VaccinationGroupID], 
[jT_vcn_VaccinationGroup].[Name] as [SILENT_rf_VaccinationGroupID], 
[hDED].[rf_ResultID] as [rf_ResultID], 
[jT_vcn_Result].[Name] as [SILENT_rf_ResultID], 
[hDED].[rf_VaccineSeriesID] as [rf_VaccineSeriesID], 
[jT_vcn_VaccineSeries].[Series] as [SILENT_rf_VaccineSeriesID], 
[hDED].[DateExecute] as [DateExecute], 
[hDED].[ExecuteDose] as [ExecuteDose], 
[hDED].[Series] as [Series], 
[hDED].[LocalReaction] as [LocalReaction], 
[hDED].[GlobalReaction] as [GlobalReaction], 
[hDED].[Result] as [Result], 
[hDED].[AgeSelector] as [AgeSelector], 
[hDED].[Age] as [Age], 
[hDED].[VaccinationNumber] as [VaccinationNumber], 
[hDED].[InoculationResult] as [InoculationResult], 
[hDED].[PapSize] as [PapSize], 
[hDED].[DatePurpose] as [DatePurpose], 
[hDED].[DateResult] as [DateResult], 
[hDED].[isPurposed] as [isPurposed], 
[hDED].[isExecuted] as [isExecuted], 
[hDED].[isResult] as [isResult], 
[hDED].[isPurposeSigned] as [isPurposeSigned], 
[hDED].[isExecuteSigned] as [isExecuteSigned], 
[hDED].[isResultSigned] as [isResultSigned], 
[hDED].[ControlNumber] as [ControlNumber], 
[hDED].[PurposeDose] as [PurposeDose], 
[hDED].[Info] as [Info], 
[hDED].[LPUPurpose] as [LPUPurpose], 
[hDED].[LPUExecute] as [LPUExecute], 
[hDED].[LPUResult] as [LPUResult], 
[hDED].[rf_CancelUserID] as [rf_CancelUserID], 
[hDED].[CancelUserName] as [CancelUserName], 
[hDED].[CancelDate] as [CancelDate], 
[hDED].[Hyperaemia] as [Hyperaemia], 
[hDED].[InoculationGuid] as [InoculationGuid], 
[hDED].[DateME] as [DateME], 
[hDED].[DateExecuteSign] as [DateExecuteSign], 
[hDED].[DateResultSign] as [DateResultSign], 
[hDED].[ResultInfo] as [ResultInfo], 
[hDED].[Scar] as [Scar]
FROM [vcn_Inoculation] as [hDED]
INNER JOIN [V_hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_ExecuteDocPRVDID]
INNER JOIN [V_hlt_DocPRVD] as [jT_hlt_DocPRVD1] on [jT_hlt_DocPRVD1].[DocPRVDID] = [hDED].[rf_PurposeDocPRVDID]
INNER JOIN [V_hlt_DocPRVD] as [jT_hlt_DocPRVD2] on [jT_hlt_DocPRVD2].[DocPRVDID] = [hDED].[rf_ResultDocPRVDID]
INNER JOIN [oms_DLS] as [jT_oms_DLS] on [jT_oms_DLS].[DLSID] = [hDED].[rf_ExecuteDLSID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_ExecuteLPUID]
INNER JOIN [oms_LPU] as [jT_oms_LPU1] on [jT_oms_LPU1].[LPUID] = [hDED].[rf_PurposeLPUID]
INNER JOIN [oms_LPU] as [jT_oms_LPU2] on [jT_oms_LPU2].[LPUID] = [hDED].[rf_ResultLPUID]
INNER JOIN [V_hlt_TAP] as [jT_hlt_TAP] on [jT_hlt_TAP].[TAPID] = [hDED].[rf_TAPID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [vcn_Vaccine] as [jT_vcn_Vaccine] on [jT_vcn_Vaccine].[VaccineID] = [hDED].[rf_ExecuteVaccineID]
INNER JOIN [vcn_Vaccine] as [jT_vcn_Vaccine1] on [jT_vcn_Vaccine1].[VaccineID] = [hDED].[rf_PurposeVaccineID]
INNER JOIN [vcn_VaccinationType] as [jT_vcn_VaccinationType] on [jT_vcn_VaccinationType].[VaccinationTypeID] = [hDED].[rf_VaccinationTypeID]
INNER JOIN [vcn_LocalReaction] as [jT_vcn_LocalReaction] on [jT_vcn_LocalReaction].[LocalReactionID] = [hDED].[rf_LocalReactionID]
INNER JOIN [vcn_GlobalReaction] as [jT_vcn_GlobalReaction] on [jT_vcn_GlobalReaction].[GlobalReactionID] = [hDED].[rf_GlobalReactionID]
INNER JOIN [vcn_MedicalExemption] as [jT_vcn_MedicalExemption] on [jT_vcn_MedicalExemption].[MedicalExemptionID] = [hDED].[rf_MedicalExemptionID]
INNER JOIN [vcn_MEReason] as [jT_vcn_MEReason] on [jT_vcn_MEReason].[MEReasonID] = [hDED].[rf_MEReasonID]
INNER JOIN [vcn_Status] as [jT_vcn_Status] on [jT_vcn_Status].[StatusID] = [hDED].[rf_StatusID]
INNER JOIN [vcn_InjectionType] as [jT_vcn_InjectionType] on [jT_vcn_InjectionType].[InjectionTypeID] = [hDED].[rf_ExecuteInjectionTypeID]
INNER JOIN [vcn_InjectionType] as [jT_vcn_InjectionType1] on [jT_vcn_InjectionType1].[InjectionTypeID] = [hDED].[rf_PurposeInjectionTypeID]
INNER JOIN [vcn_Reason] as [jT_vcn_Reason] on [jT_vcn_Reason].[ReasonID] = [hDED].[rf_ReasonID]
INNER JOIN [vcn_VaccinationGroup] as [jT_vcn_VaccinationGroup] on [jT_vcn_VaccinationGroup].[VaccinationGroupID] = [hDED].[rf_VaccinationGroupID]
INNER JOIN [vcn_Result] as [jT_vcn_Result] on [jT_vcn_Result].[ResultID] = [hDED].[rf_ResultID]
INNER JOIN [vcn_VaccineSeries] as [jT_vcn_VaccineSeries] on [jT_vcn_VaccineSeries].[VaccineSeriesID] = [hDED].[rf_VaccineSeriesID]
go

