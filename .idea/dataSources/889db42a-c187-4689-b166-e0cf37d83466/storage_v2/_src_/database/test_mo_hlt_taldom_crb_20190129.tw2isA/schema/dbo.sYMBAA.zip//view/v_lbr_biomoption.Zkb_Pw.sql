CREATE VIEW [V_lbr_BioMOption] AS SELECT 
[hDED].[BioMOptionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResearchTypeID] as [rf_ResearchTypeID], 
[hDED].[rf_BioMID] as [rf_BioMID], 
[hDED].[rf_OptionID] as [rf_OptionID]
FROM [lbr_BioMOption] as [hDED]
go

