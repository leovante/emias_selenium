CREATE VIEW [V_hlt_DocTypeRoute] AS SELECT 
[hDED].[DocTypeRouteID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Route] as [Route], 
[hDED].[DocTypeGuid] as [DocTypeGuid], 
[hDED].[ModelName] as [ModelName]
FROM [hlt_DocTypeRoute] as [hDED]
go

