CREATE VIEW [V_oms_kl_DiagnosType] AS SELECT 
[hDED].[kl_DiagnosTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[GUIDDiagnosType] as [GUIDDiagnosType]
FROM [oms_kl_DiagnosType] as [hDED]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
go

