CREATE VIEW [V_oms_LF] AS SELECT 
[hDED].[LFID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_LF] as [C_LF], 
[hDED].[NAME_LF] as [NAME_LF], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[NAME_LF_SL] as [NAME_LF_SL], 
[hDED].[GUIDLF] as [GUIDLF], 
[hDED].[CodeEgisz] as [CodeEgisz]
FROM [oms_LF] as [hDED]
go

