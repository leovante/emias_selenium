CREATE TRIGGER [LifeTrigger_hlt_mkp_Card] ON [hlt_mkp_Card] FOR DELETE,INSERT,UPDATE
AS 

SET NOCOUNT ON;

DECLARE @userId INT
DECLARE @seanceId INT 

DECLARE @docTypeId INT 
DECLARE @CURDATE DATETIME


declare @app varchar(50)
declare @index1 int
declare @index2 int


/* @userId, @seanceId */

SET @userId = 0
SET @seanceId = 0

EXEC [GetMalibuContext] @seanceId = @seanceId OUTPUT, @userId = @userId OUTPUT

/* @docTypeId */

SET @CURDATE = getdate()

SET @docTypeId = 0

SELECT TOP 1 @docTypeId = [DocTypeDefID], @seanceId=case WHEN [x_STDO].[HostID] IS NULL THEN @seanceId ELSE 0 END
FROM [x_DocTypeDef] left join [x_STDO] on [x_DocTypeDef].[GUID] = [x_STDO].[DocTypeDef] 
WHERE [HeadTable] = 'hlt_mkp_Card'

/* action type */

DECLARE @DEL BIT
DECLARE @INS BIT 

DECLARE @action CHAR(1)


SET @DEL = 0
SET @INS = 0


IF EXISTS (SELECT TOP 1 1 FROM DELETED) SET @DEL=1
IF EXISTS (SELECT TOP 1 1 FROM INSERTED) SET @INS = 1 

IF @INS = 1 AND @DEL = 1 SET @ACTION = 'u'
IF @INS = 1 AND @DEL = 0 SET @ACTION = 'i'
IF @INS = 0 AND @DEL = 1 SET @ACTION = 'd'


IF @ACTION = 'd'
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [mkp_CardID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM deleted;

	INSERT INTO Life_hlt_mkp_Card([mkp_CardID],[CreateUserName],[DateBirth],[DateClose],[DateExtract],[DateFirst],[DateFirstInspection],[DateHospital],[DateMenstr],[DateOpen],[DateOvul],[DateStir],[EditUserName],[F_DR],[F_FAM],[F_NAME],[F_OT],[F_Post],[F_Profession],[F_Work],[FirstGestationalAge],[Flags],[GestBirth],[HospitalLPU],[Intolerance],[IsAllergy],[IsClosed],[Maiden_FAM],[Allergy],[National],[NationalF],[NUM],[NumBirth],[NumMar],[NumPreg],[PregCondDisch],[rf_birthOutcomesID],[rf_BornLPUID],[rf_CreateUserGUID],[rf_DepartamentGUID],[rf_DocPRVDID],[rf_EditUserGUID],[rf_EmergLPUID],[rf_F_GroupOfBloodRHID],[rf_F_NationalGUID],[rf_GroupOfBloodRHID],[rf_HospitalLPUID],[rf_LPUDoctorGUID],[rf_LPUID],[rf_MKABGUID],[rf_mkp_CloseReasonID],[rf_mkp_DeathMother],[rf_mkp_OutcomeGUID],[rf_mkpAbortUguid],[rf_NationalGUID],[rf_PergGUID],[rf_PlanLPUID],[RiskFrolova],[RiskRadzinskogo],[RiskSavelyeva],[RiskVittlengera],[Sert_Date],[Sert_N],[Sert_S],[Sert_Term],[StatusRisk],[Treatment],[UGUID],[x_Edition],[x_Status],[XmlData],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [mkp_CardID],[CreateUserName],[DateBirth],[DateClose],[DateExtract],[DateFirst],[DateFirstInspection],[DateHospital],[DateMenstr],[DateOpen],[DateOvul],[DateStir],[EditUserName],[F_DR],[F_FAM],[F_NAME],[F_OT],[F_Post],[F_Profession],[F_Work],[FirstGestationalAge],[Flags],[GestBirth],[HospitalLPU],[Intolerance],[IsAllergy],[IsClosed],[Maiden_FAM],[Allergy],[National],[NationalF],[NUM],[NumBirth],[NumMar],[NumPreg],[PregCondDisch],[rf_birthOutcomesID],[rf_BornLPUID],[rf_CreateUserGUID],[rf_DepartamentGUID],[rf_DocPRVDID],[rf_EditUserGUID],[rf_EmergLPUID],[rf_F_GroupOfBloodRHID],[rf_F_NationalGUID],[rf_GroupOfBloodRHID],[rf_HospitalLPUID],[rf_LPUDoctorGUID],[rf_LPUID],[rf_MKABGUID],[rf_mkp_CloseReasonID],[rf_mkp_DeathMother],[rf_mkp_OutcomeGUID],[rf_mkpAbortUguid],[rf_NationalGUID],[rf_PergGUID],[rf_PlanLPUID],[RiskFrolova],[RiskRadzinskogo],[RiskSavelyeva],[RiskVittlengera],[Sert_Date],[Sert_N],[Sert_S],[Sert_Term],[StatusRisk],[Treatment],[UGUID],[x_Edition],[x_Status],[XmlData],@action,@CURDATE,@userId,@seanceId FROM deleted;
END;
ELSE
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [mkp_CardID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM inserted;

	INSERT INTO Life_hlt_mkp_Card([mkp_CardID],[CreateUserName],[DateBirth],[DateClose],[DateExtract],[DateFirst],[DateFirstInspection],[DateHospital],[DateMenstr],[DateOpen],[DateOvul],[DateStir],[EditUserName],[F_DR],[F_FAM],[F_NAME],[F_OT],[F_Post],[F_Profession],[F_Work],[FirstGestationalAge],[Flags],[GestBirth],[HospitalLPU],[Intolerance],[IsAllergy],[IsClosed],[Maiden_FAM],[Allergy],[National],[NationalF],[NUM],[NumBirth],[NumMar],[NumPreg],[PregCondDisch],[rf_birthOutcomesID],[rf_BornLPUID],[rf_CreateUserGUID],[rf_DepartamentGUID],[rf_DocPRVDID],[rf_EditUserGUID],[rf_EmergLPUID],[rf_F_GroupOfBloodRHID],[rf_F_NationalGUID],[rf_GroupOfBloodRHID],[rf_HospitalLPUID],[rf_LPUDoctorGUID],[rf_LPUID],[rf_MKABGUID],[rf_mkp_CloseReasonID],[rf_mkp_DeathMother],[rf_mkp_OutcomeGUID],[rf_mkpAbortUguid],[rf_NationalGUID],[rf_PergGUID],[rf_PlanLPUID],[RiskFrolova],[RiskRadzinskogo],[RiskSavelyeva],[RiskVittlengera],[Sert_Date],[Sert_N],[Sert_S],[Sert_Term],[StatusRisk],[Treatment],[UGUID],[x_Edition],[x_Status],[XmlData],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [mkp_CardID],[CreateUserName],[DateBirth],[DateClose],[DateExtract],[DateFirst],[DateFirstInspection],[DateHospital],[DateMenstr],[DateOpen],[DateOvul],[DateStir],[EditUserName],[F_DR],[F_FAM],[F_NAME],[F_OT],[F_Post],[F_Profession],[F_Work],[FirstGestationalAge],[Flags],[GestBirth],[HospitalLPU],[Intolerance],[IsAllergy],[IsClosed],[Maiden_FAM],[Allergy],[National],[NationalF],[NUM],[NumBirth],[NumMar],[NumPreg],[PregCondDisch],[rf_birthOutcomesID],[rf_BornLPUID],[rf_CreateUserGUID],[rf_DepartamentGUID],[rf_DocPRVDID],[rf_EditUserGUID],[rf_EmergLPUID],[rf_F_GroupOfBloodRHID],[rf_F_NationalGUID],[rf_GroupOfBloodRHID],[rf_HospitalLPUID],[rf_LPUDoctorGUID],[rf_LPUID],[rf_MKABGUID],[rf_mkp_CloseReasonID],[rf_mkp_DeathMother],[rf_mkp_OutcomeGUID],[rf_mkpAbortUguid],[rf_NationalGUID],[rf_PergGUID],[rf_PlanLPUID],[RiskFrolova],[RiskRadzinskogo],[RiskSavelyeva],[RiskVittlengera],[Sert_Date],[Sert_N],[Sert_S],[Sert_Term],[StatusRisk],[Treatment],[UGUID],[x_Edition],[x_Status],[XmlData],@action,@CURDATE,@userId,@seanceId FROM inserted;
END; 

SET NOCOUNT OFF;


go

