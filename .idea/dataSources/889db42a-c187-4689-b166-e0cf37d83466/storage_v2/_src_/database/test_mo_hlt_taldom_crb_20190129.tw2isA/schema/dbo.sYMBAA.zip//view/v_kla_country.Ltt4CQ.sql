CREATE VIEW [V_kla_Country] AS SELECT 
[hDED].[CountryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ALFA2] as [ALFA2], 
[hDED].[ALFA3] as [ALFA3], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Rem] as [Rem], 
[hDED].[Code] as [Code], 
[hDED].[NameFull] as [NameFull], 
[hDED].[Name] as [Name]
FROM [kla_Country] as [hDED]
go

