CREATE VIEW [V_oms_onco_N007] AS SELECT 
[hDED].[onco_N007ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[ID_Mrf] as [ID_Mrf], 
[hDED].[Mrf_NAME] as [Mrf_NAME], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN007] as [GUIDN007]
FROM [oms_onco_N007] as [hDED]
go

