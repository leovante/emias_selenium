CREATE VIEW [V_rls_IicSynonyms] AS SELECT 
[hDED].[IicSynonymsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[Name] as [Name], 
[hDED].[UID] as [UID], 
[hDED].[Code] as [Code]
FROM [rls_IicSynonyms] as [hDED]
go

