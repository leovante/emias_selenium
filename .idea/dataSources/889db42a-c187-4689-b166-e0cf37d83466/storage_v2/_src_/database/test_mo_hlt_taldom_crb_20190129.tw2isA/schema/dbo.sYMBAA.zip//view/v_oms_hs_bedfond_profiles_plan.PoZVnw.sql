CREATE VIEW [V_oms_hs_bedfond_profiles_plan] AS SELECT 
[hDED].[hs_bedfond_profiles_planID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_BedProfileID] as [rf_BedProfileID], 
[hDED].[plane_by_profile] as [plane_by_profile]
FROM [oms_hs_bedfond_profiles_plan] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

