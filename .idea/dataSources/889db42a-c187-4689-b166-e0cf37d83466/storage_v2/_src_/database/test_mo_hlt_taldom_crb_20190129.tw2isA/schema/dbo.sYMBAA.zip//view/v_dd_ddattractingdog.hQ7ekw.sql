CREATE VIEW [V_dd_DDAttractingDog] AS SELECT 
[hDED].[DDAttractingDogID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUMainID] as [rf_LPUMainID], 
[hDED].[rf_LPUOherID] as [rf_LPUOherID], 
[hDED].[rf_STFGUID] as [rf_STFGUID], 
[jT_dd_STF].[TF_NAME] as [SILENT_rf_STFGUID], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[jT_dd_DDType].[Name] as [SILENT_rf_DDTypeGUID], 
[hDED].[NUMBER] as [NUMBER], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEDOGOVOR] as [DATEDOGOVOR], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[DATELPUDOGOVOR] as [DATELPUDOGOVOR], 
[hDED].[DATEIN] as [DATEIN]
FROM [dd_DDAttractingDog] as [hDED]
INNER JOIN [dd_STF] as [jT_dd_STF] on [jT_dd_STF].[UGUID] = [hDED].[rf_STFGUID]
INNER JOIN [dd_DDType] as [jT_dd_DDType] on [jT_dd_DDType].[UGUID] = [hDED].[rf_DDTypeGUID]
go

