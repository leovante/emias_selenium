CREATE VIEW [V_smp_JournalCall] AS SELECT 
[hDED].[JournalCallID], [hDED].[x_Edition], [hDED].[x_Status], 
(((convert(varchar, [hDED].DateBirth, 104))  )
) as [V_DateBirth], 
((((convert(varchar, [hDED].DateCall, 104))  )
)) as [V_DateCall], 
(((([hDED].Surname + ' ' + [hDED].Name + ' ' + [hDED].Patronymic))  )
) as [V_FIO], 
((((convert(varchar, [hDED].TimeCall, 108))  )
)) as [V_TimeCall], 
(((convert(varchar, [hDED].TimeDeparture, 108))  )
) as [V_TimeDeparture], 
(((convert(varchar, [hDED].TimeEnd, 108))  )
) as [V_TimeEnd], 
(((convert(varchar, [hDED].TimeGoPlace, 108))  )
) as [V_TimeGoPlace], 
((((convert(varchar, [hDED].TimeReturnDep, 108)))  )
) as [V_TimeReturnDep], 
((((((convert(varchar, [hDED].TimeReturnMO, 108)))  )))
) as [V_TimeReturnMO], 
((((convert(varchar, [hDED].TimeTransferBegin, 108)))  )
) as [V_TimeTransferBegin], 
((((convert(varchar, [hDED].TimeTransferBrigade, 108))  )
)) as [V_TimeTransferBrigade], 
((( [dbo].[FullYearAge]([hDED].DateBirth,[hDED].DateCall) ))) as [V_Age], 
[jT_smp_Brigade].[Number] as [V_BrigadeNumber], 
[jT_smp_OccasionCall].[Name] as [V_OccasionCallName], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_MKB2ID] as [rf_MKB2ID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_PatientID] as [rf_PatientID], 
[hDED].[rf_AddressID] as [rf_AddressID], 
[hDED].[rf_kl_VisitResultID] as [rf_kl_VisitResultID], 
[hDED].[rf_kl_StatCureResultID] as [rf_kl_StatCureResultID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[hDED].[rf_OccasionCallID] as [rf_OccasionCallID], 
[hDED].[rf_BrigadeID] as [rf_BrigadeID], 
[hDED].[rf_DoctorID] as [rf_DoctorID], 
[hDED].[rf_DoctorMedicalID] as [rf_DoctorMedicalID], 
[hDED].[Address] as [Address], 
[hDED].[DateBirth] as [DateBirth], 
[hDED].[DateCall] as [DateCall], 
[hDED].[DateHealthBegin] as [DateHealthBegin], 
[hDED].[DateHealthEnd] as [DateHealthEnd], 
[hDED].[MedicalProcedures] as [MedicalProcedures], 
[hDED].[Name] as [Name], 
[hDED].[Number] as [Number], 
[hDED].[Patronymic] as [Patronymic], 
[hDED].[Surname] as [Surname], 
[hDED].[SurnameCall] as [SurnameCall], 
[hDED].[TelephoneCall] as [TelephoneCall], 
[hDED].[TimeCall] as [TimeCall], 
[hDED].[TimeDeparture] as [TimeDeparture], 
[hDED].[TimeEnd] as [TimeEnd], 
[hDED].[TimeGoPlace] as [TimeGoPlace], 
[hDED].[TimeReturnDep] as [TimeReturnDep], 
[hDED].[TimeReturnMO] as [TimeReturnMO], 
[hDED].[TimeTransferBegin] as [TimeTransferBegin], 
[hDED].[TimeTransferBrigade] as [TimeTransferBrigade], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [smp_JournalCall] as [hDED]
INNER JOIN [smp_Brigade] as [jT_smp_Brigade] on [jT_smp_Brigade].[BrigadeID] = [hDED].[rf_BrigadeID]
INNER JOIN [smp_OccasionCall] as [jT_smp_OccasionCall] on [jT_smp_OccasionCall].[OccasionCallID] = [hDED].[rf_OccasionCallID]
go

