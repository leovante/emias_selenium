CREATE VIEW [V_oms_dent_ConditionGroup] AS SELECT 
[hDED].[dent_ConditionGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidConditionGroup], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Guid] as [Guid], 
[hDED].[Flags] as [Flags]
FROM [oms_dent_ConditionGroup] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
go

