CREATE VIEW [V_onco_BiomaterialCollection] AS SELECT 
[hDED].[BiomaterialCollectionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TalonID] as [rf_TalonID], 
[hDED].[DiagDate] as [DiagDate], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [onco_BiomaterialCollection] as [hDED]
go

