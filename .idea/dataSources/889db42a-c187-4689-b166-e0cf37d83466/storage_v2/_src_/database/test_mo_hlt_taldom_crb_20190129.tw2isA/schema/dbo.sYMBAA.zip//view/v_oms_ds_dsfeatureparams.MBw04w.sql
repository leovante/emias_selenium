CREATE VIEW [V_oms_ds_DSFeatureParams] AS SELECT 
[hDED].[ds_DSFeatureParamsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DSFeaturesGUID] as [rf_DSFeaturesGUID], 
[jT_oms_ds_DSFeatures].[Name] as [SILENT_rf_DSFeaturesGUID], 
[hDED].[rf_RecordID] as [rf_RecordID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[isDel] as [isDel], 
[hDED].[Flags] as [Flags], 
[hDED].[DSFeatureParamsGUID] as [DSFeatureParamsGUID]
FROM [oms_ds_DSFeatureParams] as [hDED]
INNER JOIN [oms_ds_DSFeatures] as [jT_oms_ds_DSFeatures] on [jT_oms_ds_DSFeatures].[DSFeaturesGUID] = [hDED].[rf_DSFeaturesGUID]
go

