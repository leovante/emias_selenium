CREATE VIEW [V_oms_SMCriterionCollect] AS SELECT 
[hDED].[SMCriterionCollectID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[hDED].[rf_SMCollectID] as [rf_SMCollectID], 
[hDED].[SMCriterionCollectDescription] as [SMCriterionCollectDescription], 
[hDED].[SMCriterionCollectRem] as [SMCriterionCollectRem]
FROM [oms_SMCriterionCollect] as [hDED]
go

