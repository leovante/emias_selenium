CREATE VIEW [V_oms_SMRegisterInstruction] AS SELECT 
[hDED].[SMRegisterInstructionID], [hDED].[x_Edition], [hDED].[x_Status], 
(((((select FIO from x_User where UserId = LastUserID))))) as [V_FIOUser], 
[jT_oms_SMRegisterExpert].[V_PRVS_NAME] as [V_V_PRVS_NAME], 
[hDED].[rf_SMExpVidID] as [rf_SMExpVidID], 
[jT_oms_SMExpVid].[NameExpVid] as [SILENT_rf_SMExpVidID], 
[hDED].[rf_SMexpTypeID] as [rf_SMexpTypeID], 
[jT_oms_SMexpType].[NameExpType] as [SILENT_rf_SMexpTypeID], 
[hDED].[rf_SMExpTargetID] as [rf_SMExpTargetID], 
[jT_oms_SMExpTarget].[NameExpTarget] as [SILENT_rf_SMExpTargetID], 
[hDED].[rf_SMExpReasonID] as [rf_SMExpReasonID], 
[jT_oms_SMExpReason].[NameExpReason] as [SILENT_rf_SMExpReasonID], 
[hDED].[rf_SMRegisterExpertID] as [rf_SMRegisterExpertID], 
[jT_oms_SMRegisterExpert].[V_FIO] as [SILENT_rf_SMRegisterExpertID], 
[hDED].[LastUserID] as [LastUserID], 
[hDED].[Num] as [Num], 
[hDED].[DateSend] as [DateSend], 
[hDED].[DateExec] as [DateExec], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags], 
[hDED].[Sum] as [Sum]
FROM [oms_SMRegisterInstruction] as [hDED]
INNER JOIN [V_oms_SMRegisterExpert] as [jT_oms_SMRegisterExpert] on [jT_oms_SMRegisterExpert].[SMRegisterExpertID] = [hDED].[rf_SMRegisterExpertID]
INNER JOIN [oms_SMExpVid] as [jT_oms_SMExpVid] on [jT_oms_SMExpVid].[SMExpVidID] = [hDED].[rf_SMExpVidID]
INNER JOIN [oms_SMexpType] as [jT_oms_SMexpType] on [jT_oms_SMexpType].[SMexpTypeID] = [hDED].[rf_SMexpTypeID]
INNER JOIN [oms_SMExpTarget] as [jT_oms_SMExpTarget] on [jT_oms_SMExpTarget].[SMExpTargetID] = [hDED].[rf_SMExpTargetID]
INNER JOIN [oms_SMExpReason] as [jT_oms_SMExpReason] on [jT_oms_SMExpReason].[SMExpReasonID] = [hDED].[rf_SMExpReasonID]
go

