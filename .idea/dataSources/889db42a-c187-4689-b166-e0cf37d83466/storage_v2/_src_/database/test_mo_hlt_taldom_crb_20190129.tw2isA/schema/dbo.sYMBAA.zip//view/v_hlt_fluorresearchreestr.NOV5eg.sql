CREATE VIEW [V_hlt_FluorResearchReestr] AS SELECT 
[hDED].[FluorResearchReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_LPU].[M_NAMES] as [V_LPUName], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[Num] as [Num], 
[hDED].[DateExport] as [DateExport], 
[hDED].[ReestrType] as [ReestrType], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_FluorResearchReestr] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

