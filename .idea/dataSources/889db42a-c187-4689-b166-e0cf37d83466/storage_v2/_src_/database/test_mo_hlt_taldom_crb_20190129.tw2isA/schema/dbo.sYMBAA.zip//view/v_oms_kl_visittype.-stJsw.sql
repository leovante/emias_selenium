CREATE VIEW [V_oms_kl_VisitType] AS SELECT 
[hDED].[kl_VisitTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_VisitTypeCode], 
((((isnull((Select TOP 1 Code from oms_kl_DepartmentType where kl_DepartmentTypeId = [hDED].[rf_kl_DepartmentTypeID]), 0))))) as [V_DepartmentTypeCode], 
(((isnull((Select TOP 1 name from oms_kl_DepartmentType where kl_DepartmentTypeId = [hDED].[rf_kl_DepartmentTypeID]), 0)))) as [V_DepartmentTypename], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_VisitType] as [hDED]
go

