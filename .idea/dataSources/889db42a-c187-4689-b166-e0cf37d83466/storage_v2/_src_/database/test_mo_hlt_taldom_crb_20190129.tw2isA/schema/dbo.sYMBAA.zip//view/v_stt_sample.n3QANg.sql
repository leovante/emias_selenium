CREATE VIEW [V_stt_Sample] AS SELECT 
[hDED].[SampleID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SamplesTypeID] as [rf_SamplesTypeID], 
[jT_stt_SamplesType].[Name] as [SILENT_rf_SamplesTypeID], 
[hDED].[rf_TransfusionID] as [rf_TransfusionID], 
[jT_stt_Transfusion].[rf_MedicalHistoryID] as [SILENT_rf_TransfusionID], 
[hDED].[compatible] as [compatible], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flags] as [flags]
FROM [stt_Sample] as [hDED]
INNER JOIN [stt_SamplesType] as [jT_stt_SamplesType] on [jT_stt_SamplesType].[SamplesTypeID] = [hDED].[rf_SamplesTypeID]
INNER JOIN [stt_Transfusion] as [jT_stt_Transfusion] on [jT_stt_Transfusion].[TransfusionID] = [hDED].[rf_TransfusionID]
go

