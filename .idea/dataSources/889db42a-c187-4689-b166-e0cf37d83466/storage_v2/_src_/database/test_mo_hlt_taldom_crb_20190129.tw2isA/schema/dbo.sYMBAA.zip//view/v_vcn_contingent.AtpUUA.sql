CREATE VIEW [V_vcn_Contingent] AS SELECT 
[hDED].[ContingentID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_ContingentCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [vcn_Contingent] as [hDED]
go

