CREATE VIEW [V_stt_FHBrigadeProfile] AS SELECT 
[hDED].[FHBrigadeProfileID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [stt_FHBrigadeProfile] as [hDED]
go

