



--   exec  drop procedure [dbo].[hlt_getDocPRVDFilterTable] 0,0,0,11,2,'6758,6753','2019-09-26T00:00:00'
create function [dbo].[hlt_getDocPRVDFilter_v1.3](
@rf_MKABID int, 
@rf_kl_ProfitTypeID int, 
@rf_kl_VisitPlaceID int, 
@rf_kl_ReasonTypeID int, 
@rf_kl_DDServiceID int, 
@rf_ServiceMedicalIDStr varchar(max),
@DateTAP date)
RETURNS --@result 
TABLE
--(servicemedicalId int,IDs_Str varchar(100))

as return
--begin
--insert into @result(servicemedicalId,IDs_Str)
select	servicemedicalId, substring(ids_str,1,len(ids_str)-1) IDs_Str
from	oms_servicemedical sm 
		outer apply (	  
					select (
							select  distinct cast(trf.rf_PRVSID as varchar(11))+','
							from  oms_tariff trf 
								--inner join hlt_DocPRVD d on d.rf_PRVSID = case when trf.rf_PRVSID = 0 then d.rf_PRVSID else trf.rf_PRVSID  end
							where  @DateTAP between trf.date_b and trf.date_e
								and trf.rf_kl_ReasonTypeID = case when (@rf_kl_ReasonTypeID = 0 OR trf.rf_kl_ReasonTypeID = 0) then trf.rf_kl_ReasonTypeID else @rf_kl_ReasonTypeID end
								and trf.rf_kl_VisitPlaceID = case when (@rf_kl_VisitPlaceID = 0 or trf.rf_kl_VisitPlaceID = 0) then trf.rf_kl_VisitPlaceID else @rf_kl_VisitPlaceID end
								and trf.rf_kl_DDServiceID  = case when (@rf_kl_DDServiceID = 0 or trf.rf_kl_DDServiceID = 0) then trf.rf_kl_DDServiceID else @rf_kl_DDServiceID end
								and trf.rf_ServiceMedicalID = sm.ServiceMedicalID
								--and d.rf_LPUDoctorID > 0   and d.DocPRVDID > 0 and d.D_END > @DateTAP			
							for xml path('') 
						) ids_Str
					) PRVS_IDs
where ','+@rf_ServiceMedicalIDStr+',' like  case when @rf_ServiceMedicalIDStr > '' then 	'%,'+cast(ServiceMedicalID as varchar(7))+',%' else '%' end
		and ids_Str >''
--RETURN
--end


go

