CREATE VIEW [V_ehr_Doctors] AS SELECT 
[hDED].[DoctorsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TemplateID] as [rf_TemplateID], 
[hDED].[rf_PredefinedChunkID] as [rf_PredefinedChunkID], 
[hDED].[Guid] as [Guid], 
[hDED].[rf_DoctorId] as [rf_DoctorId], 
[hDED].[rf_DoctorTypeGuid] as [rf_DoctorTypeGuid]
FROM [ehr_Doctors] as [hDED]
go

