CREATE VIEW [V_prp_Purpose] AS SELECT 
[hDED].[PurposeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_CancelDocPRVDID] as [rf_CancelDocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_CancelDocPRVDID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD1].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_SignDocPRVDID] as [rf_SignDocPRVDID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_PurposeID] as [rf_PurposeID], 
[hDED].[rf_PurposeTypeID] as [rf_PurposeTypeID], 
[jT_prp_PurposeType].[Name] as [SILENT_rf_PurposeTypeID], 
[hDED].[rf_PurposeStateID] as [rf_PurposeStateID], 
[hDED].[CancelDate] as [CancelDate], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[SystemDate] as [SystemDate], 
[hDED].[Name] as [Name], 
[hDED].[Summary] as [Summary], 
[hDED].[rf_CardRecordID] as [rf_CardRecordID], 
[hDED].[rf_DocTypeDefGUID] as [rf_DocTypeDefGUID], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[isChronicDiagnos] as [isChronicDiagnos], 
[hDED].[SignDate] as [SignDate], 
[hDED].[Flag] as [Flag]
FROM [prp_Purpose] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_CancelDocPRVDID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD1] on [jT_hlt_DocPRVD1].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [prp_PurposeType] as [jT_prp_PurposeType] on [jT_prp_PurposeType].[PurposeTypeID] = [hDED].[rf_PurposeTypeID]
go

