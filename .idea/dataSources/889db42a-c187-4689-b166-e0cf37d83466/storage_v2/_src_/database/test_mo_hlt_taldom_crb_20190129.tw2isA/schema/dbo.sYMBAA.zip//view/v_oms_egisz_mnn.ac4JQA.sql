CREATE VIEW [V_oms_Egisz_Mnn] AS SELECT 
[hDED].[Egisz_MnnID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Uid] as [Uid], 
[hDED].[Name] as [Name]
FROM [oms_Egisz_Mnn] as [hDED]
go

