CREATE VIEW [V_emd_Status] AS SELECT 
[hDED].[StatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [emd_Status] as [hDED]
go

