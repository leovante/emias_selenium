CREATE VIEW [V_oms_LicenceReestr] AS SELECT 
[hDED].[LicenceReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_LPU].[M_NAMES] as [V_M_NAMES], 
[jT_oms_LPU].[MCOD] as [V_MCOD], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[NumLic] as [NumLic], 
[hDED].[Doc] as [Doc], 
[hDED].[DateB] as [DateB], 
[hDED].[DateE] as [DateE], 
[hDED].[Rem] as [Rem], 
[hDED].[State] as [State], 
[hDED].[GUIDLicenceReestr] as [GUIDLicenceReestr], 
[hDED].[Flags] as [Flags]
FROM [oms_LicenceReestr] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

