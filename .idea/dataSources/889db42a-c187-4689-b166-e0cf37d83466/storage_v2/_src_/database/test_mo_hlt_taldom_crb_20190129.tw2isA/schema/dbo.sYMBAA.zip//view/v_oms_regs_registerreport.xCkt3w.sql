CREATE VIEW [V_oms_regs_RegisterReport] AS SELECT 
[hDED].[regs_RegisterReportID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RegisterID] as [rf_RegisterID], 
[hDED].[rf_ReportGuid] as [rf_ReportGuid]
FROM [oms_regs_RegisterReport] as [hDED]
go

