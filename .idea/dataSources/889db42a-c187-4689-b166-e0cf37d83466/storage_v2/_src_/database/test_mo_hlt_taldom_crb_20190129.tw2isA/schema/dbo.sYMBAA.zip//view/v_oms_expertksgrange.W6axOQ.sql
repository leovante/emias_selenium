CREATE VIEW [V_oms_ExpertKSGRange] AS SELECT 
[hDED].[ExpertKSGRangeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[MinValue] as [MinValue], 
[hDED].[MaxValue] as [MaxValue]
FROM [oms_ExpertKSGRange] as [hDED]
go

