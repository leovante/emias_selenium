CREATE VIEW [V_dd_DDPhisicalDevelopment] AS SELECT 
[hDED].[DDPhisicalDevelopmentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDChildFormID] as [rf_DDChildFormID], 
[hDED].[Growth] as [Growth], 
[hDED].[Weight] as [Weight], 
[hDED].[HeadCircumference] as [HeadCircumference], 
[hDED].[IsDeviant] as [IsDeviant], 
[hDED].[Flag] as [Flag]
FROM [dd_DDPhisicalDevelopment] as [hDED]
go

