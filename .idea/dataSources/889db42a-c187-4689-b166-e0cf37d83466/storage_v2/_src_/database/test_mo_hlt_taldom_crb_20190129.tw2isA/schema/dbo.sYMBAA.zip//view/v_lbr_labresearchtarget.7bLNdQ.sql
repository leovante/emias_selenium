CREATE VIEW [V_lbr_LabResearchTarget] AS SELECT 
[hDED].[LabResearchTargetID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags]
FROM [lbr_LabResearchTarget] as [hDED]
go

