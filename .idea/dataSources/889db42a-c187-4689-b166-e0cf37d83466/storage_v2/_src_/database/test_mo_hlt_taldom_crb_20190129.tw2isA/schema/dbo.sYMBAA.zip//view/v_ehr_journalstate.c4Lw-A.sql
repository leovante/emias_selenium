CREATE VIEW [V_ehr_JournalState] AS SELECT 
[hDED].[JournalStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Description] as [Description]
FROM [ehr_JournalState] as [hDED]
go

