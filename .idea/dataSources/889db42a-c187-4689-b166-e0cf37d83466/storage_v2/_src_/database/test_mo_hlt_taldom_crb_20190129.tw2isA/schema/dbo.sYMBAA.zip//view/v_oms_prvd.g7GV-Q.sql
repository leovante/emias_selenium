CREATE VIEW [V_oms_PRVD] AS SELECT 
[hDED].[PRVDID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[C_PRVD] as [C_PRVD], 
[hDED].[NAME] as [NAME], 
[hDED].[Date_B] as [Date_B], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[Date_E] as [Date_E]
FROM [oms_PRVD] as [hDED]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
go

