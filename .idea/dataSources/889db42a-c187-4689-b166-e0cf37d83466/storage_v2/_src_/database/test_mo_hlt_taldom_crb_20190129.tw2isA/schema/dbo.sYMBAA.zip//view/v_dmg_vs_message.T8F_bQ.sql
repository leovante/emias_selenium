CREATE VIEW [V_dmg_vs_Message] AS SELECT 
[hDED].[vs_MessageID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_vs_VacationTypeID] as [rf_vs_VacationTypeID], 
[hDED].[rf_vs_OrganizatonID] as [rf_vs_OrganizatonID], 
[hDED].[Date] as [Date], 
[hDED].[IsDelivered] as [IsDelivered], 
[hDED].[ErrorCode] as [ErrorCode], 
[hDED].[Snils] as [Snils], 
[hDED].[DateBeginDocument] as [DateBeginDocument], 
[hDED].[DateEndDocument] as [DateEndDocument], 
[hDED].[DocumentType] as [DocumentType], 
[hDED].[DocumentGuid] as [DocumentGuid], 
[hDED].[MessageType] as [MessageType], 
[hDED].[DateBeginVacation] as [DateBeginVacation], 
[hDED].[DateEndVacation] as [DateEndVacation], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dmg_vs_Message] as [hDED]
go

