CREATE VIEW [V_vcn_LocalReaction] AS SELECT 
[hDED].[LocalReactionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [vcn_LocalReaction] as [hDED]
go

