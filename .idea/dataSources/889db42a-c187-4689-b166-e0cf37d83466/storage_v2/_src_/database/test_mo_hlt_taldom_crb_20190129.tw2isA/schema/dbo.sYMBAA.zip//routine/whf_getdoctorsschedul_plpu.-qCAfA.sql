
CREATE FUNCTION [dbo].[whf_GetDoctorsSchedul_PLPU]
(	@dateA datetime, 
	@dateB datetime	,
	@MCOD varchar(10) = '%' ,
	@FlagAccess int		)
RETURNS 
@tmp_tab TABLE
(	DocPRVDID int,	
	DocID int,
	Fam varchar (255),
	Im varchar (50),
	Ot varchar (50),	
	UchastokID int,
	Uchastok varchar(255), 	
	SeparationID int,
	SeparationName varchar (255),
	SpecialityID int,
	SpecialityCode varchar (255),
	SpecialityName varchar (255),	
	DolgID int,
	DolgName varchar (250),
	RoomID int,
	RoomNum varchar (250),	
	[Date] datetime, 
	[OutReason] varchar(250),
	Hour_from int,
	Minute_from int,
	Hour_to int,
	Minute_to int,
	[TicketCount] int,
	[FlagAccess] int,
	InTime	int,
	ShownInSchedule int)
AS
BEGIN	

declare @maxDaysTmp int = (select ValueInt from x_UserSettings where Property = 'WebHlt: количество дней в расписании')
declare @hourOpen int = (select ValueInt from x_UserSettings where Property = 'WebHlt: время открытия талонов')
declare @maxDays int = case when @FlagAccess = 8 then 28 else (case when (datepart(hour, getdate()) >= @hourOpen) then @maxDaysTmp else @maxDaysTmp - 1 end) end

declare  @prvdWithOneAndMoreInternetAccess table(
prvsid int);

 insert into @prvdWithOneAndMoreInternetAccess select docPRVD.docPRVDID from hlt_DocPRVD docPRVD WITH (NOLOCK)
			INNER JOIN oms_Department dep WITH (NOLOCK) ON dep.DepartmentID = docPRVD.rf_DepartmentID
			INNER JOIN oms_LPU lpu WITH (NOLOCK) ON dep.rf_LPUID = lpu.LPUID
				AND lpu.MCOD LIKE @MCOD
			INNER JOIN hlt_DoctorTimeTable dtt WITH (NOLOCK) ON dtt.rf_DocPRVDID = docPRVD.docPRVDID
			INNER JOIN hlt_DocBusyType dbt WITH (NOLOCK) ON dtt.rf_DocBusyType = dbt.DocBusyTypeID
			LEFT JOIN hlt_DoctorVisitTable dvt WITH (NOLOCK) ON dvt.rf_DoctorTimeTableID = dtt.DoctorTimeTableID
			WHERE docPRVD.rf_PRVSID > 0
				AND docPRVD.docPRVDID > 0
				AND docPRVD.inTime = 1
				AND dtt.DoctorTimeTableID > 0
				and (DATEPART(hour, getdate()) >= @hourOpen and dtt.Date = CAST(getdate() AS date))
				and (FlagAccess & 4) > 0
				AND dtt.Begin_Time <> '1900-01-01T00:00:00' and datepart(hour, dtt.Begin_Time) > 0 --отсекаем записи вне очереди
				AND dbt.TypeBusy in (1, 2)
---------------------------------
	INSERT INTO @tmp_tab
	(	DocPRVDID,	
		DocID,
		Fam,
		Im ,
		Ot ,	
		UchastokID,
		Uchastok, 	
		SeparationID,
		SeparationName,
		SpecialityID,
		SpecialityCode,
		SpecialityName,		
		DolgID,
		DolgName,
		RoomID,
		RoomNum,	
		[Date], 
		[OutReason],
		Hour_from ,
		Minute_from ,
		Hour_to ,
		Minute_to ,
		[TicketCount] ,
		[FlagAccess] ,
		InTime,
		ShownInSchedule)
	SELECT  
		p.DocPRVDID as DocPRVDID,
		doc.LPUDoctorID as DocID,
		
		CASE WHEN p.rf_ResourceTypeID = 2 THEN	hr.Comment		
			WHEN p.rf_ResourceTypeID = 3 THEN eq.Name +' '+ eqt.Name
			 WHEN doc.LPUDoctorID = 0 THEN ''
			 WHEN (doc.FAM_V is null) OR (LEN(doc.FAM_V)) = 0 THEN ''
			 WHEN (LEN(doc.FAM_V) = 1) THEN Upper(doc.FAM_V)
			 ELSE CAST(Upper(substring(doc.FAM_V,1,1)) + lower(substring(doc.FAM_V,2, 50)) AS VARCHAR(255)) 
			 END AS Fam,
		CASE WHEN p.rf_ResourceTypeID = 2 OR p.rf_ResourceTypeID = 3 THEN ''
			 WHEN doc.LPUDoctorID = 0 THEN ''
			 WHEN (doc.IM_V is null) OR (LEN(doc.IM_V)) = 0 THEN ''
			 WHEN (LEN(doc.IM_V) = 1) THEN Upper(doc.IM_V)
			 ELSE CAST(Upper(substring(doc.IM_V,1,1)) + lower(substring(doc.IM_V,2, 25)) AS VARCHAR(25)) 
			 END AS IM,
		CASE WHEN p.rf_ResourceTypeID = 2 OR p.rf_ResourceTypeID = 3 THEN ''
			 WHEN doc.LPUDoctorID = 0 THEN ''
			 WHEN (doc.OT_V is null) OR (LEN(doc.OT_V)) = 0 THEN ''
			 WHEN (LEN(doc.OT_V) = 1) THEN Upper(doc.OT_V)
			 ELSE CAST(Upper(substring(doc.OT_V,1,1)) + lower(substring(doc.OT_V,2, 25)) AS VARCHAR(25)) 
			 END AS OT,

		null AS UchastokID, 	
		CAST('' AS VARCHAR(100)) AS Uchastok, 	
		ISNULL(dp.DepartmentID, 0) AS SeparationID ,
		CAST(ISNULL(dp.DepartmentName, '') AS VARCHAR(255)) AS SeparationName, 
		ISNULL(prvs.PRVSid, 0) AS SpecialityID, 
		CAST(ISNULL(prvs.C_PRVS, '') AS VARCHAR(255)) AS SpecialityCode, 
		CAST(ISNULL(prvs.PRVS_NAME, '') AS VARCHAR(255)) AS SpecialityName, 
		ISNULL(prvd.prvdid, 0) AS DolgID, 
		CASE prvd.prvdid WHEN 0 THEN '' ELSE CAST(ISNULL(prvd.name, '') AS VARCHAR(50)) END AS DolgName, 
		ISNULL(hr.HealingRoomID, 0) AS RoomID,
		CAST(ISNULL(hr.Num, '') AS VARCHAR(10)) AS RoomNum,		
		/*DTT_Date*/iv.Date AS [Date],
		ISNULL(OutReason, '') AS [OutReason],
		ISNULL(Hour_from, 0) AS Hour_from,
		ISNULL(Minute_from, 0) AS Minute_from,
		ISNULL(Hour_To, 0) AS Hour_To,
		ISNULL(Minute_to, 0) AS Minute_to,
		0 AS [TicketCount],
		0 AS [FlagAccess],
		p.InTime AS InTime,
		p.ShownInSchedule as ShownInSchedule
	FROM hlt_DocPrvd p WITH(NOLOCK) 
		INNER JOIN hlt_LpuDoctor doc WITH(NOLOCK)  on p.rf_LPUDoctorID = doc.LPUDoctorID
		INNER JOIN oms_Department dp WITH(NOLOCK)  on dp.DepartmentID = p.rf_DepartmentID 
		INNER JOIN oms_LPU lpu WITH(NOLOCK)  ON dp.rf_LPUID = lpu.LPUID and lpu.MCOD like @MCOD
		left JOIN oms_prvs prvs WITH(NOLOCK)  on p.rf_PRVSID  = prvs.prvsid
		left JOIN oms_prvd prvd WITH(NOLOCK)  on prvd.PRVDID = p.rf_PRVDID
		left JOIN hlt_HealingRoom hr WITH(NOLOCK)  on hr.HealingRoomID = p.rf_HealingRoomID
		left JOIN hlt_Equipment eq WITH(NOLOCK)  on p.rf_EquipmentID = eq.EquipmentID
		left JOIN hlt_EquipmentType eqt WITH(NOLOCK)  on eq.rf_EquipmentTypeID = eqt.EquipmentTypeID 
		INNER JOIN
		(	SELECT dtt.Date, 
				dtt.rf_DocPRVDID as DocPRVDID,									
				CASE (ISNULL(MAX(dbt.TypeBusy),0))
					WHEN 0 THEN 
						CASE ISNULL(min(dbt.CODE ), 0)
							WHEN 0 THEN NULL
							WHEN 1 THEN 'Отп.'
							WHEN 2 THEN 'Вых.'
							WHEN 3 THEN 'Бол.'
							ELSE
							  'н/п'
							END					
					ELSE NULL END as [OutReason],
				CASE  
					WHEN min(dtt.Begin_Time) = null THEN NULL
					WHEN DATEPART(hh, (min(dtt.Begin_Time))) = 0 THEN NULL 
					ELSE Convert(VARCHAR(2), DATEPART(hh, (min(dtt.Begin_Time))), 2)					  
					END AS Hour_from,				
				CASE 
					WHEN min(dtt.Begin_Time) = null THEN NULL
					WHEN DATEPART(hh, min(dtt.Begin_Time)) = 0 THEN NULL
					ELSE right('0' + convert(VARCHAR(2), DATEPART(mi, min(dtt.Begin_Time))), 2)
					END AS Minute_from,
				CASE
					WHEN min(dtt.Begin_Time) = null THEN NULL
					WHEN DATEPART(hh, min(dtt.Begin_Time)) = 0 THEN NULL
					ELSE Convert(VARCHAR(2), DATEPART(hh, max(dtt.End_Time)), 2) 
					END AS Hour_to,
				CASE 
					WHEN min(dtt.Begin_Time) = null THEN NULL
					WHEN DATEPART(hh, min(dtt.Begin_Time)) = 0 THEN null
					ELSE right('0' + convert(VARCHAR(2), DATEPART(mi, max(dtt.End_Time))), 2)
					END AS Minute_to
			FROM         
				dbo.hlt_DoctorTimeTable AS dtt  WITH(NOLOCK) 
				INNER JOIN
					dbo.hlt_DocBusyType AS dbt  WITH(NOLOCK) 
					ON dbt.DocBusyTypeID = dtt.rf_DocBusyType AND dbt.DocBusyTypeID <> 0 				
				WHERE   dtt.DoctorTimeTableID <> 0                        
						and dtt.Begin_Time <> '1900-01-01T00:00:00' and datepart(hour, dtt.Begin_Time) > 0  
						and dtt.rf_DocPRVDID <> 0 
						and dtt.Date between CAST(@dateA AS DATE)  and @dateB
																								-- Для записи врач-врач не ограничиваем интервал.
						and ((dtt.Begin_Time < DateAdd(d, @maxDays, CAST(getdate() AS date))) or (@FlagAccess = 8))
						and ((dbt.TypeBusy = 0) OR (dbt.TypeBusy in (1, 2) AND (DATEPART(hh, dtt.Begin_Time) > 0)))	
				group by dtt.Date, dtt.rf_DocPRVDID		)	iv
		on iv.DocPRVDID = p.DocPrVdID 

delete from @tmp_tab where intime != 1;
/* Считаем TicketCount */

if @FlagAccess > 0 BEGIN
	UPDATE @tmp_tab
	SET  [TicketCount]  = iv.TicketCount
	FROM @tmp_tab t
		left loop JOIN (
			SELECT 
				dtt.Date, 
				dtt.rf_DocPrVdID,
				sum(dtt.PlanUE - dtt.UsedUE) as TicketCount
			FROM 
				dbo.hlt_DoctorTimeTable AS dtt  WITH(NOLOCK) 
					INNER JOIN 	dbo.hlt_DocBusyType AS dbt  WITH(NOLOCK) 
						ON dbt.DocBusyTypeID = dtt.rf_DocBusyType AND dbt.DocBusyTypeID <> 0 
			WHERE dtt.Date between CAST(@dateA AS DATE) and @dateB
				  and dtt.PlanUE > 0
				  and (dbt.TypeBusy in (1, 2)) 			  
				  --and (dtt.FlagAccess & @FlagAccess) > 0		-- Только для самозаписи	----------------------------------------------
				  
				  and 
				  	-- После @hourOpen на сегодня открываем ячейки, на которые был запрет самозаписи
				    -- (есть хотя бы 1 ячейка с возомжностью записи через интернет)
					(case when
						(((@FlagAccess & 4) > 0) and (dtt.Date = CAST(getdate() AS date)) and (DATEPART(hour, getdate()) >= @hourOpen) and dtt.rf_DocPrvdID in (select * from @prvdWithOneAndMoreInternetAccess))
						then 
						  1
						else 
						  (case when
							  ((dtt.FlagAccess & @FlagAccess) > 0) 
							  then 1
							  else 0
						  end)
						end)> 0

				  and dtt.DoctorTimeTableID <> 0       
				  AND ((dtt.DATE > CAST(@dateA AS DATE)) OR (dtt.Begin_Time > @dateA)) --В день начала учитываем время                  
				  and dtt.Begin_Time <> '1900-01-01T00:00:00' and datepart(hour, dtt.Begin_Time) > 0 --отсекаем записи вне очереди
																						-- Для записи врач-врач не ограничиваем интервал.
				   and (dtt.Begin_Time < DateAdd(d, @maxDays, CAST(getdate() AS date)) or (@FlagAccess = 8))
				  and (dtt.rf_DocPRVDID <> 0)			  
			GROUP BY  dtt.Date, dtt.rf_DocPrVdID		)	iv
		ON iv.rf_DocPrVdID = t.DocPRVDID and iv.Date = t.[Date]
	WHERE iv.rf_DocPrVdID is not null 


	/* Считаем [FlagAccess] */ 
	UPDATE @tmp_tab
	SET  [FlagAccess]  = iv.FA
	FROM @tmp_tab t
		inner loop JOIN (
				SELECT 
				dtt.Date, 
				dtt.rf_DocPrVdID,
					max( DISTINCT(dtt.[FlagAccess] & 1)) +
					max( DISTINCT(dtt.[FlagAccess] & 2)) +
					max( DISTINCT(dtt.[FlagAccess] & 4)) +
					max( DISTINCT(dtt.[FlagAccess] & 8))  AS FA 
				FROM 
				dbo.hlt_DoctorTimeTable AS dtt  WITH(NOLOCK) 
					INNER JOIN 	dbo.hlt_DocBusyType AS dbt  WITH(NOLOCK) 
						ON dbt.DocBusyTypeID = dtt.rf_DocBusyType AND dbt.DocBusyTypeID <> 0 
				WHERE dtt.Date between CAST(@dateA AS DATE) and @dateB
					  and dtt.PlanUE > 0
					  and (dbt.TypeBusy in (1, 2)) 			  
					  --and (dtt.PlanUE > dtt.UsedUE)
					  and dtt.DoctorTimeTableID <> 0                        
					  and dtt.Begin_Time <> '1900-01-01T00:00:00' and datepart(hour, dtt.Begin_Time) > 0 --отсекаем записи вне очереди					  
					  and (dtt.rf_DocPRVDID <> 0)			  
				GROUP BY  dtt.Date, dtt.rf_DocPrVdID	)	iv
		on iv.rf_DocPrVdID = t.DocPRVDID and iv.Date = t.[Date]
	WHERE iv.rf_DocPrVdID is not null 
END

UPDATE @tmp_tab 
SET Uchastokid = 0, Uchastok = isnull(CAST(substring((SELECT ', ' + ltrim(rtrim(Code)) AS [text()] FROM dbo.hlt_Uchastok   WITH(NOLOCK) WHERE rf_DocPRVDID = DocPRVDID FOR XML PATH('')), 3, 1000) AS VARCHAR(200) ), '') 
FROM @tmp_tab

	RETURN 

END

go

