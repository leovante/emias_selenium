CREATE VIEW [V_hlt_disp_ServicePRVS] AS SELECT 
[hDED].[disp_ServicePRVSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_PRVSID], 
[hDED].[rf_ServiceGuid] as [rf_ServiceGuid], 
[jT_hlt_disp_Service].[Name] as [SILENT_rf_ServiceGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_ServicePRVS] as [hDED]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
INNER JOIN [hlt_disp_Service] as [jT_hlt_disp_Service] on [jT_hlt_disp_Service].[Guid] = [hDED].[rf_ServiceGuid]
go

