CREATE VIEW [V_lbr_SampleConteiner] AS SELECT 
[hDED].[SampleConteinerID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ContainerID] as [rf_ContainerID], 
[hDED].[rf_SampleID] as [rf_SampleID], 
[hDED].[LaboratoryNumber] as [LaboratoryNumber]
FROM [lbr_SampleConteiner] as [hDED]
go

