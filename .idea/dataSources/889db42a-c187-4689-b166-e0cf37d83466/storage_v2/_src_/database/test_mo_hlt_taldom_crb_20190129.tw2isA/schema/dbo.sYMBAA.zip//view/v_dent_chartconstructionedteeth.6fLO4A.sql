CREATE VIEW [V_dent_ChartConstructionedTeeth] AS SELECT 
[hDED].[ChartConstructionedTeethID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ChildToothID] as [rf_ChildToothID], 
[jT_dent_ChartTooth].[Date] as [SILENT_rf_ChildToothID], 
[hDED].[rf_RootToothID] as [rf_RootToothID], 
[jT_dent_ChartTooth1].[Date] as [SILENT_rf_RootToothID], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dent_ChartConstructionedTeeth] as [hDED]
INNER JOIN [dent_ChartTooth] as [jT_dent_ChartTooth] on [jT_dent_ChartTooth].[ChartToothID] = [hDED].[rf_ChildToothID]
INNER JOIN [dent_ChartTooth] as [jT_dent_ChartTooth1] on [jT_dent_ChartTooth1].[ChartToothID] = [hDED].[rf_RootToothID]
go

