CREATE VIEW [V_oms_TRName] AS SELECT 
[hDED].[TRNameID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_TRN] as [C_TRN], 
[hDED].[NAME_TRN] as [NAME_TRN], 
[hDED].[NAME_LAT] as [NAME_LAT], 
[hDED].[MSG_TEXT] as [MSG_TEXT], 
[hDED].[GUIDTrn] as [GUIDTrn], 
[hDED].[Brand] as [Brand]
FROM [oms_TRName] as [hDED]
go

