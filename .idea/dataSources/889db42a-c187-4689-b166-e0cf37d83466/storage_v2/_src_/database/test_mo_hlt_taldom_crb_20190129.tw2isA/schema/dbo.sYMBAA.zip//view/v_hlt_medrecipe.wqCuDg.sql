CREATE VIEW [V_hlt_MedRecipe] AS SELECT 
[hDED].[MedRecipeID], [hDED].[x_Edition], [hDED].[x_Status], 
(( select top 1 ([FAMILY] + ' ' + [NAME] + ' ' + [OT]) from hlt_MKAB m where  m.UGUID = hDED.PersonGUID )) as [V_FIO], 
(isnull( ( select top 1 NAME_MED from oms_LS l where l.NOMK_LS = hDED.NOMK_LS ) , '')) as [V_LS], 
(isnull( ( select top 1 NAME_MNN from oms_MNName m  where  m.C_MNN = hDED.C_MNN ) , '')) as [V_MNN], 
(((select case when hDED.RecipeView = 0 then 'Коммерческий' when hDED.RecipeView = 1 then 'Льготный' else  'не определено' end))) as [V_RecipeView], 
[hDED].[rf_LFID] as [rf_LFID], 
[jT_oms_LF].[C_LF] as [SILENT_rf_LFID], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[jT_oms_KATL].[C_KATL] as [SILENT_rf_KATLID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[jT_oms_Finl].[NAME] as [SILENT_rf_FinlID], 
[hDED].[rf_PR_LRID] as [rf_PR_LRID], 
[jT_oms_PR_LR].[PR_LR_VALUE] as [SILENT_rf_PR_LRID], 
[hDED].[rf_PeriodID] as [rf_PeriodID], 
[jT_oms_Period].[Period_Length] as [SILENT_rf_PeriodID], 
[hDED].[rf_Period2ID] as [rf_Period2ID], 
[jT_oms_Period1].[Period_Length] as [SILENT_rf_Period2ID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_CancelDocPRVDID] as [rf_CancelDocPRVDID], 
[jT_hlt_DocPRVD1].[Name] as [SILENT_rf_CancelDocPRVDID], 
[hDED].[rf_CommonReestrID] as [rf_CommonReestrID], 
[jT_hlt_CommonReestr].[Num] as [SILENT_rf_CommonReestrID], 
[hDED].[rf_DeliveryAddressID] as [rf_DeliveryAddressID], 
[jT_kla_Address].[CODE] as [SILENT_rf_DeliveryAddressID], 
[hDED].[rf_LSPurposeID] as [rf_LSPurposeID], 
[jT_hlt_LSPurpose].[rf_MNNameID] as [SILENT_rf_LSPurposeID], 
[hDED].[rf_MedRecipeFormID] as [rf_MedRecipeFormID], 
[jT_oms_MedRecipeForm].[Name] as [SILENT_rf_MedRecipeFormID], 
[hDED].[rf_MedRecipeForm2ID] as [rf_MedRecipeForm2ID], 
[jT_oms_MedRecipeForm1].[Name] as [SILENT_rf_MedRecipeForm2ID], 
[hDED].[rf_MedRecipeUrgencyID] as [rf_MedRecipeUrgencyID], 
[jT_oms_MedRecipeUrgency].[Name] as [SILENT_rf_MedRecipeUrgencyID], 
[hDED].[rf_MedRecipeStatusID] as [rf_MedRecipeStatusID], 
[jT_oms_MedRecipeStatus].[Name] as [SILENT_rf_MedRecipeStatusID], 
[hDED].[DateRecipe] as [DateRecipe], 
[hDED].[C_MNN] as [C_MNN], 
[hDED].[Doz] as [Doz], 
[hDED].[Description] as [Description], 
[hDED].[KEK_State] as [KEK_State], 
[hDED].[NOMK_LS] as [NOMK_LS], 
[hDED].[PCOD] as [PCOD], 
[hDED].[PersonGUID] as [PersonGUID], 
[hDED].[PrintCount] as [PrintCount], 
[hDED].[SS] as [SS], 
[hDED].[Kv_all] as [Kv_all], 
[hDED].[Num_Recipe] as [Num_Recipe], 
[hDED].[Series_Recipe] as [Series_Recipe], 
[hDED].[Signa] as [Signa], 
[hDED].[RecipeGUID] as [RecipeGUID], 
[hDED].[RecipeView] as [RecipeView], 
[hDED].[Flags] as [Flags], 
[hDED].[AgeYears] as [AgeYears], 
[hDED].[AgeMonth] as [AgeMonth], 
[hDED].[DispencePeriod] as [DispencePeriod], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[Series_additional] as [Series_additional], 
[hDED].[Num_additional] as [Num_additional], 
[hDED].[CancelDate] as [CancelDate], 
[hDED].[isBaseDoseOverride] as [isBaseDoseOverride], 
[hDED].[EDS] as [EDS], 
[hDED].[isSpecialPurpose] as [isSpecialPurpose], 
[hDED].[isSigned] as [isSigned], 
[hDED].[isChronicDisease] as [isChronicDisease], 
[hDED].[isSoftVersion] as [isSoftVersion], 
[hDED].[isLSHome] as [isLSHome], 
[hDED].[isStatusEdition] as [isStatusEdition], 
[hDED].[isSignedKek] as [isSignedKek], 
[hDED].[PatientPhone] as [PatientPhone], 
[hDED].[DeliveryAddress] as [DeliveryAddress]
FROM [hlt_MedRecipe] as [hDED]
INNER JOIN [oms_LF] as [jT_oms_LF] on [jT_oms_LF].[LFID] = [hDED].[rf_LFID]
INNER JOIN [oms_KATL] as [jT_oms_KATL] on [jT_oms_KATL].[KATLID] = [hDED].[rf_KATLID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_Finl] as [jT_oms_Finl] on [jT_oms_Finl].[FinlID] = [hDED].[rf_FinlID]
INNER JOIN [oms_PR_LR] as [jT_oms_PR_LR] on [jT_oms_PR_LR].[PR_LRID] = [hDED].[rf_PR_LRID]
INNER JOIN [oms_Period] as [jT_oms_Period] on [jT_oms_Period].[PeriodID] = [hDED].[rf_PeriodID]
INNER JOIN [oms_Period] as [jT_oms_Period1] on [jT_oms_Period1].[PeriodID] = [hDED].[rf_Period2ID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD1] on [jT_hlt_DocPRVD1].[DocPRVDID] = [hDED].[rf_CancelDocPRVDID]
INNER JOIN [hlt_CommonReestr] as [jT_hlt_CommonReestr] on [jT_hlt_CommonReestr].[CommonReestrID] = [hDED].[rf_CommonReestrID]
INNER JOIN [kla_Address] as [jT_kla_Address] on [jT_kla_Address].[AddressID] = [hDED].[rf_DeliveryAddressID]
INNER JOIN [hlt_LSPurpose] as [jT_hlt_LSPurpose] on [jT_hlt_LSPurpose].[LSPurposeID] = [hDED].[rf_LSPurposeID]
INNER JOIN [oms_MedRecipeForm] as [jT_oms_MedRecipeForm] on [jT_oms_MedRecipeForm].[MedRecipeFormID] = [hDED].[rf_MedRecipeFormID]
INNER JOIN [oms_MedRecipeForm] as [jT_oms_MedRecipeForm1] on [jT_oms_MedRecipeForm1].[MedRecipeFormID] = [hDED].[rf_MedRecipeForm2ID]
INNER JOIN [oms_MedRecipeUrgency] as [jT_oms_MedRecipeUrgency] on [jT_oms_MedRecipeUrgency].[MedRecipeUrgencyID] = [hDED].[rf_MedRecipeUrgencyID]
INNER JOIN [oms_MedRecipeStatus] as [jT_oms_MedRecipeStatus] on [jT_oms_MedRecipeStatus].[MedRecipeStatusID] = [hDED].[rf_MedRecipeStatusID]
go

