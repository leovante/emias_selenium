CREATE VIEW [V_stt_PathologicalReaction] AS SELECT 
[hDED].[PathologicalReactionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MNNameID] as [rf_MNNameID], 
[hDED].[rf_LSID] as [rf_LSID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_PathologicalReactionTypeID] as [rf_PathologicalReactionTypeID], 
[hDED].[rf_PathologicalReactionClinicalManifestationsID] as [rf_PathologicalReactionClinicalManifestationsID], 
[hDED].[rf_AllergenID] as [rf_AllergenID], 
[hDED].[Date] as [Date], 
[hDED].[Note] as [Note], 
[hDED].[UGUID] as [UGUID], 
[hDED].[SideEffect] as [SideEffect], 
[hDED].[rf_EventID] as [rf_EventID], 
[hDED].[EventDocGUID] as [EventDocGUID]
FROM [stt_PathologicalReaction] as [hDED]
go

