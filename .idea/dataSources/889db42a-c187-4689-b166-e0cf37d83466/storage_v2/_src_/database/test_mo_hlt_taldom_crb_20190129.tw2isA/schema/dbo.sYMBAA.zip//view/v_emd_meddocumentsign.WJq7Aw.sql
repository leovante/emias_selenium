CREATE VIEW [V_emd_MedDocumentSign] AS SELECT 
[hDED].[MedDocumentSignID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MedDocumentID] as [rf_MedDocumentID], 
[jT_emd_MedDocument].[RegNum] as [SILENT_rf_MedDocumentID], 
[hDED].[rf_SignRoleID] as [rf_SignRoleID], 
[jT_emd_SignRole].[Name] as [SILENT_rf_SignRoleID], 
[hDED].[SignData] as [SignData], 
[hDED].[rf_DoctorTypeID] as [rf_DoctorTypeID], 
[hDED].[rf_DoctorID] as [rf_DoctorID], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateSign] as [DateSign]
FROM [emd_MedDocumentSign] as [hDED]
INNER JOIN [emd_MedDocument] as [jT_emd_MedDocument] on [jT_emd_MedDocument].[MedDocumentID] = [hDED].[rf_MedDocumentID]
INNER JOIN [emd_SignRole] as [jT_emd_SignRole] on [jT_emd_SignRole].[SignRoleID] = [hDED].[rf_SignRoleID]
go

