CREATE VIEW [V_hlt_TypeManipulation] AS SELECT 
[hDED].[TypeManipulationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_HealingRoomID] as [rf_HealingRoomID], 
[jT_hlt_HealingRoom].[Num] as [SILENT_rf_HealingRoomID], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[CODE] as [CODE], 
[hDED].[Name] as [Name], 
[hDED].[GUID] as [GUID], 
[hDED].[Flags] as [Flags]
FROM [hlt_TypeManipulation] as [hDED]
INNER JOIN [hlt_HealingRoom] as [jT_hlt_HealingRoom] on [jT_hlt_HealingRoom].[HealingRoomID] = [hDED].[rf_HealingRoomID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
go

