CREATE VIEW [V_oms_onco_Sign] AS SELECT 
[hDED].[onco_SignID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Flags] as [Flags], 
[hDED].[GuidSign] as [GuidSign]
FROM [oms_onco_Sign] as [hDED]
go

