CREATE VIEW [V_onco_Mrf] AS SELECT 
[hDED].[MrfID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_onco_N007ID] as [rf_onco_N007ID], 
[hDED].[rf_onco_N008ID] as [rf_onco_N008ID], 
[hDED].[rf_TalonID] as [rf_TalonID], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Diag_Date_Mrf] as [Diag_Date_Mrf]
FROM [onco_Mrf] as [hDED]
go

