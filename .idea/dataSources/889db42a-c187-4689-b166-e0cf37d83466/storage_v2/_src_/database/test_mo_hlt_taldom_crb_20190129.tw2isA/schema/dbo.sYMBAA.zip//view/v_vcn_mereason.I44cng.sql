CREATE VIEW [V_vcn_MEReason] AS SELECT 
[hDED].[MEReasonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [vcn_MEReason] as [hDED]
go

