CREATE VIEW [V_smp_MedService] AS SELECT 
[hDED].[MedServiceID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [V_ServiceMedicalName], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[hDED].[rf_TariffID] as [rf_TariffID], 
[hDED].[rf_JournalCallID] as [rf_JournalCallID], 
[hDED].[Count] as [Count], 
[hDED].[Date] as [Date], 
[hDED].[Flag] as [Flag], 
[hDED].[flagBill] as [flagBill], 
[hDED].[flagComplete] as [flagComplete], 
[hDED].[flagPay] as [flagPay], 
[hDED].[flagStatic] as [flagStatic], 
[hDED].[Norm] as [Norm], 
[hDED].[PercentComplete] as [PercentComplete], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateEnd] as [DateEnd]
FROM [smp_MedService] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
go

