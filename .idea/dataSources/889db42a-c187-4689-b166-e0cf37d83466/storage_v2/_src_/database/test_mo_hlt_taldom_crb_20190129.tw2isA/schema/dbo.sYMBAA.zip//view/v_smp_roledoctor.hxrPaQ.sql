CREATE VIEW [V_smp_RoleDoctor] AS SELECT 
[hDED].[RoleDoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [smp_RoleDoctor] as [hDED]
go

