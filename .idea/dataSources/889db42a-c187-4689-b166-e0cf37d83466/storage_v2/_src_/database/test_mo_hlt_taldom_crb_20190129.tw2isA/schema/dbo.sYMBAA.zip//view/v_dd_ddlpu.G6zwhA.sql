CREATE VIEW [V_dd_DDLPU] AS SELECT 
[hDED].[DDLPUID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_STFGUID] as [rf_STFGUID], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[DateDogovor] as [DateDogovor], 
[hDED].[MaxPrice] as [MaxPrice], 
[hDED].[Number] as [Number], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDLPU] as [hDED]
go

