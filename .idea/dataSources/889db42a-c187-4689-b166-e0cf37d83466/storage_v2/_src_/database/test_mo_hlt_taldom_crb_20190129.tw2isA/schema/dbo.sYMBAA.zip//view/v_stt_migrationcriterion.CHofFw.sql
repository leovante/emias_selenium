CREATE VIEW [V_stt_MigrationCriterion] AS SELECT 
[hDED].[MigrationCriterionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[hDED].[rf_ExpertKSGCriterionID] as [rf_ExpertKSGCriterionID], 
[hDED].[UGUID] as [UGUID]
FROM [stt_MigrationCriterion] as [hDED]
go

