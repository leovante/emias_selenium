CREATE VIEW [V_hlt_DiscountReasonType] AS SELECT 
[hDED].[DiscountReasonTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_DiscountReasonType] as [hDED]
go

