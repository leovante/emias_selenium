CREATE VIEW [V_oms_regs_FormView] AS SELECT 
[hDED].[regs_FormViewID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FormID] as [rf_FormID], 
[hDED].[Content] as [Content], 
[hDED].[Type] as [Type]
FROM [oms_regs_FormView] as [hDED]
go

