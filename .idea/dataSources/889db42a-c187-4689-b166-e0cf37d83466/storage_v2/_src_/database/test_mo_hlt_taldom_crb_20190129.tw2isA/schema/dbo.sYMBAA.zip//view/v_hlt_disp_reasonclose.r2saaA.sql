CREATE VIEW [V_hlt_disp_ReasonClose] AS SELECT 
[hDED].[disp_ReasonCloseID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Guid] as [Guid], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description]
FROM [hlt_disp_ReasonClose] as [hDED]
go

