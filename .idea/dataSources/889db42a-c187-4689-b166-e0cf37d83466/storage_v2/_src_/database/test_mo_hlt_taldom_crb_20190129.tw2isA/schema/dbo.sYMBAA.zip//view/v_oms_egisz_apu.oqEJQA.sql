CREATE VIEW [V_oms_Egisz_Apu] AS SELECT 
[hDED].[Egisz_ApuID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Uid] as [Uid], 
[hDED].[Name] as [Name], 
[hDED].[Region] as [Region], 
[hDED].[Address] as [Address], 
[hDED].[Ogrn] as [Ogrn], 
[hDED].[Okato] as [Okato], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_Egisz_Apu] as [hDED]
go

