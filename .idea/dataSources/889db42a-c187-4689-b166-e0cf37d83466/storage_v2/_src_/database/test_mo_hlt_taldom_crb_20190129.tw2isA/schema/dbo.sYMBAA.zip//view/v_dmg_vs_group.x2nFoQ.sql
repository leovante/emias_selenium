CREATE VIEW [V_dmg_vs_Group] AS SELECT 
[hDED].[vs_GroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_vs_OrganizationID] as [rf_vs_OrganizationID], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Code] as [Code], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [dmg_vs_Group] as [hDED]
go

