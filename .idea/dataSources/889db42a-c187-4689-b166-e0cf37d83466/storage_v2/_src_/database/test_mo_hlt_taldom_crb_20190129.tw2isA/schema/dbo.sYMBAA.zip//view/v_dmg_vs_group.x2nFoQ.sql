CREATE VIEW [V_dmg_vs_Group] AS SELECT 
[hDED].[vs_GroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_vs_OrganizatonID] as [rf_vs_OrganizatonID], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dmg_vs_Group] as [hDED]
go

