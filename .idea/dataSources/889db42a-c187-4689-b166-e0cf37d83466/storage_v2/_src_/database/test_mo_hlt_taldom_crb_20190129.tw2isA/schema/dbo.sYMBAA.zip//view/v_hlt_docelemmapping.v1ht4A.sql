CREATE VIEW [V_hlt_DocElemMapping] AS SELECT 
[hDED].[DocElemMappingID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[DocElemDefGuid] as [DocElemDefGuid], 
[hDED].[DtoField] as [DtoField]
FROM [hlt_DocElemMapping] as [hDED]
go

