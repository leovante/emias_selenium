CREATE VIEW [V_hlt_CommonReestr] AS SELECT 
[hDED].[CommonReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_CommonReestrTypeID] as [rf_CommonReestrTypeID], 
[jT_hlt_CommonReestrType].[Name] as [SILENT_rf_CommonReestrTypeID], 
[hDED].[Num] as [Num], 
[hDED].[Reestr_CreateDate] as [Reestr_CreateDate], 
[hDED].[Reestr_Begin_Date] as [Reestr_Begin_Date], 
[hDED].[Reestr_End_Date] as [Reestr_End_Date], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag]
FROM [hlt_CommonReestr] as [hDED]
INNER JOIN [hlt_CommonReestrType] as [jT_hlt_CommonReestrType] on [jT_hlt_CommonReestrType].[CommonReestrTypeID] = [hDED].[rf_CommonReestrTypeID]
go

