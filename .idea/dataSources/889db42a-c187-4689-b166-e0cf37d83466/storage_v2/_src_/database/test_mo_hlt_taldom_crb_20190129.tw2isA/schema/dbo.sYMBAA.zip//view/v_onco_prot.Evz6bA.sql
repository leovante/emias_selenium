CREATE VIEW [V_onco_PrOt] AS SELECT 
[hDED].[PrOtID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_onco_N001ID] as [rf_onco_N001ID], 
[hDED].[rf_TalonID] as [rf_TalonID], 
[hDED].[Date] as [Date], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [onco_PrOt] as [hDED]
go

