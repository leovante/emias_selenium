CREATE VIEW [V_oms_DeliveryCLSDate] AS SELECT 
[hDED].[DeliveryCLSDateID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_CLS].[V_Num] as [V_V_Num], 
[jT_oms_APU].[P_NAMES] as [V_P_NAMES], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_APUID] as [rf_APUID], 
[jT_oms_APU].[P_NAMES] as [SILENT_rf_APUID], 
[hDED].[rf_CLSID] as [rf_CLSID], 
[hDED].[rf_TenderTypeID] as [rf_TenderTypeID], 
[jT_oms_TenderType].[TenderType_Name] as [SILENT_rf_TenderTypeID], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Count] as [Count], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Note] as [Note], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[GUIDDel] as [GUIDDel]
FROM [oms_DeliveryCLSDate] as [hDED]
INNER JOIN [V_oms_CLS] as [jT_oms_CLS] on [jT_oms_CLS].[CLSID] = [hDED].[rf_CLSID]
INNER JOIN [oms_APU] as [jT_oms_APU] on [jT_oms_APU].[APUID] = [hDED].[rf_APUID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_TenderType] as [jT_oms_TenderType] on [jT_oms_TenderType].[TenderTypeID] = [hDED].[rf_TenderTypeID]
go

