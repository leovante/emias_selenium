CREATE VIEW [V_hlt_DogovorPayingType] AS SELECT 
[hDED].[DogovorPayingTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_DogovorPayingType] as [hDED]
go

