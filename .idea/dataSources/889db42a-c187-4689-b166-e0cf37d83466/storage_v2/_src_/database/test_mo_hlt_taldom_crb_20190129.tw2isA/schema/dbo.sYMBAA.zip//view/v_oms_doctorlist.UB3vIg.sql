CREATE VIEW [V_oms_DoctorList] AS SELECT 
[hDED].[DoctorListID], [hDED].[x_Edition], [hDED].[x_Status], 
(select top 1 Fam_v +' '+ IM_V + ' ' + OT_V  from oms_doctor where DoctorID = rf_DoctorID)  as [V_Doctor_FIO], 
[jT_oms_DOCTOR].[V_C_OGRN] as [V_C_OGRN], 
[jT_oms_DOCTOR].[V_DoctorCode] as [V_V_DoctorCode], 
[jT_oms_TypeDoctorList].[Code] as [Code], 
[jT_oms_DOCTOR].[PCOD] as [PCOD], 
[jT_oms_TypeDoctorList].[Name] as [V_Name], 
[hDED].[rf_DoctorID] as [rf_DoctorID], 
[hDED].[rf_TypeDoctorListID] as [rf_TypeDoctorListID], 
[hDED].[Date_BP] as [Date_BP], 
[hDED].[Date_EP] as [Date_EP], 
[hDED].[Rem] as [Rem]
FROM [oms_DoctorList] as [hDED]
INNER JOIN [V_oms_DOCTOR] as [jT_oms_DOCTOR] on [jT_oms_DOCTOR].[DOCTORID] = [hDED].[rf_DoctorID]
INNER JOIN [oms_TypeDoctorList] as [jT_oms_TypeDoctorList] on [jT_oms_TypeDoctorList].[TypeDoctorListID] = [hDED].[rf_TypeDoctorListID]
go

