CREATE VIEW [V_oms_DocumentType] AS SELECT 
[hDED].[DocumentTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[DocType_Name] as [DocType_Name]
FROM [oms_DocumentType] as [hDED]
go

