CREATE VIEW [V_oms_regs_UserDoctor] AS SELECT 
[hDED].[regs_UserDoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DOCTORID] as [rf_DOCTORID], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_UserGUID] as [rf_UserGUID]
FROM [oms_regs_UserDoctor] as [hDED]
go

