CREATE VIEW [V_oms_Egisz_Dls] AS SELECT 
[hDED].[Egisz_DlsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_Egisz_MeasurementID] as [rf_Egisz_MeasurementID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Dose] as [Dose]
FROM [oms_Egisz_Dls] as [hDED]
go

