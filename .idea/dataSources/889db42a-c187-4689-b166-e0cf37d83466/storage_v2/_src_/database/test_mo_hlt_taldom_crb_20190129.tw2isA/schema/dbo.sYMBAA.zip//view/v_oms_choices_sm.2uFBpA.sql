CREATE VIEW [V_oms_CHOICES_SM] AS SELECT 
[hDED].[CHOICES_SMID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[rem1] as [rem1], 
[hDED].[Name] as [Name], 
[hDED].[Field1] as [Field1], 
[hDED].[Field2] as [Field2], 
[hDED].[Field] as [Field], 
[hDED].[Caption] as [Caption], 
[hDED].[Rem] as [Rem]
FROM [oms_CHOICES_SM] as [hDED]
go

