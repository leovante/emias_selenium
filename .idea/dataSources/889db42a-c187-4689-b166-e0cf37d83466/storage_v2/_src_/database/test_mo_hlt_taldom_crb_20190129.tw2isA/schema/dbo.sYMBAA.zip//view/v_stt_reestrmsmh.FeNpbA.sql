CREATE VIEW [V_stt_ReestrMSMH] AS SELECT 
[hDED].[ReestrMSMHID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[jT_hlt_ReestrMH].[DateBegin] as [SILENT_rf_ReestrMHID], 
[hDED].[rf_MedServicePatientID] as [rf_MedServicePatientID], 
[jT_stt_MedServicePatient].[V_ServiceMedicalCode] as [SILENT_rf_MedServicePatientID], 
[hDED].[Num] as [Num], 
[hDED].[Flag] as [Flag]
FROM [stt_ReestrMSMH] as [hDED]
INNER JOIN [hlt_ReestrMH] as [jT_hlt_ReestrMH] on [jT_hlt_ReestrMH].[ReestrMHID] = [hDED].[rf_ReestrMHID]
INNER JOIN [V_stt_MedServicePatient] as [jT_stt_MedServicePatient] on [jT_stt_MedServicePatient].[MedServicePatientID] = [hDED].[rf_MedServicePatientID]
go

