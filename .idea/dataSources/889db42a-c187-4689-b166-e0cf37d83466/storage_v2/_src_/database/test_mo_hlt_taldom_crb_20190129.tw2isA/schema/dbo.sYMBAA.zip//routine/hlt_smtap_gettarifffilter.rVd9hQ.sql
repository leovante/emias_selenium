
-- =============================================
-- Author:		Shumer
-- Create date: 13.02.2013
-- Description:	Фильтрация тарифов амбулатории
-- =============================================
CREATE FUNCTION [dbo].[hlt_smtap_getTariffFilter] 
(
	-- Add the parameters for the function here
	@P int,					-- Признаки фильтрации
	@date_p datetime,		-- Дата оказания услуги 
	@serviceid int,			-- Мед услуга
	@tapid int,				-- ТАП
	@mkbid int,				-- Диагноз
	@departmentid int,		-- Отделение
	@lpudoctorid int,		-- Врач
	@docprvdid int,			-- Должность врача
	@mkabid int,			-- МКАБ
	@userid int				-- User
)
RETURNS varchar(4000)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result varchar(4000)
	SET @Result = '(1=1)'
	
	DECLARE @P1 INT
	DECLARE @P2 INT
	DECLARE @P3 INT
	DECLARE @P4 INT
	DECLARE @P5 INT
	DECLARE @P6 INT
	DECLARE @P7 INT
	DECLARE @P8 INT
	DECLARE @P9 INT
	DECLARE @P10 INT
	DECLARE @P11 INT
	DECLARE @P12 INT

	SET @P1  = 0x0001
	SET @P2  = 0x0002-- свободен!
	SET @P3  = 0x0004
	SET @P4  = 0x0008
	SET @P5  = 0x0010
	SET @P6  = 0x0020
	SET @P7  = 0x0040
	SET @P8  = 0x0080
	SET @P9  = 0x0100
	SET @P10 = 0x0120

	SET @P11 = 0x0400 --0000 0100 0000 0000
	SET @P12 = 0x0800 --0000 0100 0000 0000
	
/*
Всегда: I.1 Если указана услуга  - фильтровать по услуге
1 Базовый фильтр "Действует на дату оказания"

2 Фильтр по диагнозу

3 II.1 Фильтрация по договору
   tap != null И tap.rf_PolisMKABID != 0 И tap.rf_PolisMKABID_Typed.rf_DOGOVORID != 0 - фильтруем по этоку договору

III. Фильтрация по отделению
4 1. Если указано отделение - фильтровать по отделению
5 2. Если указано отделение - фильтровать по ЛПУ отделения
6 2. Если указано отделение - головному ЛПУ

7 3. Допустимы тарифы, не привязанные к отделению
8 4. Допустимы тарифы, не привязанные к ЛПУ

 -- Не реализовано
 9 IV. По  категориям ЛПУ/Отделения
 10 1. Если указано отделение, определяем действующий KRR для отделения, определяем категорию (rf_kl_CategoryID ) отделения, фильтруем тариф по 
категории
 11 - Вид оплаты ТАП
*/
	--Если указана услуга  - фильтровать по услуге - однозначно
	IF @serviceid != 0
	BEGIN
		SET	@Result = @Result + ' AND (rf_ServiceMedicalID = ' + cast(@serviceid as varchar) + ')'
		-- select * from oms_tariff where (rf_ServiceMedicalID = 0)
	END		

	-- 1 Базовый фильтр "Действует на дату оказания"
	IF @P & @P1 != 0
	BEGIN
		SET	@Result = @Result + ' AND (''' + convert(varchar,   @date_p, 126) + ''' between DATE_B and DATE_E)'
		-- select * from oms_tariff where    convert(varchar, getdate(), 126)  between DATE_B and DATE_E
	END

	-- 2 Фильтр по диагнозу. 
	IF @P & @P2 != 0
	BEGIN
		-- Когда определим стандарты лечения
		DECLARE @DS int
		
	END
	
	
	-- 3 II.1 Фильтрация по договору (при наличии)
	IF @P & @P3 != 0
	BEGIN
		IF @tapid != 0		
		BEGIN
			DECLARE @DogovorID int
			SET @DogovorID = isnull (
				(
					SELECT TOP 1 rf_DogovorID 
					FROM hlt_PolisMKAB pm
					INNER JOIN hlt_TAP tap ON tap.rf_PolisMKABID = pm.PolisMKABID
					WHERE tap.TAPID = @tapid and tap.rf_PolisMKABID != 0
				),0)

			IF @DogovorID != 0 
			BEGIN
				SET	@Result = @Result + ' AND (rf_DogovorID = ' + cast(@serviceid as varchar)  + ')'
				-- select * from oms_tariff where (rf_DogovorID = 0)
			END
		END			
	END


	IF @departmentid != 0
	BEGIN
		-- 4 1. Если указано отделение - фильтровать по отделению
		IF @P & @P4 != 0		
		BEGIN
			-- novoe
			 
			BEGIN
				DECLARE @depProfile int;
			    DECLARE @res VARCHAR(2000) 
			SET @res = '-1'
				SET @depProfile = isnull (
					(
						SELECT TOP 1 rf_kl_DepartmentProfileID
						FROM oms_Department 					
						WHERE DepartmentID = @departmentid 
					),0)
				SET	@res = @res + ', ' + cast(@depProfile as varchar)
			END
				/*	SET	@Result = @Result + ' AND (rf_kl_DepartmentProfileID in (' + @res  + ') '+ 'and '*/

			--7 3. Допустимы тарифы, не привязанные к отделению
			IF @P & @P7 != 0
			BEGIN
				SET	@Result = @Result + ' AND ((rf_DepartmentID = ' + cast(@departmentid as varchar)  + ') OR (rf_DepartmentID = 0))'
				-- select * from oms_tariff where ((rf_DepartmentID = 0) OR (rf_DepartmentID = 0))
			END
			ELSE
			BEGIN
				SET	@Result = @Result + ' AND (rf_DepartmentID = ' + cast(@departmentid as varchar)  + ')'
				-- select * from oms_tariff where (rf_DepartmentID = 0)
			END
		END		
			
			 			


		-- 5 2. Если указано отделение - фильтровать по ЛПУ отделения
		-- 6 2. Если указано отделение - головному ЛПУ
		IF (@P & @P5 != 0) OR ((@P & @P6 != 0))
		BEGIN
			DECLARE @LPUID int
			DECLARE @LPULIST varchar(100)

			SET @LPULIST = '-1'

			--8 4. Допустимы тарифы, не привязанные к ЛПУ
			IF @P & @P8 != 0
			BEGIN
				SET @LPULIST = @LPULIST + ', 0'
			END

			SET @LPUID = isnull (
				(
					SELECT TOP 1 rf_LPUID 
					FROM oms_Department 					
					WHERE DepartmentID = @departmentid 
				),0)

			IF ((@P & @P5 != 0))
			BEGIN
				SET @LPULIST = @LPULIST + ', ' + cast(@LPUID as varchar)
			END

			IF ((@P & @P6 != 0))
			BEGIN
				SET @LPUID = isnull (
					(
						SELECT l1.LPUID 
						FROM oms_lpu l1
						INNER JOIN oms_lpu l2
						ON l1.c_ogrn = l2.c_ogrn
						WHERE l2.lpuid = @LPUID and l1.stLPU = 1
					),0)
				SET @LPULIST = @LPULIST + ', ' + cast(@LPUID as varchar)
			END

			SET	@Result = @Result + ' AND (rf_LPUID in (' + @LPULIST  + '))'
			-- select * from oms_tariff where (rf_LPUID in (-1,0,1))
		END
	END

	--9 IV. По  категориям ЛПУ/Отделения	
--	IF @P & @P9 != 0
--	BEGIN	
--		
--	END

   --10 1. Если указано отделение, определяем действующий KRR для отделения, определяем категорию (rf_kl_CategoryID ) отделения,
   -- фильтруем тариф по категории
--	IF @P & @P10 != 0
--	BEGIN	
--		
--	END

	-- Фильтрация доп условие 1 - Тариф по возрасту на дату оказания услуги (value3 and value4)
	IF @P & @P12 != 0
	BEGIN
		SET @Result = @Result + ' AND ((Value4 = 0) OR (' + 	cast((SELECT  top 1 [dbo].[FullYearAge] ( (select top 1 date_bd from hlt_mkab where mkabid = @mkabid) , @date_p)) as varchar(3))+' between value3 and value4))' 
	END

		
		IF (@lpudoctorid != 0) OR (@docprvdid != 0)
	BEGIN
		 
		DECLARE @prvs int

		IF @docprvdid	!= 0
		BEGIN
			 
			SET @prvs = ISNULL((SELECT TOP 1 rf_PRVSID from hlt_DocPRVD where DocPRVDID = @docprvdid), 0)
		END
		ELSE
			 
			SET @prvs = ISNULL((SELECT TOP 1 rf_PRVSID from hlt_LPUDoctor where LPUDoctorID = @lpudoctorid), 0)
		BEGIN
		SET	@Result = @Result + ' AND (rf_PRVSID = ' + cast(@prvs as varchar)  + ') '  
		 end
		 end
		  
		
	-- Return the result of the function
	RETURN @Result

END
go

