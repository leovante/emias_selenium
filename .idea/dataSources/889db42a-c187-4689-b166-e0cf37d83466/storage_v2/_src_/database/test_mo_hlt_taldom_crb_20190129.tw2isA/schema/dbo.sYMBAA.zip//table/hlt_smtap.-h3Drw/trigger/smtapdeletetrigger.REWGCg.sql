CREATE TRIGGER SmtapDeleteTrigger ON hlt_SMTAP FOR DELETE
	AS BEGIN
	-- Триггер для запрета удаления услуги, входящей в счёт, вне ТМ:МИС (скриптом) 
	IF( dbo.GetCurrentUserID() = 0 and Exists(select 1 from deleted where rf_InvoiceID != 0) ) 
	BEGIN
	RAISERROR('Удаление услуги, входящей в счёт запрещено', 16, 1)
	ROLLBACK
	END
END
go

