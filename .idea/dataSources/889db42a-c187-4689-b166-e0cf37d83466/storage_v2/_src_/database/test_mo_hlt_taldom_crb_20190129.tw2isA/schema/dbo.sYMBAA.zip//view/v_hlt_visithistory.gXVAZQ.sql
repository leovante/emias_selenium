CREATE VIEW [V_hlt_VisitHistory] AS SELECT 
[hDED].[VisitHistoryID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_DocInfo], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_DoctorVisitTableID] as [rf_DoctorVisitTableID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[Date] as [Date], 
[hDED].[IsComplete] as [IsComplete], 
[hDED].[Flags] as [Flags], 
[hDED].[FactBeginTime] as [FactBeginTime], 
[hDED].[GUID] as [GUID], 
[hDED].[FactEndTime] as [FactEndTime], 
[hDED].[BeginTime] as [BeginTime], 
[hDED].[DateConclusion] as [DateConclusion], 
[hDED].[Conclusion] as [Conclusion]
FROM [hlt_VisitHistory] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
go

