CREATE VIEW [V_oms_TariffNorm] AS SELECT 
[hDED].[TariffNormID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_ServiceMedical].[V_ProfName] as [V_V_ProfName], 
[jT_oms_ServiceMedical].[V_TypeName] as [V_V_TypeName], 
[jT_oms_ServiceMedical].[V_UnitName] as [V_V_UnitName], 
[jT_oms_kl_AgeGroup].[Name] as [V_V_AgeName], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_kl_AgeGroupID] as [rf_kl_AgeGroupID], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_kl_MedCareTypeID] as [rf_kl_MedCareTypeID], 
[jT_oms_kl_MedCareType].[Code] as [SILENT_rf_kl_MedCareTypeID], 
[hDED].[rf_kl_MedCareUnitID] as [rf_kl_MedCareUnitID], 
[jT_oms_kl_MedCareUnit].[Code] as [SILENT_rf_kl_MedCareUnitID], 
[hDED].[rf_kl_ReasonTypeID] as [rf_kl_ReasonTypeID], 
[jT_oms_kl_ReasonType].[Name] as [SILENT_rf_kl_ReasonTypeID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[rf_kl_TariffTypeID] as [rf_kl_TariffTypeID], 
[jT_oms_kl_TariffType].[Name] as [SILENT_rf_kl_TariffTypeID], 
[hDED].[rf_kl_VisitPlaceID] as [rf_kl_VisitPlaceID], 
[jT_oms_kl_VisitPlace].[Name] as [SILENT_rf_kl_VisitPlaceID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_kl_CategoryID] as [rf_kl_CategoryID], 
[jT_oms_kl_Category].[Code] as [SILENT_rf_kl_CategoryID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[jT_oms_kl_DepartmentProfile].[Name] as [SILENT_rf_kl_DepartmentProfileID], 
[hDED].[rf_TariffTargetID] as [rf_TariffTargetID], 
[jT_oms_TariffTarget].[TariffTargetCode] as [SILENT_rf_TariffTargetID], 
[hDED].[rf_ServiceMedicalTreeID] as [rf_ServiceMedicalTreeID], 
[jT_oms_ServiceMedicalTree].[rf_ChildServiceMedicalID] as [SILENT_rf_ServiceMedicalTreeID], 
[hDED].[Value1] as [Value1], 
[hDED].[Value2] as [Value2], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Doc] as [Doc], 
[hDED].[GuidTariffNorm] as [GuidTariffNorm], 
[hDED].[Value3] as [Value3], 
[hDED].[Value4] as [Value4], 
[hDED].[Rem] as [Rem]
FROM [oms_TariffNorm] as [hDED]
INNER JOIN [V_oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_kl_AgeGroup] as [jT_oms_kl_AgeGroup] on [jT_oms_kl_AgeGroup].[kl_AgeGroupID] = [hDED].[rf_kl_AgeGroupID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_kl_MedCareType] as [jT_oms_kl_MedCareType] on [jT_oms_kl_MedCareType].[kl_MedCareTypeID] = [hDED].[rf_kl_MedCareTypeID]
INNER JOIN [oms_kl_MedCareUnit] as [jT_oms_kl_MedCareUnit] on [jT_oms_kl_MedCareUnit].[kl_MedCareUnitID] = [hDED].[rf_kl_MedCareUnitID]
INNER JOIN [oms_kl_ReasonType] as [jT_oms_kl_ReasonType] on [jT_oms_kl_ReasonType].[kl_ReasonTypeID] = [hDED].[rf_kl_ReasonTypeID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [oms_kl_TariffType] as [jT_oms_kl_TariffType] on [jT_oms_kl_TariffType].[kl_TariffTypeID] = [hDED].[rf_kl_TariffTypeID]
INNER JOIN [oms_kl_VisitPlace] as [jT_oms_kl_VisitPlace] on [jT_oms_kl_VisitPlace].[kl_VisitPlaceID] = [hDED].[rf_kl_VisitPlaceID]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [oms_kl_Category] as [jT_oms_kl_Category] on [jT_oms_kl_Category].[kl_CategoryID] = [hDED].[rf_kl_CategoryID]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
INNER JOIN [oms_TariffTarget] as [jT_oms_TariffTarget] on [jT_oms_TariffTarget].[TariffTargetID] = [hDED].[rf_TariffTargetID]
INNER JOIN [oms_ServiceMedicalTree] as [jT_oms_ServiceMedicalTree] on [jT_oms_ServiceMedicalTree].[ServiceMedicalTreeID] = [hDED].[rf_ServiceMedicalTreeID]
go

