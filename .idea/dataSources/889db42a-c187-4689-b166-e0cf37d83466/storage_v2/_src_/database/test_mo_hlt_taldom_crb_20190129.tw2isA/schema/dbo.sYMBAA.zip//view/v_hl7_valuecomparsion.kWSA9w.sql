CREATE VIEW [V_hl7_ValueComparsion] AS SELECT 
[hDED].[ValueComparsionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_CatalogValueUGUID] as [rf_CatalogValueUGUID], 
[hDED].[rf_LocalCatalogID] as [rf_LocalCatalogID], 
[hDED].[InternalCode] as [InternalCode], 
[hDED].[internalId] as [internalId]
FROM [hl7_ValueComparsion] as [hDED]
go

