CREATE VIEW [V_hlt_GroupOfBloodRH] AS SELECT 
[hDED].[GroupOfBloodRHID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[COD] as [COD], 
[hDED].[NAME] as [NAME]
FROM [hlt_GroupOfBloodRH] as [hDED]
go

