CREATE VIEW [V_hlt_disp_ResultValue] AS SELECT 
[hDED].[disp_ResultValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_ResultTypeGuid] as [rf_ResultTypeGuid], 
[jT_hlt_disp_ResultType].[Name] as [SILENT_rf_ResultTypeGuid], 
[hDED].[rf_ResultTypeValueGuid] as [rf_ResultTypeValueGuid], 
[jT_hlt_disp_ResultTypeValue].[Name] as [SILENT_rf_ResultTypeValueGuid], 
[hDED].[rf_CardGuid] as [rf_CardGuid], 
[jT_hlt_disp_Card].[rf_MkabGuid] as [SILENT_rf_CardGuid], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Value2] as [Value2], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Value1] as [Value1], 
[hDED].[DocumentId] as [DocumentId], 
[hDED].[DocTypeGuid] as [DocTypeGuid]
FROM [hlt_disp_ResultValue] as [hDED]
INNER JOIN [hlt_disp_ResultType] as [jT_hlt_disp_ResultType] on [jT_hlt_disp_ResultType].[Guid] = [hDED].[rf_ResultTypeGuid]
INNER JOIN [hlt_disp_ResultTypeValue] as [jT_hlt_disp_ResultTypeValue] on [jT_hlt_disp_ResultTypeValue].[Guid] = [hDED].[rf_ResultTypeValueGuid]
INNER JOIN [hlt_disp_Card] as [jT_hlt_disp_Card] on [jT_hlt_disp_Card].[Guid] = [hDED].[rf_CardGuid]
go

