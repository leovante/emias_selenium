CREATE VIEW [V_oms_TypeExtracted] AS SELECT 
[hDED].[TypeExtractedID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Cod] as [Cod], 
[hDED].[Name] as [Name]
FROM [oms_TypeExtracted] as [hDED]
go

