CREATE VIEW [V_oms_dent_ToothType] AS SELECT 
[hDED].[dent_ToothTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidToothType], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [oms_dent_ToothType] as [hDED]
go

