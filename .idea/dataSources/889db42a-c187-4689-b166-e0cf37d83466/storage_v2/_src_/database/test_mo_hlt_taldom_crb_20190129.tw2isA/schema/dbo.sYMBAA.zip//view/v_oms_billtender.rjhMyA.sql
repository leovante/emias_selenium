CREATE VIEW [V_oms_BillTender] AS SELECT 
[hDED].[BillTenderID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OrganisationAgentID] as [rf_OrganisationAgentID], 
[hDED].[rf_OrganisationContragentID] as [rf_OrganisationContragentID], 
[hDED].[rf_OrganisationProviderID] as [rf_OrganisationProviderID], 
[hDED].[rf_OrganisationClientID] as [rf_OrganisationClientID], 
[hDED].[rf_DocDescriptionID] as [rf_DocDescriptionID], 
[hDED].[rf_TypeDeliveryID] as [rf_TypeDeliveryID], 
[hDED].[Num] as [Num], 
[hDED].[Date] as [Date], 
[hDED].[Note] as [Note], 
[hDED].[DateDelivery] as [DateDelivery], 
[hDED].[Dogovor] as [Dogovor], 
[hDED].[FLAGS] as [FLAGS]
FROM [oms_BillTender] as [hDED]
go

