CREATE TRIGGER [LifeTrigger_oms_PharmacyRecipe] ON [oms_PharmacyRecipe] FOR DELETE,INSERT,UPDATE
AS 

SET NOCOUNT ON;

DECLARE @userId INT
DECLARE @seanceId INT 

DECLARE @docTypeId INT 
DECLARE @CURDATE DATETIME


declare @app varchar(50)
declare @index1 int
declare @index2 int


/* @userId, @seanceId */

SET @userId = 0
SET @seanceId = 0

EXEC [GetMalibuContext] @seanceId = @seanceId OUTPUT, @userId = @userId OUTPUT

/* @docTypeId */

SET @CURDATE = getdate()

SET @docTypeId = 0

SELECT TOP 1 @docTypeId = [DocTypeDefID], @seanceId=case WHEN [x_STDO].[HostID] IS NULL THEN @seanceId ELSE 0 END
FROM [x_DocTypeDef] left join [x_STDO] on [x_DocTypeDef].[GUID] = [x_STDO].[DocTypeDef] 
WHERE [HeadTable] = 'oms_PharmacyRecipe'

/* action type */

DECLARE @DEL BIT
DECLARE @INS BIT 

DECLARE @action CHAR(1)


SET @DEL = 0
SET @INS = 0


IF EXISTS (SELECT TOP 1 1 FROM DELETED) SET @DEL=1
IF EXISTS (SELECT TOP 1 1 FROM INSERTED) SET @INS = 1 

IF @INS = 1 AND @DEL = 1 SET @ACTION = 'u'
IF @INS = 1 AND @DEL = 0 SET @ACTION = 'i'
IF @INS = 0 AND @DEL = 1 SET @ACTION = 'd'


IF @ACTION = 'd'
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [PharmacyRecipeID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM deleted;

	INSERT INTO Life_oms_PharmacyRecipe([PharmacyRecipeID],[D_Type],[DATE_OTP],[DATE_VR],[DateChange],[DateExport],[DateObr],[Delayed_Service],[Description],[docMarkGuid],[DOZ_LS],[FLAGS],[GUIDList],[Hash],[KEK_State],[KO_ALL],[KV_ALL],[LPURecipeGUID],[Num_Recipe],[NumExport],[Count_ALL],[Phone],[PRICE],[RecipeGUID],[RequestMarkGuid],[rf_APUID],[rf_ARecipe_ReestrID],[rf_CLSID],[rf_DLSID],[rf_DOCTORID],[rf_FinlID],[rf_KATLID],[rf_LFID],[rf_LPUID],[rf_LSID],[rf_MKBID],[rf_MNNameID],[rf_PeriodID],[rf_PERSONDLOID],[rf_PersonID],[rf_PersonRegLGID],[rf_PR_LRID],[rf_RecipeDefinitionID],[rf_SFOID],[rf_TenderID],[rf_TRNameID],[rf_UserID],[Series_Recipe],[StatusEdition],[Sum_ALL],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [PharmacyRecipeID],[D_Type],[DATE_OTP],[DATE_VR],[DateChange],[DateExport],[DateObr],[Delayed_Service],[Description],[docMarkGuid],[DOZ_LS],[FLAGS],[GUIDList],[Hash],[KEK_State],[KO_ALL],[KV_ALL],[LPURecipeGUID],[Num_Recipe],[NumExport],[Count_ALL],[Phone],[PRICE],[RecipeGUID],[RequestMarkGuid],[rf_APUID],[rf_ARecipe_ReestrID],[rf_CLSID],[rf_DLSID],[rf_DOCTORID],[rf_FinlID],[rf_KATLID],[rf_LFID],[rf_LPUID],[rf_LSID],[rf_MKBID],[rf_MNNameID],[rf_PeriodID],[rf_PERSONDLOID],[rf_PersonID],[rf_PersonRegLGID],[rf_PR_LRID],[rf_RecipeDefinitionID],[rf_SFOID],[rf_TenderID],[rf_TRNameID],[rf_UserID],[Series_Recipe],[StatusEdition],[Sum_ALL],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM deleted;
END;
ELSE
BEGIN

	INSERT INTO [x_ObjLife] ([DocTypeDefID], [ObjID], [LastOperation], [EditionDt], [UserID], [x_Seance], [x_Edition], [x_Status]) 
		SELECT @docTypeId, [PharmacyRecipeID], @Action, @CURDATE, @userId, @seanceId, [x_Edition], [x_Status] FROM inserted;

	INSERT INTO Life_oms_PharmacyRecipe([PharmacyRecipeID],[D_Type],[DATE_OTP],[DATE_VR],[DateChange],[DateExport],[DateObr],[Delayed_Service],[Description],[docMarkGuid],[DOZ_LS],[FLAGS],[GUIDList],[Hash],[KEK_State],[KO_ALL],[KV_ALL],[LPURecipeGUID],[Num_Recipe],[NumExport],[Count_ALL],[Phone],[PRICE],[RecipeGUID],[RequestMarkGuid],[rf_APUID],[rf_ARecipe_ReestrID],[rf_CLSID],[rf_DLSID],[rf_DOCTORID],[rf_FinlID],[rf_KATLID],[rf_LFID],[rf_LPUID],[rf_LSID],[rf_MKBID],[rf_MNNameID],[rf_PeriodID],[rf_PERSONDLOID],[rf_PersonID],[rf_PersonRegLGID],[rf_PR_LRID],[rf_RecipeDefinitionID],[rf_SFOID],[rf_TenderID],[rf_TRNameID],[rf_UserID],[Series_Recipe],[StatusEdition],[Sum_ALL],[x_Edition],[x_Status],[x_Operation],[x_DateTime],[x_User],[x_Seance])
		SELECT [PharmacyRecipeID],[D_Type],[DATE_OTP],[DATE_VR],[DateChange],[DateExport],[DateObr],[Delayed_Service],[Description],[docMarkGuid],[DOZ_LS],[FLAGS],[GUIDList],[Hash],[KEK_State],[KO_ALL],[KV_ALL],[LPURecipeGUID],[Num_Recipe],[NumExport],[Count_ALL],[Phone],[PRICE],[RecipeGUID],[RequestMarkGuid],[rf_APUID],[rf_ARecipe_ReestrID],[rf_CLSID],[rf_DLSID],[rf_DOCTORID],[rf_FinlID],[rf_KATLID],[rf_LFID],[rf_LPUID],[rf_LSID],[rf_MKBID],[rf_MNNameID],[rf_PeriodID],[rf_PERSONDLOID],[rf_PersonID],[rf_PersonRegLGID],[rf_PR_LRID],[rf_RecipeDefinitionID],[rf_SFOID],[rf_TenderID],[rf_TRNameID],[rf_UserID],[Series_Recipe],[StatusEdition],[Sum_ALL],[x_Edition],[x_Status],@action,@CURDATE,@userId,@seanceId FROM inserted;
END; 

SET NOCOUNT OFF;


go

