CREATE VIEW [V_oms_Egisz_Ls] AS SELECT 
[hDED].[Egisz_LsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [oms_Egisz_Ls] as [hDED]
go

