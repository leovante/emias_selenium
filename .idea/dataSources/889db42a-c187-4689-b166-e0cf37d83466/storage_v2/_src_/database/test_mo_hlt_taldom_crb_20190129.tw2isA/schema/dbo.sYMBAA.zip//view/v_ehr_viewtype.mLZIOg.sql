CREATE VIEW [V_ehr_ViewType] AS SELECT 
[hDED].[ViewTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code]
FROM [ehr_ViewType] as [hDED]
go

