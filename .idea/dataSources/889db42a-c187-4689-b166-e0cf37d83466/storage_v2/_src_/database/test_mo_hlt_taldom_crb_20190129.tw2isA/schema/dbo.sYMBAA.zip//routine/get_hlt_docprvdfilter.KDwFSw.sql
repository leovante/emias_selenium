
create procedure [dbo].[get_hlt_DocPRVDFilter]
@rf_MKABID int, 
@rf_kl_ProfitTypeID int, 
@rf_kl_VisitPlaceID int, 
@rf_kl_ReasonTypeID int, 
@rf_kl_DDServiceID int, 
@rf_ServiceMedicalID int = 0,
@DateTAP date
as
SelecT substring(ids_Str,2,len(ids_Str))
from	(select 
			(select	',' + cast(DocPRVDID as varchar(11))
			from	--hlt_DocPRVD
			(	select	distinct rf_prvsid DocPRVDID
				from	oms_tariff 
				where	@DateTAP between date_b and date_e
						and rf_kl_ReasonTypeID = @rf_kl_ReasonTypeID
						and rf_kl_VisitPlaceID = case when (@rf_kl_VisitPlaceID = 0 or rf_kl_VisitPlaceID = 0) then rf_kl_VisitPlaceID else @rf_kl_VisitPlaceID end
						and rf_kl_DDServiceID  = case when @rf_kl_DDServiceID = 0 then rf_kl_DDServiceID else @rf_kl_DDServiceID end
						and rf_ServiceMedicalID = case when @rf_ServiceMedicalID = 0 then rf_ServiceMedicalID else @rf_ServiceMedicalID end
				)t1
			where	DocPRVDID > 0
			for xml path('') 
			) ids_Str
		) hlt_DocPRVD_IDs

go

