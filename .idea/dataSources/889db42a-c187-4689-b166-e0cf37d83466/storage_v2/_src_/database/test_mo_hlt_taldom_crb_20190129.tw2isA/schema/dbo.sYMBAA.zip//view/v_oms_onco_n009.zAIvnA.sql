CREATE VIEW [V_oms_onco_N009] AS SELECT 
[hDED].[onco_N009ID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_onco_N007ID] as [rf_onco_N007ID], 
[jT_oms_onco_N007].[Mrf_NAME] as [SILENT_rf_onco_N007ID], 
[hDED].[ID_M_D] as [ID_M_D], 
[hDED].[DS_Mrf] as [DS_Mrf], 
[hDED].[DATEBEG] as [DATEBEG], 
[hDED].[DATEEND] as [DATEEND], 
[hDED].[GUIDN009] as [GUIDN009]
FROM [oms_onco_N009] as [hDED]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_onco_N007] as [jT_oms_onco_N007] on [jT_oms_onco_N007].[onco_N007ID] = [hDED].[rf_onco_N007ID]
go

