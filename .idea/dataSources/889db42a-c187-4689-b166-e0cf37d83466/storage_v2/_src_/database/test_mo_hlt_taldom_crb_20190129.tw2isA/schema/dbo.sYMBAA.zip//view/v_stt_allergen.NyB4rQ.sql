CREATE VIEW [V_stt_Allergen] AS SELECT 
[hDED].[AllergenID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MNNameID] as [rf_MNNameID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [stt_Allergen] as [hDED]
go

