CREATE VIEW [V_hlt_disp_ResultType] AS SELECT 
[hDED].[disp_ResultTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[hDED].[rf_DispTypeGuid] as [rf_DispTypeGuid], 
[jT_hlt_disp_Type].[Name] as [SILENT_rf_DispTypeGuid], 
[hDED].[rf_ResultTypeDisplayID] as [rf_ResultTypeDisplayID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[TypeValue] as [TypeValue], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[IsMain] as [IsMain], 
[hDED].[IsShowCtrl] as [IsShowCtrl], 
[hDED].[AgeFrom] as [AgeFrom], 
[hDED].[AgeTo] as [AgeTo]
FROM [hlt_disp_ResultType] as [hDED]
INNER JOIN [hlt_disp_Type] as [jT_hlt_disp_Type] on [jT_hlt_disp_Type].[Guid] = [hDED].[rf_DispTypeGuid]
go

