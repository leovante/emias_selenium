CREATE VIEW [V_dmg_vs_Organizaton] AS SELECT 
[hDED].[vs_OrganizatonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_SocStatusID] as [rf_kl_SocStatusID], 
[hDED].[Inn] as [Inn], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dmg_vs_Organizaton] as [hDED]
go

