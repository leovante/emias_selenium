CREATE VIEW [V_stt_Fluid] AS SELECT 
[hDED].[FluidID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LSID] as [rf_LSID], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[rf_BloodGroupID] as [rf_BloodGroupID], 
[hDED].[rf_RhID] as [rf_RhID], 
[hDED].[rf_FluidTypeID] as [rf_FluidTypeID], 
[hDED].[rf_TransfusionID] as [rf_TransfusionID], 
[hDED].[Name] as [Name], 
[hDED].[StickerNum] as [StickerNum], 
[hDED].[Series] as [Series], 
[hDED].[CreateDate] as [CreateDate], 
[hDED].[DonorSurname] as [DonorSurname], 
[hDED].[capacity] as [capacity], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flags] as [flags]
FROM [stt_Fluid] as [hDED]
go

