CREATE VIEW [V_oms_SMExpertGlobal] AS SELECT 
[hDED].[SMExpertGlobalID], [hDED].[x_Edition], [hDED].[x_Status], 
((select FIO from x_User where UserId = rf_UserID)) as [V_FIOUser], 
[hDED].[rf_SMExpertTypeID] as [rf_SMExpertTypeID], 
[jT_oms_SMExpertType].[Name] as [SILENT_rf_SMExpertTypeID], 
[hDED].[rf_SMexpertStateID] as [rf_SMexpertStateID], 
[jT_oms_SMexpertState].[Code] as [SILENT_rf_SMexpertStateID], 
[hDED].[Date] as [Date], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[DateIn] as [DateIn], 
[hDED].[Description] as [Description], 
[hDED].[FileName] as [FileName], 
[hDED].[Num] as [Num]
FROM [oms_SMExpertGlobal] as [hDED]
INNER JOIN [oms_SMExpertType] as [jT_oms_SMExpertType] on [jT_oms_SMExpertType].[SMExpertTypeID] = [hDED].[rf_SMExpertTypeID]
INNER JOIN [oms_SMexpertState] as [jT_oms_SMexpertState] on [jT_oms_SMexpertState].[SMexpertStateID] = [hDED].[rf_SMexpertStateID]
go

