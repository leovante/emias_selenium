CREATE VIEW [V_oms_kl_ProfitType] AS SELECT 
[hDED].[kl_ProfitTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_kl_ProfitTypeCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_ProfitType] as [hDED]
go

