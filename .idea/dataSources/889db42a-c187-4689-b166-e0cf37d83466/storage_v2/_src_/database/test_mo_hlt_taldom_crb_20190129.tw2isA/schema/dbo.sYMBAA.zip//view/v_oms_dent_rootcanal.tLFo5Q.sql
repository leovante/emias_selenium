CREATE VIEW [V_oms_dent_RootCanal] AS SELECT 
[hDED].[dent_RootCanalID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidRootCanal], 
[hDED].[rf_dent_SectorID] as [rf_dent_SectorID], 
[jT_oms_dent_Sector].[Name] as [SILENT_rf_dent_SectorID], 
[hDED].[Name] as [Name], 
[hDED].[Symbol] as [Symbol], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [oms_dent_RootCanal] as [hDED]
INNER JOIN [oms_dent_Sector] as [jT_oms_dent_Sector] on [jT_oms_dent_Sector].[dent_SectorID] = [hDED].[rf_dent_SectorID]
go

