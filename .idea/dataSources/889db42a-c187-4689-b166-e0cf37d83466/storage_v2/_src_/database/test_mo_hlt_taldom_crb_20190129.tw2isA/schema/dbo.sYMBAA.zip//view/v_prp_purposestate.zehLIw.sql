CREATE VIEW [V_prp_PurposeState] AS SELECT 
[hDED].[PurposeStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [prp_PurposeState] as [hDED]
go

