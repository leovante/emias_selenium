CREATE VIEW [V_vcn_Status] AS SELECT 
[hDED].[StatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [vcn_Status] as [hDED]
go

