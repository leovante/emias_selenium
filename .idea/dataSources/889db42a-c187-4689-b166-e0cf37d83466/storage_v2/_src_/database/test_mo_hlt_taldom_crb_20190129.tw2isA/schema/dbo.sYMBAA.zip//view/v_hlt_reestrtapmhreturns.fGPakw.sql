CREATE VIEW [V_hlt_ReestrTAPMHReturns] AS SELECT 
[hDED].[ReestrTAPMHReturnsID], [hDED].[x_Edition], [hDED].[x_Status], 
(select top 1 [Name] from oms_ExpertType where ExpertTypeID = (select top 1 rf_ExpertTypeID from hlt_MHExpert where MHExpertID = hded.rf_MHExpertID)) as [V_ExpertType], 
[jT_oms_SMCriterion].[SMCriterionCode] as [V_SMCriterionCode], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[jT_hlt_TAP].[v_TAP] as [SILENT_rf_TAPID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[hDED].[rf_ReestrTAPMHID] as [rf_ReestrTAPMHID], 
[jT_hlt_ReestrTAPMH].[rf_TAPID] as [SILENT_rf_ReestrTAPMHID], 
[hDED].[rf_ReestrMHSMTAPID] as [rf_ReestrMHSMTAPID], 
[jT_hlt_ReestrMHSMTAP].[V_MedHelpDate] as [SILENT_rf_ReestrMHSMTAPID], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[jT_oms_SMCriterion].[SMCriterionCaption] as [SILENT_rf_SMCriterionID], 
[hDED].[rf_MHExpertID] as [rf_MHExpertID], 
[hDED].[Rem] as [Rem]
FROM [hlt_ReestrTAPMHReturns] as [hDED]
INNER JOIN [oms_SMCriterion] as [jT_oms_SMCriterion] on [jT_oms_SMCriterion].[SMCriterionID] = [hDED].[rf_SMCriterionID]
INNER JOIN [V_hlt_TAP] as [jT_hlt_TAP] on [jT_hlt_TAP].[TAPID] = [hDED].[rf_TAPID]
INNER JOIN [hlt_ReestrTAPMH] as [jT_hlt_ReestrTAPMH] on [jT_hlt_ReestrTAPMH].[ReestrTAPMHID] = [hDED].[rf_ReestrTAPMHID]
INNER JOIN [V_hlt_ReestrMHSMTAP] as [jT_hlt_ReestrMHSMTAP] on [jT_hlt_ReestrMHSMTAP].[ReestrMHSMTAPID] = [hDED].[rf_ReestrMHSMTAPID]
go

