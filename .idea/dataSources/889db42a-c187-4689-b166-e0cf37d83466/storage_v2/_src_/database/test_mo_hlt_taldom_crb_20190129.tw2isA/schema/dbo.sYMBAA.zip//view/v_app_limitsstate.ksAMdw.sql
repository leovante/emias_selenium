CREATE VIEW [V_App_LimitsState] AS SELECT 
[hDED].[LimitsStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Cod] as [Cod], 
[hDED].[State] as [State], 
[hDED].[Description] as [Description]
FROM [App_LimitsState] as [hDED]
go

