CREATE VIEW [V_oms_kl_Education] AS SELECT 
[hDED].[kl_EducationID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[GuidEducation] as [GuidEducation]
FROM [oms_kl_Education] as [hDED]
go

