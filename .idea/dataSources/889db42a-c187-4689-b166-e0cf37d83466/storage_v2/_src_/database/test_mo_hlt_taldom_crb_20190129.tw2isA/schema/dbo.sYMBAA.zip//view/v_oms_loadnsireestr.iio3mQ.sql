CREATE VIEW [V_oms_LoadNSIReestr] AS SELECT 
[hDED].[LoadNSIReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Num] as [Num], 
[hDED].[DateLoad] as [DateLoad], 
[hDED].[Rem] as [Rem], 
[hDED].[UserFIO] as [UserFIO], 
[hDED].[TP_Name] as [TP_Name], 
[hDED].[Status] as [Status]
FROM [oms_LoadNSIReestr] as [hDED]
go

