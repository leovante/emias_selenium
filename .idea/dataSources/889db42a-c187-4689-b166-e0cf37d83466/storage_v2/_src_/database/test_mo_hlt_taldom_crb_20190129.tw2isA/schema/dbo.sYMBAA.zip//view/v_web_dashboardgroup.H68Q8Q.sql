CREATE VIEW [V_web_DashboardGroup] AS SELECT 
[hDED].[DashboardGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Guid] as [Guid]
FROM [web_DashboardGroup] as [hDED]
go

