CREATE VIEW [V_oms_SMReestrB_DIAG] AS SELECT 
[hDED].[SMReestrB_DIAGID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[rf_SMReestrONK_SLID] as [rf_SMReestrONK_SLID], 
[hDED].[DIAG_TIP] as [DIAG_TIP], 
[hDED].[DIAG_CODE] as [DIAG_CODE], 
[hDED].[DIAG_RSLT] as [DIAG_RSLT], 
[hDED].[DIAG_DATE] as [DIAG_DATE], 
[hDED].[REC_RSLT] as [REC_RSLT]
FROM [oms_SMReestrB_DIAG] as [hDED]
go

