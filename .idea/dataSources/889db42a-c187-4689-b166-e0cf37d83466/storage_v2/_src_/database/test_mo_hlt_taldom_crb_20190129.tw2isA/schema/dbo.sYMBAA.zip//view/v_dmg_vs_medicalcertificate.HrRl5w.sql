CREATE VIEW [V_dmg_vs_MedicalCertificate] AS SELECT 
[hDED].[vs_MedicalCertificateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_MKB2ID] as [rf_MKB2ID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[Number] as [Number], 
[hDED].[DatePrint] as [DatePrint], 
[hDED].[IsInfectiousContact] as [IsInfectiousContact], 
[hDED].[Note] as [Note], 
[hDED].[Guid] as [Guid], 
[hDED].[Date] as [Date], 
[hDED].[Flags] as [Flags], 
[hDED].[IsDelivered] as [IsDelivered], 
[hDED].[Error] as [Error], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [dmg_vs_MedicalCertificate] as [hDED]
go

