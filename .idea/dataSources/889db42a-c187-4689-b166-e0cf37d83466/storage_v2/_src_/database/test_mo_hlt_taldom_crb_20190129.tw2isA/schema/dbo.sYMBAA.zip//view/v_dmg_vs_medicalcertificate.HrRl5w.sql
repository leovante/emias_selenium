CREATE VIEW [V_dmg_vs_MedicalCertificate] AS SELECT 
[hDED].[vs_MedicalCertificateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_MKB2ID] as [rf_MKB2ID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_kl_SocStatusID] as [rf_kl_SocStatusID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_vs_VacationTypeID] as [rf_vs_VacationTypeID], 
[hDED].[Number] as [Number], 
[hDED].[DatePrint] as [DatePrint], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[IsInfectiousContact] as [IsInfectiousContact], 
[hDED].[Note] as [Note], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dmg_vs_MedicalCertificate] as [hDED]
go

