CREATE VIEW [V_prp_PurposeLS] AS SELECT 
[hDED].[PurposeLSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LSID] as [rf_LSID], 
[jT_oms_LS].[NAME_MED] as [SILENT_rf_LSID], 
[hDED].[CodeRAS] as [CodeRAS], 
[hDED].[Flags] as [Flags], 
[hDED].[Name] as [Name]
FROM [prp_PurposeLS] as [hDED]
INNER JOIN [oms_LS] as [jT_oms_LS] on [jT_oms_LS].[LSID] = [hDED].[rf_LSID]
go

