CREATE VIEW [V_mail_MessageType] AS SELECT 
[hDED].[MessageTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName]
FROM [mail_MessageType] as [hDED]
go

