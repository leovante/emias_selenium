CREATE VIEW [V_hlt_disp_ResultTypeValue] AS SELECT 
[hDED].[disp_ResultTypeValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DispTypeGuid] as [rf_DispTypeGuid], 
[jT_hlt_disp_Type].[Name] as [SILENT_rf_DispTypeGuid], 
[hDED].[rf_ResultTypeGuid] as [rf_ResultTypeGuid], 
[jT_hlt_disp_ResultType].[Name] as [SILENT_rf_ResultTypeGuid], 
[hDED].[rf_VariantGuid] as [rf_VariantGuid], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [hlt_disp_ResultTypeValue] as [hDED]
INNER JOIN [hlt_disp_Type] as [jT_hlt_disp_Type] on [jT_hlt_disp_Type].[Guid] = [hDED].[rf_DispTypeGuid]
INNER JOIN [hlt_disp_ResultType] as [jT_hlt_disp_ResultType] on [jT_hlt_disp_ResultType].[Guid] = [hDED].[rf_ResultTypeGuid]
go

