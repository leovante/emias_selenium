CREATE VIEW [V_hlt_NotWorkDocReestr] AS SELECT 
[hDED].[NotWorkDocReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[Num] as [Num], 
[hDED].[Count] as [Count], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[DateExport] as [DateExport], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_NotWorkDocReestr] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

