 create trigger trigger_changeDate
  on hlt_doctortimetable after insert
  AS 
  update hlt_doctortimetable
  set
      Begin_Time =dateadd(DAY,datediff(day,cast(Begin_Time as date),cast([date] as date)),Begin_Time), 
      End_Time   =dateadd(DAY,datediff(day,cast(End_Time as date),cast([date] as date)),End_Time)
  where doctortimetableId in(
  select i.doctortimetableId 
  from inserted i
  where 
  (
    DATEPART(DAY,i.Begin_Time) != DATEPART(DAY,i.Date)
    or DATEPART(month,i.Begin_Time) != DATEPART(month,i.Date)
    or DATEPART(YEAR,i.Begin_Time) != DATEPART(YEAR,i.Date)
  ) and year(i.Begin_Time) > '1900'
  )


 go

