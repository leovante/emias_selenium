CREATE VIEW [V_oms_kl_Calendar] AS SELECT 
[hDED].[kl_CalendarID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[GUIDCalendar] as [GUIDCalendar], 
[hDED].[Date] as [Date], 
[hDED].[Desc] as [Desc], 
[hDED].[Rem] as [Rem], 
[hDED].[isWork] as [isWork], 
[hDED].[isWSaturday] as [isWSaturday], 
[hDED].[Flags] as [Flags]
FROM [oms_kl_Calendar] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

