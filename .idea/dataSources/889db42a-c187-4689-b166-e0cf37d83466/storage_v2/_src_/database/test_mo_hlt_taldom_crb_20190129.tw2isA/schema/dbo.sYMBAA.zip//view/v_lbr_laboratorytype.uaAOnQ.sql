CREATE VIEW [V_lbr_LaboratoryType] AS SELECT 
[hDED].[LaboratoryTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
(UGUID) as [V_LaboratoryGUID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flags] as [Flags], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [lbr_LaboratoryType] as [hDED]
go

