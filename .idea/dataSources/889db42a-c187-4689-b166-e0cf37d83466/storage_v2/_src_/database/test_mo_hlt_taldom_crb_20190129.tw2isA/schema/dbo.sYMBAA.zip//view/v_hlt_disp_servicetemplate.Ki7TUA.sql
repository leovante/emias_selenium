CREATE VIEW [V_hlt_disp_ServiceTemplate] AS SELECT 
[hDED].[disp_ServiceTemplateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_BlankTemplateGuid] as [rf_BlankTemplateGuid], 
[jT_hlt_BlankTemplate].[Caption] as [SILENT_rf_BlankTemplateGuid], 
[hDED].[rf_ServiceGuid] as [rf_ServiceGuid], 
[jT_hlt_disp_Service].[Name] as [SILENT_rf_ServiceGuid], 
[hDED].[Reserved] as [Reserved], 
[hDED].[Require] as [Require], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[TypeMr] as [TypeMr], 
[hDED].[EhrTemplateGuid] as [EhrTemplateGuid]
FROM [hlt_disp_ServiceTemplate] as [hDED]
INNER JOIN [hlt_BlankTemplate] as [jT_hlt_BlankTemplate] on [jT_hlt_BlankTemplate].[GUID] = [hDED].[rf_BlankTemplateGuid]
INNER JOIN [hlt_disp_Service] as [jT_hlt_disp_Service] on [jT_hlt_disp_Service].[Guid] = [hDED].[rf_ServiceGuid]
go

