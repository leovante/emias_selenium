CREATE VIEW [V_oms_SMRegisterAktMEE] AS SELECT 
[hDED].[SMRegisterAktMEEID], [hDED].[x_Edition], [hDED].[x_Status], 
(((((select FIO from x_User where UserId = LastUserID))))) as [V_FIOUser], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_SMExpertTypeID] as [rf_SMExpertTypeID], 
[jT_oms_SMExpertType].[Name] as [SILENT_rf_SMExpertTypeID], 
[hDED].[rf_SMRegisterMEEExpertID] as [rf_SMRegisterMEEExpertID], 
[jT_oms_SMRegisterMEEExpert].[V_FIO] as [SILENT_rf_SMRegisterMEEExpertID], 
[hDED].[LastUserID] as [LastUserID], 
[hDED].[Num] as [Num], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags], 
[hDED].[Period_B] as [Period_B], 
[hDED].[Period_E] as [Period_E]
FROM [oms_SMRegisterAktMEE] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_SMExpertType] as [jT_oms_SMExpertType] on [jT_oms_SMExpertType].[SMExpertTypeID] = [hDED].[rf_SMExpertTypeID]
INNER JOIN [V_oms_SMRegisterMEEExpert] as [jT_oms_SMRegisterMEEExpert] on [jT_oms_SMRegisterMEEExpert].[SMRegisterMEEExpertID] = [hDED].[rf_SMRegisterMEEExpertID]
go

