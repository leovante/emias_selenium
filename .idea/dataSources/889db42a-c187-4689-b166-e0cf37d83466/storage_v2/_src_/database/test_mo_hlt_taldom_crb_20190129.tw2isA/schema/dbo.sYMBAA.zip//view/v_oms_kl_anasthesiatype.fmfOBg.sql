CREATE VIEW [V_oms_kl_AnasthesiaType] AS SELECT 
[hDED].[kl_AnasthesiaTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[GUIDAnasthesiaType] as [GUIDAnasthesiaType]
FROM [oms_kl_AnasthesiaType] as [hDED]
go

