CREATE VIEW [V_stt_Reanimation] AS SELECT 
[hDED].[ReanimationID], [hDED].[x_Edition], [hDED].[x_Status], 
(((isnull((select top 1 sb.V_BranchInfo as info from stt_reanimation r
inner join dbo.stt_MigrationPatient mp ON mp.MigrationPatientID = r.rf_MigrationPatientID
inner join V_stt_stationarBranch sb on sb.stationarBranchid=mp.rf_stationarbranchID
where reanimationID=hDED.ReanimationID
order by reanimationID desc),'0')))) as [V_CurrentStationarBranchInfo], 
((isnull((select top 1 case when rf_servicemedicalid>0 
						 then ''''+V_ServiceMedicalCode+''''+' - '+  ''''+V_ServiceMedicalName+''''
						 else '' end as info from V_stt_MedServicePatient msp 
where msp.rf_ReanimationID =hDED.ReanimationID
order by MedServicePatientID desc),''))) as [V_MedServiceInfo], 
((isnull((select top 1 case when rf_servicemedicalid>0 
						 then V_DS
						 else '' end as DS from V_stt_MedServicePatient msp 
where msp.rf_ReanimationID =hDED.ReanimationID
order by MedServicePatientID desc),''))) as [V_DS], 
((isnull((select top 1 
case when mh.medcardnum != '' then 'Карта №'+mh.medcardnum+'-' else '' end +
mh.Family+' '+
case when mh.Name!='' then substring(mh.Name,0,2)+'. ' else '' end +
case when mh.Ot !='' then substring(mh.Ot,0,2)+'. ' else '' end +
convert(varchar,mh.BD,104)+'(Лет: '+convert(varchar,dbo.FullYearAge(mh.BD,mh.DateRecipientHS))+') '+
case when N_Pol != '' then 'Полис: '+S_Pol+' '+N_Pol
else '' end
 as PAT from stt_MigrationPatient mp
						 inner join stt_MedicalHistory mh on mp.rf_MedicalHistoryID = MedicalHistoryID 
where mp.MigrationPatientID  = hDED.rf_MigrationPatientID
order by MigrationPatientID desc),''))) as [V_FIO], 
[jT_stt_StationarBranch].[V_BranchInfo] as [V_StationarBranchInfo], 
[jT_stt_MigrationPatient].[rf_MedicalHistoryID] as [V_rf_MedicalHistoryID], 
[jT_stt_MigrationPatient].[rf_StationarBranchID] as [V_rf_StationarBranchID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[hDED].[rf_DiagnosID] as [rf_DiagnosID], 
[hDED].[DateIn] as [DateIn], 
[hDED].[DateOut] as [DateOut], 
[hDED].[duration] as [duration], 
[hDED].[isComplete] as [isComplete], 
[hDED].[flag] as [flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Description] as [Description]
FROM [stt_Reanimation] as [hDED]
INNER JOIN [V_stt_StationarBranch] as [jT_stt_StationarBranch] on [jT_stt_StationarBranch].[StationarBranchID] = [hDED].[rf_StationarBranchID]
INNER JOIN [stt_MigrationPatient] as [jT_stt_MigrationPatient] on [jT_stt_MigrationPatient].[MigrationPatientID] = [hDED].[rf_MigrationPatientID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
go

