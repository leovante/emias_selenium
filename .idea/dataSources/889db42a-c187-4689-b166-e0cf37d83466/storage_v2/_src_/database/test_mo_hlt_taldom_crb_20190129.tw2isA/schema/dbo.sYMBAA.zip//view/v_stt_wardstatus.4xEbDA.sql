CREATE VIEW [V_stt_WardStatus] AS SELECT 
[hDED].[WardStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E], 
[hDED].[UGUID] as [UGUID]
FROM [stt_WardStatus] as [hDED]
go

