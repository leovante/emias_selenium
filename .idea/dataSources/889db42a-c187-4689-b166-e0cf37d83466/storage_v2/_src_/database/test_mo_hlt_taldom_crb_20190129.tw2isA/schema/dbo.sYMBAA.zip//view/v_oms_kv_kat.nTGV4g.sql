CREATE VIEW [V_oms_KV_KAT] AS SELECT 
[hDED].[KV_KATID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[KV_KAT_NAME] as [KV_KAT_NAME], 
[hDED].[KVKAT] as [KVKAT]
FROM [oms_KV_KAT] as [hDED]
go

