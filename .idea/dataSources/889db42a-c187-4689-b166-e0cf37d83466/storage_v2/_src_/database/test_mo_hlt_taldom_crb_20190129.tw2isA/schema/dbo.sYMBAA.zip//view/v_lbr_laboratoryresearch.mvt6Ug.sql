CREATE VIEW [V_lbr_LaboratoryResearch] AS SELECT 
[hDED].[LaboratoryResearchID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_lbr_Laboratory].[V_DepartmentNAME] as [V_LaboratoryName], 
[jT_hlt_MKAB].[NUM] as [v_MKABNum], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_LPUSenderID] as [rf_LPUSenderID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUSenderID], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU1].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_kl_TipOMSID] as [rf_kl_TipOMSID], 
[jT_oms_kl_TipOMS].[IDDOC] as [SILENT_rf_kl_TipOMSID], 
[hDED].[rf_LaboratoryID] as [rf_LaboratoryID], 
[hDED].[rf_LabResearchCauseID] as [rf_LabResearchCauseID], 
[jT_lbr_LabResearchCause].[Name] as [SILENT_rf_LabResearchCauseID], 
[hDED].[rf_LabResearchTargetID] as [rf_LabResearchTargetID], 
[jT_lbr_LabResearchTarget].[Name] as [SILENT_rf_LabResearchTargetID], 
[hDED].[Number] as [Number], 
[hDED].[Pat_Family] as [Pat_Family], 
[hDED].[Pat_Name] as [Pat_Name], 
[hDED].[Pat_Ot] as [Pat_Ot], 
[hDED].[DOCT_FIO] as [DOCT_FIO], 
[hDED].[DOCT_PCOD] as [DOCT_PCOD], 
[hDED].[Date_Direction] as [Date_Direction], 
[hDED].[Flag] as [Flag], 
[hDED].[GUID] as [GUID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[FlagUnload] as [FlagUnload], 
[hDED].[Priority] as [Priority], 
[hDED].[Pat_Birthday] as [Pat_Birthday], 
[hDED].[Pat_W] as [Pat_W], 
[hDED].[Pat_S_POL] as [Pat_S_POL], 
[hDED].[Pat_N_POL] as [Pat_N_POL], 
[hDED].[Comment] as [Comment], 
[hDED].[isReadOnly] as [isReadOnly], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[AccessionNumber] as [AccessionNumber], 
[hDED].[DOCT_DPRVDGUID] as [DOCT_DPRVDGUID]
FROM [lbr_LaboratoryResearch] as [hDED]
INNER JOIN [V_lbr_Laboratory] as [jT_lbr_Laboratory] on [jT_lbr_Laboratory].[LaboratoryID] = [hDED].[rf_LaboratoryID]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUSenderID]
INNER JOIN [oms_LPU] as [jT_oms_LPU1] on [jT_oms_LPU1].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [oms_kl_TipOMS] as [jT_oms_kl_TipOMS] on [jT_oms_kl_TipOMS].[kl_TipOMSID] = [hDED].[rf_kl_TipOMSID]
INNER JOIN [lbr_LabResearchCause] as [jT_lbr_LabResearchCause] on [jT_lbr_LabResearchCause].[LabResearchCauseID] = [hDED].[rf_LabResearchCauseID]
INNER JOIN [lbr_LabResearchTarget] as [jT_lbr_LabResearchTarget] on [jT_lbr_LabResearchTarget].[LabResearchTargetID] = [hDED].[rf_LabResearchTargetID]
go

