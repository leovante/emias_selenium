create proc GetNumLicense 
@Serial varchar (20) output , 
@Number bigint output as 
set transaction isolation level SERIALIZABLE 
begin tran tranz1 
SET @Serial='-1' 
SET @Number=-1 
UPDATE oms_Licenses 
SET @Serial=Serial, @Number=Number, Number=Number+1 
FROM oms_Licenses (tablockx) 
WHERE LicensesID in(select top 1 LicensesID from oms_Licenses where Number<=MaxNumber) 
commit tran tranz1 
set transaction isolation level READ COMMITTED  
RETURN
go

