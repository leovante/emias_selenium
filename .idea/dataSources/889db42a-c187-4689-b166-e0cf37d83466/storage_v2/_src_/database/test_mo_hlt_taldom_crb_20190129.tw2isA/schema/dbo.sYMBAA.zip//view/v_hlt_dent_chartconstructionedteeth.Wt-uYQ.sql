CREATE VIEW [V_hlt_dent_ChartConstructionedTeeth] AS SELECT 
[hDED].[dent_ChartConstructionedTeethID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_dent_RootChartToothID] as [rf_dent_RootChartToothID], 
[jT_hlt_dent_ChartTooth].[Date] as [SILENT_rf_dent_RootChartToothID], 
[hDED].[rf_dent_ChildChartToothID] as [rf_dent_ChildChartToothID], 
[jT_hlt_dent_ChartTooth1].[Date] as [SILENT_rf_dent_ChildChartToothID], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_dent_ChartConstructionedTeeth] as [hDED]
INNER JOIN [hlt_dent_ChartTooth] as [jT_hlt_dent_ChartTooth] on [jT_hlt_dent_ChartTooth].[dent_ChartToothID] = [hDED].[rf_dent_RootChartToothID]
INNER JOIN [hlt_dent_ChartTooth] as [jT_hlt_dent_ChartTooth1] on [jT_hlt_dent_ChartTooth1].[dent_ChartToothID] = [hDED].[rf_dent_ChildChartToothID]
go

