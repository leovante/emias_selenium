CREATE VIEW [V_hlt_MedInspection] AS SELECT 
[hDED].[MedInspectionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_HealthGroupID] as [rf_HealthGroupID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[Date] as [Date], 
[hDED].[SanResort] as [SanResort]
FROM [hlt_MedInspection] as [hDED]
go

