CREATE VIEW [V_stt_NotWorkDoc] AS SELECT 
[hDED].[NotWorkDocID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_NotWorkDocStatusID] as [rf_NotWorkDocStatusID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_DisabilityCauseID] as [rf_DisabilityCauseID], 
[hDED].[DateOpen] as [DateOpen], 
[hDED].[DateClose] as [DateClose], 
[hDED].[CarePersonAge] as [CarePersonAge], 
[hDED].[CarePersonSex] as [CarePersonSex], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag]
FROM [stt_NotWorkDoc] as [hDED]
go

