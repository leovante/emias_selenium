CREATE VIEW [V_onco_TalonCons] AS SELECT 
[hDED].[TalonConsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[jT_hlt_TAP].[v_TAP] as [SILENT_rf_TAPID], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[jT_stt_MigrationPatient].[rf_StationarBranchID] as [SILENT_rf_MigrationPatientID], 
[hDED].[rf_TalonID] as [rf_TalonID], 
[jT_onco_Talon].[rf_TAPID] as [SILENT_rf_TalonID], 
[hDED].[rf_onco_N019ID] as [rf_onco_N019ID], 
[jT_oms_onco_N019].[Cons_Name] as [SILENT_rf_onco_N019ID], 
[hDED].[Description] as [Description], 
[hDED].[Date] as [Date], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [onco_TalonCons] as [hDED]
INNER JOIN [V_hlt_TAP] as [jT_hlt_TAP] on [jT_hlt_TAP].[TAPID] = [hDED].[rf_TAPID]
INNER JOIN [stt_MigrationPatient] as [jT_stt_MigrationPatient] on [jT_stt_MigrationPatient].[MigrationPatientID] = [hDED].[rf_MigrationPatientID]
INNER JOIN [onco_Talon] as [jT_onco_Talon] on [jT_onco_Talon].[TalonID] = [hDED].[rf_TalonID]
INNER JOIN [oms_onco_N019] as [jT_oms_onco_N019] on [jT_oms_onco_N019].[onco_N019ID] = [hDED].[rf_onco_N019ID]
go

