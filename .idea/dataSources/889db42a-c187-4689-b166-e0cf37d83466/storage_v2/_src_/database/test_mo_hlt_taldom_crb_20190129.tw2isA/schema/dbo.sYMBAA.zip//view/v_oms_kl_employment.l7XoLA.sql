CREATE VIEW [V_oms_kl_Employment] AS SELECT 
[hDED].[kl_EmploymentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[GuidEmployment] as [GuidEmployment]
FROM [oms_kl_Employment] as [hDED]
go

