CREATE VIEW [V_hlt_disp_TypeToDocBusyType] AS SELECT 
[hDED].[disp_TypeToDocBusyTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DocBusyTypeID] as [rf_DocBusyTypeID], 
[jT_hlt_DocBusyType].[CODE] as [SILENT_rf_DocBusyTypeID], 
[hDED].[rf_DispTypeGuid] as [rf_DispTypeGuid], 
[jT_hlt_disp_Type].[Name] as [SILENT_rf_DispTypeGuid], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_TypeToDocBusyType] as [hDED]
INNER JOIN [hlt_DocBusyType] as [jT_hlt_DocBusyType] on [jT_hlt_DocBusyType].[DocBusyTypeID] = [hDED].[rf_DocBusyTypeID]
INNER JOIN [hlt_disp_Type] as [jT_hlt_disp_Type] on [jT_hlt_disp_Type].[Guid] = [hDED].[rf_DispTypeGuid]
go

