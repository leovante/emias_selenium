CREATE VIEW [V_oms_Planmark] AS SELECT 
[hDED].[PlanmarkID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_MarkID] as [rf_MarkID], 
[jT_oms_Mark].[Code] as [SILENT_rf_MarkID], 
[hDED].[Plan] as [Plan], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_Planmark] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [oms_Mark] as [jT_oms_Mark] on [jT_oms_Mark].[MarkID] = [hDED].[rf_MarkID]
go

