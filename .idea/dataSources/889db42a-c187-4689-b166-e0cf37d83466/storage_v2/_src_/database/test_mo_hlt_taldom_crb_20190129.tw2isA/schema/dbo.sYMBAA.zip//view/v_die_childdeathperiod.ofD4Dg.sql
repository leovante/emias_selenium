CREATE VIEW [V_die_ChildDeathPeriod] AS SELECT 
[hDED].[ChildDeathPeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [die_ChildDeathPeriod] as [hDED]
go

