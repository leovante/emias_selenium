CREATE VIEW [V_stt_ProcedureDescription] AS SELECT 
[hDED].[ProcedureDescriptionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_ProcedureID] as [rf_ProcedureID], 
[jT_stt_Procedure].[Name] as [SILENT_rf_ProcedureID], 
[hDED].[Code] as [Code], 
[hDED].[Comment] as [Comment]
FROM [stt_ProcedureDescription] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [stt_Procedure] as [jT_stt_Procedure] on [jT_stt_Procedure].[ProcedureID] = [hDED].[rf_ProcedureID]
go

