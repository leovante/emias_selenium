CREATE VIEW [V_ehr_Document] AS SELECT 
[hDED].[DocumentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DocumentTypeID] as [rf_DocumentTypeID], 
[hDED].[Guid] as [Guid], 
[hDED].[BindingGuid] as [BindingGuid], 
[hDED].[Comment] as [Comment], 
[hDED].[MedicalRecordGuid] as [MedicalRecordGuid]
FROM [ehr_Document] as [hDED]
go

