CREATE VIEW [V_App_OLSSZ_POS] AS SELECT 
[hDED].[OLSSZ_POSID], [hDED].[x_Edition], [hDED].[x_Status], 
ISNULL ((SELECT TOP (1) PR_REG FROM dbo.oms_CLS AS m WHERE (rf_LSID = hDED.rf_LSID) ORDER BY DATE_BP DESC), 0.0) as [V_Price], 
ISNULL ((SELECT TOP (1) PR_REG FROM dbo.oms_CLS AS m WHERE (rf_LSID = hDED.rf_LSID) ORDER BY DATE_BP DESC), 0.0) * hDED.OrdCnt as [V_Sum], 
[jT_oms_LS].[NOMK_LS] as [NOMK_LS], 
[jT_oms_LS].[NAME_MED] as [Name_Med], 
[hDED].[rf_LSID] as [rf_LSID], 
[hDED].[rf_OLSSZID] as [rf_OLSSZID], 
[hDED].[rf_CrusialSZID] as [rf_CrusialSZID], 
[jT_App_CrusialSZ].[LPUDoctorFIO] as [SILENT_rf_CrusialSZID], 
[hDED].[OrdCnt] as [OrdCnt], 
[hDED].[Flags] as [Flags]
FROM [App_OLSSZ_POS] as [hDED]
INNER JOIN [oms_LS] as [jT_oms_LS] on [jT_oms_LS].[LSID] = [hDED].[rf_LSID]
INNER JOIN [App_CrusialSZ] as [jT_App_CrusialSZ] on [jT_App_CrusialSZ].[CrusialSZID] = [hDED].[rf_CrusialSZID]
go

