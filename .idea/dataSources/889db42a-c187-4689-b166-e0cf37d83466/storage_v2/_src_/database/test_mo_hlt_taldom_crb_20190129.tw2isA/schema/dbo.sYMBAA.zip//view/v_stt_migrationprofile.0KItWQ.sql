CREATE VIEW [V_stt_MigrationProfile] AS SELECT 
[hDED].[MigrationProfileID], [hDED].[x_Edition], [hDED].[x_Status], 
(isnull(
		(	select V_BranchInfo from stt_MigrationPatient mp
			join  v_stt_stationarBranch b on mp.rf_StationarBranchID =b.StationarBranchID
			where mp.MigrationPatientID = hDED.rf_MigrationPatientID
		)
		, '')) as [V_StationarBranch], 
[jT_stt_MigrationPatient].[DateIngoing] as [V_DateIngoing], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[hDED].[rf_BedProfileID] as [rf_BedProfileID], 
[jT_stt_BedProfile].[Name] as [SILENT_rf_BedProfileID], 
[hDED].[ProfileDate] as [ProfileDate], 
[hDED].[UGUID] as [UGUID]
FROM [stt_MigrationProfile] as [hDED]
INNER JOIN [stt_MigrationPatient] as [jT_stt_MigrationPatient] on [jT_stt_MigrationPatient].[MigrationPatientID] = [hDED].[rf_MigrationPatientID]
INNER JOIN [stt_BedProfile] as [jT_stt_BedProfile] on [jT_stt_BedProfile].[BedProfileID] = [hDED].[rf_BedProfileID]
go

