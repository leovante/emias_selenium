CREATE VIEW [V_App_OLSState] AS SELECT 
[hDED].[OLSStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Cod] as [Cod], 
[hDED].[State] as [State], 
[hDED].[Description] as [Description]
FROM [App_OLSState] as [hDED]
go

