CREATE VIEW [V_oms_PERSONDLO] AS SELECT 
[hDED].[PERSONDLOID], [hDED].[x_Edition], [hDED].[x_Status], 
((([FAM]+' '+ [IM]+' '+[OT]))) as [V_FIO], 
[hDED].[rf_OMS_OKATOID] as [rf_OMS_OKATOID], 
[hDED].[rf_REG_OKATOID] as [rf_REG_OKATOID], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_TYPEDOCID] as [rf_TYPEDOCID], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[jT_oms_KATL].[C_KATL] as [SILENT_rf_KATLID], 
[hDED].[N_POL] as [N_POL], 
[hDED].[SS_DLO] as [SS_DLO], 
[hDED].[S_POL] as [S_POL], 
[hDED].[FAM] as [FAM], 
[hDED].[IM] as [IM], 
[hDED].[OT] as [OT], 
[hDED].[W] as [W], 
[hDED].[DR] as [DR], 
[hDED].[S_DOC] as [S_DOC], 
[hDED].[N_DOC] as [N_DOC], 
[hDED].[D_TYPE] as [D_TYPE], 
[hDED].[Adress] as [Adress]
FROM [oms_PERSONDLO] as [hDED]
INNER JOIN [oms_KATL] as [jT_oms_KATL] on [jT_oms_KATL].[KATLID] = [hDED].[rf_KATLID]
go

