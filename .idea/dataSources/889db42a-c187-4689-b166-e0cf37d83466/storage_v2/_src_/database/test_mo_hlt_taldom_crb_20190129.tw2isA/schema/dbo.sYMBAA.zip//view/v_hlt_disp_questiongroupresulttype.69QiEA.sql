CREATE VIEW [V_hlt_disp_QuestionGroupResultType] AS SELECT 
[hDED].[disp_QuestionGroupResultTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResultTypeGuid] as [rf_ResultTypeGuid], 
[hDED].[rf_QuestionGroupGuid] as [rf_QuestionGroupGuid]
FROM [hlt_disp_QuestionGroupResultType] as [hDED]
go

