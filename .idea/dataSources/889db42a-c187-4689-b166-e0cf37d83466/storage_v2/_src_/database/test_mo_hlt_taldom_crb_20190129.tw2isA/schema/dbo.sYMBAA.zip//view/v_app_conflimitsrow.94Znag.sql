CREATE VIEW [V_App_ConfLimitsRow] AS SELECT 
[hDED].[ConfLimitsRowID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LSID] as [rf_LSID], 
[jT_oms_LS].[NAME_MED] as [SILENT_rf_LSID], 
[hDED].[rf_LimitsID] as [rf_LimitsID], 
[jT_App_Limits].[Rem] as [SILENT_rf_LimitsID], 
[hDED].[NOMK_LS] as [NOMK_LS], 
[hDED].[KV_ALL] as [KV_ALL]
FROM [App_ConfLimitsRow] as [hDED]
INNER JOIN [oms_LS] as [jT_oms_LS] on [jT_oms_LS].[LSID] = [hDED].[rf_LSID]
INNER JOIN [App_Limits] as [jT_App_Limits] on [jT_App_Limits].[LimitsID] = [hDED].[rf_LimitsID]
go

