CREATE VIEW [V_hlt_disp_TypeToServiceDependence] AS SELECT 
[hDED].[disp_TypeToServiceDependenceID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TypeToServiceGuid] as [rf_TypeToServiceGuid], 
[hDED].[rf_DependsOnTypeToServiceGuid] as [rf_DependsOnTypeToServiceGuid], 
[hDED].[DatePartValue] as [DatePartValue], 
[hDED].[DatePartType] as [DatePartType], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_TypeToServiceDependence] as [hDED]
go

