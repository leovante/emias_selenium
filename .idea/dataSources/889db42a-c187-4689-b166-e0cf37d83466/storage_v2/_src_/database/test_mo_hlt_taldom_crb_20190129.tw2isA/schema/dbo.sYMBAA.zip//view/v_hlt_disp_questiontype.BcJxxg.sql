CREATE VIEW [V_hlt_disp_QuestionType] AS SELECT 
[hDED].[disp_QuestionTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description]
FROM [hlt_disp_QuestionType] as [hDED]
go

