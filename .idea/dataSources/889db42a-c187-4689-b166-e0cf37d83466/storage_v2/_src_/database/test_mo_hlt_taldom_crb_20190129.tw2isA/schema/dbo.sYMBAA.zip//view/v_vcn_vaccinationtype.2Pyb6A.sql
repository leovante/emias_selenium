CREATE VIEW [V_vcn_VaccinationType] AS SELECT 
[hDED].[VaccinationTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
(Code) as [V_NextVaccinationTypeCode], 
(Code) as [V_PrevVaccinationTypeCode], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[ShortName] as [ShortName]
FROM [vcn_VaccinationType] as [hDED]
go

