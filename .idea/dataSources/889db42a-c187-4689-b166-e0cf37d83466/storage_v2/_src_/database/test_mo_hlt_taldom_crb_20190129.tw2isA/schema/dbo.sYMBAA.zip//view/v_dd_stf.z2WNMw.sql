CREATE VIEW [V_dd_STF] AS SELECT 
[hDED].[STFID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[hDED].[TF_NAME] as [TF_NAME], 
[hDED].[FAMD_RUK] as [FAMD_RUK], 
[hDED].[IMD_RUK] as [IMD_RUK], 
[hDED].[OTD_RUK] as [OTD_RUK], 
[hDED].[FAMD_R] as [FAMD_R], 
[hDED].[FAM_BUX] as [FAM_BUX], 
[hDED].[IM_BUX] as [IM_BUX], 
[hDED].[OT_BUX] as [OT_BUX], 
[hDED].[FAM_RBYX] as [FAM_RBYX], 
[hDED].[TEL] as [TEL], 
[hDED].[FAX] as [FAX], 
[hDED].[E_MAIL] as [E_MAIL], 
[hDED].[ADRES] as [ADRES], 
[hDED].[POST_IDP] as [POST_IDP], 
[hDED].[F_OGRN] as [F_OGRN], 
[hDED].[DateIn] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[F_INN] as [F_INN], 
[hDED].[F_KPP] as [F_KPP]
FROM [dd_STF] as [hDED]
go

