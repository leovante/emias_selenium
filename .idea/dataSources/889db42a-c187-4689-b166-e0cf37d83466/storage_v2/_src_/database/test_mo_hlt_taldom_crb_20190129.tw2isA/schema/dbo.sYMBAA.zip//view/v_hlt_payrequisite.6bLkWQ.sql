CREATE VIEW [V_hlt_PayRequisite] AS SELECT 
[hDED].[PayRequisiteID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKABID] as [rf_MKABID], 
[jT_hlt_MKAB].[NUM] as [SILENT_rf_MKABID], 
[hDED].[AccountNumber] as [AccountNumber], 
[hDED].[BankName] as [BankName], 
[hDED].[BankDepartment] as [BankDepartment], 
[hDED].[BIK] as [BIK], 
[hDED].[IsMain] as [IsMain], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_PayRequisite] as [hDED]
INNER JOIN [hlt_MKAB] as [jT_hlt_MKAB] on [jT_hlt_MKAB].[MKABID] = [hDED].[rf_MKABID]
go

