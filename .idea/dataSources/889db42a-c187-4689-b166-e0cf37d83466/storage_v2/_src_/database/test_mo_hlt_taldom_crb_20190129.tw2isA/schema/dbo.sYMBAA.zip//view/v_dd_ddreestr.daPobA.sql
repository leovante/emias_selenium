CREATE VIEW [V_dd_DDReestr] AS SELECT 
[hDED].[DDReestrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_STFGUID] as [rf_STFGUID], 
[hDED].[rf_DDLPUGUID] as [rf_DDLPUGUID], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[hDED].[Num] as [Num], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[FLAG] as [FLAG], 
[hDED].[UGUID] as [UGUID]
FROM [dd_DDReestr] as [hDED]
go

