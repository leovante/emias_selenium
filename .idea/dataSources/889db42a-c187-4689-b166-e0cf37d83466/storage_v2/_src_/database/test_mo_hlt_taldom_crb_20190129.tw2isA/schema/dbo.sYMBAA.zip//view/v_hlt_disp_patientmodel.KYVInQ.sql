CREATE VIEW [V_hlt_disp_PatientModel] AS SELECT 
[hDED].[disp_PatientModelID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_SocStatusID] as [rf_kl_SocStatusID], 
[jT_oms_kl_SocStatus].[Name] as [SILENT_rf_kl_SocStatusID], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[rf_DispTypeGuid] as [rf_DispTypeGuid], 
[jT_hlt_disp_Type].[Name] as [SILENT_rf_DispTypeGuid], 
[hDED].[Code] as [Code], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[AgeMin] as [AgeMin], 
[hDED].[AgeMax] as [AgeMax], 
[hDED].[AgeType] as [AgeType], 
[hDED].[SQLCase] as [SQLCase], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Name] as [Name]
FROM [hlt_disp_PatientModel] as [hDED]
INNER JOIN [oms_kl_SocStatus] as [jT_oms_kl_SocStatus] on [jT_oms_kl_SocStatus].[kl_SocStatusID] = [hDED].[rf_kl_SocStatusID]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
INNER JOIN [hlt_disp_Type] as [jT_hlt_disp_Type] on [jT_hlt_disp_Type].[Guid] = [hDED].[rf_DispTypeGuid]
go

