CREATE VIEW [V_die_DiagnosType] AS SELECT 
[hDED].[DiagnosTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[IsPerinatal] as [IsPerinatal]
FROM [die_DiagnosType] as [hDED]
go

