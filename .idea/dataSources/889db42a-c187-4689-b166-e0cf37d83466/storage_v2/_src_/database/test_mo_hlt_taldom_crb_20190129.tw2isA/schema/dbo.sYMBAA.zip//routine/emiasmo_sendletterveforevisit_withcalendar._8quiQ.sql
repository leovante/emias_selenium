
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[EMIASMO_SENDLETTERВeforeVISIT_WithCalendar] (@uguid UNIQUEIDENTIFIER, @d DATE, @testemail varchar(100))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	IF EXISTS (select 1 from rpt_remindMessage rem WITH(NOLOCK) where rem.dvtuguid = @uguid and datediff(day,rem.senddate,rem.visitDate) = datediff(day,getdate(),@d))
	RETURN

	declare  @obr varchar(200)
			,@io varchar(200)
			,@res varchar(200)
			,@KabNum varchar(200)
			,@Speciality varchar(200)
			,@DocFio varchar(200)
			,@dttdate varchar(100)
			,@Begin_Time varchar(100)
			,@lpu varchar(500)
			,@ADRES varchar(500)
			,@talon varchar(30)
			,@email varchar(200)
			,@email2 varchar(200)
			,@mkabid int = 0
			,@dvtid int = 0
			,@mcod varchar(20)
			,@date datetime
			,@uguidLpu UNIQUEIDENTIFIER
			,@dateBegin datetime
			,@dateEnd datetime
			,@dateCreate datetime
			,@dateBegin_str varchar(30)
			,@dateEnd_str varchar(30)
			,@dateCreate_str varchar(30);

	select @dvtid =		dvt.DoctorVisitTableID
		,@obr =			case when mkab.W = 1 then 'Уважаемый' else 'Уважаемая' end
		,@io=			rtrim(ltrim(dbo.InitCapFirst(mkab.NAME) + ' ' + dbo.InitCapFirst(mkab.OT)))
		,@res =			case when res.EnumName = 'Equipment' then 'Исследование' else 'Врач' end	
		,@Speciality =  case when prvs.PRVSID > 0 then prvs.PRVS_NAME else '' end
		,@KabNum =		case when room.HealingRoomID > 0 and (room.Comment!='' or room.Num!='') 
							then case when room.Num != '' then room.Num else room.Comment end
							else '' end
		,@DocFio = 		case when res.EnumName = 'Equipment' 
							then isnull(research.researchName,'')
							else case when lpudoc.LPUDoctorID > 0 then ltrim(rtrim(lpudoc.FAM_V + ' ' + lpudoc.IM_V + ' ' + lpudoc.OT_V )) 
								else '-' end
							end
		,@dttdate =		convert(varchar(30),dtt.Date,104) 
		,@Begin_Time =	case when datepart(hour,dtt.Begin_Time) = 0 then 'вне расписания' else left(convert(varchar(30),dtt.Begin_Time,108),5) end
		,@lpu =			lpu._2dr_name
		,@ADRES =		lpu.ADRES
		,@talon =		dvt.StubNum
		,@email =		mkab.contactEmail
		,@mkabid =		mkab.MKABID
		,@mcod =		lpu.Mcod
		,@date =		dateadd(minute, datepart(n, dtt.Begin_Time), dateadd(hour, datepart(hh, dtt.Begin_Time), dtt.Date)) 
		,@uguidLpu =	lpu.GUIDLPU
		,@dateBegin =	dtt.Begin_Time
		,@dateEnd =		dtt.End_Time
		,@dateCreate =	dvt.DateTimeCreate
	from hlt_DoctorVisitTable dvt WITH(NOLOCK)
		inner join hlt_MKAB mkab WITH(NOLOCK) on mkab.MKABID = dvt.rf_MKABID 
			and mkab.FAMILY != ''
			and replace(mkab.FAMILY,substring(mkab.FAMILY,1,1),'') != '' 
			and len(replace(replace(ltrim(rtrim(mkab.FAMILY))+ltrim(rtrim(mkab.NAME))+ltrim(rtrim(mkab.OT)),'-',''),'.','')) > 3			
			and dvt.UGUID = @uguid 
		inner join hlt_DoctorTimeTable dtt WITH(NOLOCK) on dtt.DoctorTimeTableID = dvt.rf_DoctorTimeTableID
			and dtt.Date > getdate()
			and datepart(hh, dtt.Begin_Time) > 0 
		inner join hlt_DocPRVD dprvd WITH(NOLOCK) on dprvd.DocPRVDID = dtt.rf_DocPRVDID
		inner join hlt_ResourceType res WITH(NOLOCK) on res.ResourceTypeID = dprvd.rf_ResourceTypeID 
		inner join hlt_LPUDoctor lpudoc WITH(NOLOCK) on lpudoc.LPUDoctorID = dprvd.rf_LPUDoctorID
				and case when res.EnumName = 'Doctor' then replace(lpudoc.FAM_V,'не известно','') else 'f' end != ''
		inner join hlt_HealingRoom room WITH(NOLOCK) on room.HealingRoomID = dprvd.rf_HealingRoomID
		--inner join oms_PRVD prvd WITH(NOLOCK) on prvd.PRVDID = dprvd.rf_PRVDID
		inner join Oms_PRVS prvs WITH(NOLOCK) on prvs.PRVSID = dprvd.rf_PRVSID
		inner join oms_Department dep WITH(NOLOCK) on dep.DepartmentID = dprvd.rf_DepartmentID
		inner join rpt_LpuInfo lpu WITH(NOLOCK) on lpu.LPUID = dep.rf_LPUID	
		--inner join hlt_Equipment eq WITH(NOLOCK) on eq.EquipmentID = dprvd.rf_EquipmentID
		--inner join hlt_EquipmentType eqt WITH(NOLOCK) on eqt.EquipmentTypeID = eq.rf_EquipmentTypeID
		outer apply (
			select top 1 isnull(rt.ResearchName,'') researchName 
			from hlt_ActionSchedule ash WITH(NOLOCK)
				inner join lbr_LaboratoryResearch lr WITH(NOLOCK) on lr.LaboratoryResearchID = ash.rf_DocTypeID
					and res.EnumName = 'Equipment'
					and ash.DocTypeDefID = (select top 1 DocTypeDefID from x_DocTypeDef WITH(NOLOCK) where HeadTable = 'lbr_LaboratoryResearch')
					and ash.rf_DoctorVisitTableID = dvt.DoctorVisitTableID
				inner join lbr_Research r WITH(NOLOCK) on r.rf_LaboratoryResearchGUID = lr.GUID  
				inner join lbr_ResearchType rt WITH(NOLOCK) on rt.UGUID = r.rf_ResearchTypeUGUID
					and rt.ResearchTypeID > 0
		)research
	order by dvt.DoctorVisitTableID desc
	

	IF isnull(@mkabid,0) = 0
	RETURN;
	

	IF (patindex('%_@_%_.__%', @email) <= 0 or (select count(1) from contactEMail_ISKL WITH(NOLOCK) where email = @email) > 0) and @testemail=''
	BEGIN
		set @email = (
			select top 1 emailp.email 
			from rpt_EmiasPatientEMail emailp WITH(NOLOCK)
				inner join hlt_MKAB mkab WITH(NOLOCK) on mkab.MKABID = @mkabid 
					and emailp.s_pol = mkab.S_POL
					and emailp.n_pol = mkab.N_POL
					and emailp.active = 1
					and emailp.date_bd = mkab.DATE_BD 
					and emailp.email != 'example@mail.ru' 
					and patindex('%_@_%_.__%',emailp.email) > 0
		)

		IF patindex('%_@_%_.__%', isnull(@email,'')) <= 0 
		RETURN 
	END



	IF @DocFio = '' or replace(@DocFio,'не известно','') = '' or @DocFio = 'не известно'
	RETURN 

	IF not exists(select * from sys.tables where name = 'contactEMail_ISKL') select convert(varchar(1000),'') as email into contactEMail_ISKL


	IF (select count(1) from contactEMail_ISKL where email = @email) > 0
	RETURN


	declare @timezoneDiff int = datediff(hh,getdate(),GETUTCDATE())
	set @dateBegin = dateadd(hh,@timezoneDiff,@dateBegin)
	set @dateEnd = dateadd(hh,@timezoneDiff,@dateEnd)
	set @dateCreate = dateadd(hh,@timezoneDiff,@dateCreate)
	set @dateBegin_str = convert(varchar(30),@dateBegin,126)
	set @dateEnd_str = convert(varchar(30),@dateEnd,126)
	set @dateCreate_str = convert(varchar(30),@dateCreate,126)

	--ПРОСТАВИТЬ АДРЕС!!!!!!!!!
	--SET @email  ='nchernova@softrust.ru'
	--SET @email  ='hmeal95@gmail.com'
	--SET @email  ='ninasvoy@inbox.ru'
	--SET @email  ='emprres@gmail.com'
	--SET @email  ='dim@softrust.ru'
	--SET @email  ='dkhvorostov@gmail.com'
	--SET @email  ='muraleksandrovna@yandex.ru'
	--SET @email  ='rulshin@softrust.ru'

	--if (@email not like '%@softrust.ru%') return

	if @testemail>'' 
		set @email =@testemail

	declare @templateid int =(select top 1 templateMessageId from rpt_templatemessage where isActual =1 and templateCod = 't_remind')
	declare @template varchar(max) = (select templateText from rpt_templatemessage where isActual =1 and templateMessageId = @templateid) --(select dbo.[EMIASMO_PrepareLetterBeforeVisit]())

	SET @template = REPLACE(@template, '__obr', @obr)
	SET @template = REPLACE(@template, '__PatIO', @io)
	SET @template = REPLACE(@template, '__VisitDate', @dttdate)
	SET @template = REPLACE(@template, '__VisitTime', @Begin_Time)
	SET @template = REPLACE(@template, '__Speciality', @Speciality)
	SET @template = REPLACE(@template, '__DocFio', @DocFio)
	SET @template = REPLACE(@template, '__LPUName', @lpu)
	SET @template = REPLACE(@template, '__ADRES', @ADRES)
	SET @template = REPLACE(@template, '__Talon', @talon)
	SET @template = REPLACE(@template, '__Resource', @res)
	SET @template = REPLACE(@template, '__KabNum', @KabNum)
	SET @template = REPLACE(@template, '__dvtGUID', cast(@uguid as varchar(50)))
	SET @template = REPLACE(@template, '__lpuGUID', cast(@uguidLpu as varchar(50)))

	IF len(@template) < 100
		RETURN
				
	--Добавляем запись
	INSERT INTO [dbo].rpt_remindMessage (
		[dvtuguid]
		,[mcod]
		,[docFIO]
		,[rf_MKABID]
		,[visitDate]
		,[email]
		,[senddate]
		,[isSend]		
		)
	SELECT @uguid
		,@mcod
		,@docFIO +' ('+@Speciality+')'
		,@mkabid
		,@date
		,@email
		,getdate()
		,1


--declare @descript varchar(500) = 'Талон № __Talon \n __Resource: __DocFio (__Speciality)\n Кабинет __KabNum\n Время: __VisitTime'
declare @descript varchar(500) = 'Талон № __Talon ; __Resource: __DocFio (__Speciality); Кабинет __KabNum; Время: __VisitTime'
	
	SET @descript = REPLACE(@descript, '__VisitTime', @Begin_Time)
	SET @descript = REPLACE(@descript, '__Speciality', @Speciality)
	SET @descript = REPLACE(@descript, '__DocFio', @DocFio)
	SET @descript = REPLACE(@descript, '__Talon', @talon)
	SET @descript = REPLACE(@descript, '__Resource', @res)
	SET @descript = REPLACE(@descript, '__KabNum', @KabNum)
	
	----Отправляем письмо
	--EXEC msdb.dbo.sp_send_dbmail @profile_name = 'test'
	--	,@recipients = @email
	--	,@subject = 'Вы записаны на приём в поликлинике. Ждём вас!'
	--	,@body_format = 'HTML'
	--	,@body = @template


declare @evid int;
--	select @@VERSION
exec sp_send_calendar_event
	   @profile_name =  'test'
	 , @recipients =  @email
	 , @from_displayName = 'Тест напоминаний'
	-- ,  @copy_recipients =  'copy_recipients [ ; ...n ]' 
	-- ,  @blind_copy_recipients =  'blind_copy_recipients [ ; ...n ]' 
	-- , @from_address =  'alert@softrust.ru' 
	-- , [ @reply_to = ] 'reply_to' ]
	 , @subject = 'Вы записаны на приём в поликлинике. Ждём вас! С календарем'
	 , @body =  @template
	 , @body_format = N'HTML'
	-- ,  @importance =  'LOW | NORMAL | HIGH' 
	-- ,  @sensitivity =  'PUBLIC | PRIVATE | CONFIDENTIAL' 
	-- ,  @file_attachments =  'file_attachments [ ; ...n ]']
	,  @location = @ADRES
	,  @start_time_utc = @dateBegin_str
	,  @end_time_utc = @dateEnd_str
	,  @timestamp_utc = @dateCreate_str
	,  @method ='PUBLISH'
	-- , [ @sequence = ] sequence ]
	-- , [ @prod_id = ] 'prod_id' ]
	,  @use_reminder =  1 
	,  @reminder_minutes = 75
	,  @require_rsvp =  1
	-- , [ @recipients_role = ] 'REQ-PARTICIPANT | OPT-PARTICIPANT | NON-PARTICIPANT | CHAIR' ]
	-- , [ @copy_recipients_role = ] 'REQ-PARTICIPANT | OPT-PARTICIPANT | NON-PARTICIPANT | CHAIR' ]
	-- , [ @blind_copy_recipients_role = ] 'REQ-PARTICIPANT | OPT-PARTICIPANT | NON-PARTICIPANT | CHAIR' ]
	 , @smtp_servername = null--get from profile 'smtp.yandex.ru' 
	 , @port = null --get from profile 587 
	 , @enable_ssl = null --get from profile 1
    -- ,  @use_default_credentials =  1 | 0 
	-- ,  @username = 'alert@softrust.ru'  --get from profile 
	 , @password = '!qweASD' 
	 , @summary = @lpu
	 , @description = @descript
	 , @filename = 'calendar'
	-- , [ @suppress_info_messages = ] 1 | 0 ]
	---- ,  @event_identifier = @evid OUTPUT
	-- , [ @ics_contents = ] 'ics_contents' [ OUTPUT ] ]
--	select @evid

	--Добавляем xml
	INSERT INTO dbo.rpt_remindMessage_xml([uguid],[message],rf_rpt_templatemessageid)
	SELECT @uguid,
	'__obr'+'='+ @obr+';'+
	'__PatIO'+'='+ @io+';'+
	'__VisitDate'+'='+ @dttdate+';'+
	'__VisitTime'+'='+ @Begin_Time+';'+
	'__Speciality'+'='+ @Speciality+';'+
	'__DocFio'+'='+ @DocFio+';'+
	'__LPUName'+'='+ @lpu+';'+
	'__ADRES'+'='+ @ADRES+';'+
	'__Talon'+'='+ @talon+';'+
	'__Resource'+'='+ @res+';'+
	'__KabNum'+'='+ @KabNum+';'+
	'__dvtGUID'+'='+ cast(@uguid as varchar(50))+
	'__lpuGUID'+'='+ cast(@uguidLpu as varchar(50))
	,@templateid
END

go

