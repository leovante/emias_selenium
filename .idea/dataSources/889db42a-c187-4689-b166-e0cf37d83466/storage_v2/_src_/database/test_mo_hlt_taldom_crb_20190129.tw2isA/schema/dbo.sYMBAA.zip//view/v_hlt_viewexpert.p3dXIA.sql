CREATE VIEW [V_hlt_ViewExpert] AS SELECT 
[hDED].[ViewExpertID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_SMO].[COD] as [V_COD], 
[jT_oms_SMCriterion].[rf_SMExpertTypeID] as [V_rf_SMExpertTypeID], 
[jT_oms_SMCriterion].[SMCriterionCode] as [V_SMCriterionCode], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[jT_hlt_ReestrMH].[DateBegin] as [SILENT_rf_ReestrMHID], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[jT_oms_SMCriterion].[SMCriterionCaption] as [SILENT_rf_SMCriterionID], 
[hDED].[rf_mainSMCriterionID] as [rf_mainSMCriterionID], 
[jT_oms_SMCriterion1].[SMCriterionCaption] as [SILENT_rf_mainSMCriterionID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[jT_hlt_ReportPeriod].[Year_Month] as [SILENT_rf_ReportPeriodID], 
[hDED].[Dep_Name] as [Dep_Name], 
[hDED].[Amb_P] as [Amb_P], 
[hDED].[Amb_U] as [Amb_U], 
[hDED].[Amb_S] as [Amb_S], 
[hDED].[Amb_Sum] as [Amb_Sum], 
[hDED].[St_P] as [St_P], 
[hDED].[St_U] as [St_U], 
[hDED].[St_S] as [St_S], 
[hDED].[St_Sum] as [St_Sum], 
[hDED].[DS_P] as [DS_P], 
[hDED].[DS_U] as [DS_U], 
[hDED].[DS_S] as [DS_S], 
[hDED].[DS_Sum] as [DS_Sum], 
[hDED].[SP_P] as [SP_P], 
[hDED].[SP_U] as [SP_U], 
[hDED].[SP_S] as [SP_S], 
[hDED].[SP_Sum] as [SP_Sum], 
[hDED].[Rem] as [Rem], 
[hDED].[Flags] as [Flags]
FROM [hlt_ViewExpert] as [hDED]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_SMCriterion] as [jT_oms_SMCriterion] on [jT_oms_SMCriterion].[SMCriterionID] = [hDED].[rf_SMCriterionID]
INNER JOIN [hlt_ReestrMH] as [jT_hlt_ReestrMH] on [jT_hlt_ReestrMH].[ReestrMHID] = [hDED].[rf_ReestrMHID]
INNER JOIN [oms_SMCriterion] as [jT_oms_SMCriterion1] on [jT_oms_SMCriterion1].[SMCriterionID] = [hDED].[rf_mainSMCriterionID]
INNER JOIN [V_hlt_ReportPeriod] as [jT_hlt_ReportPeriod] on [jT_hlt_ReportPeriod].[ReportPeriodID] = [hDED].[rf_ReportPeriodID]
go

