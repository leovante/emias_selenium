CREATE VIEW [V_emd_MedDocumentStatus] AS SELECT 
[hDED].[MedDocumentStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MedDocumentID] as [rf_MedDocumentID], 
[jT_emd_MedDocument].[RegNum] as [SILENT_rf_MedDocumentID], 
[hDED].[rf_StatusID] as [rf_StatusID], 
[jT_emd_Status].[Name] as [SILENT_rf_StatusID], 
[hDED].[DateStatus] as [DateStatus], 
[hDED].[rf_UserID] as [rf_UserID], 
[hDED].[UserInfo] as [UserInfo], 
[hDED].[Comment] as [Comment], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [emd_MedDocumentStatus] as [hDED]
INNER JOIN [emd_MedDocument] as [jT_emd_MedDocument] on [jT_emd_MedDocument].[MedDocumentID] = [hDED].[rf_MedDocumentID]
INNER JOIN [emd_Status] as [jT_emd_Status] on [jT_emd_Status].[StatusID] = [hDED].[rf_StatusID]
go

