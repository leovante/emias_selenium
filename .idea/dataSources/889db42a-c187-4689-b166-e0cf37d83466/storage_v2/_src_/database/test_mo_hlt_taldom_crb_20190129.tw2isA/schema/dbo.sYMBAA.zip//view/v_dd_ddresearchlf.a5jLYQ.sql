CREATE VIEW [V_dd_DDResearchLF] AS SELECT 
[hDED].[DDResearchLFID], [hDED].[x_Edition], [hDED].[x_Status], 
(((Select top 1 DDServiceName from dd_DDService
where dd_DDService.UGUID=rf_DDServiceGUID))) as [V_DDService], 
(((Select top 1 DDServiceName from dd_DDService
where ParamCode=0 and DDServiceTypeCode=
(Select top 1 DDServiceTypeCode from dd_DDService
where dd_DDService.UGUID=rf_DDServiceGUID))
)) as [V_DDServiceType], 
[hDED].[rf_DDFormID] as [rf_DDFormID], 
[hDED].[rf_DDFormGUID] as [rf_DDFormGUID], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[hDED].[rf_DDServiceGUID] as [rf_DDServiceGUID], 
[hDED].[rf_DDChildFormID] as [rf_DDChildFormID], 
[jT_dd_DDChildForm].[v_FIO] as [SILENT_rf_DDChildFormID], 
[hDED].[rf_CategoryServiceID] as [rf_CategoryServiceID], 
[hDED].[Value] as [Value], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[IsParaclinic] as [IsParaclinic], 
[hDED].[DDResearchLFGUID] as [DDResearchLFGUID], 
[hDED].[IsOtkaz] as [IsOtkaz], 
[hDED].[OtkazDate] as [OtkazDate], 
[hDED].[StatusRecord] as [StatusRecord], 
[hDED].[IsOtherLPU] as [IsOtherLPU], 
[hDED].[AddInfo] as [AddInfo]
FROM [dd_DDResearchLF] as [hDED]
INNER JOIN [V_dd_DDChildForm] as [jT_dd_DDChildForm] on [jT_dd_DDChildForm].[DDChildFormID] = [hDED].[rf_DDChildFormID]
go

