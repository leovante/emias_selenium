CREATE VIEW [V_dmg_vs_VacationType] AS SELECT 
[hDED].[vs_VacationTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dmg_vs_VacationType] as [hDED]
go

