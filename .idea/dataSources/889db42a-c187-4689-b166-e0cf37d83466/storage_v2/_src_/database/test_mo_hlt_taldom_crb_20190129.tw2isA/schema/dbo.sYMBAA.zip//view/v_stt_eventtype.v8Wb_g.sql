CREATE VIEW [V_stt_EventType] AS SELECT 
[hDED].[EventTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
(isNull((select Caption from x_DocTypeDef where GUID =hDED.DocTypeDefGuid),0)) as [V_TableName], 
[hDED].[DocTypeDefGuid] as [DocTypeDefGuid], 
[hDED].[Name] as [Name], 
[hDED].[flag] as [flag]
FROM [stt_EventType] as [hDED]
go

