CREATE VIEW [V_oms_SMReestrNAZ_V] AS SELECT 
[hDED].[SMReestrNAZ_VID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[NAZ_V] as [NAZ_V]
FROM [oms_SMReestrNAZ_V] as [hDED]
go

