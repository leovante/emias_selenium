CREATE VIEW [V_emd_SignRole] AS SELECT 
[hDED].[SignRoleID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [emd_SignRole] as [hDED]
go

