CREATE VIEW [V_hlt_disp_CardPlan] AS SELECT 
[hDED].[disp_CardPlanID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DOGOVORID] as [rf_DOGOVORID], 
[jT_oms_DOGOVOR].[V_Info] as [SILENT_rf_DOGOVORID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[rf_TariffID] as [rf_TariffID], 
[jT_oms_Tariff].[Value1] as [SILENT_rf_TariffID], 
[hDED].[rf_disp_CardID] as [rf_disp_CardID], 
[jT_hlt_disp_Card].[rf_MkabGuid] as [SILENT_rf_disp_CardID], 
[hDED].[StageNum] as [StageNum], 
[hDED].[DocTypeID] as [DocTypeID], 
[hDED].[DocumentID] as [DocumentID], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Date] as [Date], 
[hDED].[Count] as [Count]
FROM [hlt_disp_CardPlan] as [hDED]
INNER JOIN [V_oms_DOGOVOR] as [jT_oms_DOGOVOR] on [jT_oms_DOGOVOR].[DOGOVORID] = [hDED].[rf_DOGOVORID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
INNER JOIN [oms_Tariff] as [jT_oms_Tariff] on [jT_oms_Tariff].[TariffID] = [hDED].[rf_TariffID]
INNER JOIN [hlt_disp_Card] as [jT_hlt_disp_Card] on [jT_hlt_disp_Card].[disp_CardID] = [hDED].[rf_disp_CardID]
go

