CREATE VIEW [V_hlt_mkp_DiagnosPreg] AS SELECT 
[hDED].[mkp_DiagnosPregID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_mkp_ImpDiagnos].[Code] as [V_Code], 
[jT_hlt_mkp_ImpDiagnos].[Color] as [V_Color], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_LPUDoctorGUID] as [rf_LPUDoctorGUID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorGUID], 
[hDED].[rf_mkp_ImpDiagnosGUID] as [rf_mkp_ImpDiagnosGUID], 
[hDED].[rf_mkp_DiagnosPregTypeGUID] as [rf_mkp_DiagnosPregTypeGUID], 
[jT_hlt_mkp_DiagnosPregType].[V_Descr] as [SILENT_rf_mkp_DiagnosPregTypeGUID], 
[hDED].[rf_mkp_CardGUID] as [rf_mkp_CardGUID], 
[hDED].[rf_mkp_BornGUID] as [rf_mkp_BornGUID], 
[jT_hlt_mkp_Born].[NUM] as [SILENT_rf_mkp_BornGUID], 
[hDED].[rf_mkp_DiagnosPregSubTypeGUID] as [rf_mkp_DiagnosPregSubTypeGUID], 
[jT_hlt_mkp_DiagnosPregSubType].[V_Descr] as [SILENT_rf_mkp_DiagnosPregSubTypeGUID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DateDiagnos] as [DateDiagnos], 
[hDED].[Flags] as [Flags], 
[hDED].[AdditionalInfo] as [AdditionalInfo], 
[hDED].[IsDateDiagnos] as [IsDateDiagnos]
FROM [hlt_mkp_DiagnosPreg] as [hDED]
INNER JOIN [hlt_mkp_ImpDiagnos] as [jT_hlt_mkp_ImpDiagnos] on [jT_hlt_mkp_ImpDiagnos].[UGUID] = [hDED].[rf_mkp_ImpDiagnosGUID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[UGUID] = [hDED].[rf_LPUDoctorGUID]
INNER JOIN [V_hlt_mkp_DiagnosPregType] as [jT_hlt_mkp_DiagnosPregType] on [jT_hlt_mkp_DiagnosPregType].[UGUID] = [hDED].[rf_mkp_DiagnosPregTypeGUID]
INNER JOIN [hlt_mkp_Born] as [jT_hlt_mkp_Born] on [jT_hlt_mkp_Born].[UGUID] = [hDED].[rf_mkp_BornGUID]
INNER JOIN [V_hlt_mkp_DiagnosPregSubType] as [jT_hlt_mkp_DiagnosPregSubType] on [jT_hlt_mkp_DiagnosPregSubType].[UGUID] = [hDED].[rf_mkp_DiagnosPregSubTypeGUID]
go

