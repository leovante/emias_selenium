CREATE VIEW [V_hl7_CatalogValue] AS SELECT 
[hDED].[CatalogValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_CatalogGUID] as [rf_CatalogGUID], 
[jT_hl7_Catalog].[NameNSI] as [SILENT_rf_CatalogGUID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[CodeNSI] as [CodeNSI], 
[hDED].[OID] as [OID], 
[hDED].[NameNSI] as [NameNSI], 
[hDED].[InternalCode] as [InternalCode], 
[hDED].[InternalID] as [InternalID], 
[hDED].[Code2] as [Code2]
FROM [hl7_CatalogValue] as [hDED]
INNER JOIN [hl7_Catalog] as [jT_hl7_Catalog] on [jT_hl7_Catalog].[UGUID] = [hDED].[rf_CatalogGUID]
go

