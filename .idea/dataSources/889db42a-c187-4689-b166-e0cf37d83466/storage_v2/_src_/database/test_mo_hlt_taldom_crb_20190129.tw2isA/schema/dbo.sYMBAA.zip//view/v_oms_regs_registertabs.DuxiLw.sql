CREATE VIEW [V_oms_regs_RegisterTabs] AS SELECT 
[hDED].[regs_RegisterTabsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_regs_RegisterID] as [rf_regs_RegisterID], 
[jT_oms_regs_Register].[TypeName] as [SILENT_rf_regs_RegisterID], 
[hDED].[rf_regs_TabsID] as [rf_regs_TabsID], 
[jT_oms_regs_Tabs].[Name] as [SILENT_rf_regs_TabsID]
FROM [oms_regs_RegisterTabs] as [hDED]
INNER JOIN [oms_regs_Register] as [jT_oms_regs_Register] on [jT_oms_regs_Register].[regs_RegisterID] = [hDED].[rf_regs_RegisterID]
INNER JOIN [oms_regs_Tabs] as [jT_oms_regs_Tabs] on [jT_oms_regs_Tabs].[regs_TabsID] = [hDED].[rf_regs_TabsID]
go

