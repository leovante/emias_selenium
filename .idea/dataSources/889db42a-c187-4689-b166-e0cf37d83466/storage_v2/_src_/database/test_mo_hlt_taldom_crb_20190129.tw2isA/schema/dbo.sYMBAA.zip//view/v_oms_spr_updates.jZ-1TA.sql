CREATE VIEW [V_oms_Spr_Updates] AS SELECT 
[hDED].[Spr_UpdatesID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[SprPack_Num] as [SprPack_Num]
FROM [oms_Spr_Updates] as [hDED]
go

