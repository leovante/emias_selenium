
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[InitCapFirst]
(
	-- Add the parameters for the function here
	@str varchar(500)
)
RETURNS varchar(500)
AS
BEGIN
	-- Declare the return variable here
	if LEN(@str)>1
	set @str = UPPER(left(@str,1))+LOWER(right(@str,LEN(@str)-1))
	else set @str = UPPER(@str)

	-- Return the result of the function
	RETURN @str

END

go

