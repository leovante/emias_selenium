CREATE VIEW [V_stt_Ambulance] AS SELECT 
[hDED].[AmbulanceID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E], 
[hDED].[Flag] as [Flag], 
[hDED].[COD] as [COD]
FROM [stt_Ambulance] as [hDED]
go

