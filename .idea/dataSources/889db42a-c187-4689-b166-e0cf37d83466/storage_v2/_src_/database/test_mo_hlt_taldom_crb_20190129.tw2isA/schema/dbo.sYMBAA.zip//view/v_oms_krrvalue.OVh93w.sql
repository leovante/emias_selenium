CREATE VIEW [V_oms_KRRValue] AS SELECT 
[hDED].[KRRValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_KRRVidID] as [rf_KRRVidID], 
[jT_oms_KRRVid].[VidK_N_ame] as [SILENT_rf_KRRVidID], 
[hDED].[rf_mn_DocLPUID] as [rf_mn_DocLPUID], 
[jT_oms_mn_DocLPU].[Name] as [SILENT_rf_mn_DocLPUID], 
[hDED].[rf_DocObjID] as [rf_DocObjID], 
[hDED].[Value] as [Value], 
[hDED].[TypeEdit] as [TypeEdit], 
[hDED].[DateEdit] as [DateEdit], 
[hDED].[GuidKRRValue] as [GuidKRRValue], 
[hDED].[IsCalc] as [IsCalc]
FROM [oms_KRRValue] as [hDED]
INNER JOIN [oms_KRRVid] as [jT_oms_KRRVid] on [jT_oms_KRRVid].[KRRVidID] = [hDED].[rf_KRRVidID]
INNER JOIN [oms_mn_DocLPU] as [jT_oms_mn_DocLPU] on [jT_oms_mn_DocLPU].[mn_DocLPUID] = [hDED].[rf_mn_DocLPUID]
go

