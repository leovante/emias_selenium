CREATE VIEW [V_dd_DDErrorCode] AS SELECT 
[hDED].[DDErrorCodeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDTypeGUID] as [rf_DDTypeGUID], 
[hDED].[CODE] as [CODE], 
[hDED].[ERROR_COMMENT] as [ERROR_COMMENT], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Priority] as [Priority]
FROM [dd_DDErrorCode] as [hDED]
go

