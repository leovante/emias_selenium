CREATE VIEW [V_dmg_vs_Student] AS SELECT 
[hDED].[vs_StudentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Snils] as [Snils], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dmg_vs_Student] as [hDED]
go

