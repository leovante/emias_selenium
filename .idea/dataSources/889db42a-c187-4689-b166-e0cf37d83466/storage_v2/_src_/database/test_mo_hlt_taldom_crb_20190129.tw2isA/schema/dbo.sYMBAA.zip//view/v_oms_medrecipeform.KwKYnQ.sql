CREATE VIEW [V_oms_MedRecipeForm] AS SELECT 
[hDED].[MedRecipeFormID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Caption] as [Caption], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Code] as [Code]
FROM [oms_MedRecipeForm] as [hDED]
go

