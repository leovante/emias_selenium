CREATE VIEW [V_dmg_birth_CertificateState] AS SELECT 
[hDED].[birth_CertificateStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dmg_birth_CertificateState] as [hDED]
go

