CREATE VIEW [V_oms_SMExpVid] AS SELECT 
[hDED].[SMExpVidID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[NameExpVid] as [NameExpVid], 
[hDED].[Code] as [Code]
FROM [oms_SMExpVid] as [hDED]
go

