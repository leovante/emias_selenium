CREATE VIEW [V_stt_ReestrOccasion] AS SELECT 
[hDED].[ReestrOccasionID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_stt_MedicalHistory].[FIO] as [V_FIO], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[jT_oms_OKATO].[C_OKATO] as [SILENT_rf_OKATOID], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[jT_hlt_ReestrMH].[DateBegin] as [SILENT_rf_ReestrMHID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[jT_hlt_ReportPeriod].[Year_Month] as [SILENT_rf_ReportPeriodID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[jT_stt_MedicalHistory].[FIO] as [SILENT_rf_MedicalHistoryID], 
[hDED].[rf_MHReturnsTypeID] as [rf_MHReturnsTypeID], 
[jT_oms_MHReturnsType].[Name] as [SILENT_rf_MHReturnsTypeID], 
[hDED].[Sum_V] as [Sum_V], 
[hDED].[Sum_O] as [Sum_O], 
[hDED].[Kol_V] as [Kol_V], 
[hDED].[Kol_O] as [Kol_O], 
[hDED].[flag] as [flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Num] as [Num], 
[hDED].[NumRepPer] as [NumRepPer]
FROM [stt_ReestrOccasion] as [hDED]
INNER JOIN [V_stt_MedicalHistory] as [jT_stt_MedicalHistory] on [jT_stt_MedicalHistory].[MedicalHistoryID] = [hDED].[rf_MedicalHistoryID]
INNER JOIN [oms_OKATO] as [jT_oms_OKATO] on [jT_oms_OKATO].[OKATOID] = [hDED].[rf_OKATOID]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [hlt_ReestrMH] as [jT_hlt_ReestrMH] on [jT_hlt_ReestrMH].[ReestrMHID] = [hDED].[rf_ReestrMHID]
INNER JOIN [V_hlt_ReportPeriod] as [jT_hlt_ReportPeriod] on [jT_hlt_ReportPeriod].[ReportPeriodID] = [hDED].[rf_ReportPeriodID]
INNER JOIN [oms_MHReturnsType] as [jT_oms_MHReturnsType] on [jT_oms_MHReturnsType].[MHReturnsTypeID] = [hDED].[rf_MHReturnsTypeID]
go

