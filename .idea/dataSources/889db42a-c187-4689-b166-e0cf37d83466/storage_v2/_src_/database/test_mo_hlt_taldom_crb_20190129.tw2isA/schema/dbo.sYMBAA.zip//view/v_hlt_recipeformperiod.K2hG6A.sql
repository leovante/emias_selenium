CREATE VIEW [V_hlt_RecipeFormPeriod] AS SELECT 
[hDED].[RecipeFormPeriodID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PeriodID] as [rf_PeriodID], 
[jT_oms_Period].[Period_Length] as [SILENT_rf_PeriodID], 
[hDED].[rf_MedRecipeFormID] as [rf_MedRecipeFormID], 
[jT_oms_MedRecipeForm].[Name] as [SILENT_rf_MedRecipeFormID]
FROM [hlt_RecipeFormPeriod] as [hDED]
INNER JOIN [oms_Period] as [jT_oms_Period] on [jT_oms_Period].[PeriodID] = [hDED].[rf_PeriodID]
INNER JOIN [oms_MedRecipeForm] as [jT_oms_MedRecipeForm] on [jT_oms_MedRecipeForm].[MedRecipeFormID] = [hDED].[rf_MedRecipeFormID]
go

