CREATE VIEW [V_dd_DDInvalidity] AS SELECT 
[hDED].[DDInvalidityID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_INV].[NAME] as [V_INVNAME], 
[hDED].[rf_INVID] as [rf_INVID], 
[hDED].[DiscoveryDate] as [DiscoveryDate], 
[hDED].[LastExaminationDate] as [LastExaminationDate], 
[hDED].[Flag] as [Flag]
FROM [dd_DDInvalidity] as [hDED]
INNER JOIN [hlt_INV] as [jT_hlt_INV] on [jT_hlt_INV].[INVID] = [hDED].[rf_INVID]
go

