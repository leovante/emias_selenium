CREATE VIEW [V_hlt_HeathGroup] AS SELECT 
[hDED].[HeathGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DATEIN] as [DATEIN], 
[hDED].[DATEOUT] as [DATEOUT], 
[hDED].[DATEEDIT] as [DATEEDIT], 
[hDED].[UGUID] as [UGUID], 
[hDED].[AlterCode] as [AlterCode]
FROM [hlt_HeathGroup] as [hDED]
go

