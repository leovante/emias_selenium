CREATE VIEW [V_vcn_Vaccine] AS SELECT 
[hDED].[VaccineID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_vcn_VaccineType].[GUID] as [V_VaccineTypeGUID], 
[hDED].[rf_DLSID] as [rf_DLSID], 
[hDED].[rf_LSID] as [rf_LSID], 
[hDED].[rf_VaccineTypeID] as [rf_VaccineTypeID], 
[jT_vcn_VaccineType].[Name] as [SILENT_rf_VaccineTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Maker] as [Maker], 
[hDED].[GUID] as [GUID], 
[hDED].[Dose] as [Dose], 
[hDED].[FullName] as [FullName], 
[hDED].[National] as [National], 
[hDED].[Epidemical] as [Epidemical], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [vcn_Vaccine] as [hDED]
INNER JOIN [vcn_VaccineType] as [jT_vcn_VaccineType] on [jT_vcn_VaccineType].[VaccineTypeID] = [hDED].[rf_VaccineTypeID]
go

