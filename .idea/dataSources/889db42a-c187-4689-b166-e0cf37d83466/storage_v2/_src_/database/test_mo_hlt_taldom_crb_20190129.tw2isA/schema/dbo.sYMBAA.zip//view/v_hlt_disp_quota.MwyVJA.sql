CREATE VIEW [V_hlt_disp_Quota] AS SELECT 
[hDED].[disp_QuotaID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_disp_TypeGuid] as [rf_disp_TypeGuid], 
[jT_hlt_disp_Type].[Name] as [SILENT_rf_disp_TypeGuid], 
[hDED].[Date] as [Date], 
[hDED].[Count] as [Count], 
[hDED].[Rem] as [Rem], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_Quota] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [hlt_disp_Type] as [jT_hlt_disp_Type] on [jT_hlt_disp_Type].[Guid] = [hDED].[rf_disp_TypeGuid]
go

