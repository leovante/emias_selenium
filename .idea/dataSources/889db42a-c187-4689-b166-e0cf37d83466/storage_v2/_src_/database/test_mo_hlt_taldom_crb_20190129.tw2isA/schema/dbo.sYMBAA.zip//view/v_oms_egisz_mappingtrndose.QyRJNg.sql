CREATE VIEW [V_oms_Egisz_MappingTrnDose] AS SELECT 
[hDED].[Egisz_MappingTrnDoseID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[TrnUid] as [TrnUid], 
[hDED].[DoseUid] as [DoseUid], 
[hDED].[DoseCount] as [DoseCount]
FROM [oms_Egisz_MappingTrnDose] as [hDED]
go

