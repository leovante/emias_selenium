CREATE VIEW [V_App_FPRLS] AS SELECT 
[hDED].[FPRLSID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_LS].[NAME_MED] as [NAME_MED], 
[jT_oms_Finl].[NAME] as [FINL], 
[jT_oms_LS].[NOMK_LS] as [NOMK_LS], 
[hDED].[rf_LS] as [rf_LS], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[hDED].[rf_FRPersonID] as [rf_FRPersonID], 
[jT_App_FRPerson].[v_FIO] as [SILENT_rf_FRPersonID], 
[hDED].[DS] as [DS], 
[hDED].[Count] as [Count], 
[hDED].[NOZ_Group] as [NOZ_Group], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E], 
[hDED].[BK] as [BK], 
[hDED].[Notes] as [Notes]
FROM [App_FPRLS] as [hDED]
INNER JOIN [oms_LS] as [jT_oms_LS] on [jT_oms_LS].[LSID] = [hDED].[rf_LS]
INNER JOIN [oms_Finl] as [jT_oms_Finl] on [jT_oms_Finl].[FinlID] = [hDED].[rf_FinlID]
INNER JOIN [V_App_FRPerson] as [jT_App_FRPerson] on [jT_App_FRPerson].[FRPersonID] = [hDED].[rf_FRPersonID]
go

