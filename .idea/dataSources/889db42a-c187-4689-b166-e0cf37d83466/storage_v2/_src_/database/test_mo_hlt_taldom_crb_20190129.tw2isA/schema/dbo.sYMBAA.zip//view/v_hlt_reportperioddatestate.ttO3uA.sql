CREATE VIEW [V_hlt_ReportPeriodDateState] AS SELECT 
[hDED].[ReportPeriodDateStateID], [hDED].[x_Edition], [hDED].[x_Status], 
(select FIO from x_User where UserId = LastUserID) as [V_FIOUser], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[jT_hlt_ReestrMH].[DateBegin] as [SILENT_rf_ReestrMHID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[jT_hlt_ReportPeriod].[Year_Month] as [SILENT_rf_ReportPeriodID], 
[hDED].[rf_ReportPeriodStateID] as [rf_ReportPeriodStateID], 
[jT_hlt_ReportPeriodState].[Name] as [SILENT_rf_ReportPeriodStateID], 
[hDED].[LastUserId] as [LastUserId], 
[hDED].[Date] as [Date], 
[hDED].[Rem] as [Rem], 
[hDED].[Param] as [Param]
FROM [hlt_ReportPeriodDateState] as [hDED]
INNER JOIN [hlt_ReestrMH] as [jT_hlt_ReestrMH] on [jT_hlt_ReestrMH].[ReestrMHID] = [hDED].[rf_ReestrMHID]
INNER JOIN [V_hlt_ReportPeriod] as [jT_hlt_ReportPeriod] on [jT_hlt_ReportPeriod].[ReportPeriodID] = [hDED].[rf_ReportPeriodID]
INNER JOIN [hlt_ReportPeriodState] as [jT_hlt_ReportPeriodState] on [jT_hlt_ReportPeriodState].[ReportPeriodStateID] = [hDED].[rf_ReportPeriodStateID]
go

