CREATE VIEW [V_smp_Doctor] AS SELECT 
[hDED].[DoctorID], [hDED].[x_Edition], [hDED].[x_Status], 
((((([hDED].Surname + ' ' + [hDED].Name + ' ' + [hDED].Patronymic))  )  )
) as [V_FIO], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_LPUDoctorInfo], 
[jT_smp_Brigade].[V_BrigadeInfo] as [V_BrigadeNumber], 
[jT_smp_RoleDoctor].[Name] as [V_RoleName], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_RoleDoctorID] as [rf_RoleDoctorID], 
[hDED].[rf_BrigadeID] as [rf_BrigadeID], 
[hDED].[Surname] as [Surname], 
[hDED].[Patronymic] as [Patronymic], 
[hDED].[Name] as [Name], 
[hDED].[isDoctor] as [isDoctor], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [smp_Doctor] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [V_smp_Brigade] as [jT_smp_Brigade] on [jT_smp_Brigade].[BrigadeID] = [hDED].[rf_BrigadeID]
INNER JOIN [smp_RoleDoctor] as [jT_smp_RoleDoctor] on [jT_smp_RoleDoctor].[RoleDoctorID] = [hDED].[rf_RoleDoctorID]
go

