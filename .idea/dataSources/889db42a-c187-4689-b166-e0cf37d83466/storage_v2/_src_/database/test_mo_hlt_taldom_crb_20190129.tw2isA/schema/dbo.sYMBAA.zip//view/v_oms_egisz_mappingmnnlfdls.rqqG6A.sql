CREATE VIEW [V_oms_Egisz_MappingMnnLfDls] AS SELECT 
[hDED].[Egisz_MappingMnnLfDlsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[MnnUid] as [MnnUid], 
[hDED].[LfUid] as [LfUid], 
[hDED].[DlsUid] as [DlsUid]
FROM [oms_Egisz_MappingMnnLfDls] as [hDED]
go

