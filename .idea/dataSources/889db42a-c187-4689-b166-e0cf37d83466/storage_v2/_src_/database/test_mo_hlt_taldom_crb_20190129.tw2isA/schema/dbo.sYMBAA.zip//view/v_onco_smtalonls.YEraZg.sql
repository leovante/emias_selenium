CREATE VIEW [V_onco_smTalonLS] AS SELECT 
[hDED].[smTalonLSID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LSID] as [rf_LSID], 
[jT_oms_LS].[NAME_MED] as [SILENT_rf_LSID], 
[hDED].[rf_SmTalonID] as [rf_SmTalonID], 
[jT_onco_SmTalon].[rf_SMTAPID] as [SILENT_rf_SmTalonID], 
[hDED].[rf_onco_N020ID] as [rf_onco_N020ID], 
[jT_oms_onco_N020].[MNN] as [SILENT_rf_onco_N020ID], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Count] as [Count], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [onco_smTalonLS] as [hDED]
INNER JOIN [oms_LS] as [jT_oms_LS] on [jT_oms_LS].[LSID] = [hDED].[rf_LSID]
INNER JOIN [onco_SmTalon] as [jT_onco_SmTalon] on [jT_onco_SmTalon].[SmTalonID] = [hDED].[rf_SmTalonID]
INNER JOIN [oms_onco_N020] as [jT_oms_onco_N020] on [jT_oms_onco_N020].[onco_N020ID] = [hDED].[rf_onco_N020ID]
go

