CREATE VIEW [V_stt_TransportHost] AS SELECT 
[hDED].[TransportHostID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[HostName] as [HostName], 
[hDED].[TSAvailable] as [TSAvailable]
FROM [stt_TransportHost] as [hDED]
go

