CREATE VIEW [V_hlt_OrderInitiator] AS SELECT 
[hDED].[OrderInitiatorID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[OrderInitiator_Text] as [OrderInitiator_Text]
FROM [hlt_OrderInitiator] as [hDED]
go

