CREATE VIEW [V_oms_SMexpType] AS SELECT 
[hDED].[SMexpTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[NameExpType] as [NameExpType]
FROM [oms_SMexpType] as [hDED]
go

