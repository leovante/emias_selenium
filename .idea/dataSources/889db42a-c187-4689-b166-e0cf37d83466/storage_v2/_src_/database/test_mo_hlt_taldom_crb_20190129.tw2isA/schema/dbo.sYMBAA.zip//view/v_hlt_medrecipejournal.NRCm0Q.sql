CREATE VIEW [V_hlt_MedRecipeJournal] AS SELECT 
[hDED].[MedRecipeJournalID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LSPurposeID] as [rf_LSPurposeID], 
[jT_hlt_LSPurpose].[rf_MNNameID] as [SILENT_rf_LSPurposeID], 
[hDED].[rf_MedRecipeID] as [rf_MedRecipeID], 
[jT_hlt_MedRecipe].[DateRecipe] as [SILENT_rf_MedRecipeID], 
[hDED].[MethodName] as [MethodName], 
[hDED].[Date] as [Date], 
[hDED].[User] as [User], 
[hDED].[UseFIO] as [UseFIO], 
[hDED].[RequestXml] as [RequestXml], 
[hDED].[ResponseXml] as [ResponseXml], 
[hDED].[ErrorCode] as [ErrorCode], 
[hDED].[ErrorMessage] as [ErrorMessage], 
[hDED].[Flags] as [Flags]
FROM [hlt_MedRecipeJournal] as [hDED]
INNER JOIN [hlt_LSPurpose] as [jT_hlt_LSPurpose] on [jT_hlt_LSPurpose].[LSPurposeID] = [hDED].[rf_LSPurposeID]
INNER JOIN [hlt_MedRecipe] as [jT_hlt_MedRecipe] on [jT_hlt_MedRecipe].[MedRecipeID] = [hDED].[rf_MedRecipeID]
go

