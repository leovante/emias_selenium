CREATE VIEW [V_App_FORM_RPXZ] AS SELECT 
[hDED].[FORM_RPXZID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FORM_RPXZState] as [rf_FORM_RPXZState], 
[jT_App_FORM_RPXZState].[Name] as [SILENT_rf_FORM_RPXZState], 
[hDED].[Description] as [Description], 
[hDED].[GUID] as [GUID], 
[hDED].[DATE_IN] as [DATE_IN], 
[hDED].[DATE_OUT] as [DATE_OUT], 
[hDED].[MCOD] as [MCOD], 
[hDED].[OGRN] as [OGRN]
FROM [App_FORM_RPXZ] as [hDED]
INNER JOIN [App_FORM_RPXZState] as [jT_App_FORM_RPXZState] on [jT_App_FORM_RPXZState].[FORM_RPXZStateID] = [hDED].[rf_FORM_RPXZState]
go

