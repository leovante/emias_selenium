CREATE VIEW [V_oms_ParamVar] AS SELECT 
[hDED].[ParamVarID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ParamID] as [rf_ParamID], 
[jT_oms_Param].[Name] as [SILENT_rf_ParamID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Guid] as [Guid], 
[hDED].[Score] as [Score]
FROM [oms_ParamVar] as [hDED]
INNER JOIN [oms_Param] as [jT_oms_Param] on [jT_oms_Param].[ParamID] = [hDED].[rf_ParamID]
go

