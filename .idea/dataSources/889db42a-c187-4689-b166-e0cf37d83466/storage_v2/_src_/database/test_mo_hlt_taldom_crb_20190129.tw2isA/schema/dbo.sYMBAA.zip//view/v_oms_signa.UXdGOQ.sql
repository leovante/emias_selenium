CREATE VIEW [V_oms_Signa] AS SELECT 
[hDED].[SignaID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Signa_Text] as [Signa_Text]
FROM [oms_Signa] as [hDED]
go

