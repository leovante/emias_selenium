
CREATE procedure [dbo].[sp_selectServiceMedical]
		@str varchar(100),
		@dateSm datetime,
		@docPrvdId int, /* значение Id из hlt_DocPrvd */
		@doctorId int, /* значение Id из hlt_LpuDoctor */
		@departmentId int, 	
		@reasonTypeId int, /* цель посещения (Заболевание,Профосмотр,Патронаж,Другое), таблица oms_kl_ReasonType */	
		@mkabId int,
		@medicalHistoryId int,
		@favorite bit,
		@payTypeId int,
		@visitPlaceId int,
		@ddServiceId int,
		@medCareTypeId int,
		@result varchar(254) output--выходной параметр в случае ошибки или доп.инфо

as

begin
	set @result = ''--информационное сообщение, в случае ошибки или доп.инфо.
	set @str = '%' + ltrim(rtrim(@str)) + '%';
	
	declare @depProfileId int,
				@depTypeId int,
				@lpuId int,
				@lpuIdUL int;
		declare @prvdId int,
				@prvsId int;

		select	@depTypeId = ISNULL(rf_kl_DepartmentTypeID, 0),
				@depProfileId = ISNULL(rf_kl_DepartmentProfileID, 0), 
				@lpuIdUL = (select top 1 lpuid from oms_LPU where 
					 C_OGRN = ((select top 1 ValueStr from x_UserSettings where [Property] = 'ОГРН поликлиники' and rf_UserID = 1))  
					and stLPU = '1'),				
				@lpuId = ISNULL(rf_LPUID, 0) from oms_Department where DepartmentID = @departmentId
		/* получаем значения ИД должности и специлальности из занимаемой должности врача (hlt_DocPrvd) */
		select @prvdId = ISNULL(rf_PRVDID, 0), 
		@prvsId = ISNULL(rf_PRVSID, 0) from hlt_DocPRVD where DocPRVDID = @docPrvdId;
		--на будущее: если будет задействован @doctorId(hlt_LpuDoctor), то из hlt_LpuDoctor взять @prvdId и @prvsId


	declare @ag varchar(1) = (select case when (select dbo.FullYearAge(hltMKAB.DATE_BD, @dateSm) from hlt_MKAB hltMKAB where hltMKAB.MKABID = @mkabId) >= 18 then '1' else '2' end)
	declare @IsStomatProfile bit

	if (@favorite = 1) 
	begin
		
		SELECT top 100
			sm.[ServiceMedicalID] AS Id,
			sm.[ServiceMedicalCode]+case when len(@str)>3 and len(FCode_Usl)>2 and sm.FCode_Usl LIKE @str ESCAPE '~' 
						and (sm.FCode_Usl != sm.[ServiceMedicalCode]) then ' ('+sm.FCode_Usl+')' else '' end  AS Code,
			sm.[ServiceMedicalName] AS Name, 
			sm.[GUIDSM] AS UGuid, 
			sm.[Date_B] AS [Begin], 
			sm.[Date_E] AS [End], 
			smDepType.[kl_DepartmentTypeID] AS [DepTypeId], 
			smDepType.[Name] AS [DepTypeName], 
			smDepProfile.[kl_DepartmentProfileID] AS [DepProfileId], 
			smDepProfile.[Name] AS [DepProfileName],
			prvd.[PRVDID] AS [PrvdId], 
			prvd.[NAME] AS [PrvdName], 
			prvs.[PRVSID] AS [PrvsId], 
			prvs.[PRVS_NAME] AS [PrvsName],
			actionteeth.[kl_ActionTeethID] as ActionTeethId,
			actionteeth.[Name] as ActionTeethName,
			fr.FavoriteRecordsID AS [Favorite],						
			unit.kl_MedCareUnitID as UnitId,
			unit.CODE as UnitCode,
			unit.NAME as UnitName,
			sm.Info as Info,
			sm.IDServ as IdService--Номер записи в реестре услуг
		FROM [dbo].[oms_ServiceMedical] AS sm
				INNER JOIN [dbo].[oms_kl_MedCareUnit] as unit ON sm.rf_kl_MedCareUnitID = unit.kl_MedCareUnitID
				INNER JOIN [dbo].[oms_kl_DepartmentType] AS smDepType ON sm.[rf_kl_DepartmentTypeID] = smDepType.[kl_DepartmentTypeID]
				INNER JOIN [dbo].[oms_kl_DepartmentProfile] AS smDepProfile ON sm.[rf_kl_DepartmentProfileID] = smDepProfile.[kl_DepartmentProfileID]
				INNER JOIN [dbo].[oms_PRVS] AS prvs ON sm.[rf_PRVSID] = prvs.[PRVSID]  and (prvs.PRVSID IN (0,  @prvsId )) 
				INNER JOIN [dbo].[oms_PRVD] AS prvd ON sm.[rf_PRVDID] = prvd.[PRVDID] AND (prvd.[PRVDID] IN (0,  @prvDId  )) 
				INNER JOIN [dbo].[oms_kl_ActionTeeth] AS actionteeth ON sm.rf_kl_ActionTeethID = actionteeth.kl_ActionTeethID
				INNER JOIN [dbo].[hlt_FavoriteRecords] AS fr on sm.[ServiceMedicalID] = fr.[rf_DocID] and fr.[rf_DocTypeDefGUID] = '3426C6B4-49EB-41CA-A240-D27D4FC727BB' and fr.[rf_DocPRVDID] = @docPrvdId
		where 	( 
				EXISTS 
				(
					SELECT 1 AS [C1]
					FROM [dbo].[oms_Tariff] AS tariff
						INNER JOIN oms_Tariff tarif on sm.ServiceMedicalID=tarif.rf_ServiceMedicalID AND (tarif.[Date_B] <=  @dateSm) AND ( @dateSm  <= tarif.[Date_E])
						INNER JOIN [dbo].[oms_PRVS] AS prvs ON tarif.[rf_PRVSID] = prvs.[PRVSID]  and (prvs.PRVSID IN (0,  @prvsId )) 
						INNER JOIN [dbo].oms_kl_AgeGroup AS AgeGroup ON tarif.rf_kl_AgeGroupID = AgeGroup.kl_AgeGroupID and AgeGroup.CODE in ('0','3',@ag)
					WHERE (tariff.[rf_ServiceMedicalID] = sm.[ServiceMedicalID]) 
					--AND (tariff.[rf_kl_ReasonTypeID] IN (0,@reasonTypeId)) 
                    AND (tariff.[rf_LPUID] IN (0,@lpuId, @lpuIdUL))
				)
			) 
			and sm.ServiceMedicalID > 0
			AND (sm.[Date_E] >= @dateSm) 
			AND (sm.[Date_B] <= @dateSm) 
			AND ((sm.[ServiceMedicalName] LIKE @str ESCAPE '~') OR (sm.[ServiceMedicalCode] LIKE @str ESCAPE '~')
				 OR (len(@str)>3 and len(FCode_Usl)>2 and sm.FCode_Usl LIKE @str ESCAPE '~'))
		ORDER BY sm.[ServiceMedicalID] ASC

	end 
	else
	begin
		/* ищем услуги без признака избранные */

		
		/* основная выборка данных */
		SELECT top 100
			sm.[ServiceMedicalID] AS Id,
			sm.[ServiceMedicalCode]+case when len(@str)>3 and len(FCode_Usl)>2 and sm.FCode_Usl LIKE @str ESCAPE '~' and (sm.FCode_Usl != sm.[ServiceMedicalCode]) then ' ('+sm.FCode_Usl+')' else '' end  AS Code,
			sm.[ServiceMedicalName] AS Name, 
			sm.[GUIDSM] AS UGuid, 
			sm.[Date_B] AS [Begin], 
			sm.[Date_E] AS [End], 
			smDepType.[kl_DepartmentTypeID] AS [DepTypeId], 
			smDepType.[Name] AS [DepTypeName], 
			smDepProfile.[kl_DepartmentProfileID] AS [DepProfileId], 
			smDepProfile.[Name] AS [DepProfileName],
			prvd.[PRVDID] AS [PrvdId], 
			prvd.[NAME] AS [PrvdName], 
			prvs.[PRVSID] AS [PrvsId], 
			prvs.[PRVS_NAME] AS [PrvsName],
			actionteeth.[kl_ActionTeethID] as ActionTeethId,
			actionteeth.[Name] as ActionTeethName,			
			CASE WHEN (fr.FavoriteRecordsID IS NULL) THEN 0 ELSE fr.FavoriteRecordsID END AS [Favorite],
			unit.kl_MedCareUnitID as UnitId,
			unit.CODE as UnitCode,
			unit.NAME as UnitName,
			sm.Info as Info,
			sm.IDServ as IdService--Номер записи в реестре услуг
  		    FROM [dbo].[oms_ServiceMedical] AS sm   
			  INNER JOIN [dbo].[oms_kl_MedCareUnit] as unit ON sm.rf_kl_MedCareUnitID = unit.kl_MedCareUnitID       
			  INNER JOIN [dbo].[oms_kl_DepartmentType] AS smDepType ON sm.[rf_kl_DepartmentTypeID] = smDepType.[kl_DepartmentTypeID] and (smDepType.[kl_DepartmentTypeID] IN ( @depTypeId ))  
			  INNER JOIN [dbo].[oms_kl_DepartmentProfile] AS smDepProfile ON sm.[rf_kl_DepartmentProfileID] = smDepProfile.[kl_DepartmentProfileID]
			  INNER JOIN [dbo].[oms_PRVS] AS prvs ON sm.[rf_PRVSID] = prvs.[PRVSID]  and (prvs.PRVSID IN (0,  @prvsId )) 
			  INNER JOIN [dbo].[oms_PRVD] AS prvd ON sm.[rf_PRVDID] = prvd.[PRVDID] AND (prvd.[PRVDID] IN (0,  @prvDId  )) 
			  INNER JOIN [dbo].[oms_kl_ActionTeeth] AS actionteeth ON sm.rf_kl_ActionTeethID = actionteeth.kl_ActionTeethID
			  LEFT JOIN [dbo].[hlt_FavoriteRecords] AS fr on sm.[ServiceMedicalID] = fr.[rf_DocID] and fr.[rf_DocTypeDefGUID] = '3426C6B4-49EB-41CA-A240-D27D4FC727BB' and fr.[rf_DocPRVDID] = @docPrvdId
			WHERE 
			
			( 
				EXISTS 
				(
				SELECT 1 AS [C1]
						FROM [dbo].[oms_Tariff] AS tariff
					/*	INNER JOIN oms_Tariff tarif on sm.ServiceMedicalID=tarif.rf_ServiceMedicalID AND (tarif.[Date_B] <=  @dateSm) AND ( @dateSm  <= tarif.[Date_E])*/
								
						INNER JOIN [dbo].[oms_PRVS] AS prvs ON tariff.[rf_PRVSID] = prvs.[PRVSID]  and (prvs.PRVSID IN (0,  @prvsId )) 
						INNER JOIN [dbo].oms_kl_AgeGroup AS AgeGroup ON tariff.rf_kl_AgeGroupID = AgeGroup.kl_AgeGroupID and AgeGroup.CODE in ('0','3',@ag)
					WHERE (tariff.[rf_ServiceMedicalID] = sm.[ServiceMedicalID])  AND (tariff.[Date_B] <=  @dateSm) AND ( @dateSm  <= tariff.[Date_E])
                    AND (tariff.[rf_LPUID] IN (0,@lpuId, @lpuIdUL))
					--AND (AgeGroup.kl_AgeGroupID = 0 OR AgeGroup.CODE = '3' OR AgeGroup.CODE = case when (select dbo.FullYearAge(hltMKAB.DATE_BD, @dateSm) from hlt_MKAB hltMKAB where hltMKAB.MKABID = @mkabId) >= 18 then '1' else '2' end) 
				)
			) 
			AND (sm.[ServiceMedicalID] > 0) 
			AND (sm.[Date_E] >= @dateSm) 
			AND (sm.[Date_B] <= @dateSm) 
			AND ((sm.[ServiceMedicalName] LIKE @str ESCAPE '~')	OR (sm.[ServiceMedicalCode] LIKE @str ESCAPE '~')
			OR (len(@str)>3 and len(FCode_Usl)>2 and sm.FCode_Usl LIKE @str ESCAPE '~'))
			 
			ORDER BY sm.[ServiceMedicalID] ASC 	
	end	
end

go

