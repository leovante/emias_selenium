CREATE VIEW [V_hlt_SMTAP] AS SELECT 
[hDED].[SMTAPID], [hDED].[x_Edition], [hDED].[x_Status], 
((((((isnull((select top 1 prvs.PRVS_NAME
from hlt_DocPRVD dprvd
join oms_PRVS prvs on prvs.PRVSID = dprvd.rf_PRVSID
where dprvd.DocPRVDID = [hDED].rf_DocPRVDID), ''))))))) as [V_DocPRVS], 
([hDED].rf_TapID) as [V_TAP], 
((select top 1 isnull(mkab.FAMILY + ' ' + mkab.Name + ' ' + mkab.OT, '') from hlt_MKAB mkab
join hlt_TAP tap on tap.rf_MKABID = mkab.MKABID
where tap.TAPID = [hDED].rf_TAPID)) as [V_FIO], 
((SELECT '[' + ltrim(rtrim(PCOD)) + '] '+ Upper(substring(ltrim(FAM_V), 1, 1))+ 
CASE WHEN LEN(FAM_V) > 0  THEN LOWER(SUBSTRING(LTRIM(RTRIM(FAM_V)), 2, LEN(LTRIM(RTRIM(FAM_V))) - 1))  
ELSE '' END + ' '  + Upper(substring(ltrim(IM_V), 1, 1)) + '. ' + Upper(substring(ltrim(OT_V), 1, 1)) + '.' FROM hlt_LPUDoctor where hlt_LPUDoctor.LPUDoctorID = [hDED].rf_LPUDoctorID)) as [V_DocInfo], 
(((SELECT '[' + ltrim(rtrim(PCOD)) + '] '+ Upper(substring(ltrim(FAM_V), 1, 1))+ 
CASE WHEN LEN(FAM_V) > 0  THEN LOWER(SUBSTRING(LTRIM(RTRIM(FAM_V)), 2, LEN(LTRIM(RTRIM(FAM_V))) - 1))  
ELSE '' END + ' '  + Upper(substring(ltrim(IM_V), 1, 1)) + '. ' + Upper(substring(ltrim(OT_V), 1, 1)) + '.' FROM hlt_LPUDoctor where hlt_LPUDoctor.LPUDoctorID = [hDED].rf_LPUDoctor_SID))) as [V_DocInfo_S], 
((select date_bd from hlt_mkab m join hlt_tap t on m.MKABID = t.rf_MKABID and t.TAPID = [hDED].rf_TAPID)) as [V_DATE_BD], 
(select isnull(SUBSTRING(
(
select ', ' +((convert(varchar(2),Tooth)))
from hlt_SmTapTeeth stt 
join oms_kl_Teeth klt on klt.kl_TeethID = stt.rf_kl_TeethID
where rf_SMTAPID = [hded].SMTAPID
FOR XML PATH ('')
) , 3, 260), '')) as [V_Teeths], 
[jT_oms_ServiceMedical].[FCode_Usl] as [V_FCode_Usl], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode], 
[jT_oms_Department].[DepartmentNAME] as [V_DepartmentNAME], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[jT_oms_MKB].[DS] as [SILENT_rf_MKBID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[hDED].[rf_DoctorVisitTableID] as [rf_DoctorVisitTableID], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_LPUDoctor_SID] as [rf_LPUDoctor_SID], 
[hDED].[rf_RootSMTAPID] as [rf_RootSMTAPID], 
[jT_hlt_SMTAP].[REG_S] as [SILENT_rf_RootSMTAPID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_omsServiceMedicalID] as [rf_omsServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_omsServiceMedicalID], 
[hDED].[rf_usl_ProfitTypeID] as [rf_usl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_usl_ProfitTypeID], 
[hDED].[rf_kl_VisitPlaceID] as [rf_kl_VisitPlaceID], 
[jT_oms_kl_VisitPlace].[Name] as [SILENT_rf_kl_VisitPlaceID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[jT_oms_Department].[DepartmentCODE] as [SILENT_rf_DepartmentID], 
[hDED].[rf_TariffID] as [rf_TariffID], 
[jT_oms_Tariff].[Value1] as [SILENT_rf_TariffID], 
[hDED].[rf_InvoiceID] as [rf_InvoiceID], 
[hDED].[rf_BillServiceID] as [rf_BillServiceID], 
[hDED].[rf_OperationID] as [rf_OperationID], 
[hDED].[rf_kl_TeethID] as [rf_kl_TeethID], 
[jT_oms_kl_Teeth].[V_Name] as [SILENT_rf_kl_TeethID], 
[hDED].[rf_kl_ActionTeethID] as [rf_kl_ActionTeethID], 
[jT_oms_kl_ActionTeeth].[Name] as [SILENT_rf_kl_ActionTeethID], 
[hDED].[REG_S] as [REG_S], 
[hDED].[SMTAPGuid] as [SMTAPGuid], 
[hDED].[IsFake] as [IsFake], 
[hDED].[Count] as [Count], 
[hDED].[DATE_P] as [DATE_P], 
[hDED].[FLAGS] as [FLAGS], 
[hDED].[Description] as [Description], 
[hDED].[FlagPay] as [FlagPay], 
[hDED].[FlagComplete] as [FlagComplete], 
[hDED].[FlagStatist] as [FlagStatist], 
[hDED].[FlagBill] as [FlagBill], 
[hDED].[rf_CreateUserID] as [rf_CreateUserID], 
[hDED].[rf_EditUserID] as [rf_EditUserID], 
[hDED].[Sum_V] as [Sum_V], 
[hDED].[Sum_Opl] as [Sum_Opl], 
[hDED].[CreateUserName] as [CreateUserName], 
[hDED].[EditUserName] as [EditUserName], 
[hDED].[DATE_E] as [DATE_E], 
[hDED].[DateWarranty] as [DateWarranty], 
[hDED].[IsFailWarranty] as [IsFailWarranty]
FROM [hlt_SMTAP] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_omsServiceMedicalID]
INNER JOIN [oms_Department] as [jT_oms_Department] on [jT_oms_Department].[DepartmentID] = [hDED].[rf_DepartmentID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [hlt_SMTAP] as [jT_hlt_SMTAP] on [jT_hlt_SMTAP].[SMTAPID] = [hDED].[rf_RootSMTAPID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_usl_ProfitTypeID]
INNER JOIN [oms_kl_VisitPlace] as [jT_oms_kl_VisitPlace] on [jT_oms_kl_VisitPlace].[kl_VisitPlaceID] = [hDED].[rf_kl_VisitPlaceID]
INNER JOIN [oms_Tariff] as [jT_oms_Tariff] on [jT_oms_Tariff].[TariffID] = [hDED].[rf_TariffID]
INNER JOIN [V_oms_kl_Teeth] as [jT_oms_kl_Teeth] on [jT_oms_kl_Teeth].[kl_TeethID] = [hDED].[rf_kl_TeethID]
INNER JOIN [oms_kl_ActionTeeth] as [jT_oms_kl_ActionTeeth] on [jT_oms_kl_ActionTeeth].[kl_ActionTeethID] = [hDED].[rf_kl_ActionTeethID]
go

