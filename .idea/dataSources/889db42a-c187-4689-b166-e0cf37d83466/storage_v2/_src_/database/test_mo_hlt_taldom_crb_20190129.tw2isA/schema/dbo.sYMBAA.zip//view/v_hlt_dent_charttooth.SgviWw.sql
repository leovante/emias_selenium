CREATE VIEW [V_hlt_dent_ChartTooth] AS SELECT 
[hDED].[dent_ChartToothID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_disp_ExamID] as [rf_disp_ExamID], 
[jT_hlt_disp_Exam].[rf_ServiceGuid] as [SILENT_rf_disp_ExamID], 
[hDED].[rf_dent_ToothID] as [rf_dent_ToothID], 
[jT_oms_dent_Tooth].[Number] as [SILENT_rf_dent_ToothID], 
[hDED].[Date] as [Date], 
[hDED].[IsDeleted] as [IsDeleted], 
[hDED].[IsSupernumerary] as [IsSupernumerary], 
[hDED].[IsChild] as [IsChild], 
[hDED].[Iropz] as [Iropz], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_dent_ChartTooth] as [hDED]
INNER JOIN [hlt_disp_Exam] as [jT_hlt_disp_Exam] on [jT_hlt_disp_Exam].[disp_ExamID] = [hDED].[rf_disp_ExamID]
INNER JOIN [oms_dent_Tooth] as [jT_oms_dent_Tooth] on [jT_oms_dent_Tooth].[dent_ToothID] = [hDED].[rf_dent_ToothID]
go

