CREATE VIEW [V_oms_kl_MetodHMP] AS SELECT 
[hDED].[kl_MetodHMPID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_VidHMPID] as [rf_kl_VidHMPID], 
[jT_oms_kl_VidHMP].[Name] as [SILENT_rf_kl_VidHMPID], 
[hDED].[CodeMetod] as [CodeMetod], 
[hDED].[NameMetod] as [NameMetod], 
[hDED].[GUIDMetodHMP] as [GUIDMetodHMP], 
[hDED].[Diagn] as [Diagn], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_kl_MetodHMP] as [hDED]
INNER JOIN [oms_kl_VidHMP] as [jT_oms_kl_VidHMP] on [jT_oms_kl_VidHMP].[kl_VidHMPID] = [hDED].[rf_kl_VidHMPID]
go

