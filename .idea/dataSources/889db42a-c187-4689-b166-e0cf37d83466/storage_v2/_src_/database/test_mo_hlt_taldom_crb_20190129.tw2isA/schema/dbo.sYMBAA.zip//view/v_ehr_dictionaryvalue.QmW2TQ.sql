CREATE VIEW [V_ehr_DictionaryValue] AS SELECT 
[hDED].[DictionaryValueID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DictionaryID] as [rf_DictionaryID], 
[hDED].[Value] as [Value]
FROM [ehr_DictionaryValue] as [hDED]
go

