CREATE VIEW [V_lbr_TypeToTypeParam] AS SELECT 
[hDED].[TypeToTypeParamID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResearchTypeGuid] as [rf_ResearchTypeGuid], 
[hDED].[rf_ResearchTypeParamGuid] as [rf_ResearchTypeParamGuid], 
[hDED].[Guid] as [Guid]
FROM [lbr_TypeToTypeParam] as [hDED]
go

