CREATE VIEW [V_hlt_disp_QuestionGroup] AS SELECT 
[hDED].[disp_QuestionGroupID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_disp_QuestionGroupParentID] as [rf_disp_QuestionGroupParentID], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_QuestionGroup] as [hDED]
go

