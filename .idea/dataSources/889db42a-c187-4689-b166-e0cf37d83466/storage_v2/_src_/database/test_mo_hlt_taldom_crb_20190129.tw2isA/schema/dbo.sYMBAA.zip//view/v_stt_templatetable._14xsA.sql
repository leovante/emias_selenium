CREATE VIEW [V_stt_TemplateTable] AS SELECT 
[hDED].[TemplateTableID], [hDED].[x_Edition], [hDED].[x_Status], 
(isNull((select Caption from x_DocTypeDef where GUID =  [hDED].[rf_DocTypeDefGUID]),'')) as [V_Document], 
[hDED].[rf_TemplateTypeID] as [rf_TemplateTypeID], 
[jT_stt_TemplateType].[Name] as [SILENT_rf_TemplateTypeID], 
[hDED].[rf_DocTypeDefGUID] as [rf_DocTypeDefGUID]
FROM [stt_TemplateTable] as [hDED]
INNER JOIN [stt_TemplateType] as [jT_stt_TemplateType] on [jT_stt_TemplateType].[TemplateTypeID] = [hDED].[rf_TemplateTypeID]
go

