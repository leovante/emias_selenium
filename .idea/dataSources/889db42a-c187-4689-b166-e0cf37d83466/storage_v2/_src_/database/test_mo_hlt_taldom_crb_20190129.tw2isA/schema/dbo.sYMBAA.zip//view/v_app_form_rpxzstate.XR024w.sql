CREATE VIEW [V_App_FORM_RPXZState] AS SELECT 
[hDED].[FORM_RPXZStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Cod] as [Cod], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description]
FROM [App_FORM_RPXZState] as [hDED]
go

