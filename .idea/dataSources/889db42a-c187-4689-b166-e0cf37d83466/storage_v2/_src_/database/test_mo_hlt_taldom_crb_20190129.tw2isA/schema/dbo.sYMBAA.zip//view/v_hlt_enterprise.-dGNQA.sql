CREATE VIEW [V_hlt_Enterprise] AS SELECT 
[hDED].[EnterpriseID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[hDED].[rf_OrganisationID] as [rf_OrganisationID], 
[hDED].[NumEnt] as [NumEnt], 
[hDED].[FullNameEnt] as [FullNameEnt], 
[hDED].[NameEnt] as [NameEnt], 
[hDED].[INN] as [INN], 
[hDED].[KPP] as [KPP], 
[hDED].[OGRN] as [OGRN], 
[hDED].[OKPO] as [OKPO], 
[hDED].[NDog] as [NDog], 
[hDED].[FIO_RUK] as [FIO_RUK], 
[hDED].[FIO_BUH] as [FIO_BUH], 
[hDED].[FIO_WRK] as [FIO_WRK], 
[hDED].[Telephone] as [Telephone], 
[hDED].[Address] as [Address], 
[hDED].[Code] as [Code], 
[hDED].[CodeTO] as [CodeTO], 
[hDED].[Flags] as [Flags], 
[hDED].[isUseELN] as [isUseELN], 
[hDED].[DateDog] as [DateDog]
FROM [hlt_Enterprise] as [hDED]
go

