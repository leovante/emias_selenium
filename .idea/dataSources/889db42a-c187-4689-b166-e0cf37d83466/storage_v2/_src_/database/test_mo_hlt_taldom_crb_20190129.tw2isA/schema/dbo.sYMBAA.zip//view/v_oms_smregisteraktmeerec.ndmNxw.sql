CREATE VIEW [V_oms_SMRegisterAktMEERec] AS SELECT 
[hDED].[SMRegisterAktMEERecID], [hDED].[x_Edition], [hDED].[x_Status], 
(((select FIO from x_User where UserId = hDED.LastUserID))) as [V_UserFIO], 
[hDED].[rf_SMReestrSluchID] as [rf_SMReestrSluchID], 
[hDED].[rf_SMReestrSluchViewID] as [rf_SMReestrSluchViewID], 
[jT_oms_SMReestrSluchView].[inf_Family] as [SILENT_rf_SMReestrSluchViewID], 
[hDED].[rf_SMRegisterAktMEEID] as [rf_SMRegisterAktMEEID], 
[jT_oms_SMRegisterAktMEE].[Num] as [SILENT_rf_SMRegisterAktMEEID], 
[hDED].[LastUserID] as [LastUserID], 
[hDED].[Num] as [Num], 
[hDED].[Date_Akt] as [Date_Akt], 
[hDED].[Flags] as [Flags]
FROM [oms_SMRegisterAktMEERec] as [hDED]
INNER JOIN [oms_SMReestrSluchView] as [jT_oms_SMReestrSluchView] on [jT_oms_SMReestrSluchView].[SMReestrSluchViewID] = [hDED].[rf_SMReestrSluchViewID]
INNER JOIN [oms_SMRegisterAktMEE] as [jT_oms_SMRegisterAktMEE] on [jT_oms_SMRegisterAktMEE].[SMRegisterAktMEEID] = [hDED].[rf_SMRegisterAktMEEID]
go

