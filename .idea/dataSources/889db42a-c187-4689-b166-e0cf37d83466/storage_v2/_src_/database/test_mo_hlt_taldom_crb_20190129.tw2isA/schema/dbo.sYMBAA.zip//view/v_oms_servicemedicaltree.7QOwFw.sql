CREATE VIEW [V_oms_ServiceMedicalTree] AS SELECT 
[hDED].[ServiceMedicalTreeID], [hDED].[x_Edition], [hDED].[x_Status], 
(SELECT ServiceMedicalCode FROM oms_ServiceMedical WHERE ServiceMedicalID = [hded].rf_ChildServiceMedicalID) as [V_ChildServiceMedicalCode], 
(SELECT ServiceMedicalCode FROM oms_ServiceMedical WHERE ServiceMedicalID = [hded].rf_RootServiceMedicalID) as [V_RootServiceMedicalCode], 
[hDED].[rf_PRVDID] as [rf_PRVDID], 
[jT_oms_PRVD].[NAME] as [SILENT_rf_PRVDID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_PRVSID], 
[hDED].[rf_ChildServiceMedicalID] as [rf_ChildServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ChildServiceMedicalID], 
[hDED].[rf_RootServiceMedicalID] as [rf_RootServiceMedicalID], 
[jT_oms_ServiceMedical1].[ServiceMedicalName] as [SILENT_rf_RootServiceMedicalID], 
[hDED].[GUIDTree] as [GUIDTree], 
[hDED].[Flags] as [Flags], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_ServiceMedicalTree] as [hDED]
INNER JOIN [oms_PRVD] as [jT_oms_PRVD] on [jT_oms_PRVD].[PRVDID] = [hDED].[rf_PRVDID]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ChildServiceMedicalID]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical1] on [jT_oms_ServiceMedical1].[ServiceMedicalID] = [hDED].[rf_RootServiceMedicalID]
go

