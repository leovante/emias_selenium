CREATE VIEW [V_oms_sc_Complication] AS SELECT 
[hDED].[sc_ComplicationID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_kl_Complication].[Name] as [V_Name], 
[hDED].[rf_sc_StandartCureID] as [rf_sc_StandartCureID], 
[jT_oms_sc_StandartCure].[StandartName] as [SILENT_rf_sc_StandartCureID], 
[hDED].[rf_kl_ComplicationID] as [rf_kl_ComplicationID], 
[jT_oms_kl_Complication].[Name] as [SILENT_rf_kl_ComplicationID], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_sc_Complication] as [hDED]
INNER JOIN [oms_kl_Complication] as [jT_oms_kl_Complication] on [jT_oms_kl_Complication].[kl_ComplicationID] = [hDED].[rf_kl_ComplicationID]
INNER JOIN [oms_sc_StandartCure] as [jT_oms_sc_StandartCure] on [jT_oms_sc_StandartCure].[sc_StandartCureID] = [hDED].[rf_sc_StandartCureID]
go

