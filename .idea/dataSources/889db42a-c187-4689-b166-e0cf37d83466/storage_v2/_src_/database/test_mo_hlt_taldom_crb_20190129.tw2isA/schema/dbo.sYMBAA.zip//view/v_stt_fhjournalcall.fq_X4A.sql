CREATE VIEW [V_stt_FHJournalCall] AS SELECT 
[hDED].[FHJournalCallID], [hDED].[x_Edition], [hDED].[x_Status], 
((([hDED].Surname + ' ' + [hDED].Name + ' ' + [hDED].Patronymic))
) as [V_FIO], 
((convert(varchar, [hDED].TimeCall, 108))
) as [V_TimeCall], 
((convert(varchar, [hDED].TimeDeparture, 108))
) as [V_TimeDeparture], 
((convert(varchar, [hDED].TimeEnd, 108))
) as [V_TimeEnd], 
((convert(varchar, [hDED].TimeTransferBrigade, 108))
) as [V_TimeTransferBrigade], 
((convert(varchar, [hDED].TimeGoPlace, 108))
) as [V_TimeGoPlace], 
((convert(varchar, [hDED].DateCall, 104))
) as [V_DateCall], 
((convert(varchar, [hDED].DateBirth, 104))
) as [V_DateBirth], 
(((convert(varchar, [hDED].TimeTransferBegin, 108)))
) as [V_TimeTransferBegin], 
(((((convert(varchar, [hDED].TimeReturnMO, 108)))
))) as [V_TimeReturnMO], 
(((convert(varchar, [hDED].TimeReturnDep, 108)))
) as [V_TimeReturnDep], 
[jT_stt_FHOccasionCall].[Name] as [V_OccasionCallName], 
[jT_stt_FHBrigade].[Number] as [V_BrigadeNumber], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_MKB2ID] as [rf_MKB2ID], 
[hDED].[rf_PatientID] as [rf_PatientID], 
[hDED].[rf_AddressID] as [rf_AddressID], 
[hDED].[rf_kl_VisitResultID] as [rf_kl_VisitResultID], 
[hDED].[rf_kl_StatCureResultID] as [rf_kl_StatCureResultID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[hDED].[rf_FHBrigadeID] as [rf_FHBrigadeID], 
[hDED].[rf_FHDoctorID] as [rf_FHDoctorID], 
[hDED].[rf_FHDoctorMedicalID] as [rf_FHDoctorMedicalID], 
[hDED].[rf_FHOccasionCallID] as [rf_FHOccasionCallID], 
[hDED].[DateCall] as [DateCall], 
[hDED].[Surname] as [Surname], 
[hDED].[Name] as [Name], 
[hDED].[Patronymic] as [Patronymic], 
[hDED].[DateBirth] as [DateBirth], 
[hDED].[Address] as [Address], 
[hDED].[SurnameCall] as [SurnameCall], 
[hDED].[TelephoneCall] as [TelephoneCall], 
[hDED].[MedicalProcedures] as [MedicalProcedures], 
[hDED].[TimeCall] as [TimeCall], 
[hDED].[TimeDeparture] as [TimeDeparture], 
[hDED].[TimeEnd] as [TimeEnd], 
[hDED].[TimeTransferBrigade] as [TimeTransferBrigade], 
[hDED].[TimeGoPlace] as [TimeGoPlace], 
[hDED].[Number] as [Number], 
[hDED].[DateHealthBegin] as [DateHealthBegin], 
[hDED].[DateHealthEnd] as [DateHealthEnd], 
[hDED].[TimeTransferBegin] as [TimeTransferBegin], 
[hDED].[TimeReturnMO] as [TimeReturnMO], 
[hDED].[TimeReturnDep] as [TimeReturnDep]
FROM [stt_FHJournalCall] as [hDED]
INNER JOIN [stt_FHOccasionCall] as [jT_stt_FHOccasionCall] on [jT_stt_FHOccasionCall].[FHOccasionCallID] = [hDED].[rf_FHOccasionCallID]
INNER JOIN [stt_FHBrigade] as [jT_stt_FHBrigade] on [jT_stt_FHBrigade].[FHBrigadeID] = [hDED].[rf_FHBrigadeID]
go

