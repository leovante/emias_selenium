CREATE VIEW [V_oms_rx_Mapping] AS SELECT 
[hDED].[rx_MappingID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[OuterFieldValue] as [OuterFieldValue], 
[hDED].[OutherSystemMnemonic] as [OutherSystemMnemonic], 
[hDED].[DocTypeDefGUID] as [DocTypeDefGUID], 
[hDED].[KeyFieldName] as [KeyFieldName], 
[hDED].[KeyFieldValue] as [KeyFieldValue]
FROM [oms_rx_Mapping] as [hDED]
go

