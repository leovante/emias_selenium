CREATE VIEW [V_App_OLSPZState] AS SELECT 
[hDED].[OLSPZStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Cod] as [Cod], 
[hDED].[State] as [State], 
[hDED].[Description] as [Description]
FROM [App_OLSPZState] as [hDED]
go

