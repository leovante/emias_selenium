CREATE VIEW [V_hlt_National] AS SELECT 
[hDED].[NationalID], [hDED].[x_Edition], [hDED].[x_Status], 
(( '( '  + [hded].Code+  ' -  '+ [hded].Name+' )')) as [V_Descr], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Name_W] as [Name_W]
FROM [hlt_National] as [hDED]
go

