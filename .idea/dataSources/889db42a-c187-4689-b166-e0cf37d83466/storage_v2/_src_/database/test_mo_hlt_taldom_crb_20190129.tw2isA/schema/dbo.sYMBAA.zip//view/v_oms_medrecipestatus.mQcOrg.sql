CREATE VIEW [V_oms_MedRecipeStatus] AS SELECT 
[hDED].[MedRecipeStatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CodeMedRS] as [CodeMedRS], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUIDMedRS] as [UGUIDMedRS], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Caption] as [Caption]
FROM [oms_MedRecipeStatus] as [hDED]
go

