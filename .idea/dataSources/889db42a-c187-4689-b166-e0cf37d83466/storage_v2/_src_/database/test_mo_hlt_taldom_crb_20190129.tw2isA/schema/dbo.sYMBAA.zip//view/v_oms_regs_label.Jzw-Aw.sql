CREATE VIEW [V_oms_regs_Label] AS SELECT 
[hDED].[regs_LabelID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[InnerCode] as [InnerCode]
FROM [oms_regs_Label] as [hDED]
go

