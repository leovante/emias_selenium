CREATE VIEW [V_oms_SendState] AS SELECT 
[hDED].[SendStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Description] as [Description], 
[hDED].[Rem] as [Rem]
FROM [oms_SendState] as [hDED]
go

