CREATE VIEW [V_vcn_Result] AS SELECT 
[hDED].[ResultID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [vcn_Result] as [hDED]
go

