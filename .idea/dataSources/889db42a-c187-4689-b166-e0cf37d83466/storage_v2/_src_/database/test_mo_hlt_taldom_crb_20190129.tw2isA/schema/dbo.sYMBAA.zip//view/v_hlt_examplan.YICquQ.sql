CREATE VIEW [V_hlt_ExamPlan] AS SELECT 
[hDED].[ExamPlanID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_disp_CardID] as [rf_disp_CardID], 
[jT_hlt_disp_Card].[rf_MkabGuid] as [SILENT_rf_disp_CardID], 
[hDED].[rf_disp_ExamID] as [rf_disp_ExamID], 
[jT_hlt_disp_Exam].[rf_ServiceGuid] as [SILENT_rf_disp_ExamID], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_ExamPlan] as [hDED]
INNER JOIN [hlt_disp_Card] as [jT_hlt_disp_Card] on [jT_hlt_disp_Card].[disp_CardID] = [hDED].[rf_disp_CardID]
INNER JOIN [hlt_disp_Exam] as [jT_hlt_disp_Exam] on [jT_hlt_disp_Exam].[disp_ExamID] = [hDED].[rf_disp_ExamID]
go

