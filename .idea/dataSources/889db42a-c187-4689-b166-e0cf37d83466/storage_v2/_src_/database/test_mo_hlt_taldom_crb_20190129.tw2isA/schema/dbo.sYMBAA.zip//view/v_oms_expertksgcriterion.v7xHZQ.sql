CREATE VIEW [V_oms_ExpertKSGCriterion] AS SELECT 
[hDED].[ExpertKSGCriterionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[GUIDExpertKSGCriterion] as [GUIDExpertKSGCriterion], 
[hDED].[CodeKSGCriterion] as [CodeKSGCriterion], 
[hDED].[MNNKSGCriterion] as [MNNKSGCriterion], 
[hDED].[NameKSGCriterion] as [NameKSGCriterion], 
[hDED].[KolKSGCriterion] as [KolKSGCriterion], 
[hDED].[GospitKSGCriterion] as [GospitKSGCriterion], 
[hDED].[Flags] as [Flags], 
[hDED].[Rem] as [Rem], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Doc] as [Doc], 
[hDED].[Type] as [Type]
FROM [oms_ExpertKSGCriterion] as [hDED]
go

