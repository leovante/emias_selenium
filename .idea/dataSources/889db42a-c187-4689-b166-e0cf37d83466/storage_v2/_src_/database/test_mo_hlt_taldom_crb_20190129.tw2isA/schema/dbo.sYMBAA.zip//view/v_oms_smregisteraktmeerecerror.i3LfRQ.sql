CREATE VIEW [V_oms_SMRegisterAktMEERecError] AS SELECT 
[hDED].[SMRegisterAktMEERecErrorID], [hDED].[x_Edition], [hDED].[x_Status], 
((select FIO from x_User where UserId = hDED.LastUserID)) as [V_UserFIO], 
[hDED].[rf_SMCriterionID] as [rf_SMCriterionID], 
[jT_oms_SMCriterion].[SMCriterionCaption] as [SILENT_rf_SMCriterionID], 
[hDED].[rf_SMRegisterAktMEERecID] as [rf_SMRegisterAktMEERecID], 
[jT_oms_SMRegisterAktMEERec].[Num] as [SILENT_rf_SMRegisterAktMEERecID], 
[hDED].[Rem] as [Rem], 
[hDED].[LastUserID] as [LastUserID], 
[hDED].[Sum] as [Sum]
FROM [oms_SMRegisterAktMEERecError] as [hDED]
INNER JOIN [oms_SMCriterion] as [jT_oms_SMCriterion] on [jT_oms_SMCriterion].[SMCriterionID] = [hDED].[rf_SMCriterionID]
INNER JOIN [oms_SMRegisterAktMEERec] as [jT_oms_SMRegisterAktMEERec] on [jT_oms_SMRegisterAktMEERec].[SMRegisterAktMEERecID] = [hDED].[rf_SMRegisterAktMEERecID]
go

