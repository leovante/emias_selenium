CREATE VIEW [V_oms_sc_MedArticle] AS SELECT 
[hDED].[sc_MedArticleID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_MedicalArticle].[Name] as [V_Name], 
[hDED].[rf_sc_StandartCureID] as [rf_sc_StandartCureID], 
[jT_oms_sc_StandartCure].[StandartName] as [SILENT_rf_sc_StandartCureID], 
[hDED].[rf_MedicalArticleID] as [rf_MedicalArticleID], 
[jT_oms_MedicalArticle].[Name] as [SILENT_rf_MedicalArticleID], 
[hDED].[Percent] as [Percent], 
[hDED].[Count] as [Count], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_sc_MedArticle] as [hDED]
INNER JOIN [oms_MedicalArticle] as [jT_oms_MedicalArticle] on [jT_oms_MedicalArticle].[MedicalArticleID] = [hDED].[rf_MedicalArticleID]
INNER JOIN [oms_sc_StandartCure] as [jT_oms_sc_StandartCure] on [jT_oms_sc_StandartCure].[sc_StandartCureID] = [hDED].[rf_sc_StandartCureID]
go

