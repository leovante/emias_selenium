CREATE VIEW [V_oms_SMRegisterTarif] AS SELECT 
[hDED].[SMRegisterTarifID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_KV_KATID] as [rf_KV_KATID], 
[jT_oms_KV_KAT].[KV_KAT_NAME] as [SILENT_rf_KV_KATID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[rf_SMExpVidID] as [rf_SMExpVidID], 
[jT_oms_SMExpVid].[NameExpVid] as [SILENT_rf_SMExpVidID], 
[hDED].[Tarif] as [Tarif], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [oms_SMRegisterTarif] as [hDED]
INNER JOIN [oms_KV_KAT] as [jT_oms_KV_KAT] on [jT_oms_KV_KAT].[KV_KATID] = [hDED].[rf_KV_KATID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [oms_SMExpVid] as [jT_oms_SMExpVid] on [jT_oms_SMExpVid].[SMExpVidID] = [hDED].[rf_SMExpVidID]
go

