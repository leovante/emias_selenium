CREATE VIEW [V_oms_TypeDocRepresentative] AS SELECT 
[hDED].[TypeDocRepresentativeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [oms_TypeDocRepresentative] as [hDED]
go

