CREATE VIEW [V_oms_CHOICES_APP_POL] AS SELECT 
[hDED].[CHOICES_APP_POLID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[field] as [field], 
[hDED].[Caption] as [Caption], 
[hDED].[Rem] as [Rem], 
[hDED].[Field1] as [Field1], 
[hDED].[Field2] as [Field2], 
[hDED].[rem1] as [rem1]
FROM [oms_CHOICES_APP_POL] as [hDED]
go

