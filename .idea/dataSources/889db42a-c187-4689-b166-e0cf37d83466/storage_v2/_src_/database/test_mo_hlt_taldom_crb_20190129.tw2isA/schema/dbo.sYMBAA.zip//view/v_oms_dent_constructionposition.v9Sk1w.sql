CREATE VIEW [V_oms_dent_ConstructionPosition] AS SELECT 
[hDED].[dent_ConstructionPositionID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidConstructionPosition], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [oms_dent_ConstructionPosition] as [hDED]
go

