CREATE VIEW [V_hlt_mkp_DiagnosPregType] AS SELECT 
[hDED].[mkp_DiagnosPregTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
([hded].Code+  ' - '+ [hded].Name) as [V_Descr], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Code] as [Code], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[Sort] as [Sort]
FROM [hlt_mkp_DiagnosPregType] as [hDED]
go

