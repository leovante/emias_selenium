CREATE VIEW [V_oms_DoctorPosition] AS SELECT 
[hDED].[DoctorPositionID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_DOCTOR].[V_DoctorCode] as [V_V_DoctorCode], 
[jT_oms_DOCTOR].[DOCTOR_FIO] as [V_DOCTOR_FIO], 
[jT_oms_PRVS].[C_PRVS] as [V_C_PRVS], 
[jT_oms_LPU].[MCOD] as [V_MCOD], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[rf_PRVDID] as [rf_PRVDID], 
[jT_oms_PRVD].[NAME] as [SILENT_rf_PRVDID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_PRVSID], 
[hDED].[rf_KV_KATID] as [rf_KV_KATID], 
[hDED].[rf_DOCTORID] as [rf_DOCTORID], 
[jT_oms_DOCTOR].[DOCTOR_FIO] as [SILENT_rf_DOCTORID], 
[hDED].[rf_DepartmentID] as [rf_DepartmentID], 
[hDED].[Date_b] as [Date_b], 
[hDED].[Date_e] as [Date_e], 
[hDED].[D_PRIK] as [D_PRIK], 
[hDED].[D_END] as [D_END], 
[hDED].[REM] as [REM]
FROM [oms_DoctorPosition] as [hDED]
INNER JOIN [V_oms_DOCTOR] as [jT_oms_DOCTOR] on [jT_oms_DOCTOR].[DOCTORID] = [hDED].[rf_DOCTORID]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
INNER JOIN [oms_PRVD] as [jT_oms_PRVD] on [jT_oms_PRVD].[PRVDID] = [hDED].[rf_PRVDID]
go

