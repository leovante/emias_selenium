CREATE VIEW [V_oms_x_TableRef] AS SELECT 
[hDED].[x_TableRefID], [hDED].[x_Edition], [hDED].[x_Status], 
((select Headtable from x_DocTypeDef where GUID=DocTypeDefGUID)) as [V_Table], 
(select name from x_DocElemDef where GUID=DocElemDefGUID) as [V_Field], 
[hDED].[DocTypeDefGuid] as [DocTypeDefGuid], 
[hDED].[DocElemDefGuid] as [DocElemDefGuid], 
[hDED].[Num] as [Num]
FROM [oms_x_TableRef] as [hDED]
go

