CREATE VIEW [V_oms_TehAtr] AS SELECT 
[hDED].[TehAtrID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ProjectID] as [rf_ProjectID], 
[hDED].[rf_TehAtrDataTypeID] as [rf_TehAtrDataTypeID], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[Flag] as [Flag], 
[hDED].[Mask] as [Mask], 
[hDED].[IsUnique] as [IsUnique], 
[hDED].[IsSin] as [IsSin], 
[hDED].[AccessLevel] as [AccessLevel], 
[hDED].[MaskDescription] as [MaskDescription]
FROM [oms_TehAtr] as [hDED]
go

