CREATE VIEW [V_stt_Diet] AS SELECT 
[hDED].[DietID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Num] as [Num], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[Code] as [Code], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_Diet] as [hDED]
go

