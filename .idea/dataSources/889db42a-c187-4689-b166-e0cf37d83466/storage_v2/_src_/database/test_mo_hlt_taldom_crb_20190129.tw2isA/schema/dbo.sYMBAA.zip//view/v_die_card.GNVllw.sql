CREATE VIEW [V_die_Card] AS SELECT 
[hDED].[CardID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MkabGuid] as [rf_MkabGuid], 
[hDED].[rf_CitizenId] as [rf_CitizenId], 
[hDED].[rf_LiveAdressId] as [rf_LiveAdressId], 
[hDED].[rf_kl_SexId] as [rf_kl_SexId], 
[hDED].[rf_MedicalHistoryGuid] as [rf_MedicalHistoryGuid], 
[hDED].[PersonGuid] as [PersonGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Name] as [Name], 
[hDED].[Surname] as [Surname], 
[hDED].[BirthDate] as [BirthDate], 
[hDED].[Patronymic] as [Patronymic]
FROM [die_Card] as [hDED]
go

