CREATE VIEW [V_lbr_LabResearchContingent] AS SELECT 
[hDED].[LabResearchContingentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[CodeLis] as [CodeLis], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [lbr_LabResearchContingent] as [hDED]
go

