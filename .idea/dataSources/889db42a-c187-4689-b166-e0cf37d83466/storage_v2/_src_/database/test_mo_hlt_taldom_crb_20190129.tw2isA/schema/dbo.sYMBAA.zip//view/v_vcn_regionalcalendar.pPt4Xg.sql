CREATE VIEW [V_vcn_RegionalCalendar] AS SELECT 
[hDED].[RegionalCalendarID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_VaccinationTypeID] as [rf_VaccinationTypeID], 
[hDED].[PeriodSelector] as [PeriodSelector], 
[hDED].[PeriodFrom] as [PeriodFrom], 
[hDED].[PeriodTo] as [PeriodTo]
FROM [vcn_RegionalCalendar] as [hDED]
go

