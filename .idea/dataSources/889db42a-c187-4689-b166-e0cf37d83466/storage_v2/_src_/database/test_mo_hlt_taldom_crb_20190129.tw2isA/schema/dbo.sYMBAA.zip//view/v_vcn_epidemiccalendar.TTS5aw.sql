CREATE VIEW [V_vcn_EpidemicCalendar] AS SELECT 
[hDED].[EpidemicCalendarID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_VaccinationTypeID] as [rf_VaccinationTypeID], 
[hDED].[MonthsFrom] as [MonthsFrom], 
[hDED].[YearsFrom] as [YearsFrom], 
[hDED].[FirstRevac] as [FirstRevac], 
[hDED].[SecondRevacPeriod] as [SecondRevacPeriod]
FROM [vcn_EpidemicCalendar] as [hDED]
go

