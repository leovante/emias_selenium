CREATE VIEW [V_stt_PLPosition] AS SELECT 
[hDED].[PLPositionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[hDED].[rf_ListOfPurposeID] as [rf_ListOfPurposeID], 
[hDED].[rf_PurposeLSID] as [rf_PurposeLSID], 
[hDED].[rf_LSOutlayID] as [rf_LSOutlayID], 
[hDED].[rf_ProcedurePositionID] as [rf_ProcedurePositionID], 
[hDED].[Date] as [Date], 
[hDED].[PurposeCount] as [PurposeCount], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag], 
[hDED].[IsFullFilled] as [IsFullFilled], 
[hDED].[IsManual] as [IsManual], 
[hDED].[Dose] as [Dose]
FROM [stt_PLPosition] as [hDED]
go

