CREATE VIEW [V_prp_ListOfPurpose] AS SELECT 
[hDED].[ListOfPurposeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PurposeLSID] as [rf_PurposeLSID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Flag] as [Flag], 
[hDED].[Signature] as [Signature], 
[hDED].[Dose] as [Dose], 
[hDED].[TimesInDay] as [TimesInDay], 
[hDED].[SpecificDose] as [SpecificDose], 
[hDED].[RationalDose] as [RationalDose], 
[hDED].[UnitDose] as [UnitDose], 
[hDED].[IsWriteCoreDose] as [IsWriteCoreDose]
FROM [prp_ListOfPurpose] as [hDED]
go

