CREATE VIEW [V_oms_TYPEDOC] AS SELECT 
[hDED].[TYPEDOCID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[C_DOC] as [C_DOC], 
[hDED].[NAME_PFR] as [NAME_PFR], 
[hDED].[NAME] as [NAME], 
[hDED].[DocSer] as [DocSer], 
[hDED].[DocNum] as [DocNum], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[CodeEgisz] as [CodeEgisz]
FROM [oms_TYPEDOC] as [hDED]
go

