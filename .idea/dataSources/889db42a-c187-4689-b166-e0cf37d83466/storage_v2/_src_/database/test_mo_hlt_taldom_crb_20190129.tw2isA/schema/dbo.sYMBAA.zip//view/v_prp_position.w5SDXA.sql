CREATE VIEW [V_prp_Position] AS SELECT 
[hDED].[PositionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_PurposeID] as [rf_PurposeID], 
[hDED].[Date] as [Date], 
[hDED].[DateComplete] as [DateComplete], 
[hDED].[isComplete] as [isComplete]
FROM [prp_Position] as [hDED]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
go

