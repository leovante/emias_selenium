CREATE VIEW [V_dent_CardConstructionedTeeth] AS SELECT 
[hDED].[CardConstructionedTeethID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_RootToothID] as [rf_RootToothID], 
[jT_dent_CardTooth].[Date] as [SILENT_rf_RootToothID], 
[hDED].[rf_ChildToothID] as [rf_ChildToothID], 
[jT_dent_CardTooth1].[Date] as [SILENT_rf_ChildToothID], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dent_CardConstructionedTeeth] as [hDED]
INNER JOIN [dent_CardTooth] as [jT_dent_CardTooth] on [jT_dent_CardTooth].[CardToothID] = [hDED].[rf_RootToothID]
INNER JOIN [dent_CardTooth] as [jT_dent_CardTooth1] on [jT_dent_CardTooth1].[CardToothID] = [hDED].[rf_ChildToothID]
go

