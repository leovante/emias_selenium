CREATE VIEW [V_stt_HospExit] AS SELECT 
[hDED].[HospExitID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[Flag] as [Flag], 
[hDED].[COD] as [COD]
FROM [stt_HospExit] as [hDED]
go

