CREATE VIEW [V_dd_HealthIndexTypeDD] AS SELECT 
[hDED].[HealthIndexTypeDDID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DDTypeUGUID] as [rf_DDTypeUGUID], 
[hDED].[rf_HealthIndexUGUID] as [rf_HealthIndexUGUID], 
[hDED].[UGUID] as [UGUID]
FROM [dd_HealthIndexTypeDD] as [hDED]
go

