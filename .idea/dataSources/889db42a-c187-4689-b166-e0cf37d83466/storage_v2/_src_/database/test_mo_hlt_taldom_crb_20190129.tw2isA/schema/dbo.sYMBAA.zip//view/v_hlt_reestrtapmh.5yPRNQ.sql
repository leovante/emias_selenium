CREATE VIEW [V_hlt_ReestrTAPMH] AS SELECT 
[hDED].[ReestrTAPMHID], [hDED].[x_Edition], [hDED].[x_Status], 
(jt_hlt_TAP.SILENT_rf_DepartmentID) as [V_Department], 
[jT_hlt_TAP].[v_fio] as [V_fio], 
[hDED].[rf_OKATOID] as [rf_OKATOID], 
[jT_oms_OKATO].[C_OKATO] as [SILENT_rf_OKATOID], 
[hDED].[rf_SMOID] as [rf_SMOID], 
[jT_oms_SMO].[Q_NAME] as [SILENT_rf_SMOID], 
[hDED].[rf_prikLPUID] as [rf_prikLPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_prikLPUID], 
[hDED].[rf_TAPID] as [rf_TAPID], 
[jT_hlt_TAP].[v_TAP] as [SILENT_rf_TAPID], 
[hDED].[rf_UchastokID] as [rf_UchastokID], 
[hDED].[rf_ReestrMHID] as [rf_ReestrMHID], 
[hDED].[rf_SMReestrID] as [rf_SMReestrID], 
[jT_oms_SMReestr].[V_SMReestr] as [SILENT_rf_SMReestrID], 
[hDED].[rf_ReportPeriodID] as [rf_ReportPeriodID], 
[jT_hlt_ReportPeriod].[Year_Month] as [SILENT_rf_ReportPeriodID], 
[hDED].[rf_ReestrMHReturnsTypeID] as [rf_ReestrMHReturnsTypeID], 
[jT_oms_MHReturnsType].[Name] as [SILENT_rf_ReestrMHReturnsTypeID], 
[hDED].[Num] as [Num], 
[hDED].[Flag] as [Flag], 
[hDED].[DateOfReturn] as [DateOfReturn], 
[hDED].[Sum_V] as [Sum_V], 
[hDED].[Sum_O] as [Sum_O], 
[hDED].[Kol_V] as [Kol_V], 
[hDED].[Kol_O] as [Kol_O], 
[hDED].[CriticalFlag] as [CriticalFlag], 
[hDED].[k_sum] as [k_sum]
FROM [hlt_ReestrTAPMH] as [hDED]
INNER JOIN [V_hlt_TAP] as [jT_hlt_TAP] on [jT_hlt_TAP].[TAPID] = [hDED].[rf_TAPID]
INNER JOIN [oms_OKATO] as [jT_oms_OKATO] on [jT_oms_OKATO].[OKATOID] = [hDED].[rf_OKATOID]
INNER JOIN [oms_SMO] as [jT_oms_SMO] on [jT_oms_SMO].[SMOID] = [hDED].[rf_SMOID]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_prikLPUID]
INNER JOIN [V_oms_SMReestr] as [jT_oms_SMReestr] on [jT_oms_SMReestr].[SMReestrID] = [hDED].[rf_SMReestrID]
INNER JOIN [V_hlt_ReportPeriod] as [jT_hlt_ReportPeriod] on [jT_hlt_ReportPeriod].[ReportPeriodID] = [hDED].[rf_ReportPeriodID]
INNER JOIN [oms_MHReturnsType] as [jT_oms_MHReturnsType] on [jT_oms_MHReturnsType].[MHReturnsTypeID] = [hDED].[rf_ReestrMHReturnsTypeID]
go

