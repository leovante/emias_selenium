CREATE VIEW [V_oms_RecipePerson] AS SELECT 
[hDED].[RecipePersonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ReestrID] as [rf_ReestrID], 
[hDED].[SS] as [SS], 
[hDED].[SN_POL] as [SN_POL], 
[hDED].[FAM] as [FAM], 
[hDED].[IM] as [IM], 
[hDED].[OT] as [OT], 
[hDED].[W] as [W], 
[hDED].[DR] as [DR], 
[hDED].[C_KAT] as [C_KAT], 
[hDED].[SN_DOC] as [SN_DOC], 
[hDED].[C_DOC] as [C_DOC], 
[hDED].[OKATO_OMS] as [OKATO_OMS], 
[hDED].[QM_OGRN] as [QM_OGRN], 
[hDED].[OKATO_REG] as [OKATO_REG], 
[hDED].[D_TYPE] as [D_TYPE]
FROM [oms_RecipePerson] as [hDED]
go

