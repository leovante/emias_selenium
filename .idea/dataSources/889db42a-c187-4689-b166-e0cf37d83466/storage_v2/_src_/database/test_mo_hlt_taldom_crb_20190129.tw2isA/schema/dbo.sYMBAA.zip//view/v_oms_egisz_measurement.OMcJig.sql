CREATE VIEW [V_oms_Egisz_Measurement] AS SELECT 
[hDED].[Egisz_MeasurementID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Uid] as [Uid], 
[hDED].[Name] as [Name], 
[hDED].[Code] as [Code]
FROM [oms_Egisz_Measurement] as [hDED]
go

