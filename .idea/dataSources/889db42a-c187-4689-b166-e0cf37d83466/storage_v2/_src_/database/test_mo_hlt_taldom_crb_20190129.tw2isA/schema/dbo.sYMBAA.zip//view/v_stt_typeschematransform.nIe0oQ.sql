CREATE VIEW [V_stt_TypeSchemaTransform] AS SELECT 
[hDED].[TypeSchemaTransformID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flag] as [Flag]
FROM [stt_TypeSchemaTransform] as [hDED]
go

