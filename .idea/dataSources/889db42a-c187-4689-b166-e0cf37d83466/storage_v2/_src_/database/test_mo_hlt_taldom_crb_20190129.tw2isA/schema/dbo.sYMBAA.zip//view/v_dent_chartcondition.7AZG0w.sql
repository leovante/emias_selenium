CREATE VIEW [V_dent_ChartCondition] AS SELECT 
[hDED].[ChartConditionID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_disp_ExamID] as [rf_disp_ExamID], 
[jT_hlt_disp_Exam].[rf_ServiceGuid] as [SILENT_rf_disp_ExamID], 
[hDED].[rf_dent_ZoneID] as [rf_dent_ZoneID], 
[jT_oms_dent_Zone].[Name] as [SILENT_rf_dent_ZoneID], 
[hDED].[rf_dent_ToothID] as [rf_dent_ToothID], 
[jT_oms_dent_Tooth].[Number] as [SILENT_rf_dent_ToothID], 
[hDED].[rf_dent_SurfaceID] as [rf_dent_SurfaceID], 
[jT_oms_dent_Surface].[Name] as [SILENT_rf_dent_SurfaceID], 
[hDED].[rf_dent_ConditionTypeID] as [rf_dent_ConditionTypeID], 
[jT_oms_dent_ConditionType].[Name] as [SILENT_rf_dent_ConditionTypeID], 
[hDED].[rf_dent_ConditionLevelID] as [rf_dent_ConditionLevelID], 
[jT_oms_dent_ConditionLevel].[Name] as [SILENT_rf_dent_ConditionLevelID], 
[hDED].[rf_ChartID] as [rf_ChartID], 
[jT_dent_Chart].[IsActive] as [SILENT_rf_ChartID], 
[hDED].[rf_ChartToothID] as [rf_ChartToothID], 
[jT_dent_ChartTooth].[Date] as [SILENT_rf_ChartToothID], 
[hDED].[rf_dent_ConstructionPositionID] as [rf_dent_ConstructionPositionID], 
[jT_oms_dent_ConstructionPosition].[Code] as [SILENT_rf_dent_ConstructionPositionID], 
[hDED].[Date] as [Date], 
[hDED].[IsDeleted] as [IsDeleted], 
[hDED].[Note] as [Note], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dent_ChartCondition] as [hDED]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [hlt_disp_Exam] as [jT_hlt_disp_Exam] on [jT_hlt_disp_Exam].[disp_ExamID] = [hDED].[rf_disp_ExamID]
INNER JOIN [oms_dent_Zone] as [jT_oms_dent_Zone] on [jT_oms_dent_Zone].[dent_ZoneID] = [hDED].[rf_dent_ZoneID]
INNER JOIN [oms_dent_Tooth] as [jT_oms_dent_Tooth] on [jT_oms_dent_Tooth].[dent_ToothID] = [hDED].[rf_dent_ToothID]
INNER JOIN [oms_dent_Surface] as [jT_oms_dent_Surface] on [jT_oms_dent_Surface].[dent_SurfaceID] = [hDED].[rf_dent_SurfaceID]
INNER JOIN [oms_dent_ConditionType] as [jT_oms_dent_ConditionType] on [jT_oms_dent_ConditionType].[dent_ConditionTypeID] = [hDED].[rf_dent_ConditionTypeID]
INNER JOIN [oms_dent_ConditionLevel] as [jT_oms_dent_ConditionLevel] on [jT_oms_dent_ConditionLevel].[dent_ConditionLevelID] = [hDED].[rf_dent_ConditionLevelID]
INNER JOIN [dent_Chart] as [jT_dent_Chart] on [jT_dent_Chart].[ChartID] = [hDED].[rf_ChartID]
INNER JOIN [dent_ChartTooth] as [jT_dent_ChartTooth] on [jT_dent_ChartTooth].[ChartToothID] = [hDED].[rf_ChartToothID]
INNER JOIN [oms_dent_ConstructionPosition] as [jT_oms_dent_ConstructionPosition] on [jT_oms_dent_ConstructionPosition].[dent_ConstructionPositionID] = [hDED].[rf_dent_ConstructionPositionID]
go

