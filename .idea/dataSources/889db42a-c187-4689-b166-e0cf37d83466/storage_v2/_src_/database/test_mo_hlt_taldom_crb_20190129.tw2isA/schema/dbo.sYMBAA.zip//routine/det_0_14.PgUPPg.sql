CREATE FUNCTION Det_0_14(@flagX int, @ds nvarchar(4000), @DateBegin datetime, @DateEnd datetime)
RETURNS TABLE
AS
RETURN 
(
select
	cast(sum(1) as varchar) as [all]
	,isnull(cast(sum(case when [dbo].[FullYearAge](mkab.date_bd, s.date_p) between '0' and '4' then 1 else 0 end) as varchar), 0) as [04]
	,isnull(cast(sum(case when [dbo].[FullYearAge](mkab.date_bd, s.date_p) between '5' and '9' then 1 else 0 end) as varchar), 0) as [59]
	,isnull(cast(sum(case when drs.code = 2 /*Взято*/ then 1 else 0 end) as varchar), 0) as [dispVZ]
	,isnull(cast(sum(case when dt.code = 2 /*Впервые в жизни установленное хроническое */ then 1 else 0 end) as varchar), 0) as [harVP]
	,isnull(cast(sum(case when dt.code = 2 /*Впервые в жизни установленное хроническое */ and drs.code = 2 /*Взято*/ then 1 else 0 end) as varchar), 0) as [VPdispVZ]
	,isnull(cast(sum(case when dt.code = 2 /*Впервые в жизни установленное хроническое */ and drs.code != 2 then 1 else 0 end) as varchar), 0) as [VPdispOST]
	,isnull(cast(sum(case when drs.code = 3 /*Снят*/ or drs.code = 4 /*Снят по причине выздоровления*/ or drs.code = 6 /*Снят по другим причинам*/ then 1 else 0 end) as varchar), 0) as [dispSN]
	,case when @flagX = 1 then 'X' else isnull(cast(sum(case when drs.code = 1 /*Состоит*/ then 1 else 0 end) as varchar), 0) end as [dispSO]
from hlt_tap t
	inner join hlt_mkab mkab on t.rf_mkabid = mkab.mkabid
	inner join oms_kl_DispRegState drs on t.rf_kl_DispRegStateID = drs.kl_DispRegStateID
	inner join oms_kl_DiseaseType dt on t.rf_kl_DiseaseTypeID = dt.kl_DiseaseTypeID
	inner join oms_mkb mkb on t.rf_mkbid = mkb.mkbid
		inner join selectByMKB(@ds) sbmkb on (mkb.MKBID = sbmkb.MKBID)
	inner join hlt_SMTAP s on t.tapid = s.rf_tapid
where
	t.DateClose between @DateBegin and @DateEnd
	and t.IsClosed = '1'
)
go

