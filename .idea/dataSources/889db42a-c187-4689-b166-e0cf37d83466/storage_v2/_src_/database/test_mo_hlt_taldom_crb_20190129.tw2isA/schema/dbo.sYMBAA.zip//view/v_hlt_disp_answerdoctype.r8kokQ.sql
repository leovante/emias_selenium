CREATE VIEW [V_hlt_disp_AnswerDocType] AS SELECT 
[hDED].[disp_AnswerDocTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ResultTypeGuid] as [rf_ResultTypeGuid], 
[hDED].[rf_ResultTypeValueGuid] as [rf_ResultTypeValueGuid], 
[hDED].[DocTypeGuid] as [DocTypeGuid]
FROM [hlt_disp_AnswerDocType] as [hDED]
go

