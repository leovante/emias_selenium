CREATE VIEW [V_stt_ProcedurePosition] AS SELECT 
[hDED].[ProcedurePositionID], [hDED].[x_Edition], [hDED].[x_Status], 
((select '['+s.[ServiceMedicalCode]+'] '+s.ServiceMedicalName from stt_ProcedureList p
		inner join oms_ServiceMedical s on p.rf_ServiceMedicalID = s.ServiceMedicalID
		where p.ProcedureListID = rf_ProcedureListID)) as [V_ServiceMedical], 
[hDED].[rf_ProcedureListID] as [rf_ProcedureListID], 
[jT_stt_ProcedureList].[rf_ServiceMedicalID] as [SILENT_rf_ProcedureListID], 
[hDED].[flag] as [flag], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Date] as [Date]
FROM [stt_ProcedurePosition] as [hDED]
INNER JOIN [stt_ProcedureList] as [jT_stt_ProcedureList] on [jT_stt_ProcedureList].[ProcedureListID] = [hDED].[rf_ProcedureListID]
go

