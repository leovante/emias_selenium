CREATE VIEW [V_hlt_disp_ServiceDependence] AS SELECT 
[hDED].[disp_ServiceDependenceID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ServicePMGuid] as [rf_ServicePMGuid], 
[jT_hlt_disp_ServicePM].[rf_ServiceGuid] as [SILENT_rf_ServicePMGuid], 
[hDED].[rf_DependsOnServicePMGuid] as [rf_DependsOnServicePMGuid], 
[jT_hlt_disp_ServicePM1].[rf_ServiceGuid] as [SILENT_rf_DependsOnServicePMGuid], 
[hDED].[DatePartValue] as [DatePartValue], 
[hDED].[DatePartType] as [DatePartType], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_ServiceDependence] as [hDED]
INNER JOIN [hlt_disp_ServicePM] as [jT_hlt_disp_ServicePM] on [jT_hlt_disp_ServicePM].[Guid] = [hDED].[rf_ServicePMGuid]
INNER JOIN [hlt_disp_ServicePM] as [jT_hlt_disp_ServicePM1] on [jT_hlt_disp_ServicePM1].[Guid] = [hDED].[rf_DependsOnServicePMGuid]
go

