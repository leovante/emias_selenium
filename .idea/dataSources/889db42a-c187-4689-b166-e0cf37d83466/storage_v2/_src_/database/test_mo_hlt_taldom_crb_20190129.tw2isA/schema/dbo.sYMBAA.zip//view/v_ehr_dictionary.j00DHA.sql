CREATE VIEW [V_ehr_Dictionary] AS SELECT 
[hDED].[DictionaryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_TemplateID] as [rf_TemplateID], 
[hDED].[rf_DoctorsID] as [rf_DoctorsID], 
[hDED].[Guid] as [Guid], 
[hDED].[ControlId] as [ControlId]
FROM [ehr_Dictionary] as [hDED]
go

