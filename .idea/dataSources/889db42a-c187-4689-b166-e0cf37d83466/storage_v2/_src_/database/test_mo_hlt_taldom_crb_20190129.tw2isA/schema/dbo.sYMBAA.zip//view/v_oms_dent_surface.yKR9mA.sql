CREATE VIEW [V_oms_dent_Surface] AS SELECT 
[hDED].[dent_SurfaceID], [hDED].[x_Edition], [hDED].[x_Status], 
([hDED].[Guid]) as [V_GuidSurface], 
[hDED].[rf_dent_ToothTypeID] as [rf_dent_ToothTypeID], 
[jT_oms_dent_ToothType].[Name] as [SILENT_rf_dent_ToothTypeID], 
[hDED].[rf_dent_SectorID] as [rf_dent_SectorID], 
[jT_oms_dent_Sector].[Name] as [SILENT_rf_dent_SectorID], 
[hDED].[rf_dent_ConditionGroupID] as [rf_dent_ConditionGroupID], 
[jT_oms_dent_ConditionGroup].[Name] as [SILENT_rf_dent_ConditionGroupID], 
[hDED].[Name] as [Name], 
[hDED].[Symbol] as [Symbol], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Number] as [Number]
FROM [oms_dent_Surface] as [hDED]
INNER JOIN [oms_dent_ToothType] as [jT_oms_dent_ToothType] on [jT_oms_dent_ToothType].[dent_ToothTypeID] = [hDED].[rf_dent_ToothTypeID]
INNER JOIN [oms_dent_Sector] as [jT_oms_dent_Sector] on [jT_oms_dent_Sector].[dent_SectorID] = [hDED].[rf_dent_SectorID]
INNER JOIN [oms_dent_ConditionGroup] as [jT_oms_dent_ConditionGroup] on [jT_oms_dent_ConditionGroup].[dent_ConditionGroupID] = [hDED].[rf_dent_ConditionGroupID]
go

