CREATE VIEW [V_oms_IntakeWay] AS SELECT 
[hDED].[IntakeWayID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Name] as [Name], 
[hDED].[C_IW] as [C_IW], 
[hDED].[GUID_IW] as [GUID_IW], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd]
FROM [oms_IntakeWay] as [hDED]
go

