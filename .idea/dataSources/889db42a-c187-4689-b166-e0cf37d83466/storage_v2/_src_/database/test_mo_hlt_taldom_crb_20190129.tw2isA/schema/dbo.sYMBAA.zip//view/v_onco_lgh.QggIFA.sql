CREATE VIEW [V_onco_Lgh] AS SELECT 
[hDED].[LghID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_onco_N010ID] as [rf_onco_N010ID], 
[hDED].[rf_onco_N011ID] as [rf_onco_N011ID], 
[hDED].[rf_TalonID] as [rf_TalonID], 
[hDED].[Description] as [Description], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[Diag_Date_Lgh] as [Diag_Date_Lgh]
FROM [onco_Lgh] as [hDED]
go

