CREATE VIEW [V_hlt_atc_Status] AS SELECT 
[hDED].[atc_StatusID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_atc_ClaimKindID] as [rf_atc_ClaimKindID], 
[jT_hlt_atc_ClaimKind].[Name] as [SILENT_rf_atc_ClaimKindID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Flags] as [Flags], 
[hDED].[GUID] as [GUID]
FROM [hlt_atc_Status] as [hDED]
INNER JOIN [hlt_atc_ClaimKind] as [jT_hlt_atc_ClaimKind] on [jT_hlt_atc_ClaimKind].[atc_ClaimKindID] = [hDED].[rf_atc_ClaimKindID]
go

