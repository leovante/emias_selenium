CREATE VIEW [V_stt_DietTable] AS SELECT 
[hDED].[DietTableID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_PatientAgentID] as [rf_PatientAgentID], 
[jT_stt_PatientAgent].[Surname] as [SILENT_rf_PatientAgentID], 
[hDED].[rf_DietID] as [rf_DietID], 
[jT_stt_Diet].[Name] as [SILENT_rf_DietID], 
[hDED].[rf_AgentDietID] as [rf_AgentDietID], 
[jT_stt_Diet1].[Name] as [SILENT_rf_AgentDietID], 
[hDED].[Date] as [Date], 
[hDED].[Description] as [Description], 
[hDED].[UGUID] as [UGUID], 
[hDED].[TimesPerDay] as [TimesPerDay], 
[hDED].[TimesPerDayAgent] as [TimesPerDayAgent]
FROM [stt_DietTable] as [hDED]
INNER JOIN [stt_PatientAgent] as [jT_stt_PatientAgent] on [jT_stt_PatientAgent].[PatientAgentID] = [hDED].[rf_PatientAgentID]
INNER JOIN [stt_Diet] as [jT_stt_Diet] on [jT_stt_Diet].[DietID] = [hDED].[rf_DietID]
INNER JOIN [stt_Diet] as [jT_stt_Diet1] on [jT_stt_Diet1].[DietID] = [hDED].[rf_AgentDietID]
go

