CREATE VIEW [V_dent_CPITN] AS SELECT 
[hDED].[CPITNID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_CardID] as [rf_CardID], 
[jT_dent_Card].[IsActive] as [SILENT_rf_CardID], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[Number] as [Number], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [dent_CPITN] as [hDED]
INNER JOIN [dent_Card] as [jT_dent_Card] on [jT_dent_Card].[CardID] = [hDED].[rf_CardID]
go

