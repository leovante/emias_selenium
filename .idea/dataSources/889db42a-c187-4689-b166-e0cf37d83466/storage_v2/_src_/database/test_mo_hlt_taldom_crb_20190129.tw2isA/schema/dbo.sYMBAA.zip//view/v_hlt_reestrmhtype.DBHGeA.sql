CREATE VIEW [V_hlt_ReestrMHType] AS SELECT 
[hDED].[ReestrMHTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[jT_oms_kl_DepartmentType].[Name] as [SILENT_rf_kl_DepartmentTypeID], 
[hDED].[Code] as [Code], 
[hDED].[Flags] as [Flags], 
[hDED].[Name] as [Name], 
[hDED].[Rem] as [Rem], 
[hDED].[Name_File] as [Name_File], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E]
FROM [hlt_ReestrMHType] as [hDED]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
go

