CREATE VIEW [V_oms_LG_Person] AS SELECT 
[hDED].[LG_PersonID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_PersonID] as [rf_PersonID], 
[hDED].[rf_KATLID] as [rf_KATLID], 
[jT_oms_KATL].[C_KATL] as [SILENT_rf_KATLID], 
[hDED].[DATE_BL] as [DATE_BL], 
[hDED].[DATE_EL] as [DATE_EL], 
[hDED].[NAME_DL] as [NAME_DL], 
[hDED].[SN_DL] as [SN_DL], 
[hDED].[S_DL] as [S_DL], 
[hDED].[N_DL] as [N_DL], 
[hDED].[Name] as [Name]
FROM [oms_LG_Person] as [hDED]
INNER JOIN [oms_KATL] as [jT_oms_KATL] on [jT_oms_KATL].[KATLID] = [hDED].[rf_KATLID]
go

