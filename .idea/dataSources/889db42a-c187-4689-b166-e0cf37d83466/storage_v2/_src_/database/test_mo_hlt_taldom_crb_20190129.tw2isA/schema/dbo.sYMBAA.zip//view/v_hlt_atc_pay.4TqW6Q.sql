CREATE VIEW [V_hlt_atc_Pay] AS SELECT 
[hDED].[atc_PayID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_atc_PayAmountID] as [rf_atc_PayAmountID], 
[jT_hlt_atc_PayAmount].[Amount] as [SILENT_rf_atc_PayAmountID], 
[hDED].[rf_PayRequisiteID] as [rf_PayRequisiteID], 
[jT_hlt_PayRequisite].[AccountNumber] as [SILENT_rf_PayRequisiteID], 
[hDED].[IsPersonal] as [IsPersonal], 
[hDED].[MonthPay] as [MonthPay], 
[hDED].[YearPay] as [YearPay], 
[hDED].[UGUID] as [UGUID]
FROM [hlt_atc_Pay] as [hDED]
INNER JOIN [hlt_atc_PayAmount] as [jT_hlt_atc_PayAmount] on [jT_hlt_atc_PayAmount].[atc_PayAmountID] = [hDED].[rf_atc_PayAmountID]
INNER JOIN [hlt_PayRequisite] as [jT_hlt_PayRequisite] on [jT_hlt_PayRequisite].[PayRequisiteID] = [hDED].[rf_PayRequisiteID]
go

