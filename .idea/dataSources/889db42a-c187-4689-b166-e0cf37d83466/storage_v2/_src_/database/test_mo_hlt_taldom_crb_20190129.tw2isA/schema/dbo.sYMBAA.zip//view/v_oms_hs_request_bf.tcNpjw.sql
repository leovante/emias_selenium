CREATE VIEW [V_oms_hs_request_bf] AS SELECT 
[hDED].[hs_request_bfID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUID] as [rf_LPUID], 
[jT_oms_LPU].[M_NAMES] as [SILENT_rf_LPUID], 
[hDED].[request_bf_ext_id] as [request_bf_ext_id], 
[hDED].[description] as [description], 
[hDED].[comment] as [comment], 
[hDED].[state] as [state], 
[hDED].[state_text] as [state_text], 
[hDED].[url_file] as [url_file], 
[hDED].[date_request] as [date_request]
FROM [oms_hs_request_bf] as [hDED]
INNER JOIN [oms_LPU] as [jT_oms_LPU] on [jT_oms_LPU].[LPUID] = [hDED].[rf_LPUID]
go

