CREATE VIEW [V_stt_DeathCertificate] AS SELECT 
[hDED].[DeathCertificateID], [hDED].[x_Edition], [hDED].[x_Status], 
(S_DeathCertificate+ ' ' + N_DeathCertificate
) as [V_SNCertificate], 
((Family + ' ' + [hDED].[Name] + ' ' + OT)) as [V_FIO], 
(S_Doc+ ' ' + N_Doc
) as [V_SNDOC], 
[hDED].[rf_TYPEDOCID] as [rf_TYPEDOCID], 
[hDED].[rf_DeadID] as [rf_DeadID], 
[hDED].[rf_TypeDeathCertificateID] as [rf_TypeDeathCertificateID], 
[hDED].[S_DeathCertificate] as [S_DeathCertificate], 
[hDED].[N_DeathCertificate] as [N_DeathCertificate], 
[hDED].[Date_DeathCertificate] as [Date_DeathCertificate], 
[hDED].[Family] as [Family], 
[hDED].[Name] as [Name], 
[hDED].[OT] as [OT], 
[hDED].[S_Doc] as [S_Doc], 
[hDED].[N_Doc] as [N_Doc], 
[hDED].[IssuedOrganisation] as [IssuedOrganisation], 
[hDED].[Date_Doc] as [Date_Doc], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flags] as [flags]
FROM [stt_DeathCertificate] as [hDED]
go

