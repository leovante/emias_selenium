CREATE VIEW [V_oms_ServiceMedical] AS SELECT 
[hDED].[ServiceMedicalID], [hDED].[x_Edition], [hDED].[x_Status], 
(hDED.GUIDSM) as [V_GUIDSM], 
[jT_oms_ServiceMedical].[ServiceMedicalCode] as [V_ServiceMedicalCode], 
[jT_oms_kl_AgeGroup].[Name] as [V_AgeName], 
[jT_oms_kl_DepartmentProfile].[Name] as [V_ProfName], 
[jT_oms_kl_MedCareUnit].[Name] as [V_UnitName], 
[jT_oms_kl_DepartmentType].[Name] as [V_TypeName], 
[hDED].[rf_PRVDID] as [rf_PRVDID], 
[jT_oms_PRVD].[NAME] as [SILENT_rf_PRVDID], 
[hDED].[rf_PRVSID] as [rf_PRVSID], 
[jT_oms_PRVS].[PRVS_NAME] as [SILENT_rf_PRVSID], 
[hDED].[rf_kl_AgeGroupID] as [rf_kl_AgeGroupID], 
[hDED].[rf_ServiceMedicalID] as [rf_ServiceMedicalID], 
[jT_oms_ServiceMedical].[ServiceMedicalName] as [SILENT_rf_ServiceMedicalID], 
[hDED].[rf_kl_VisitTypeID] as [rf_kl_VisitTypeID], 
[hDED].[rf_kl_NomServiceID] as [rf_kl_NomServiceID], 
[hDED].[rf_kl_DDServiceID] as [rf_kl_DDServiceID], 
[hDED].[rf_kl_MedCareTypeID] as [rf_kl_MedCareTypeID], 
[hDED].[rf_kl_MedCareLicenceID] as [rf_kl_MedCareLicenceID], 
[hDED].[rf_kl_MedCareUnitID] as [rf_kl_MedCareUnitID], 
[hDED].[rf_kl_OperationTypeID] as [rf_kl_OperationTypeID], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[rf_kl_DepartmentTypeID] as [rf_kl_DepartmentTypeID], 
[hDED].[rf_kl_DepartmentProfileID] as [rf_kl_DepartmentProfileID], 
[hDED].[rf_sc_StandartCureID] as [rf_sc_StandartCureID], 
[hDED].[rf_kl_MetodHMPID] as [rf_kl_MetodHMPID], 
[jT_oms_kl_MetodHMP].[NameMetod] as [SILENT_rf_kl_MetodHMPID], 
[hDED].[rf_kl_ActionTeethID] as [rf_kl_ActionTeethID], 
[jT_oms_kl_ActionTeeth].[Name] as [SILENT_rf_kl_ActionTeethID], 
[hDED].[ServiceMedicalName] as [ServiceMedicalName], 
[hDED].[ServiceMedicalCode] as [ServiceMedicalCode], 
[hDED].[GUIDSM] as [GUIDSM], 
[hDED].[IDServ] as [IDServ], 
[hDED].[DOC] as [DOC], 
[hDED].[Date_B] as [Date_B], 
[hDED].[Date_E] as [Date_E], 
[hDED].[FCode_Usl] as [FCode_Usl], 
[hDED].[Info] as [Info], 
[hDED].[isComplex] as [isComplex], 
[hDED].[Flags] as [Flags], 
[hDED].[Warranty] as [Warranty]
FROM [oms_ServiceMedical] as [hDED]
INNER JOIN [oms_ServiceMedical] as [jT_oms_ServiceMedical] on [jT_oms_ServiceMedical].[ServiceMedicalID] = [hDED].[rf_ServiceMedicalID]
INNER JOIN [oms_kl_AgeGroup] as [jT_oms_kl_AgeGroup] on [jT_oms_kl_AgeGroup].[kl_AgeGroupID] = [hDED].[rf_kl_AgeGroupID]
INNER JOIN [oms_kl_DepartmentProfile] as [jT_oms_kl_DepartmentProfile] on [jT_oms_kl_DepartmentProfile].[kl_DepartmentProfileID] = [hDED].[rf_kl_DepartmentProfileID]
INNER JOIN [oms_kl_MedCareUnit] as [jT_oms_kl_MedCareUnit] on [jT_oms_kl_MedCareUnit].[kl_MedCareUnitID] = [hDED].[rf_kl_MedCareUnitID]
INNER JOIN [oms_kl_DepartmentType] as [jT_oms_kl_DepartmentType] on [jT_oms_kl_DepartmentType].[kl_DepartmentTypeID] = [hDED].[rf_kl_DepartmentTypeID]
INNER JOIN [oms_PRVD] as [jT_oms_PRVD] on [jT_oms_PRVD].[PRVDID] = [hDED].[rf_PRVDID]
INNER JOIN [oms_PRVS] as [jT_oms_PRVS] on [jT_oms_PRVS].[PRVSID] = [hDED].[rf_PRVSID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
INNER JOIN [oms_kl_MetodHMP] as [jT_oms_kl_MetodHMP] on [jT_oms_kl_MetodHMP].[kl_MetodHMPID] = [hDED].[rf_kl_MetodHMPID]
INNER JOIN [oms_kl_ActionTeeth] as [jT_oms_kl_ActionTeeth] on [jT_oms_kl_ActionTeeth].[kl_ActionTeethID] = [hDED].[rf_kl_ActionTeethID]
go

