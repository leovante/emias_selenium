CREATE VIEW [V_oms_Protokol] AS SELECT 
[hDED].[ProtokolID], [hDED].[x_Edition], [hDED].[x_Status], 
(( ((isnull((Select count(*) from oms_Tender where rf_ProtokolID = [hDED].[ProtokolID]), 0) )) )) as [V_TenderCount], 
[jT_oms_SFO].[FO_NAMES] as [V_FO_NAMES], 
[jT_oms_SFO].[FO_OGRN] as [V_FO_OGRN], 
[hDED].[rf_SFOID] as [rf_SFOID], 
[hDED].[rf_FinlID] as [rf_FinlID], 
[jT_oms_Finl].[NAME] as [SILENT_rf_FinlID], 
[hDED].[rf_SendStateID] as [rf_SendStateID], 
[jT_oms_SendState].[Description] as [SILENT_rf_SendStateID], 
[hDED].[rf_ProtokolStateID] as [rf_ProtokolStateID], 
[jT_oms_ProtokolState].[Name] as [SILENT_rf_ProtokolStateID], 
[hDED].[Rem] as [Rem], 
[hDED].[Date_BP] as [Date_BP], 
[hDED].[Date_EP] as [Date_EP], 
[hDED].[ProtokolGUID] as [ProtokolGUID], 
[hDED].[Num] as [Num], 
[hDED].[Date] as [Date], 
[hDED].[Author] as [Author], 
[hDED].[DateProtokol] as [DateProtokol], 
[hDED].[FinYear] as [FinYear], 
[hDED].[Flags] as [Flags], 
[hDED].[AuctionInfo] as [AuctionInfo], 
[hDED].[Amount] as [Amount], 
[hDED].[Sup_OKOPF] as [Sup_OKOPF], 
[hDED].[Sup_INN] as [Sup_INN], 
[hDED].[Sup_KPP] as [Sup_KPP], 
[hDED].[Sup_Name] as [Sup_Name]
FROM [oms_Protokol] as [hDED]
INNER JOIN [oms_SFO] as [jT_oms_SFO] on [jT_oms_SFO].[SFOID] = [hDED].[rf_SFOID]
INNER JOIN [oms_Finl] as [jT_oms_Finl] on [jT_oms_Finl].[FinlID] = [hDED].[rf_FinlID]
INNER JOIN [oms_SendState] as [jT_oms_SendState] on [jT_oms_SendState].[SendStateID] = [hDED].[rf_SendStateID]
INNER JOIN [oms_ProtokolState] as [jT_oms_ProtokolState] on [jT_oms_ProtokolState].[ProtokolStateID] = [hDED].[rf_ProtokolStateID]
go

