CREATE VIEW [V_stt_PathologicalReactionType] AS SELECT 
[hDED].[PathologicalReactionTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME], 
[hDED].[PARENT] as [PARENT], 
[hDED].[SCTID] as [SCTID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_PathologicalReactionType] as [hDED]
go

