
create FUNCTION [dbo].[GetKRR_old](
@date datetime,
@lpuid int,
@profileId int,
@typeid  int,
@usl1 varchar(20),
@usl2 varchar(20),
@mkb int,
@age int,
@dlit int,
@prervxml varchar(max)
)
RETURNS @result TABLE (
vidID int,
info varchar(max),
[Value] [decimal](38, 6) NULL

)
AS
begin
Declare @xml xml
declare @Sh varchar(max)
declare @Op varchar(max)
declare @DopDS varchar(max)
declare @prerv varchar(10)
set @xml =convert(xml,@prervxml)

set @Sh=''
set @Op=''
set @DopDs=''
set @prerv=''

select  @Sh= t.x.value('@Sh[1]',  'varchar(max)'),
@Op=t.x.value('@Op[1]',  'varchar(max)')
from @xml.nodes('/a') t(x) 

select  @DopDs=t.x.value('@DopDS[1]',  'varchar(max)')
from @xml.nodes('/b') t(x) 

select  top 1 @prerv=Code
 from (
select t.x.value('@dateOut[1]',  'datetime') as Dt, 
  t.x.value('@rf_kl_DepartmentTypeId[1]', 'int') as DepartementTypeID,
  t.x.value('@rf_lpuid[1]', 'int') as lpuid,
  t.x.value('@rf_kl_DepartmentProfileID[1]','int') as DepartementProfileID,
  t.x.value('@Code[1]','varchar') as Code
from   @xml.nodes('/Prerv ') as t(x)
  )t 
where lpuid=@lpuid and @profileId =DepartementProfileID and DepartementTypeID=@typeid


INSERT INTO @result
select (select krrVidId from oms_krrvid where vidK_Code ='KR1'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR1' and @age<=3 and @typeid=rf_kl_DepartmentTypeid and
 @usl1  not in ('181107','181108','181109','181110','181111','181112','181113')
  and @usl1  not like '%[-]%'
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='СверхОп'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='СверхОп' and @typeid=rf_kl_DepartmentTypeid and @usl1 not in ('181003','181004','181005','181011','181012','181016','181071','181092','181086','181099','181032','181033','181034','181144','181145','181146','181147','181148','181149','181150','181151','181152','181153','181154','181155','181156','181157','181167','181168','181172','181173','181174','181198','181219','181271','181301','181314','181316','181317.1','181317.2','181320','182006','182007','182014','182015','182016','182052','182053','182054','182055','182056','182057','182058','182059','182060','182061','182062','182063','182022','182023','182024','182025','182026')  and  @dlit<=3 and @usl2 like 'A16.%' and @usl1  not like '%[-]%' union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='Сверх'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='Сверх' and @typeid=rf_kl_DepartmentTypeid and @usl1 not in ('181003','181004','181005','181011','181012','181016','181071','181092','181086','181099','181032','181033','181034','181144','181145','181146','181147','181148','181149','181150','181151','181152','181153','181154','181155','181156','181157','181167','181168','181172','181173','181174','181198','181219','181271','181301','181314','181316','181317.1','181317.2','181320','182006','182007','182014','182015','182016','182052','182053','182054','182055','182056','182057','182058','182059','182060','182061','182062','182063','182022','182023','182024','182025','182026')  and  @dlit<=3 and @usl2 not like 'A16%' union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='1'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='1' and @typeid=rf_kl_DepartmentTypeid and @usl1  not like '%[-]%'
 union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR2'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR2' and @age>=75 and @usl1 not in   ('181144','181145','181146','181147','181148','181149','181150', '181151','181152','181153','181154','181155','181156', '181157', '181160','181161','181162') and @typeid=rf_kl_DepartmentTypeid union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR3'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR3' and @typeid=rf_kl_DepartmentTypeid and dbo.IsPathology(@DopDS)>0  union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR4'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR4' and @typeid=rf_kl_DepartmentTypeid and dbo.IsPathology(@DopDS)>0  union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='KR5'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId  where  V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and VidK_Code='KR5' and @typeid=rf_kl_DepartmentTypeid and dbo.IsKSLP5(@Op,@Sh )>0  union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='ПрервОп'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and @prerv like '%П%' and VidK_Code='ПрервОп' and @typeid=rf_kl_DepartmentTypeid and @usl1 not in ('181003','181004','181005','181011','181012','181016','181071','181092','181086','181099','181032','181033','181034','181144','181145','181146','181147','181148','181149','181150','181151','181152','181153','181154','181155','181156','181157','181167','181168','181172','181173','181174','181198','181219','181271','181301','181314','181316','181317.1','181317.2','181320','182006','182007','182014','182015','182016','182052','182053','182054','182055','182056','182057','182058','182059','182060','182061','182062','182063','182022','182023','182024','182025','182026')  and  @dlit>3 and @usl2 like 'A16.%' and @usl1  not like '%[-]%' union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='Прерв'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and @prerv = 'П' and VidK_Code='Прерв' and @typeid=rf_kl_DepartmentTypeid and @usl1 not in ('181003','181004','181005','181011','181012','181016','181071','181092','181086','181099','181032','181033','181034','181144','181145','181146','181147','181148','181149','181150','181151','181152','181153','181154','181155','181156','181157','181167','181168','181172','181173','181174','181198','181219','181271','181301','181314','181316','181317.1','181317.2','181320','182006','182007','182014','182015','182016','182052','182053','182054','182055','182056','182057','182058','182059','182060','182061','182062','182063','182022','182023','182024','182025','182026')  and  @dlit>3 and @usl2 not like 'A16%' union 
 
  select (select krrVidId from oms_krrvid where vidK_Code ='ЛетальныйИ'),'',valueKRR from V_oms_krr inner join oms_krrvid on krrvidId= rf_KrrvidId where V_oms_krr.date_E>=@date and V_oms_krr.date_B<@date and @prerv like '%Л%' and VidK_Code='ЛетальныйИ' and @typeid=rf_kl_DepartmentTypeid and @usl1 not in ('181003','181004','181005','181011','181012','181016','181071','181092','181086','181099','181032','181033','181034','181144','181145','181146','181147','181148','181149','181150','181151','181152','181153','181154','181155','181156','181157','181167','181168','181172','181173','181174','181198','181219','181271','181301','181314','181316','181317.1','181317.2','181320','182006','182007','182014','182015','182016','182052','182053','182054','182055','182056','182057','182058','182059','182060','182061','182062','182063','182022','182023','182024','182025','182026')  and  @dlit>3 and @dlit<9 
 
 
 
 declare @info varchar(max)
 set @info=''

  return end
go

