CREATE VIEW [V_oms_SMexpertState] AS SELECT 
[hDED].[SMexpertStateID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name]
FROM [oms_SMexpertState] as [hDED]
go

