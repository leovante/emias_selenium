CREATE VIEW [V_stt_Anamnez] AS SELECT 
[hDED].[AnamnezID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [V_V_DocInfo], 
[jT_stt_TemplateType].[Name] as [V_Name], 
[hDED].[rf_DoctorID] as [rf_DoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_DoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_MedicalHistoryID] as [rf_MedicalHistoryID], 
[hDED].[rf_TemplateTypeID] as [rf_TemplateTypeID], 
[jT_stt_TemplateType].[Name] as [SILENT_rf_TemplateTypeID], 
[hDED].[rf_DeadID] as [rf_DeadID], 
[hDED].[rf_FHJournalCallID] as [rf_FHJournalCallID], 
[hDED].[Flag] as [Flag], 
[hDED].[Date] as [Date], 
[hDED].[Note] as [Note], 
[hDED].[UGUID] as [UGUID], 
[hDED].[XMLData] as [XMLData], 
[hDED].[rf_DocRecordID] as [rf_DocRecordID], 
[hDED].[rf_DocTypeDefGUID] as [rf_DocTypeDefGUID], 
[hDED].[Signature] as [Signature], 
[hDED].[isSigned] as [isSigned], 
[hDED].[CRC] as [CRC], 
[hDED].[rf_JournalCallID] as [rf_JournalCallID], 
[hDED].[PrivilegeCod] as [PrivilegeCod]
FROM [stt_Anamnez] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_DoctorID]
INNER JOIN [stt_TemplateType] as [jT_stt_TemplateType] on [jT_stt_TemplateType].[TemplateTypeID] = [hDED].[rf_TemplateTypeID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
go

