CREATE VIEW [V_stt_BedType] AS SELECT 
[hDED].[BedTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CODE] as [CODE], 
[hDED].[Name] as [Name]
FROM [stt_BedType] as [hDED]
go

