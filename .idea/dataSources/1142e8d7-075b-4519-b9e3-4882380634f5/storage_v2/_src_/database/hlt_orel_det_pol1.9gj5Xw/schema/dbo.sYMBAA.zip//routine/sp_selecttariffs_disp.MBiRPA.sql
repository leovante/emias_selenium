
CREATE procedure [dbo].[sp_selectTariffs_disp]
			@dateSm datetime,
			@docPrvdId int,
			@departmentId int,		
			@reasonTypeId int,		
			@mkabId int,
			@serviceMedicalId int,
			@result varchar(254) output -- Выходной параметр в случае ошибки или доп.инфо
	as
	begin
		set @result = '' -- Информационное сообщение, в случае ошибки или доп.инфо.

		-- Дополнительные параметры, получаем из входных
		declare @depTypeId int,
				@lpuId int,
				@otdId int,
			    @prvdId int,
				@prvsId int;
				
/* Скрипт для Орловской Области. Modifided: Vafflg */
-----------------------------------------------------------------------------------------------------------------------------------------------------
		/* Получаем значения Типа отделения и Id самого отделения */
		select @depTypeId = ISNULL(rf_kl_DepartmentTypeID, 0), @otdId = ISNULL(rf_LPUID, 0) from oms_Department where DepartmentID = @departmentId;

		/* Получаем значения ИД ЛПУ из таблицы oms_lpu*/
		/* Если есть хотя бы один действующий тариф на текущее подразделение, то берем LPUID подразделения, если тарифа нет, то берем LPUID Юр. Лица*/
		SELECT @lpuId = IIF ((SELECT count(rf_LPUID) FROM [dbo].[oms_Tariff] WHERE rf_LPUID = @otdId AND (Date_B <=  @dateSm) AND (@dateSm  <= Date_E)) > 0, @otdId, rf_mainlpuid) from oms_lpu where LPUID = @otdId

		/* Получаем значения ИД должности и специлальности из занимаемой должности врача (hlt_DocPrvd) */
		select @prvdId = ISNULL(rf_PRVDID, 0), @prvsId = ISNULL(rf_PRVSID, 0) from hlt_DocPRVD where DocPRVDID = @docPrvdId;
------------------------------------------------------------------------------------------------------------------------------------------------------
		SELECT top 1 
			tariff.TariffID as [Id],
			tariff.GUIDTariff as [UGuid],
			tariff.Value1 as [Value1],
			tariff.Value2 as [Value2],
			tariff.Value3 as [Value3],
			tariff.Value4 as [Value4],
			tariff.Date_B as [Begin],
			tariff.Date_E as [End],
			tariff.rf_LPUID as [LpuId],
			tariff.rf_kl_ReasonTypeID as [ReasonTypeId],
			tariff.rf_ServiceMedicalID as [ServiceMedicalId],
			sm.Info as SmInfo,
			case when sm.Info = 'UE' then 1  else 0 end as IsStomatInfo	
		from [dbo].[oms_Tariff] tariff
			inner join [dbo].[oms_ServiceMedical] as sm on tariff.rf_ServiceMedicalID = sm.ServiceMedicalID
			inner join [dbo].[oms_LPU] lpu on tariff.rf_LPUID = lpu.LPUID
			inner join [dbo].[oms_kl_ReasonType] rt on tariff.rf_kl_ReasonTypeID = rt.kl_ReasonTypeID
			INNER JOIN [dbo].[oms_kl_AgeGroup] AS AgeGroup ON tariff.rf_kl_AgeGroupID = AgeGroup.kl_AgeGroupID
		where tariff.TariffID > 0 
			AND sm.ServiceMedicalID = @serviceMedicalId
			AND lpu.LPUID in (0, @lpuId)
			AND rt.kl_ReasonTypeID in (0, @reasonTypeId)
			AND ((tariff.[Date_B] <= @dateSm) 
			AND (@dateSm <= tariff.[Date_E])) 
			and (AgeGroup.kl_AgeGroupID = 0 OR AgeGroup.CODE = '3' OR AgeGroup.CODE = 
			case when (select dbo.FullYearAge(hltMKAB.DATE_BD, @dateSm) 
			from hlt_MKAB hltMKAB where hltMKAB.MKABID = @mkabId) >= 18 then '1' else '2' end)
			and tariff.rf_PRVSID=case when (select count(1) from [oms_Tariff] trf where trf.rf_ServiceMedicalID = @serviceMedicalId and trf.Date_E>=@dateSm ) <1 then 0 else @prvsId end
	end
go

