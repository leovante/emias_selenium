CREATE VIEW [V_oms_DocTemplatyRec] AS SELECT 
[hDED].[DocTemplatyRecID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DocTemplatyID] as [rf_DocTemplatyID], 
[jT_oms_DocTemplaty].[Name] as [SILENT_rf_DocTemplatyID], 
[hDED].[Kol] as [Kol], 
[hDED].[Text_SQL] as [Text_SQL], 
[hDED].[Report_SQL] as [Report_SQL], 
[hDED].[Rep_Kol] as [Rep_Kol], 
[hDED].[Flags] as [Flags]
FROM [oms_DocTemplatyRec] as [hDED]
INNER JOIN [oms_DocTemplaty] as [jT_oms_DocTemplaty] on [jT_oms_DocTemplaty].[DocTemplatyID] = [hDED].[rf_DocTemplatyID]
go

