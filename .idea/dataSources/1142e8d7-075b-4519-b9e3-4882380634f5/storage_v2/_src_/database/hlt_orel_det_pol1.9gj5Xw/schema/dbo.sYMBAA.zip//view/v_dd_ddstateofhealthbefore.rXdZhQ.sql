CREATE VIEW [V_dd_DDStateOfHealthBefore] AS SELECT 
[hDED].[DDStateOfHealthBeforeID], [hDED].[x_Edition], [hDED].[x_Status], 
(case AfterCheckUpRealization when -1 then 'Не назначено'
when 1 then 'Начато'
when 2 then 'Выполнено'
else 'Не проведено'
end) as [V_ACUR], 
(case MedicalTreatmentRealization
when -1 then 'Не назначено'
when 1 then 'Начато'
when 2 then 'Выполнено'
else 'Не проведено'
end) as [V_MTR], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_DDChildFormID] as [rf_DDChildFormID], 
[jT_dd_DDChildForm].[v_FIO] as [SILENT_rf_DDChildFormID], 
[hDED].[Flag] as [Flag], 
[hDED].[AfterCheckUp] as [AfterCheckUp], 
[hDED].[AfterCheckUpRealization] as [AfterCheckUpRealization], 
[hDED].[MedicalTreatment] as [MedicalTreatment], 
[hDED].[MedicalTreatmentRealization] as [MedicalTreatmentRealization]
FROM [dd_DDStateOfHealthBefore] as [hDED]
INNER JOIN [V_dd_DDChildForm] as [jT_dd_DDChildForm] on [jT_dd_DDChildForm].[DDChildFormID] = [hDED].[rf_DDChildFormID]
go

