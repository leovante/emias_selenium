CREATE VIEW [V_stt_MedCardType] AS SELECT 
[hDED].[MedCardTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[EnumName] as [EnumName], 
[hDED].[Name] as [Name], 
[hDED].[Description] as [Description], 
[hDED].[Code] as [Code]
FROM [stt_MedCardType] as [hDED]
go

