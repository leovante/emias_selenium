CREATE VIEW [V_stt_MedStage] AS SELECT 
[hDED].[MedStageID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_LPUDoctorID] as [rf_LPUDoctorID], 
[jT_hlt_LPUDoctor].[V_DocInfo] as [SILENT_rf_LPUDoctorID], 
[hDED].[rf_DocPRVDID] as [rf_DocPRVDID], 
[jT_hlt_DocPRVD].[Name] as [SILENT_rf_DocPRVDID], 
[hDED].[rf_sc_StandartCureID] as [rf_sc_StandartCureID], 
[jT_oms_sc_StandartCure].[StandartName] as [SILENT_rf_sc_StandartCureID], 
[hDED].[rf_MigrationPatientID] as [rf_MigrationPatientID], 
[jT_stt_MigrationPatient].[rf_StationarBranchID] as [SILENT_rf_MigrationPatientID], 
[hDED].[rf_StationarBranchID] as [rf_StationarBranchID], 
[jT_stt_StationarBranch].[V_BranchInfo] as [SILENT_rf_StationarBranchID], 
[hDED].[rf_DiagnosID] as [rf_DiagnosID], 
[jT_stt_Diagnos].[Date] as [SILENT_rf_DiagnosID], 
[hDED].[rf_BedProfileID] as [rf_BedProfileID], 
[jT_stt_BedProfile].[Name] as [SILENT_rf_BedProfileID], 
[hDED].[DateBegin] as [DateBegin], 
[hDED].[DateEnd] as [DateEnd], 
[hDED].[Description] as [Description], 
[hDED].[Duration] as [Duration], 
[hDED].[isComplete] as [isComplete], 
[hDED].[UGUID] as [UGUID], 
[hDED].[flag] as [flag]
FROM [stt_MedStage] as [hDED]
INNER JOIN [V_hlt_LPUDoctor] as [jT_hlt_LPUDoctor] on [jT_hlt_LPUDoctor].[LPUDoctorID] = [hDED].[rf_LPUDoctorID]
INNER JOIN [hlt_DocPRVD] as [jT_hlt_DocPRVD] on [jT_hlt_DocPRVD].[DocPRVDID] = [hDED].[rf_DocPRVDID]
INNER JOIN [oms_sc_StandartCure] as [jT_oms_sc_StandartCure] on [jT_oms_sc_StandartCure].[sc_StandartCureID] = [hDED].[rf_sc_StandartCureID]
INNER JOIN [stt_MigrationPatient] as [jT_stt_MigrationPatient] on [jT_stt_MigrationPatient].[MigrationPatientID] = [hDED].[rf_MigrationPatientID]
INNER JOIN [V_stt_StationarBranch] as [jT_stt_StationarBranch] on [jT_stt_StationarBranch].[StationarBranchID] = [hDED].[rf_StationarBranchID]
INNER JOIN [stt_Diagnos] as [jT_stt_Diagnos] on [jT_stt_Diagnos].[DiagnosID] = [hDED].[rf_DiagnosID]
INNER JOIN [stt_BedProfile] as [jT_stt_BedProfile] on [jT_stt_BedProfile].[BedProfileID] = [hDED].[rf_BedProfileID]
go

