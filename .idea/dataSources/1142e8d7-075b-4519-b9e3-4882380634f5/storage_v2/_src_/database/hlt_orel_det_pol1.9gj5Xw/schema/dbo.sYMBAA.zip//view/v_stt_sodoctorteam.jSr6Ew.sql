CREATE VIEW [V_stt_SODoctorTeam] AS SELECT 
[hDED].[SODoctorTeamID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_DoctorID] as [rf_DoctorID], 
[hDED].[rf_SurgicalOperationID] as [rf_SurgicalOperationID], 
[hDED].[rf_DoctorPositionID] as [rf_DoctorPositionID], 
[hDED].[Num] as [Num], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [stt_SODoctorTeam] as [hDED]
go

