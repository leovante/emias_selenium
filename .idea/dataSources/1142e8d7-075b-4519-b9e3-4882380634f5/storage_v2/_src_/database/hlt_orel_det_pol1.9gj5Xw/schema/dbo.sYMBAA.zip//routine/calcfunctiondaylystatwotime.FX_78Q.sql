
CREATE FUNCTION [dbo].[CalcFunctionDaylyStatWOTime]

(

      @beginHosp datetime, @endHosp datetime, @StartHospitalTime datetime

)

RETURNS int

AS

BEGIN

 

      declare @t date,  @d date

      declare @dt int , @ts int

      set @t= @endHosp

 

      if (CONVERT(datetime,@endHosp,121)='1900-01-01 00:00:00') return 0

      if(@t<@beginHosp)

      begin

            set @endHosp = @beginHosp

        set @beginHosp = @t

      end

     

      set @dt=DATEDIFF(dd,convert(date,@beginHosp),convert(date,@endHosp))

     

      if (@dt=0) set @dt=1

      if(convert(date,@beginHosp)<>convert(date,@endHosp))

            set @dt=@dt+1

 

      RETURN @dt

 

END
go

