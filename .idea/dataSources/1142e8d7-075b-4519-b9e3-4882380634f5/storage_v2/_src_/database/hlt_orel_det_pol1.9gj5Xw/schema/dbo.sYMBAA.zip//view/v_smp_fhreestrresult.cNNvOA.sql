CREATE VIEW [V_smp_FHReestrResult] AS SELECT 
[hDED].[FHReestrResultID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_FHReestrOccasionID] as [rf_FHReestrOccasionID], 
[jT_smp_FHReestrOccasion].[rf_JournalCallID] as [SILENT_rf_FHReestrOccasionID], 
[hDED].[rf_FHReestrPositionID] as [rf_FHReestrPositionID], 
[jT_smp_FHReestrPosition].[rf_MedServiceID] as [SILENT_rf_FHReestrPositionID], 
[hDED].[UGUID] as [UGUID], 
[hDED].[Res_Name] as [Res_Name], 
[hDED].[ID_Rec] as [ID_Rec], 
[hDED].[N_Rec] as [N_Rec]
FROM [smp_FHReestrResult] as [hDED]
INNER JOIN [smp_FHReestrOccasion] as [jT_smp_FHReestrOccasion] on [jT_smp_FHReestrOccasion].[FHReestrOccasionID] = [hDED].[rf_FHReestrOccasionID]
INNER JOIN [smp_FHReestrPosition] as [jT_smp_FHReestrPosition] on [jT_smp_FHReestrPosition].[FHReestrPositionID] = [hDED].[rf_FHReestrPositionID]
go

