CREATE FUNCTION stroka_Deti57 (@MKB_CODES as nvarchar(4000), @DateBegin datetime, @DateEnd datetime)
RETURNS TABLE
AS
RETURN (
Select 
/*Пациенты, имеющие 2 и более травмы (отравления), показываются по соответствующим строкам по числу 
выявленных и зарегистрированных травм (отравлений) при единице измерения - человек.*/ 
count(distinct case when mkb_v.DS like 'V%' OR TRT.Name like '%ДТП%' then MKB.DS+cast(rf_MKABID as varchar)
when mkb_v.MKBID=0 and (TRT.Name like '%транспорт%') then MKB.DS+cast(rf_MKABID as varchar) else null end) as a5,
count(distinct case when TRT.Name like '%ДТП%' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a6,
count(distinct case when mkb_v.DS like 'V%' OR TRT.Name like '%ДТП%' then null
when mkb_v.MKBID=0 and (TRT.Name like '%транспорт%') then null 
when mkb_v.DS like 'W%' OR mkb_v.DS like 'X[0-5]%' OR mkb_v.MKBID=0 then MKB.DS+cast(rf_MKABID as varchar) else null end) as a7,
count(distinct case when mkb_v.DS between 'W65' and 'W74.9' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a8,
count(distinct case when mkb_v.DS between 'X00' and 'X09.9' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a9,
count(distinct case when mkb_v.DS between 'X40' and 'X49.9' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a10,
count(distinct case when mkb_v.DS like 'X42%' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a11,
count(distinct case when mkb_v.DS like 'X45%' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a12,
count(distinct case when mkb_v.DS between 'X60' and 'X84.9' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a13,
count(distinct case when mkb_v.DS like 'X62%' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a14,
count(distinct case when mkb_v.DS like 'X65%' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a15,
count(distinct case when mkb_v.DS between 'X85' and 'Y09.9' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a16,
count(distinct case when mkb_v.DS between 'Y10' and 'Y34.9' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a17,
count(distinct case when mkb_v.DS between 'Y35' and 'Y38.9' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a18,
count(distinct case when mkb_v.DS between 'Y40' and 'Y84.9' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a19,
count(distinct case when mkb_v.DS between 'Y85' and 'Y89.9' then MKB.DS+cast(rf_MKABID as varchar) else null end) as a20
from hlt_TAP WITH (NOLOCK)
inner join oms_kl_DiseaseType WITH (NOLOCK) on kl_DiseaseTypeID=rf_kl_DiseaseTypeID
inner join hlt_MKAB WITH (NOLOCK) ON MKABID=rf_MKABID
inner join oms_MKB MKB WITH (NOLOCK) ON MKB.MKBID=rf_MKBID
inner join selectByMKB(@MKB_CODES) FU on MKB.MKBID=FU.MKBID
inner join oms_kl_TraumaType TRT WITH (NOLOCK) on kl_TraumaTypeID=rf_kl_TraumaTypeID
inner join oms_MKB mkb_v WITH (NOLOCK) on mkb_v.MKBID=rf_MKBExternalID
inner join tmp_report_OKATO57 on OKATOID=hlt_MKAB.rf_OKATOID
inner join tmp_report_Dep57 on tmp_report_Dep57.DepartmentID=hlt_TAP.rf_DepartmentID 
where /*kl_TraumaTypeID>0 and*/ dbo.FullYearAge(hlt_MKAB.DATE_BD,hlt_TAP.DateClose) < 18
and (hlt_TAP.DateClose between @DateBegin and @DateEnd)
--and oms_kl_DiseaseType.Code='1'/*Регистрации подлежат все травмы и отравления со знаком "+"*/
)
go

