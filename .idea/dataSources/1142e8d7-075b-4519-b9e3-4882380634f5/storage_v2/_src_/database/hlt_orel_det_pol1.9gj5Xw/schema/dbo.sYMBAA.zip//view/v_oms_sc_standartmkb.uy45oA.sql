CREATE VIEW [V_oms_sc_StandartMKB] AS SELECT 
[hDED].[sc_StandartMKBID], [hDED].[x_Edition], [hDED].[x_Status], 
[jT_oms_sc_AgeRange].[V_Range] as [V_V_Range], 
[jT_oms_MKB].[NAME] as [V_NAME], 
[jT_oms_MKB].[DS] as [V_MKB], 
[hDED].[rf_MKBID] as [rf_MKBID], 
[hDED].[rf_kl_SexID] as [rf_kl_SexID], 
[jT_oms_kl_Sex].[Name] as [SILENT_rf_kl_SexID], 
[hDED].[rf_kl_ProfitTypeID] as [rf_kl_ProfitTypeID], 
[jT_oms_kl_ProfitType].[Name] as [SILENT_rf_kl_ProfitTypeID], 
[hDED].[rf_sc_AgeRangeID] as [rf_sc_AgeRangeID], 
[jT_oms_sc_AgeRange].[V_Range] as [SILENT_rf_sc_AgeRangeID], 
[hDED].[Flag] as [Flag], 
[hDED].[UGUID] as [UGUID]
FROM [oms_sc_StandartMKB] as [hDED]
INNER JOIN [V_oms_sc_AgeRange] as [jT_oms_sc_AgeRange] on [jT_oms_sc_AgeRange].[sc_AgeRangeID] = [hDED].[rf_sc_AgeRangeID]
INNER JOIN [oms_MKB] as [jT_oms_MKB] on [jT_oms_MKB].[MKBID] = [hDED].[rf_MKBID]
INNER JOIN [oms_kl_Sex] as [jT_oms_kl_Sex] on [jT_oms_kl_Sex].[kl_SexID] = [hDED].[rf_kl_SexID]
INNER JOIN [oms_kl_ProfitType] as [jT_oms_kl_ProfitType] on [jT_oms_kl_ProfitType].[kl_ProfitTypeID] = [hDED].[rf_kl_ProfitTypeID]
go

