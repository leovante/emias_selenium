CREATE VIEW [V_stt_BedAssigment] AS SELECT 
[hDED].[BedAssigmentID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_BedAssigment] as [hDED]
go

