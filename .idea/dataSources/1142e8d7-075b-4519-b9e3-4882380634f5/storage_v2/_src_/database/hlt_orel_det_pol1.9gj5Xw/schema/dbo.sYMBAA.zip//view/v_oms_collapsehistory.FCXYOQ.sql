CREATE VIEW [V_oms_CollapseHistory] AS SELECT 
[hDED].[CollapseHistoryID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[OldCode] as [OldCode], 
[hDED].[NewCode] as [NewCode], 
[hDED].[CollapseDate] as [CollapseDate], 
[hDED].[UGUID] as [UGUID], 
[hDED].[IsSuccessCod] as [IsSuccessCod], 
[hDED].[IsSuccessAu] as [IsSuccessAu], 
[hDED].[DateCreate] as [DateCreate], 
[hDED].[isRollbackCod] as [isRollbackCod], 
[hDED].[isRollbackAu] as [isRollbackAu], 
[hDED].[RollbackDate] as [RollbackDate], 
[hDED].[ClsGuid] as [ClsGuid]
FROM [oms_CollapseHistory] as [hDED]
go

