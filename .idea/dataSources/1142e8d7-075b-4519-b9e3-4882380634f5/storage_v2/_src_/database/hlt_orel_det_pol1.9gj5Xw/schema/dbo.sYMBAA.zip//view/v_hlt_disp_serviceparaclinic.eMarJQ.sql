CREATE VIEW [V_hlt_disp_ServiceParaclinic] AS SELECT 
[hDED].[disp_ServiceParaclinicID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_ServiceGuid] as [rf_ServiceGuid], 
[jT_hlt_disp_Service].[Name] as [SILENT_rf_ServiceGuid], 
[hDED].[rf_ResearchTypeGuid] as [rf_ResearchTypeGuid], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid]
FROM [hlt_disp_ServiceParaclinic] as [hDED]
INNER JOIN [hlt_disp_Service] as [jT_hlt_disp_Service] on [jT_hlt_disp_Service].[Guid] = [hDED].[rf_ServiceGuid]
go

