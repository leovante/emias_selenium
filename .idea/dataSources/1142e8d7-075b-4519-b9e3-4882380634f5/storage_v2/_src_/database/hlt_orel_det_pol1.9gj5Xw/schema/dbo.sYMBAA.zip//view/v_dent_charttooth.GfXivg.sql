CREATE VIEW [V_dent_ChartTooth] AS SELECT 
[hDED].[ChartToothID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[rf_disp_ExamID] as [rf_disp_ExamID], 
[jT_hlt_disp_Exam].[rf_ServiceGuid] as [SILENT_rf_disp_ExamID], 
[hDED].[rf_dent_ToothID] as [rf_dent_ToothID], 
[jT_oms_dent_Tooth].[Number] as [SILENT_rf_dent_ToothID], 
[hDED].[rf_ChartID] as [rf_ChartID], 
[jT_dent_Chart].[IsActive] as [SILENT_rf_ChartID], 
[hDED].[Date] as [Date], 
[hDED].[IsDeleted] as [IsDeleted], 
[hDED].[IsSupernumerary] as [IsSupernumerary], 
[hDED].[Iropz] as [Iropz], 
[hDED].[Note] as [Note], 
[hDED].[Flags] as [Flags], 
[hDED].[Guid] as [Guid], 
[hDED].[IsChild] as [IsChild]
FROM [dent_ChartTooth] as [hDED]
INNER JOIN [hlt_disp_Exam] as [jT_hlt_disp_Exam] on [jT_hlt_disp_Exam].[disp_ExamID] = [hDED].[rf_disp_ExamID]
INNER JOIN [oms_dent_Tooth] as [jT_oms_dent_Tooth] on [jT_oms_dent_Tooth].[dent_ToothID] = [hDED].[rf_dent_ToothID]
INNER JOIN [dent_Chart] as [jT_dent_Chart] on [jT_dent_Chart].[ChartID] = [hDED].[rf_ChartID]
go

