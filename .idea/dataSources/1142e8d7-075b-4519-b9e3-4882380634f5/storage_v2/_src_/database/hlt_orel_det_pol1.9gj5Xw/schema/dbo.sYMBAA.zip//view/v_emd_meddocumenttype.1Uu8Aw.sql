CREATE VIEW [V_emd_MedDocumentType] AS SELECT 
[hDED].[MedDocumentTypeID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[Code] as [Code], 
[hDED].[Name] as [Name], 
[hDED].[rf_DocTypeDefID] as [rf_DocTypeDefID], 
[hDED].[Flags] as [Flags], 
[hDED].[UGUID] as [UGUID]
FROM [emd_MedDocumentType] as [hDED]
go

