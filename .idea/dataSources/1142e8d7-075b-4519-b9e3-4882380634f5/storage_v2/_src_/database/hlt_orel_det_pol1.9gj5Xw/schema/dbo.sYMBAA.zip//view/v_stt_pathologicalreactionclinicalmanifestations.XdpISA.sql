CREATE VIEW [V_stt_PathologicalReactionClinicalManifestations] AS SELECT 
[hDED].[PathologicalReactionClinicalManifestationsID], [hDED].[x_Edition], [hDED].[x_Status], 
[hDED].[CODE] as [CODE], 
[hDED].[NAME] as [NAME], 
[hDED].[SCTID] as [SCTID], 
[hDED].[NAME_SYN] as [NAME_SYN], 
[hDED].[UGUID] as [UGUID], 
[hDED].[DATE_B] as [DATE_B], 
[hDED].[DATE_E] as [DATE_E]
FROM [stt_PathologicalReactionClinicalManifestations] as [hDED]
go

